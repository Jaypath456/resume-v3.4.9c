# MASTER RESUME CONTEXT — LEAN RUNTIME VERSION v3.4.9c (synced to Resume_Template_CURRENT.tex)

## 0-v349c) v3.4.9c RULES (read first; these win over every section below, including 0-v349b)
- Facts: Jay graduates in December 2026 and can start work in February 2027 (two separate facts). Education line "August 2025 -- December 2026" (never "Expected"). Coursework (master.json): Algorithms Analysis & Design, Computer Security, Intro to Machine Learning, Data Intensive Computing, Operating Systems, Data Models & Query Languages, Project Development, Deep Learning, Project Management. Agentic AI is a skill, never coursework. The hackathon award and the AWS certification stay facts in master.json but never appear on the page or in a letter.
- Page (page_v349c): the Standard reference layout (name line, "|" separators, Education on two lines with coursework under the Master's line, no Certifications & Awards section). Approved deviations (Jay, 2026-10-22): side margins 0.3in (not 0.4in) and Standard spacing on every page (not the NewGrad spacing). The page is not an exact match of the Trial2 visual spec.
- Spacing (spacing_v349c): after the content is fixed, section, role and list spacing grow to the largest step that still leaves one US Letter page with at least 10.5pt spare (the buffer is 10.5pt, not 10pt). Margins never change.
- Thesis (thesis_v349c): the first Thesis bullet is variant I (Agile/Scrum, reviewed and merged team pull requests); variant E (requirements first) only when a role line asks for requirements work. The HeinOnline mentoring line reads "Interviewed about 20 student candidates, onboarded and mentored the hires through weekly coding rounds over their first 3 weeks."
- Coursework (coursework_v349c): new-grad pages only, one line, the top 3 courses by posting terms (2+ courses must match); standard pages show no coursework line.
- Layout (layout_v349c): new-grad pages use 3/2/2 project slots chosen from the reference page's bullets; fit fallback per page: coursework line, then Skills filler, then one bullet slot. Skills at most 5 lines (a 6th only when every item needing it is posting-named); Python leads the Languages line on AI/ML postings. Approved exception: a Skills item may leave when its only bullet leaves with the 3/2/2 slot reduction (cardinal: Django REST Framework).
- Data (data_v349c): a required posting term the page does not show joins its Skills category (never from the unprinted coursework list).
- Must-have ranking (must_framework_v349c): a language or framework the posting requires (an unhedged qualification line, not a responsibility, a stack list, a preferred / plus line, alternatives or a list of 3+ technologies) whose single primary project is already one of the three becomes rank 1. The project set never changes.
- Closings (closing_v349c): every specific word of the closing's responsibility must appear in its proof's master evidence; otherwise the next responsibility is tried, then the role-family closing (whose claim must itself be in master evidence, else the general_swe closing). Generic verbs and qualities are not claims.
- Letters (letters_plain_v349c): exactly three paragraphs, 120-160 words, plain everyday English. P1: the position and company, then the hook as the connection to the posting. P2: the Experience item and the rank #1 project, at most one concrete achievement. P3: the graduation sentence (full-time "I graduate in December 2026 and can start work in February 2027."; internships keep their sentence), "I am open to relocating." for onsite roles outside Buffalo, NY, the grounded closing, a thank-you. Never tool or library names, digits (except the graduation sentence and the posting's own title or company name), hackathon or certification references, or "we / our / us". Resumes, tracker rows and outreach do not depend on the plain letter.
- Switches: master.json v347_flags data_v349c, page_v349c, thesis_v349c, coursework_v349c, layout_v349c, spacing_v349c, must_framework_v349c, closing_v349c, letters_plain_v349c (default true); all nine false gives the v3.4.9b outputs byte for byte (reports then say v3.4.9b).

## 0-v349b) v3.4.9b FORMAT RULES (still in force unless 0-v349c above changes them; these win over 0-v349a and below)
- Facts unchanged: Jay graduates in December 2026 and is available to start work in February 2027; two separate facts. No new claims: every number, name and claim still traces to master.json.
- Page: US Letter (`letterpaper`), Times (`\usepackage{mathptmx}`), 0.3in side margins, 10pt. The A4 notes in section 6 describe v3.4.9a and earlier. Header: email | phone | NY, US | linkedin.com/in/jaypathare3 | github.com/Jaypath456 (the visible address is the link text; no portfolio link on the resume). Section rules 0.2em above / 0.25em below; 3pt between projects.
- Bold results: the script bolds a numeric result plus up to 3 following words, at most 2 per bullet, only in Experience and Personal Projects bullets (never headings, dates, Skills, links, the letter, the tracker or outreach). Removing the bold gives exactly the plain text. Never add bold by hand.
- Skills: at most 5 rendered lines, one line per category. When a category runs over, items leave from the end: filler first, then posting-named skills the page already shows, then other posting-named non-priority skills (listed in the "Skills full" note), then must / high terms that a bullet, Experience line or project heading already shows (the ATS check still finds them). Required ATS terms and page technologies always stay; if they alone need it, one category takes a second line (a 6th line only when all 5 categories are shown).
- Fit to one Letter page with 10pt spare, in this order: slots 3/3/3, then 3/3/2, then 3/2/2 (a fallback page keeps a subset of the 3/3/3 bullets and the same letter); then the optional coursework line leaves; then one bullet slot leaves the lowest-ranked project with two or more (subset, same letter). Page order by date and rank are unchanged.
- Two reference trims on Letter: the HeinOnline "Interviewed" Experience line uses its short form ("Interviewed about 20 student candidates and onboarded the hires through weekly coding rounds over their first 3 weeks."), and the AWS certification line is not shown. Both are facts in master.json.
- Bank: two variants were reworded for the Letter line width (ripple.tests.s2 replaces ripple.tests.s1; pintos.tests.c replaces pintos.tests.a): same numbers, no new names, no more words. bank_check measures on Letter with bold, tail floor 0.30.
- Switches: master.json v347_flags bank_format_v349b, format_letter_v349b, bold_results_v349b, skills_cap5_v349b, letter_trims_v349b (default true); all five false rebuilds the v3.4.9a A4 page byte for byte.

## 0-v349a) v3.4.9a RULES (still in force unless 0-v349b above changes them; these win over 0-v348c and below)
- Facts unchanged: Jay graduates in December 2026 and is available to start work in February 2027 (subject to OPT/EAD approval); two separate facts.
- Reading the posting: headings like "What sets you apart", "Nice to have", "Bonus", "Ways to stand out" and "Preferred" are preferred, never required. "About You" alone is not a requirements heading: the sub-heading under it decides. Lines in example lists ("Some examples:", "for example", "for instance", "projects like") and company-voice asides ("(we use PostgreSQL and SQL Server)") are context: never requirements, hard gaps or jd_requirements_extra. "A and/or B", "A or B" and "at least one of" are alternatives.
- Years: "0-3 years" / "1-3 years" mean a minimum of 0 / 1; a years note appears only when the stated minimum is 3 or more. A company-history phrase ("for more than 25 years") is never a years requirement.
- Fit: preferred, example or context items never make Fit Low. Low comes only from a must-have gap or a blocker. Stack gaps never cap Fit (unchanged).
- Bullets: a number only breaks ties between equally relevant bullets (no flat number bonus). The LLM engine's resume-wording bullets ("write resume bullets", "resume-generation") appear only on postings about documents or resumes; its failover and claim-check bullets are preferred.
- Ranking: one scoring path. The theme-first score orders the projects and the legacy score breaks ties (never list order). The role family's anchor project leads unless another project beats it clearly (by 2 points on standalone + legacy / 2). A lead language the posting singles out still leads. report.json ranking_v349 shows every score and the reason. The GoingOnce Fleet bullet still appears only on logistics postings: when no same-shape swap exists, the selector picks again without it.
- Page order: the three projects are shown newest to oldest by master.json date (ties by rank). Slot counts stay by rank (rank #1 gets the most bullets); rank #1 is the project with the most bullets, not the first one on the page. Headings and Skills follow rank, so only the order of the blocks (and the tracker's Projects Used) follows the date. Every page stays one page.
- Closing proof: the proof is an evidence id whose bullet is on the page (checked by id, not digits), or an Experience line on the page; otherwise another on-page proof, else the role-family closing. A proof not on the page fails the build (closing_proof_not_on_page).
- Copy rule: the hook and a model-written closing need 3 or more content words from one responsibility line (no longer 4 consecutive words); the hook may paraphrase and never copies a typo or "our / we / us" ("our backend systems" becomes "DoorDash's backend systems"; "we" or "us" fails). A closing phrase stops before a trailing bare singular phrase ("develop and maintain services", not "services for control plane"). "Design  develop" verb pairs get their "and".
- Skills: one name per alias group (React + ReactJS -> ReactJS). Formats (JSON, HTML/CSS, ...) sit on the Languages line, never Tools. A vendor API already in a rendered project heading is not repeated in Tools unless the posting names it. A posting-named term is never dropped.
- Tracker: tracker_row.json has company_key (the company lowercased, without punctuation or suffixes such as Inc, LLC, Ltd, Corp, Corporation, Technologies, Information Services). Update an existing row when company_key AND Role match (keep the longer official name); otherwise append. "Akamai" and "Akamai Technologies" are one company.
- Switches: master.json v347_flags jd_sections_v349 (1), years_range_v349 (2), fit_guard_v349 (3), bullet_score_v349 (4), ranker_v349 (5), date_order_v349 (6), proof_on_page_v349 (7), copy_rule_v349 (8), skills_dedupe_v349 (9), company_key_v349 (10) (default true); false restores v3.4.8c behaviour for that fix only.

## 0-v348c) v3.4.8c RULES (still in force unless 0-v349a above changes them; these win over 0-v348b and below)
- Facts unchanged: Jay graduates in December 2026 and is available to start work in February 2027 (subject to OPT/EAD approval); two separate facts.
- Start dates: "2026 Start", "Start date: 12/01/2026", "Target start date: 12/01/2026", "commit to an onboarding date by end of year 2026" and "start in (early / late) 2026" count as a start before February 2027 and add the Timing note "Timing check: the posting mentions a start before February 2027. Graduates December 2026; available to start February 2027 (subject to OPT/EAD approval)." Never a blocker, never a Fit change; only Notes / Timing change.
- Bank wording (same facts, new variant ids; the old ids stay for the switch): GoingOnce interface goingonce.ui.c ("Created the Streamlit and React interface for the agents' streaming API ..."), RIPPLE ripple.git.c (names what the Git-diff check flags: unexpected edits, missing tests, stale callers), ripple.eff.b ("Measured agent usage at about 10 tool calls and about 17 model calls per run ..."), ripple.cc.d ("Wrote RIPPLE with Claude Code as a coding assistant, checking its output with RIPPLE's 241-test suite ...").
- Fleet: GoingOnce's Fleet bullet stays only on supply-chain / warehouse / logistics / vehicle-fleet postings. Where the in-place swap of 0-v347c finds no other bullet, the plain-code bullet without "Claude" (goingonce.determ.b: plain code for search, history checks, pricing, negotiation math and logistics; a language model only for language and photos; a saved fallback for every call) is the last resort; where that fails too, the GoingOnce set is picked again without Fleet (other GoingOnce bullets may change). Projects, order, slot counts, headings and Skills never change; the letter changes only in the sentence that cited Fleet. FAIL-CLOSED: otherwise the page keeps Fleet and report.json fleet_v348c says why.
- Skills: "Languages & Databases" lists languages (Python, Java, JavaScript, HTML/CSS, C, Go, SQL) first, then databases, each in its posting-relevance order. A line with fewer than 3 items gains master-supported languages / databases that the page's own bullets show, up to 3 (e.g. "Python, SQL, PostgreSQL"). No other Skills line moves.
- Headings: when a posting-named technology leaves one project heading (0-v347a) and no other heading names it, it joins the heading of the selected project whose bullets show it, only if that heading has fewer than 4 technologies; nothing is displaced and Skills never change. ats_coverage lists "header" only when a rendered heading shows the term.
- Closings: the proof follows the responsibility. Model training / optimization / accuracy / latency -> Fraud's measured results when Fraud is on the page (GraphSAGE 0.9259 against about 0.858 AUC-ROC, the edge-type ablation, the leakage controls); agent / evaluation / LLM reliability -> RIPPLE's evaluation; integrations / APIs -> LedgerFlow exactly-once; permissions / access -> LaunchOps server checks; interactive / real-time -> LaunchOps live quiz or the GoingOnce interface; testing -> CI and test suites; operations / monitoring -> the Thesis heartbeat. The proof is always a project on the page and never repeats a letter fact. A generic responsibility ("design, develop, and maintain software applications") moves to a posting responsibility that names the product, users or domain only when it is clearly more specific (the script's specificity score at least 2 higher, with at least 2 domain words); otherwise the closing stays. Closing validators unchanged (<= 30 words, no repeated proof, clause boundary, company named, letter <= 200 words).
- Switches: master.json v347_flags start_date_parse_v348 (T), bank_wording_v348 (W), fleet_language_model_v348 and fleet_repick_v348 (F), skills_lines_v348 (S), heading_move_v348 (J), closing_proof_map_v348 and closing_specific_v348 (C) (default true); false restores v3.4.8b behaviour for that fix only.

## 0-v348b) v3.4.8b RULES (still in force unless 0-v348c above changes them; these win over 0-v348a and below)
- FACT (confirmed by Jay and the university, 2026-10-19): Jay's Master's in Computer Science at the University at Buffalo runs August 2025 - December 2026; he graduates in December 2026 and is available to start work in February 2027 (subject to OPT/EAD approval). Graduation and start date are two separate facts: never call February 2027 a graduation date, and never say he can start in December 2026.
- Resume Education line: "August 2025 -- December 2026" (Resume_Template_CURRENT.tex; v3.4.9c: no "Expected"). The page stays one page.
- Letter logistics: full-time "I graduate in December 2026 and can start work in February 2027."; internships "My Master's in Computer Science at the University at Buffalo is expected in December 2026, and I can start work in February 2027." Plus "I am open to relocating." for onsite roles outside Buffalo, NY. Letters stay <= 200 words.
- Eligibility and timing: graduation windows, graduating-class notes, enrollment-required internships and rising-senior / continuing-student programs use December 2026 (one month of tolerance: "December 2026 - June 2027" includes him, "May 2027 - May 2027" does not). Start-date checks use February 2027 (a posting that starts in January 2027 gets a Timing note). Internships that require enrollment during or after the internship, or that start after December 2026, get the enrollment blocker (a note; never a skip). Timing notes read "Graduates December 2026; available to start February 2027 (subject to OPT/EAD approval)". There is no separate OPT date.
- Outreach notes never name dates (unchanged).
- Switch: master.json v347_flags graduation_dec2026_v348 (default true); false restores v3.4.8a behaviour.

## 0-v348a) v3.4.8a RULES (still in force unless 0-v348b above changes them; these win over 0-v347c and below)
- Outreach: print report.json outreach.linkedin.block_md exactly. It has a Company / Job post (/ Req) line of markdown links, then four numbered sections (1. Hiring manager, 2. Software engineers / team members, 3. Technical recruiters, 4. University at Buffalo alumni), each with one people-search link and its note alone in a ```text block. Never rewrite the notes; Jay fills {Name} and sends them. outreach.linkedin.block is the old plain form, kept for compatibility.
- Notes read as Jay typed them: short, warm, plain words; <=300 characters; no digits, project names, metrics, requisition IDs, "referral", "considered", "opportunity to", "I am excited", "passionate", exclamation marks or dashes; end "Thanks, Jay" or "Best, Jay". Background stays generic (MS in CS at UB, startup experience, internships, one domain phrase from master outreach.domain_phrases_v348). Alumni: their path and work, never the application. Engineers: their work and team, no job ask. Hiring manager and recruiter: the application once, lightly, then background and an easy close. A failing note fails the build.
- Employer statements: "<Org> is searching for / is looking for / is seeking / seeks / is recruiting" (a capitalized name, never "We", "The team", "Our client") is recorded like "<Org> is hiring" (0-v347a). Notes only, never a rename; the Notes line appears only when that employer differs from application.company.
- Hook: when the posting lists no responsibilities, the hook may copy its 4+ consecutive words from the posting's role summary (a "<Org> is hiring a ... to ..." sentence, the "The Role" / "About the role" paragraph, or the first paragraph about the job). The script's hook check uses that summary too, and compares job-title words without trailing hyphens or punctuation ("Developer-" = "Developer"). The letter text never changes because of it.
- Switches: master.json v347_flags outreach_v348, employer_phrasings_v348, hook_fallback_v348 (default true); false restores v3.4.7c behaviour.

## 0-v347c) v3.4.7c RULES (still in force unless 0-v348a above changes them; these win over 0-v347b and below)
- Fleet bullet: GoingOnce's Fleet bullet (rental cars in full truckloads) appears only on supply-chain / warehouse / logistics / vehicle-fleet postings. On every other posting the script replaces it with another GoingOnce bullet of the same line count, with a new evidence id and a verb no other page bullet uses, and only when the selector reproduces that exact page; otherwise the Fleet bullet stays (FAIL-CLOSED). Project choice, order, slot counts, Skills, Fit and the letter never change, except that a letter sentence giving the Fleet fact becomes the replacement bullet's letter sentence. report.json logs each swap in strict_fleet_v347c. Never write a Fleet sentence into the letter by hand on a non-logistics posting.
- Switch: master.json v347_flags strict_fleet (default true); false restores v3.4.7b behaviour.

## 0-v347b) v3.4.7b RULES (still in force unless 0-v347c above changes them; these win over 0-v347a and below)
- Sponsorship: only the employer's own clearly negative wording creates a sponsorship blocker ("will not / cannot / unable to / does not sponsor", "must be authorized to work without sponsorship (now or in the future)", "no visa sponsorship", "U.S. citizenship or green card required"). Positive or neutral text ("sponsorship available", "will sponsor", "has sponsored"), job-board badges ("H1B Sponsor Likely") and Department of Labor statistics never block; they go in Notes as "Sponsorship information (not a blocker)". Wording that is neither clearly negative nor clearly positive keeps the earlier behaviour and Notes says "Sponsorship wording unclear: check manually".
- OR-groups: "at least one of (the following):", "one or more of", "any of" followed by list lines, and an inline "A, B, or C" in one requirement line, are one OR-group. If any member is covered, the other members are never hard gaps or stack gaps and never lower Fit; Notes lists them as "OR-group alternatives Jay does not have". A member also named on its own in another posting line stays a gap, and an unclear list keeps the earlier reading. "hallucinations", "hallucination mitigation" and "grounding" count as covered by the claim-check evidence (RIPPLE's zero-unsupported-claims evaluation and claim checks; the LLM engine's claim checks); no new bullet text. Fit rises at most one level from this rule.
- SQL: a literal "SQL" in a database requirement line ("databases such as SQL Server, MySQL, ...") is a requirement term (coverage only; it never changes Fit).
- Bullets: GoingOnce's Fleet bullet is preferred only on supply-chain / warehouse / logistics / vehicle-fleet postings ("shipping ML systems" or "shipping software" is not logistics). Within a selected project the script swaps one bullet only when another bullet of the same project and size scores clearly higher against the posting's responsibility and requirement lines; project choice, order, slot counts, line counts and verb uniqueness never change. AI / ML / LLM / agent postings favour GoingOnce's multi-agent + human-approval, Negotiate and plain-code-with-saved-fallback bullets; LLM-limitation lines favour RIPPLE's claim-check bullets.
- Each v3.4.7b fix has a switch in master.json v347_flags (sponsorship_polarity, or_groups, sql_parse, bullet_relevance; default true); a false switch restores v3.4.7a behaviour for that fix only.

## 0-v347a) v3.4.7a RULES (still in force unless 0-v347b above changes them; these win over 0-v346 and below)
- Relocation: "I am open to relocating." goes in every onsite or hybrid letter outside Buffalo, NY. Only the city Buffalo with NY / New York counts as local; "Buffalo Grove, IL" and any other place containing "Buffalo" get the sentence. Remote postings never mention relocation.
- Project headings: a technology the posting names that the script adds to a heading (beyond the project's core stack, master header_priority_tech) stays only on the selected project whose bullets best show it, at most one heading. It leaves a heading whose bullets do not show it when another selected project's heading or bullets do (a React bullet shows JavaScript, a Django bullet shows Python). Core stack and a posting technology only one project can show (Maven on LedgerFlow) always stay. Skills are unchanged.
- application.company is the organization the posting says has the opening or receives applications ("<Org> ... has openings", "<Org> is hiring", "send resume to <...@domain>"). A different job-board or header label (e.g. "company: Capgemini" on a Meritore Technologies LLC posting) goes in Notes: "Posted under <label>; the posting names <employer> as the employer." The script never renames anything. The recruiter / agency rule is unchanged. The letter names only application.company as an organization; a sentence naming another organization from the posting fails (cover_letter_two_organizations): fix the hook.
- report.json: verify_changes_v344 lists only posting-driven changes, each quoting a JD line; script-rule changes (variant J, preferences with no posting line) are in internal_changes with a reason. When hook_specific is false, cover_letter.hook_specific_reason says which test failed. When the company is "Not stated", the outreach people searches leave the company out and the block says the company is not stated.
- Each v3.4.7a fix has a switch in master.json v347_flags (default true); a false switch restores v3.4.6 behaviour for that fix only.

## 0-v346) v3.4.6 RULES (still in force unless 0-v347a above changes them; these win over section 0 and below)
- RIPPLE: the tool-calling bullet says "seven code-analysis tools" (master: 7 code-analysis tools), never "static-analysis".
- Skills: when a posting line asks for a web application server, an ASGI server or an async server and LaunchOps is on the page, Skills show "Daphne/ASGI" (LaunchOps runs on Daphne). Never added for postings that do not ask.
- Letter logistics (paragraph 2) always state when Jay can start. Full-time: "I graduate in December 2026 and can start work in February 2027." Internships: "My Master's in Computer Science at the University at Buffalo is expected in December 2026, and I can start work in February 2027." (v3.4.8b) Plus "I am open to relocating." for onsite roles outside Buffalo. The script fails a letter whose second paragraph has no start clause.
- tagline_text is script-checked: a domain or scope phrase (platform, integrations, AWS, cloud, commerce, payments, content, safety, permissions, live, devices and the like) fails the run (tagline_unsupported_scope, naming the phrase) unless one selected bullet or Experience line on the page names every word of that phrase. Rewrite tagline_text, or use tagline_id; there is no plan.json switch.
- Experience variant J (approved by Jay 2026-10-16, verb-only): "Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data and generate automated anomaly reports for the compliance and audit team." Only the opening verb changes. The script uses it whenever another Experience bullet on the page opens with "Developed", and fails any page where two Experience bullets open with the same verb. "Authored" is now an Experience verb, so no project bullet may use it.

## 0) v3.4.5 AUTHORITATIVE RULES (read first; these win over any older section below)
- Stack gaps: a technology the posting names only on a "Stack:", "Tech stack:" or "Technologies:" line (in any section) is a stack gap. It is reported in Notes and in jd_gap_terms_detected and never caps Fit. Every jd_gap_terms_detected term is either a hard gap or listed in the stack-gaps note. Currency codes (USD, CAD, ...) are never requirements. An "About the Team / Role / Job / Position" heading ends the company intro.
- Skills: every supported skill the posting names shows in Skills (Kubernetes as "Kubernetes (local k3d)"); a vendor API that a project heading already shows is dropped first to make room. A project heading technology always shows in Skills. ML postings drop Spring Boot and Full-Stack Development (unless named) and show "Data Preprocessing" when the posting asks for preprocessing.
- Ranking: an automatic override never inserts a project the role family avoids or displaces the family's first preferred project unless a posting line explicitly asks for LLM evaluation or provider failover; the report shows the override reason, the displaced project and any blocked override. On agent / content-safety ML postings GoingOnce is #3 ahead of the LLM engine. Relevance beats novelty in the closing proof (ElevenLabs: LaunchOps ownership and prerequisites, not the quiz sync).
- Letter: on ML / AI / agent postings the LLM engine sentence never says it turns a job description into a tailored resume and cover letter. Sensor / IoT / device postings lead with the Thesis IoT sentence. Defect, debugging, ops, on-call and monitoring lines count as operations themes (variant G is considered). The closing ends at a clause boundary (never "... systems that adapt at <company>"), and the repeat check runs on the final closing.
- Bullets: one Fraud bullet names IEEE-CIS; ML postings prefer the edge-type ablation and leakage-control bullets. Go Digital stays only on data engineering / analytics / fintech / compliance postings or when the posting asks to analyze data. Warehouse / logistics postings use the GoingOnce Fleet bullet. NoSQL postings use the LaunchOps MongoDB quiz bullet. RIPPLE says "testing edge cases across real repositories". The second Pintos bullet does not repeat "teaching operating system ... in C". The GoingOnce interface bullet never pairs the UI with the team's 24 tests.
- Education: GPA inline after the degree name, one right-aligned date per degree line. New-grad AI/ML postings, or postings that ask for coursework, add a "Relevant coursework" line (v3.4.9c: new-grad pages only, top 3 matching courses; see 0-v349c; dropped if it would break one page).
- Verify quotes come from role sections only (never company intro text or the bare title) and contain a term of the changed item.
- Outreach to a UB alum asks for advice, never a referral.
- tagline_text describes only work Jay has done, in the posting's words; never a domain or scope he lacks (not "AWS integrations", "for connected commerce", "content quality and safety", "AWS applications").
- If a tracker write fails, the reply's first line is "TRACKER NOT UPDATED: <reason>".

## 0-v344) v3.4.4 RULES (still in force unless 0 above changes them)
- Closing (one sentence, <= 30 words, Jay is the actor): "I want to <build / improve responsibility from the posting> at <company>, <building on | drawing on> <proof>." The proof never repeats a fact, number or phrase the letter already gives, and it matches the claim: well-tested / reliable -> CI and test suites; integrations / APIs -> LedgerFlow exactly-once; permissions / auth -> LaunchOps server checks; interactive / real-time -> LaunchOps live service; embedded / systems -> Pintos or the Thesis IoT pipeline; operations / monitoring -> the Thesis heartbeat monitor and failure response. A responsibility with a scale claim the evidence cannot back ("millions of concurrent users") is skipped. Never "build ... building on". A clause that ends mid-phrase fails. The generic role-family closing is the last resort (at most 10% of fixtures). The model may set cover_letter.closing itself: one sentence, <= 36 words, 4+ consecutive words from a responsibility line, the company named in full, the proof project named; it is kept only when it passes these checks.
- Letter experience sentence: code review / debugging / operations / mentorship postings use the Thesis evidence (reviewed and merged team pull requests, mentored new hires through weekly coding rounds, responded to heartbeat-detected failures and restored services); stakeholder / requirements postings keep the requirements-gathering sentence; data / ML roles keep HeinOnline or Go Digital; healthcare postings keep the healthcare Thesis sentence.
- Letters stay <= 200 words counted as a reader counts them (greeting and sign-off included). RIPPLE: Claude Code helped write RIPPLE and Jay checked its output with RIPPLE's 241-test suite (never "RIPPLE, whose AI-generated code").
- Hook: says why the work appeals (the product or its users), in the posting's words, not only a restated responsibility. Tagline: names the posting's focus in its own words.
- GoingOnce: the 24 tests and the award stay team-scoped ("backed by the team's 24 tests"); the project-level bullet says "with a four-person team" with no second "with". Pintos bullets open with "Implemented" (Jay wrote the layer); the second Pintos bullet covers synchronization and memory safety only.
- The LLM engine's "three AI workers ... 73%" bullet never appears on ML-infrastructure or agent postings (it reads as resume automation); its failover and claim-check bullets lead instead. "Operating systems in production" never adds the Operating Systems skill. A project heading keeps ReactJS when a selected bullet shows React and the posting names React. A posting that names software design patterns prefers LedgerFlow's transactional outbox / idempotent consumer bullet. Preflight lists required posting terms that appear only in Skills or a heading and prefers a bullet or approved variant that names them (dropped when it would cost the one-page buffer).
- Experience variant I (approved by Jay 2026-10-16), for postings naming Agile, Scrum, code review or pull requests: "Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements in client meetings, prototyped to validate scope, and reviewed and merged team pull requests." It is the only variant that may add facts, and only these master-recorded ones (Agile/Scrum; reviewed and merged team pull requests); it renders the same number of lines.
- The verify report (report.json verify_changes_v344) quotes the posting line behind every change; "selected the updated variants" is never enough.
- Job-board widget sections are removed before parsing: "Represents the skills you have", "Find out how your skills align", skill-tag lists, "H1B Sponsorship ... (Data Powered by US Department of Labor)", "Distribution of Different Job Fields Receiving Sponsorship", company-profile lines (Founded, crunchbase, linkedin, company-logo, employee counts) and markdown widget lines ("image**Improve My Match**", "svg**40**Low Match", "&#x20;"). Informational sponsorship text never creates a no-sponsorship blocker; only the employer's own requirement text can.
- A company name ending in "." never produces ".." anywhere (letter, outreach notes, tracker).
- Tracker (section 14): 11 columns; every new row starts with Status "Applied"; "status: <Company> | <Role> | <Rejected / Interview / Offer / Withdrawn>" updates the exact Company AND Role row (Status and Outcome Date only). The chat reply still prints the visa / sponsorship note; only the sheet column is gone.

## 0a) v3.4.3 RULES (still in force unless 0 above changes them)
- Confirmed by Jay 2026-10-15: LedgerFlow's GitHub Actions CI runs all 94 tests, and its integration tests run against real PostgreSQL and Kafka in containers (Testcontainers). RIPPLE's Git-diff check is RIPPLE's automated check ("Added a Git-diff check that flags unexpected edits, missing tests, and stale callers"), never manual review; bank bullets say "Created" because "Added" is an Experience verb. Fraud: Jay built the whole notebook himself; always his own work, never team work. GoingOnce: a four-person team; Jay worked on all four agents (mainly Negotiate and Fleet) and built the Streamlit/React front end; feature bullets may describe any agent (Buy, Sell, Negotiate, Fleet); the project-level bullet keeps "with a four-person team"; never imply he built the whole system alone (this replaces the old "never claim Buy or Sell alone" rule). Pintos: "all 80 tests" (never the redundant "of 80" wording).
- No job title in the paste -> the run stops with "stop: paste the job title line" (no package, force cannot override). The role must be the posting's own title line.
- "Bachelor's + N years OR Master's + M years" -> one note that evaluates both options (Jay: Master's expected December 2026, about 2 years of professional experience).
- Job-board widget lines ("Let's Strengthen Your Resume", "X out of 5 keywords matched", "Low Match", "Improve My Match") are removed before parsing. "Data classification" in the governance sense (storage, policy, handling) is not ML, never ranks Fraud and never adds the Classification skill. "We spark listeners' imaginations" is not Spark.
- Generic method phrases map to evidence and never lower Fit: log analysis -> Debugging; metrics examination -> Application Monitoring; testability -> Unit Testing; data storage / management -> PostgreSQL. "AWS" in a posting names the AWS (EC2/RDS) entry.
- Skills: AI coding tools show only as the posting names them (Claude Code also when it asks for AI coding tools); Cursor / GitHub Copilot never auto-expand. Off-role frameworks leave Skills (LangGraph / Streamlit on non-AI roles, Pydantic unless the posting or a bullet names it, Pandas / NumPy / ML libraries on non-data roles); a line of 3 or fewer swaps in a framework the page already shows, or else gets shorter; headings may still show them. Each line is ordered by posting relevance. A posting-named supported skill is never trimmed for a filler. When AI/ML appears only in preferred lines, the AI/ML line shows only terms the page backs (never Machine Learning or Model Evaluation without a bullet).
- Project headings may add one posting-named technology master lists for that project (Maven for LedgerFlow, JavaScript for LaunchOps / GoingOnce).
- Agentic / ML-infrastructure postings that ask for distributed systems keep LedgerFlow on the page instead of a project with no distributed evidence (project #1 and the LLM engine, when the reliability rule added it, stay).
- Closing (script-written, <= 30 words, Jay is the actor): "I want to <responsibility> at <company>, building on <proof>." Only build / improve responsibilities qualify (build, design, implement, test, deploy, integrate, monitor, improve...); growth / environment lines (work alongside, mentors, gain exposure, grow, learn, own features) never do. Proof map: permissions / auth -> LaunchOps access control; interactive / real-time -> LaunchOps live service; integrations / APIs -> LedgerFlow exactly-once; embedded / systems -> Pintos or the Thesis IoT pipeline; testing -> CI / test suites. Nothing qualifies -> the role-family closing.
- Hook: says what draws Jay to the work (first person), never a description of the team, and names the company's own product or domain in the posting's words (e.g. "connected commerce", "warehouse management systems", "audiobook").
- New-grad layout, only when the title or posting says new grad / new college grad / university graduate / early career / recent graduate or names a 2026 / 2027 graduating class (plain "entry level" never does): Education, Experience, Personal Projects, Technical Skills, Certifications & Awards; the Go Digital internship is left off unless the role is data / fintech / compliance; projects #2 and #3 get a third slot when the bank has a third distinct evidence item and the page keeps its buffer (3/3/3, else 3/3/2, 3/2/3, 3/2/2). Everything else is unchanged.
- Experience variants are approved (A-H) and on (`experience_variants_enabled` true): a variant may drop facts but never adds a fact, number or tool; its opening verb may change only when no other bullet on the page starts with it; it renders the same number of lines.
- Tracker: update an existing row only when Company AND Role match exactly; otherwise append a new row. A generic key (e.g. "Cisco_Application") never overwrites a row.
- No ".." after a company name that ends in a period ("Audible, Inc.").

## 0b) v3.4.2 RULES (still in force unless 0 above changes them)
- v3.4.2 facts (confirmed by Jay 2026-10-15): LedgerFlow's GitHub Actions CI workflow runs its 94 automated tests. Claude Code's output on RIPPLE was checked by running RIPPLE's 241-test suite (this replaces "corrected its generated code multiple times").
- Eligibility never skips: every posting gets a full package. Sponsorship, citizenship, clearance, graduation-window and rising-senior / enrollment blockers go in report Notes and the tracker's Blockers column (a firm no-sponsorship, citizenship, clearance, graduation-window, rising-senior or enrollment blocker caps Fit at Low). Only a paste with zero parsed requirements stops ("stop: <reason>").
- The AI/ML skills line appears only when the posting has an AI/ML theme or names AI/ML terms in its role lines. No line-count floor adds it.
- Language-led roles: when the title, or a required / preferred line, singles out ONE language, project #1 is Jay's strongest project in it (Java -> LedgerFlow, C -> Pintos). A list of several languages never triggers it, and an AI / ML / data / frontend / mobile title is not overridden by a language line in its body.
- Testing, TDD, test design, CI/CD, continuous delivery and GitHub Actions postings prefer the LedgerFlow CI bullet and RIPPLE's 241-test check. GitHub Actions joins the LedgerFlow heading when the CI bullet is on the page and the posting names it.
- Letter sentences follow the posting's top requirements: permissions / authorization roles get the LaunchOps access-control sentence (blocks edits to other users' tasks); embedded / systems roles lead with Pintos or the Thesis IoT pipeline; testing-heavy roles include the 94-test CI sentence.
- Closing: leave `cover_letter.closing` empty and the script writes one sentence naming the posting's top responsibility in its own words plus Jay's matching proof from the letter's projects. A closing that starts "I would welcome the chance" is rejected.
- Show "Kubernetes (local k3d)", never bare Kubernetes. OAuth/Auth0 shows when the posting names OAuth, SSO or authentication.
- Skills filler: "Claude API" only when GoingOnce is on the page or the posting names LLM APIs ("Claude Code" is a coding tool, not the Claude API). A 1-line pair partner never restates its project's first bullet. At most 2 terms from one synonym group.
- Internship letters for onsite roles include "I am open to relocating."
- Every run writes judge_packet.md (evidence inventory from master.json + eligibility notes + posting + resume text + letter); `3_validation/combine_judge_packets.py` merges several into one judge batch.
- (v3.4.3: Experience variants A-H are approved and enabled; see section 0.)

## 0c) v3.4.1 RULES (still in force unless 0 above changes them)
- The script decides projects, bullets, skills and letter sentences. The model fills only the plan fields named in the Project instructions and never rewrites bullet, skills or letter prose. Model-written fields (company, role, location, visa, hook, closing, team_focus, tagline_text) are cleaned by the script: list bullets, smart quotes, zero-width characters and emoji are removed.
- (v3.4.2 replaces the SKIP verdict: blocked postings are built with the blocker in Notes and the Blockers column.) A firm requirement for U.S. citizenship, a U.S. security clearance, or "no visa sponsorship" is a hard blocker; the same words in a bonus / "ways to stand out" list, or worded as a preference ("clearance preferred"), stay soft notes. Text with no job requirements (a recruiting ad) ends with "stop: <reason>".
- Tagline: the model writes `plan.tagline_text` under the Project-instruction rules (<= 96 chars, starts "Master's CS student "). The section-16 bank is only the fallback when tagline_text is empty.
- Projects display in RANK order (#1 on top), not newest-first. Dates stay on each heading.
- Bullet slots: #1 gets 3 slots, #2 and #3 get 2. Every slot renders exactly 2 lines: one 2-line bank bullet, or two 1-line bank bullets from the same project that state different real facts. No filler clause is ever added to reach a second line.
- Project bullets never start with a verb the Experience section uses: Engineered, Merged, Parallelized, Standardized, Led, Developed, Delivered, Containerized, Built, Interviewed, Deployed, Automated (plus Reviewed, Added, Cut). Every project verb on the page is different. Allowed verbs live in master.json `project_verbs`.
- Technical Skills are gated (no protected baseline): a skill appears only if the JD names it and Master supports it, a selected project shows it, it is a universal basic (Python, SQL, Git), or the page visibly shows it. OOP, Agile, System Design, API Design, Code Review, Debugging, Kubernetes and Incident Response appear only when the JD names them. A JD that names both members of a synonym pair ("SQL and relational databases") shows both; a JD that names one member shows that wording. Postings that say they are not ML roles get no ML filler skills.
- JD wording mapped to existing evidence only: authentication -> JWT (LaunchOps); terminal / command line -> Linux; reading logs -> Debugging; logging -> Application Monitoring; documentation is a soft skill (never a skill or a gap).
- AI coding tools: (v3.4.3) only the tools the posting names; Claude Code when it asks for AI coding tools. A required/responsibility line asking for AI coding tools forces RIPPLE onto the page with its Claude Code bullet, and the cover letter's second project becomes RIPPLE with the Claude Code sentence.
- Letter lead experience: LLM / document-extraction roles lead with HeinOnline (healthcare ones add the Thesis healthcare-platform sentence); data and ML roles lead with Go Digital ETL (data engineering) or HeinOnline extraction; other healthcare postings use the Thesis healthcare-platform + client-requirements sentence.
- "Intelligent / information / business systems" titles are not operating-systems work; "distributed training" is ML, not distributed backend systems. "Washington, D.C.", "Objective-C" and "C/C++" never count as the C language.
- No TypeScript anywhere: GoingOnce and LaunchOps are ReactJS.
- GoingOnce: (v3.4.3) four-person team; Jay worked on all four agents (mainly Negotiate and Fleet) and built the Streamlit/React front end; feature bullets may describe any agent; never imply he built the whole system alone; tests and the award stay team-scoped.
- Full-time letters end logistics with "I graduate in December 2026 and can start work in February 2027." Internships say the Master's is expected in December 2026, and I can start work in February 2027 (v3.4.8b). Never "soon after".
- A resume or cover letter pasted after the posting is removed before parsing (report: quality_v33.json jd_pasted_material_removed).
- Data Maven provisioning: never name a tool (none is recorded). The ~40% setup reduction is an estimate; keep the "~".

> Purpose: fast JD-based resume and cover-letter tailoring. This file is the factual source of truth. `Resume_Template_CURRENT.tex` controls formatting/layout. The JD controls relevance only.
> Fixed sections (header, Experience, Education, Certifications & Awards) are copied verbatim from `Resume_Template_CURRENT.tex` and must match it exactly. If this file and the template ever differ on fixed text, stop and flag the mismatch to Jay instead of choosing silently. For everything else (projects, skills pool, evidence, boundaries), this file wins.
> Text below is a plain-text rendering of the template: `~` stands for `$\sim$` and `%` for `\%` in the LaTeX source.

## 1) CORE CONTRACT
- Never invent evidence or move facts/metrics/technologies between jobs/projects.
- Professional Experience is fixed.
- Evaluate all 7 active projects for every JD; select exactly 3.
- Relevance rank controls bullet allocation: #1=3, #2=2, #3=2.
- Display selected projects newest-first; ties go to higher relevance.
- Technical Skills start from the protected baseline and may add only supported, JD-relevant skills.
- Unsupported JD requirements remain gaps.
- Metrics may be omitted, never strengthened, changed, or re-attributed.
- Truth/evidence grounding outranks ATS keyword overlap.

## 1B) PLAIN-ENGLISH WRITING RULES (READER = TECHNICAL HR)
The first reader is a technical recruiter who sees the page for the first time and has no context. Every generated line must be understood in one read. These rules apply to all generated project bullets, the skills lines, and the cover letter. They do NOT apply to the fixed Experience bullets, which are copied verbatim from the template and never rewritten.

Keep only what helps a recruiter decide:
- One main accomplishment per bullet, then at most one supporting detail.
- At most 2 numbers per bullet: one result and one scale (for example, a percentage and a count). Everything else stays in the evidence, not on the page.
- State a result once. Use a percentage OR a before/after pair, never both. Wrong: "cut runtime by about 73% (about 11 minutes to about 3)". Right: "cut runtime by about 73%".
- No internal, test-harness, or tool-brand jargon. If a term would need a footnote, replace it with what it does.
- At most 2 named technologies per bullet, and only if they explain the work or match the JD.
- Plain verbs and short clauses. No stacked parentheses, no semicolon chains, no slash lists.
- Say what the thing does for a user or a business before how it works.

Phrasebook (use the right-hand wording on the page; the left-hand terms stay in the evidence only):
- chaos campaign / fault injection run -> tests that crash services and repeat messages on purpose
- invariant violations -> data errors (wrong balances, double payments)
- JVM crashes -> forced service crashes
- pod-restart demo / k3d -> restarting a service in a local Kubernetes setup
- idempotent consumers + transactional outbox -> safeguards that stop a payment being recorded twice
- p95 latency -> response time for the slowest 5% of requests (only for performance JDs)
- held-out / fresh tasks -> unseen tasks
- oracle predictions / Stage B / candidate ledger / trust boundary -> do not use on the page
- precision / recall / F1 / MRR -> use one of them at most, and only for ML or AI JDs; otherwise use the zero-unsupported-claims result
- AUC-ROC -> allowed only for ML JDs, always next to the baseline it beat
- dynamic programming, RRF, BM25, Lua, Pub/Sub -> name only if the JD asks for it; otherwise say what it does
- ground truth -> known-correct answers (fine to keep "ground truth" when the JD is ML or data)
- aiscore -> confidence scores
- normalized schemas -> well-structured relational database design

## 2) CURRENT WORKFLOW OVERRIDES
### Section order and names
Always use exactly these headings, in this order, unless Jay explicitly asks otherwise:
1. EXPERIENCE
2. PERSONAL PROJECTS
3. EDUCATION
4. TECHNICAL SKILLS
5. CERTIFICATIONS & AWARDS

Do not move Education to the top for new-grad/campus/recent-grad/graduation-window/entry-level roles.

### Layout (from Resume_Template_CURRENT.tex)
- A4, 10pt, `\usepackage[top=0.21in, bottom=0.21in, left=0.3in, right=0.3in]{geometry}`, `\linespread{0.98}`, `\parskip` 0.4pt.
- `\rolegap` (`\vspace{3.5pt}`) separates roles in EXPERIENCE and separates the three project blocks in PERSONAL PROJECTS (Project1 block, `\rolegap`, Project2 block, `\rolegap`, Project3 block). Education has a 3.5pt gap between the two degrees.
- Template-sanctioned fallback: only if the page still overflows after the skills budget is applied, `\rolegap` may be lowered from 3.5pt to 2pt (per the template's own comment). No other spacing, margin, or font changes.

### Deliverables
- Resume: the script writes standalone LaTeX `<Key>.tex`; deliver it in chat as one copyable latex code block (no resume PDF).
- Cover letter: the script writes `<Key>_Cover_Letter.pdf` plus `<Key>_Cover_Letter.txt` (starts with "Dear Hiring Manager,", no header/date/address); deliver the PDF link plus the .txt in one copyable text code block. No DOCX.
- Paste the full LaTeX in chat only if Jay asks for it.

### Runtime process
- Do not re-search/re-discover this Master and the Resume Template for each JD.
- Treat this lean Master + current Resume Template + saved overrides as loaded project state.
- Score all 7 projects from compact summaries first; inspect deeper evidence only for finalists if needed.
- Project bullets come from `bullet_bank.json` by variant id; the model never writes project-bullet prose. To get new wording, add a reviewed variant to the bank and rerun `bank_check.py`.
- Compile an internal PDF and validate programmatically: 1 page, exactly 7 project bullets, each exactly 2 physical lines, second line >=40%, every project heading exactly 1 rendered line, Tools exactly 1 rendered line, skills <=8 rendered lines.
- Do not routinely render page screenshots unless programmatic checks fail or something is ambiguous.
- The script builds the cover letter only after the resume passes.

### Visa / sponsorship
- Read the JD only by default.
- If explicit, report sponsorship/restrictions.
- If absent, say: `Visa / sponsorship: not stated in the posting.`
- Do not do external sponsorship research unless Jay asks.
- Operational eligibility profile for blocker reporting only (never add this to resume prose): Jay is not a U.S. citizen, is an F-1 student planning post-completion OPT subject to approved OPT/EAD, and will require future employer sponsorship after OPT. Security-clearance status is unknown unless Jay updates it.
- `eligibility_blockers` is reported before application output when an explicit JD citizenship, work-authorization, sponsorship, or known-clearance requirement conflicts with this profile. Blockers warn but never cancel truthful resume/cover-letter generation.

## 3) CONTACT AND HEADER
Name: Jay Niketan Pathare  
Email: jayadmit456@gmail.com  
Phone: +1(716)303-9924  
Location: NY, US  
Portfolio: https://jay-portfolio-black-eight.vercel.app/  
LinkedIn: https://www.linkedin.com/in/jaypathare3  
GitHub: https://github.com/Jaypath456

Header tagline: `plan.tagline_text` per section 0; the section-16 bank is the fallback only.

## 4) EDUCATION
### Master's in Computer Science
Institution: University at Buffalo, The State University of New York, Buffalo, NY  
Dates: August 2025 -- December 2026  
GPA: 3.85 / 4.0

Timing:
- Coursework/exams expected complete: December 16, 2026.
- Graduation: December 2026 (confirmed by Jay and the university, 2026-10-19; v3.4.8b).
- Available to start work: February 2027, subject to approved OPT/EAD.
- Resume/LinkedIn graduation date: December 2026.
- Graduation (December 2026) and start date (February 2027) are two separate facts; never merge them.
- Do not mention CPT as the basis for post-graduation availability.

Coursework: Algorithms Analysis & Design, Computer Security, Intro to Machine Learning, Data Intensive Computing, Operating Systems, Data Models & Query Languages, Project Development, Deep Learning, Project Management (a new-grad page shows at most 3; see 0-v349c).

### Bachelor of Engineering, Information Technology
Vivekanand Education Society's Institute of Technology, Mumbai University, India  
Dates: August 2019 - May 2023

## 5) FIXED PROFESSIONAL EXPERIENCE (verbatim from Resume_Template_CURRENT.tex)
All 13 bullets below are mandatory, in exact role/bullet order. Do not add, remove, merge, shorten, rewrite, or reorder them.

### Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY
January 2026 -- April 2026
1. Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
2. Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ~90% and pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
3. Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
4. Standardized author names by matching them to HeinOnline's 500+ authors in PostgreSQL, even when spelled differently.
Evidence anchors: 47 journals / 28,167+ pages; measured extraction accuracy 90.81% (resume wording: "about 91%"); manual author-entry work cut by about 90% (estimated); worker pool sized to CPU cores minus one; on 47 journals the run took about 50 minutes sequentially and 9 minutes 15 seconds in parallel on 10 cores (about 81% reduction); confidence source values API = 100, LLM = 85, scraper = 50; Docker supported; author names standardized by matching against HeinOnline's 500+ authors stored in PostgreSQL (handles different spellings). Team of 5 for the project. In cover letters say "about 91%".

### Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India
August 2024 -- August 2025
1. Led end-to-end delivery of healthcare platform modules with a team of 4: gathered requirements in client meetings, prototyped to validate scope, and broke the finalized work into tasks.
2. Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ~2s live monitoring.
3. Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses, plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
4. Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
5. Built a heartbeat monitoring dashboard for 4 production projects, pinging each site every 5 minutes to track health.
6. Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds over their first 3 weeks and introducing them to the production projects and tech stack.
Evidence anchors: client/stakeholder meetings; prototyping; "led" means technical coordination of a four-person team, not people management or hiring authority; team size is 4 (team of 4); interviewed about 20 student candidates and onboarded the new hires; SQL/relational schemas; PostgreSQL/Redis/WebSockets; WebRTC; real production deployment; heartbeat/service monitoring and responding to failures it surfaced; reviewed and merged team pull requests (cover letters, and the resume only through Experience variant I); Agile/Scrum. The earlier "~90% setup-time reduction" for Docker was an estimate, not a measurement, so it is not used on the resume. Do not infer HIPAA/FHIR/EHR, observability vendors, formal SRE/on-call, SLA ownership, or HA.

### Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India
November 2023 -- May 2024
1. Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
2. Automated cloud resource provisioning, cutting setup time by ~40% and reducing deployment issues.
Evidence anchors: AWS EC2/RDS, VPC, security groups. The 40% setup reduction is estimated, not instrumented; keep "~" and be ready to explain it in an interview.

### Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India
June 2023 -- August 2023
1. Developed a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data and generate automated anomaly reports for the compliance and audit team.
Evidence anchors: Python, Pandas, NumPy, MySQL, SQL, ETL, cleaning/transformation/reporting.

## 6) ACTIVE PROJECTS
Exactly 7 resume-eligible projects: `ledgerflow`, `goingonce`, `ripple`, `tailor_pipeline`, `launchops`, `pintos`, `fraud`. They appear under the PERSONAL PROJECTS heading.
Archived and never selectable: Temperature Monitoring System, Music Genre Classification (the publication is no longer on the default resume).
Evidence below is written in plain English on purpose. Items marked (optional) are for JDs that care about that area; otherwise leave them off the page. Never put the left-hand jargon from section 1B on the page.

### LedgerFlow — Event-Driven Payment Ledger
ID: ledgerflow | Individual | October 2026  
GitHub: https://github.com/Jaypath456/ledgerFlow (project repository; URL provided by user)
Tech: Java 25, Spring Boot, Spring MVC, Spring JDBC/JdbcClient, Kafka, PostgreSQL 17, Flyway, Maven, Docker Compose, Kubernetes (local k3d), k3d/k3s/kubectl, Testcontainers, JUnit 5, AssertJ, Awaitility, Actuator/Micrometer, k6, GitHub Actions, HTML/CSS/JavaScript, YAML

Evidence:
- Two Spring Boot services that talk through Kafka: a payment API and a ledger that records every payment as matching debit and credit entries (double-entry accounting).
- Safeguards (transactional outbox, idempotent consumers, reconciliation check) so a payment is never recorded twice or lost when messages are repeated or retried. Supported phrase: each payment takes effect exactly once even though Kafka may deliver a message more than once.
- Overspending test: 200 simultaneous $10 requests against an account funded for exactly 50 payments. 50 went through, 150 were safely rejected, the balance ended at $0, and there was no overdraft or double posting.
- Testing: 94 automated tests, plus 27 of 27 crash-and-repeat test runs with 0 data errors (18,000 repeated messages and 14 forced service crashes in total).
- (optional) Speed: in a controlled local test at 200 payments per second, response time for the slowest 5% of requests dropped from 121 ms to 51 ms after the outbox polling interval went from 50 ms to 10 ms.
- CI (confirmed by Jay 2026-10-15): LedgerFlow's GitHub Actions CI runs all 94 tests; the integration tests run against real PostgreSQL and Kafka in containers with Testcontainers and JUnit 5.
- (optional) Local Kubernetes demo (k3d, plain YAML manifests): restarting a service mid-run still completed 250 of 250 payments with 0 duplicates; a fresh cluster came up in 142 s and a replacement service was ready in about 8.9 s.

Boundaries: personal/local project; not production/HA/PCI; no real bank/card network; no exactly-once Kafka delivery; no EKS/GKE/AKS/Helm/HPA/multi-node HA; CI only, not Continuous Deployment.
Relevance: Java, Spring, Kafka, PostgreSQL, backend, distributed systems, event-driven architecture, microservices, ACID, concurrency, idempotency, reconciliation, chaos/testing, performance, Kubernetes, CI.

### GoingOnce — Multi-Agent Car Marketplace
ID: goingonce | Team of 4 | October 2026  
GitHub: https://github.com/raunakpandey1/goingonce (team repository; public link verified)
Tech: Python, LangGraph, Claude API, Streamlit, ReactJS/Vite, Server-Sent Events, pytest, JavaScript

Evidence:
- Four agents built by the team (Buy, Sell, Negotiate, Fleet) for a car-marketplace prototype; a human approves every simulated bid or listing before it goes through.
- Claude handles language and photo tasks; ordinary code handles search, pricing, and negotiation rules.
- Streamlit and React interface on top of a streaming API; 24 automated tests.
- Simulated marketplace data only.
- 1st Place in ACV Auctions + Copart challenge at UB AI for Good Hackathon Design Challenge.
- Mentor feedback shaped the Negotiate and Fleet flows.
- Jay worked on all four agents (mainly the Negotiate and Fleet agents) and built the Streamlit and React front end himself (confirmed 2026-10-15).
- Negotiate agent (repo README): each side's agent keeps a private price limit, a mediator closes the gap in rounds, then the deal closes itself: simulated escrow payment, insurance, loan payoff, title, and truck transport.
- Fleet agent (repo README): checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.
- Buy agent (repo README): checks each car's history and throws out cars with hidden salvage or odometer rollback across 310 simulated ACV and Copart listings, and pauses for dealer approval before any bid.
- Determinism (repo README): search, history checks, pricing, negotiation math and logistics are plain code; Claude is called only for language and photos, and every Claude call has a saved fallback, so results repeat.
- The HTTP API streams agent steps to the React UI as Server-Sent Events (repo README).

Boundaries: Four-person team project (confirmed by Jay 2026-10-15): Jay worked on all four agents (mainly Negotiate and Fleet) and built the Streamlit/React front end. Feature bullets may describe any agent (Buy, Sell, Negotiate, Fleet); the project-level bullet keeps "with a four-person team"; never imply he built the whole system alone. The 24 tests and the award stay team-scoped; not production; bids, payments, prices and transport are simulated; no real ACV/Copart integration; no FastAPI/Docker/RAG/vector DB; award stays out of project bullets.
Relevance: LangGraph, multi-agent systems, LLM apps, human-in-the-loop, React, Streamlit, rapid prototyping, customer/mentor feedback.

### RIPPLE — Agentic Change-Impact Analysis
ID: ripple | Individual | August 2026  
GitHub: https://github.com/Jaypath456/ripple (project repository; URL provided by user)
Tech: Python, Python AST, Git CLI, Pydantic, pytest, LLM API, JSON/JSONL

Evidence:
- Command-line AI agent for Python repositories: given a plain-English description of a change, it predicts which files, tests, and regression risks the change will touch before any code is written.
- Uses 7 code-analysis tools with a cap of 25 tool calls per task; Python code checks every claim against evidence before it can enter the report.
- After the change is made, RIPPLE's own Git-diff check flags unexpected edits, missing tests, and stale callers (Jay 2026-10-15: "Added a Git-diff check that flags unexpected edits, missing tests, and stale callers"; it is RIPPLE's automated check, not manual review).
- 241 automated tests.
- Evaluation: 90 runs on 30 unseen tasks from 16 repositories. Precision 0.306, recall 0.152, F1 0.198, MRR 0.311, and 0 unsupported claims accepted into any report. On the page prefer the zero-unsupported-claims result plus at most one score, and only use the score for AI/ML JDs.
- (optional) Efficiency: about 10 tool calls and 17 model calls per run, with under 1 duplicate call per run (exact: 10.37, 16.60, 0.73).
- (optional) Separate post-change check: found all 3 kinds of planted problems on 15 tasks (100% detection) when given the correct pre-change predictions. Never present this as end-to-end performance.
- Hybrid code search over code chunks (BM25 + dense retrieval) is designed only; dense retrieval/RAG implementation and benchmark are not complete.
- Used Claude Code as a coding assistant while building RIPPLE: Claude Code helped write RIPPLE, and Jay checked its output by running RIPPLE's 241-test suite (confirmed by Jay 2026-10-15); he also used it to study how AI agents work and to probe their edge cases.

Boundaries: Python only; no production/adoption/bugs-prevented/productivity claims; no LangGraph/NetworkX/SQLite/MCP/Redis/Docker; do not attribute current metrics to RAG; do not claim it beat historical B3; Claude Code: say Claude Code helped write RIPPLE and Jay checked its output with RIPPLE's 241-test suite (confirmed 2026-10-15); never "RIPPLE, whose AI-generated code" (RIPPLE generates no code); give no count of corrections, no specific bug example and no productivity claim. The Git-diff check is RIPPLE's automated check (Jay 2026-10-15); never describe it as Jay reading diffs by hand.
Relevance: Agentic AI, tool calling, developer tooling, static analysis, Python AST, dependency analysis, Git, regression analysis, testing, deterministic validation, evaluation.

### LLM Application Optimization Engine
ID: tailor_pipeline | Individual | July 2026  
GitHub: https://github.com/Jaypath456/llm-resume-pipeline (public link verified)
Tech: Python, Gemini API (main provider), Novita API (fallback after 3 failed Gemini attempts), Groq API (assessment), pytest, LaTeX, pdflatex, pdftotext

Evidence:
- Turns a job description into a tailored one-page resume and cover letter grounded in verified evidence.
- Chooses which 3 projects to show and how many bullets each gets by checking every valid combination (dynamic programming); with 7 active projects the expected count is 105 once runtime integration is verified. Describe it as "picks the best projects"; do not hard-code the count.
- Three AI workers write bullets at the same time; typical runtime fell by about 73% (from about 11 minutes to about 3). On the page use the percentage only.
- Python checks reject unsupported technologies, ownership claims, borrowed evidence, and changed numbers before anything is shipped.
- Compiles the LaTeX and re-reads the PDF to check the layout.
- 2,500+ automated pytest tests.
- Uses Gemini as the main model provider and falls back to Novita's model API after 3 failed attempts; retries and repairs only the parts that failed.

Boundaries: individual project; do not claim unsupported production/org adoption; assignment count must remain catalogue-dependent.
Relevance: Python, LLM applications, prompt engineering, dynamic programming, concurrency, deterministic validation, reliability, pytest, developer tooling, PDF/LaTeX.

### LaunchOps — Employee Onboarding Platform (resume title: "LaunchOps: Employee Onboarding Platform")
ID: launchops | Individual | March 2026  
GitHub: https://github.com/Jaypath456/LaunchOps (project repository; URL provided by user)
Tech: Python, Django REST Framework, ReactJS, Go, PostgreSQL, MongoDB (live answers only), Redis, Django Channels, Daphne, Docker Compose, WebSockets, JWT, Locust, asyncio

Evidence:
- Django REST and React onboarding platform with a 20-task workflow shared across HR, IT, manager, and employee roles; tasks have owners, prerequisites, and required evidence.
- Five lessons, each with a 3-question quiz, and an exact 70% pass rule.
- Server-side checks stop users from completing someone else's task, submitting forged evidence, skipping prerequisites, or submitting twice; unresolved support issues also block completion.
- PostgreSQL is the main durable store.
- Live-quiz service written in Go using WebSockets, running as two copies behind nginx; Redis Pub/Sub with Lua scripts coordinates the copies, and a unique MongoDB index rejects duplicate answers.
- A repeatable Django-vs-Go benchmark exists; no speed result after the Go move is verified.

Boundaries: no production deployment, throughput/failover claims, or Go speedup; MongoDB stores live answers only; never reuse retired-LMS metrics.
Relevance: Django REST, React, Go, PostgreSQL, MongoDB, Redis, WebSockets, JWT, real-time/distributed coordination, learning platform, full-stack/backend, system design.

### Pintos Operating System — User Programs Layer
ID: pintos | Individual academic | May 2026  
GitHub: none on the resume. The course repo is private; restore the URL in master.json only after the professor approves making it public.
Tech: C, x86, Operating Systems, Kernel Development, Concurrency, Thread Synchronization, File Systems, Process Lifecycle

Evidence: wrote the part of a teaching operating system that runs user programs, in C: starting programs with arguments, parent/child waiting and exit, 13 system calls, up to 128 open files per process, locks, and safety checks on memory access; all 80 tests pass.
Boundary: C, not C++; teaching OS, not production OS work.
Relevance: systems programming, C, OS/kernel, concurrency, synchronization, syscalls, file I/O, low-level debugging/correctness.

### Fraud Detection using Graph Neural Networks
ID: fraud | Individual (Jay's own work) | April 2026  
GitHub: https://github.com/Jaypath456/gnn-fraud-detection (public link verified)
Tech: PyTorch, PyTorch Geometric, GNN, GraphSAGE, GAT, NetworkX, Pandas, scikit-learn, Focal Loss

Evidence:
- trained fraud models on the IEEE-CIS dataset (590,540 transactions, about 3.5% fraud, roughly 27.6 normal transactions for every fraud). The GraphSAGE graph neural network scored 0.9259 AUC-ROC (fraud F1 0.5641) against about 0.858 for a plain neural-network baseline (MLP); the GAT model did worse. On the Elliptic dataset, GraphSAGE reached about 0.988 AUC and 0.906 F1. Ablation analysis available. On the page always show AUC next to the baseline it beat.
- Graph construction (notebook): a transaction graph of 590,540 nodes and 4,122,298 edges (about 4.1M) built by linking transactions that share card (card1, card2, card1+addr1), address (addr1) and email-domain (P_emaildomain, R_emaildomain) identifiers; any identifier group larger than 50 transactions is skipped so no hub node forms.
- Edge-type ablation (notebook) over five identifier types (card1, card2, addr1, P_emaildomain, R_emaildomain) on the trained GraphSAGE model: all edges 0.9113 test AUC vs 0.8954 with no edges, so the graph adds 0.016 AUC; card1 links alone reach 0.9109 (almost all of the gain), while each other type alone stays at 0.8954-0.8955.
- Model comparison (notebook): MLP, GraphSAGE and GAT trained with focal loss and class weights, with decision thresholds tuned for F1 on validation data; test fraud F1: GraphSAGE 0.564 (0.5641), MLP 0.394 (0.3944), GAT 0.261 (0.2605).
- Leakage controls (notebook): stratified 70/15/15 train/validation/test split; the feature scaler is fit on the training split only; decision thresholds are tuned on the validation split; final results are reported on the held-out 15% test set.
- Jay built the whole notebook himself (confirmed 2026-10-15); describe it as his own work.

Boundaries: Jay's own work: he built 100% of the notebook himself (confirmed 2026-10-15; the course submission lists three names, but the other two worked on a different project). Describe it as Jay's own work, never as team work. Never quote a class-imbalance ratio of 41.4x (that figure includes the 1.5 fraud weight); the true ratio is about 27.6 normal transactions per fraud. The edge ablation tested each identifier type alone and all together; it did not test removing one type from the full graph.
Relevance: ML, GNN, fraud/anomaly detection, PyTorch, imbalanced classification, Focal Loss, model evaluation, AUC/F1, threshold tuning, ablations.

## 7) PROJECT SELECTION + BULLET CONTRACT
For every JD:
- Re-score all 7 active projects.
- Select exactly 3.
- Rank by JD relevance.
- #1 gets 3 bullets; #2 gets 2; #3 gets 2.
- Display in rank order (section 0).

Selection priority:
1. Direct proof of important JD requirements.
2. Evidence not already strongly covered by Experience/Education/Skills.
3. Technical depth/evidence strength.
4. Measured/validated results.
5. Complementary coverage.
6. Avoid redundant proof.

Specialized JDs: depth in the primary domain beats forced variety.

Project bullets:
- Select bullet variants only by id from `bullet_bank.json`; never write, rewrite, shorten, expand, or paraphrase project-bullet prose during a JD run.
- Tailoring comes from project selection, bank variant selection, project header tech, skills, and the cover letter.
- To introduce new bullet wording, add a reviewed variant to `bullet_bank.json` and run `bank_check.py` before using it.
- Exactly 7 total.
- Use only same-project evidence.
- Prefer one main accomplishment.
- Render exactly 2 physical PDF lines.
- Second line >=40% filled; 60-90% preferred.
- A bank variant that no longer renders as exactly 2 lines indicates template/bank drift; do not edit its text during an application run. Rerun `bank_check.py` and stop until the bank is revalidated.
- No forced wraps, fake spaces, invisible text, font/margin tricks, filler, or borrowed evidence.
- Follow section 1B: plain English, at most 2 numbers, a result stated once (percentage OR before/after, never both), no internal jargon, at most 2 named technologies.
- Recruiter readability is handled when variants are authored and reviewed for the bank; normal JD runs select only approved variants and never repair their prose.

Banned anywhere in project bullets, including mid-bullet:
Engineered, Merged, Parallelized, Standardized, Led, Developed, Delivered, Containerized, Built, Interviewed, Deployed, Automated, Reviewed, Added, Cut (every Experience verb, so no verb repeats on the page).

Use seven distinct project action verbs across the seven bullets; no repeats. Preferred: Designed, Implemented, Created, Wrote, Coded, Programmed, Directed, Integrated, Instrumented, Benchmarked, Validated, Verified, Orchestrated, Prototyped, Evaluated, Optimized, Enforced, Prevented, Measured, Tested, Stress-tested. Avoid inflated "Architected".

## 8) TECHNICAL SKILLS
### Former protected baseline (RETIRED in v3.3; skills are gated per section 0 — kept for history only)
- Languages & Databases: Python, SQL, PostgreSQL, MySQL
- Frameworks & Libraries: Django, Django REST Framework, Pandas, NumPy, PyTorch, scikit-learn
- AI/ML: LLM Integration, Prompt Engineering, Machine Learning, Deep Learning, Agentic AI, Model Evaluation, Neural Networks (CNN, GNN), Transformers
- Software Engineering: OOP, REST APIs, Full-Stack Development, Backend Development, System Design, ETL, Parallel Processing, Agile, Real-Time Monitoring
- Tools defaults: Linux, Redis, AWS (EC2/RDS), Docker, Git, WebSockets, OAuth/Auth0

Only `Neural Networks (CNN, GNN)` may be removed, solely when needed for the skills-line budget.

Tools renders as exactly 1 physical line. Add JD-matched supported tools first (Claude Code, for example, is in the supported pool but is no longer a default; add it only when the JD matches). Never prune a JD-matched default. If overflow, drop unmatched defaults in this order: OAuth/Auth0 -> WebSockets -> Redis -> Linux -> AWS (EC2/RDS) -> Git -> Docker.

Rendered skills targets: Languages max 2 lines, Frameworks max 2, AI/ML max 2, Software Engineering max 2, Tools exactly 1; total max 7 lines (6 is fine); when more fit, the least JD-relevant items are dropped first. Selected-project technology closure takes priority; when concrete selected technologies are added, the only prunable baseline item remains `Neural Networks (CNN, GNN)`.

### Supported skill pool
Languages/DB: Python, Java, JavaScript, HTML/CSS, C, Go, SQL, PostgreSQL, MongoDB, MySQL.
Frameworks/Libraries: Django, Django REST Framework, Django Channels, ReactJS, Spring Boot, Spring MVC, Spring Kafka, Spring JDBC/JdbcClient, JUnit 5, Testcontainers, AssertJ, Awaitility, pytest, Vite, Pandas, NumPy, scikit-learn, PyTorch, PyTorch Geometric, NetworkX, Librosa, CatBoost, Pydantic, LangGraph, Streamlit, TensorFlow, Matplotlib.
AI/ML/Data: LLMs, Agentic Workflows, LLM Integration, Prompt Engineering, Agentic AI, AI Agents, Tool Calling, Multi-Agent Systems, Human-in-the-Loop Workflows, OCR/Tesseract, Machine Learning, Deep Learning, CNNs, RNNs, GNNs, GraphSAGE, GAT, Focal Loss, Model Evaluation, Threshold Optimization, Data Preprocessing, Data Transformation, Fuzzy Matching.
Software Engineering: Data Structures, Algorithms, API Design (confirmed by Jay; skills line only, never project bullets), REST APIs, Full-Stack Development, Backend Development, System Design, Event-Driven Architecture, Microservices, Payment Systems, Transactional Outbox, Idempotency, Idempotent Consumers, Double-Entry Ledger, Database Transactions/ACID, Row-Level Locking, Reconciliation, Fault Injection, Chaos Testing, Continuous Integration, Unit Testing, ETL, Parallel Processing, Multiprocessing/Worker Pools, Load Testing, Latency Measurement, Distributed Systems, Backtracking Algorithms, Agile, Scrum, Real-Time Monitoring, Concurrency, Thread Synchronization, Operating Systems, Kernel Development, Process Lifecycle, Static Analysis, Dependency Analysis, Change-Impact Analysis, Regression Analysis, Web Scraping, Production Deployment, Application Monitoring, Heartbeat Monitoring, Incident Response, OOP, Code Review.
Tools/Platforms: Redis, Apache Kafka, Kafka KRaft, Maven, Flyway, k6, GitHub Actions, Spring Boot Actuator, Micrometer, AWS (EC2/RDS), Docker, Docker Compose, Kubernetes (local k3d), k3d, k3s, kubectl, Git, GitHub, GitHub Copilot, OAuth/Auth0, JWT, WebRTC, WebSockets, nginx, Daphne/ASGI, Locust, asyncio, Arduino Uno, LaTeX, pdflatex, pdftotext, Gemini API, Novita API, Groq API, Claude API, CrossRef API, JSON, YAML, Cursor, Claude Code, Linux, Tableau, Power BI.

Normalization/scope:
- Unix -> surface Linux, not Unix.
- AWS remains AWS (EC2/RDS).
- Golang -> Go; Java 25 -> Java; PostgreSQL 17 -> PostgreSQL; Kafka -> Apache Kafka; Git CLI -> Git; Django REST -> Django REST Framework; React -> ReactJS; WebSocket -> WebSockets; Auth0 -> OAuth/Auth0; ETL Pipeline -> ETL; REST API Development -> REST APIs.
- Do not use broad `CI/CD`; supported is Continuous Integration only.
- Java/Spring/Kafka/Kubernetes evidence = LedgerFlow only.
- LangGraph/Multi-Agent/Human-in-the-Loop/Claude API = GoingOnce only.
- Go/MongoDB live quiz = LaunchOps only.
- Production Deployment/Application Monitoring/Heartbeat Monitoring = Thesis Mumbai Tech only.

## 9) UNSUPPORTED / DO NOT CLAIM
C++, FastAPI, Angular, Ruby, Apache Spark, Apache Airflow, AWS Glue, Terraform, Azure, GCP, EKS/GKE/AKS, production/high-availability Kubernetes, Helm, Kubernetes HPA/autoscaling, HIPAA implementation/compliance, FHIR, EHR integration, Continuous Deployment, cloud ML platforms beyond AWS EC2/RDS, data-warehouse/platform experience unless added, finance-industry Professional Experience.

Guards:
- Pintos is C, not C++.
- Load testing is not profiling.
- AWS EC2/RDS is not SageMaker/Glue.
- Healthcare software does not imply HIPAA/FHIR/EHR.
- Payment-system project work is not finance-industry Professional Experience.

## 10) GENERAL EVIDENCE FOR COVER LETTERS
Collaboration/product:
- Direct client/stakeholder meetings at Thesis Mumbai Tech.
- Clarified requirements and translated them into technical work.
- Prototyped before full implementation.
- Coordinated a four-person engineering team (technical coordination, not people management).
- Reviewed pull requests.
- Worked with clients on UI/UX and product requirements.
- Interviewed about 20 student candidates and onboarded the new hires.
- Agile/Scrum.

Production/operations:
- Deployed team software to a shared production server.
- Built heartbeat/service-status monitoring.
- Responded to heartbeat-detected production failures and restored affected services.
- Do not inflate into formal SRE/on-call/SLA/HA ownership.

AI-assisted development:
- GitHub Copilot supported in scoped development evidence.
- Cursor and Claude Code used for repository-level development, debugging, test-driven iteration, and code review.

Coursework:
- Agentic AI is a skill, not coursework (v3.4.9c); never merge coursework into RIPPLE or Professional Experience.

## 11) CERTIFICATIONS & AWARDS (v3.4.9c: no such section on the page; never in a letter)
Facts kept in master.json (not shown):
- 1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB | October 2026
- AWS Certified Cloud Practitioner | July 2024

Not on the default resume (use only if Jay asks, or in a cover letter when relevant):
- Research Publication: J. Pathare et al., “Music Genre Classification,” IJRAR, April 2023 (97.68% accuracy). https://www.ijrar.org/papers/IJRAR23B1728.pdf
- Certificate of Appreciation — Event Manager, CSE Workshop “GitHub: Hands-On from Basics to Advanced,” University at Buffalo — February 2026

## 12) FINAL CHECKLIST
Before returning a resume:
- Headings exactly: EXPERIENCE, PERSONAL PROJECTS, EDUCATION, TECHNICAL SKILLS, CERTIFICATIONS & AWARDS, in that order.
- Header tagline is one approved section-16 tagline selected by `plan.tagline_id`.
- Exactly 3 selected projects; all 7 were considered.
- Projects newest-first; ties by higher relevance.
- Bullet allocation remains 3/2/2 by relevance rank.
- Exactly 7 project bullets total.
- Each project bullet exactly 2 PDF lines; second-line fill >=40%.
- Seven distinct allowed project action verbs; no banned project verbs anywhere.
- Fixed Experience (all 13 bullets) identical to the template, character for character.
- Plain-English check passed for every project bullet: at most 2 numbers, no before/after pair next to a percentage, no section 1B jargon, readable in one pass by a first-time technical recruiter.
- No unsupported claim/technology; no changed/re-attributed metric; no borrowed evidence.
- Protected baseline preserved (including OOP and Real-Time Monitoring); Tools exactly 1 line; skills <=8 rendered lines.
- Dynamic skills supported, relevant, canonical, deduplicated.
- No forced-wrap/layout hacks; `\rolegap` stays 3.5pt unless the template-sanctioned fallback was needed.
- One-page resume.
- Cover letter grounded in the same evidence.
- Return the resume LaTeX code block + cover-letter PDF and text code block.

Priority: factual truth/evidence > JD relevance > evidence strength > technical specificity > ATS coverage > structural requirements > PDF geometry > cosmetic preferences.
## 13) SEMANTIC / ATS VALIDATION CONTRACT

These rules are enforced in addition to the PDF/layout checks.

### Evidence IDs
- Every generated project bullet must cite one `main_evidence_id` from the same project.
- A bullet may cite supporting evidence IDs only from the same project.
- Two bullets from the same project may not share the same `main_evidence_id`.
- Supporting evidence may repeat when it is genuinely shared context.
- `master.json` is the machine-readable source for evidence IDs, claim atoms, clusters, hero flags, optional themes, and evidence-specific technical terms.

### Hero evidence
- Each project has one or more evidence items marked `hero`.
- If a project is relevance rank #1, at least one of its bullets must use a hero item as `main_evidence_id`.
- Rank #2/#3 should prefer hero evidence when it improves direct JD proof, but it is not mandatory.

### Claim grounding
- Each bullet declares the exact claim atoms it uses.
- Every declared claim atom must exist under its referenced evidence item(s).
- Every numeric value appearing in a generated bullet must be supported by the referenced evidence/claim atoms.
- A project-specific technical term may appear only when it is supported by the evidence IDs referenced by that bullet.
- Do not silently combine unrelated evidence. A bullet uses one evidence cluster; a second cluster is allowed only when the structured evidence marks the clusters as related.
- If deterministic checks cannot prove a wording choice, treat the bullet as requiring semantic review rather than accepting it silently.

### Verb semantics
- `master.json` contains an allowed project-verb taxonomy with usage notes and evidence kinds.
- The opening verb in every project bullet must be one of those verbs and must fit the kind of the bullet's `main_evidence_id`.
- Example: `Instrumented` is only for metrics/telemetry/monitoring; tests normally use `Validated`, `Verified`, or `Evaluated`; performance comparisons use `Benchmarked` or `Optimized`.

### ATS/JD coverage — v3.2
- The planning step receives the raw JD as a file and outputs at most 25 `jd_requirements`: all `must`/`high` requirements first, then at most 12 `medium` requirements; omit `low`. Include supported responsibilities (unit testing, code review, Agile) as medium so they are not crowded out by gaps.
- Each requirement contains: canonical `term`, exact-JD `verbatim`, optional `aliases`, priority (`must`, `high`, `medium`), and `supported`. The pipeline hard-fails when `verbatim` does not occur literally in the raw JD.
- Support and ATS matching use word-boundary matching, never arbitrary substring matching.
- `ats_safe_verbatim_aliases` is deliberately small and is seeded only from the existing normalization map: Golang→Go, Kafka→Apache Kafka, WebSocket→WebSockets, Auth0→OAuth/Auth0, ETL Pipeline→ETL, REST API Development→REST APIs, Java 25→Java, PostgreSQL 17→PostgreSQL, Git CLI→Git, Django REST→Django REST Framework, React→ReactJS, ReactJS/Vite→ReactJS, Claude→Claude API, HTML→HTML/CSS, CSS→HTML/CSS, Daphne→Daphne/ASGI. `Unix→Linux` remains normalization-only and is not safe verbatim surfacing.
- Every supported `must` requirement must appear on the rendered resume in its JD `verbatim` form when that form is itself in the supported skill pool or in `ats_safe_verbatim_aliases`; singular/plural variants such as `REST API` / `REST APIs` are equivalent. If the exact JD form is not safe to surface but a supported canonical term/alias is present, report `alias only` as a warning rather than inventing the JD wording.
- Existing supported `must`/`high` coverage remains a hard requirement. ATS visible surfaces are, in priority order: Skills > project header > project bullet > Experience > tagline > Education. `report.json` records the primary surface plus optional `also_in`.
- If a supported skill-pool term occurs in the raw JD but was omitted from `jd_requirements`, warn so the planner can tighten extraction; do not silently add it.
- Unsupported JD requirements remain explicit gaps and are never inserted for keyword matching.
- Skills priority when space is tight: supported must terms > selected-project technology closure > JD-ranked optional skills > unmatched defaults. Total skills max 7 rendered lines; Tools exactly 1 line. If required ATS skills cannot fit, hard-fail `required_ats_terms_exceed_skill_budget` and name them.

### Fit (High / Medium / Low) — v3.2
- Calculate `hard_gaps` from unsupported JD requirements: all `must`/`high` priorities plus unsupported requirements whose JD wording explicitly says `required` or `must have`. A years-of-experience shortfall with at least one related professional year remains `partial`, not supported.
- If any `hard_gap` is `unsupported` and its exact JD wording explicitly says `required` or `must have` (case-insensitive), cap effective Fit at **Low**.
- Otherwise, if a `hard_gap` is an unsupported `must`/`high` requirement, cap effective Fit at **Medium**. Existing partial-years hard gaps continue to cap at Medium.
- A cap only lowers, never raises, the plan's Fit. Report `effective_fit` and use that exact value in tracker `Fit (High/Medium/Low)`. Eligibility warnings and hard gaps never cancel a truthful application package.

### Optional evidence
- Optional evidence items carry allowed `optional_themes`.
- The planning step outputs `jd_themes`.
- An optional evidence item may be used only when its themes intersect the JD themes.
- Example: LedgerFlow latency evidence is allowed for performance/latency/scalability JDs; the local Kubernetes demo is allowed for Kubernetes/infrastructure/reliability JDs.

### Project title format
- The script, not the model, writes project titles.
- Resume project titles use `Name: Description` with a colon, never an em dash. When a selected project has a non-empty public `github` URL in `master.json`, hyperlink the title and verify its PDF link annotation; when no public URL is recorded, render a plain title and do not create a dead link.

## 14) APPLICATION TRACKER CONTRACT

Google Sheet columns, in this exact order (v3.4.4; Jay deleted Career Status Portal, Visa / Sponsorship and Lane):
1. Company
2. Role
3. Date Applied
4. Location
5. Projects Used
6. Fit (High/Medium/Low)
7. Resume File Name
8. Status
9. Source
10. Outcome Date
11. Blockers

Rules:
- Do not create a Notes column.
- Do not store the original job-posting link in the tracker.
- Generating application documents means the application is treated as submitted: every new row starts with Status = `Applied`; do not wait for Jay to say "applied".
- Update an existing row only when Company AND Role match exactly; otherwise append a new row.
- Status updates: when Jay sends "status: <Company> | <Role> | <Rejected / Interview / Offer / Withdrawn>", find the row where Company AND Role match exactly, set Status to that value and Outcome Date to today, change nothing else, and reply with the row number. No exact match: list the closest rows and change nothing.
- `Source` is optional and blank when not supplied.
- `Outcome Date` stays blank while active and is filled when an outcome is recorded.
- `Blockers` lists eligibility blockers (citizenship, clearance, the employer's own no-sponsorship text, graduation window); blank when none.
- The chat reply still prints the visa / sponsorship note; only the sheet column is gone.
- Hiring-status emails may later update Status to `Assessment`, `Interview`, `Rejected`, or `Offer` when the email is explicit.
- Gmail access for this workflow is read-only from the assistant's perspective: reading/searching is allowed; Gmail write/change actions require confirmation.
- Absence of an application-confirmation email does not by itself mean submission failed. Keep `Applied`.
- The `Summary` tab contains formula-driven counts of applications and callbacks (`Assessment`, `Interview`, `Offer`) by Source and Fit, using `COUNTIFS`.
- Google Sheets write access is handled outside the local resume validator through the connected Google Drive/Sheets integration.
- Tracker `Resume File Name` stores only the ASCII `Company_Role` key: no name prefix, extension, or date.

## 15) PROJECT QUALITY GUARDS

- `resume_pipeline_v3_2.py` uses each project's canonical `header_priority_tech` unless a plan supplies a supported `project_tech` override for JD coverage; header tech never licenses unsupported skills or claims.
- The canonical header stacks are:
  - LedgerFlow: Java, Spring Boot, Kafka, PostgreSQL
  - GoingOnce: Python, LangGraph, ReactJS, Streamlit
  - RIPPLE: Python, Python AST, Git, Pydantic
  - LLM Application Optimization Engine: Python, Gemini API, Novita API, pytest
  - LaunchOps: Django, ReactJS, PostgreSQL
  - Pintos: C, x86, Operating Systems, Concurrency
  - Fraud Detection: PyTorch, GraphSAGE
- Project bullets within the same project must not repeat a salient two-word phrase unless it is an unavoidable technology/name phrase. This catches semantic padding such as repeating the same failure/outcome phrase across two bullets.
- Evidence values marked approximate in `master.json` must retain an approximation qualifier such as `about`, `approximately`, `around`, or `~` on the resume.
- `Hardened` is not an allowed generated project verb. Use the evidence-specific taxonomy; for preventative validation/authorization checks, `Enforced` is preferred when accurate.
- `Debugging` is not in the canonical supported skills pool. Do not add it as an ATS skill unless the Master is deliberately updated with stronger explicit evidence.
- Every rendered project heading (project title + header tech + date) must fit on exactly 1 PDF line. If it wraps, shorten the `plan.project_tech` override first; do not alter bank bullet text.
- Technical Skills must close over selected-project technologies: every concrete technology named in a selected bank bullet or rendered project header must appear in Technical Skills under its canonical supported name, unless a normalization alias already covers it. This includes languages, databases, frameworks/libraries, and tools/platforms.
### Bullet quality contract

- The 40% second-line rule remains the structural minimum, but the generation target is at least 50%.
- A 40-50% tail is a non-blocking quality warning. Bank variants should normally stay at or above the bank's 50% floor; the hard resume floor remains 40%.
- Never pad or repair a selected bank bullet during an application run. If wording should improve, add a reviewed bank variant and rerun `bank_check.py`.
- Prefer bullet shape: action + concrete system/test + result.
- Rank #1 projects must include their headline evidence. With 3 bullets, the normal mix is headline/result + JD-specific proof + complementary capability.
- Evidence selection is role-aware. For Quality/SDET jobs, prioritize automated tests, chaos/failure testing, regression evidence, and measured reliability over architecture-only details when bullet slots are limited.
- Do not use `Evaluated` for a single concurrency/correctness test. Prefer a result-accurate verb such as `Prevented`, `Stress-tested`, `Validated`, or `Verified`.
- For LedgerFlow, prefer `each payment is recorded once even when messages repeat` over an unqualified `exactly-once` phrase.
- Filler/restatement detection is advisory only. In bank mode, geometry or wording problems are bank-maintenance work, not per-application prose repairs.

## 16) TAGLINE BANK

Fallback only (section 0): when `plan.tagline_text` is empty the header tagline is selected by `plan.tagline_id`. Allowed ids are defined in `master.json` under `taglines.options`. The general tagline is always allowed; themed taglines must intersect the JD themes. The pipeline replaces the fixed template tagline with the selected approved text and rejects unknown or theme-mismatched ids.

## 17) BANK MODE

Normal application runs use `bullet_bank.json` as the only source of project-bullet prose. The model outputs variant ids only; `resume_pipeline_v3_2.py` expands those ids back into the bank's structured bullet objects and then runs the existing hard validators.

Selection rules:
- Choose exactly 3/2/2 variants for ranks #1/#2/#3, all from the matching project.
- Each chosen variant must have a different main_evidence_id within its project.
- No two chosen variants may appear in each other's conflicts_with list.
- The seven chosen verbs must all be different.
- Rank #1 must include a variant whose headline is true.
- Use a variant with optional=true only when optional_themes intersects the JD themes.
- Prefer variants whose angles/jd_terms match the JD's must/high requirements; if none match, prefer hero evidence.
- JD terms that are supported by the Master but do not appear in a selected bank bullet must be covered through Technical Skills and/or the project header tech line using a supported `plan.project_tech` override; never create new project-bullet prose to insert a keyword.
- Unsupported JD terms remain explicit gaps. They are never invented in bullets, project headers, skills, or the cover letter.
- Free-text project bullets are disabled by default. They are available only through the pipeline's explicit `--allow-free-text` compatibility flag and are not part of the normal application workflow.
- In bank mode, any project-bullet geometry failure means template/bank drift. Do not edit bullet text; rerun `bank_check.py` and stop until the bank passes again.
- Example bank-mode plans must be complete pipeline inputs: include application metadata and a non-empty `jd_requirements` list in addition to ranking, themes, bank selections, skills/header overrides, and cover-letter content. Do not use fragments as proof plans.

## 18) APPLICATION SPEED / OUTPUT CONTRACT

- Normal applications use Medium reasoning.
- Pipeline timing fields are milliseconds (`duration_ms`). Normal skill fitting uses zero separate LaTeX compiles: it measures during the single final compile, caches the resolved fit by skills-text hash, and reuses the cached fit when available.
- `jd_requirements`: at most 25; must/high first, at most 12 medium, no low.
- Do not manually re-analyze ATS coverage after planning. Run the pipeline once and read only failures/warnings/`ats_coverage`.
- Do not reopen/re-read the Master or bank during a normal application after the plan is constructed.
- Cover letter: exactly 3 short paragraphs from the same plan data; no extra research unless Jay explicitly asks.
- Plan-construction/preflight corrections do not consume the one repair pass. After the first complete bank-valid pipeline run, fix only the named failure and rerun at most once.
- Filename key = ASCII `Company_Role` using letters/digits/underscores only, punctuation removed, no date. Resume LaTeX = `<Key>.tex`; cover letter = `<Key>_Cover_Letter.pdf` and `.txt`; tracker stores `<Key>` only.
- After the tracker row, provide outreach: three suggested contact-title types and one message of exactly 3 sentences and fewer than 75 words, grounded only in the Master and selected projects. Sentence 3 asks for a 10-minute conversation for advice about the team; do not ask for a referral first. Do not store outreach in the tracker.
- After PDF compile, run automatic parse checks as warnings only: section order, email/phone extraction, private-use/control characters, and ligature/encoding artifacts.
## 19) v3.2 ADDITIONS (authoritative where they differ from earlier sections)

### Role family (required: `plan.role_family`)
Pick the closest family. The script hard-fails a selected project listed in the family's avoid list unless `ranking_override_reason` is non-empty, and it rejects taglines outside the family's list.

| role_family | Use for | Preferred projects (in order) | Avoid | Taglines |
|---|---|---|---|---|
| backend | Backend, API, distributed systems | ledgerflow, launchops, ripple, pintos | tailor_pipeline, fraud | backend, general |
| fullstack | Full-stack / web apps | launchops, ledgerflow, goingonce, ripple | tailor_pipeline, fraud, pintos | general, enterprise_apps, backend |
| sdet_quality | QA, SDET, test automation | ledgerflow, ripple, launchops, tailor_pipeline | fraud, goingonce | quality, general |
| support_sustaining | Sustaining, production/app support, IT or enterprise platform dev (ServiceNow, Salesforce, .NET shops) | ledgerflow, launchops, ripple, pintos | tailor_pipeline, goingonce, fraud | sustaining, quality, enterprise_apps, general |
| data_engineering | Data engineering, ETL, analytics engineering | ledgerflow, fraud, launchops, ripple | tailor_pipeline, goingonce, pintos | data, backend, general |
| data_science_ml | Data science, ML engineering, applied ML | fraud, ripple, goingonce, ledgerflow | pintos, tailor_pipeline | ai_ml, data, general |
| ai_llm | AI / LLM / agentic engineering | goingonce, ripple, tailor_pipeline, fraud | pintos | ai_ml, general |
| systems | Systems, embedded, OS, low-level | pintos, ledgerflow, launchops, ripple | tailor_pipeline, goingonce, fraud | systems, general |
| devops_cloud | DevOps, cloud, SRE, infrastructure | ledgerflow, launchops, ripple, pintos | tailor_pipeline, fraud, goingonce | devops, backend, general |
| general_swe | General / new-grad SWE | ledgerflow, launchops, ripple, goingonce, pintos | tailor_pipeline | general, backend, enterprise_apps |

Non-AI families (all except data_science_ml and ai_llm) use a compact skills baseline: AI/ML line = Machine Learning, LLM Integration, Prompt Engineering, Agentic AI; Frameworks baseline = Django, Django REST Framework, Pandas, NumPy. JD-matched terms are still added.

### Bank selection
- Default: `"bank_selection": "auto"`. The script picks a valid 3/2/2 set (distinct evidence, distinct verbs, no conflicts, no redundant pairs, headline first for rank #1) that best matches the supported JD requirements and themes.
- To steer it, add `"prefer_variants": [ids]` (up to 3). Manual id lists still work but are checked for redundancy.

### Skills
- The script scans the JD and adds every supported-pool skill it names literally (JD-named pool skills), so ATS coverage does not depend on the plan.
- Supported `high` requirements are added to Technical Skills automatically before `optional_skills`.

### Cover letter (script-built PDF + plain-text copy, US Letter, 1 page)
- Exactly 2 paragraphs, 110-250 words total (P1 40-120, P2 55-140). Plain, simple English: every sentence 36 words or fewer; aim for under 25. About 160-190 words is typical.
- P1: exact `application.role` and company name, then `cover_letter.hook` (one JD-based sentence written by the planner), then one fixed Experience item with a real metric. Data/ML roles: Go Digital ETL + anomaly reports, or the HeinOnline extraction benchmark.
- P2: the #1 and #2 ranked project sentences (real metrics), then "I graduate in December 2026 and can start work in February 2027." (v3.4.8b; plus ", and I am open to relocating" for non-remote jobs outside Buffalo), then one closing sentence naming the company. No visa or OPT wording.
- No keyword filler sentence is added in hook mode.
- At least 2 supported must/high JD requirement terms in their JD wording.
- The #1 ranked project must appear in the letter with one of its real numbers (when its headline evidence has numbers).
- No sentence that lists 4+ skills as "skills" (show skills through actions instead).
- Every number must exist in the Master. No gap terms or unsupported technologies (role and company names are exempt). No visa/OPT wording. If graduation is mentioned, it must say December 2026; February 2027 is only the start date.
- Banned phrases include: "I am writing to express", "passionate", "perfect fit", "leverage", "proven track record", "detail-oriented", "fast-paced environment", "I am confident that". Use the short project name (LedgerFlow), never "LedgerFlow: Event-Driven...".
- Optional `cover_letter_salutation` (for example "Dear Ms. Rivera,") when the hiring manager is named in the posting; default "Dear Hiring Manager,".

### Plan hygiene
- AND-lists are split into one requirement per item ("Java and Python" = two). OR-lists ("one of", "or", "such as", "e.g.", "at least one") are ONE requirement whose aliases list every option; it is supported if any option is supported. The script adds every JD-named skill you have to the resume anyway, so splitting an OR-list only produces false gaps and a wrongly low Fit.
- Set `"required_section": true` on any requirement listed under a required/minimum/basic qualifications or "what we need to see" heading. An unsupported one caps Fit at Low.
- Each project may appear in only one cover-letter paragraph, and the letter names at most 2 projects (go deeper, not wider).
- `application.location`: one short location, at most 40 characters, no semicolons (for example "Mountain View, CA (Hybrid)").
- Split list requirements into one requirement per technology ("Java, Python, etc." becomes separate Java and Python entries), and include every JD-named tool that is in the supported pool (for example Claude Code, GitHub Copilot, PyTorch).

### Outreach
Sentence 2 uses the role family's hook and the #1 project's short name; nothing is hard-coded to healthcare.

### Support matching
Negated policy text ("no FastAPI", "do not infer HIPAA", "designed only") never counts as support, and `never_supported_terms` in master.json (RAG, Flask, Jira, Azure DevOps, .NET, C#, Salesforce, Terraform, Spark, Airflow, and others) always stay gaps.

## 20) v3.2 AUTOMATION (the script does the judgment-heavy work)
- `"ranking": "auto"`: the script scores all 7 projects from the JD requirements, JD-named skills, JD themes and the role family, and picks the top 3. Override only with an explicit ranking + project_scores + ranking_override_reason.
- `"bank_selection": "auto"`: the script picks the bullet variants.
- Skills: core items are guaranteed; then supported high/medium requirements, then every supported skill the JD names literally, then the plan's optional_skills, then the rest of the old baseline as filler. report.json `ats_summary` shows supported requirements visible and JD-named skills visible (target 100%).
- Gaps: report.json `jd_gap_terms_detected` lists known-unsupported terms found in the JD so none are forgotten.
- Cover letter (bank mode, required): the planner gives `cover_letter.hook` (ONE plain sentence, 8-32 words, no digits, copying at least 4 consecutive words from the JD about what the team builds or why it matters; no emotion words, no skills lists, no technology Jay lacks), optional `experience` (hein, thesis, godigital, datamaven) and optional `extra` (one sentence, <= 30 words, used only when the script reports cover_letter_jd_coverage). The script writes both paragraphs from the bank. The planner may also give `tagline_text` (one line, <= 96 characters, starts "Master's CS student ", no digits, no unsupported technology) and `cover_letter.closing` (one sentence starting "I would welcome the chance to ", <= 26 words, names the company); both are checked by the script and replace the fixed tagline and closing when valid. Older plans with `team_focus` instead of `hook` still work ("Your team <team_focus>.").

- report.json `role_mismatch: true` means the posting is not a software role Jay fits (no or almost no supported must-haves); say so first in the reply.
- Eligibility blockers are also detected from the raw JD text: any U.S. citizenship requirement, any security-clearance requirement (clearances need citizenship), and visa/H-1B restrictions.

- Skills order: core, then supported high/medium requirements, then JD-named skills, then plan extras, then the role family's relevant fillers (master.json skills.family_fillers). Generic fillers (ETL, Parallel Processing, Real-Time Monitoring on non-data roles) are gone.
- Auto ranking: a must-have that only one project proves forces that project into the top 3 (for example Pintos when C is required, LedgerFlow when Java is required).

- Degree, graduation-window, internship, production-code and AI-tool-use requirements are qualifications. Use a term from master.json `qualification_facts` (for example "Master's degree in Computer Science", "internship experience", "production code") and mark supported:true. They count as covered by Education/Experience and are never pasted into the cover letter.
- hook: one sentence, 8-32 words, copied JD phrase (4+ consecutive words), no digits, no emotion words (passionate, excited, love).

## 21) v3.2.1 AUTO JD READER (default; the planner no longer reads the JD line by line)
- Plan fields `"jd_requirements": "auto"`, `"role_family": "auto"`, `"tagline_id": "auto"`, `"jd_themes": "auto"` and `application.fit: "auto"` make the script read jd.txt itself. The planner supplies only `application` facts and `cover_letter.team_focus`.
- The reader finds sections by heading (required / preferred / responsibilities / skills list / intro / benefits), splits AND-lists, merges OR-lists and example lists ("or", "one of", "at least one", "such as", "e.g.", "like", "including", "etc.", "C++/Go") into one requirement led by Jay's strongest supported option, and turns degree, graduation-window, internship, years-of-experience, U.S. citizenship and clearance lines into qualifications.
- Priority: required-section or inline "required/must" -> must; preferred section or inline "preferred / a plus / bonus" -> medium; responsibilities and skills lists -> high. `required_section` is set only under strict headings (Required / Minimum / Basic / Must-have) or inline "required"; an unsupported one caps Fit at Low.
- Corrections without rewriting the list: `"jd_requirements_extra": [{"term","verbatim"(exact JD text),"priority","aliases"}]` adds missed items; `"jd_requirements_remove": ["term", ...]` drops false positives. Use these only when the report shows a clear miss.
- A full manual `jd_requirements` list, role_family or tagline_id still overrides the reader (not recommended).
- report.json `plan_resolved_fields` (also out/plan_resolved_fields.json) shows exactly what the reader decided.
- Skills serve the JD first: a selected-project technology the JD does not name may give up its Skills slot to a JD term (it stays visible in the project header/bullets). JD-named technologies always stay in Skills.
- Project choice: for a specific role family (not general_swe) the family's anchor project (first in preferred_projects) is ranked #1, so it gets 3 bullets and leads cover-letter paragraph 2 (full-stack -> LaunchOps, backend -> LedgerFlow, data science/ML -> Fraud, AI/LLM -> GoingOnce, systems -> Pintos). Must-haves only one project proves still force that project into the top 3.
- Every selected project includes one identity bullet that says what the project is (LaunchOps workflow, LedgerFlow exactly-once/architecture, RIPPLE core agent, GoingOnce agents, Pintos processes/syscalls/tests, Fraud GraphSAGE/dataset, Tailor pipeline/runtime).
- Technical Skills show only skills the posting names, skills visible on the page, the guaranteed baseline, and Jay's confirmed list. Go is treated as named when the posting says Golang or lists it beside other languages (for example "Java or Go").
- New supported pool items backed by evidence: Relational Databases (PostgreSQL/MySQL work), Database Design (normalized schemas at Thesis). "containerization" maps to Docker; HTML and CSS always display as HTML/CSS.
- v3.2.3: Data Pipelines (HeinOnline extraction pipeline, Go Digital ETL) and Debugging added to the pool. JDs that describe work without naming tools are read through concept terms (backend software, APIs, data modeling, monitoring, pipelines, background processing, troubleshooting, in production). Current/recent-bachelor's-only postings are an eligibility blocker. Agency postings get a "your client" letter.
