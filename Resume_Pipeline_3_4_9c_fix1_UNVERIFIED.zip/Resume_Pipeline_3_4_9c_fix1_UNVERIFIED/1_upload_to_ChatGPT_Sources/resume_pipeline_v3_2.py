#!/usr/bin/env python3
"""
Deterministic resume assembler + validator.

Canonical inputs:
  - Resume_Template_CURRENT.tex
  - master.json
  - bullet_bank.json
  - plan.json
  - raw JD text file (--jd)

The script refuses to run when the canonical template or master.json hashes do
not match the versions it was built against.

Normal outputs:
  resume.tex
  resume.pdf
  resolved_plan.json
  report.json

report.json contains failures, non-blocking warnings, and stage timestamps/timings. Passed checks are intentionally omitted.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import sys
import time
from copy import deepcopy
import itertools
from functools import lru_cache
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import fitz


EXPECTED_TEMPLATE_SHA256 = "a3aaddd95463add46e7965d099dd283bbf09b3db5d6cea1ed3c31dded7dd5a10"
EXPECTED_MASTER_JSON_SHA256 = "019e5b87c2ae1ba5c9798ae79f6eb844dffd7dffeb10dd78c77f2cdbba55e2c0"
EXPECTED_BULLET_BANK_SHA256 = "914805e95b59c485b0bd03d119f70d97acfa5b844fb0a17be5477c0be830485c"


class PipelineError(Exception):
    pass


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


class StageTimer:
    def __init__(self, report: dict[str, Any], name: str):
        self.report = report
        self.name = name

    def __enter__(self):
        self.start_perf = time.perf_counter()
        self.start_iso = now_iso()
        return self

    def __exit__(self, exc_type, exc, tb):
        end_perf = time.perf_counter()
        self.report["timestamps"][self.name] = {
            "start": self.start_iso,
            "end": now_iso(),
            "duration_ms": round((end_perf - self.start_perf) * 1000, 3),
        }


def fail(kind: str, target: str, measured: Any, expected: Any, repair: str) -> dict[str, Any]:
    return {
        "type": kind,
        "target": target,
        "measured": measured,
        "expected": expected,
        "suggested_repair": repair,
    }


def latex_escape(text: str) -> str:
    """Escape plain user/model text for LaTeX while preserving ordinary ASCII."""
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(ch, ch) for ch in text)


def normalize_fixed_text(text: str) -> str:
    text = text.replace(r"$\sim$", "~").replace(r"\%", "%").replace(r"\&", "&")
    return re.sub(r"\s+", " ", text).strip()


def normalize_skill_name(skill: str, master: dict[str, Any]) -> str:
    norm = master["skills"].get("normalization", {})
    return norm.get(skill, skill)


def supported_skill_category(skill: str, master: dict[str, Any]) -> str | None:
    """Return the resume category for a supported skill."""
    skill = normalize_skill_name(skill, master)
    pools = master["skills"]["supported_pool"]

    mapping = [
        ("languages_databases", "languages_databases"),
        ("frameworks_libraries", "frameworks_libraries"),
        ("ai_ml_data", "ai_ml"),
        ("software_engineering", "software_engineering"),
        ("tools_platforms", "tools"),
    ]
    for pool_key, category in mapping:
        if skill in pools.get(pool_key, []):
            return category
    return None


def unsupported_hits(texts: list[str], master: dict[str, Any]) -> list[str]:
    joined = "\n".join(texts).lower()
    hits = []
    for item in master["unsupported_claims"]:
        # Only scan concrete claim/token labels; skip prose-like policy entries.
        if " unless " in item.lower() or " beyond " in item.lower():
            continue
        token = item.lower()
        # Slash-composite policy labels are checked by their concrete components.
        components = [token]
        if token in {"eks/gke/aks"}:
            components = ["eks", "gke", "aks"]
        elif token == "kubernetes hpa/autoscaling":
            components = ["hpa", "autoscaling"]
        found = False
        for comp in components:
            if re.search(r"(?<![a-z0-9+#])" + re.escape(comp) + r"(?![a-z0-9+#])", joined):
                found = True
                break
        if found:
            hits.append(item)
    return hits



def extract_action_verb(bullet: str) -> str:
    m = re.match(r"([A-Za-z]+(?:-[A-Za-z]+)?)", bullet.strip())
    return m.group(1) if m else ""


def bullet_text(bullet: Any) -> str:
    if isinstance(bullet, dict):
        return str(bullet.get("text", ""))
    return str(bullet)


def normalize_numeric(token: str) -> str:
    return token.lower().replace(",", "").replace("$", "").strip()


def numeric_tokens(text: str) -> list[str]:
    return re.findall(r"\$?\d[\d,]*(?:\.\d+)?(?:%|\+)?", text)


def evidence_item(master: dict[str, Any], pid: str, evidence_id: str) -> dict[str, Any] | None:
    return master["projects"].get(pid, {}).get("evidence_items", {}).get(evidence_id)


def project_title_text(master: dict[str, Any], pid: str) -> str:
    title = master["projects"][pid].get("resume_title")
    if not title:
        return master["projects"][pid]["name"].replace(" — ", ": ")
    name = title["name"]
    desc = title.get("description")
    return f"{name}: {desc}" if desc else name


def clusters_related(master: dict[str, Any], pid: str, a: str, b: str) -> bool:
    if a == b:
        return True
    pairs = master.get("evidence_cluster_relations", {}).get(pid, [])
    return [a, b] in pairs or [b, a] in pairs


def boundary_contains(text: str, term: str) -> bool:
    """ASCII alphanumeric word-boundary match without regex compilation.

    Semantics match the previous (?<![A-Za-z0-9])TERM(?![A-Za-z0-9]) check.
    """
    if not term:
        return False
    hay=str(text).casefold(); needle=str(term).casefold(); start=0
    while True:
        idx=hay.find(needle,start)
        if idx<0:
            return False
        before_ok = idx == 0 or not (hay[idx-1].isascii() and hay[idx-1].isalnum())
        end=idx+len(needle)
        after_ok = end == len(hay) or not (hay[end].isascii() and hay[end].isalnum())
        if before_ok and after_ok:
            return True
        start=idx+1


def technology_hits(text: str, techs: list[str]) -> list[str]:
    found: list[str] = []
    for tech in sorted(techs, key=len, reverse=True):
        if boundary_contains(text, tech) and not any(
            tech.lower() in x.lower() or x.lower() in tech.lower() for x in found
        ):
            found.append(tech)
    return found


def concrete_technology_aliases(master: dict[str, Any]) -> dict[str, list[str]]:
    """Canonical concrete resume technologies -> names that may appear in bullets/headers."""
    pools = master["skills"]["supported_pool"]
    pool_keys = master["skills"].get(
        "technology_skill_pool_keys",
        ["languages_databases", "frameworks_libraries", "tools_platforms"],
    )
    canonicals: list[str] = []
    for key in pool_keys:
        for item in pools.get(key, []):
            if item not in canonicals:
                canonicals.append(item)

    aliases = {c: [c] for c in canonicals}
    for alias, canonical in master["skills"].get("normalization", {}).items():
        if canonical in aliases and alias not in aliases[canonical]:
            aliases[canonical].append(alias)
    return aliases


def selected_technology_skills(
    plan: dict[str, Any],
    master: dict[str, Any],
    project_tech: dict[str, list[str]],
) -> list[str]:
    """Return concrete canonical technologies visibly named in selected bullets/headers."""
    texts: list[str] = []
    for pid in plan.get("ranking", []):
        for bullet in plan.get("bullets", {}).get(pid, []):
            texts.append(bullet_text(bullet))
        texts.extend(project_tech.get(pid, []))

    aliases = concrete_technology_aliases(master)
    required: list[str] = []
    for canonical, names in aliases.items():
        if any(boundary_contains(text, name) for text in texts for name in names):
            required.append(canonical)
    return required


def resolve_tagline(plan: dict[str, Any], master: dict[str, Any]) -> tuple[str, str]:
    bank = master.get("taglines", {})
    options = bank.get("options", {})
    custom = re.sub(r"\s+", " ", str(plan.get("tagline_text", "") or "")).strip()
    if custom and plan.get("_tagline_text_ok"):
        return "custom", custom
    tagline_id = plan.get("tagline_id") or bank.get("default_id")
    item = options.get(tagline_id)
    if not item:
        raise PipelineError(f"Unknown tagline_id: {tagline_id}")
    return str(tagline_id), str(item["text"])


def master_supports_requirement(term: str, aliases: list[str], master: dict[str, Any]) -> bool:
    needles = [term] + list(aliases or [])
    corpus: list[str] = []

    for role in master["experience"]:
        corpus.extend(role["bullets"])
        corpus.append(role.get("evidence_anchors", ""))

    for pdata in master["projects"].values():
        corpus.extend(pdata.get("tech", []))
        corpus.extend(pdata.get("tags", []))
        for item in pdata.get("evidence_items", {}).values():
            corpus.append(item.get("text", ""))
            corpus.extend(item.get("terms", []))
            corpus.extend(item.get("claim_atoms", []))

    for values in master["skills"]["supported_pool"].values():
        corpus.extend(values)

    haystack = "\n".join(str(x) for x in corpus).lower()
    return any(str(n).lower() in haystack for n in needles if n)


def salient_bigrams(text: str) -> set[str]:
    words = re.findall(r"[a-z0-9]+", text.lower())
    stop = {
        "the","a","an","and","or","to","of","for","with","in","on","by","from","into","across","after","before",
        "using","used","that","this","each","every","all","while","through","under","over","at","as","its","it",
        "project","system","systems","service","services","data","code","software","application","applications","workflow","workflows"
    }
    out=set()
    for a,b in zip(words,words[1:]):
        if a in stop or b in stop:
            continue
        phrase=f"{a} {b}"
        if len(phrase)>=11:
            out.add(phrase)
    return out


def has_approx_qualifier(text: str, numeric_token: str) -> bool:
    pattern=re.compile(r"(?:about|approximately|around|roughly|~)\s*"+re.escape(numeric_token),re.IGNORECASE)
    return bool(pattern.search(text))


def adapt_header_tech(pid: str, vals: list[str], plan: dict[str, Any], master: dict[str, Any]) -> list[str]:
    """A technology the posting names and the chosen bullets show moves into the project heading, replacing a technology the posting does not name."""
    jd = list(plan.get("_jd_pool_terms", []) or [])
    if not jd:
        return vals
    texts = " ".join(str(b.get("text", "")) if isinstance(b, dict) else str(b) for b in (plan.get("bullets", {}) or {}).get(pid, []))
    pool = master["projects"][pid].get("tech", [])
    canon_len = len(", ".join(master["projects"][pid].get("header_priority_tech", vals)))
    out = list(vals)
    langs = {x.casefold() for x in master["skills"]["supported_pool"].get("languages_databases", [])}
    frames = {x.casefold() for x in master["skills"]["supported_pool"].get("frameworks_libraries", [])}
    cands = [t for t in jd if t not in out and t in pool and re.search(r"(?<![A-Za-z])" + re.escape(t) + r"(?![A-Za-z])", texts)]
    cands.sort(key=lambda t: (0 if t.casefold() in langs else 1 if t.casefold() in frames else 2))
    jdkeys = {x.casefold() for x in jd}
    for t in cands[:1]:  # at most one swap, so the project keeps its identity technologies
        spot = next((i for i in range(len(out) - 1, 0, -1) if out[i].casefold() not in jdkeys), None)
        if spot is None:
            continue
        cand = out[:spot] + [t] + out[spot + 1:]
        if len(", ".join(cand)) <= canon_len:
            out = cand
    return out


def resolved_project_header_tech(master: dict[str, Any], display_order: list[str], plan: dict[str, Any] | None = None) -> dict[str, list[str]]:
    defaults = {pid:list(master["projects"][pid].get("header_priority_tech", master["projects"][pid].get("tech", [])[:4])) for pid in display_order}
    if not plan:
        return defaults
    overrides = plan.get("project_tech", {}) or {}
    out = {}
    for pid in display_order:
        vals = overrides.get(pid, defaults[pid])
        if not isinstance(vals, list) or not all(isinstance(x, str) for x in vals):
            raise PipelineError(f"project_tech.{pid} must be a list of strings")
        if pid not in overrides:
            vals = adapt_header_tech(pid, vals, plan, master)
        out[pid] = vals
    return out


def validate_semantic_plan(
    plan: dict[str, Any],
    master: dict[str, Any],
    warnings: list[dict[str, Any]] | None = None,
    free_text_mode: bool = False,
) -> list[dict[str, Any]]:
    failures: list[dict[str, Any]] = []
    ranking = plan["ranking"]
    jd_themes = {str(x).strip().lower() for x in plan.get("jd_themes", [])}
    taxonomy = master.get("project_verbs", {})
    banned = master["banned_project_verbs"]

    all_verbs: list[str] = []

    for rank_i, pid in enumerate(ranking):
        bullets = plan["bullets"][pid]
        pdata = master["projects"][pid]
        evidence_map = pdata.get("evidence_items", {})
        main_ids: list[str] = []
        hero_used = False
        headline_used = False
        project_bullet_texts: list[tuple[str,str]] = []

        for idx, bullet in enumerate(bullets, 1):
            target = f"{pid}.bullet_{idx}"
            if not isinstance(bullet, dict):
                failures.append(
                    fail(
                        "bullet_schema",
                        target,
                        type(bullet).__name__,
                        "Object with text, verb, main_evidence_id, supporting_evidence_ids, claims, jd_terms",
                        "Convert this project bullet to the structured evidence-aware schema.",
                    )
                )
                continue

            required = {"text", "verb", "main_evidence_id", "supporting_evidence_ids", "claims", "jd_terms"}
            missing = sorted(required - set(bullet))
            if missing:
                failures.append(
                    fail(
                        "bullet_schema",
                        target,
                        missing,
                        "All structured bullet fields present",
                        "Add the missing fields while preserving the same supported evidence.",
                    )
                )
                continue

            text = str(bullet["text"]).strip()
            project_bullet_texts.append((target, text))
            verb = str(bullet["verb"]).strip()
            opening = extract_action_verb(text)
            main_id = str(bullet["main_evidence_id"])
            support_ids = list(bullet.get("supporting_evidence_ids", []))
            claims = list(bullet.get("claims", []))

            if opening.lower() != verb.lower():
                failures.append(
                    fail(
                        "verb_text_mismatch",
                        target,
                        {"declared": verb, "opening": opening},
                        "Declared verb matches the bullet's opening verb",
                        "Make the bullet opening and verb field identical.",
                    )
                )

            all_verbs.append(verb.lower())

            banned_found = [
                v for v in banned
                if re.search(r"\b" + re.escape(v) + r"\b", text, flags=re.IGNORECASE)
            ]
            if banned_found:
                failures.append(
                    fail(
                        "banned_project_verb",
                        target,
                        banned_found,
                        "No banned verb anywhere in a project bullet",
                        "Rewrite only this bullet with an allowed verb.",
                    )
                )

            main = evidence_map.get(main_id)
            if main is None:
                failures.append(
                    fail(
                        "invalid_main_evidence_id",
                        target,
                        main_id,
                        sorted(evidence_map),
                        "Use a main evidence ID from the same project.",
                    )
                )
                continue

            main_ids.append(main_id)
            hero_used = hero_used or bool(main.get("hero", False))
            headline_used = headline_used or bool(main.get("headline", False))

            if main.get("resume_eligible", True) is False:
                failures.append(
                    fail(
                        "non_resume_evidence",
                        target,
                        main_id,
                        "resume-eligible evidence",
                        "Choose a resume-eligible main evidence item.",
                    )
                )

            referenced = [main]
            for sid in support_ids:
                item = evidence_map.get(sid)
                if item is None:
                    failures.append(
                        fail(
                            "invalid_supporting_evidence_id",
                            target,
                            sid,
                            sorted(evidence_map),
                            "Use supporting evidence IDs from the same project.",
                        )
                    )
                    continue
                if item.get("resume_eligible", True) is False:
                    failures.append(
                        fail(
                            "non_resume_evidence",
                            target,
                            sid,
                            "resume-eligible evidence",
                            "Remove this supporting evidence ID.",
                        )
                    )
                referenced.append(item)

            # Main evidence may not be reused by two bullets in the same project.
            if main_ids.count(main_id) > 1:
                failures.append(
                    fail(
                        "repeated_main_evidence",
                        target,
                        main_id,
                        "Unique main evidence ID within each project's bullets",
                        "Use a different primary accomplishment for this bullet.",
                    )
                )

            # Evidence cluster compatibility.
            main_cluster = main.get("cluster", "")
            for item in referenced[1:]:
                other = item.get("cluster", "")
                if not clusters_related(master, pid, main_cluster, other):
                    failures.append(
                        fail(
                            "unrelated_evidence_clusters",
                            target,
                            [main_cluster, other],
                            "Same or explicitly related evidence clusters",
                            "Keep one accomplishment cluster in this bullet, or use only a Master-approved related cluster.",
                        )
                    )

            # Optional evidence may be used only when its JD theme is present.
            for item in referenced:
                if item.get("optional", False):
                    allowed = {str(x).lower() for x in item.get("optional_themes", [])}
                    if not (allowed & jd_themes):
                        failures.append(
                            fail(
                                "optional_evidence_without_jd_theme",
                                target,
                                {"evidence": main_id, "allowed_themes": sorted(allowed), "jd_themes": sorted(jd_themes)},
                                "At least one matching JD theme",
                                "Remove this optional evidence or use it only for a JD whose themes justify it.",
                            )
                        )

            # Declared claims must exactly map to claim atoms from referenced evidence.
            allowed_claims = {
                str(atom).strip().lower()
                for item in referenced
                for atom in item.get("claim_atoms", [])
            }
            bad_claims = [c for c in claims if str(c).strip().lower() not in allowed_claims]
            if bad_claims:
                failures.append(
                    fail(
                        "ungrounded_declared_claim",
                        target,
                        bad_claims,
                        sorted(allowed_claims),
                        "Use only claim atoms from referenced evidence IDs.",
                    )
                )

            # Numeric tokens in prose must exist somewhere in the referenced evidence.
            reference_text = "\n".join(
                [item.get("text", "") for item in referenced]
                + [str(a) for item in referenced for a in item.get("claim_atoms", [])]
            )
            allowed_nums = {normalize_numeric(x) for x in numeric_tokens(reference_text)}
            prose_nums = numeric_tokens(text)
            unsupported_nums = [x for x in prose_nums if normalize_numeric(x) not in allowed_nums]
            if unsupported_nums:
                failures.append(
                    fail(
                        "unsupported_number",
                        target,
                        unsupported_nums,
                        sorted(allowed_nums),
                        "Use only numbers present in the referenced evidence.",
                    )
                )

            approx_required = {
                normalize_numeric(x): x
                for item in referenced
                for x in item.get("approx_numbers", [])
            }
            missing_qualifiers=[]
            for prose_num in prose_nums:
                norm=normalize_numeric(prose_num)
                if norm in approx_required and not has_approx_qualifier(text, prose_num):
                    missing_qualifiers.append(prose_num)
            if missing_qualifiers:
                failures.append(
                    fail(
                        "missing_approximation_qualifier",
                        target,
                        missing_qualifiers,
                        "Approximate evidence values must be written with about/approximately/around/~",
                        "Restore the approximation qualifier from the canonical evidence.",
                    )
                )

            if len(prose_nums) > master["writing_rules"]["max_numbers_per_project_bullet"]:
                failures.append(
                    fail(
                        "too_many_numbers",
                        target,
                        prose_nums,
                        f"<= {master['writing_rules']['max_numbers_per_project_bullet']} numeric tokens",
                        "Keep the strongest result and scale; move other numbers back to evidence.",
                    )
                )

            # Named technologies should be supported by the referenced evidence.
            hits = technology_hits(text, pdata.get("tech", []))
            ref_text = "\n".join(
                [item.get("text", "") for item in referenced]
                + [str(x) for item in referenced for x in item.get("terms", [])]
            ).lower()
            bad_tech = [x for x in hits if x.lower() not in ref_text]
            if bad_tech:
                failures.append(
                    fail(
                        "technology_not_in_referenced_evidence",
                        target,
                        bad_tech,
                        "Technology named by referenced evidence",
                        "Remove the technology or cite the evidence item that actually supports it.",
                    )
                )

            if len(hits) > master["writing_rules"]["max_named_technologies_per_project_bullet"]:
                failures.append(
                    fail(
                        "too_many_named_technologies",
                        target,
                        hits,
                        f"<= {master['writing_rules']['max_named_technologies_per_project_bullet']}",
                        "Keep only the technologies that explain the work or match the JD.",
                    )
                )

            # Guard sensitive semantic nouns/phrases against unreferenced evidence.
            guard_terms = master.get("semantic_guard_terms", {}).get(pid, [])
            referenced_terms = "\n".join(
                [item.get("text", "") for item in referenced]
                + [str(x) for item in referenced for x in item.get("terms", [])]
                + [str(x) for item in referenced for x in item.get("claim_atoms", [])]
            ).lower()
            bad_guard = []
            for term in guard_terms:
                if boundary_contains(text, term) and not boundary_contains(referenced_terms, term):
                    bad_guard.append(term)
            if bad_guard:
                failures.append(
                    fail(
                        "unguarded_semantic_term",
                        target,
                        bad_guard,
                        "Sensitive term must be present in referenced evidence",
                        "Remove the unsupported noun/phrase or cite the evidence that supports it.",
                    )
                )

            # Heuristic prose guard: advisory only. Bank text is reviewed offline;
            # free-text compatibility mode may surface this as a warning.
            filler_hits = [
                phrase for phrase in master.get("writing_rules", {}).get("filler_tail_phrases", [])
                if phrase.lower() in text.lower()
            ]
            if filler_hits and warnings is not None:
                warnings.append(
                    fail(
                        "restatement_or_padding",
                        target,
                        filler_hits,
                        "No filler/restatement tail",
                        "Advisory only: improve the bank offline; do not repair selected bank prose in an application run.",
                    )
                )

            # LedgerFlow safety wording: unqualified exactly-once wording is too easy
            # to misread as exactly-once Kafka delivery.
            if pid == "ledgerflow" and "exactly-once" in text.lower():
                lowered = text.lower()
                if not ("financial effects" in lowered and "at-least-once" in lowered):
                    failures.append(
                        fail(
                            "ambiguous_exactly_once_wording",
                            target,
                            "exactly-once",
                            "Plain wording ('each payment is recorded once even when messages repeat') or explicit financial-effects qualifier",
                            "Rewrite without implying exactly-once Kafka delivery.",
                        )
                    )

            # Verb semantics against the main evidence kind.
            rule = taxonomy.get(verb)
            if rule is None:
                failures.append(
                    fail(
                        "verb_not_in_taxonomy",
                        target,
                        verb,
                        sorted(taxonomy),
                        "Choose a verb from the canonical verb taxonomy.",
                    )
                )
            else:
                kind = main.get("kind", "")
                if kind not in rule.get("allowed_kinds", []):
                    failures.append(
                        fail(
                            "verb_semantic_mismatch",
                            target,
                            {"verb": verb, "main_evidence_kind": kind},
                            rule.get("allowed_kinds", []),
                            f"Use a verb whose usage matches '{kind}' evidence.",
                        )
                    )

        # Heuristic phrase-overlap detection is advisory and only relevant to
        # explicit free-text compatibility mode. Bank conflicts are checked by id.
        if free_text_mode and warnings is not None:
            for i in range(len(project_bullet_texts)):
                for j in range(i+1, len(project_bullet_texts)):
                    t1, b1 = project_bullet_texts[i]
                    t2, b2 = project_bullet_texts[j]
                    shared = sorted(salient_bigrams(b1) & salient_bigrams(b2))
                    tech_bigrams = {x.lower() for x in pdata.get("tech", []) if len(x.split()) == 2}
                    phrase_exemptions = set(master.get("semantic_phrase_overlap_exemptions", [])) | tech_bigrams
                    shared = [x for x in shared if x not in phrase_exemptions]
                    if shared:
                        warnings.append(
                            fail(
                                "repeated_salient_phrase",
                                f"{t1} <-> {t2}",
                                shared,
                                "No repeated salient phrase across bullets in the same project",
                                "Advisory only in free-text compatibility mode.",
                            )
                        )

        if rank_i == 0 and not hero_used:
            failures.append(
                fail(
                    "rank1_missing_hero_evidence",
                    pid,
                    [b.get("main_evidence_id") for b in bullets if isinstance(b, dict)],
                    "At least one rank #1 bullet uses hero evidence",
                    "Replace one rank #1 bullet with the project's strongest hero evidence.",
                )
            )

        if rank_i == 0 and master.get("semantic_validation_rules", {}).get("rank1_requires_headline_evidence", False) and not headline_used:
            failures.append(
                fail(
                    "rank1_missing_headline_evidence",
                    pid,
                    [b.get("main_evidence_id") for b in bullets if isinstance(b, dict)],
                    pdata.get("headline_evidence_id"),
                    "Use the rank #1 project's headline evidence as one of its bullets.",
                )
            )

    duplicates = sorted({v for v in all_verbs if v and all_verbs.count(v) > 1})
    if duplicates:
        failures.append(
            fail(
                "duplicate_project_action_verb",
                "project_bullets",
                duplicates,
                "Seven distinct action verbs",
                "Change only duplicated opening verbs using the verb taxonomy.",
            )
        )

    return failures


def validate_ats_coverage(
    plan: dict[str, Any],
    master: dict[str, Any],
    ordered_bullets: list[str],
    resolved_skills: dict[str, Any],
    project_tech: dict[str, list[str]],
) -> list[dict[str, Any]]:
    failures: list[dict[str, Any]] = []
    requirements = plan.get("jd_requirements", [])

    visible: list[str] = []
    for role in master["experience"]:
        visible.extend(role["bullets"])
    visible.extend(ordered_bullets)
    for values in resolved_skills.get("skills", {}).values():
        visible.extend(values)
    for values in project_tech.values():
        visible.extend(values)
    visible_text = "\n".join(visible).lower()

    for req in requirements:
        if not isinstance(req, dict):
            continue
        term = str(req.get("term", "")).strip()
        aliases = [str(x) for x in req.get("aliases", [])]
        priority = str(req.get("priority", "medium")).lower()
        declared_supported = bool(req.get("supported", False))
        actual_supported = master_supports_requirement(term, aliases, master)

        if declared_supported != actual_supported:
            failures.append(
                fail(
                    "jd_support_classification_mismatch",
                    term,
                    declared_supported,
                    actual_supported,
                    "Align the requirement's supported flag with the canonical evidence.",
                )
            )

        if priority not in master.get("ats_rules", {}).get("jd_requirement_priorities_checked", ["must", "high"]):
            continue
        if not actual_supported:
            continue

        needles = [term] + aliases
        covered = any(n.lower() in visible_text for n in needles if n)
        if not covered:
            failures.append(
                fail(
                    "ats_priority_term_missing",
                    term,
                    {"priority": priority, "aliases": aliases},
                    "Supported must/high JD term appears in Experience, Projects, project tech labels, or Skills",
                    "Add the highest-value supported term once in a natural project bullet, project tech label, or skill line.",
                )
            )
    return failures


def validate_selected_technology_skill_coverage(
    plan: dict[str, Any],
    master: dict[str, Any],
    resolved_skills: dict[str, Any],
    project_tech: dict[str, list[str]],
) -> list[dict[str, Any]]:
    required = selected_technology_skills(plan, master, project_tech)
    visible: set[str] = set()
    for values in resolved_skills.get("skills", {}).values():
        for value in values:
            visible.add(normalize_skill_name(str(value), master))
    missing = [x for x in required if normalize_skill_name(x, master) not in visible]
    if not missing:
        return []
    return [
        fail(
            "selected_technology_missing_from_skills",
            "TECHNICAL SKILLS",
            missing,
            required,
            "Every concrete technology named in a selected bullet/header must appear in Skills under its canonical name or supported alias.",
        )
    ]


def load_bullet_bank(path: Path) -> dict[str, Any]:
    bank = json.loads(path.read_text(encoding="utf-8"))
    if v349c_page_on():   # v3.4.9c run 2 P4: never rendered, so never selectable
        for pid, vs in (bank.get("projects") or {}).items():
            bank["projects"][pid] = [v for v in vs if not any(x in str(v.get("text", "")) for x in V349C_NEVER_RENDER)]
    return bank


def expand_bank_plan(
    raw_plan: dict[str, Any],
    bank: dict[str, Any],
    master: dict[str, Any],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Expand bank_selection ids into the existing structured bullet schema."""
    failures: list[dict[str, Any]] = []
    ranking = raw_plan.get("ranking")
    if not isinstance(ranking, list) or len(ranking) != 3 or len(set(ranking)) != 3:
        return deepcopy(raw_plan), [fail("ranking", "ranking", ranking, "Exactly 3 distinct project IDs", "Fix ranking before bank expansion.")]

    selections = raw_plan.get("bank_selection")
    if not isinstance(selections, dict):
        return deepcopy(raw_plan), [fail("bank_selection_schema", "bank_selection", selections, "Object keyed by selected project id", "Provide bank_selection ids only.")]

    index: dict[str, tuple[str, dict[str, Any]]] = {}
    for project_id, variants in bank.get("projects", {}).items():
        for variant in variants:
            index[str(variant.get("id"))] = (project_id, variant)

    expected_counts = {ranking[0]: 3, ranking[1]: 2, ranking[2]: 2}
    expanded = deepcopy(raw_plan)
    expanded["bullets"] = {}
    chosen_variants: list[dict[str, Any]] = []
    chosen_ids: list[str] = []

    for pid, expected in expected_counts.items():
        ids = selections.get(pid)
        if not isinstance(ids, list):
            failures.append(fail("bank_selection_schema", pid, ids, f"List of exactly {expected} bank ids", "Provide bank variant ids for this project."))
            continue
        if len(ids) != expected:
            failures.append(fail("bullet_allocation", pid, len(ids), expected, f"Choose exactly {expected} bank variants for {pid}."))
        bullets=[]
        for vid in ids:
            entry=index.get(str(vid))
            if entry is None:
                failures.append(fail("bank_variant_missing", str(vid), "not found", "Variant id present in bullet_bank.json", "Choose an existing bank variant id."))
                continue
            owner, variant=entry
            if owner != pid:
                failures.append(fail("bank_variant_wrong_project", str(vid), owner, pid, "Select variants only from the project they belong to."))
                continue
            if variant.get("status") != "ok":
                failures.append(fail("bank_variant_not_ok", str(vid), variant.get("status"), "ok", "Rerun bank_check.py and choose only passing variants."))
                continue
            if variant.get("optional", False):
                allowed={str(x).strip().lower() for x in variant.get("optional_themes", [])}
                themes={str(x).strip().lower() for x in raw_plan.get("jd_themes", [])}
                if not (allowed & themes):
                    failures.append(fail("bank_optional_theme_mismatch", str(vid), {"optional_themes":sorted(allowed),"jd_themes":sorted(themes)}, "Non-empty intersection", "Choose this optional variant only for a matching JD theme."))
            bullet={k:deepcopy(variant[k]) for k in ("text","verb","main_evidence_id","supporting_evidence_ids","claims","jd_terms")}
            bullets.append(bullet)
            chosen_variants.append(variant)
            chosen_ids.append(str(vid))
        expanded["bullets"][pid]=bullets

    # No ids for unselected projects: catches accidental project/id mixing without
    # requiring the plan to enumerate all seven projects here.
    extras=sorted(set(selections)-set(ranking))
    if extras:
        failures.append(fail("bank_selection_unselected_project", "bank_selection", extras, ranking, "Remove bank selections for projects outside the top three."))

    chosen_set=set(chosen_ids)
    clashes=[]
    for variant in chosen_variants:
        for other in variant.get("conflicts_with", []):
            if other in chosen_set:
                pair=tuple(sorted((variant["id"], other)))
                if pair not in clashes:
                    clashes.append(pair)
    if clashes:
        failures.append(fail("bank_conflicts_with", "bank_selection", [list(x) for x in clashes], "No selected variants conflict", "Choose a non-conflicting bank combination; do not write new prose."))

    verbs=[str(v.get("verb","")).lower() for v in chosen_variants]
    dup=sorted({v for v in verbs if v and verbs.count(v)>1})
    if dup:
        failures.append(fail("duplicate_project_action_verb", "bank_selection", dup, "Seven distinct action verbs", "Choose bank variants with distinct verbs; do not edit prose."))

    rank1_ids=set(selections.get(ranking[0], []) if isinstance(selections.get(ranking[0]),list) else [])
    rank1_headline=any(v.get("id") in rank1_ids and v.get("headline") is True for v in chosen_variants)
    if not rank1_headline:
        failures.append(fail("rank1_missing_headline_variant", ranking[0], sorted(rank1_ids), "At least one selected rank #1 variant has headline=true", "Choose a headline=true bank variant for rank #1."))

    return expanded, failures


def parse_month_year(value: str) -> tuple[int, int]:
    clean = value.strip()
    dt = datetime.strptime(clean, "%B %Y")
    return dt.year, dt.month


def build_display_order(ranking: list[str], master: dict[str, Any]) -> list[str]:
    rank_index = {pid: i for i, pid in enumerate(ranking)}
    return sorted(
        ranking,
        key=lambda pid: (
            -parse_month_year(master["projects"][pid]["date"])[0],
            -parse_month_year(master["projects"][pid]["date"])[1],
            rank_index[pid],
        ),
    )



def expected_ranking_from_scores(plan: dict[str, Any]) -> list[str] | None:
    scores = plan.get("project_scores")
    if not isinstance(scores, dict) or len(scores) < 3:
        return None
    parsed: list[tuple[str, float, int]] = []
    for i, (pid, score) in enumerate(scores.items()):
        if not isinstance(pid, str) or not isinstance(score, (int, float)) or isinstance(score, bool):
            return None
        parsed.append((pid, float(score), i))
    parsed.sort(key=lambda item: (-item[1], item[2]))
    return [pid for pid, _score, _i in parsed[:3]]


def validate_ranking_consistency(plan: dict[str, Any]) -> list[dict[str, Any]]:
    scores = plan.get("project_scores")
    expected = expected_ranking_from_scores(plan)
    if expected is None:
        return [fail(
            "project_scores_schema", "project_scores", scores,
            "Object with at least three numeric project scores",
            "Score the active projects before ranking them; this is a preflight/schema correction, not a repair pass.",
        )]
    ranking = plan.get("ranking")
    if ranking == expected:
        return []
    reason = plan.get("ranking_override_reason")
    if isinstance(reason, str) and reason.strip():
        return []
    return [fail(
        "ranking_project_scores_mismatch", "ranking", ranking, expected,
        "ranking must equal the top three project_scores in descending score order; add a non-empty ranking_override_reason only for an intentional override.",
    )]


def validate_plan(
    plan: dict[str, Any],
    master: dict[str, Any],
    warnings: list[dict[str, Any]] | None = None,
    free_text_mode: bool = False,
) -> list[dict[str, Any]]:
    failures: list[dict[str, Any]] = []
    active = set(master["project_selection_rules"]["active_project_ids"])

    ranking = plan.get("ranking")
    if not isinstance(ranking, list) or len(ranking) != 3 or len(set(ranking)) != 3:
        failures.append(
            fail(
                "ranking",
                "ranking",
                ranking,
                "Exactly 3 distinct project IDs",
                "Provide exactly three distinct active project IDs in relevance order.",
            )
        )
        return failures

    invalid = [x for x in ranking if x not in active]
    if invalid:
        failures.append(
            fail(
                "ranking_project_id",
                "ranking",
                invalid,
                sorted(active),
                "Replace invalid project IDs with active project IDs.",
            )
        )
        return failures

    failures.extend(validate_ranking_consistency(plan))

    bullets = plan.get("bullets", {})
    expected_counts = {ranking[0]: 3, ranking[1]: 2, ranking[2]: 2}
    for pid, expected in expected_counts.items():
        actual = bullets.get(pid)
        count = len(actual) if isinstance(actual, list) else None
        if count != expected:
            failures.append(
                fail(
                    "bullet_allocation",
                    pid,
                    count,
                    expected,
                    f"Provide exactly {expected} structured bullets for {pid}.",
                )
            )

    optional = plan.get("optional_skills", [])
    if not isinstance(optional, list):
        failures.append(
            fail(
                "optional_skills_schema",
                "optional_skills",
                type(optional).__name__,
                "Ranked list of skill strings",
                "Make optional_skills a list ordered from highest to lowest priority.",
            )
        )
    else:
        unsupported_optional = []
        for raw in optional:
            if not isinstance(raw, str):
                unsupported_optional.append(raw)
                continue
            normalized = normalize_skill_name(raw, master)
            if supported_skill_category(normalized, master) is None:
                unsupported_optional.append(raw)
        if unsupported_optional:
            failures.append(
                fail(
                    "unsupported_optional_skill",
                    "optional_skills",
                    unsupported_optional,
                    "Every optional skill exists in master.json supported_pool",
                    "Remove unsupported skills or update the canonical evidence first.",
                )
            )

    themes = plan.get("jd_themes")
    if not isinstance(themes, list) or not all(isinstance(x, str) for x in themes):
        failures.append(
            fail(
                "jd_themes_schema",
                "jd_themes",
                themes,
                "List of canonical JD-theme strings",
                "Provide jd_themes such as backend, distributed_systems, reliability, performance, kubernetes.",
            )
        )

    reqs = plan.get("jd_requirements")
    if not isinstance(reqs, list) or not reqs:
        failures.append(
            fail(
                "jd_requirements_schema",
                "jd_requirements",
                reqs,
                "Non-empty list of requirement objects",
                "Add canonical JD requirements with term, aliases, priority, and supported fields.",
            )
        )
    else:
        for i, req in enumerate(reqs, 1):
            if not isinstance(req, dict):
                failures.append(
                    fail(
                        "jd_requirement_schema",
                        f"jd_requirements[{i}]",
                        type(req).__name__,
                        "Object",
                        "Use an object with term, aliases, priority, supported.",
                    )
                )
                continue
            missing = {"term", "aliases", "priority", "supported"} - set(req)
            if missing:
                failures.append(
                    fail(
                        "jd_requirement_schema",
                        f"jd_requirements[{i}]",
                        sorted(missing),
                        "term, aliases, priority, supported",
                        "Add the missing requirement fields.",
                    )
                )

    application = plan.get("application", {})
    required_app = ["company", "role", "location", "visa_sponsorship", "fit"]
    missing_app = [k for k in required_app if not application.get(k)]
    if missing_app:
        failures.append(
            fail(
                "application_metadata",
                "application",
                missing_app,
                required_app,
                "Provide tracker metadata; document generation automatically counts as Applied.",
            )
        )

    tagline_id = plan.get("tagline_id")
    tagline_bank = master.get("taglines", {})
    tagline_options = tagline_bank.get("options", {})
    if not tagline_id or tagline_id not in tagline_options:
        failures.append(
            fail(
                "tagline_id",
                "tagline_id",
                tagline_id,
                sorted(tagline_options),
                "Select one pre-approved tagline id from master.json; do not write tagline prose.",
            )
        )
    else:
        allowed_themes = {str(x).strip().lower() for x in tagline_options[tagline_id].get("themes", [])}
        jd_theme_set = {str(x).strip().lower() for x in plan.get("jd_themes", [])}
        if allowed_themes and not (allowed_themes & jd_theme_set):
            failures.append(
                fail(
                    "tagline_theme_mismatch",
                    tagline_id,
                    {"tagline_themes": sorted(allowed_themes), "jd_themes": sorted(jd_theme_set)},
                    "Non-empty theme intersection or use the general tagline",
                    "Choose a pre-approved tagline whose themes match this JD; do not write new prose.",
                )
            )

    cover = plan.get("cover_letter_paragraphs", [])
    if cover and (not isinstance(cover, list) or not all(isinstance(x, str) for x in cover)):
        failures.append(
            fail(
                "cover_letter_schema",
                "cover_letter_paragraphs",
                cover,
                "List of strings",
                "Provide cover_letter_paragraphs as a list of paragraph strings.",
            )
        )

    if not failures:
        failures.extend(validate_semantic_plan(plan, master, warnings=warnings, free_text_mode=free_text_mode))

    return failures

def build_skill_states(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    """
    Build prefix states. Concrete technologies named in selected bullets or
    rendered project headers are mandatory; ranked optional skills are added
    afterward until the compile-time line budget is reached.
    """
    baseline = deepcopy(master["skills"]["baseline"])
    states: list[dict[str, Any]] = []

    header_tech = resolved_project_header_tech(master, plan["ranking"], plan)
    required_techs = selected_technology_skills(plan, master, header_tech)

    # The Master permits exactly one generic baseline item to be pruned. When
    # selected projects introduce any concrete technology that is not already
    # in the baseline, prioritize those concrete technologies over the generic
    # Neural Networks umbrella so the 7-line skill budget can still hold.
    pruned_baseline_items: list[str] = []
    baseline_flat = {x for values in baseline.values() for x in values}
    if any(skill not in baseline_flat for skill in required_techs):
        prunable = master["skills"].get("only_prunable_baseline_item")
        if prunable:
            for cat, values in baseline.items():
                if prunable in values:
                    baseline[cat] = [x for x in values if x != prunable]
                    pruned_baseline_items.append(prunable)
                    break

    optionals = [normalize_skill_name(s, master) for s in plan.get("optional_skills", [])]
    optionals = [s for s in optionals if s not in required_techs]

    def make_state(prefix: list[str]) -> dict[str, Any]:
        state = deepcopy(baseline)
        matched_tools = set()

        # Selected-project technologies are mandatory and, for Tools, protected
        # from the default pruning sequence.
        for skill in required_techs:
            cat = supported_skill_category(skill, master)
            if cat is None:
                continue
            if cat == "tools":
                matched_tools.add(skill)
            if skill not in state[cat]:
                state[cat].append(skill)

        for skill in prefix:
            cat = supported_skill_category(skill, master)
            if cat is None:
                continue
            if cat == "tools" and skill in baseline["tools"]:
                matched_tools.add(skill)
                continue
            if skill not in state[cat]:
                state[cat].append(skill)

        return {
            "skills": state,
            "matched_tools": sorted(matched_tools),
            "prefix": list(prefix),
            "required_technologies": list(required_techs),
            "pruned_baseline_items": list(pruned_baseline_items),
        }

    states.append(make_state([]))
    for i in range(1, len(optionals) + 1):
        states.append(make_state(optionals[:i]))
    return states


def tool_variants(tools: list[str], matched_tools: set[str], prune_order: list[str]) -> list[list[str]]:
    variants = [list(tools)]
    cur = list(tools)
    for default in prune_order:
        if default in matched_tools:
            continue
        if default in cur:
            cur = [x for x in cur if x != default]
            variants.append(list(cur))
    return variants


def tex_skill_measurement_and_selection(states: list[dict[str, Any]], master: dict[str, Any]) -> str:
    """
    Generate compile-time TeX that measures candidate skill states invisibly,
    accepts ranked optional skills in prefix order, and stops at the first state
    that exceeds a category/total line budget.

    State/control-sequence names use letters only because TeX control-sequence
    names cannot contain ordinary digits.
    """
    if len(states) > 26:
        raise PipelineError("At most 25 optional skills are supported in one plan")

    limits = master["layout_rules"]["skills_category_line_limits"]
    prune_order = master["skills"]["tools_prune_order"]

    label = {
        "languages_databases": r"Languages \& Databases",
        "frameworks_libraries": r"Frameworks \& Libraries",
        "ai_ml": r"AI/ML",
        "software_engineering": r"Software Engineering",
        "tools": r"Tools",
    }

    category_order = [
        "languages_databases",
        "frameworks_libraries",
        "ai_ml",
        "software_engineering",
    ]

    macro_name = {
        "languages_databases": "LanguagesDatabases",
        "frameworks_libraries": "FrameworksLibraries",
        "ai_ml": "AiMl",
        "software_engineering": "SoftwareEngineering",
    }

    def sid(i: int) -> str:
        return chr(ord("A") + i)

    def vid(j: int) -> str:
        if j >= 26:
            raise PipelineError("Too many Tools-pruning variants")
        return chr(ord("A") + j)

    lines: list[str] = [
        "% ==== AUTO-GENERATED SKILL FITTER ====",
        r"\newcount\SkillLineCount",
        r"\newcount\SkillTotalCount",
        r"\newif\ifSkillStateFits",
        r"\newif\ifSkillToolsFit",
        r"\newcommand{\CountSkillLines}[2]{%",
        r"  \setbox0=\vbox{%",
        r"    \hsize=\dimexpr\textwidth-\leftmargini\relax",
        r"    \parindent=0pt",
        r"    \noindent\textbf{#1:} #2\par",
        r"    \global\SkillLineCount=\prevgraf",
        r"  }%",
        r"}",
    ]

    variants_by_state: dict[int, list[list[str]]] = {}
    for i, st in enumerate(states):
        skills = st["skills"]
        token = sid(i)
        for cat in category_order:
            content = ", ".join(latex_escape(x) for x in skills[cat])
            lines.append(fr"\def\State{token}{macro_name[cat]}{{{content}}}")

        variants = tool_variants(
            skills["tools"],
            set(st["matched_tools"]),
            prune_order,
        )
        variants_by_state[i] = variants
        for j, variant in enumerate(variants):
            content = ", ".join(latex_escape(x) for x in variant)
            lines.append(fr"\def\State{token}ToolsV{vid(j)}{{{content}}}")

    lines.extend([
        r"\def\FinalLanguagesDatabases{}",
        r"\def\FinalFrameworksLibraries{}",
        r"\def\FinalAiMl{}",
        r"\def\FinalSoftwareEngineering{}",
        r"\def\FinalTools{}",
    ])

    def state_eval_tex(i: int) -> list[str]:
        token = sid(i)
        out = [
            r"\SkillStateFitstrue",
            r"\SkillTotalCount=0",
        ]
        for cat in category_order:
            smacro = fr"\State{token}{macro_name[cat]}"
            out.extend([
                fr"\CountSkillLines{{{label[cat]}}}{{{smacro}}}",
                *([fr"\ifx{smacro}\empty\SkillLineCount=0 \fi"] if _v347_on("skills_cap5_v349b") else []),   # v3.4.9b: a category the page does not show takes no line
                fr"\ifnum\SkillLineCount>{limits[cat]} \SkillStateFitsfalse\fi",
                r"\advance\SkillTotalCount by \SkillLineCount",
            ])

        out.extend([
            r"\SkillToolsFitfalse",
            r"\def\StateToolsSelected{}",
        ])

        variants = variants_by_state[i]
        # Try full Tools first, then deterministic prune variants until one line.
        for j, _ in enumerate(variants):
            vtoken = vid(j)
            if j == 0:
                out.extend([
                    fr"\CountSkillLines{{Tools}}{{\State{token}ToolsV{vtoken}}}",
                    r"\ifnum\SkillLineCount=1",
                    r"  \SkillToolsFittrue",
                    fr"  \global\let\StateToolsSelected\State{token}ToolsV{vtoken}",
                    fr"  \typeout{{TOOLVARIANT:{i}:{j}}}",
                    r"\fi",
                ])
            else:
                out.extend([
                    r"\ifSkillToolsFit\else",
                    fr"  \CountSkillLines{{Tools}}{{\State{token}ToolsV{vtoken}}}",
                    r"  \ifnum\SkillLineCount=1",
                    r"    \SkillToolsFittrue",
                    fr"    \global\let\StateToolsSelected\State{token}ToolsV{vtoken}",
                    fr"    \typeout{{TOOLVARIANT:{i}:{j}}}",
                    r"  \fi",
                    r"\fi",
                ])

        out.extend([
            r"\ifSkillToolsFit\else\SkillStateFitsfalse\fi",
            r"\advance\SkillTotalCount by \SkillLineCount",
            fr"\ifnum\SkillTotalCount>{master['layout_rules']['skills_rendered_lines_max']} \SkillStateFitsfalse\fi",
        ])
        return out

    def apply_state_tex(i: int) -> list[str]:
        token = sid(i)
        return [
            fr"\global\let\FinalLanguagesDatabases\State{token}LanguagesDatabases",
            fr"\global\let\FinalFrameworksLibraries\State{token}FrameworksLibraries",
            fr"\global\let\FinalAiMl\State{token}AiMl",
            fr"\global\let\FinalSoftwareEngineering\State{token}SoftwareEngineering",
            r"\global\let\FinalTools\StateToolsSelected",
            fr"\typeout{{SKILLSTATEPASS:{i}}}",
        ]

    def nested(i: int) -> list[str]:
        out = state_eval_tex(i)
        out.append(r"\ifSkillStateFits")
        out.extend("  " + x for x in apply_state_tex(i))
        if i + 1 < len(states):
            out.extend("  " + x for x in nested(i + 1))
        out.append(r"\fi")
        return out

    lines.extend(nested(0))
    lines.append("% ==== END AUTO-GENERATED SKILL FITTER ====")
    return "\n".join(lines)



def build_project_block(plan: dict[str, Any], master: dict[str, Any]) -> tuple[str, list[str], list[str]]:
    ranking = plan["ranking"]
    display = build_display_order(ranking, master)
    blocks: list[str] = []
    ordered_bullets: list[str] = []

    header_tech = resolved_project_header_tech(master, display, plan)

    for pos, pid in enumerate(display):
        pdata = master["projects"][pid]
        techs = header_tech[pid]

        title = latex_escape(project_title_text(master, pid))
        tech_text = ", ".join(latex_escape(x) for x in techs)
        date = latex_escape(pdata["date"])

        block = [
            fr"\noindent\textbf{{{title}}} $|$ {tech_text} \hfill \textit{{{date}}}",
            r"\begin{itemize}",
            r"  \setlength{\itemsep}{0pt}",
        ]
        bullets = plan["bullets"][pid]
        for bullet in bullets:
            text = bullet_text(bullet)
            ordered_bullets.append(text)
            block.append(fr"  \item {latex_escape(text)}")
        block.append(r"\end{itemize}")
        blocks.extend(block)
        if pos < len(display) - 1:
            blocks.append(r"\rolegap")
    return "\n".join(blocks), display, ordered_bullets

def replace_section_body(template: str, heading: str, body: str) -> str:
    start_marker = fr"\section*{{{heading}}}"
    start = template.index(start_marker)
    body_start = start + len(start_marker)
    if r"\sectiondivider" not in template[body_start:]:   # v3.4.9c run 2 P4: Skills is the last section
        end = template.index(r"\end{document}", body_start)
        return template[:body_start] + "\n" + body.rstrip() + "\n\t" + template[end:]
    end = template.index(r"\sectiondivider", body_start)
    return template[:body_start] + "\n" + body.rstrip() + "\n\t" + template[end:]


def assemble_latex(
    template: str,
    skill_selector_tex: str,
    project_block: str,
    tagline_text: str,
    rolegap_pt: float | None = None,
) -> str:
    tex = template
    tex, tagline_replacements = re.subn(
        r"\\textit\{Master's student[^{}]*\}",
        lambda _m: r"\textit{" + latex_escape(tagline_text) + "}",
        tex,
        count=1,
    )
    if tagline_replacements != 1:
        raise PipelineError("Could not replace canonical template tagline")
    if rolegap_pt is not None:
        tex = re.sub(
            r"\\newcommand\{\\rolegap\}\{\\vspace\{[^}]+\}\}",
            fr"\\newcommand{{\\rolegap}}{{\\vspace{{{rolegap_pt:g}pt}}}}",
            tex,
            count=1,
        )

    skills_body = r"""
\begin{itemize}
  \setlength{\itemsep}{0pt}
  \item \textbf{Languages \& Databases:} \FinalLanguagesDatabases
  \item \textbf{Frameworks \& Libraries:} \FinalFrameworksLibraries
  \ifx\FinalAiMl\empty\else\item \textbf{AI/ML:} \FinalAiMl\fi
  \item \textbf{Software Engineering:} \FinalSoftwareEngineering
  \item \textbf{Tools:} \FinalTools
\end{itemize}
""".strip()

    tex = replace_section_body(tex, "PERSONAL PROJECTS", project_block)
    tex = replace_section_body(tex, "TECHNICAL SKILLS", skills_body)

    # Hidden TeX measurement/selection code. It creates boxes only and ships
    # nothing to the PDF, so final resume is still compiled in one pdflatex run.
    begin = r"\begin{document}"
    tex = tex.replace(begin, begin + "\n\n" + skill_selector_tex + "\n", 1)
    return tex


def run_pdflatex(tex_path: Path, cwd: Path) -> tuple[int, str, float]:
    start = time.perf_counter()
    p = subprocess.run(
        ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", tex_path.name],
        cwd=cwd,
        capture_output=True,
        text=True,
    )
    elapsed = time.perf_counter() - start
    return p.returncode, (p.stdout or "") + "\n" + (p.stderr or ""), elapsed


def extract_pdf_lines(pdf: fitz.Document) -> list[dict[str, Any]]:
    all_lines: list[dict[str, Any]] = []
    for page_index, page in enumerate(pdf):
        for block in page.get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                spans = line.get("spans", [])
                if not spans:
                    continue
                text = "".join(s["text"] for s in spans).strip()
                if not text:
                    continue
                x0 = min(s["bbox"][0] for s in spans)
                y0 = min(s["bbox"][1] for s in spans)
                x1 = max(s["bbox"][2] for s in spans)
                y1 = max(s["bbox"][3] for s in spans)
                all_lines.append(
                    {
                        "page": page_index,
                        "text": text,
                        "bbox": [x0, y0, x1, y1],
                    }
                )
    all_lines.sort(key=lambda x: (x["page"], round(x["bbox"][1], 2), x["bbox"][0]))
    return all_lines


def find_line_index(lines: list[dict[str, Any]], needle: str, start: int = 0) -> int | None:
    for i in range(start, len(lines)):
        if needle in lines[i]["text"]:
            return i
    return None


def collect_project_bullets(
    pdf: fitz.Document,
    lines: list[dict[str, Any]],
    display_order: list[str],
    master: dict[str, Any],
) -> tuple[dict[str, list[list[dict[str, Any]]]], list[dict[str, Any]]]:
    failures = []
    result: dict[str, list[list[dict[str, Any]]]] = {}

    heading_indices = []
    for pid in display_order:
        title_meta = master["projects"][pid].get("resume_title", {})
        name = title_meta.get("name") or project_title_text(master, pid)
        idx = find_line_index(lines, name)
        if idx is None:
            failures.append(fail("project_heading_missing", pid, "not found in PDF", name, "Check LaTeX assembly/project heading text."))
        else:
            heading_indices.append((pid, idx))

    education_idx = find_line_index(lines, "EDUCATION")
    if len(heading_indices) != len(display_order) or education_idx is None:
        return result, failures

    # PyMuPDF can expose the itemize glyph as arbitrary characters (observed
    # as \x88), so detect first lines geometrically instead of by glyph.
    for k, (pid, idx) in enumerate(heading_indices):
        end = heading_indices[k + 1][1] if k + 1 < len(heading_indices) else education_idx
        segment = [x for x in lines[idx + 1:end] if x["text"].strip()]
        heading_x0 = lines[idx]["bbox"][0]
        indented = [x for x in segment if heading_x0 + 5.0 <= x["bbox"][0] <= heading_x0 + 100.0]
        if not indented:
            result[pid] = []
            continue

        # Continuation lines are the farther-right *dominant* indentation level.
        # Choose the most frequent x0 cluster, breaking ties toward the larger
        # indentation. This ignores wrapped header/date fragments that occur once.
        from collections import Counter
        rounded = [round(x["bbox"][0], 1) for x in indented]
        counts = Counter(rounded)
        max_count = max(counts.values())
        continuation_x0 = max(x for x, count in counts.items() if count == max_count)
        content_lines = [x for x in indented if x["bbox"][0] <= continuation_x0 + 2.0]
        bullets: list[list[dict[str, Any]]] = []
        current: list[dict[str, Any]] | None = None
        for line in content_lines:
            x0=line["bbox"][0]
            is_start=(x0 <= continuation_x0 - 5.0) and (x0 >= heading_x0 + 5.0)
            if is_start:
                if current:
                    bullets.append(current)
                current=[line]
            elif current is not None:
                current.append(line)
        if current:
            bullets.append(current)
        result[pid]=bullets
    return result, failures


def validate_pdf(
    pdf_path: Path,
    generated_tex: str,
    plan: dict[str, Any],
    master: dict[str, Any],
    display_order: list[str],
    ordered_bullets: list[str],
    warnings: list[dict[str, Any]] | None = None,
    bank_mode: bool = True,
    pdf: fitz.Document | None = None,
    lines: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    failures: list[dict[str, Any]] = []
    if pdf is None:
        pdf = fitz.open(pdf_path)
    if lines is None:
        lines = extract_pdf_lines(pdf)

    # Page count.
    expected_pages = master["layout_rules"]["resume_pages"]
    if len(pdf) != expected_pages:
        suggestion = "Reduce optional skills first."
        if master["layout_rules"]["rolegap_pt"] > master["layout_rules"]["rolegap_fallback_pt"]:
            suggestion += " If skills are already within budget, rerun with --rolegap 2."
        failures.append(
            fail(
                "page_count",
                "resume",
                len(pdf),
                expected_pages,
                suggestion,
            )
        )

    # Section order.
    section_names = master["layout_rules"]["section_order"]
    positions = []
    for section in section_names:
        idx = find_line_index(lines, section)
        positions.append(idx)
    if any(x is None for x in positions) or positions != sorted(x for x in positions if x is not None):
        failures.append(
            fail(
                "section_order",
                "resume",
                positions,
                section_names,
                "Restore the exact canonical section headings/order from master.json.",
            )
        )

    # Exact Experience source integrity.
    exp_tex = generated_tex.split(r"\section*{EXPERIENCE}", 1)[1].split(r"\sectiondivider", 1)[0]
    actual_exp = [normalize_fixed_text(x) for x in re.findall(r"\\item\s+(.+)", exp_tex)]
    canonical_exp = [
        normalize_fixed_text(b)
        for role in master["experience"]
        for b in role["bullets"]
    ]
    if actual_exp != canonical_exp:
        failures.append(
            fail(
                "experience_integrity",
                "EXPERIENCE",
                actual_exp,
                canonical_exp,
                "Do not repair with model text. Restore EXPERIENCE verbatim from the canonical template/master.",
            )
        )

    # Project count/allocation/order are deterministic from plan + assembly.
    ranking = plan["ranking"]
    expected_counts = {ranking[0]: 3, ranking[1]: 2, ranking[2]: 2}
    if len(display_order) != 3:
        failures.append(
            fail(
                "project_count",
                "PERSONAL PROJECTS",
                len(display_order),
                3,
                "Select exactly 3 active projects.",
            )
        )

    expected_display = build_display_order(ranking, master)
    if display_order != expected_display:
        failures.append(
            fail(
                "project_display_order",
                "PERSONAL PROJECTS",
                display_order,
                expected_display,
                "Display selected projects newest-first; same-month ties use relevance rank.",
            )
        )

    grouped, group_failures = collect_project_bullets(pdf, lines, display_order, master)
    failures.extend(group_failures)

    # Every project header (title + tech + date) must render on exactly one line.
    expected_heading_lines = master["layout_rules"].get("project_heading_rendered_lines_exact", 1)
    for pid in display_order:
        title_meta = master["projects"][pid].get("resume_title", {})
        name = title_meta.get("name") or project_title_text(master, pid)
        heading_idx = find_line_index(lines, name)
        groups = grouped.get(pid, [])
        if heading_idx is None or not groups or not groups[0]:
            continue
        first_bullet_line = groups[0][0]
        first_bullet_idx = next((i for i, line in enumerate(lines) if line is first_bullet_line), None)
        if first_bullet_idx is None:
            first_bullet_idx = next((i for i, line in enumerate(lines) if line == first_bullet_line), None)
        if first_bullet_idx is None:
            continue
        # PyMuPDF may split the left title/tech and right-aligned date into
        # separate line objects even when they share the same visual baseline.
        # Count distinct vertical baselines instead of raw text-line objects.
        header_objs = lines[heading_idx:first_bullet_idx]
        y_clusters: list[float] = []
        for obj in header_objs:
            y = float(obj["bbox"][1])
            if not any(abs(y - existing) <= 2.0 for existing in y_clusters):
                y_clusters.append(y)
        heading_lines = len(y_clusters)
        if heading_lines != expected_heading_lines:
            failures.append(
                fail(
                    "project_heading_line_count",
                    pid,
                    heading_lines,
                    expected_heading_lines,
                    "Shorten plan.project_tech for this project first so title + tech + date fit on one line; do not edit bank bullet prose.",
                )
            )

    right_margin_pt = master["layout_rules"]["margins_in"]["right"] * 72.0
    expected_bullet_lines = master["layout_rules"]["project_bullet_rendered_lines"]
    min_fill = master["layout_rules"]["project_second_line_min_fill"]

    for pid in display_order:
        actual_groups = grouped.get(pid, [])
        if len(actual_groups) != expected_counts[pid]:
            failures.append(
                fail(
                    "rendered_bullet_count",
                    pid,
                    len(actual_groups),
                    expected_counts[pid],
                    "Check project assembly and bullet parsing; preserve the 3/2/2 allocation.",
                )
            )
            continue
        for j, group in enumerate(actual_groups, 1):
            line_count = len(group)
            target = f"{pid}.bullet_{j}"
            if line_count != expected_bullet_lines:
                failures.append(
                    fail(
                        "project_bullet_line_count",
                        target,
                        line_count,
                        expected_bullet_lines,
                        "template/bank drift: rerun bank_check.py" if bank_mode else "Expand truthfully from the same evidence if 1 line; compress if 3+ lines.",
                    )
                )
                continue

            second = group[1]
            page = pdf[second["page"]]
            x0, _, x1, _ = second["bbox"]
            calibrated_available = page.rect.width - right_margin_pt - x0
            used = x1 - x0
            fill_ratio = used / calibrated_available if calibrated_available > 0 else 0.0
            if fill_ratio < min_fill:
                failures.append(
                    fail(
                        "project_bullet_second_line_fill",
                        target,
                        {
                            "fill_ratio": round(fill_ratio, 4),
                            "used_width_pt": round(used, 2),
                            "available_width_pt": round(calibrated_available, 2),
                        },
                        {"min_fill_ratio": min_fill},
                        "template/bank drift: rerun bank_check.py" if bank_mode else "Expand only this bullet using supported evidence from the same project.",
                    )
                )

            quality_floor = master.get("semantic_validation_rules", {}).get("quality_tail_floor")
            if quality_floor is not None and fill_ratio >= min_fill and fill_ratio < quality_floor and warnings is not None:
                warnings.append(
                    fail(
                        "project_bullet_tail_quality",
                        target,
                        {
                            "fill_ratio": round(fill_ratio, 4),
                            "used_width_pt": round(used, 2),
                            "available_width_pt": round(calibrated_available, 2),
                        },
                        {"quality_min_fill_ratio": quality_floor, "structural_min_fill_ratio": min_fill},
                        "Advisory only. In bank mode, improve/re-measure the bank offline; never pad the selected bullet.",
                    )
                )

    # Skills rendered line counts.
    skills_idx = find_line_index(lines, "TECHNICAL SKILLS")
    cert_idx = find_line_index(lines, "CERTIFICATIONS & AWARDS")
    if skills_idx is None or cert_idx is None:
        failures.append(
            fail(
                "skills_section_missing",
                "TECHNICAL SKILLS",
                [skills_idx, cert_idx],
                "Both TECHNICAL SKILLS and CERTIFICATIONS & AWARDS headings present",
                "Restore canonical section headings.",
            )
        )
    else:
        skill_lines = lines[skills_idx + 1 : cert_idx]
        # Filter divider artifacts if any (usually none in text extraction).
        skill_lines = [x for x in skill_lines if x["text"]]
        merged_rows: list[dict[str, Any]] = []
        for x in sorted(skill_lines, key=lambda r: ((r["bbox"][1] + r["bbox"][3]) / 2, r["bbox"][0])):
            yc = (x["bbox"][1] + x["bbox"][3]) / 2
            if merged_rows and abs(merged_rows[-1]["_yc"] - yc) < 3.0:
                merged_rows[-1]["text"] += " " + x["text"]
                merged_rows[-1]["bbox"][2] = max(merged_rows[-1]["bbox"][2], x["bbox"][2])
            else:
                merged_rows.append({**x, "bbox": list(x["bbox"]), "_yc": yc})
        skill_lines = merged_rows
        total_skill_lines = len(skill_lines)
        max_total = master["layout_rules"]["skills_rendered_lines_max"]
        if total_skill_lines > max_total:
            failures.append(
                fail(
                    "skills_line_count",
                    "TECHNICAL SKILLS",
                    total_skill_lines,
                    f"<= {max_total}",
                    "Remove lower-priority optional skills; do not remove protected baseline except the explicitly prunable neural-networks item.",
                )
            )

        # Tools is last skills item; count from Tools start through section boundary.
        tools_start = None
        for i, line in enumerate(skill_lines):
            if "Tools:" in line["text"]:
                tools_start = i
                break
        if tools_start is None:
            failures.append(
                fail(
                    "tools_line_count",
                    "Tools",
                    0,
                    1,
                    "Restore the Tools skill item.",
                )
            )
        else:
            tools_lines = len(skill_lines[tools_start:])
            if tools_lines != master["layout_rules"]["tools_rendered_lines_exact"]:
                failures.append(
                    fail(
                        "tools_line_count",
                        "Tools",
                        tools_lines,
                        1,
                        "Prune unmatched default Tools in the canonical prune order until Tools renders on exactly one line.",
                    )
                )

    # Unsupported scan over generated project bullets and rendered skill text.
    scan_texts = list(ordered_bullets)
    if skills_idx is not None and cert_idx is not None:
        scan_texts.extend(x["text"] for x in lines[skills_idx + 1 : cert_idx])
    hits = unsupported_hits(scan_texts, master)
    if hits:
        failures.append(
            fail(
                "unsupported_claim_or_skill",
                "generated_content",
                hits,
                [],
                "Remove unsupported terms. Related evidence must remain named as the supported skill/claim instead.",
            )
        )


    return failures


def parse_skill_log(log_text: str, states: list[dict[str, Any]], master: dict[str, Any]) -> tuple[int, int]:
    state_hits = [int(x) for x in re.findall(r"SKILLSTATEPASS:(\d+)", log_text)]
    if not state_hits:
        return -1, -1
    final_state = state_hits[-1]
    tool_hits = [
        (int(a), int(b))
        for a, b in re.findall(r"TOOLVARIANT:(\d+):(\d+)", log_text)
        if int(a) == final_state
    ]
    tool_variant = tool_hits[-1][1] if tool_hits else -1
    return final_state, tool_variant


def resolved_skill_payload(
    state_index: int,
    tool_variant_index: int,
    states: list[dict[str, Any]],
    master: dict[str, Any],
) -> dict[str, Any]:
    if state_index < 0:
        return {}
    state = deepcopy(states[state_index]["skills"])
    variants = tool_variants(
        state["tools"],
        set(states[state_index]["matched_tools"]),
        master["skills"]["tools_prune_order"],
    )
    if 0 <= tool_variant_index < len(variants):
        state["tools"] = variants[tool_variant_index]
    return {
        "accepted_optional_skills": states[state_index]["prefix"],
        "required_selected_technologies": states[state_index].get("required_technologies", []),
        "pruned_baseline_items": states[state_index].get("pruned_baseline_items", []),
        "skills": state,
        "tool_variant_index": tool_variant_index,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--template", required=True, type=Path)
    ap.add_argument("--master", required=True, type=Path)
    ap.add_argument("--plan", required=True, type=Path)
    ap.add_argument("--bank", type=Path, default=Path(__file__).with_name("bullet_bank.json"))
    ap.add_argument("--allow-free-text", action="store_true", help="Compatibility only: permit plan.bullets instead of bank_selection; prints a warning")
    ap.add_argument("--repair-pass", type=int, choices=[0, 1], default=0, help="At most one orchestration repair pass is permitted")
    ap.add_argument("--out-dir", required=True, type=Path)
    ap.add_argument("--rolegap", type=float, default=None, help="Override rolegap in pt; allowed fallback is 2.0")
    args = ap.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    report: dict[str, Any] = {
        "status": "FAIL",
        "failures": [],
        "warnings": [],
        "timestamps": {},
        "repair_pass": args.repair_pass,
    }
    total_start_perf = time.perf_counter()
    total_start_iso = now_iso()

    try:
        with StageTimer(report, "hash_check"):
            template_sha = sha256(args.template)
            master_sha = sha256(args.master)
            bank_sha = sha256(args.bank) if args.bank.exists() else None
            if template_sha != EXPECTED_TEMPLATE_SHA256:
                report["failures"].append(
                    fail(
                        "template_hash_mismatch",
                        str(args.template),
                        template_sha,
                        EXPECTED_TEMPLATE_SHA256,
                        "Use the exact canonical Resume_Template_CURRENT.tex or intentionally rebuild the pipeline constants.",
                    )
                )
                raise PipelineError("Template hash mismatch")
            if master_sha != EXPECTED_MASTER_JSON_SHA256:
                report["failures"].append(
                    fail(
                        "master_hash_mismatch",
                        str(args.master),
                        master_sha,
                        EXPECTED_MASTER_JSON_SHA256,
                        "Use the exact canonical master.json or intentionally rebuild the pipeline constants.",
                    )
                )
                raise PipelineError("master.json hash mismatch")

            if bank_sha != EXPECTED_BULLET_BANK_SHA256:
                report["failures"].append(
                    fail(
                        "bullet_bank_hash_mismatch",
                        str(args.bank),
                        bank_sha,
                        EXPECTED_BULLET_BANK_SHA256,
                        "Use the exact hash-locked bullet_bank.json or intentionally rebuild the v3 constants after bank_check.py passes.",
                    )
                )
                raise PipelineError("bullet_bank.json hash mismatch")

            master = json.loads(args.master.read_text(encoding="utf-8"))
            if master["source"]["template_sha256"] != template_sha:
                report["failures"].append(
                    fail(
                        "master_template_hash_mismatch",
                        "master.json.source.template_sha256",
                        master["source"]["template_sha256"],
                        template_sha,
                        "Regenerate master.json from the canonical synchronized source files.",
                    )
                )
                raise PipelineError("master.json does not point to this template")

        raw_plan = json.loads(args.plan.read_text(encoding="utf-8"))
        bank_mode = not args.allow_free_text

        with StageTimer(report, "bank_expand"):
            if bank_mode:
                if "bullets" in raw_plan:
                    report["failures"].append(
                        fail("free_text_rejected", "bullets", "present", "bank_selection only", "Remove free-text bullets; select ids from bullet_bank.json.")
                    )
                    raise PipelineError("Free-text bullets rejected in bank mode")
                bank = load_bullet_bank(args.bank)
                plan, bank_failures = expand_bank_plan(raw_plan, bank, master)
                report["failures"].extend(bank_failures)
                if bank_failures:
                    raise PipelineError("Bank expansion failed")
            else:
                print("WARNING: --allow-free-text enabled; bank mode is bypassed", file=sys.stderr)
                report["warnings"].append(
                    fail("free_text_compatibility_mode", "pipeline", True, False, "Use bank_selection for normal applications.")
                )
                if "bullets" not in raw_plan:
                    report["failures"].append(fail("free_text_missing", "bullets", "missing", "Free-text structured bullets", "Supply bullets or remove --allow-free-text."))
                    raise PipelineError("Free-text bullets missing")
                plan=deepcopy(raw_plan)

        with StageTimer(report, "plan_validation"):
            plan_failures = validate_plan(plan, master, warnings=report["warnings"], free_text_mode=not bank_mode)
            report["failures"].extend(plan_failures)
            if plan_failures:
                raise PipelineError("Plan validation failed")

        with StageTimer(report, "skill_plan_build"):
            states = build_skill_states(plan, master)
            skill_selector_tex = tex_skill_measurement_and_selection(states, master)

        with StageTimer(report, "latex_assembly"):
            template = args.template.read_text(encoding="utf-8")
            project_block, display_order, ordered_bullets = build_project_block(plan, master)
            tagline_id, tagline_text = resolve_tagline(plan, master)
            generated = assemble_latex(
                template,
                skill_selector_tex,
                project_block,
                tagline_text,
                rolegap_pt=args.rolegap,
            )
            tex_path = args.out_dir / "resume.tex"
            tex_path.write_text(generated, encoding="utf-8")

        with StageTimer(report, "pdflatex"):
            returncode, log_text, compile_elapsed = run_pdflatex(tex_path, args.out_dir)
            log_path = args.out_dir / "pdflatex.log.txt"
            log_path.write_text(log_text, encoding="utf-8")
            if returncode != 0:
                tail = "\n".join(log_text.splitlines()[-30:])
                report["failures"].append(
                    fail(
                        "pdflatex",
                        "resume.tex",
                        {"returncode": returncode, "log_tail": tail},
                        "returncode 0",
                        "Fix only the reported LaTeX assembly/escaping defect; do not alter fixed content.",
                    )
                )
                raise PipelineError("pdflatex failed")

        pdf_path = args.out_dir / "resume.pdf"
        if not pdf_path.exists():
            report["failures"].append(
                fail(
                    "pdf_missing",
                    "resume.pdf",
                    "missing",
                    "generated PDF",
                    "Inspect pdflatex output and file permissions.",
                )
            )
            raise PipelineError("PDF missing")

        with StageTimer(report, "pdf_validation"):
            final_state, tool_variant = parse_skill_log(log_text, states, master)
            if final_state < 0:
                report["failures"].append(
                    fail(
                        "skills_fit",
                        "TECHNICAL SKILLS",
                        "No baseline skill state fit",
                        "At least baseline state must fit category/7-line budgets",
                        "Canonical baseline/template are inconsistent; do not silently remove protected skills.",
                    )
                )
            pdf_failures = validate_pdf(
                pdf_path,
                generated,
                plan,
                master,
                display_order,
                ordered_bullets,
                warnings=report["warnings"],
                bank_mode=bank_mode,
            )
            report["failures"].extend(pdf_failures)
            if bank_mode and any(f.get("type") in {"project_bullet_line_count", "project_bullet_second_line_fill"} for f in pdf_failures):
                report["failures"].append(
                    fail(
                        "template_bank_drift",
                        "project_bullets",
                        "geometry mismatch with reviewed bank",
                        "bank_check.py passes against this template/master/pipeline",
                        "template/bank drift: rerun bank_check.py; do not edit bank bullet text during an application run",
                    )
                )

            resolved_skills = resolved_skill_payload(final_state, tool_variant, states, master)
            rendered_project_tech = resolved_project_header_tech(master, display_order, plan)
            ats_failures = validate_ats_coverage(
                plan,
                master,
                ordered_bullets,
                resolved_skills,
                rendered_project_tech,
            )
            report["failures"].extend(ats_failures)
            report["failures"].extend(
                validate_selected_technology_skill_coverage(
                    plan, master, resolved_skills, rendered_project_tech
                )
            )

        with StageTimer(report, "write_outputs"):
            resolved = {
                "ranking": plan["ranking"],
                "display_order": display_order,
                "bank_selection": raw_plan.get("bank_selection", {}) if bank_mode else None,
                "bullet_allocation": {
                    plan["ranking"][0]: 3,
                    plan["ranking"][1]: 2,
                    plan["ranking"][2]: 2,
                },
                "skill_resolution": resolved_skills,
                "tagline_id": tagline_id,
                "tagline_text": tagline_text,
                "cover_letter_paragraphs": plan.get("cover_letter_paragraphs", []),
                "project_tech": resolved_project_header_tech(master, display_order, plan),
            }
            (args.out_dir / "resolved_plan.json").write_text(
                json.dumps(resolved, indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )

            app = plan.get("application", {})
            applied_date = app.get("application_date") or datetime.now().date().isoformat()
            tracker_row = {
                "Company": app.get("company", ""),
                "Role": app.get("role", ""),
                "Date Applied": applied_date,
                "Career Status Portal": app.get("career_status_portal", ""),
                "Location": app.get("location", ""),
                "Visa / Sponsorship": app.get("visa_sponsorship", ""),
                "Projects Used": "; ".join(project_title_text(master, pid) for pid in display_order),
                "Fit (High/Medium/Low)": app.get("fit", ""),
                "Resume File Name": app.get("resume_file_name", ""),
                "Status": "Applied",
            }
            (args.out_dir / "tracker_row.json").write_text(
                json.dumps(tracker_row, indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )



        report["status"] = "PASS" if not report["failures"] else "FAIL"

    except (PipelineError, KeyError, ValueError, json.JSONDecodeError) as e:
        if not report["failures"]:
            report["failures"].append(
                fail(
                    "pipeline_exception",
                    "pipeline",
                    str(e),
                    "Successful deterministic run",
                    "Fix the specific input/schema/configuration error and rerun.",
                )
            )
        report["status"] = "FAIL"

    finally:
        report["timestamps"]["total"] = {
            "start": total_start_iso,
            "end": now_iso(),
            "duration_ms": round((time.perf_counter() - total_start_perf) * 1000, 3),
        }
        (args.out_dir / "report.json").write_text(
            json.dumps(report, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    return 0 if report["status"] == "PASS" else 2



# ==================== v3.1 OVERRIDES ====================
import unicodedata

SURFACE_PRIORITY = ["skills", "header", "bullet", "experience", "tagline", "education"]


def boundary_variants(term: str) -> list[str]:
    """Exact phrase plus a simple singular/plural variant on the final token."""
    term = str(term or "").strip()
    if not term:
        return []
    out = [term]
    m = re.match(r"^(.*?)([A-Za-z][A-Za-z0-9+#.-]*)([^A-Za-z0-9]*)$", term)
    if not m:
        return out
    prefix, last, suffix = m.groups()
    # Do not singularize all-caps acronyms such as CSS; accept REST API/APIs
    # and ordinary singular/plural forms only.
    if last.isupper() and last.lower().endswith("s"):
        return out
    if last.lower().endswith("s") and len(last) > 2:
        alt = last[:-1]
    else:
        alt = last + "s"
    v = prefix + alt + suffix
    if v.lower() != term.lower():
        out.append(v)
    return out


def boundary_contains_plural(text: str, term: str) -> bool:
    return any(boundary_contains(text, v) for v in boundary_variants(term))


def _prepare_runtime_cache(master: dict[str, Any]) -> dict[str, Any]:
    cache = master.setdefault("_runtime_cache", {})
    if "supported_skill_terms" not in cache:
        terms: list[str] = []
        for vals in master["skills"]["supported_pool"].values():
            for x in vals:
                if x not in terms:
                    terms.append(x)
        cache["supported_skill_terms"] = terms
        cache["supported_skill_map"] = {x.casefold(): x for x in terms}
    if "support_corpus" not in cache:
        corpus: list[str] = []
        for role in master["experience"]:
            corpus.extend(role["bullets"])
            corpus.append(role.get("evidence_anchors", ""))
        for pdata in master["projects"].values():
            corpus.extend(pdata.get("tech", []))
            corpus.extend(pdata.get("tags", []))
            for item in pdata.get("evidence_items", {}).values():
                corpus.append(item.get("text", ""))
                corpus.extend(item.get("terms", []))
                corpus.extend(item.get("claim_atoms", []))
        for values in master["skills"]["supported_pool"].values():
            corpus.extend(values)
        cache["support_corpus"] = tuple(str(x) for x in corpus if str(x))
    return cache


def all_supported_skill_terms(master: dict[str, Any]) -> list[str]:
    return list(_prepare_runtime_cache(master)["supported_skill_terms"])

def canonical_pool_match(value: str, master: dict[str, Any]) -> str | None:
    return _prepare_runtime_cache(master)["supported_skill_map"].get(str(value).casefold())

def safe_verbatim_alias_match(value: str, master: dict[str, Any]) -> str | None:
    amap = master.get("ats_rules", {}).get("ats_safe_verbatim_aliases", {})
    for alias, canonical in amap.items():
        if alias.casefold() == str(value).casefold():
            return canonical
    return None


def master_supports_requirement(term: str, aliases: list[str], master: dict[str, Any]) -> bool:
    needles = [str(term)] + [str(x) for x in aliases or []]
    corpus = _prepare_runtime_cache(master)["support_corpus"]
    return any(n and boundary_contains(item, n) for n in needles for item in corpus)

def education_visible_text(master: dict[str, Any]) -> str:
    edu = master.get("education", {})
    parts: list[str] = []
    if isinstance(edu, dict):
        for _, obj in edu.items():
            if isinstance(obj, dict):
                for v in obj.values():
                    if isinstance(v, list): parts.extend(map(str, v))
                    else: parts.append(str(v))
            else:
                parts.append(str(obj))
    elif isinstance(edu, list):
        parts.extend(map(str, edu))
    return "\n".join(parts)


def represented_requirement_canonicals(plan: dict[str, Any], master: dict[str, Any]) -> set[str]:
    represented: set[str] = set()
    for req in plan.get("jd_requirements", []):
        if not isinstance(req, dict):
            continue
        for x in [req.get("term", ""), req.get("verbatim", "")] + list(req.get("aliases", [])):
            if not x: continue
            canonical = normalize_skill_name(str(x), master)
            pool = canonical_pool_match(canonical, master)
            if pool: represented.add(pool.casefold())
    return represented


def jd_omission_warnings(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[dict[str, Any]]:
    represented = represented_requirement_canonicals(plan, master)
    warnings: list[dict[str, Any]] = []
    for item in all_supported_skill_terms(master):
        if item.casefold() in represented:
            continue
        if boundary_contains(raw_jd, item):
            warnings.append(fail(
                "jd_supported_skill_term_omitted",
                item,
                "Present in raw JD but absent from jd_requirements",
                "Include important supported JD terms within the capped jd_requirements set",
                "Planning warning only; do not auto-add or invent requirements.",
            ))
    return warnings


def _experience_months_from_master(master: dict[str, Any]) -> int:
    months = {"january":1,"february":2,"march":3,"april":4,"may":5,"june":6,"july":7,"august":8,"september":9,"october":10,"november":11,"december":12}
    total = 0
    for role in master.get("experience", []):
        text = str(role.get("dates", ""))
        m = re.match(r"\s*([A-Za-z]+)\s+(\d{4})\s*--\s*([A-Za-z]+)\s+(\d{4})\s*$", text)
        if not m: continue
        sm, sy, em, ey = m.groups()
        if sm.lower() not in months or em.lower() not in months: continue
        start = int(sy)*12 + months[sm.lower()]
        end = int(ey)*12 + months[em.lower()]
        total += max(0, end-start+1)
    return total


def hard_gaps(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    out=[]; exp_months=_experience_months_from_master(master)
    for req in plan.get("jd_requirements", []):
        if not isinstance(req, dict) or req.get("supported") is not False: continue
        term=str(req.get("term","")).strip(); verbatim=str(req.get("verbatim",term)).strip(); priority=str(req.get("priority","")).strip().lower(); lower=verbatim.lower()
        years_req=bool(re.search(r"\b\d+\s*(?:to|-|–|—)?\s*\d*\s*\+?\s*years?\b", lower)) and "experience" in lower
        explicit_required=bool(re.search(r"\brequired\b|\bmust\s+have\b", lower))
        status="partial" if years_req and exp_months >= 12 else "unsupported"
        if priority in {"must", "high"} or explicit_required or status=="partial":
            out.append({"term":term,"verbatim":verbatim,"priority":priority,"status":status,"reason":(f"Candidate record shows {exp_months // 12}+ year(s) of professional experience, but not the full stated role-specific threshold." if status=="partial" else "Requirement is marked unsupported by the canonical evidence.")})
    return out


def lowered_fit(fit: str, gaps: list[dict[str, Any]]) -> str:
    value=str(fit or "").strip().capitalize()
    rank={"Low":0,"Medium":1,"High":2}
    if any(gap.get("status")=="unsupported" and re.search(r"\brequired\b|\bmust\s+have\b",str(gap.get("verbatim", "")),re.IGNORECASE) for gap in gaps):
        cap="Low"
    elif any(gap.get("status")=="partial" or (gap.get("status")=="unsupported" and str(gap.get("priority", "")).lower() in {"must","high"}) for gap in gaps):
        cap="Medium"
    else:
        return value
    return min((value,cap),key=lambda item:rank.get(item,0))


def _is_data_ml_role(plan: dict[str, Any]) -> bool:
    role=str(plan.get("application",{}).get("role","")).lower(); themes={str(x).lower() for x in plan.get("jd_themes",[])}
    return bool(re.search(r"\b(data scientist|data science|machine learning|ml engineer|ai engineer|analytics)\b",role) or themes & {"ml","machine_learning","model_evaluation","analytics","data_science","data_engineering"})


def validate_data_ml_cover_paragraph_2(plan: dict[str, Any]) -> list[dict[str, Any]]:
    if not _is_data_ml_role(plan): return []
    cover=plan.get("cover_letter_paragraphs",[])
    if not isinstance(cover,list) or len(cover)<2: return []
    p2=" ".join(str(x) for x in cover).lower()
    go_digital=("go digital" in p2 and "etl" in p2 and "anomaly" in p2)
    heinonline=("heinonline" in p2 and ("extraction" in p2 or "metadata" in p2) and ("benchmark" in p2 or "ground truth" in p2 or "91%" in p2 or "90.81" in p2))
    thesis_iot=bool(plan.get("_v345_sensor_line")) and "thesis mumbai tech" in p2 and "iot" in p2   # v3.4.5 (item 11): sensor / IoT / device postings
    if go_digital or heinonline or thesis_iot: return []
    return [fail("data_ml_cover_paragraph_2_experience","cover_letter_paragraphs[1]",cover[1],"Reference Go Digital ETL + anomaly reports OR the HeinOnline extraction benchmark","For data/ML roles, paragraph 2 must anchor to one fixed Experience item; projects may be mentioned additionally.")]


def _validate_plan_v3_1_base(
    plan: dict[str, Any], master: dict[str, Any], raw_jd: str,
    warnings: list[dict[str, Any]] | None = None,
    free_text_mode: bool = False,
) -> list[dict[str, Any]]:
    failures = validate_plan(plan, master, warnings=warnings, free_text_mode=free_text_mode)
    reqs = plan.get("jd_requirements", [])
    ats = master.get("ats_rules", {})
    max_reqs = int(ats.get("jd_requirements_max", 12))
    if isinstance(reqs, list):
        if len(reqs) > max_reqs:
            failures.append(fail("jd_requirements_too_many", "jd_requirements", len(reqs), f"<= {max_reqs}", "Keep must/high first; include at most 3 medium; omit low."))
        priorities=[]
        medium_count=0
        seen_medium=False
        for i, req in enumerate(reqs, 1):
            if not isinstance(req, dict): continue
            if "verbatim" not in req or not str(req.get("verbatim", "")).strip():
                failures.append(fail("jd_requirement_schema", f"jd_requirements[{i}]", "missing verbatim", "term, verbatim, aliases, priority, supported", "Copy verbatim exactly from the raw JD."))
                continue
            priority=str(req.get("priority", "")).lower()
            priorities.append(priority)
            if priority not in ats.get("allowed_priorities", ["must","high","medium"]):
                failures.append(fail("jd_requirement_priority", f"jd_requirements[{i}]", priority, ats.get("allowed_priorities"), "Use must/high/medium only; omit low."))
            if priority == "medium":
                medium_count += 1; seen_medium=True
            elif priority in {"must","high"} and seen_medium:
                failures.append(fail("jd_requirement_order", f"jd_requirements[{i}]", priority, "All must/high entries before medium entries", "Reorder requirements; this is plan construction, not a repair pass."))
            verbatim=str(req.get("verbatim", ""))
            if verbatim and verbatim not in raw_jd:
                failures.append(fail("jd_verbatim_not_in_raw_jd", f"jd_requirements[{i}].verbatim", verbatim, "Exact literal text copied from the JD file", "Copy the requirement spelling/casing exactly from the raw JD."))
        if medium_count > int(ats.get("medium_requirements_max", 3)):
            failures.append(fail("jd_medium_requirements_too_many", "jd_requirements", medium_count, f"<= {ats.get('medium_requirements_max',3)}", "Keep at most three medium requirements."))
    app=plan.get("application", {})
    lane=app.get("lane", master.get("tracking",{}).get("lane_default","Speed"))
    if lane not in master.get("tracking",{}).get("lane_values", ["Speed","Referral"]):
        failures.append(fail("application_lane", "application.lane", lane, master.get("tracking",{}).get("lane_values"), "Use Speed or Referral."))
    cover=plan.get("cover_letter_paragraphs", [])
    exact=int(master.get("application_speed_rules",{}).get("cover_letter_paragraphs_exact",2))
    if not isinstance(cover,list) or len(cover)!=exact or not all(isinstance(x,str) and x.strip() for x in cover):
        failures.append(fail("cover_letter_paragraph_count", "cover_letter_paragraphs", len(cover) if isinstance(cover,list) else type(cover).__name__, exact, "Use exactly two short paragraphs from the same plan data."))
    failures.extend(validate_data_ml_cover_paragraph_2(plan))
    if warnings is not None:
        warnings.extend(jd_omission_warnings(plan, master, raw_jd))
    return failures


def required_ats_skill_displays(plan: dict[str, Any], master: dict[str, Any]) -> list[str]:
    """Mandatory skill-surface candidates for supported must requirements.
    Preserve a safe JD verbatim alias when possible so the exact word appears.
    """
    out: list[str] = []
    seen: set[str] = set()
    for req in plan.get("jd_requirements", []):
        if not isinstance(req, dict) or str(req.get("priority","")).lower() != "must":
            continue
        term=str(req.get("term", "")); aliases=[str(x) for x in req.get("aliases", [])]
        if not master_supports_requirement(term, aliases, master):
            continue
        verbatim=str(req.get("verbatim", "")).strip()
        display=None
        canonical=canonical_pool_match(verbatim, master)
        if canonical:
            display=canonical if canonical.casefold()==verbatim.casefold() else verbatim
        else:
            safe=safe_verbatim_alias_match(verbatim, master)
            if safe:
                display=verbatim
            else:
                candidates=[term]+aliases
                for c in candidates:
                    normalized=normalize_skill_name(c, master)
                    canonical=canonical_pool_match(normalized, master)
                    if canonical:
                        display=canonical; break
        if display and supported_skill_category(display, master):
            key=display.casefold()
            if key not in seen:
                out.append(display); seen.add(key)
    return out


def _build_skill_states_v3_1(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    baseline=deepcopy(master["skills"]["baseline"])
    states: list[dict[str, Any]]=[]
    header_tech=resolved_project_header_tech(master, plan["ranking"], plan)
    required_ats=required_ats_skill_displays(plan, master)
    required_techs=selected_technology_skills(plan, master, header_tech)

    # Required ATS display forms win over canonical technology duplicates.
    occupied={normalize_skill_name(x, master).casefold() for x in required_ats}
    required_techs=[x for x in required_techs if normalize_skill_name(x,master).casefold() not in occupied]

    pruned_baseline_items=[]
    baseline_flat={normalize_skill_name(x,master).casefold() for values in baseline.values() for x in values}
    if any(normalize_skill_name(skill,master).casefold() not in baseline_flat for skill in required_ats+required_techs):
        prunable=master["skills"].get("only_prunable_baseline_item")
        if prunable:
            for cat,values in baseline.items():
                if prunable in values:
                    baseline[cat]=[x for x in values if x!=prunable]; pruned_baseline_items.append(prunable); break

    optionals=[]
    mandatory_norm={normalize_skill_name(x,master).casefold() for x in required_ats+required_techs}
    for s in plan.get("optional_skills", []):
        n=normalize_skill_name(s, master)
        if n.casefold() not in mandatory_norm and n not in optionals:
            optionals.append(n)

    def add_skill(state, skill, matched_tools, allow_same_canonical=False):
        cat=supported_skill_category(skill, master)
        if cat is None: return
        canon=normalize_skill_name(skill,master).casefold()
        if skill in state[cat]:
            if cat=="tools": matched_tools.add(skill)
            return
        # Required JD verbatim aliases may need two distinct display forms that
        # normalize to the same canonical skill (e.g. HTML and CSS -> HTML/CSS).
        if not allow_same_canonical and any(normalize_skill_name(x,master).casefold()==canon for x in state[cat]):
            if cat=="tools":
                for x in state[cat]:
                    if normalize_skill_name(x,master).casefold()==canon: matched_tools.add(x)
            return
        state[cat].append(skill)
        if cat=="tools": matched_tools.add(skill)

    def make_state(prefix):
        state=deepcopy(baseline); matched_tools=set()
        # protect baseline tools that satisfy a mandatory requirement
        for skill in required_ats:
            cat=supported_skill_category(skill,master)
            if cat=="tools":
                canon=normalize_skill_name(skill,master).casefold()
                for x in state["tools"]:
                    if normalize_skill_name(x,master).casefold()==canon: matched_tools.add(x)
            add_skill(state, skill, matched_tools, allow_same_canonical=True)
        for skill in required_techs: add_skill(state, skill, matched_tools)
        for skill in prefix:
            if supported_skill_category(skill,master)=="tools" and skill in baseline["tools"]:
                matched_tools.add(skill)
            add_skill(state, skill, matched_tools)
        return {
            "skills":state,
            "matched_tools":sorted(matched_tools),
            "prefix":list(prefix),
            "required_ats_terms":list(required_ats),
            "required_technologies":list(required_techs),
            "pruned_baseline_items":list(pruned_baseline_items),
        }
    states.append(make_state([]))
    for i in range(1,len(optionals)+1): states.append(make_state(optionals[:i]))
    return states


def resolved_skill_payload(state_index:int, tool_variant_index:int, states:list[dict[str,Any]], master:dict[str,Any]) -> dict[str,Any]:
    if state_index<0: return {}
    state=deepcopy(states[state_index]["skills"])
    variants=tool_variants(state["tools"], set(states[state_index]["matched_tools"]), master["skills"]["tools_prune_order"])
    if 0<=tool_variant_index<len(variants): state["tools"]=variants[tool_variant_index]
    return {
        "accepted_optional_skills":states[state_index]["prefix"],
        "required_ats_terms":states[state_index].get("required_ats_terms",[]),
        "required_selected_technologies":states[state_index].get("required_technologies",[]),
        "pruned_baseline_items":states[state_index].get("pruned_baseline_items",[]),
        "skills":state,
        "tool_variant_index":tool_variant_index,
    }



def skills_text_hash(states: list[dict[str, Any]], master: dict[str, Any]) -> str:
    payload = {
        "states": [
            {"skills": st.get("skills", {}), "matched_tools": st.get("matched_tools", []), "prefix": st.get("prefix", [])}
            for st in states
        ],
        "category_limits": master["layout_rules"]["skills_category_line_limits"],
        "total_limit": master["layout_rules"]["skills_rendered_lines_max"],
        "tools_prune_order": master["skills"]["tools_prune_order"],
        "template_sha256": v349b_template_sha() if v348b_on() else V348B_OLD_TEMPLATE_SHA256,   # v3.4.8b: flag off keys the cache as v3.4.8a did; v3.4.9b: format_letter_v349b off keys it as v3.4.9a did
    }
    raw = json.dumps(payload, sort_keys=True, ensure_ascii=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _skill_fit_cache_path() -> Path:
    return Path(__file__).with_name(".resume_skill_fit_cache.json")


def load_skill_fit_cache() -> dict[str, Any]:
    path = _skill_fit_cache_path()
    try:
        if path.exists():
            obj = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(obj, dict):
                return obj
    except Exception:
        pass
    return {}


def save_skill_fit_cache(cache: dict[str, Any]) -> None:
    try:
        _skill_fit_cache_path().write_text(json.dumps(cache, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    except Exception:
        pass


def tex_cached_skill_selection(state_index: int, tool_variant_index: int, states: list[dict[str, Any]], master: dict[str, Any]) -> str:
    payload = resolved_skill_payload(state_index, tool_variant_index, states, master)
    if not payload:
        return tex_skill_measurement_and_selection(states, master)
    skills = payload["skills"]
    macros = {
        "FinalLanguagesDatabases": skills["languages_databases"],
        "FinalFrameworksLibraries": skills["frameworks_libraries"],
        "FinalAiMl": skills["ai_ml"],
        "FinalSoftwareEngineering": skills["software_engineering"],
        "FinalTools": skills["tools"],
    }
    lines = ["% ==== CACHED SKILL FIT ===="]
    for macro, values in macros.items():
        lines.append(fr"\def\{macro}{{{', '.join(latex_escape(x) for x in values)}}}")
    lines.append(fr"\typeout{{SKILLSTATEPASS:{state_index}}}")
    lines.append(fr"\typeout{{TOOLVARIANT:{state_index}:{tool_variant_index}}}")
    lines.append("% ==== END CACHED SKILL FIT ====")
    return "\n".join(lines)

def build_project_block(plan:dict[str,Any], master:dict[str,Any]) -> tuple[str,list[str],list[str]]:
    ranking=plan["ranking"]; display=build_display_order(ranking, master); blocks=[]; ordered=[]
    if v348c_f2_active(plan):   # v3.4.8c F2: headings come from the page before the Fleet re-pick
        with _v347c_pre_swap(plan):
            header_tech=resolved_project_header_tech(master, display, plan)
            if _v347_on("heading_tech_fix"):
                header_tech=_v347_heading_placement({k: list(v) for k, v in header_tech.items()}, master, display, plan)
    else:
        header_tech=resolved_project_header_tech(master, display, plan)
    if _v347_on("heading_tech_fix") and not v348c_f2_active(plan):   # v3.4.7a A2: the rendered heading only; Skills and page checks keep the full set
        header_tech=_v347_heading_placement({k: list(v) for k, v in header_tech.items()}, master, display, plan)
    for pos,pid in enumerate(display):
        pdata=master["projects"][pid]; techs=header_tech[pid]
        title=latex_escape(project_title_text(master,pid)); url=str(pdata.get("github","") or "").strip()
        tech_text=", ".join(latex_escape(x) for x in techs); date=latex_escape(pdata["date"])
        link_text=fr" $|$ \href{{{url}}}{{\underline{{GitHub}}}}" if url else ""
        block=[fr"\noindent\textbf{{{title}}} $|$ {tech_text}{link_text} \hfill \textit{{{date}}}", r"\begin{itemize}", r"  \setlength{\itemsep}{0pt}"]
        for bullet in plan["bullets"][pid]:
            text=bullet_text(bullet); ordered.append(text); block.append(fr"  \item {latex_escape(text)}")
        block.append(r"\end{itemize}"); blocks.extend(block)
        if pos<len(display)-1: blocks.append(r"\rolegap")
    return "\n".join(blocks),display,ordered

def surface_texts(master, ordered_bullets, resolved_skills, project_tech, tagline_text):
    surfaces={k:[] for k in SURFACE_PRIORITY}
    for vals in resolved_skills.get("skills",{}).values(): surfaces["skills"].extend(map(str,vals))
    for pid,vals in project_tech.items():
        surfaces["header"].append(project_title_text(master,pid)); surfaces["header"].extend(map(str,vals))
    surfaces["bullet"].extend(ordered_bullets)
    for role in master["experience"]: surfaces["experience"].extend(role["bullets"])
    surfaces["tagline"].append(tagline_text)
    surfaces["education"].append(education_visible_text(master))
    return surfaces


def matches_in_surfaces(surfaces, needles, plural=False):
    hits=[]
    for surf in SURFACE_PRIORITY:
        txt="\n".join(surfaces.get(surf,[]))
        fn=boundary_contains_plural if plural else boundary_contains
        if any(fn(txt,n) for n in needles if n): hits.append(surf)
    return hits


def validate_ats_coverage(plan, master, ordered_bullets, resolved_skills, project_tech, tagline_text, warnings=None):
    failures=[]; coverage=[]; surfaces=surface_texts(master,ordered_bullets,resolved_skills,project_tech,tagline_text)
    checked=set(master.get("ats_rules",{}).get("jd_requirement_priorities_checked",["must","high"]))
    for req in plan.get("jd_requirements",[]):
        if not isinstance(req,dict): continue
        term=str(req.get("term","")).strip(); verbatim=str(req.get("verbatim","")).strip(); aliases=[str(x) for x in req.get("aliases",[])]
        priority=str(req.get("priority","medium")).lower(); declared=bool(req.get("supported",False)); actual=master_supports_requirement(term,aliases,master)
        if declared!=actual:
            failures.append(fail("jd_support_classification_mismatch",term,declared,actual,"Align the requirement's supported flag with canonical evidence."))
        if not actual:
            coverage.append({"term":term,"verbatim":verbatim,"priority":priority,"supported":False,"status":"gap (unsupported)","surface":None})
            continue
        quals={q.casefold() for q in master.get("qualification_facts",[])}
        if any(x.casefold() in quals for x in [term]+aliases):
            coverage.append({"term":term,"verbatim":verbatim,"priority":priority,"supported":True,"status":"qualification (education/experience)","surface":"education/experience"})
            continue
        alias_needles=[verbatim,term]+aliases
        alias_hits=matches_in_surfaces(surfaces,alias_needles,plural=True)
        verbatim_hits=matches_in_surfaces(surfaces,[verbatim],plural=True) if verbatim else []
        enforceable=bool(canonical_pool_match(verbatim,master) or safe_verbatim_alias_match(verbatim,master))
        status="covered" if verbatim_hits else ("alias only" if alias_hits else "missing")
        hitlist=verbatim_hits if verbatim_hits else alias_hits
        entry={"term":term,"verbatim":verbatim,"priority":priority,"supported":True,"status":status,"surface":hitlist[0] if hitlist else None}
        if len(hitlist)>1: entry["also_in"]=hitlist[1:]
        if _v347_on("heading_move_v348"):   # v3.4.8c J: "header" only when a rendered heading shows the term
            v348c_header_also_in(entry, [verbatim] if verbatim_hits else alias_needles, master)
        alts=[str(x) for x in req.get("alternatives",[]) if str(x)]
        if len(alts)>1:
            # OR list: one visible member satisfies it, but say which alternatives the page does not show
            entry["alternatives_shown"]=[x for x in alts if matches_in_surfaces(surfaces,[x],plural=True)]
            entry["alternatives_not_shown"]=[x for x in alts if x not in entry["alternatives_shown"]]
        coverage.append(entry)
        if priority in checked and not alias_hits:
            failures.append(fail("ats_priority_term_missing",term,{"priority":priority,"aliases":aliases},"Supported must/high JD term appears on a validated ATS surface","Add the supported term through Skills/header or choose evidence that already contains it."))
        if priority=="must" and not verbatim_hits:
            if enforceable:
                failures.append(fail("ats_required_verbatim_missing",term,{"verbatim":verbatim,"aliases":aliases},"Supported must requirement appears verbatim (singular/plural equivalent accepted)","Prefer the exact JD form in Skills; never add an unsupported term."))
            elif alias_hits and warnings is not None:
                warnings.append(fail("ats_required_verbatim_alias_only",term,{"verbatim":verbatim,"surface":alias_hits[0]},"Exact JD form is not safe to claim; supported canonical/alias coverage is present","Warning only: keep truthful canonical wording."))
    return failures, coverage


def make_application_key(company:str, role:str) -> str:
    raw=f"{company}_{role}"
    asc=unicodedata.normalize("NFKD",raw).encode("ascii","ignore").decode("ascii")
    asc=re.sub(r"[^A-Za-z0-9]+","_",asc)
    return re.sub(r"_+","_",asc).strip("_")


def output_names(plan:dict[str,Any]) -> dict[str,str]:
    app=plan.get("application",{}); key=make_application_key(str(app.get("company","")),str(app.get("role","")))
    return {"key":key,"resume_pdf":"build_resume.pdf","resume_tex":"build_resume.tex","resume_tex_clean":f"{key}.tex","cover_txt":f"{key}_Cover_Letter.txt","cover_pdf":f"{key}_Cover_Letter.pdf"}


def validate_project_links(pdf_path:Path, display_order:list[str], master:dict[str,Any], pdf:fitz.Document|None=None):
    own_pdf = pdf is None
    if pdf is None:
        pdf=fitz.open(pdf_path)
    uris=[]
    for page in pdf:
        for link in page.get_links():
            uri=link.get("uri")
            if uri: uris.append(uri)
    per={}; failures=[]; expected=0; present=0
    for pid in display_order:
        url=str(master["projects"][pid].get("github","") or "").strip()
        if not url:
            per[pid]={"url":"","present":False,"expected":False}
            continue
        expected += 1
        ok=url in uris; present += int(ok)
        per[pid]={"url":url,"present":ok,"expected":True}
        if not ok:
            failures.append(fail("project_link_annotation_missing",pid,uris,url,"Keep the project title hyperlinked and verify hyperref annotations in the compiled PDF."))
    if own_pdf:
        pdf.close()
    return failures,{"count":present,"expected":expected,"projects":per}

def extract_pdftotext(pdf_path:Path) -> str:
    p=subprocess.run(["pdftotext",str(pdf_path),"-"],capture_output=True)
    return p.stdout.decode("utf-8",errors="replace")


def parse_pdf_warnings_from_text(text:str, master:dict[str,Any]):
    warnings=[]
    expected=master["layout_rules"]["section_order"]
    positions=[text.find(x) for x in expected]
    if any(x<0 for x in positions) or positions!=sorted(positions):
        warnings.append(fail("parse_section_order", "PDF text", positions, expected, "Warning only: verify extraction order."))
    email=str(master.get("contact",{}).get("email","")); phone=str(master.get("contact",{}).get("phone",""))
    if email and email not in text: warnings.append(fail("parse_email_missing","PDF text",False,email,"Warning only: inspect PDF text extraction."))
    if phone and phone not in text: warnings.append(fail("parse_phone_missing","PDF text",False,phone,"Warning only: inspect PDF text extraction."))
    badchars=[]
    for ch in text:
        cat=unicodedata.category(ch)
        if (cat in {"Cc","Co"} and ch not in "\n\r\t\f"):
            badchars.append(f"U+{ord(ch):04X}")
    if badchars: warnings.append(fail("parse_private_or_control_characters","PDF text",sorted(set(badchars)),[],"Warning only: inspect encoding/bullet extraction."))
    ligs=[ch for ch in text if "\ufb00"<=ch<="\ufb06"]
    artifacts=[]
    if "\ufffd" in text: artifacts.append("U+FFFD replacement character")
    if ligs: artifacts.append("ligature codepoints: "+", ".join(sorted({f"U+{ord(c):04X}" for c in ligs})))
    if any(x in text for x in ["Ã", "Â", "â€”", "â€“", "â€™"]): artifacts.append("possible mojibake")
    if artifacts: warnings.append(fail("parse_ligature_or_encoding_issue","PDF text",artifacts,[],"Warning only: inspect extracted text."))
    return warnings


def parse_pdf_warnings(pdf_path:Path, master:dict[str,Any]):
    text=extract_pdftotext(pdf_path)
    return parse_pdf_warnings_from_text(text,master),text

def _build_outreach_v3_1(plan:dict[str,Any], master:dict[str,Any], display_order:list[str]):
    app=plan.get("application",{}); company=str(app.get("company","")); role=str(app.get("role","")); top=project_title_text(master,plan["ranking"][0])
    titles=["Technical Recruiter / Talent Acquisition Partner", f"{role} Hiring Manager / Team Lead", f"Relevant Engineer on the hiring team or University at Buffalo alumnus at {company}"]
    msg=(f"Hi, I’m Jay Niketan Pathare, a master's student in Computer Science at the University at Buffalo applying for the {role} role at {company}. "
         f"My background includes production healthcare software and the {top} project. "
         "Would you be open to a 10-minute chat so I can get your advice on the team and what you look for in candidates?")
    return {"contact_titles":titles,"message":msg,"sentence_count":len([x for x in re.split(r"(?<=[.!?])\s+",msg.strip()) if x]),"word_count":len(msg.split())}


def eligibility_blockers(plan:dict[str,Any], master:dict[str,Any]) -> list[dict[str,str]]:
    profile=master.get("candidate_eligibility",{})
    us_citizen=profile.get("us_citizen")
    needs_future_sponsorship=profile.get("requires_future_employer_sponsorship")
    clearance=str(profile.get("security_clearance","unknown")).lower()
    blockers=[]; seen=set()
    def add(kind, requirement, reason):
        key=kind
        if key not in seen:
            blockers.append({"type":kind,"requirement":requirement,"reason":reason}); seen.add(key)
    texts=[]
    for req in plan.get("jd_requirements",[]):
        if isinstance(req,dict):
            v=str(req.get("verbatim") or req.get("term") or "").strip()
            if v: texts.append(v)
    visa_note=str(plan.get("application",{}).get("visa_sponsorship","")).strip()
    if visa_note: texts.append(visa_note)
    for requirement in texts:
        low=requirement.casefold()
        if us_citizen is False and any(x in low for x in ["u.s. citizenship","us citizenship","u.s. citizen","us citizen"]):
            add("citizenship",requirement,"Candidate is not a U.S. citizen.")
        if needs_future_sponsorship is True and (sponsorship_denied(low) or any(x in low for x in ["no sponsorship","without sponsorship","will not sponsor","does not sponsor","cannot sponsor","not sponsor","unrestricted work authorization","permanent work authorization"])):
            add("work_authorization_or_sponsorship",requirement,"Candidate plans to use F-1 OPT and requires future employer sponsorship.")
        if clearance in {"none","no active clearance"} and "clearance" in low and any(x in low for x in ["active","current","must possess","required"]):
            add("clearance",requirement,"An active security clearance is required but none is recorded for the candidate.")
    return blockers

def main_v3_1() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--template",required=True,type=Path); ap.add_argument("--master",required=True,type=Path); ap.add_argument("--plan",required=True,type=Path)
    ap.add_argument("--jd",required=True,type=Path,help="Raw JD text file used to verify verbatim requirement extraction")
    ap.add_argument("--bank",type=Path,default=Path(__file__).with_name("bullet_bank.json")); ap.add_argument("--allow-free-text",action="store_true")
    ap.add_argument("--repair-pass",type=int,choices=[0,1],default=0); ap.add_argument("--out-dir",required=True,type=Path); ap.add_argument("--rolegap",type=float,default=None)
    ap.add_argument("--experience-variants-test",action="store_true",help="v3.4.2 test mode: run the Experience variant selector although master.experience_variants_enabled is false")
    args=ap.parse_args(); args.out_dir.mkdir(parents=True,exist_ok=True)
    report={"status":"FAIL","failures":[],"warnings":[],"timestamps":{},"repair_pass":args.repair_pass,"ats_coverage":[],"project_links":{},"pdflatex_calls":[],"compile_strategy":{},"eligibility_blockers":[]}
    total_start_perf=time.perf_counter(); total_start_iso=now_iso()
    try:
        with StageTimer(report,"hash_check"):
            template_sha=sha256(args.template); master_sha=sha256(args.master); bank_sha=sha256(args.bank)
            for typ,target,measured,expected,msg in [
                ("template_hash_mismatch","Resume_Template_CURRENT.tex",template_sha,EXPECTED_TEMPLATE_SHA256,"Use the canonical template."),
                ("master_hash_mismatch","master.json",master_sha,EXPECTED_MASTER_JSON_SHA256,"Use the canonical v3.2 master.json."),
                ("bullet_bank_hash_mismatch","bullet_bank.json",bank_sha,EXPECTED_BULLET_BANK_SHA256,"Use the hash-locked bullet bank; do not edit bank prose."),
            ]:
                if measured!=expected:
                    report["failures"].append(fail(typ,target,measured,expected,msg)); raise PipelineError(typ)
            master=json.loads(args.master.read_text(encoding="utf-8"))
            _prepare_runtime_cache(master)
            if master["source"]["template_sha256"]!=template_sha: raise PipelineError("master template pointer mismatch")
            raw_jd=clean_jd_text(args.jd.read_text(encoding="utf-8"))
        raw_plan=json.loads(args.plan.read_text(encoding="utf-8")); bank_mode=not args.allow_free_text
        raw_plan["_jd_fingerprint"]=jd_fingerprint(raw_jd)
        with StageTimer(report,"ranking_check"):
            apply_auto_plan_fields(raw_plan, master, raw_jd)
            apply_auto_ranking(raw_plan, master, raw_jd)
            ranking_failures=validate_ranking_consistency(raw_plan); report["failures"].extend(ranking_failures)
            if ranking_failures: raise PipelineError("Ranking/project_scores mismatch")
            _bl,_gate=early_skip_check(raw_plan,master,raw_jd)
            if _gate["skip_reasons"] and not raw_plan.get("application",{}).get("force"):
                fill_skip_report(report,raw_plan,master,_bl,_gate); raise EarlySkip()
        with StageTimer(report,"bank_expand"):
            if bank_mode:
                if "bullets" in raw_plan: raise PipelineError("Free-text bullets rejected in bank mode")
                plan,bank_failures=expand_bank_plan(raw_plan,load_bullet_bank(args.bank),master); report["failures"].extend(bank_failures)
                if bank_failures: raise PipelineError("Bank expansion failed")
            else:
                report["warnings"].append(fail("free_text_compatibility_mode","pipeline",True,False,"Use bank_selection for normal applications.")); plan=deepcopy(raw_plan)
        with StageTimer(report,"plan_validation"):
            pf=validate_plan_v3_1(plan,master,raw_jd,warnings=report["warnings"],free_text_mode=not bank_mode); report["failures"].extend(pf)
            if pf: raise PipelineError("Plan validation failed")
        with StageTimer(report,"skill_plan_build"):
            states=build_skill_states(plan,master)
            skill_hash=skills_text_hash(states,master)
            skill_cache=load_skill_fit_cache()
            cached_fit=skill_cache.get(skill_hash)
            cache_hit=False
            if isinstance(cached_fit,dict):
                si=int(cached_fit.get("state",-1)); ti=int(cached_fit.get("tool_variant",-1))
                if 0 <= si < len(states):
                    skill_selector_tex=tex_cached_skill_selection(si,ti,states,master); cache_hit=True
            if not cache_hit:
                skill_selector_tex=tex_skill_measurement_and_selection(states,master)
            report["skill_fit_cache"]={"skills_text_hash":skill_hash,"hit":cache_hit}
        with StageTimer(report,"latex_assembly"):
            template_text=args.template.read_text(encoding="utf-8"); project_block,display_order,ordered_bullets=build_project_block(plan,master); tagline_id,tagline_text=resolve_tagline(plan,master)
            generated=assemble_latex(template_text,skill_selector_tex,project_block,tagline_text,rolegap_pt=args.rolegap)
            exp_template=template_text
            if master.get("experience_variants_enabled") or args.experience_variants_test:
                plan["_v342_exp_variants_test"]=bool(args.experience_variants_test)
                generated,exp_template,report["experience_variants"]=experience_variants_stage(plan,master,template_text,generated)
            names=output_names(plan); tex_path=args.out_dir/names["resume_tex"]; tex_path.write_text(generated,encoding="utf-8")
            report["failures"].extend(experience_byte_check(exp_template,generated))
        with StageTimer(report,"pdflatex"):
            rc,log_text,compile_elapsed=run_pdflatex(tex_path,args.out_dir); (args.out_dir/'pdflatex.log.txt').write_text(log_text,encoding='utf-8')
            report["pdflatex_calls"].append({"purpose":"final_compile","duration_ms":round(compile_elapsed*1000,3)})
            report["compile_strategy"]={"skills_fitter_compiles":0,"line_fitting_compiles":0,"final_compiles":1,"total_pdflatex_calls":1,"skill_fit_method":"compile-time TeX measurement inside the final compile; cached by skills_text_hash when previously seen"}
            if rc!=0: report["failures"].append(fail("pdflatex",tex_path.name,rc,0,"Fix only the named assembly defect.")); raise PipelineError("pdflatex failed")
        pdf_path=args.out_dir/names["resume_pdf"]
        if not pdf_path.exists(): raise PipelineError(f"Expected PDF missing: {names['resume_pdf']}")
        with StageTimer(report,"pdf_inspection"):
            final_state,tool_variant=parse_skill_log(log_text,states,master)
            if final_state<0:
                required=states[0].get("required_ats_terms",[]) if states else []
                report["failures"].append(fail("required_ats_terms_exceed_skill_budget","TECHNICAL SKILLS",required,{"skills_max_lines":master['layout_rules']['skills_rendered_lines_max'],"tools_lines":1},"Required ATS terms plus protected/selected-project skills do not fit; name the terms rather than dropping them."))
                resolved_skills={}
            else:
                resolved_skills=resolved_skill_payload(final_state,tool_variant,states,master)
                if not report.get("skill_fit_cache",{}).get("hit"):
                    skill_cache[skill_hash]={"state":final_state,"tool_variant":tool_variant}
                    save_skill_fit_cache(skill_cache)
            with fitz.open(pdf_path) as pdf_doc:
                pdf_lines=extract_pdf_lines(pdf_doc)
                pdf_failures=validate_pdf(pdf_path,generated,plan,master,display_order,ordered_bullets,warnings=report["warnings"],bank_mode=bank_mode,pdf=pdf_doc,lines=pdf_lines); report["failures"].extend(pdf_failures)
                if bank_mode and any(f.get("type") in {"project_bullet_line_count","project_bullet_second_line_fill"} for f in pdf_failures):
                    report["failures"].append(fail("template_bank_drift","project_bullets","geometry mismatch","bank_check.py passes","template/bank drift: rerun bank_check.py"))
                rendered_project_tech=resolved_project_header_tech(master,display_order,plan)
                if resolved_skills:
                    ats_fail,coverage=validate_ats_coverage(plan,master,ordered_bullets,resolved_skills,rendered_project_tech,tagline_text,warnings=report["warnings"]); report["failures"].extend(ats_fail); report["ats_coverage"]=coverage
                    report["failures"].extend(validate_selected_technology_skill_coverage(plan,master,resolved_skills,rendered_project_tech))
                link_fail,link_report=validate_project_links(pdf_path,display_order,master,pdf=pdf_doc); report["failures"].extend(link_fail); report["project_links"]=link_report
            parsed_text=extract_pdftotext(pdf_path)
            report["warnings"].extend(parse_pdf_warnings_from_text(parsed_text,master))
        with StageTimer(report,"write_outputs"):
            if resolved_skills:
                (args.out_dir/names["resume_tex_clean"]).write_text(clean_resume_tex(generated,resolved_skills),encoding="utf-8")
            app=plan.get("application",{}); applied_date=app.get("application_date") or datetime.now().date().isoformat(); lane=app.get("lane") or master.get("tracking",{}).get("lane_default","Speed")
            tracker_row={
                "Company":app.get("company",""),"Role":app.get("role",""),"Date Applied":applied_date,"Career Status Portal":app.get("career_status_portal",""),"Location":app.get("location",""),"Visa / Sponsorship":app.get("visa_sponsorship",""),
                "Projects Used":"; ".join(project_title_text(master,pid) for pid in display_order),"Fit (High/Medium/Low)":app.get("fit",""),"Resume File Name":names["key"],"Status":"Applied","Source":app.get("source","") or "","Lane":lane,"Outcome Date":"",
            }
            outreach=build_outreach(plan,master,display_order)
            blockers=eligibility_blockers(plan,master); report["eligibility_blockers"]=blockers
            gaps=hard_gaps(plan,master); report["hard_gaps"]=gaps
            effective_fit=lowered_fit(app.get("fit",""),gaps)
            gate=gating_assessment(plan,master,blockers)
            if gate["fit_cap"]: effective_fit=min((effective_fit,gate["fit_cap"]),key=lambda x:{"Low":0,"Medium":1,"High":2}.get(x,0))
            report["effective_fit"]=effective_fit
            have={b.get("type") for b in blockers}
            blockers.extend({"type":x["type"],"requirement":x["reason"],"reason":x["reason"]} for x in gate["skip_reasons"] if x["type"] not in have and x["type"] in ("seniority_gap","seniority_title","primary_stack_gap"))
            report["eligibility_blockers"]=blockers
            tracker_row["Blockers"]=blockers_summary(blockers)
            report["notes"]=[f"{b.get('type')}: {b.get('reason','')}" for b in blockers]
            report["skip"]=bool(gate["skip_reasons"]); report["skip_reasons"]=gate["skip_reasons"]; report["forced"]=bool(app.get("force")) and report["skip"]
            for w in gate["warnings"]: report["warnings"].append(fail(w["type"],"gating",w["reason"],"","Check the posting before applying."))
            tracker_row["Fit (High/Medium/Low)"]=effective_fit
            resolved={"project_scores":raw_plan.get("project_scores",{}),"ranking":plan["ranking"],"ranking_override_reason":raw_plan.get("ranking_override_reason",""),"display_order":display_order,"bank_selection":plan.get("bank_selection",{}) if bank_mode else None,"bank_selection_auto":plan.get("_bank_selection_auto"),"skill_resolution":resolved_skills,"tagline_id":tagline_id,"tagline_text":tagline_text,"cover_letter_paragraphs":plan.get("cover_letter_paragraphs",[]),"project_tech":resolved_project_header_tech(master,display_order,plan),"filenames":names,"ats_coverage":report["ats_coverage"],"project_links":report["project_links"],"eligibility_blockers":blockers,"hard_gaps":gaps,"effective_fit":effective_fit}
            (args.out_dir/'resolved_plan.json').write_text(json.dumps(resolved,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
            (args.out_dir/'tracker_row.json').write_text(json.dumps(tracker_row,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
            (args.out_dir/'outreach.json').write_text(json.dumps(outreach,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
            (args.out_dir/'hard_gaps.json').write_text(json.dumps(gaps,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
            (args.out_dir/'filenames.json').write_text(json.dumps(names,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
            report["tracker_row"]=tracker_row; report["outreach"]=outreach; report["filenames"]=names
            visible=" | ".join([*(x for v in (resolved_skills or {}).get("skills",{}).values() for x in v), *ordered_bullets, *(x for v in resolved_project_header_tech(master,display_order,plan).values() for x in v), *(b for r in master["experience"] for b in r["bullets"])])
            pool_terms=plan.get("_jd_pool_terms",[]); pool_missing=[x for x in pool_terms if not boundary_contains_plural(visible,x)]
            sup=[c for c in report.get("ats_coverage",[]) if c.get("supported")]; sup_ok=[c for c in sup if c.get("status") in ("covered","alias only") or str(c.get("status","")).startswith("qualification")]
            exact=[c for c in sup if c.get("status")=="covered" or str(c.get("status","")).startswith("qualification")]; alias_only=[c["term"] for c in sup if c.get("status")=="alias only"]
            report["ats_summary"]={"supported_requirements_visible":f"{len(sup_ok)}/{len(sup)}","exact_jd_wording_visible":f"{len(exact)}/{len(sup)}","alias_only":alias_only,"missing":[c["term"] for c in sup if c.get("status")=="missing"],"or_alternatives_not_shown":[x for c in sup for x in c.get("alternatives_not_shown",[])],
                                   "unsupported_gaps":[c["term"] for c in report.get("ats_coverage",[]) if not c.get("supported")],"requirements_parsed":len(report.get("ats_coverage",[])),
                                   "jd_named_skills_visible":f"{len(pool_terms)-len(pool_missing)}/{len(pool_terms)}","jd_named_skills_missing":pool_missing}
            if len(report.get("ats_coverage",[]))<8:
                report["warnings"].append(fail("ats_thin_parse","jd_requirements",len(report.get("ats_coverage",[])),">= 8 parsed requirements","Few requirements were read from this JD, so the coverage number says little. Check the JD text, or add missed requirements with jd_requirements_extra."))
            musts=[r for r in plan.get("jd_requirements",[]) if isinstance(r,dict) and str(r.get("priority","")).lower()=="must"]
            sup_musts=[r for r in musts if master_supports_requirement(str(r.get("term","")),[str(a) for a in r.get("aliases",[])],master)]
            report["role_mismatch"]=non_software_role(str(app.get("role","")),str(plan.get("_raw_jd_text","")))
            report["jd_gap_terms_detected"]=plan.get("_jd_gap_terms",[]); report["jd_pool_terms_detected"]=plan.get("_jd_pool_terms",[]); report["cover_letter_mode"]=plan.get("_cover_letter_mode","free")
            report["plan_resolved_fields"]={"role_family":raw_plan.get("role_family"),"role_family_auto":bool(raw_plan.get("_role_family_auto")),"tagline_id":raw_plan.get("tagline_id"),"jd_themes":raw_plan.get("jd_themes"),"fit_input":app.get("fit",""),"jd_requirements_auto":bool(raw_plan.get("_jd_requirements_auto")),"jd_requirements_extra_rejected":raw_plan.get("_extra_rejected",[]),"jd_requirements_trimmed":raw_plan.get("_trimmed_requirements",[]),"jd_requirements_extra_already_covered":raw_plan.get("_extra_already_covered",[]),"jd_domain":raw_plan.get("_jd_domain"),"jd_requirements":[{k:r.get(k) for k in ("term","priority","supported","required_section","verbatim","aliases","alternatives") if k in r} for r in raw_plan.get("jd_requirements",[]) if isinstance(r,dict)]}
            (args.out_dir/'plan_resolved_fields.json').write_text(json.dumps(report["plan_resolved_fields"],indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        with StageTimer(report,"cover_letter"):
            cl_fail,cl_info=build_cover_letter(plan,master,args.out_dir,names)
            report["failures"].extend(cl_fail); report["cover_letter"]=cl_info
            report["failures"].extend(final_output_scan(args.out_dir,names,outreach))
            if report.get("skip") and not report.get("forced"): apply_skip(args.out_dir,report)
            else: write_judge_packet(args.out_dir,plan,master,raw_jd,names,report)
        report["status"]="PASS" if not report["failures"] else "FAIL"
    except EarlySkip:
        report["status"]="PASS"
        globals()["write_skip_file"](args.out_dir,report)
    except (PipelineError,KeyError,ValueError,json.JSONDecodeError) as e:
        if not report["failures"]: report["failures"].append(fail("pipeline_exception","pipeline",str(e),"Successful deterministic run","Fix the specific input/schema/configuration error and rerun."))
        report["status"]="FAIL"
    finally:
        report["timestamps"]["total"]={"start":total_start_iso,"end":now_iso(),"duration_ms":round((time.perf_counter()-total_start_perf)*1000,3)}
        (args.out_dir/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    return 0 if report["status"]=="PASS" else 2







































































































# ---------------------------------------------------------------------------
# v3.2 layer: role families, compact AI/ML skills line, cover-letter rules,
# deterministic cover-letter DOCX/PDF, family-aware outreach.
# ---------------------------------------------------------------------------

YEAR_RE = re.compile(r"^(19|20)\d\d$")


def role_family_profile(plan: dict[str, Any], master: dict[str, Any]) -> dict[str, Any] | None:
    fam = str(plan.get("role_family", ""))
    profile = master.get("role_families", {}).get(fam)
    return profile if isinstance(profile, dict) and not fam.startswith("_") else None



_SPONSOR_NEG = re.compile(r"\b(?:not|never|n't|unable to|cannot|can ?not|won't|no longer)\b")
_SPONSOR_DENY = re.compile(
    r"h-?1b|visa categor|\bno (?:visa |immigration |employer )?sponsorship|without (?:visa |immigration |employer )?sponsorship|"
    r"(?:not|n't|never|unable to|cannot|can ?not|won't|will not)\s+(?:be able to\s+)?(?:offer|provide|sponsor|support|consider|extend|file|pursue|assist with|entertain|accept)\b[^.]{0,50}?(?:sponsor|visa|work authori|immigration|petition|employment-based|work permit)|"
    r"(?:sponsorship|visa|immigration)[^.]{0,60}?(?:will not|won't|not) be (?:considered|provided|offered|available|supported)|"
    r"(?:sponsorship|visa|immigration|work authorization)[^.]{0,30}(?:is|are) (?:not|unavailable)|"
    r"unrestricted[^.]{0,40}authori|(?:permanent|independent)[^.]{0,40}(?:work )?authori|"
    r"authorized to work[^.]{0,80}without[^.]{0,20}sponsor|not eligible for[^.]{0,20}sponsorship|"
    r"(?:will|do|does|can) not (?:offer|provide|sponsor)", re.I)


_NONSW_TITLE = re.compile(r"\b(sales|account (?:manager|executive)|recruiter|nurse|accountant|marketing (?:manager|specialist|coordinator)|driver|teacher|store manager|cashier|customer service|paralegal|attorney|physician|therapist|electrician|mechanic|warehouse|bookkeeper|merchandis)", re.I)
_SW_WORDS = re.compile(r"\b(engineer|developer|programmer|software|devops|sre|machine learning|ml|data (?:scientist|engineer|analyst)|full[- ]?stack|backend|frontend|web)\b", re.I)


def non_software_role(role: str, raw_jd: str) -> bool:
    if re.search(r"\bnot (?:a|an) (?:software|engineering|technical|developer)[a-z ]{0,20}role\b", raw_jd or "", re.I):
        return True
    return bool(_NONSW_TITLE.search(role or "")) and not _SW_WORDS.search(role or "")


def clean_jd_text(text: str) -> str:
    """Decode HTML entities and remove markdown/job-board noise so the parser sees the words a person reads."""
    import html as _html
    s = str(text)
    for _ in range(2):
        s = _html.unescape(s)
    s = re.sub(r"\*\*|__", "", s)
    s = re.sub(r"\[([^\]]*)\]\((?:https?://)?[^)\s]*\)", r"\1", s)
    s = s.replace("\u00a0", " ").replace("\u200b", "")
    keep = []
    for ln in s.split("\n"):
        if re.search(r"keywords? matched|improve my match|\bfair match\b|\bgood match\b|submit resume|almost there", ln, re.I) and len(ln) < 200:
            continue
        keep.append(re.sub(r"[ \t]+", " ", ln))
    return "\n".join(keep)


_PRIMARY_UNSUPPORTED = {"typescript", "node.js", "nodejs", "node", "c#", "c++", ".net", "php", "ruby", "rust", "swift", "kotlin", "scala", "angular", "vue", "graphql", "perl"}
_SENIOR_TITLE = re.compile(r"\b(senior|sr\.?|staff|principal|lead|director|architect|distinguished|head of|engineering manager)\b|\b(?:engineer|developer|swe)\s+(?:iii|iv|v|3|4)\b|\b(?:iii|iv)\b", re.I)


def jd_min_years(raw_jd: str) -> tuple[int, str]:
    """Smallest N from a stated 'N+ years ... experience' in a non-optional sentence, wherever it sits in the posting."""
    best = (0, "")
    for s in re.split(r"(?<=[.!?])\s+|\n", re.sub(r"\bU\.S\.", "US", str(raw_jd))):
        low = s.casefold()
        if re.search(r"\b(preferred|a plus|nice to have|bonus|ideally|desired|helpful)\b", low):
            continue
        m = re.search(r"(\d+)\s*\+?\s*(?:-|–|to)?\s*(\d+)?\s*\+?\s*years?(?:\s+of)?(?:\s+[\w/&-]+){0,6}?\s+(?:experience|work|background)", low) or \
            re.search(r"experience[^.;]{0,40}?(\d+)\s*\+?\s*(?:-|–|to)?\s*(\d+)?\s*\+?\s*years?", low)
        if not m or int(m.group(1)) < 3 or int(m.group(1)) > 15:
            continue
        if re.search(r"master|m\.s\.|graduate degree|advanced degree|ph\.?d", low):
            continue  # degree substitutes for years in that sentence
        n = int(m.group(1))
        if best[0] == 0 or n < best[0]:
            best = (n, s.strip()[:140])
    return best


_FOREIGN_LOC = re.compile(r"\b(india|bangalore|bengaluru|chennai|hyderabad|pune|mumbai|gurgaon|gurugram|noida|delhi|kolkata|canada|toronto|vancouver|montreal|ontario|united kingdom|\buk\b|london|dublin|ireland|germany|berlin|munich|france|paris|netherlands|amsterdam|singapore|australia|sydney|melbourne|japan|tokyo|israel|tel aviv|brazil|mexico|poland|warsaw|romania|china|beijing|shanghai|philippines|manila|dubai|uae)\b", re.I)
_US_LOC = re.compile(r"\b(united states|u\.s\.a?\.?|usa|remote \(us|remote - us|us remote|remote, us)\b|\b(?:alabama|alaska|arizona|arkansas|california|colorado|connecticut|delaware|florida|georgia|hawaii|idaho|illinois|indiana|iowa|kansas|kentucky|louisiana|maine|maryland|massachusetts|michigan|minnesota|mississippi|missouri|montana|nebraska|nevada|new hampshire|new jersey|new mexico|new york|north carolina|north dakota|ohio|oklahoma|oregon|pennsylvania|rhode island|south carolina|south dakota|tennessee|texas|utah|vermont|virginia|washington|west virginia|wisconsin|wyoming)\b", re.I)
_US_ABBR = re.compile(r",\s*(?:AL|AK|AZ|AR|CA|CO|CT|DE|DC|FL|GA|HI|ID|IL|IN|IA|KS|KY|LA|ME|MD|MA|MI|MN|MS|MO|MT|NE|NV|NH|NJ|NM|NY|NC|ND|OH|OK|OR|PA|RI|SC|SD|TN|TX|UT|VT|VA|WA|WV|WI|WY)\b")


def location_outside_us(raw_jd: str, location: str) -> bool:
    """True when every place named at the top of the posting (and in the plan) is outside the United States."""
    head = "\n".join(str(raw_jd).split("\n")[:30]) + "\n" + str(location or "")
    return bool(_FOREIGN_LOC.search(head)) and not _US_LOC.search(head) and not _US_ABBR.search(head)


_PRIMARY_RX = {"TypeScript": r"typescript", "Node.js": r"node(?:\.js|js)?", "C#": r"c#", "C++": r"c\+\+", ".NET": r"\.net", "PHP": r"php", "Ruby": r"ruby", "Rust": r"rust", "Swift": r"swift",
               "Kotlin": r"kotlin", "Scala": r"scala", "Angular": r"angular", "GraphQL": r"graphql", "Perl": r"perl"}


def raw_primary_stack_gaps(raw_jd: str, master: dict[str, Any]) -> list[str]:
    """Technologies outside Jay's evidence that run through the posting (3+ lines that are not OR/example lists)."""
    found = []
    lines = str(raw_jd).split("\n")
    for name, rx in _PRIMARY_RX.items():
        if master_supports_requirement(name, [], master):
            continue
        n = sum(1 for ln in lines if re.search(r"(?<![\w.#+])" + rx + r"(?![\w#+])", ln, re.I) and not re.search(r"\b(or|such as|e\.g\.|including|similar|equivalent)\b", ln, re.I))
        if n >= 3:
            found.append(name)
    return found


def grad_window_warning(raw_jd: str) -> str:
    """A posting that lists explicit graduation months, none of which is early 2027 (Jay's degree is conferred February 2027).
    v3.4.8b: Jay graduates in December 2026; the window check is v348b_grad_window (flag graduation_dec2026_v348)."""
    if v348b_on():
        return v348b_grad_window(raw_jd)
    mon = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6, "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12}
    for s in re.split(r"(?<=[.!?])\s+|\n", str(raw_jd)):
        if not re.search(r"graduat|class of|conferr", s, re.I):
            continue
        if re.search(r"\b(winter|spring|summer|fall|autumn)\b", s, re.I) or re.search(r"\b(through|between|from|until|before)\b", s, re.I):
            continue
        toks = []
        for m in re.finditer(r"((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*(?:\s*/\s*(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*)*)\s+(20\d\d)", s, re.I):
            for part in re.split(r"\s*/\s*", m.group(1)):
                toks.append((mon[part[:3].lower()], int(m.group(2))))
        if len(toks) >= 2 and not any(y == 2027 and mo <= 3 for mo, y in toks):
            return s.strip()[:140]
    return ""


def gating_assessment(plan: dict[str, Any], master: dict[str, Any], blockers: list[dict[str, str]]) -> dict[str, Any]:
    """Decide before a package is handed over: skip reasons (blocking unless forced), warnings, and a Fit cap."""
    app = plan.get("application", {}); role = str(app.get("role", ""))
    reqs = [r for r in plan.get("jd_requirements", []) if isinstance(r, dict)]
    raw = str(plan.get("_raw_jd_text", ""))
    reasons, warnings, cap = [], [], None
    for b in blockers:
        if b.get("type") in ("work_authorization_or_sponsorship", "citizenship", "clearance"):
            reasons.append({"type": b["type"], "reason": b.get("requirement", "")[:140]})
    for r in reqs:
        m = re.match(r"(\d+)\+ years of experience", str(r.get("term", "")))
        if m and r.get("supported") is False and (r.get("required_section") or str(r.get("priority", "")).lower() == "must"):
            n = int(m.group(1))
            if n >= 3:
                reasons.append({"type": "seniority_gap", "reason": f"requires {n}+ years of professional experience; likely screened out"})
            else:
                warnings.append({"type": "experience_years", "reason": f"asks {n}+ years of experience"})
            break
    if location_outside_us(raw, app.get("location", "")):
        reasons.append({"type": "location_outside_us", "reason": "every location in the posting is outside the United States"})
    n_text, n_line = jd_min_years(raw)
    if n_text == 0:
        m2 = re.search(r"(?<!\d)([12])\s*\+?\s*(?:-|–|to)?\s*\d?\s*\+?\s*years?(?:\s+of)?(?:\s+[\w/&-]+){0,6}?\s+(?:experience|work|background)", raw.casefold())
        if m2 and not re.search(r"preferred|a plus|nice to have", raw[max(0, m2.start() - 80):m2.end() + 40], re.I):
            warnings.append({"type": "experience_years", "reason": f"asks {m2.group(1)}+ years of experience; Jay has about one year of professional experience"})
    gw = grad_window_warning(raw)
    if gw:
        warnings.append({"type": "graduation_window", "reason": f"lists graduation dates that do not include February 2027: \"{gw}\""})
    if n_text >= 3 and not any(x["type"] == "seniority_gap" for x in reasons):
        reasons.append({"type": "seniority_gap", "reason": f"requires {n_text}+ years of professional experience: \"{n_line}\""})
    if _SENIOR_TITLE.search(re.sub(r"member of technical staff|technical staff", "", role, flags=re.I)):
        reasons.append({"type": "seniority_title", "reason": f"senior-level title: {role}"})
    elif re.search(r"\bfounding\b", role, re.I):
        warnings.append({"type": "founding_role", "reason": "founding role: ownership expectations are high"}); cap = "Medium"
    musts = [r for r in reqs if str(r.get("priority", "")).lower() == "must"][:3]
    low_role = role.casefold()
    for r in reqs:
        term = str(r.get("term", "")); key = term.casefold()
        if key not in _PRIMARY_UNSUPPORTED or r.get("supported") is not False:
            continue
        alts = [a for a in r.get("alternatives", []) if master_supports_requirement(str(a), [], master)]
        if alts:
            continue
        first = any(x is r for x in musts)
        mentions = len(re.findall(r"(?<![\w])" + re.escape(term) + r"(?![\w])", raw, re.I)) if raw else 0
        if first or key in low_role or mentions >= 3:
            reasons.append({"type": "primary_stack_gap", "reason": f"the main stack asks for {term}, which is not in your evidence"})
            break
    if not any(x["type"] == "primary_stack_gap" for x in reasons):
        rp_gaps = raw_primary_stack_gaps(raw, master)
        if rp_gaps:
            reasons.append({"type": "primary_stack_gap", "reason": f"the posting is built around {', '.join(rp_gaps)}, which is not in your evidence"})
    if non_software_role(role, raw):
        reasons.append({"type": "role_mismatch", "reason": "not a software role"})
    reasons = [x for i, x in enumerate(reasons) if x["type"] not in {y["type"] for y in reasons[:i]}]
    fit_cap = "Low" if any(x["type"] in ("seniority_gap", "primary_stack_gap", "seniority_title") for x in reasons) else cap
    return {"skip_reasons": reasons, "warnings": warnings, "fit_cap": fit_cap}


class EarlySkip(Exception):
    pass


def fill_skip_report(report: dict[str, Any], raw_plan: dict[str, Any], master: dict[str, Any], blockers, gate) -> None:
    app = raw_plan.get("application", {})
    try:
        gaps = hard_gaps(raw_plan, master)
    except Exception:
        gaps = []
    fit = lowered_fit(app.get("fit", ""), gaps) if str(app.get("fit", "")).capitalize() in ("High", "Medium", "Low") else "Medium"
    if gate["fit_cap"]:
        fit = "Low" if gate["fit_cap"] == "Low" else fit
    have = {b.get("type") for b in blockers}
    blockers = list(blockers) + [{"type": x["type"], "requirement": x["reason"], "reason": x["reason"]} for x in gate["skip_reasons"] if x["type"] not in have and x["type"] in ("seniority_gap", "seniority_title", "primary_stack_gap")]
    reqs = [r for r in raw_plan.get("jd_requirements", []) if isinstance(r, dict)]
    report.update({"eligibility_blockers": blockers, "hard_gaps": gaps, "effective_fit": fit, "skip": True, "skip_reasons": gate["skip_reasons"], "forced": False,
                   "package_withheld": True, "role_mismatch": non_software_role(str(app.get("role", "")), str(raw_plan.get("_raw_jd_text", ""))),
                   "ats_summary": {"unsupported_gaps": [r["term"] for r in reqs if r.get("supported") is False], "requirements_parsed": len(reqs)},
                   "jd_gap_terms_detected": raw_plan.get("_jd_gap_terms", [])})
    for w in gate["warnings"]:
        report["warnings"].append(fail(w["type"], "gating", w["reason"], "", "Check the posting before applying."))



def early_skip_check(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str):
    """Runs right after the requirements are read: a posting that must be skipped never reaches the heavy stages."""
    raw_plan["_raw_jd_text"] = raw_jd
    blockers = eligibility_blockers(raw_plan, master)
    gate = gating_assessment(raw_plan, master, blockers)
    return blockers, gate


def apply_skip(out_dir, report: dict[str, Any]) -> None:
    """A skipped posting keeps only the reasons: no resume, letter, tracker row or outreach is handed over."""
    import pathlib as _pl
    for p in _pl.Path(out_dir).iterdir():
        if p.is_file() and p.name not in ("report.json", "plan_resolved_fields.json", "resolved_plan.json"):
            p.unlink()
    for k in ("tracker_row", "outreach", "cover_letter", "filenames"):
        report.pop(k, None)
    report["package_withheld"] = True
    (_pl.Path(out_dir) / "SKIP.txt").write_text("SKIP: " + "; ".join(f"{x['type']}: {x['reason']}" for x in report.get("skip_reasons", [])) + "\n", encoding="utf-8")


def sponsorship_denied(text: str) -> bool:
    low = re.sub(r"\bu\.s\.", "us", " ".join(str(text).split()), flags=re.I)
    if not _SPONSOR_DENY.search(low):
        return False
    # an H-1B or visa mention alone is not a denial when the sentence offers sponsorship
    hard = re.search(r"\bno (?:visa |immigration |employer )?sponsorship|without (?:visa |immigration |employer )?sponsorship|unrestricted|permanent|independent|authorized to work|not eligible", low, re.I)
    if not hard and re.search(r"\b(?:will|can|do|does|may|able to|happy to)\s+(?:also\s+)?(?:sponsor|provide|offer|support)\b|sponsorship (?:is )?(?:available|provided|offered)|(?:visa )?sponsorship available", low, re.I) and not _SPONSOR_NEG.search(low):
        return False
    return True


def validate_role_family(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    families = [k for k in master.get("role_families", {}) if not k.startswith("_")]
    profile = role_family_profile(plan, master)
    if profile is None:
        return [fail("role_family_missing", "role_family", plan.get("role_family"), families,
                     "Set plan.role_family to the closest family for this JD.")]
    failures = []
    override = str(plan.get("ranking_override_reason", "")).strip()
    avoided = [pid for pid in plan.get("ranking", []) if pid in profile.get("avoid_projects", [])]
    if avoided and not override:
        failures.append(fail("role_family_avoided_project", "ranking", avoided,
                             f"none of {profile.get('avoid_projects')} for {plan.get('role_family')}",
                             "Pick from the family's preferred_projects, or give a JD-specific ranking_override_reason."))
    allowed_taglines = profile.get("tagline_ids", [])
    if allowed_taglines and plan.get("tagline_id") not in allowed_taglines:
        failures.append(fail("role_family_tagline", "tagline_id", plan.get("tagline_id"), allowed_taglines,
                             "Use a tagline allowed for this role family."))
    return failures


def _high_priority_skill_displays(plan: dict[str, Any], master: dict[str, Any]) -> list[str]:
    out = []
    reqs = [r for r in plan.get("jd_requirements", []) if isinstance(r, dict)]
    reqs = [r for r in reqs if str(r.get("priority", "")).lower() == "high"] + [r for r in reqs if str(r.get("priority", "")).lower() == "medium"]
    for req in reqs:
        if False:
            continue
        term = str(req.get("term", "")); aliases = [str(a) for a in req.get("aliases", [])]
        if not master_supports_requirement(term, aliases, master):
            continue
        for c in [str(req.get("verbatim", "")), term] + aliases:
            canon = canonical_pool_match(normalize_skill_name(c, master), master) if c else None
            if canon and supported_skill_category(canon, master):
                if canon not in out:
                    out.append(canon)
                break
    return out


def _skill_on_page(skill: str, text: str) -> bool:
    toks = [t for t in re.findall(r"[A-Za-z0-9+#]+", skill) if len(t) > 2 and t.lower() not in ("and", "the")]
    if not toks:
        return True
    return all(re.search(r"(?<![A-Za-z0-9])" + re.escape(t[:5].lower()), text.lower()) for t in toks)


def _drop_unanchored_skills(merged: list[str], plan: dict[str, Any], master: dict[str, Any], jd_keys: set[str], core: Any) -> list[str]:
    """Skills the posting does not name must be shown somewhere on the page (experience, chosen project bullets, project headings);
    JD-named skills, the guaranteed baseline, the confirmed list and anything the plan asked for explicitly stay."""
    bullets = plan.get("bullets") or {}
    if not bullets:
        return merged
    parts = [b for e in master.get("experience", []) for b in e.get("bullets", [])]
    for pid, bl in bullets.items():
        parts += [str(b.get("text", "")) if isinstance(b, dict) else str(b) for b in bl]
        parts += list(master["projects"].get(pid, {}).get("header_priority_tech", []))
    parts += [master.get("education", {}).get("degree", "") if isinstance(master.get("education"), dict) else ""]
    text = " ".join(parts)
    explicit = {normalize_skill_name(x, master).casefold() for x in plan.get("optional_skills", [])}
    keep = set(jd_keys) | explicit | {normalize_skill_name(x, master).casefold() for x in master["skills"].get("jay_confirmed_skills", [])}
    if core:
        keep |= {normalize_skill_name(x, master).casefold() for v in core.values() for x in v}
    return [x for x in merged if normalize_skill_name(x, master).casefold() in keep or _skill_on_page(x, text)]


def build_skill_states(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    highs = _high_priority_skill_displays(plan, master)
    jd_terms = list(plan.get("_jd_pool_terms", []))
    profile = role_family_profile(plan, master) or {}
    mode = "full" if profile.get("ai_ml_baseline") == "full" else "compact"
    core = master.get("skills", {}).get("core_baseline", {}).get(mode)
    _dom = plan.get("_jd_domain") or {}
    if core and mode == "compact" and _dom.get("lead") not in ("ai", "ml") and str(plan.get("role_family", "")) not in ("ai_llm", "data_science_ml"):
        core = {**core, "ai_ml": []}  # a non-AI posting does not need LLM Integration in the guaranteed baseline
    old_baseline = master["skills"]["baseline"]
    if mode == "compact" and master.get("skills", {}).get("compact_ai_ml_baseline"):
        old_baseline = {**old_baseline, "ai_ml": master["skills"]["compact_ai_ml_baseline"],
                        "frameworks_libraries": master["skills"].get("compact_frameworks_baseline", old_baseline["frameworks_libraries"])}
    prunable = master.get("skills", {}).get("only_prunable_baseline_item")
    fillers = []
    if core:
        core_set = {x for v in core.values() for x in v}
        for cat, vals in old_baseline.items():
            if cat == "tools":
                continue  # tool fillers would outrank core tools in the one-line Tools fitter
            for x in vals:
                if x not in core_set and x != prunable:
                    fillers.append(x)
    merged, seen = [], set()
    fam_fill = master.get("skills", {}).get("family_fillers", {}).get(str(plan.get("role_family", "")), [])
    # Selected-project technology closure: JD-named techs stay mandatory; the rest are already visible in
    # project headers/bullets, so they only fill leftover skill space after JD terms.
    raw_jd_text = str(plan.get("_raw_jd_text", ""))
    closure_all = selected_technology_skills(plan, master, resolved_project_header_tech(master, plan["ranking"], plan))
    jd_keys = {normalize_skill_name(x, master).casefold() for x in highs + jd_terms + required_ats_skill_displays(plan, master)}
    closure_keep = [x for x in closure_all if normalize_skill_name(x, master).casefold() in jd_keys or (raw_jd_text and boundary_contains_plural(raw_jd_text, x))]
    closure_rest = [x for x in closure_all if x not in closure_keep]
    for x in highs + jd_terms + list(plan.get("optional_skills", [])) + closure_rest + list(fam_fill):
        key = normalize_skill_name(x, master).casefold()
        if key not in seen:
            merged.append(x); seen.add(key)
    merged = _drop_unanchored_skills(merged, plan, master, jd_keys, core)
    plan = dict(plan)
    if len(merged) > 25:
        plan["_optional_skills_trimmed"] = merged[25:]  # lowest-priority automatic candidates; reported, never a failure
        merged = merged[:25]
    plan["optional_skills"] = merged
    m2 = dict(master)
    skills = deepcopy(master["skills"])
    skills["baseline"] = deepcopy(core) if core else {k: [x for x in v if x != prunable] for k, v in old_baseline.items()}
    m2["skills"] = skills
    g = globals(); orig = g["selected_technology_skills"]
    g["selected_technology_skills"] = lambda _p, _m, _h: list(closure_keep)
    try:
        return _build_skill_states_v3_1(plan, m2)
    finally:
        g["selected_technology_skills"] = orig


def _letter_words(text: str) -> int:
    return len(re.findall(r"[A-Za-z0-9][A-Za-z0-9'’.%+/#-]*", text))


def _master_numbers(master: dict[str, Any]) -> set[str]:
    facts = {k: master.get(k) for k in ("experience", "education", "awards", "non_default_items", "cover_letter_evidence")}
    facts["projects"] = {pid: {"evidence_items": p.get("evidence_items"), "evidence": p.get("evidence"), "date": p.get("date")}
                         for pid, p in master.get("projects", {}).items()}
    blob = json.dumps(facts, ensure_ascii=False)
    nums = set()
    for tok in numeric_tokens(blob):
        n = normalize_numeric(tok).rstrip("%+")
        nums.add(n)
        if "." in n:
            nums.add(n.rstrip("0").rstrip("."))
    return nums


def _short_project_names(master: dict[str, Any]) -> dict[str, str]:
    out = {}
    for pid, proj in master["projects"].items():
        title = proj.get("resume_title") or {}
        out[pid] = title.get("name") or proj["name"].split(" — ")[0]
    return out


def validate_cover_letter_v32(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    rules = master.get("cover_letter_rules", {})
    paras = plan.get("cover_letter_paragraphs", [])
    if not isinstance(paras, list) or len(paras) != int(rules.get("paragraphs_exact", 3)):
        return []  # the v3.1 count check already reports this
    failures = []
    app = plan.get("application", {})
    company = str(app.get("company", "")).strip()
    role = str(app.get("role", "")).strip()
    text = "\n".join(paras)
    low = text.lower()

    lo, hi = rules.get("words_total", [170, 300])
    total = sum(_letter_words(p) for p in paras)
    if not lo <= total <= hi:
        failures.append(fail("cover_letter_length", "cover_letter_paragraphs", total, f"{lo}-{hi} words",
                             "Keep the letter short: tighten or add one concrete proof sentence."))
    for i, ptxt in enumerate(paras, 1):
        plo, phi = rules.get("words_per_paragraph", {}).get(str(i), [0, 999])
        n = _letter_words(ptxt)
        if not plo <= n <= phi:
            failures.append(fail("cover_letter_paragraph_length", f"cover_letter_paragraphs[{i-1}]", n, f"{plo}-{phi} words",
                                 "Rebalance paragraph length."))

    p1, p3 = paras[0].lower(), paras[-1].lower()
    if company_is_placeholder(company):
        company = ""  # not stated: the composer uses "your team"; final_output_scan blocks any placeholder text
    if company and company.lower() not in p1:
        failures.append(fail("cover_letter_company_p1", "cover_letter_paragraphs[0]", company, "company named in paragraph 1", "Name the company in paragraph 1."))
    if company and company.lower() not in p3 and "your client" not in p3:
        failures.append(fail("cover_letter_company_p3", f"cover_letter_paragraphs[{len(paras)-1}]", company, "company named in the closing paragraph", "Name the company in the closing sentence."))
    if role and not role_is_placeholder(role) and role.lower() not in p1:
        failures.append(fail("cover_letter_role_p1", "cover_letter_paragraphs[0]", role, "exact application.role in paragraph 1", "Use the exact role title from application.role."))
    if not re.search(r"\d", paras[1]):
        failures.append(fail("cover_letter_p2_metric", "cover_letter_paragraphs[1]", "no number", "at least one real metric", "Add one supported metric from Experience or a selected project."))

    if re.search(r"\b(graduating|graduation|graduate in|graduate on|will graduate|expect to graduate|expected to graduate)\b", low) and "february 2027" not in low:
        failures.append(fail("cover_letter_graduation_date", "cover_letter_paragraphs", "graduation mentioned without February 2027", "Expected February 2027 degree date", "Say 'graduating in February 2027' or drop the date; never say December graduation."))
    if re.search(r"\b(cpt|opt|h-1b|visa|visas|sponsor|sponsorship)\b", low):
        failures.append(fail("cover_letter_visa_mention", "cover_letter_paragraphs", "work-authorization wording", "none", "Keep visa/OPT details out of the cover letter."))
    long_sentences = [s for s in re.split(r"(?<=[.!?])\s+", text.replace("\n", " ")) if len(s.split()) > int(rules.get("sentence_words_max", 40))]
    if long_sentences:
        failures.append(fail("cover_letter_sentence_too_long", "cover_letter_paragraphs", [s[:80] + "..." for s in long_sentences],
                             f"every sentence <= {rules.get('sentence_words_max', 40)} words", "Split long sentences; one idea per sentence."))
    banned = [b for b in rules.get("banned_phrases", []) if b in low]
    if banned:
        failures.append(fail("cover_letter_banned_phrase", "cover_letter_paragraphs", banned, "none", "Replace generic phrasing with a concrete fact."))

    ranking = plan.get("ranking") or []
    if ranking:
        top = ranking[0]
        names = [_short_project_names(master)[top]] + list(master["projects"][top].get("letter_aliases", []))
        mentioned = any(re.search(r"\b" + re.escape(n) + r"\b", text, re.I) for n in names)
        items = master["projects"][top].get("evidence_items", {})
        head = items.get(master["projects"][top].get("headline_evidence_id", ""), {})
        head_has_numbers = bool(numeric_tokens(" ".join(head.get("claim_atoms", []))))
        top_nums = set()
        if head_has_numbers:
            for it in items.values():
                if it.get("resume_eligible") is False:
                    continue
                for x in numeric_tokens(" ".join(it.get("claim_atoms", []))):
                    top_nums.add(normalize_numeric(x).rstrip("%+"))
        letter_nums = {normalize_numeric(x).rstrip("%+") for x in numeric_tokens(text)}
        if not mentioned:
            failures.append(fail("cover_letter_missing_top_project", "cover_letter_paragraphs", names[0], "the #1 ranked project appears in P1 or P2",
                                 "Lead with the project that best proves the JD's main responsibility."))
        elif top_nums and not (top_nums & letter_nums):
            failures.append(fail("cover_letter_top_project_without_metric", "cover_letter_paragraphs", sorted(top_nums), "one number from the #1 project's resume bullets",
                                 "Quote the strongest result of the #1 project (for example its AUC versus the baseline)."))
    pool_terms = [x for vals in master["skills"]["supported_pool"].values() for x in vals if len(x) > 2]
    for sent in re.split(r"(?<=[.!?])\s+", text.replace("\n", " ")):
        hits = [x for x in pool_terms if boundary_contains(sent, x)]
        if len(hits) >= 4 and re.search(r"\bskills?\b|\bproficien", sent, re.I):
            failures.append(fail("cover_letter_keyword_list", "cover_letter_paragraphs", sent[:90] + "...", "no sentence that lists 4+ skills",
                                 "Show a skill through what you did with it; skill lists belong on the resume."))
            break
    named = [n for n in _short_project_names(master).values() if re.search(r"\b" + re.escape(n) + r"\b", text)]
    if len(named) > int(rules.get("projects_named_max", 2)):
        failures.append(fail("cover_letter_too_many_projects", "cover_letter_paragraphs", named, f"at most {rules.get('projects_named_max', 2)} projects named",
                             "Go deeper on fewer projects: keep the two that best prove the JD's top requirements."))
    for name in _short_project_names(master).values():
        in_paras = sum(1 for ptxt in paras if re.search(r"\b" + re.escape(name) + r"\b", ptxt))
        if in_paras > 1:
            failures.append(fail("cover_letter_project_repeated", "cover_letter_paragraphs", name, "each project in at most one paragraph",
                                 "Mention each project once; use the space for a different piece of evidence."))
        if re.search(re.escape(name) + r"\s*:", text):
            failures.append(fail("cover_letter_project_title_format", "cover_letter_paragraphs", name + ":", f"plain short name '{name}'", "Use the short project name without the colon subtitle."))

    allowed = _master_numbers(master)
    bad_nums = []
    for tok in numeric_tokens(text):
        n = normalize_numeric(tok).rstrip("%+")
        if YEAR_RE.match(n) or n in allowed or n.rstrip("0").rstrip(".") in allowed:
            continue
        bad_nums.append(tok)
    if bad_nums:
        failures.append(fail("cover_letter_unsupported_number", "cover_letter_paragraphs", bad_nums, "numbers that appear in the Master", "Use only Master metrics; never round up or invent."))

    scrub = text
    focus_txt = str((plan.get("cover_letter") or {}).get("team_focus", "")) if isinstance(plan.get("cover_letter"), dict) else ""
    for name in sorted((role, company, focus_txt, focus_txt.strip().rstrip(".")), key=len, reverse=True):
        if name:
            scrub = re.sub(re.escape(name), " ", scrub, flags=re.I)
    unsup = unsupported_hits([scrub], master)
    gap_terms = []
    supported_hits = set()
    for req in plan.get("jd_requirements", []):
        if not isinstance(req, dict):
            continue
        term = str(req.get("term", "")); aliases = [str(a) for a in req.get("aliases", [])]
        verbatim = str(req.get("verbatim", ""))
        candidates = [term] + aliases + ([verbatim] if len(verbatim.split()) <= 4 else [])
        if master_supports_requirement(term, aliases, master):
            if str(req.get("priority", "")).lower() in {"must", "high"} and any(c and boundary_contains_plural(text, c) for c in candidates):
                supported_hits.add(term)
        else:
            for c in [term] + ([verbatim] if len(verbatim.split()) <= 4 else []):
                if c and len(c) > 2 and boundary_contains_plural(scrub, c) and not master_supports_requirement(c, [], master):
                    gap_terms.append(c)
    if unsup or gap_terms:
        failures.append(fail("cover_letter_unsupported_claim", "cover_letter_paragraphs", sorted(set(unsup + gap_terms)), "no unsupported technologies or gap terms", "Remove gap terms; never imply experience with them."))
    need = int(rules.get("must_mention_supported_requirements_min", 2))
    qf = {q.casefold() for q in master.get("qualification_facts", [])}
    supported_reqs = [r for r in plan.get("jd_requirements", []) if isinstance(r, dict) and str(r.get("priority", "")).lower() in {"must", "high"}
                      and master_supports_requirement(str(r.get("term", "")), [str(a) for a in r.get("aliases", [])], master)
                      and not any(x.casefold() in qf for x in [str(r.get("term", ""))] + [str(a) for a in r.get("aliases", [])])]
    need = min(len(supported_reqs), 1 if len(supported_reqs) <= 3 else need)
    if len(supported_hits) < need and not (isinstance(plan.get("cover_letter"), dict) and plan["cover_letter"].get("hook")):
        failures.append(fail("cover_letter_jd_coverage", "cover_letter_paragraphs", sorted(supported_hits), f">= {need} supported must/high requirement terms",
                             "Name the JD's top supported requirements in their JD wording."))
    return failures


def validate_project_tech_length(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    out = []
    for pid, techs in (plan.get("project_tech") or {}).items():
        if pid not in master["projects"] or not isinstance(techs, list):
            continue
        canon = ", ".join(master["projects"][pid].get("header_priority_tech", []))
        given = ", ".join(str(x) for x in techs)
        if len(given) > len(canon):
            out.append(fail("project_tech_too_long", f"project_tech.{pid}", given, f"<= {len(canon)} characters (canonical: {canon})",
                            "Keep the heading short: swap a technology instead of adding one, or drop project_tech."))
    return out


def validate_application_fields(plan: dict[str, Any]) -> list[dict[str, Any]]:
    loc = str(plan.get("application", {}).get("location", ""))
    if len(loc) > 40 or ";" in loc:
        return [fail("application_location_format", "application.location", loc, "one short location, <= 40 chars, no semicolons",
                     "Use a single location such as 'Mountain View, CA (Hybrid)'.")]
    return []


_GO_LANGS = r"(?:Java|Python|C\+\+|C#|Rust|Node(?:\.js)?|TypeScript|JavaScript|Ruby|Kotlin|Scala|PHP|Swift|Elixir)"


def go_language_named(raw_jd: str) -> bool:
    """True when the posting names the Go language (not the verb): Golang, or Go beside other languages ("Java or Go", "Go, Python")."""
    if re.search(r"\bGolang\b", raw_jd):
        return True
    return bool(re.search(r"\b" + _GO_LANGS + r"\s*(?:,|/|or|and|&)\s*(?:or\s+)?Go\b(?![a-z])|(?<![A-Za-z])Go\s*(?:,|/|or|and|&)\s*" + _GO_LANGS, raw_jd))


def jd_named_pool_terms(raw_jd: str, master: dict[str, Any]) -> list[str]:
    """Supported-pool skills the JD names literally, so ATS coverage does not depend on the planner."""
    squashed = re.sub(r"\s+", "", raw_jd).lower()
    found = []
    for vals in master["skills"]["supported_pool"].values():
        for term in vals:
            if len(term) <= 2:
                if re.search(r"(?<![A-Za-z0-9])" + re.escape(term) + r"(?![A-Za-z0-9+#])", raw_jd) and term not in ("C", "Go"):
                    found.append(term)
                elif term == "Go" and go_language_named(raw_jd):
                    found.append(term)
                continue
            if boundary_contains_plural(raw_jd, term) or (" " in term and term.replace(" ", "").lower() in squashed):
                found.append(term)
    return found


_STOP = set("a an the and or of for to in on with at by from that this your our their its is are be as into across".split())

# What the team's product is about, read from the whole posting (mission, team blurb, responsibilities). A general SWE
# role on an AI-agent or legal-AI product should lead with AI project evidence, not the payment ledger.
_AI_DOMAIN = re.compile(r"\b(ai agents?|agentic|llms?|large language models?|generative ai|gen ?ai|ai[- ]powered|ai systems?|ai features?|frontier ai|"
                        r"retrieval|rag|evals|evaluation results|agent traces?|traces|tracing|prompt engineering|prompts|prompting|enterprise agents|multi-agent|langchain|langgraph|"
                        r"ai[- ](?:assisted|first|focused|native|driven|powered|services?|products?|applications?)|ai/ml|ai and security|language models?|tool calling)\b", re.I)
_ML_DOMAIN = re.compile(r"\b(machine learning|ml models?|train(?:ing)?,? (?:and )?(?:evaluat\w+ )?(?:ml |deep learning )?models?|pytorch|tensorflow|"
                        r"ranking (?:and retrieval )?models?|recommend(?:er|ation) systems?|a/b tests?|feature engineering|deep learning|neural networks?|model evaluation|scikit-learn)\b", re.I)
_DOMAIN_MIN = 6


_DOMAIN_SHORT_MIN = 3          # a short posting can be AI-led with fewer mentions
_DOMAIN_PER_1000 = 10.0        # ... as long as they are dense: at least 10 per 1,000 words


def jd_domain(raw_jd: str) -> dict[str, Any]:
    ai = len(_AI_DOMAIN.findall(raw_jd)); ml = len(_ML_DOMAIN.findall(raw_jd))
    words = max(1, len(re.findall(r"[A-Za-z][A-Za-z'-]*", raw_jd)))
    dense = lambda n: n >= _DOMAIN_SHORT_MIN and n * 1000.0 / words >= _DOMAIN_PER_1000
    ai_ok = ai >= _DOMAIN_MIN or dense(ai)
    ml_ok = ml >= _DOMAIN_MIN or dense(ml)
    lead = "ai" if ai_ok and ai >= ml else ("ml" if ml_ok else "")
    return {"ai_hits": ai, "ml_hits": ml, "words": words, "lead": lead}


def company_is_placeholder(company: Any) -> bool:
    return role_is_placeholder(company)


def jd_fingerprint(raw_jd: str) -> str:
    """Stable id for a posting: ignores case, spacing, punctuation and markdown, so a rerun of the same JD matches."""
    import hashlib
    return hashlib.sha1(re.sub(r"\W+", "", str(raw_jd).casefold()).encode("utf-8")).hexdigest()[:6]


def make_application_key(company: str, role: str, fp: str = "", suffix: str = "") -> str:
    role_part = "Application" if role_is_placeholder(role) else role
    if company_is_placeholder(company):
        # no company name: never write "Not stated" into a file name; the JD id keeps different postings apart
        raw = f"Company_Not_Stated_{role_part}_{fp or 'nojd'}"
    else:
        raw = f"{company}_{role_part}"
    if str(suffix or "").strip():
        raw += f"_{suffix}"
    asc = unicodedata.normalize("NFKD", raw).encode("ascii", "ignore").decode("ascii")
    asc = re.sub(r"[^A-Za-z0-9]+", "_", asc)
    return re.sub(r"_+", "_", asc).strip("_")


def output_names(plan: dict[str, Any]) -> dict[str, str]:
    app = plan.get("application", {})
    key = make_application_key(str(app.get("company", "")), str(app.get("role", "")), str(plan.get("_jd_fingerprint", "")), str(app.get("key_suffix", "")))
    return {"key": key, "resume_pdf": "build_resume.pdf", "resume_tex": "build_resume.tex", "resume_tex_clean": f"{key}.tex",
            "cover_txt": f"{key}_Cover_Letter.txt", "cover_pdf": f"{key}_Cover_Letter.pdf"}


_PLACEHOLDER_OUT = re.compile(r"\b(?:not (?:stated|listed|specified|given|provided)|n/a|tbd|unknown company)\b|\{company\}|\[company\]|\{role\}|\[role\]", re.I)


def final_output_scan(out_dir: Path, names: dict[str, str], outreach: dict[str, Any]) -> list[dict[str, Any]]:
    """Placeholder text must never reach a page the employer reads. The tracker row (visa line etc.) is not scanned."""
    failures = []
    targets = [(names.get("resume_tex_clean", ""), None), (names.get("cover_txt", ""), None), ("outreach message", str((outreach or {}).get("message", "")))]
    for name, text in targets:
        if text is None:
            p = out_dir / name
            if not name or not p.exists():
                continue
            text = p.read_text(encoding="utf-8")
            if name.endswith(".tex"):
                text = "\n".join(l for l in text.splitlines() if not l.lstrip().startswith("%"))
        hits = sorted({m.group(0) for m in _PLACEHOLDER_OUT.finditer(text)})
        if hits:
            failures.append(fail("placeholder_in_output", name, hits, "no placeholder text in the resume, cover letter or outreach",
                                 "Leave application.company or role as given; the script writes neutral wording when they are not stated."))
    return failures


def experience_byte_check(template_text: str, generated_tex: str) -> list[dict[str, Any]]:
    """The EXPERIENCE block (role headers, dates and bullets) must equal the template byte for byte."""
    def block(s: str) -> str | None:
        if r"\section*{EXPERIENCE}" not in s:
            return None
        return s.split(r"\section*{EXPERIENCE}", 1)[1].split(r"\sectiondivider", 1)[0]
    a, b = block(template_text), block(generated_tex)
    if a is None or b is None or a != b:
        import difflib
        diff = [l for l in difflib.unified_diff((a or "").splitlines(), (b or "").splitlines(), "template", "output", n=0, lineterm="") if l[:1] in "+-" and l[:3] not in ("+++", "---")]
        return [fail("experience_bytes", "EXPERIENCE", diff[:6] or "section missing", "EXPERIENCE identical to the template, character for character",
                     "Experience is fixed: restore the template's EXPERIENCE block exactly.")]
    return []


def _plain_sentence_failures(text: str, raw_jd: str, master: dict[str, Any], company: str, field: str, need_jd_words: int) -> list[dict[str, Any]]:
    out = []
    low = text.lower()
    if re.search(r"\d", text):
        out.append(fail("plain_sentence_digits", field, text, "no digits", "Remove numbers; metrics come from the bank."))
    if re.search(r"\b(passionate|excited|thrilled|love|dream|leverage|cutting-edge|synergy)\b", low):
        out.append(fail("plain_sentence_emotion", field, text, "no emotion or buzz words", "Say what you will do, in plain words."))
    bad = unsupported_hits([text], master) + [g for g in jd_gap_terms(raw_jd, master) if boundary_contains_plural(text, g)]
    if bad:
        out.append(fail("plain_sentence_unsupported", field, sorted(set(bad)), "no technology Jay lacks", "Remove the unsupported technology."))
    jd_words = {w.lower() for w in re.findall(r"[A-Za-z][A-Za-z-]+", raw_jd)}
    skip = {w.lower() for w in re.findall(r"[A-Za-z]+", company)}
    content = {w for w in re.findall(r"[a-z][a-z-]+", low) if w not in _STOP and w not in skip and len(w) > 3}
    if len(content & jd_words) < need_jd_words:
        out.append(fail("plain_sentence_not_from_jd", field, text, f"at least {need_jd_words} content words taken from the JD", "Reuse the JD's own words for what the team or role does."))
    return out


def compose_bank_cover_letter(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[dict[str, Any]]:
    cl = plan.get("cover_letter")
    if isinstance(cl, dict) and cl.get("mode") == "free":
        return []
    if not isinstance(cl, dict):
        return [fail("cover_letter_mode", "cover_letter", cl, '{"mode":"bank","hook":"..."}',
                     "Use bank mode: give hook (one plain sentence using at least 4 consecutive words from the JD) and optionally an experience key.")]
    bank = master.get("cover_letter_bank", {})
    fam = str(plan.get("role_family", ""))
    app = plan.get("application", {})
    company = str(app.get("company", "")).strip(); role = str(app.get("role", "")).strip()
    failures = []
    hook_in = re.sub(r"\s+", " ", str(cl.get("hook", "")).strip())
    focus = re.sub(r"\s+", " ", str(cl.get("team_focus", "")).strip()).rstrip(".")
    if hook_in:
        _hw = [w for w in re.findall(r"[A-Za-z0-9][A-Za-z0-9'&+#.-]*", hook_in.lower())]
        _jw = [w for w in re.findall(r"[A-Za-z0-9][A-Za-z0-9'&+#.-]*", raw_jd.lower())]
        _jset = {" ".join(_jw[i:i + 4]) for i in range(len(_jw) - 3)}
        _grams = [" ".join(_hw[i:i + 4]) for i in range(len(_hw) - 3)]
        _own = [w for w in re.findall(r"[a-z]+", hook_in.lower()) if w not in _STOP]
        if not 8 <= len(hook_in.split()) <= 32 or not hook_in.endswith((".", "!")) or len(re.split(r"(?<=[.!?])\s+", hook_in)) != 1 or re.search(r"\d", hook_in):
            failures.append(fail("cover_letter_hook", "cover_letter.hook", hook_in, "one sentence, 8-32 words, ending with a period, no digits",
                                 "Write one plain sentence saying what draws you to this team's work, in the JD's own words."))
        elif not (v349_from_one_line(hook_in, raw_jd) if _v347_on("copy_rule_v349") else any(g in _jset for g in _grams)):   # v3.4.9a fix 8
            failures.append(fail("cover_letter_hook_not_from_jd", "cover_letter.hook", hook_in, "contains at least 4 consecutive words copied from the JD",
                                 "Reuse a phrase from the JD (what the team builds or why it matters) inside the sentence."))
        elif re.search(r"\b(passionate|excited|thrilled|love|dream)\b", hook_in, re.I):
            failures.append(fail("cover_letter_hook_generic", "cover_letter.hook", hook_in, "no emotion words (passionate, excited, love)",
                                 "Say what the team does and why it matters to you; no emotion words."))
        focus = ""
    tag_in = re.sub(r"\s+", " ", str(plan.get("tagline_text", "") or "")).strip()
    plan["_tagline_text_ok"] = False
    if tag_in:
        tf = []
        if not tag_in.startswith("Master's CS student ") or not tag_in.endswith(".") or len(tag_in) > 96 or re.search(r"[&%$#_{}\\~^]", tag_in):
            tf.append(fail("tagline_text_shape", "tagline_text", tag_in, "starts with \"Master's CS student \", ends with a period, <= 96 characters, no LaTeX special characters",
                           "Write one short line, e.g. Master's CS student building backend APIs and reliable data services."))
        tf += _plain_sentence_failures(tag_in, raw_jd, master, "", "tagline_text", 1)
        failures += tf
        plan["_tagline_text_ok"] = not tf
    close_in = re.sub(r"\s+", " ", str(cl.get("closing", "") or "")).strip()
    if close_in:
        cf = []
        if not close_in.startswith("I would welcome the chance to ") or not close_in.endswith(".") or len(close_in.split()) > 26:
            cf.append(fail("cover_letter_closing_shape", "cover_letter.closing", close_in, 'starts with "I would welcome the chance to ", <= 26 words, ends with a period',
                           "One sentence saying what you would work on at this company, in the JD's words."))
        if company and not company_is_placeholder(company) and company.lower() not in close_in.lower() and "your client" not in close_in.lower():
            cf.append(fail("cover_letter_closing_company", "cover_letter.closing", close_in, "names the company", "Name the company in the closing."))
        cf += _plain_sentence_failures(close_in, raw_jd, master, company, "cover_letter.closing", 2)
        failures += cf
    words = focus.split()
    first = re.sub(r"[^a-z]", "", words[0].lower()) if words else ""
    if hook_in:
        pass
    elif not 6 <= len(words) <= 25 or re.match(r"(?i)^(i|we|my|our|you)\b", focus) or not (first.endswith("s") or first in {"is", "has", "does"}):
        failures.append(fail("cover_letter_team_focus", "cover_letter.team_focus", focus, "6-25 words, starts with a third-person verb (builds, owns, develops), no I/we",
                             "Describe what the team does in the JD's own words, e.g. 'builds recommendation systems that help members find jobs'."))
    jd_words = {w.lower() for w in re.findall(r"[A-Za-z][A-Za-z-]+", raw_jd)}
    _concepts = {c.casefold() for c in globals().get("_CONCEPT_TERMS", [])}
    tech_hits = len([r for _, r in _find_terms(focus, _lexicon(master)) if r.casefold() not in _concepts]) if "_find_terms" in globals() else 0
    if not hook_in and (tech_hits >= 3 or (tech_hits >= 2 and focus.count(",") >= 3)):
        failures.append(fail("cover_letter_team_focus_list", "cover_letter.team_focus", focus, "a plain sentence about what the team builds and for whom, not a list of technologies",
                             "Rewrite team_focus as what the team builds and who uses it, e.g. 'builds internal web apps and automation tools for business teams'; do not list skills."))
    content = [w.lower() for w in re.findall(r"[A-Za-z][A-Za-z-]+", focus) if w.lower() not in _STOP]
    if not hook_in and sum(1 for w in content if w in jd_words) < 3:
        failures.append(fail("cover_letter_team_focus_not_from_jd", "cover_letter.team_focus", focus, "at least 3 content words taken from the JD",
                             "Paraphrase the JD's description of the team's work; do not write a generic phrase."))
    ranking = plan.get("ranking") or []
    dom = jd_domain(raw_jd)
    exp_key = cl.get("experience") or ("hein" if _is_data_ml_role(plan) and fam not in ("data_engineering",) else bank.get("family_default_experience", {}).get(fam, "hein"))
    if not cl.get("experience") and exp_key == "thesis" and dom["lead"] in ("ai", "ml") and fam in ("general_swe", "backend"):
        exp_key = "hein"
    if not cl.get("experience") and exp_key == "thesis" and (fam != "fullstack" or dom["lead"] == "ai"):
        # pipeline / extraction / LLM work in the JD is proven best by the HeinOnline pipeline, not the healthcare modules
        pipe_terms = {"data pipelines", "etl", "information extraction", "llms", "llm integration", "ai agents", "parallel processing", "ocr/tesseract", "data preprocessing"}
        req_terms = {str(r.get("term", "")).casefold() for r in plan.get("jd_requirements", []) if isinstance(r, dict) and r.get("supported")
                     and str(r.get("priority", "")).lower() in ("must", "high")}
        if req_terms & pipe_terms:
            exp_key = "hein"
    exp = bank.get("experience", {}).get(exp_key)
    hook = bank.get("family_hooks", {}).get(fam)
    if fam == "general_swe" and dom["lead"] in ("ai", "ml"):
        hook = bank.get("family_hooks", {}).get("general_swe_" + dom["lead"], hook)
    projs = dict(bank.get("projects", {}))
    for pid, by_fam in (bank.get("project_variants", {}) or {}).items():
        if isinstance(by_fam, dict) and by_fam.get(fam):
            projs[pid] = by_fam[fam]
    if not exp or not hook or len(ranking) < 2 or ranking[0] not in projs or ranking[1] not in projs:
        failures.append(fail("cover_letter_bank_missing", "cover_letter", {"experience": exp_key, "family": fam}, "known bank keys", "Use a listed experience key and a valid role_family."))
        return failures
    p1_text = projs[ranking[0]]
    p2_text = projs[ranking[1]]
    if p2_text.startswith("I also built") and p1_text.startswith("I also built"):
        p1_text = p1_text.replace("I also built", "I built", 1)
    if p1_text.startswith("I also built"):
        p1_text = p1_text.replace("I also built", "I built", 1)
    collab = bank["collaboration"]["short" if exp_key == "thesis" else "with_employer"]
    agency = re.search(r"(recruiting|hiring|searching) (?:for this (?:role|position) )?on behalf of (?:our|a|an|their) client|\bour client is\b|on behalf of a client|\b(?:recruit(?:ing|ment)|staffing|search) (?:agency|firm|company)\b|\brepresent(?:ing|s) (?:a|an|our)\b[^.]{0,40}\bclient\b|\bon behalf of (?:its|our|a|an|their)\b[^.]{0,20}\bclient\b|\bclient name (?:cannot|can not|will not|is not) be\b|\bconfidential (?:retail |tech |financial )?client\b", raw_jd, re.I) is not None
    poss = company + ("'" if company.endswith("s") else "'s")
    tmpl = bank["family_closing"].get(fam, "contribute at {company}")
    no_company = company_is_placeholder(company)
    if no_company and not agency:
        # company not stated in the posting: neutral wording, never the placeholder itself
        tmpl = tmpl.replace("the team at {company}", "your team").replace(" at {company}", " on your team").replace("{company}'s", "your team's").replace("{company}", "your team")
    if agency:
        tmpl = tmpl.replace("the team at {company}", "your client's team").replace(" at {company}", " for your client").replace("{company}'s", "your client's").replace("{company}", "your client")
    closing = "I would welcome the chance to " + tmpl.replace("{company}'s", poss).replace("{company}", company) + "."
    if close_in and not [f for f in failures if str(f.get("target", "")).startswith("cover_letter.closing")]:
        closing = close_in
    extra = re.sub(r"\s+", " ", str(cl.get("extra", "")).strip())
    if extra:
        if len(extra.split()) > 30 or not extra.endswith("."):
            failures.append(fail("cover_letter_extra", "cover_letter.extra", extra, "one sentence, <= 30 words, ending with a period",
                                 "Use extra only to name 1-3 supported JD requirements the bank sentences miss."))
            return failures
        collab = extra
    role_txt = "open engineering" if role_is_placeholder(role) else role
    # v3.2.15 two-paragraph letter: opening + one JD-based sentence + one Experience proof, then two projects, logistics and the close
    loc = str(app.get("location", "")).strip()
    reloc = bool(loc) and loc.lower() not in ("not stated", "n/a", "unknown") and not re.search(r"remote|buffalo", loc, re.I)
    logistics = "I graduate in February 2027 and can start soon after." + (" I am also open to relocating." if reloc else "")
    opening = (f"I am applying for the {role_txt} role {'you are' if no_company else 'that ' + company + ' is'} recruiting for." if agency
               else (f"I am applying for the {role_txt} role you posted." if no_company else f"I am applying for the {role_txt} role at {company}."))
    if hook_in:
        why = hook_in if hook_in.endswith((".", "!")) else hook_in + "."
    else:
        why = f"{'The' if agency else 'Your'} team {focus}."
    paras = [f"{opening} {why} {exp}", f"{p1_text} {p2_text} {extra + ' ' if extra else ''}{logistics} {closing}"]
    # the JD asks for hands-on AI-assisted development: say what Jay did with Claude Code (master evidence ripple.claude_code_dev)
    ai_dev = bank.get("ai_assisted_development")
    if ai_dev and "ripple" in ranking and any(isinstance(r, dict) and r.get("term") == "Claude Code" and r.get("supported")
                                             and str(r.get("priority", "")).lower() in ("must", "high") for r in plan.get("jd_requirements", [])):
        # the sentence names RIPPLE, so it joins the paragraph that already has the RIPPLE sentence (never a second paragraph)
        idx = next((i for i in range(len(paras)) if "RIPPLE" in paras[i]), None)
        if idx is not None:
            cap = int(master.get("cover_letter_rules", {}).get("words_per_paragraph", {}).get(str(idx + 1), [0, 130])[1])
            if _letter_words(paras[idx]) + _letter_words(ai_dev) <= cap:
                paras[idx] = f"{paras[idx]} {ai_dev}"
    if not extra and not hook_in:
        body = " ".join(paras)
        missing = []
        for req in plan.get("jd_requirements", []):
            if not isinstance(req, dict) or str(req.get("priority", "")).lower() not in {"must", "high"}:
                continue
            term = str(req.get("term", "")); aliases = [str(a) for a in req.get("aliases", [])]
            if not master_supports_requirement(term, aliases, master):
                continue
            if any(x.casefold() in {q.casefold() for q in master.get("qualification_facts", [])} for x in [term] + aliases):
                continue
            cands = [term] + aliases
            if any(c and boundary_contains_plural(body, c) for c in cands):
                continue
            show = next((c for c in cands if canonical_pool_match(normalize_skill_name(c, master), master)), None) or (term if len(term.split()) <= 3 else None)
            if show and show not in missing and len(show) <= 30:
                missing.append(show)
        qf = {q.casefold() for q in master.get("qualification_facts", [])}
        sup_reqs = [r for r in plan.get("jd_requirements", []) if isinstance(r, dict) and str(r.get("priority", "")).lower() in {"must", "high"}
                    and master_supports_requirement(str(r.get("term", "")), [str(a) for a in r.get("aliases", [])], master)
                    and not any(x.casefold() in qf for x in [str(r.get("term", ""))] + [str(a) for a in r.get("aliases", [])])]
        need = min(len(sup_reqs), 1 if len(sup_reqs) <= 3 else 2)
        covered = len(sup_reqs) - len(missing)
        if missing and covered < need:
            def natural(term):
                cat = supported_skill_category(term, master)
                display = {"ReactJS": "React", "AWS (EC2/RDS)": "AWS", "HTML/CSS": "HTML and CSS", "OAuth/Auth0": "OAuth"}.get(term, term)
                if cat in ("software_engineering", "ai_ml") and not re.search(r"[A-Z]{2,}", display):
                    display = display.lower()
                return display
            pick = [natural(x) for x in missing[:3]]
            listed = pick[0] if len(pick) == 1 else (", ".join(pick[:-1]) + (", and " if len(pick) > 2 else " and ") + pick[-1])
            paras[-1] = paras[-1].replace(f" {closing}", f" My projects and past roles also gave me hands-on practice with {listed}. {closing}")
    plan["cover_letter_paragraphs"] = paras
    plan["_cover_letter_mode"] = "bank"
    return failures


def jd_gap_terms(raw_jd: str, master: dict[str, Any]) -> list[str]:
    pool = {x.casefold() for vals in master["skills"]["supported_pool"].values() for x in vals}
    out = []
    ambiguous = {"Make", "Shell", "Metal", "Ray", "Chef", "Express", "Beam", "Excel", "Spring", "Go", "Rust", "Swift", "Unity", "Ruby", "Julia", "Dart", "Lambda", "Hive", "Puppet", "Rails"}
    for term in master.get("never_supported_terms", []) + [x for x in master.get("unsupported_claims", []) if "/" not in x and " " not in x]:
        if term.casefold() in pool or len(term) < 2:
            continue
        if term in ambiguous:
            # ordinary English words: only a capitalised, technology-looking use counts
            if not re.search(r"(?<![\w])" + re.escape(term) + r"(?![\w])", raw_jd) or re.search(r"(?:^|[.!?]\s)" + re.escape(term) + r"\s+[a-z]", raw_jd):
                continue
        if boundary_contains_plural(raw_jd, term) and term not in out:
            out.append(term)
    return out


def validate_plan_v3_1(plan: dict[str, Any], master: dict[str, Any], raw_jd: str,
                       warnings: list[dict[str, Any]] | None = None, free_text_mode: bool = False) -> list[dict[str, Any]]:
    plan["_jd_pool_terms"] = jd_named_pool_terms(raw_jd, master)
    plan["_jd_gap_terms"] = jd_gap_terms(raw_jd, master)
    plan["_raw_jd_text"] = raw_jd
    bank_fail = compose_bank_cover_letter(plan, master, raw_jd)
    if bank_fail:
        return bank_fail
    failures = _validate_plan_v3_1_base(plan, master, raw_jd, warnings=warnings, free_text_mode=free_text_mode)
    failures.extend(validate_role_family(plan, master))
    failures.extend(validate_application_fields(plan))
    failures.extend(validate_project_tech_length(plan, master))
    failures.extend(validate_cover_letter_v32(plan, master))
    return failures


def build_outreach(plan: dict[str, Any], master: dict[str, Any], display_order: list[str]):
    app = plan.get("application", {}); company = str(app.get("company", "")); role = str(app.get("role", ""))
    profile = role_family_profile(plan, master) or {}
    hook = profile.get("outreach_hook", "backend services for production web platforms")
    top = plan["ranking"][0]
    short = master["projects"][top].get("short_name") or _short_project_names(master)[top]
    at_co = "on your team" if company_is_placeholder(company) else f"at {company}"
    role = "open engineering" if role_is_placeholder(role) else role
    titles = ["Technical Recruiter / Talent Acquisition Partner", f"{role} Hiring Manager / Team Lead",
              f"Engineer on the hiring team or University at Buffalo alumnus {'at the company' if company_is_placeholder(company) else 'at ' + company}"]
    msg = (f"Hi, I'm Jay Pathare, a CS master's student at the University at Buffalo applying for the {role} role {at_co}. "
           f"My background includes {hook}, plus my {short} project. "
           "Would you be open to a 10-minute chat so I can get your advice on the team?")
    words = len(msg.split())
    return {"contact_titles": titles, "message": msg,
            "sentence_count": len([x for x in re.split(r"(?<=[.!?])\s+", msg.strip()) if x]),
            "word_count": words, "within_limit": words < int(master.get("outreach", {}).get("message_words_max", 75))}


def _letter_date(plan: dict[str, Any]) -> str:
    raw = plan.get("application", {}).get("application_date")
    try:
        d = datetime.strptime(str(raw), "%Y-%m-%d").date() if raw else datetime.now().date()
    except ValueError:
        d = datetime.now().date()
    return d.strftime("%B %-d, %Y")


def _cover_letter_parts(plan: dict[str, Any], master: dict[str, Any]) -> dict[str, Any]:
    app = plan.get("application", {}); c = master["contact"]; rules = master.get("cover_letter_rules", {})
    salutation = str(plan.get("cover_letter_salutation") or rules.get("salutation_default", "Dear Hiring Team,"))
    if not (salutation.startswith("Dear ") and salutation.endswith(",")):
        salutation = rules.get("salutation_default", "Dear Hiring Team,")
    co = str(app.get("company", "")).strip()
    loc = str(app.get("location", "")).strip()
    addressee = [x for x in ["Hiring Team", "" if company_is_placeholder(co) else co, "" if role_is_placeholder(loc) else loc] if x]
    return {"name": c["name"], "contact": [c["email"], c["phone"], c["location"]],
            "links": [("LinkedIn", c["linkedin"]), ("GitHub", c["github"])],
            "date": _letter_date(plan), "addressee": addressee, "salutation": salutation,
            "paragraphs": [str(p).strip() for p in plan.get("cover_letter_paragraphs", [])],
            "closing": rules.get("closing", "Sincerely,")}


def _write_cover_docx(parts: dict[str, Any], path: Path) -> None:
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Pt, Inches

    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Inches(8.5), Inches(11)
    for side in ("left_margin", "right_margin"):
        setattr(sec, side, Inches(1))
    sec.top_margin = sec.bottom_margin = Inches(0.9)
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"; normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(0); normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.line_spacing = 1.08

    def para(text="", bold=False, size=None, align=None, after=0):
        p = doc.add_paragraph()
        if text:
            r = p.add_run(text); r.bold = bold
            if size: r.font.size = Pt(size)
        if align is not None: p.alignment = align
        p.paragraph_format.space_after = Pt(after)
        return p

    def hyperlink(p, text, url):
        rel = p.part.relate_to(url, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", is_external=True)
        h = OxmlElement("w:hyperlink"); h.set(qn("r:id"), rel)
        r = OxmlElement("w:r"); rpr = OxmlElement("w:rPr")
        color = OxmlElement("w:color"); color.set(qn("w:val"), "1F4E79"); rpr.append(color)
        r.append(rpr); t = OxmlElement("w:t"); t.text = text; r.append(t); h.append(r); p._p.append(h)

    para(parts["name"], bold=True, size=16, align=WD_ALIGN_PARAGRAPH.CENTER, after=2)
    p = para(" | ".join(parts["contact"]) + " | ", align=WD_ALIGN_PARAGRAPH.CENTER, after=14)
    for i, (label, url) in enumerate(parts["links"]):
        if i: p.add_run(" | ")
        hyperlink(p, label, url)
    para(parts["date"], after=12)
    for i, line in enumerate(parts["addressee"]):
        para(line, after=12 if i == len(parts["addressee"]) - 1 else 0)
    para(parts["salutation"], after=10)
    for text in parts["paragraphs"]:
        para(text, after=10)
    para(parts["closing"], after=0)
    para(parts["name"])
    doc.core_properties.author = parts["name"]
    doc.core_properties.title = "Cover Letter"
    doc.save(str(path))


def _tex_escape_plain(text: str) -> str:
    return latex_escape(text.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"'))


def _write_cover_pdf(parts: dict[str, Any], out_dir: Path, pdf_name: str) -> tuple[bool, str, int]:
    links = " $|$ ".join(rf"\href{{{url}}}{{{label}}}" for label, url in parts["links"])
    contact = " $|$ ".join(_tex_escape_plain(x) for x in parts["contact"])
    body = "\n\n".join(_tex_escape_plain(p) for p in parts["paragraphs"])
    addressee = r"\\ ".join(_tex_escape_plain(x) for x in parts["addressee"])
    tex = rf"""\documentclass[11pt,letterpaper]{{article}}
\usepackage[T1]{{fontenc}}
\usepackage[utf8]{{inputenc}}
\usepackage{{cmap}}
\usepackage[top=0.9in,bottom=0.9in,left=1in,right=1in]{{geometry}}
\usepackage[hidelinks]{{hyperref}}
\setlength{{\parindent}}{{0pt}}
\setlength{{\parskip}}{{10pt}}
\pagestyle{{empty}}
\begin{{document}}
\begin{{center}}
{{\Large\bfseries {_tex_escape_plain(parts['name'])}}}\\[2pt]
{contact} $|$ {links}
\end{{center}}
\vspace{{4pt}}
{_tex_escape_plain(parts['date'])}

{addressee}

{_tex_escape_plain(parts['salutation'])}

{body}

{_tex_escape_plain(parts['closing'])}\\
{_tex_escape_plain(parts['name'])}
\end{{document}}
"""
    stem = Path(pdf_name).stem
    tex_path = out_dir / f"{stem}.tex"
    tex_path.write_text(tex, encoding="utf-8")
    proc = subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", tex_path.name],
                          cwd=out_dir, capture_output=True, text=True, timeout=60)
    pdf_path = out_dir / pdf_name
    pages = 0
    if pdf_path.exists():
        with fitz.open(pdf_path) as d:
            pages = d.page_count
    for ext in (".aux", ".log", ".out", ".tex"):
        (out_dir / f"{stem}{ext}").unlink(missing_ok=True)
    return proc.returncode == 0 and pdf_path.exists(), proc.stdout[-1500:], pages


def build_cover_letter(plan: dict[str, Any], master: dict[str, Any], out_dir: Path, names: dict[str, str]):
    failures = []
    parts = _cover_letter_parts(plan, master)
    info = {"pdf": names["cover_pdf"], "txt": names["cover_txt"], "words": sum(_letter_words(p) for p in parts["paragraphs"])}
    text = "\n\n".join([parts["salutation"]] + parts["paragraphs"] + [parts["closing"] + "\n" + parts["name"]]) + "\n"
    (out_dir / names["cover_txt"]).write_text(text, encoding="utf-8")
    ok, log_tail, pages = _write_cover_pdf(parts, out_dir, names["cover_pdf"])
    info["pdf_pages"] = pages
    if not ok:
        failures.append(fail("cover_letter_pdf_compile", names["cover_pdf"], log_tail, "compiled PDF", "Fix the character or text that broke LaTeX."))
    elif pages != 1:
        failures.append(fail("cover_letter_pages", names["cover_pdf"], pages, 1, "Shorten the paragraphs."))
    return failures, info


# ---------------------------------------------------------------------------
# Deterministic bank selection: plan.bank_selection may be "auto" (or omitted).
# Pins: plan.prefer_variants lists ids that get a strong preference.
# ---------------------------------------------------------------------------

def _jd_keyword_weights(raw_plan: dict[str, Any]) -> list[tuple[str, float, list[str]]]:
    """One entry per supported JD requirement: (term, weight, spellings). A bullet earns a requirement's weight once,
    however many of its spellings (term or aliases) it contains."""
    pw = {"must": 3.0, "high": 2.0, "medium": 1.0}
    groups: dict[str, tuple[str, float, list[str]]] = {}
    for req in raw_plan.get("jd_requirements", []):
        if not isinstance(req, dict) or not req.get("supported", True):
            continue
        term = str(req.get("term", "")).strip()
        if not term:
            continue
        w = pw.get(str(req.get("priority", "")).lower(), 0.5)
        spell = list(dict.fromkeys(t for t in (str(x).strip().lower() for x in [term] + list(req.get("aliases", [])) + list(req.get("alternatives", []))) if t))
        old = groups.get(term.casefold())
        if old:
            w = max(w, old[1]); spell = list(dict.fromkeys(old[2] + spell))
        groups[term.casefold()] = (term, w, spell)
    return list(groups.values())


def _variant_score(v: dict[str, Any], weights, themes: set[str], prefer: set[str], breakdown: bool = False):
    text = str(v.get("text", ""))
    terms = {str(x).lower() for x in v.get("jd_terms", [])}
    if isinstance(weights, dict):  # legacy flat {keyword: weight}
        weights = [(k, w, [k]) for k, w in weights.items()]
    score = 0.0
    parts: list[tuple[str, float, str]] = []
    for term, w, spell in weights:
        hit = next((s for s in spell if s in terms), None) or next((s for s in spell if s != "go" and boundary_contains_plural(text, s)), None)
        if hit:
            score += w
            parts.append((term, w, hit))
    th = sorted({str(a).lower() for a in v.get("angles", [])} & themes)
    if th:
        score += 0.75 * len(th); parts.append(("theme", 0.75 * len(th), ",".join(th)))
    if v.get("hero"):
        score += 0.5; parts.append(("hero", 0.5, ""))
    if str(v.get("id", "")).startswith("tailor_pipeline.runtime") and not (themes & {"performance", "concurrency", "distributed_systems"}):
        score -= 2.5; parts.append(("runtime_speed", -2.5, ""))  # resume-generation speed proves little outside performance postings
    if v.get("headline") is True:
        score += 1.0; parts.append(("headline", 1.0, ""))  # the project's strongest result
    if re.search(r"\d", text):
        score += 1.0; parts.append(("metric", 1.0, ""))  # a bullet with a real number proves more than one without
    if v.get("id") in prefer:
        score += 50.0; parts.append(("prefer", 50.0, ""))
    return (score, parts) if breakdown else score


def _redundant(a: str, b: str, pairs: list[list[str]]) -> bool:
    for x, y in pairs:
        if (a.startswith(x) and b.startswith(y)) or (a.startswith(y) and b.startswith(x)):
            return True
    return False


def _project_combos(variants: list[dict[str, Any]], k: int, need_headline: bool, scores: dict[str, float], keep: int = 40, pairs: list[list[str]] | None = None):
    from itertools import combinations
    out = []
    for combo in combinations(variants, k):
        if pairs and any(_redundant(x["id"], y["id"], pairs) for x, y in combinations(combo, 2)):
            continue
        if len({c.get("main_evidence_id") for c in combo}) != k:
            continue
        if len({str(c.get("verb", "")).lower() for c in combo}) != k:
            continue
        ids = {c["id"] for c in combo}
        if any(o in ids for c in combo for o in c.get("conflicts_with", [])):
            continue
        if need_headline and not any(c.get("headline") is True for c in combo):
            continue
        repeats = 0
        for x, y in combinations(combo, 2):
            repeats += len(salient_bigrams(str(x.get("text", ""))) & salient_bigrams(str(y.get("text", ""))))
        out.append((sum(scores[c["id"]] for c in combo) - 1.5 * repeats, sorted(ids), combo))
    # ties go to the combination holding the project's headline result, then to id order
    out.sort(key=lambda x: (-x[0], -sum(1 for c in x[2] if c.get("headline") is True), x[1]))
    return out[:keep]


_IDENTITY_EVIDENCE = {
    "ledgerflow": {"ledger.architecture", "ledger.exactly_once_effect"}, "ripple": {"ripple.core_agent"},
    "launchops": {"launchops.workflow", "launchops.assessments"}, "goingonce": {"goingonce.agents"},
    "tailor_pipeline": {"tailor.pipeline", "tailor.concurrent_runtime"}, "pintos": {"pintos.processes", "pintos.syscalls", "pintos.tests"},
    "fraud": {"fraud.graphsage", "fraud.dataset"},
}


def auto_bank_selection(raw_plan: dict[str, Any], bank: dict[str, Any], pairs: list[list[str]] | None = None) -> tuple[dict[str, list[str]] | None, dict[str, Any]]:
    ranking = raw_plan.get("ranking", [])
    themes = {str(x).strip().lower() for x in raw_plan.get("jd_themes", [])}
    prefer = {str(x) for x in raw_plan.get("prefer_variants", [])}
    weights = _jd_keyword_weights(raw_plan)
    per_project = []
    for rank, pid in enumerate(ranking):
        pool = []
        for v in bank.get("projects", {}).get(pid, []):
            if v.get("status") != "ok":
                continue
            if v.get("optional") and not ({str(x).lower() for x in v.get("optional_themes", [])} & themes):
                continue
            pool.append(v)
        scores = {v["id"]: _variant_score(v, weights, themes, prefer) for v in pool}
        # every project includes one identity bullet (what the project is) so a first-time reader understands it
        allc = _project_combos(pool, 3 if rank == 0 else 2, rank == 0, scores, keep=600, pairs=pairs)
        ident = _IDENTITY_EVIDENCE.get(pid, set())
        combos = [c for c in allc if any(v.get("main_evidence_id") in ident for v in c[2])][:40] or allc[:40]
        if not combos:
            return None, {"project": pid, "reason": "no valid variant combination"}
        per_project.append(combos)
    best = None
    for a in per_project[0]:
        va = {str(c.get("verb", "")).lower() for c in a[2]}
        for b in per_project[1]:
            vb = {str(c.get("verb", "")).lower() for c in b[2]}
            if va & vb:
                continue
            for c in per_project[2]:
                vc = {str(x.get("verb", "")).lower() for x in c[2]}
                if (va | vb) & vc:
                    continue
                total = a[0] + b[0] + c[0]
                hl = sum(1 for combo in (a, b, c) for v in combo[2] if v.get("headline") is True)
                key = (-total, -hl, a[1] + b[1] + c[1])
                if best is None or key < best[0]:
                    best = (key, (a, b, c))
                break  # combos are sorted; first compatible c is best for this (a, b)
    if best is None:
        return None, {"reason": "no verb-distinct combination across projects"}
    # identity bullet first (what the project is), then the headline metric, then the rest
    sel = {pid: [c["id"] for c in sorted(combo[2], key=lambda x: (x.get("main_evidence_id") not in _IDENTITY_EVIDENCE.get(pid, set()), not x.get("headline"),
                                                                    -_variant_score(x, weights, themes, prefer), x["id"]))]
           for pid, combo in zip(ranking, best[1])}
    for pid, ids in sel.items():
        idn = [i for i in ids if next((v for v in bank["projects"][pid] if v["id"] == i), {}).get("main_evidence_id") in _IDENTITY_EVIDENCE.get(pid, set())]
        for extra in idn[1:]:
            ids.remove(extra); ids.append(extra)
    allv = {v["id"]: v for pid in ranking for v in bank.get("projects", {}).get(pid, [])}
    why = {vid: [f"{t} +{w:g}" + (f" ({h})" if h else "") for t, w, h in _variant_score(allv[vid], weights, themes, prefer, breakdown=True)[1]]
           for ids in sel.values() for vid in ids}
    return sel, {"score": -best[0][0], "breakdown": why}


_expand_bank_plan_v3_1 = expand_bank_plan


def expand_bank_plan(raw_plan: dict[str, Any], bank: dict[str, Any], master: dict[str, Any]):
    sel = raw_plan.get("bank_selection")
    if sel is None or sel == "auto":
        ranking = raw_plan.get("ranking")
        if not isinstance(ranking, list) or len(ranking) != 3 or len(set(ranking)) != 3:
            return _expand_bank_plan_v3_1(raw_plan, bank, master)
        chosen, info = auto_bank_selection(raw_plan, bank, master.get("bank_redundant_pairs", []))
        if chosen is None:
            return deepcopy(raw_plan), [fail("bank_auto_selection", "bank_selection", info, "valid 3/2/2 combination", "Change the ranking or pin variants with prefer_variants.")]
        raw_plan = deepcopy(raw_plan)
        raw_plan["bank_selection"] = chosen
        raw_plan["_bank_selection_auto"] = info
        return _expand_bank_plan_v3_1(raw_plan, bank, master)
    expanded, failures = _expand_bank_plan_v3_1(raw_plan, bank, master)
    pairs = master.get("bank_redundant_pairs", [])
    if isinstance(sel, dict):
        from itertools import combinations
        for pid, ids in sel.items():
            if isinstance(ids, list):
                bad = [[a, b] for a, b in combinations(ids, 2) if _redundant(str(a), str(b), pairs)]
                if bad:
                    failures.append(fail("bank_redundant_variants", pid, bad, "variants that say different things", "Use bank_selection \"auto\" or pick non-redundant variants."))
    return expanded, failures


# ---------------------------------------------------------------------------
# Support matching that ignores negated policy text ("no FastAPI", "do not
# infer HIPAA", "designed only") and never counts a known-unsupported term.
# ---------------------------------------------------------------------------

_NEGATION_RE = re.compile(r"\b(no|not|never|do not|don't|without|unless|designed only|incomplete|beyond)\b", re.I)


def _support_corpus_v32(master: dict[str, Any]) -> tuple[str, ...]:
    cache = master.setdefault("_runtime_cache", {})
    if "support_corpus_v32" in cache:
        return cache["support_corpus_v32"]

    def keep(text: str) -> list[str]:
        parts = re.split(r"(?<=[.;])\s+|\n", str(text))
        return [p for p in parts if p.strip() and not _NEGATION_RE.search(p)]

    corpus: list[str] = []
    for role in master["experience"]:
        corpus.extend(role["bullets"])
        corpus.extend(keep(role.get("evidence_anchors", "")))
    for pdata in master["projects"].values():
        corpus.extend(pdata.get("tech", []))
        corpus.extend(pdata.get("tags", []))
        for item in pdata.get("evidence_items", {}).values():
            if item.get("resume_eligible") is False or item.get("kind") == "design_only":
                continue
            corpus.extend(keep(item.get("text", "")))
            corpus.extend(item.get("terms", []))
            corpus.extend(item.get("claim_atoms", []))
    for values in master["skills"]["supported_pool"].values():
        corpus.extend(values)
    corpus.extend(master.get("qualification_facts", []))
    for role in master["experience"]:
        corpus.append(str(role.get("role", "")))
    cache["support_corpus_v32"] = tuple(str(x) for x in corpus if str(x))
    return cache["support_corpus_v32"]


def _denied_terms(master: dict[str, Any]) -> list[str]:
    out = []
    for item in list(master.get("unsupported_claims", [])) + list(master.get("never_supported_terms", [])):
        s = str(item)
        if " unless " in s.lower() or " beyond " in s.lower():
            continue
        out.append(s)
    return out


def master_supports_requirement(term: str, aliases: list[str], master: dict[str, Any]) -> bool:
    needles = [str(term)] + [str(x) for x in aliases or []]
    needles = [n for n in needles if n.strip()]
    pool = {x.casefold() for vals in master["skills"]["supported_pool"].values() for x in vals}
    for n in needles:
        if n.casefold() in pool:
            continue
        if any(boundary_contains(n, d) for d in _denied_terms(master)):
            return False
    corpus = _support_corpus_v32(master)
    return any(boundary_contains(item, n) for n in needles for item in corpus)


def clean_resume_tex(generated: str, resolved_skills: dict[str, Any]) -> str:
    """Standalone LaTeX for Overleaf: no measurement block, skill lines written out."""
    tex = re.sub(r"% ==== (?:AUTO-GENERATED SKILL FITTER|CACHED SKILL FIT) ====.*?% ==== END (?:AUTO-GENERATED SKILL FITTER|CACHED SKILL FIT) ====\n?", "", generated, flags=re.S)
    skills = resolved_skills.get("skills", {})
    if skills.get("ai_ml"):
        tex = re.sub(r"\\ifx\\FinalAiMl\\empty\\else(.*?)\\fi", lambda m: m.group(1), tex, flags=re.S)
    else:
        tex = re.sub(r"[ \t]*\\ifx\\FinalAiMl\\empty\\else.*?\\fi[ \t]*\n?", "", tex, flags=re.S)
    macros = {"FinalLanguagesDatabases": "languages_databases", "FinalFrameworksLibraries": "frameworks_libraries",
              "FinalAiMl": "ai_ml", "FinalSoftwareEngineering": "software_engineering", "FinalTools": "tools"}
    for macro, key in macros.items():
        value = ", ".join(latex_escape(x) for x in skills.get(key, []))
        tex = tex.replace("\\" + macro, value.replace("\\", "\\\\"))
    return re.sub(r"\n{3,}", "\n\n", tex)


# ---------------------------------------------------------------------------
# Requirements listed under a "required / minimum / what we need to see"
# heading carry required_section: true and cap Fit at Low when unsupported.
# ---------------------------------------------------------------------------

_hard_gaps_v3_1 = hard_gaps
_lowered_fit_v3_1 = lowered_fit


def hard_gaps(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    gaps = _hard_gaps_v3_1(plan, master)
    flagged = {str(r.get("verbatim", "")).strip() for r in plan.get("jd_requirements", [])
               if isinstance(r, dict) and r.get("required_section") is True}
    for g in gaps:
        if g.get("verbatim") in flagged:
            g["required_section"] = True
    return gaps


def lowered_fit(fit: str, gaps: list[dict[str, Any]]) -> str:
    value = _lowered_fit_v3_1(fit, gaps)
    if any(g.get("status") == "unsupported" and g.get("required_section") for g in gaps):
        return "Low"
    if _v347_on("fit_guard_v349"):   # v3.4.9a fix 3: Low only from a must-have gap (or a blocker, through gating_assessment)
        return v349_fit_guard(value, gaps)
    return value


# ---------------------------------------------------------------------------
# "ranking": "auto" lets the script rank projects from the JD and role family.
# ---------------------------------------------------------------------------

def auto_project_scores(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> dict[str, float]:
    pw = {"must": 3.0, "high": 2.0, "medium": 1.0}
    # One entry per JD requirement: a project proves it if it matches ANY spelling (the term, an alias, or an OR-list
    # alternative), and earns its weight once. Which member of an OR list became the "term" never changes the ranking.
    groups: dict[str, tuple[float, list[str]]] = {}
    def _add(key: str, w: float, spell: list[str]):
        spell = [s for s in dict.fromkeys(str(x).strip() for x in spell) if s]
        if not spell:
            return
        old = groups.get(key)
        groups[key] = (max(w, old[0]), list(dict.fromkeys(old[1] + spell))) if old else (w, spell)
    for req in plan.get("jd_requirements", []):
        if isinstance(req, dict) and req.get("supported") is not False:
            term0 = str(req.get("term", "")).strip()
            _add(term0.casefold(), pw.get(str(req.get("priority", "")).lower(), 0.5), [term0] + list(req.get("aliases", [])) + list(req.get("alternatives", [])))
    covered = {s.casefold() for _, sp in groups.values() for s in sp}
    for k in jd_named_pool_terms(raw_jd, master):
        if k.casefold() not in covered:
            _add(k.casefold(), 1.0, [k])
    for th in plan.get("jd_themes", []):
        t = str(th).replace("_", " ")
        _add("theme:" + t.casefold(), 1.0, [t])
    profile = role_family_profile(plan, master) or {}
    pref = profile.get("preferred_projects", [])
    avoid = set(profile.get("avoid_projects", []))
    corpora = {pid: " | ".join([*pr.get("tech", []), *pr.get("tags", []), *pr.get("header_priority_tech", []),
                                *[x for it in pr.get("evidence_items", {}).values() for x in it.get("terms", [])]])
               for pid, pr in master["projects"].items()}
    hits = {k: [pid for pid, c in corpora.items() if any(boundary_contains_plural(c, s) for s in sp)] for k, (w, sp) in groups.items()}
    weights = {k: w for k, (w, sp) in groups.items()}
    scores = {}
    for pid, pr in master["projects"].items():
        s = 0.0
        for k, w in weights.items():
            if pid in hits[k]:
                s += w
                if len(hits[k]) == 1 and w >= 2:
                    s += w  # only this project proves a must/high requirement
        if pid in pref:
            s += (len(pref) - pref.index(pid)) * 2.5
        if pid in avoid:
            s -= 100
        scores[pid] = round(s, 2)
    fam = str(plan.get("role_family", ""))
    dom = jd_domain(raw_jd)
    plan["_jd_domain"] = dom
    boost = {"ai": ("ripple", "goingonce"), "ml": ("fraud",)}.get(dom["lead"], ())
    boost = [b for b in boost if b in scores and b not in avoid]
    if boost and fam in ("general_swe", "backend", "fullstack", "data_engineering", "sdet_quality"):
        for b in boost:
            scores[b] = round(scores[b] + 6.0, 2)
        if fam == "general_swe":
            # the product's domain decides the lead project for a generic title
            lead = max(boost, key=lambda b: scores[b])
            best = max(scores.values())
            if scores[lead] < best:
                scores[lead] = round(best + 0.01, 2)
    # RIPPLE (AI developer tooling) leads only for AI/ML/testing postings; the resume-pipeline project only for LLM-tooling postings.
    _ai = dom["lead"] == "ai"
    if "ripple" in scores and not _ai and fam not in ("ai_llm", "data_science_ml", "sdet_quality"):
        scores["ripple"] = round(scores["ripple"] - (10.0 if fam == "data_engineering" else 6.0), 2)
    if "tailor_pipeline" in scores and not (_ai and re.search(r"\b(evals?|evaluation|llm (?:platform|tooling|infrastructure)|ai platform|prompts?|orchestrat\w+|guardrails?|retr(?:y|ies)|failover)\b", raw_jd, re.I)):
        scores["tailor_pipeline"] = round(scores["tailor_pipeline"] - 20.0, 2)
    if fam == "ai_llm" and "ripple" in scores and len(re.findall(r"\b(?:evals?|evaluations?|benchmark\w*)\b", raw_jd, re.I)) >= 3:
        scores["ripple"] = round(scores["ripple"] + 4.0, 2)
        pref = ["ripple"] + [x for x in pref if x != "ripple"]
    # Pintos (an OS kernel project) is a top-3 project only for systems roles or postings that name low-level work.
    if "pintos" in scores and fam != "systems" and not re.search(r"\b(c|c\+\+|operating systems?|kernel|embedded|firmware|low[- ]level|systems programming|syscalls?|multithread\w*|concurrency)\b", raw_jd, re.I):
        scores["pintos"] = round(scores["pintos"] - 8.0, 2)
    # The role family's anchor project (first preferred) leads for a specific family (3 bullets, cover-letter P2).
    if pref and fam != "general_swe" and pref[0] not in avoid:
        best = max(scores.values())
        if scores[pref[0]] < best:
            scores[pref[0]] = round(best + 0.01, 2)
    # Every must-have that only one project can prove gets that project onto the page.
    must_keys = {k for k, w in weights.items() if w >= 3}
    # concept skills (Debugging, Code Review, Backend Development, ...) and anything the Experience section already
    # proves never force a project onto the page; forcing is for concrete technologies such as C or Kafka
    concept = {str(globals().get("_CANON", {}).get(c.casefold(), c)).casefold() for c in globals().get("_CONCEPT_TERMS", [])}
    exp_text = " ".join(b for e in master.get("experience", []) for b in e.get("bullets", []))
    forced = [hits[k][0] for k in must_keys if len(hits[k]) == 1 and hits[k][0] not in avoid
              and not any(sp.casefold() in concept for sp in groups[k][1]) and not any(boundary_contains_plural(exp_text, sp) for sp in groups[k][1])]
    if forced:
        top = sorted(scores, key=lambda k: (-scores[k], k))[:3]
        for pid in dict.fromkeys(forced):
            if pid not in top:
                third = top[-1]
                scores[pid] = round(scores[third] + 0.01, 2)
                top = sorted(scores, key=lambda k: (-scores[k], k))[:3]
    return scores


def apply_auto_ranking(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    if raw_plan.get("ranking") != "auto":
        return
    scores = auto_project_scores(raw_plan, master, raw_jd)
    raw_plan["project_scores"] = scores
    raw_plan["ranking"] = expected_ranking_from_scores(raw_plan) or sorted(scores, key=lambda k: (-scores[k], k))[:3]
    raw_plan["_ranking_auto"] = True


# ---------------------------------------------------------------------------
# Eligibility: also scan the raw JD, and treat any clearance requirement as a
# blocker for a non-citizen (U.S. security clearances require citizenship).
# ---------------------------------------------------------------------------

_eligibility_blockers_v3_1 = eligibility_blockers


def eligibility_blockers(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, str]]:
    blockers = _eligibility_blockers_v3_1(plan, master)
    kinds = {b["type"] for b in blockers}
    profile = master.get("candidate_eligibility", {})
    raw = str(plan.get("_raw_jd_text", ""))
    raw = re.sub(r"\bU\.S\.", "US", raw)
    sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n", raw) if s.strip()]
    def add(kind, text, reason):
        if kind not in kinds:
            blockers.append({"type": kind, "requirement": text[:200], "reason": reason}); kinds.add(kind)
    for s in sentences:
        low = s.casefold()
        if profile.get("us_citizen") is False:
            if re.search(r"\bu\.?s\.? citizen(ship)?\b|\bus citizen", low):
                add("citizenship", s, "Candidate is not a U.S. citizen.")
            if "clearance" in low and re.search(r"requir|must|obtain|eligib|ability to|active|secret|top secret|dod", low):
                add("clearance", s, "U.S. security clearances require U.S. citizenship; the candidate is not a citizen.")
        if re.search(r"bachelor", low) and not re.search(r"master|graduate degree|advanced degree|m\.s\.|\bms\b|ph\.?d", low) and (
                re.search(r"(pursuing|enrolled in|working toward|currently (?:in|attending))\s+(?:a |an |their )?bachelor", low)
                or re.search(r"(completed|earned|received|graduated|conferred)[^.]{0,80}(within|in) the (last|past) (\d+|six|twelve|eighteen) months", low)):
            add("degree_recency", s, "Posting is limited to current or recent (last ~12 months) bachelor's students; the candidate finished the bachelor's in May 2023 and is a master's student.")
        if profile.get("requires_future_employer_sponsorship") is True and sponsorship_denied(low):
            add("work_authorization_or_sponsorship", s, "Candidate plans to use F-1 OPT and will need future employer sponsorship.")
    # Timing checks (warnings, never blocking): a graduate cycle or a start date before the February 2027 graduation.
    months = {m: i for i, m in enumerate("jan feb mar apr may jun jul aug sep oct nov dec".split(), 1)}
    role = str(plan.get("application", {}).get("role", ""))
    for s in [role] + sentences:
        low = s.casefold()
        g = re.search(r"\b(?:new (?:college )?grad(?:uate)?s?|ncg|university grad(?:uate)?s?|class of)\W{0,3}(20\d\d)\b|\b(20\d\d)\W{0,3}(?:new |university |college )?grad(?:uate)?s?\b", low)
        if g:
            y = int(g.group(1) or g.group(2))
            if y < 2027:
                add("graduation_year", s, f"Timing check: the posting targets {y} graduates; the candidate graduates in February 2027. Confirm the hiring cycle before applying.")
        st = re.search(r"\bstart(?:s|ing)?\b(?:\s+date)?[^.]{0,40}?\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?,?\s+(20\d\d)\b"
                       r"|\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?,?\s+(20\d\d)\s+(?:start|onward|and beyond|and later)", low)
        if st:
            mon = months[(st.group(1) or st.group(3))[:3]]; yr = int(st.group(2) or st.group(4))
            if (yr, mon) < (2027, 2):
                add("start_date", s, "Timing check: the posting mentions a start before the candidate's February 2027 graduation; OPT work can begin only after graduation and EAD approval.")
    return blockers


# ---------------------------------------------------------------------------
# Deterministic JD reader: "jd_requirements": "auto", "role_family": "auto",
# "tagline_id": "auto", "jd_themes": "auto", "fit": "auto".
# ---------------------------------------------------------------------------

_GENERAL_TECH = [
    "TypeScript", "Node.js", "NodeJS", "Vue", "Vue.js", "Angular", "Next.js", "Redux", "Tailwind", "jQuery", "Svelte",
    "Kotlin", "Swift", "Objective-C", "Rust", "Scala", "C#", ".NET", "ASP.NET", "Ruby", "Rails", "Ruby on Rails", "PHP", "Laravel",
    "Perl", "Tcl", "Bash", "Shell", "PowerShell", "MATLAB", "R", "SAS", "Julia", "Haskell", "Elixir", "Lua", "Dart", "Flutter", "React Native",
    "C++", "CUDA", "OpenGL", "Vulkan", "Metal", "Unity", "Unreal", "ROS", "RTOS", "FPGA", "Verilog", "VHDL",
    "Terraform", "Ansible", "Puppet", "Chef", "Pulumi", "CloudFormation", "CDK", "Helm", "ArgoCD", "Jenkins", "CircleCI", "GitLab", "GitLab CI",
    "Bitbucket", "Perforce", "Bazel", "CMake", "Make", "Gradle",
    "Spark", "Apache Spark", "PySpark", "Hadoop", "Hive", "Airflow", "Apache Airflow", "dbt", "Snowflake", "BigQuery", "Redshift", "Databricks",
    "ClickHouse", "DuckDB", "Druid", "Apache Pinot", "Kafka Streams", "Temporal", "Celery", "Sidekiq", "OpenTelemetry", "LangSmith", "Langfuse",
    "Flink", "Beam", "Presto", "Trino", "Delta Lake", "Iceberg", "Informatica", "Talend", "Fivetran",
    "Tableau", "Power BI", "Looker", "Excel", "Grafana", "Prometheus", "Datadog", "Splunk", "New Relic", "ELK", "Elasticsearch", "OpenSearch",
    "GCP", "Google Cloud", "Google Cloud Platform", "Azure", "Azure DevOps", "Lambda", "ECS", "EKS", "S3", "DynamoDB", "SQS", "SNS", "Step Functions",
    "SageMaker", "Vertex AI", "Bedrock", "Firebase", "Supabase", "Heroku", "Vercel",
    "Oracle", "SQL Server", "Cassandra", "Couchbase", "Neo4j", "MariaDB", "SQLite", "Pinecone", "Weaviate", "FAISS", "Milvus", "Chroma",
    "RabbitMQ", "ActiveMQ", "Kinesis", "Pub/Sub", "gRPC", "GraphQL", "Thrift", "Protobuf", "OpenAPI", "SOAP",
    "TensorFlow", "Keras", "JAX", "Hugging Face", "Transformers", "LangChain", "LlamaIndex", "OpenAI", "MLflow", "Kubeflow", "Ray", "XGBoost",
    "LightGBM", "spaCy", "NLTK", "OpenCV", "ONNX", "TensorRT", "Triton", "vLLM",
    "RAG", "retrieval-augmented generation", "vector database", "vector databases", "embeddings", "fine-tuning", "LLM fine-tuning", "RLHF",
    "NLP", "natural language processing", "computer vision", "recommender systems", "recommendation systems", "information retrieval",
    "A/B testing", "experimentation", "statistics", "data mining", "time series", "reinforcement learning",
    "Selenium", "Cypress", "Playwright", "Jest", "Mocha", "JUnit", "TestNG", "Postman",
    "Jira", "Confluence", "Figma", "Salesforce", "ServiceNow", "SAP", "Workday", "ITSM", "ArcGIS", "CAD",
    "SAML", "OIDC", "OAuth", "SSO", "Kerberos", "TLS", "TCP/IP", "TCP", "UDP", "DNS", "HTTP", "networking",
    "Continuous Deployment", "continuous delivery", "A/B tests", "A/B test", "feature engineering", "infrastructure as code", "secrets management", "observability", "CI/CD", "microfrontends", "Hibernate", "Spring", "Express", "FastAPI", "Flask",
    "RPA", "Robotic Process Automation", "UiPath", "Automation Anywhere", "Power Automate", "Blue Prism", "Brity Works", "UI/UX", "UX design",
    "Windows Server", "wireframes", "usability testing", "accessibility", "responsive design", "relational databases", "relational database",
    "schema design", "database design", "containerization", "unit tests", "integration tests", "AWS", "Amazon Web Services", "EC2", "RDS", "Windows", "Unix", "macOS", "iOS", "Android", "Visual Studio", "Eclipse", "IntelliJ", "VS Code", "Codex", "Copilot", "ClaudeCode",
]

_REQ_HEAD = re.compile(r"(requirement|qualification|what you(?:'|’)?ll (?:bring|need)|what you bring|you have|what we(?:'|’)?re looking for|what we are looking for|"
                       r"what we need to see|must[- ]have|who you are|about you|what it takes|you will have|you(?:'|’)?ll have|skills|experience|"
                       r"to be successful|knowledge, skills|minimum|basic|required|essential)", re.I)
_PREF_HEAD = re.compile(r"(additional (?:qualifications|skills|experience|requirements)|preferred|nice[- ]to[- ]have|nice if you have|bonus|a plus|plus if|ways to stand out|stand out|desired|good to have|extra credit|pluses)", re.I)
_RESP_HEAD = re.compile(r"(responsibilit|what you(?:'|’)?ll (?:be )?do|what you will (?:be )?do|what you(?:'|’)?ll (?:own|build|work on)|you will|in this role|duties|the role|role overview|role summary|"
                        r"what you(?:'|’)?ll work on|day to day|your role|job description|about the job)", re.I)
_OTHER_HEAD = re.compile(r"(examples?,? not requirements|project examples|example projects|sample projects|possible projects|benefit|compensation|salary|pay range|about us|about the company|who we are|equal|eeo|accommodation|privacy|perks|"
                         r"why join|why .* is different|our values|culture|location and work|how to apply|disclaimer|commitment)", re.I)
_OR_CUE = re.compile(r"\b(or|one of|(?:\d+|one) or more|at least one|such as|e\.g\.|eg\.|any of|similar|equivalent|like|including|etc)(?![\w])", re.I)
_SOFT = re.compile(r"\b(communicat|team ?player|collaborat|problem[- ]solving|curios|ownership|self-motivated|detail-oriented|passion|humble|"
                   r"interpersonal|written and verbal|work independently|fast-paced|growth mindset)\b", re.I)


_STRONG_HEAD = re.compile(r"^(?:additional (?:qualifications|skills|experience|requirements)|project examples|example projects|examples?,? not requirements|how we (?:evaluate|hire|interview)|what you(?:'|’)?(?:ll| will) (?:be doing|do|bring|need|work on|own|build)|what you bring|what you have|you have|you will|you(?:'|’)?ll|who you are|about (?:you|the|us|this)|"
                          r"requirements|requirement|qualifications|minimum|basic|preferred|desired|nice[- ]to[- ]have|bonus|ways to stand out|what it takes|"
                          r"what we(?:'|’)?re looking for|what we are looking for|what we need|responsibilit|key (?:job )?responsibilit|duties|the role|role overview|"
                          r"in this role|your role|day to day|job description|description|overview|benefits|perks|compensation|why\b|who we are|our |must[- ]have|"
                          r"skills (?:&|and) (?:qualifications|experience|technologies)|required (?:skills|qualifications|experience)|essential|location)", re.I)


def _is_heading(line: str, raw: str | None = None) -> bool:
    s = line.strip()
    if not s or len(s) > 90:
        return False
    if raw is not None and raw.lstrip()[:1] in ("-", "•", "*", "·", "▪", "●", "–"):
        return False
    if s.endswith(":"):
        return True
    words = s.split()
    if len(words) > 8 or s.endswith((".", ";", ",")):
        return False
    longw = [w for w in words if len(w) > 3 and w[0].isalpha()]
    title_case = bool(longw) and all(w[0].isupper() for w in longw)
    return title_case or s.isupper() or bool(_STRONG_HEAD.match(s))


_INTRO_HEAD = re.compile(r"^(?:job )?description:?$|^why\b|^about\b(?!\s+(?:you|the role|the job|the position|the team|this role))|^overview:?$|^company overview|^who we are|^the company|^our mission|^the opportunity:?$", re.I)


def _section_of(head: str) -> str | None:
    if head.startswith("("):
        return None
    if re.search(r"^(?:skills\s*(?:&|and)\s*technologies|skills|technologies|tech stack|key skills|top skills)\s*:?$", head.strip(), re.I):
        return "skills_list"
    if _RESP_HEAD.search(head) and re.search(r"role overview|role summary|about the (?:role|job|position|team)", head, re.I):
        return "resp"
    if re.match(r"^\W*about (?:the|this|our) (?:[\w-]+ ){0,3}?(?:team|role|job|position)s?\b", head.strip(), re.I):
        return "resp"   # v3.4.5 (A2): "About the Team and Role" ends a company intro ("About Quora")
    if _INTRO_HEAD.search(head.strip()):
        return "intro"
    if _OTHER_HEAD.search(head):
        return "other"
    if _PREF_HEAD.search(head):
        return "preferred"
    if _RESP_HEAD.search(head) and not _REQ_HEAD.search(head):
        return "resp"
    if _REQ_HEAD.search(head):
        return "required"
    if re.search(r"skills\s*&\s*technologies", head, re.I):
        return "skills_list"
    return None


def _lexicon(master: dict[str, Any]) -> list[str]:
    terms = []
    for vals in master["skills"]["supported_pool"].values():
        terms.extend(vals)
    terms.extend(master["skills"].get("normalization", {}).keys())
    terms.extend(master.get("never_supported_terms", []))
    terms.extend(_GENERAL_TECH)
    terms.extend(_CONCEPT_TERMS)
    seen, out = set(), []
    for t in sorted(terms, key=len, reverse=True):
        k = t.casefold()
        if k not in seen and len(t) >= 1:
            seen.add(k); out.append(t); _LEXCASE.setdefault(k, t)
    return out


_FIELD_TERMS = {"statistics", "machine learning", "nlp", "computer vision", "data science", "mathematics", "information systems", "artificial intelligence",
                "ai", "information retrieval", "deep learning", "operations research", "data mining", "physics", "robotics", "information technology"}
_CONCEPT_TERMS = ["software development life cycle", "software development lifecycle", "sdlc", "object-oriented design", "object oriented design", "object-oriented programming", "object oriented programming", "classification", "socket programming", "sockets", "data quality checks", "data quality", "relational database design", "backend software", "backend development", "backend services", "back-end development", "back-end services", "APIs", "API",
                  "service interfaces", "web services", "data modeling", "data models", "monitoring", "full-stack", "full stack", "across the stack",
                  "data pipelines", "data pipeline", "processing pipelines", "asynchronous jobs", "background processing", "background jobs",
                  "asynchronous processing", "message queues", "troubleshooting", "debugging", "automated tests", "automated testing", "test automation",
                  "code reviews", "code review", "object-oriented programming", "object-oriented design", "OOP", "concurrency", "multithreading",
                  "releasing software in production", "production systems", "in production", "deployment",
                  "AI-assisted development tools", "AI-assisted development", "AI coding assistants", "AI coding tools", "AI-assisted coding",
                  "AI-powered systems", "AI-powered applications", "AI-powered products", "AI-powered features", "AI-powered experiences",
                  "language model APIs", "LLM APIs", "prompting", "workflow automation", "automated workflows", "containers", "version control", "data processing", "cloud platforms",
                  "well-tested", "well tested", "testing",
                  "evaluate AI features", "evaluating AI features", "evaluate AI-generated responses", "evaluating AI-generated responses",
                  "evaluate AI outputs", "evaluating AI outputs", "AI evaluation", "LLM evaluation", "evals"]
_CASE_SENSITIVE = {"Make", "Shell", "Metal", "Ray", "Chef", "Express", "Beam", "Excel", "Spring", "Go", "Rust", "Swift", "Unity", "Ruby", "Julia", "Dart", "Triton", "Lambda", "Chroma", "Presto", "Hive", "Puppet", "Flask", "Rails", "ELK", "SAS", "CAD", "SAP", "ARM", "R", "C"}


def _find_terms(line: str, lex: list[str]) -> list[tuple[int, str]]:
    found, taken = [], []
    for term in lex:
        if term in _CASE_SENSITIVE:
            pat = r"(?<![A-Za-z0-9])" + re.escape(term) + r"(?![A-Za-z0-9])"
            flags = 0
        elif len(term) <= 2:
            pat = r"(?<![A-Za-z0-9+#.])" + re.escape(term) + r"(?![A-Za-z0-9+#])"
            flags = 0
        else:
            pat = r"(?<![A-Za-z0-9])" + re.escape(term) + r"(?![A-Za-z0-9])"
            flags = re.I
        for mm in re.finditer(pat, line, flags):
            a, b = mm.span()
            if any(not (b <= x or a >= y) for x, y in taken):
                continue
            if term.casefold() == "spring" and re.match(r"\s*(?:'|’)?\d{2,4}|\s+(?:semester|term|quarter|graduat|internship|cohort|start)", line[b:b+15], re.I):
                continue
            if term.casefold() == "testing" and re.search(r"\b(?:genetic|drug|a/b|ab|usability|user|load|stress|penetration|security|performance|medical|background|pre-employment|beta|market|ux)[\s-]*$", line[max(0, a - 22):a], re.I):
                continue
            if term in ("R", "C", "Go", "Make", "Shell", "Metal", "Ray", "Chef", "Express", "Spring", "Excel", "Beam", "Transformers", "statistics", "experimentation"):
                ctx = line[max(0, a - 25): b + 25]
                if term == "Go" and not re.search(r"\bGo\b(?!\s+(?:to|beyond|above|through|live)\b)", ctx):
                    continue
                if term in ("R", "C") and not re.search(r"(language|programming|\bC\+\+|Python|Java|MATLAB|SQL|,|/|\bor\b)", ctx):
                    continue
                if term in ("Make", "Shell", "Metal", "Ray", "Chef", "Express", "Beam", "Excel") and not re.search(r"(,|/|\(|\)|\btools?\b|build)", ctx):
                    continue
                if term == "statistics" and not re.search(r"(probabilit|model|method|machine|analy|data|ML\b|math)", ctx, re.I):
                    continue
                if term == "experimentation" and not re.search(r"(A/B|framework|platform|design|online|product|metric)", ctx, re.I):
                    continue
            taken.append((a, b)); found.append((a, line[a:b]))
            break
    found.sort()
    return found


_CANON = {
    "software development life cycle": "SDLC", "software development lifecycle": "SDLC", "sdlc": "SDLC", "object-oriented design": "OOP", "object oriented design": "OOP", "object-oriented programming": "OOP", "object oriented programming": "OOP", "classification": "Classification",
    "socket programming": "Socket Programming", "sockets": "Socket Programming", "data quality checks": "Data Quality", "data quality": "Data Quality", "relational database design": "Database Design",
    "backend software": "Backend Development", "backend development": "Backend Development", "backend services": "Backend Development",
    "back-end development": "Backend Development", "back-end services": "Backend Development", "apis": "REST APIs", "api": "REST APIs",
    "service interfaces": "REST APIs", "web services": "REST APIs", "data modeling": "Database Design", "data models": "Database Design",
    "monitoring": "Application Monitoring", "full-stack": "Full-Stack Development", "full stack": "Full-Stack Development",
    "across the stack": "Full-Stack Development", "data pipelines": "Data Pipelines", "data pipeline": "Data Pipelines", "processing pipelines": "Data Pipelines",
    "asynchronous jobs": "Event-Driven Architecture", "background processing": "Event-Driven Architecture", "background jobs": "Event-Driven Architecture",
    "asynchronous processing": "Event-Driven Architecture", "message queues": "Event-Driven Architecture", "troubleshooting": "Debugging",
    "debugging": "Debugging", "automated tests": "Unit Testing", "automated testing": "Unit Testing", "test automation": "Unit Testing",
    "code reviews": "Code Review", "code review": "Code Review", "object-oriented programming": "OOP", "object-oriented design": "OOP",
    "multithreading": "Concurrency", "releasing software in production": "Production Deployment", "production systems": "Production Deployment",
    "in production": "Production Deployment", "deployment": "Production Deployment",
    "llm": "LLMs", "llms": "LLMs", "large language model": "LLMs", "large language models": "LLMs",
    "nlp": "NLP", "natural language processing": "NLP",
    "rag": "RAG", "retrieval-augmented generation": "RAG", "retrieval augmented generation": "RAG",
    "golang": "Go", "typescript": "TypeScript", "claudecode": "Claude Code", "copilot": "GitHub Copilot",
    ".net framework": ".NET", ".net": ".NET", "azure dev ops": "Azure DevOps", "azure devops": "Azure DevOps",
    "spark": "Apache Spark", "apache spark": "Apache Spark", "airflow": "Apache Airflow", "apache airflow": "Apache Airflow",
    "mlflow": "MLflow", "triton": "NVIDIA Triton", "vllm": "vLLM", "tensorrt": "TensorRT", "k8s": "Kubernetes",
    "statistics": "Statistics", "data mining": "Data Mining", "vector database": "vector databases", "vector databases": "vector databases",
    "fine-tuning": "LLM fine-tuning", "llm fine-tuning": "LLM fine-tuning", "recommendation systems": "recommender systems",
    "a/b testing": "A/B testing", "a/b tests": "A/B testing", "a/b test": "A/B testing", "continuous deployment": "Continuous Deployment", "continuous delivery": "Continuous Deployment", "feature engineering": "Feature Engineering", "ci/cd": "Continuous Integration", "node.js": "Node.js", "nodejs": "Node.js",
    "google cloud": "GCP", "google cloud platform": "GCP", "gcp": "GCP", "hugging face": "Hugging Face",
    "robotic process automation": "RPA", "ux design": "UI/UX", "relational database": "Relational Databases", "relational databases": "Relational Databases",
    "schema design": "Database Design", "database design": "Database Design", "containerization": "Docker", "unit tests": "Unit Testing",
    "integration tests": "Integration Testing", "wireframes": "UI/UX", "usability testing": "UI/UX", "aws": "AWS", "amazon web services": "AWS", "ec2": "AWS", "rds": "AWS", "data structures and algorithms": "Data Structures", "data structures & algorithms": "Data Structures",
    "ai-assisted development tools": "Claude Code", "ai-assisted development": "Claude Code", "ai coding assistants": "Claude Code",
    "ai coding tools": "Claude Code", "ai-assisted coding": "Claude Code",
    "ai-powered systems": "LLM Integration", "ai-powered applications": "LLM Integration", "ai-powered products": "LLM Integration",
    "ai-powered features": "LLM Integration", "ai-powered experiences": "LLM Integration", "language model apis": "LLM Integration", "llm apis": "LLM Integration",
    "well-tested": "Unit Testing", "well tested": "Unit Testing", "testing": "Unit Testing",
    "evaluate ai features": "Model Evaluation", "evaluating ai features": "Model Evaluation", "evaluate ai-generated responses": "Model Evaluation",
    "evaluating ai-generated responses": "Model Evaluation", "evaluate ai outputs": "Model Evaluation", "evaluating ai outputs": "Model Evaluation",
    "ai evaluation": "Model Evaluation", "llm evaluation": "Model Evaluation", "evals": "Model Evaluation",
    "prompting": "Prompt Engineering", "workflow automation": "Agentic Workflows", "automated workflows": "Agentic Workflows", "containers": "Docker", "version control": "Git", "data processing": "Data Pipelines", "cloud platforms": "AWS",
    "computer vision": "Computer Vision", "information retrieval": "Information Retrieval", "time series": "Time Series",
}
_LEXCASE: dict[str, str] = {}
_CANON_ALIAS = {"AWS": ["AWS", "AWS (EC2/RDS)", "EC2", "RDS"], "Data Structures": ["Data Structures", "Algorithms"],
                "Claude Code": ["Claude Code", "Cursor", "GitHub Copilot"], "Unit Testing": ["Unit Testing", "testing", "automated testing"], "LLM Integration": ["LLM Integration", "LLMs", "AI Agents"],
                "Model Evaluation": ["Model Evaluation", "evaluation", "AI evaluation"]}


def _norm_term(raw: str, master: dict[str, Any]) -> str:
    k = raw.casefold().strip()
    if k in _CANON:
        raw = _CANON[k]
    n = normalize_skill_name(raw, master)
    canon = canonical_pool_match(n, master)
    if canon:
        return canon
    return _CANON.get(k) or _LEXCASE.get(k, raw)


def _grad_window_ok(text: str) -> bool | None:
    if v348b_on():   # v3.4.8b: December 2026 graduation, one month of tolerance
        return v348b_window_ok(text)
    months = "jan feb mar apr may jun jul aug sep oct nov dec winter spring summer fall".split()
    yrs = [int(y) for y in re.findall(r"\b(20[2-3]\d)\b", text)]
    if not yrs:
        return None
    lo, hi = min(yrs), max(yrs)
    return lo <= 2027 <= hi or (2026 in yrs and re.search(r"\b(dec|december|winter)", text, re.I) is not None)


def parse_jd_requirements(raw_jd: str, master: dict[str, Any], title: str = "") -> list[dict[str, Any]]:
    lex = _lexicon(master)
    section = "pre"
    strict = False
    reqs: list[dict[str, Any]] = []
    seen: set[str] = set()
    prof_years = max(1, _experience_months_from_master(master) // 12)

    def add(term, verbatim, priority, req_section, aliases=None, supported=None, qual=False):
        key = term.casefold()
        if key in seen:
            for r in reqs:
                if r["term"].casefold() != key:
                    continue
                for a in [x for a0 in (aliases or []) for x in _CANON_ALIAS.get(a0, [a0])]:
                    if a not in r["aliases"] and (supported is None or supported):
                        r["aliases"].append(a)
                if {"must": 0, "high": 1, "medium": 2}[priority] < {"must": 0, "high": 1, "medium": 2}[r["priority"]]:
                    r["priority"] = priority
                    if req_section:
                        r["required_section"] = True
            return
        seen.add(key)
        al = list(dict.fromkeys([x for a in (aliases or []) for x in _CANON_ALIAS.get(a, [a])]))
        sup = master_supports_requirement(term, al, master) if supported is None else supported
        e = {"term": term, "verbatim": verbatim, "aliases": al, "priority": priority, "supported": sup}
        if req_section:
            e["required_section"] = True
        reqs.append(e)

    camel = sorted({t for t in lex if re.search(r"[a-z][A-Z]", t)}, key=len, reverse=True)

    def _unglue(txt: str) -> str:
        if len(re.findall(r"[a-z\)][A-Z]", txt)) < 3:
            return txt
        keep = {}
        for i, t in enumerate(camel):
            if t in txt:
                key = f"\x00{i}\x00"; keep[key] = t; txt = txt.replace(t, key)
        txt = re.sub(r"([a-z\)\+])([A-Z])", r"\1, \2", txt)
        for key, t in keep.items():
            txt = txt.replace(key, t)
        return txt
    raws, lines = [], []
    for rw in [_unglue(x) for x in raw_jd.splitlines()]:
        st = re.sub(r"^[^\w(]+", "", rw.strip()).strip()
        st = re.sub(r"[*_#]+$", "", st).strip()
        if rw.strip()[:1] and not rw.strip()[:1].isalnum() and rw.strip()[:1] not in "(\"'" and st != rw.strip():
            rw = "- " + st if not _is_heading(st) else st
        parts = re.split(r"(?<=[a-z0-9)][.!?])\s+(?=[A-Z])", st)
        for i, part in enumerate(parts):
            raws.append(rw if i == 0 else "- " + part); lines.append(part)
    structured = any(_is_heading(ln, rw) and _section_of(ln) in ("required", "preferred", "resp") for ln, rw in zip(lines, raws) if ln)
    for line, rawl in zip(lines, raws):
        if not line:
            continue
        if _is_heading(line, rawl):
            sec = _section_of(line)
            if sec:
                section = sec
                strict = sec == "required" and bool(re.search(r"required|must|minimum|basic|essential|need to see", line, re.I))
                continue
        if section == "other" or section == "intro":
            continue
        if re.search(r"we believe|human right|equal opportunity|committed to (?:inclusion|diversity)|fundamental right", line, re.I):
            continue
        if section == "pre" and structured and len(line.split()) > 35:
            continue
        neg_req = bool(re.search(r"\b(?:not|never|isn't|aren't|no)\s+(?:be\s+)?(?:strictly\s+)?(?:required|mandatory|necessary|essential|expected|a must|needed)\b|n't\s+(?:required|mandatory|necessary|essential|needed)\b|\b(?:helpful|useful|optional|welcome|valuable)\b", line, re.I))
        pref_inline = neg_req or bool(re.search(r"\b(preferred|a plus|is a plus|nice to have|bonus|ideally|desired)\b", line, re.I))
        if re.match(r"(nice[- ]to[- ]haves?|bonus|preferred|pluses|good to have)\s*:", line, re.I):
            pref_inline = True
        req_inline = (not pref_inline) and bool(re.search(r"\b(required|must have|must be|is a must|mandatory)\b", line, re.I)
                                                or re.match(r"(requirements?|required|must[- ]haves?|qualifications)\s*:", line, re.I))
        if req_inline:
            priority = "must"
        elif section in ("required",):
            priority = "medium" if pref_inline else "must"
        elif section == "preferred":
            priority = "medium"
        elif section in ("resp", "skills_list"):
            priority = "high"
        else:
            priority = "medium" if pref_inline else "high"
        req_sec = (section == "required" and strict and not pref_inline) or req_inline
        low = line.casefold()

        # qualifications
        degree_line = False
        if title and " ".join(line.split()).casefold() == " ".join(title.split()).casefold():
            continue
        if re.search(r"\b(bachelor|master|b\.s\.|m\.s\.|bs/ms|ms/bs|degree|ph\.?d|education in a?n? ?(?:quantitative|technical|related)?\s*field)|\b(?:ms|bs|ba|msc|bsc)\b(?= in| or|/|,)", low) and section not in ("resp",) \
                and len(line.split()) >= 4 and not re.search(r"not (?:expected|required)", low):
            degree_line = True
            phd_only = re.search(r"\bph\.?d", low) and not re.search(r"master|m\.s\.|bachelor|b\.s\.|ms/|/ms|bs/|/bs", low)
            cs_ok = re.search(r"computer|software|information|data science|technical|stem|related|equivalent|engineering|mathemat|statistic|quantitative", low)
            non_cs = re.search(r"chemical|physics|chemistry|mechanical|electrical|biolog|finance|accounting|business|nursing", low)
            if phd_only and not pref_inline:
                add("PhD degree", line[:80], priority, req_sec, supported=False)
            elif non_cs and not re.search(r"computer|software|information tech|data science|\bcs\b|engineering|mathemat|\bmath\b|related|equivalent|\bstem\b", low):
                add("degree in a non-CS field", line[:80], priority, req_sec, supported=False)
            elif not phd_only:
                add("degree in Computer Science", line[:80], priority, False, ["degree in Computer Science"], True)
        if re.search(r"graduat", low) and re.search(r"20[2-3]\d", low):
            ok = _grad_window_ok(line)
            add("graduation in 2027" if ok else "graduation window", line[:80], priority, req_sec and not ok, supported=bool(ok))
        if re.search(r"(?<!non-)(?<!non )\binternship", low) and re.search(r"requir|must|previous|prior|experience", low):
            add("internship experience", line[:80], priority, False, ["internship experience"], True)
        ym = re.search(r"(\d+)\s*\+?\s*(?:-|–|to)?\s*(\d+)?\s*\+?\s*years?(?:\s+of)?(?:\s+[\w/-]+){0,5}?\s+(?:experience|work)", low) or \
            re.search(r"experience[^.;]{0,40}?(\d+)\s*\+?\s*(?:-|–|to)?\s*(\d+)?\s*\+?\s*years?", low)
        if ym:
            n = int(ym.group(1))
            if n <= prof_years:
                add("industry experience", line[:80], priority, False, ["industry experience"], True)
            else:
                add(f"{n}+ years of experience", line[:80], priority, req_sec, supported=False)
        if re.search(r"bachelor", low) and not re.search(r"master|graduate degree|advanced degree|m\.s\.|\bms\b|ph\.?d", low) and (
                re.search(r"(pursuing|enrolled in|working toward|currently (?:in|attending))\s+(?:a |an |their )?bachelor", low)
                or re.search(r"(completed|earned|received|graduated|conferred)[^.]{0,80}(within|in) the (last|past) (\d+|six|twelve|eighteen) months", low)):
            add("current or recent bachelor's student", line[:80], "must", True, supported=False)
        if re.search(r"\bu\.?s\.? citizen", low):
            add("U.S. citizenship", line[:80], "must", True, supported=False)
        if "clearance" in low and re.search(r"requir|must|obtain|eligib|active|secret|dod", low):
            add("security clearance", line[:80], "must", True, supported=False)

        hits = _find_terms(line, lex)
        if degree_line:
            hits = [(pos, raw) for pos, raw in hits if _norm_term(raw, master).casefold() not in _FIELD_TERMS]
        if not hits:
            continue
        # "including A, B, and C" lists parts that all count (AND), so it is not an example cue; "such as"/"e.g." lists are alternatives
        wide = re.search(r"\b(one of|(?:\d+|one) or more(?: of)?(?: the following)?|(?:one|1) of the following|at least one|any of|such as|e\.g\.|eg\.|like|etc|similar|equivalent)(?![\w])|\b(tools?)\s*\(", line, re.I)
        # "You'll work with technologies such as A, B and C" / "our stack includes ..." describes the team's stack: every item counts
        # (AND), but as a medium "you'll learn" item unless another line asks for it more strongly.
        stack_line = bool(re.search(r"\b(?:you(?:'|’)?ll|you will|we|our team|the team)\s+(?:\w+\s+){0,2}(?:work|works|use|uses|build|builds)\s+(?:with|on|in)?\s*(?:\w+\s+){0,3}(?:technologies|tools|stack|languages)\b"
                                   r"|\bour (?:tech(?:nology)? )?stack\b|\bstack includes\b|\btech stack:", line, re.I)) and not re.search(r"\b(one of|at least one|any of|or similar|or equivalent)\b", line, re.I)
        if stack_line:
            wide = None
            if priority == "high":
                priority = "medium"
        or_line = False
        or_spans: list[tuple[int, int]] = []
        if len(hits) > 1 and wide:
            if (wide.group(1) or "").lower() in ("etc", "similar", "equivalent"):
                or_line = True
            else:
                # the example list is the run of terms right after the cue joined only by separators
                after = [(pos, raw) for pos, raw in hits if pos >= wide.end()]
                if after:
                    end_pos = after[0][0] + len(after[0][1])
                    for pos, raw in after[1:]:
                        if re.fullmatch(r"\s*(?:,|/|\bor\b|\band\b|,\s*(?:or|and)\b)\s*", line[end_pos:pos], re.I):
                            end_pos = pos + len(raw)
                        else:
                            break
                    if wide.group(2) and line.find(")", wide.end()) > 0:
                        end_pos = line.find(")", wide.end())  # "tools (A, B, C)": every listed item is an example
                    start_pos = wide.start()
                    # "CRM software (e.g., Salesforce)", "RPA tools (e.g., UiPath, ...)": the category and its examples are one requirement
                    before = [(pos, raw) for pos, raw in hits if pos + len(raw) <= wide.start()]
                    if before:
                        bpos, braw = before[-1]
                        if re.fullmatch(r"[^,;]{0,30}\(\s*", line[bpos + len(braw):wide.start()]):
                            start_pos = bpos
                    or_spans = [(start_pos, end_pos)]
        elif len(hits) > 1 and re.search(r"\bor\b", line, re.I):
            segs, start = [], 0
            for mm in re.finditer(r",|;|\band\b", line):
                segs.append((start, mm.start())); start = mm.end()
            segs.append((start, len(line)))
            or_idx = [i for i, (a, b) in enumerate(segs) if re.search(r"\bor\b", line[a:b], re.I)]
            if len(segs) >= 3 and or_idx == [len(segs) - 1]:
                or_line = True  # "A, B, or C"
            else:
                or_spans = [segs[i] for i in or_idx]
                if or_idx and or_idx[-1] == len(segs) - 1 and len(segs) >= 3:
                    # an earlier "or" must not defeat "..., A, B, or C": the run of short term-only segments before the final "or" is one list
                    j = len(segs) - 1
                    while j - 1 >= 0 and len(line[segs[j - 1][0]:segs[j - 1][1]].split()) <= 4 and any(segs[j - 1][0] <= pos < segs[j - 1][1] for pos, _ in hits):
                        j -= 1
                    if j < len(segs) - 1:
                        or_spans = [x for x in or_spans if x[1] <= segs[j][0]] + [(segs[j][0], len(line))]
        groups: list[list[tuple[str, str]]] = []
        prev_end = None
        for pos, raw in hits:
            t = _norm_term(raw, master)
            joined = prev_end is not None and (re.fullmatch(r"\s*/\s*", line[prev_end:pos]) is not None or
                                               any(a <= prev_end - 1 < b and a <= pos < b for a, b in or_spans))
            if groups and (or_line or joined):
                if t not in [x[0] for x in groups[-1]]:
                    groups[-1].append((t, raw))
            elif not any(t == x[0] for g in groups for x in g):
                groups.append([(t, raw)])
            prev_end = pos + len(raw)
        core = {x for grp in master["skills"].get("core_baseline", {}).get("full", {}).values() for x in grp}
        for g in groups:
            if len(g) == 1:
                add(g[0][0], g[0][1], priority, req_sec, [g[0][0]])
                continue
            supported_members = [t for t, r in g if master_supports_requirement(t, [], master)]
            # a member that is already its own requirement (from another line) does not lead, so lines never merge
            supported_members.sort(key=lambda t: (t.casefold() in seen, t not in core, canonical_pool_match(t, master) is None))
            lead = supported_members[0] if supported_members else g[0][0]
            lead_raw = next(r for t, r in g if t == lead)
            # an OR list ("A, B, or C") is one requirement: the JD needs one of them, so it carries one weight and needs
            # one visible member; "alternatives" keeps each member so ATS coverage can report which ones are shown.
            # unsupported members of an OR group never become separate gaps
            add(lead, lead_raw, priority, req_sec, supported_members or [lead], bool(supported_members))
            if len(supported_members) > 1:
                for rq in reqs:
                    if rq["term"] == lead:
                        rq["alternatives"] = list(dict.fromkeys(rq.get("alternatives", [lead]) + supported_members))

    recent = [r["verbatim"] for r in reqs if r["term"] == "current or recent bachelor's student"]
    if recent:
        reqs = [r for r in reqs if not (r["term"].startswith(("Master's degree", "degree in Computer Science")) and r["verbatim"] in recent)]
    if title:
        concept_set = {c.casefold() for c in _CONCEPT_TERMS}
        for _, raw in _find_terms(title, lex):
            if raw.casefold() in concept_set or not boundary_contains(raw_jd, raw):
                continue
            t = _norm_term(raw, master)
            add(t, raw, "must", True, [t])
    for r in reqs:
        if r["supported"] and r["aliases"] and not r["term"].startswith(("Master's degree", "degree in Computer Science", "graduation", "internship", "industry experience")):
            if not any(canonical_pool_match(normalize_skill_name(a, master), master) for a in r["aliases"]):
                r["priority"] = "medium"
                r.pop("required_section", None)
    order = {"must": 0, "high": 1, "medium": 2}
    reqs.sort(key=lambda r: order[r["priority"]])
    cap = int(master.get("ats_rules", {}).get("jd_requirements_max", 25))
    med_cap = int(master.get("ats_rules", {}).get("medium_requirements_max", 12))
    out, meds = [], 0
    _LAST_PARSE_DROPPED.clear()
    for r in reqs:
        if r["priority"] == "medium" and meds >= med_cap or len(out) >= cap:
            _LAST_PARSE_DROPPED.append(r["term"])  # reported in plan_resolved_fields, never silently lost
            continue
        if r["priority"] == "medium":
            meds += 1
        out.append(r)
    return out


_LAST_PARSE_DROPPED: list[str] = []


_FAMILY_TITLE_RULES = [
    ("data_science_ml", r"machine learning|\bml\b|data scien|applied scien|research scien|deep learning"),
    ("ai_llm", r"\bai\b|\bllm|agent|forward deployed|genai|generative"),
    ("data_engineering", r"data engineer|analytics engineer|etl|data platform"),
    ("sdet_quality", r"sdet|\btest|\bqa\b|quality"),
    ("devops_cloud", r"devops|\bsre\b|site reliability|infrastructure|cloud|platform engineer|release"),
    ("systems", r"embedded|firmware|kernel|systems software|low[- ]level|\bc\+\+"),
    ("fullstack", r"full[- ]?stack|front[- ]?end|web developer|growth"),
    ("support_sustaining", r"sustaining|support engineer|application support|servicenow|salesforce developer|claims"),
    ("backend", r"back[- ]?end|\bapi\b|payments|distributed"),
]

_FAMILY_THEMES = {
    "backend": ["backend", "distributed_systems", "testing"], "fullstack": ["web_development", "backend", "saas"],
    "sdet_quality": ["testing", "quality_engineering", "sdet", "reliability"], "support_sustaining": ["support", "troubleshooting", "reliability", "testing"],
    "data_engineering": ["data_engineering", "etl", "data_quality", "databases"], "data_science_ml": ["ml", "model_evaluation", "ai"],
    "ai_llm": ["ai", "ai_agents", "agentic_ai", "llm"], "systems": ["systems", "operating_systems", "concurrency"],
    "devops_cloud": ["devops", "cloud", "infrastructure", "monitoring", "reliability", "kubernetes"], "general_swe": ["backend", "web_development", "testing"],
}


_FAMILY_BODY = {
    "ai_llm": r"\bllms?\b|\bagent|generative|\brag\b|prompt|large language|language models?|\bai[- ](?:powered|first|focused|assisted|features?|services?|products?|systems?|applications?)\b|tool calling",
    "fullstack": r"react|front[- ]?end|full[- ]?stack|javascript|typescript|\bcss\b|\bui\b",
    "backend": r"back[- ]?end|\bapis?\b|microservice|distributed|scalab",
    "support_sustaining": r"support|troubleshoot|incident|ticket|sustain|maintenan|servicenow|\bitsm\b|defect",
    "data_science_ml": r"machine learning|\bml\b|statistic|model training|data scien",
    "devops_cloud": r"kubernetes|terraform|ci/cd|devops|infrastructure",
    "systems": r"embedded|kernel|firmware|operating system|\bc\+\+",
}


_ROLE_PLACEHOLDER = re.compile(r"^\s*(?:not (?:stated|listed|given|specified|provided)\b.*|n/?a|unknown|none|tbd|-+)?\s*$", re.I)


def role_is_placeholder(role: Any) -> bool:
    return bool(_ROLE_PLACEHOLDER.match(str(role or "")))


def auto_role_family(title: str, raw_jd: str) -> str:
    if role_is_placeholder(title):
        title = ""
    t = title.casefold()
    body = raw_jd.casefold()
    sc = {k: len(re.findall(v, body)) for k, v in _FAMILY_BODY.items()}
    for fam, pat in _FAMILY_TITLE_RULES:
        if re.search(pat, t):
            if fam == "ai_llm" and re.search(r"\bai engineer\b", t) and sc["data_science_ml"] > sc["ai_llm"]:
                return "data_science_ml"
            return fam
    ranked = sorted(sc.items(), key=lambda x: -x[1])
    # a generic title on an AI product stays general_swe: the domain rules then lead with the AI projects and keep
    # a backend/full-stack project on the page, instead of a pure-AI or pure-backend family
    if jd_domain(raw_jd)["lead"] == "ai":
        return "general_swe"
    (best, n1), (_, n2) = ranked[0], ranked[1]
    need = 8 if best == "support_sustaining" else 4
    ratio = 1.5
    if not t.strip():
        # no title at all: the body is the only signal, so accept a clearer-than-usual lead with fewer hits
        need = 6 if best == "support_sustaining" else 3
        ratio = 1.3
    return best if n1 >= need and n1 >= ratio * max(n2, 1) else "general_swe"


def apply_auto_plan_fields(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    app = raw_plan.get("application", {})
    if raw_plan.get("role_family") in (None, "", "auto"):
        raw_plan["role_family"] = auto_role_family(str(app.get("role", "")), raw_jd)
        raw_plan["_role_family_auto"] = True
    fam = raw_plan["role_family"]
    if raw_plan.get("jd_themes") in (None, "auto", []):
        raw_plan["jd_themes"] = list(_FAMILY_THEMES.get(fam, ["backend"]))
    if raw_plan.get("jd_requirements") in (None, "auto"):
        reqs = parse_jd_requirements(raw_jd, master, "" if role_is_placeholder(app.get("role")) else str(app.get("role", "")))
        if _LAST_PARSE_DROPPED:
            raw_plan.setdefault("_trimmed_requirements", []).extend(_LAST_PARSE_DROPPED)
        drop = {str(t).casefold() for t in (raw_plan.get("jd_requirements_remove") or [])}
        reqs = [r for r in reqs if r["term"].casefold() not in drop]
        have = {r["term"].casefold() for r in reqs} | {str(a).casefold() for r in reqs for a in r.get("aliases", [])}
        for x in raw_plan.get("jd_requirements_extra") or []:
            if not isinstance(x, dict) or not x.get("term"):
                continue
            if str(x["term"]).casefold() in have or normalize_skill_name(str(x["term"]), master).casefold() in have:
                raw_plan.setdefault("_extra_already_covered", []).append(str(x["term"]))
                continue
            e = {"term": str(x["term"]), "verbatim": str(x.get("verbatim") or x["term"]), "aliases": [str(a) for a in x.get("aliases", [])] or [str(x["term"])],
                 "priority": x.get("priority", "high") if x.get("priority") in ("must", "high", "medium") else "high"}
            # the verbatim must really be in the posting, and the term must be about that text: the term, an alias, a known
            # spelling of the term, or a shared word stem ("Model Evaluation" <- "evaluate AI features") has to appear in it
            squash = lambda s: re.sub(r"\s+", " ", str(s)).strip().casefold()
            if squash(e["verbatim"]) not in squash(raw_jd):
                raw_plan.setdefault("_extra_rejected", []).append({"term": e["term"], "verbatim": e["verbatim"], "reason": "verbatim not found in the JD"})
                continue
            known = [e["term"]] + e["aliases"] + list(_CANON_ALIAS.get(e["term"], [])) + [k for k, v in _CANON.items() if v == e["term"]]
            stems = {w.casefold()[:6] for w in re.findall(r"[A-Za-z]{4,}", e["term"])}
            vwords = {w.casefold()[:6] for w in re.findall(r"[A-Za-z]{4,}", e["verbatim"])}
            if not (any(boundary_contains_plural(e["verbatim"], a) for a in known) or (stems & vwords)):
                raw_plan.setdefault("_extra_rejected", []).append({"term": e["term"], "verbatim": e["verbatim"], "reason": "term not related to the verbatim text"})
                continue
            e["supported"] = master_supports_requirement(e["term"], e["aliases"], master)
            if x.get("required_section"):
                e["required_section"] = True
            e["_extra"] = True
            reqs.append(e); have.add(e["term"].casefold())
        # extras keep the priority the JD gives them: re-sort, then trim auto medium items first to stay inside the caps
        order = {"must": 0, "high": 1, "medium": 2}
        reqs.sort(key=lambda r: order.get(r.get("priority"), 2))
        cap = int(master.get("ats_rules", {}).get("jd_requirements_max", 25))
        med_cap = int(master.get("ats_rules", {}).get("medium_requirements_max", 12))
        def _over():
            return len(reqs) > cap or sum(1 for r in reqs if r.get("priority") == "medium") > med_cap
        while _over():
            idx = next((i for i in range(len(reqs) - 1, -1, -1) if reqs[i].get("priority") == "medium" and not reqs[i].get("_extra")), None)
            if idx is None:
                idx = next((i for i in range(len(reqs) - 1, -1, -1) if reqs[i].get("priority") == "medium"), len(reqs) - 1)
            raw_plan.setdefault("_trimmed_requirements", []).append(reqs[idx]["term"])
            reqs.pop(idx)
        for r in reqs:
            r.pop("_extra", None)
        raw_plan["jd_requirements"] = reqs
        raw_plan["_jd_requirements_auto"] = True
    if raw_plan.get("tagline_id") in (None, "", "auto"):
        opts = master.get("taglines", {}).get("options", {})
        themes = {t.lower() for t in raw_plan.get("jd_themes", [])}
        allowed = (master.get("role_families", {}).get(fam, {}) or {}).get("tagline_ids", ["general"])
        pick = next((tid for tid in allowed if tid == "general" or set(opts.get(tid, {}).get("themes", [])) & themes), "general")
        if fam == "general_swe" and "ai_apps" in allowed and jd_domain(raw_jd)["lead"] == "ai":
            pick = "ai_apps"
            raw_plan["jd_themes"] = list(dict.fromkeys(list(raw_plan.get("jd_themes", [])) + ["ai_apps"]))
        raw_plan["tagline_id"] = pick
    if str(app.get("fit", "")).lower() in ("", "auto"):
        musts = [r for r in raw_plan.get("jd_requirements", []) if r.get("priority") in ("must", "high")]
        sup = [r for r in musts if r.get("supported")]
        ratio = (len(sup) / len(musts)) if musts else 1.0
        app["fit"] = "High" if ratio >= 0.85 else ("Medium" if ratio >= 0.6 else "Low")
        raw_plan["application"] = app


# Skills serve the JD first: a selected-project technology that the JD does not name is already visible in the
# project header/bullets, so it may yield its Tools slot to a JD term. JD-named technologies must stay in Skills.
_validate_selected_technology_skill_coverage_v3_1 = validate_selected_technology_skill_coverage


def validate_selected_technology_skill_coverage(plan, master, resolved_skills, project_tech):
    fails = _validate_selected_technology_skill_coverage_v3_1(plan, master, resolved_skills, project_tech)
    raw = str(plan.get("_raw_jd_text", ""))
    out = []
    for f in fails:
        missing = [x for x in f.get("measured", []) if raw and boundary_contains_plural(raw, x)]
        if missing:
            f = dict(f); f["measured"] = missing; out.append(f)
    return out


# HTML and CSS display together so both ATS words are visible.
_required_ats_skill_displays_v3_1 = required_ats_skill_displays


def required_ats_skill_displays(plan, master):
    out = []
    for d in _required_ats_skill_displays_v3_1(plan, master):
        d = "HTML/CSS" if d.casefold() in ("html", "css") else d
        if d not in out:
            out.append(d)
    return out


# ===========================================================================
# v3.3 layer (2026-10-13): theme-first project ranking, relevance-ordered
# projects, gated Technical Skills (shown on the page or named by the JD,
# heading technologies always listed, >= 3 entries per line), hedged
# "could include" lists read as optional, internship enrollment check,
# page-grounded cover letter, and a quality gate on every run.
# ===========================================================================

_V33_THEME_RX = {
    "backend": r"\bback[- ]?end\b|\bapis?\b|\bmicroservices?\b|\bweb services?\b|\bserver[- ]side\b|\brest(?:ful)?\b",
    "distributed": r"\bdistributed\b|\bscal(?:e|able|ability|ing)\b|\bevent[- ]driven\b|\bkafka\b|\bmessage queues?\b|\bconcurren\w+|\bhigh[- ]volume\b|\btransactions?\b|\basynchronous\b",
    "payments": r"\bpayments?\b|\bledgers?\b|\bfintech\b|\bbilling\b|\bfinancial\b",
    "fullstack": r"\bfull[- ]?stack\b|\bfront[- ]?end\b|\breact\b|\bweb applications?\b|\buser interfaces?\b|\bjavascript\b|\buser[- ]centric\b|\bui\b",
    "data_eng": r"\bdata pipelines?\b|\betl\b|\belt\b|\bdata warehouses?\b|\bspark\b|\bairflow\b|\bdata quality\b|\bdbt\b|\bbigquery\b|\bsnowflake\b|\bdata models?\b|\bbi\b|\banalytics\b|\bdata infrastructure\b",
    "ml_dl": r"\bmachine learning\b|\bdeep learning\b|\bneural networks?\b|\bpytorch\b|\btensorflow\b|\bjax\b|\btraining jobs?\b|\btrain(?:ing|ed)? (?:ml |dl )?models?\b|\bml\b|\bcomputer vision\b|\bdl\b|\bcudnn\b",
    "recsys_search": r"\brecommend\w*|\branking\b|\bsearch\b|\bretrieval\b|\brelevance\b|\bpersonaliz\w+",
    "llm_agents": r"\bllms?\b|\blarge language models?\b|\blanguage[- ]models?\b|\bai agents?\b|\bagents?\b|\bagentic\b|\bgenerative ai\b|\bgen ?ai\b|\bprompt\w*|\brag\b|\btool calling\b|\bhallucinat\w+|\bllm integration\b|\bcoding[- ]agents?\b",
    "evaluation": r"\bevals?\b|\bevaluat\w+|\bbenchmark\w*|\bmetrics?\b|\bground truth\b|\bmeasur\w+",
    "model_api": r"\bmodel apis?\b|\binference\b|\bmodel serving\b|\bserving frameworks?\b|\bllm apis?\b|\bai providers?\b|\bmodel providers?\b|\bfailover\b",
    "testing_quality": r"\btest(?:ing|s|ed|able)?\b|\bquality\b|\bqa\b|\bsdet\b|\bregression\b|\bverif\w+|\bvalidat\w+|\breliab\w+",
    "devtools": r"\bdeveloper tool\w*|\bdeveloper productivity\b|\bengineering productivity\b|\bcode review\w*|\bstatic analysis\b|\bsdlc\b|\bcoding agents?\b|\bai tools\b|\bcodebases?\b",
    "systems": r"\boperating systems?\b|\bkernel\b|\bembedded\b|\bfirmware\b|\blow[- ]level\b|\bsystems programming\b|\bx86\b|\bcomputer memory\b|\bcpus?\b|\bgpus?\b|\bdrivers?\b|\bc\+\+|\bcuda\b|\bcomputer architecture\b|\bparallel programming\b",
    "devops_cloud": r"\bdevops\b|\bsre\b|\bkubernetes\b|\bdocker\b|\bcontainer\w*|\baws\b|\bcloud\b|\binfrastructure\b|\bdeploy\w*|\bci/cd\b|\bmonitoring\b|\bobservability\b|\blinux\b",
    "customer": r"\bcustomers?\b|\bclients?\b|\bstakeholders?\b|\bforward[- ]deployed\b|\bsolutions engineer\w*|\bcustomer[- ]facing\b|\bpocs?\b",
    "data_science": r"\bdata scien\w+|\bstatistic\w*|\bexperimentation\b|\ba/b\b|\bfeature engineering\b|\bmodel evaluation\b",
    "realtime": r"\breal[- ]time\b|\bwebsockets?\b|\blive\b",
    "performance": r"\bperformance\b|\blatency\b|\bthroughput\b|\boptimiz\w+|\befficien\w+",
    "ai_apps": r"\bai[- ](?:powered|native|first|applications?|products?|features?|tools)\b|\bllm[- ]powered\b|\bai applications?\b",
}
_V33_THEME_DAMP = {"testing_quality": 0.5, "backend": 0.8, "devops_cloud": 0.6, "performance": 0.7, "customer": 0.8, "realtime": 0.6, "distributed": 0.8}
_V33_HEDGE = re.compile(r"\b(could include|could be required|may include|might include|can include|depending on (?:the )?(?:internship |specific |your )?(?:role|team|project|position|priorities)|"
                        r"examples? (?:of|include)|not requirements|no candidate is expected|for example,? (?:an engineer )?could|is not (?:a )?required|not required|not essential|welcome but not|is a (?:big )?plus|are a plus|a bonus|is a bonus|nice to have)\b", re.I)
_V33_SKIP_SECTION = re.compile(r"^(?:#+\s*)?\**\s*(?:benefits?|perks|compensation|salary|pay (?:range|transparency)|equal opportunity|eeo|accommodation|privacy|"
                               r"why join|what else you need to know|you will benefit|about (?:us|the company|novita|linkedin|wpp|atoms)|who we are|our mission|company description)\b"
                               r"|^(?:#+\s*)?\**\s*about (?!(?:the|this|our|your) (?:[\w-]+ ){0,3}?(?:team|role|job|position|opportunity|internship|program)s?\b|you\b)[A-Z][\w&.'’-]*(?: [A-Z][\w&.'’-]*){0,3}\s*\**:?\s*\**$", re.I)


_V33_LINE_MODE: dict[str, float] = {}


def _v33_role_lines(raw_jd: str) -> list[tuple[str, float, bool]]:
    """(line, weight, hedged) for the parts of the posting that describe the role. Company blurbs count a little,
    benefits/EEO not at all, and hedged example lists ("could include", "depending on the role") count a quarter."""
    out = []
    mode = 1.0
    hsec = False
    ctx: set[int] = set()
    if _v347_on("jd_sections_v349"):   # v3.4.9a fix 1: the same headings as the requirement reader; example-list lines are hedged
        raw_jd = v349_headings_view(raw_jd)
        ctx = v349_context_lines(raw_jd)
    for _i, raw in enumerate(str(raw_jd).splitlines()):
        line = raw.strip()
        if not line:
            continue
        head = re.sub(r"[#*_]+", "", line).strip()
        if len(head.split()) <= 8 and not head.endswith(".") and (head.endswith(":") or head.istitle() or head.isupper() or line.startswith("#") or line.startswith("**")):
            hsec = bool(re.search(r"\b(potential|possible|example|sample|bonus|pluses|nice[- ]to[- ]have|stand out|extra credit|preferred|desired|optional)\b|could include|may include|might include|a plus", head, re.I))
            if _V33_SKIP_SECTION.search(head):
                mode = 0.0 if re.search(r"benefit|perk|compens|salary|pay|equal|eeo|accommod|privacy|why join|else you need|benefit from", head, re.I) else 0.35
            else:
                mode = 0.6 if re.search(r"nice to have|preferred|bonus|a plus|additional", head, re.I) else 1.0
            continue
        if mode == 0.0:
            continue
        hedged = bool(_V33_HEDGE.search(line)) or hsec or _i in ctx
        out.append((line, mode * (0.25 if hedged else 1.0), hedged))
        _V33_LINE_MODE[line] = mode
    return out


def jd_theme_vector(raw_jd: str, title: str = "", company: str = "") -> dict[str, float]:
    if company and not role_is_placeholder(company):
        for tok in sorted({company} | set(re.findall(r"[A-Za-z][A-Za-z&.-]{2,}", company)), key=len, reverse=True):
            if tok.lower() not in ("the", "inc", "llc", "corp", "and"):
                raw_jd = re.sub(r"(?<![A-Za-z])" + re.escape(tok) + r"(?![A-Za-z])", " ", raw_jd, flags=re.I)
    tally = {t: 0.0 for t in _V33_THEME_RX}
    rx = {t: re.compile(p, re.I) for t, p in _V33_THEME_RX.items()}
    lines = [(title, 4.0, False)] + _v33_role_lines(raw_jd)
    for line, w, _h in lines:
        if not w:
            continue
        for t, r in rx.items():
            n = min(3, len(r.findall(line)))
            if t == "systems":
                n = min(3, n + len(re.findall(r"(?<![\w+#/])C(?![\w+#])", line)))
            tally[t] += w * n * _V33_THEME_DAMP.get(t, 1.0)
    total = sum(tally.values()) or 1.0
    vec = {t: v / total for t, v in tally.items()}
    # the job title says what the role IS: its themes get a quarter of the mass on top
    tl = str(title or "")
    boost = []
    if re.search(r"\b(ai|llm|genai|gen ai|agents?|agentic|applied ai)\b", tl, re.I): boost += ["llm_agents", "ai_apps", "evaluation"]
    if re.search(r"\b(machine learning|ml|deep learning|data scien\w*|recommend\w*|ranking|search)\b", tl, re.I): boost += ["ml_dl", "data_science"]
    if re.search(r"\b(recommend\w*|ranking|search|relevance)\b", tl, re.I): boost += ["recsys_search"]
    if re.search(r"\bdata engineer\w*|\betl\b|analytics engineer", tl, re.I): boost += ["data_eng"]
    if re.search(r"\bback[- ]?end\b|\bapi\b|\bplatform\b|\bdistributed\b", tl, re.I): boost += ["backend", "distributed"]
    if re.search(r"full[- ]?stack|front[- ]?end|web|applications?", tl, re.I): boost += ["fullstack"]
    if re.search(r"\b(systems?|embedded|firmware|kernel|os)\b", tl, re.I) and not re.search(r"distributed systems?|\bit\b|information|corporate|business systems", tl, re.I): boost += ["systems"]
    if re.search(r"\b(devops|sre|site reliability|cloud|infrastructure)\b", tl, re.I): boost += ["devops_cloud"]
    if re.search(r"\b(qa|sdet|test|quality)\b", tl, re.I): boost += ["testing_quality"]
    if re.search(r"forward[- ]deployed|solutions engineer", tl, re.I): boost += ["model_api", "llm_agents"]
    if boost:
        per = 0.25 / len(set(boost))
        for t in set(boost):
            vec[t] = vec.get(t, 0) + per
        tot = sum(vec.values())
        vec = {t: v / tot for t, v in vec.items()}
    return {t: round(v, 4) for t, v in vec.items()}


def _v33_hedged_requirements(raw_plan: dict[str, Any], raw_jd: str) -> list[str]:
    """Requirements that appear ONLY inside hedged example lists become optional (medium, not required)."""
    lines = [(l, h) for l, _w, h in _v33_role_lines(raw_jd)]
    if not any(h for _, h in lines):
        return []
    hedged = []
    for r in raw_plan.get("jd_requirements", []) or []:
        if not isinstance(r, dict):
            continue
        spell = [str(r.get("term", ""))] + [str(a) for a in r.get("aliases", [])] + [str(a) for a in r.get("alternatives", [])]
        v = str(r.get("verbatim", ""))
        if v and len(v.split()) <= 4:
            spell.append(v)
        spell = [s for s in dict.fromkeys(spell) if s and len(s) >= 1]
        hits = [h for l, h in lines if any((re.search(r"(?<![\w+#])" + re.escape(s) + r"(?![\w+#])", l) if len(s) <= 2 else boundary_contains_plural(l, s)) for s in spell)]
        if hits and all(hits):
            if str(r.get("priority", "")).lower() in ("must", "high"):
                r["priority"] = "medium"
            r.pop("required_section", None)
            r["hedged"] = True
            hedged.append(str(r.get("term", "")))
    return hedged


_apply_auto_plan_fields_v32 = apply_auto_plan_fields


def apply_auto_plan_fields(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    fit_auto = str(raw_plan.get("application", {}).get("fit", "")).lower() in ("", "auto")
    _apply_auto_plan_fields_v32(raw_plan, master, raw_jd)
    title = str(raw_plan.get("application", {}).get("role", ""))
    if raw_plan.get("_jd_requirements_auto"):
        # "Washington, D.C." / "C-suite" are not the C language
        if not re.search(r"(?<![\w.+#/-])C(?![\w+#.-])", re.sub(r"\bD\.C\.?|\bC-(?:suite|level)\b", " ", raw_jd)):
            dropped = [r for r in raw_plan.get("jd_requirements", []) if isinstance(r, dict) and str(r.get("term")) == "C"]
            if dropped:
                raw_plan["jd_requirements"] = [r for r in raw_plan["jd_requirements"] if r not in dropped]
                raw_plan.setdefault("_trimmed_requirements", []).append("C (false match)")
        if not re.search(r"(?<![\w&.+#/-])R(?![\w&+#.-])", re.sub(r"\bR\s*&\s*D\b|\bR&amp;D\b", " ", raw_jd)):
            dropped = [r for r in raw_plan.get("jd_requirements", []) if isinstance(r, dict) and str(r.get("term")) == "R"]
            if dropped:
                raw_plan["jd_requirements"] = [r for r in raw_plan["jd_requirements"] if r not in dropped]
                raw_plan.setdefault("_trimmed_requirements", []).append("R (false match from R&D)")
        _deg_alt = [l for l in raw_jd.splitlines() if re.search(r"\bph\.?d\b|doctora", l, re.I) and re.search(r"\b(?:m\.?s\.?|master'?s?|b\.?s\.?|bachelor'?s?)\b", l, re.I)]
        if _deg_alt:
            raw_plan["jd_requirements"] = [r for r in raw_plan.get("jd_requirements", []) if not (isinstance(r, dict) and re.search(r"\bph\.?d\b|doctora", str(r.get("term", "")) + " " + str(r.get("verbatim", "")), re.I))]
        hed = _v33_hedged_requirements(raw_plan, raw_jd)
        raw_plan["_hedged_requirements"] = hed
        _order = {"must": 0, "high": 1, "medium": 2}
        _cap = int(master.get("ats_rules", {}).get("jd_requirements_max", 25)); _mcap = int(master.get("ats_rules", {}).get("medium_requirements_max", 12))
        reqs = list(raw_plan.get("jd_requirements", []))
        def _over():
            return len(reqs) > _cap or sum(1 for r in reqs if r.get("priority") == "medium") > _mcap
        for pick in (lambda r: r.get("hedged") and r.get("supported") is False, lambda r: r.get("hedged"), lambda r: r.get("priority") == "medium"):
            i = len(reqs) - 1
            while _over() and i >= 0:
                if pick(reqs[i]):
                    raw_plan.setdefault("_trimmed_requirements", []).append(reqs[i]["term"]); reqs.pop(i)
                i -= 1
        raw_plan["jd_requirements"] = reqs
        raw_plan["jd_requirements"] = sorted(raw_plan.get("jd_requirements", []), key=lambda r: _order.get(str(r.get("priority", "")).lower(), 2))
        if hed and fit_auto:
            musts = [r for r in raw_plan.get("jd_requirements", []) if r.get("priority") in ("must", "high")]
            sup = [r for r in musts if r.get("supported")]
            ratio = (len(sup) / len(musts)) if musts else 1.0
            raw_plan["application"]["fit"] = "High" if ratio >= 0.85 else ("Medium" if ratio >= 0.6 else "Low")
    vec = jd_theme_vector(raw_jd, "" if role_is_placeholder(title) else title, str(raw_plan.get("application", {}).get("company", "")))
    raw_plan["_jd_theme_vector"] = vec
    themes = list(raw_plan.get("jd_themes", []) or [])
    add = []
    if vec.get("recsys_search", 0) >= 0.06:
        add += ["ranking", "recommendation", "search", "information_retrieval"]
    if vec.get("performance", 0) + vec.get("model_api", 0) >= 0.08:
        add += ["performance", "latency"]
    if re.search(r"\bload[- ]?(?:and reliability )?test\w*|\bperformance test\w*|\bstress[- ]test\w*", raw_jd, re.I):
        add += ["performance"]
    if re.search(r"\bkubernetes\b", raw_jd, re.I) and vec.get("devops_cloud", 0) >= 0.08:
        add += ["kubernetes", "infrastructure"]
    raw_plan["jd_themes"] = list(dict.fromkeys(themes + add))


def _v33_req_groups(plan: dict[str, Any]) -> list[tuple[float, list[str], list[str], bool]]:
    pw = {"must": 3.0, "high": 2.0, "medium": 1.0}
    out = []
    for r in plan.get("jd_requirements", []) or []:
        if not isinstance(r, dict) or r.get("supported") is False:
            continue
        w = pw.get(str(r.get("priority", "")).lower(), 0.5) * (0.4 if r.get("hedged") else 1.0)
        main = [str(r.get("term", ""))] + [str(a) for a in r.get("aliases", [])]
        alts = [str(a) for a in r.get("alternatives", []) if str(a) not in main]
        out.append((w, [s for s in main if s], [s for s in alts if s], bool(r.get("hedged"))))
    return out


def _v33_corpus(pr: dict[str, Any]) -> str:
    return " | ".join([*pr.get("tech", []), *pr.get("tags", []), *pr.get("header_priority_tech", []),
                       *[x for it in pr.get("evidence_items", {}).values() for x in it.get("terms", [])]])


_auto_project_scores_v32 = auto_project_scores


def auto_project_scores(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> dict[str, float]:
    """Theme-first ranking. 1) What the role is about (title, responsibilities, requirements; hedged example lists
    and company blurbs count little) decides which projects prove it. 2) Requirement coverage breaks near-ties.
    3) Projects are picked greedily so the three complement each other (a second project proving the same theme
    is worth less). A must-have only one project proves still forces that project onto the page."""
    legacy = _auto_project_scores_v32(dict(plan), master, raw_jd)  # keeps _jd_domain and other side effects
    title = str(plan.get("application", {}).get("role", ""))
    vec = dict(plan.get("_jd_theme_vector") or jd_theme_vector(raw_jd, title))
    # customer-facing work is proven by Experience (Thesis client meetings), not by projects: score projects on the rest
    vec.pop("customer", None)
    _tot = sum(vec.values()) or 1.0
    vec = {t: v / _tot for t, v in vec.items()}
    strength = {k: v for k, v in master.get("project_theme_strength", {}).items() if not k.startswith("_")}
    active = [p for p in master.get("project_selection_rules", {}).get("active_project_ids", list(master["projects"])) if p in master["projects"]]
    groups = _v33_req_groups(plan)
    corp = {pid: _v33_corpus(master["projects"][pid]) for pid in active}
    def hit(pid, spells):
        return any(boundary_contains_plural(corp[pid], s) for s in spells)
    req_hits = {pid: [(w, hit(pid, m), (not hit(pid, m)) and hit(pid, a)) for (w, m, a, _h) in groups] for pid in active}
    total_w = sum(w for w, *_ in groups) or 1.0
    company = str(plan.get("application", {}).get("company", ""))
    profile = role_family_profile(plan, master) or {}
    avoid = set(profile.get("avoid_projects", []))
    def brand_bonus(pid):
        b = 0.0
        for t in master["projects"][pid].get("tech", []):
            m = re.match(r"^(\w+) API$", t)
            if not m or m.group(1).lower() in ("llm", "rest", "crossref"):
                continue
            brand = m.group(1)
            if re.search(r"\b" + re.escape(brand) + r"\b", company, re.I):
                b += 14.0
            elif re.search(r"\b" + re.escape(brand) + r"\b", raw_jd, re.I):
                b += 4.0
        return b
    def penalties(pid):
        p = 0.0
        if pid in avoid:
            p -= 3.0
        if pid == "pintos" and vec.get("systems", 0) < 0.05:
            p -= 12.0
        if pid == "tailor_pipeline" and vec.get("model_api", 0) + vec.get("llm_agents", 0) + vec.get("ai_apps", 0) < 0.12 and brand_bonus(pid) < 10 and vec.get("it_ops", 0) < 0.3:
            p -= 12.0
        return p
    standalone = {}
    for pid in active:
        st = strength.get(pid, {})
        th = 10.0 * sum(vec.get(t, 0) * s for t, s in st.items())
        rq = 8.0 * sum(w * (1.0 if m else 0.35 if a else 0.0) for (w, m, a) in req_hits[pid]) / total_w
        standalone[pid] = round(th + rq + brand_bonus(pid) + penalties(pid), 3)
    selected: list[str] = []
    covered = {t: 0.0 for t in vec}
    got = [False] * len(groups)
    breakdown = {}
    for _k in range(3):
        best, best_s = None, None
        for pid in active:
            if pid in selected:
                continue
            st = strength.get(pid, {})
            th = 10.0 * sum(vec.get(t, 0) * s / (1.0 + 0.5 * covered.get(t, 0.0)) for t, s in st.items())
            rq = 8.0 * sum(w * ((1.0 if m else 0.35 if a else 0.0) * (0.3 if got[i] else 1.0)) for i, (w, m, a) in enumerate(req_hits[pid])) / total_w
            s = th + rq + brand_bonus(pid) + penalties(pid)
            if best_s is None or s > best_s + 1e-9 or (abs(s - best_s) <= 1e-9 and standalone[pid] > standalone[best]):
                best, best_s = pid, s
        selected.append(best)
        breakdown[best] = round(best_s, 3)
        for t, s in strength.get(best, {}).items():
            covered[t] = covered.get(t, 0.0) + s / 3.0
        for i, (w, m, a) in enumerate(req_hits[best]):
            if m or a:
                got[i] = True
    # the strongest single fit leads (3 bullets); the complementary picks follow
    selected.sort(key=lambda p: -standalone[p])
    # a must-have (not hedged, required) concrete technology only one project proves, and Experience does not, is forced on
    concept = {str(globals().get("_CANON", {}).get(c.casefold(), c)).casefold() for c in globals().get("_CONCEPT_TERMS", [])}
    exp_text = " ".join(b for e in master.get("experience", []) for b in e.get("bullets", []))
    for r in plan.get("jd_requirements", []) or []:
        if not isinstance(r, dict) or r.get("supported") is False or r.get("hedged") or str(r.get("priority", "")).lower() != "must":
            continue
        spells = [str(r.get("term", ""))] + [str(a) for a in r.get("aliases", [])]
        if any(s.casefold() in concept for s in spells) or any(boundary_contains_plural(exp_text, s) for s in spells if s):
            continue
        who = [pid for pid in active if hit(pid, spells)]
        if len(who) == 1 and who[0] not in selected:
            selected[-1] = who[0]
    top = max(standalone.values()) if standalone else 0.0
    scores = dict(standalone)
    for i, pid in enumerate(selected):
        scores[pid] = round(top + 3.0 - i, 3)
    plan["_v33_rank"] = {"theme_vector": {k: v for k, v in sorted(vec.items(), key=lambda x: -x[1]) if v > 0}, "standalone": standalone,
                         "greedy_marginal": breakdown, "selected": selected, "legacy_v32_scores": legacy}
    if any(p in avoid for p in selected) and not str(plan.get("ranking_override_reason", "")).strip():
        plan["ranking_override_reason"] = "v3.3 theme-first ranking: " + ", ".join(f"{t} {w:.2f}" for t, w in sorted(vec.items(), key=lambda x: -x[1])[:3])
    return scores


def build_display_order(ranking: list[str], master: dict[str, Any]) -> list[str]:
    """Relevance first: the #1 project (3 bullets) sits on top where a recruiter starts reading; dates stay on each heading.
    v3.4.9a fix 6 (date_order_v349): newest to oldest by master date, ties by rank; slot counts still follow the rank."""
    if _v347_on("date_order_v349"):
        return v349_date_order(ranking, master)
    return list(ranking)


# --- Technical Skills -------------------------------------------------------

def _v33_page_text(plan: dict[str, Any], master: dict[str, Any], header_tech: dict[str, list[str]]) -> str:
    parts = [b for e in master.get("experience", []) for b in e.get("bullets", [])]
    for pid, bl in (plan.get("bullets") or {}).items():
        parts += [bullet_text(b) for b in bl]
    for pid, vals in header_tech.items():
        parts += list(vals)
    return " \n ".join(parts)


def _v33_shown(skill: str, page: str, master: dict[str, Any]) -> bool:
    pe = master.get("skills", {}).get("page_evidence", {})
    names = [skill] + [a for a, c in master["skills"].get("normalization", {}).items() if c == skill and len(a) > 2]
    names += list(pe.get(skill, []))
    for n in names:
        if not n:
            continue
        if len(n) <= 2:
            if re.search(r"(?<![\w+#/])" + re.escape(n) + r"(?![\w+#])", page):
                return True
        elif boundary_contains_plural(page, n):
            return True
    return False


def _v33_relevance(skill: str, vec: dict[str, float]) -> float:
    s = skill.casefold()
    m = {
        "backend": ["rest", "api", "backend", "microservice", "spring", "django", "postgres", "sql", "java", "go"],
        "distributed": ["distributed", "kafka", "event", "concurren", "redis", "microservice", "parallel", "idempot"],
        "fullstack": ["react", "javascript", "html", "full-stack", "django", "streamlit", "websocket"],
        "data_eng": ["etl", "pipeline", "pandas", "numpy", "sql", "data ", "mysql", "transformation", "cleaning", "validation", "parallel"],
        "ml_dl": ["pytorch", "learning", "neural", "gnn", "model", "scikit", "numpy", "pandas", "classification", "graphsage"],
        "recsys_search": ["ranking", "model evaluation", "information", "pytorch", "machine learning"],
        "llm_agents": ["llm", "agent", "prompt", "tool calling", "langgraph", "claude", "gemini", "pydantic", "multi-agent", "human-in"],
        "model_api": ["api", "llm", "gemini", "novita", "groq", "claude", "concurren", "parallel"],
        "testing_quality": ["test", "pytest", "junit", "validation", "chaos", "fault", "code review", "continuous integration"],
        "devtools": ["static analysis", "git", "change-impact", "code review", "agent"],
        "systems": ["c", "operating", "kernel", "thread", "process", "concurren", "linux", "x86"],
        "devops_cloud": ["docker", "aws", "kubernetes", "linux", "monitoring", "deployment", "nginx", "vpc", "ci"],
        "realtime": ["websocket", "redis", "real-time"],
        "customer": ["api design", "rest"],
    }
    sc = 0.0
    for t, keys in m.items():
        if any((s == k) if len(k) <= 2 else (k in s) for k in keys):
            sc += vec.get(t, 0.0)
    return sc


def build_skill_states(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    """v3.3 Technical Skills.
    Gate: a skill is listed only when it is (a) named by the JD and supported, (b) a technology in a selected project
    heading or bullet (always listed: closure), (c) one of a few universal basics, or (d) visibly shown elsewhere on the
    page. Generic words (Agile, OOP, System Design, ...) appear only when the JD asks for them.
    Order: JD must > JD high > JD medium/named > heading technologies > universal > page fillers by JD theme relevance.
    Every non-empty line gets at least 3 entries when the page supports them; the TeX fitter adds fillers until the
    7-line budget (category limits unchanged)."""
    raw_jd = str(plan.get("_raw_jd_text", ""))
    vec = plan.get("_jd_theme_vector") or jd_theme_vector(raw_jd, str(plan.get("application", {}).get("role", "")))
    header_tech = resolved_project_header_tech(master, plan["ranking"], plan)
    page = _v33_page_text(plan, master, header_tech)
    cat_of = lambda x: supported_skill_category(x, master)
    norm = lambda x: normalize_skill_name(x, master).casefold()
    hedged = {str(t).casefold() for t in plan.get("_hedged_requirements", [])}
    must = required_ats_skill_displays(plan, master)
    highs = _high_priority_skill_displays(plan, master)
    pool_jd = [x for x in plan.get("_jd_pool_terms", []) if cat_of(x)]
    hedged_jd = [x for x in highs + pool_jd if norm(x) in hedged]
    jd_named = [x for x in must + highs + pool_jd if norm(x) not in hedged] + hedged_jd
    _groups = master["skills"].get("synonym_groups", [])
    _hi_only = _high_priority_skill_displays({**plan, "jd_requirements": [r for r in plan.get("jd_requirements", []) if isinstance(r, dict) and str(r.get("priority", "")).lower() == "high"]}, master)
    _must_keys = {norm(x) for x in must + _hi_only}
    _dedup, _have = [], set()
    for x in dict.fromkeys(jd_named):
        g = next((g for g in _groups if x in g), None)
        if g and norm(x) not in _must_keys and any(norm(y) in _have for y in g):
            continue
        _dedup.append(x); _have.add(norm(x))
    jd_named = _dedup
    closure = selected_technology_skills(plan, master, header_tech)
    universal = [x for x in master["skills"].get("universal_allowed", ["Python", "SQL", "Git"])]
    pool_all = [x for vals in master["skills"]["supported_pool"].values() for x in vals]
    fam_fill = master.get("skills", {}).get("family_fillers", {}).get(str(plan.get("role_family", "")), [])
    shown = [x for x in pool_all if _v33_shown(x, page, master)]
    # never list a skill the page does not show unless the JD names it (Experience is frozen, so this is final)
    never = set(master["skills"].get("never_filler", []))
    fillers = [x for x in dict.fromkeys(list(fam_fill) + shown) if x in shown and x not in never and (x in fam_fill or _v33_relevance(x, vec) >= 0.03)]
    low_rel = [x for x in shown if x not in never and x not in fillers]
    fillers.sort(key=lambda x: (-_v33_relevance(x, vec), 0 if x in fam_fill else 1))
    mandatory: list[str] = []
    seen: set[str] = set()
    # must requirements, high-priority JD terms, heading technologies and the universal basics are guaranteed;
    # other JD-named terms come first among the optional skills (the fitter keeps as many as the 7-line budget allows)
    _jdk = {norm(x) for x in jd_named}
    core_jd = [x for x in must + [h for h in highs if norm(h) not in hedged] if norm(x) in _jdk or x in must]
    jd_optional = [x for x in jd_named if norm(x) not in {norm(y) for y in core_jd}]
    jd_optional.sort(key=lambda x: -_v33_relevance(x, vec))
    for x in core_jd + closure + universal:
        k = norm(x)
        if k in seen or not cat_of(x):
            continue
        mandatory.append(x); seen.add(k)
    # keep JD-named skills the page cannot back only if Master supports them (they always are, by construction)
    rest = [x for x in dict.fromkeys(jd_optional + fillers) if norm(x) not in seen and cat_of(x)]
    by_cat: dict[str, list[str]] = {}
    for x in mandatory:
        by_cat.setdefault(cat_of(x), []).append(x)
    # at least 3 entries on every line that will be shown
    def _syn_of_present(x, cur):
        ck = {norm(c) for c in cur}
        return any(x in g and any(norm(y) in ck for y in g if y != x) for g in _groups) and norm(x) not in {norm(j) for j in jd_named}
    for cat in list(by_cat):
        need = 3 - len(by_cat[cat])
        if need > 0:
            add = []
            for x in rest:
                if cat_of(x) == cat and not _syn_of_present(x, by_cat[cat] + add):
                    add.append(x)
                if len(add) >= need:
                    break
            for x in add:
                by_cat[cat].append(x); rest.remove(x); seen.add(norm(x))
    for cat in list(by_cat):
        if len(by_cat[cat]) > 11:
            keep = [x for x in by_cat[cat] if norm(x) in _must_keys or x in closure]
            others = [x for x in by_cat[cat] if x not in keep]
            by_cat[cat] = [x for x in by_cat[cat] if x in keep or x in others[: max(0, 11 - len(keep))]]
    # AI/ML line: shown only when it can carry 3 relevant entries; otherwise its items stay off (non-AI roles)
    ai_avail = by_cat.get("ai_ml", []) + [x for x in rest if cat_of(x) == "ai_ml"]
    ai_jd = [x for x in by_cat.get("ai_ml", []) if norm(x) in {norm(y) for y in jd_named}]
    ai_rel = vec.get("llm_agents", 0) + vec.get("ml_dl", 0) + vec.get("model_api", 0) + vec.get("ai_apps", 0) + vec.get("recsys_search", 0) + vec.get("data_science", 0)
    if not ai_jd and ai_rel < 0.04:
        by_cat.pop("ai_ml", None)
        rest = [x for x in rest if cat_of(x) != "ai_ml"]
    elif len(ai_avail) >= 3:
        _grp = master["skills"].get("synonym_groups", [])
        _ml_rel = vec.get("ml_dl", 0) + vec.get("data_science", 0) + vec.get("recsys_search", 0)
        _ml_words = {"Machine Learning", "Deep Learning", "Model Evaluation", "Neural Networks (CNN, GNN)", "CNNs", "RNNs", "GNNs", "Transformers"}
        _jdn = {norm(y) for y in jd_named}
        _pref = ("Machine Learning", "LLM Integration", "AI Agents", "Model Evaluation", "Deep Learning", "Tool Calling", "Prompt Engineering") if _ml_rel >= 0.03 \
            else ("LLM Integration", "AI Agents", "Tool Calling", "Prompt Engineering", "Agentic Workflows", "Agentic AI")
        cand = sorted([x for x in rest if cat_of(x) == "ai_ml" and (_ml_rel >= 0.03 or x not in _ml_words or norm(x) in _jdn)],
                      key=lambda x: (0 if x in _pref else 1, _pref.index(x) if x in _pref else 99))
        cur = by_cat.setdefault("ai_ml", [])
        for x in cand:
            if len(cur) >= 3:
                break
            if any(x in g and any(norm(y) in {norm(c) for c in cur} for y in g if y != x) for g in _grp):
                continue
            cur.append(x); rest.remove(x)
        if len(cur) < 3 and any(norm(c) in _jdn for c in cur):
            # the line carries a JD-named term: fill from page-shown ML basics rather than drop the term or stack synonyms
            _fb = [y for y in rest if cat_of(y) == "ai_ml" and y in _ml_words and _v33_shown(y, page, master)] + \
                  [y for y in ("Agentic Workflows", "Agentic AI") if y in rest]
            for x in _fb:
                if len(cur) >= 3:
                    break
                cur.append(x); rest.remove(x)
        if len(cur) < 3:
            by_cat.pop("ai_ml", None)
            rest = [x for x in rest if cat_of(x) != "ai_ml"]
    # synonyms: one member per group unless the JD names more
    groups = master["skills"].get("synonym_groups", [])
    def _taken(x, have):
        for g in groups:
            if x in g and any(norm(y) in have for y in g if y != x) and norm(x) not in {norm(j) for j in jd_named}:
                return True
        return False
    # optional skills: estimate line usage so a long category never blocks the others (the TeX fitter stops at the
    # first optional that does not fit); relevance order inside, categories interleaved
    label_len = {"languages_databases": 24, "frameworks_libraries": 25, "ai_ml": 8, "software_engineering": 23, "tools": 8}
    lim = master["layout_rules"]["skills_category_line_limits"]
    cap_chars = lambda c: (104 * lim.get(c, 2)) - label_len.get(c, 20)
    used = {c: sum(len(x) + 2 for x in v) for c, v in by_cat.items()}
    have = {norm(x) for v in by_cat.values() for x in v}
    lines_est = sum(max(1, -(-used[c] // 104)) for c in used if by_cat.get(c))
    optional, later = [], []
    for x in rest:
        c = cat_of(x)
        if (c == "ai_ml" and "ai_ml" not in by_cat) or _taken(x, have):
            continue
        new_used = used.get(c, 0) + len(x) + 2
        new_lines = lines_est - (max(1, -(-used.get(c, 0) // 104)) if by_cat.get(c) else 0) + max(1, -(-new_used // 104))
        if new_used <= cap_chars(c) and new_lines <= 7 and len(by_cat.get(c, [])) + sum(1 for o in optional if cat_of(o) == c) < 10:
            optional.append(x); used[c] = new_used; have.add(norm(x)); lines_est = new_lines
            by_cat.setdefault(c, by_cat.get(c, [])) if False else None
        else:
            later.append(x)
    _cnt = lambda c: len(by_cat.get(c, [])) + sum(1 for o in optional if cat_of(o) == c)
    optional += [x for x in later if not _taken(x, have) and _cnt(cat_of(x)) < 10][:4]
    # Jay's floor: 6 rendered lines when the page has room. Add an AI/ML line from page-shown AI work, then
    # lower-relevance page-shown skills (never generic words), until about 6 lines are estimated.
    if lines_est < 6:
        for x in low_rel:
            if lines_est >= 6:
                break
            c = cat_of(x)
            if not c or norm(x) in have or _taken(x, have) or (c == "ai_ml" and "ai_ml" not in by_cat):
                continue
            new_used = used.get(c, 0) + len(x) + 2
            new_lines = lines_est - (max(1, -(-used.get(c, 0) // 104)) if (by_cat.get(c) or used.get(c)) else 0) + max(1, -(-new_used // 104))
            if new_used <= cap_chars(c) and _cnt(c) < 10:
                optional.append(x); used[c] = new_used; have.add(norm(x)); lines_est = new_lines
    if lines_est < 6:
        if "ai_ml" not in by_cat and not plan.get("_v342_no_ai_floor"):   # v3.4.2: the line-count floor never adds the AI/ML line
            _ml_rel2 = vec.get("ml_dl", 0) + vec.get("data_science", 0) + vec.get("recsys_search", 0)
            _mlw2 = {"Machine Learning", "Deep Learning", "Model Evaluation", "Neural Networks (CNN, GNN)", "CNNs", "RNNs", "GNNs", "Transformers"}
            ai_shown = [x for x in shown if cat_of(x) == "ai_ml" and x not in never and not _taken(x, have)
                        and (_ml_rel2 >= 0.03 or x not in _mlw2 or (vec.get("llm_agents", 0) + vec.get("ai_apps", 0)) < 0.02)]
            ai_shown.sort(key=lambda x: (0 if x in ("Machine Learning", "LLM Integration", "AI Agents", "Model Evaluation", "Deep Learning", "Prompt Engineering") else 1))
            pick = []
            for x in ai_shown:
                if not _taken(x, have | {norm(p) for p in pick}):
                    pick.append(x)
                if len(pick) == 4:
                    break
            if len(pick) >= 3:
                by_cat["ai_ml"] = pick; have |= {norm(p) for p in pick}; lines_est += 1
                rest = [x for x in rest if x not in pick]

    plan = dict(plan)
    plan["optional_skills"] = optional[:25]
    plan["_v33_skills"] = {"jd_named": jd_named, "closure": closure, "mandatory": by_cat, "optional": optional[:25]}
    globals()["_V33_SKILLS"] = plan["_v33_skills"]
    m2 = dict(master)
    skills = deepcopy(master["skills"])
    base = {c: [] for c in master["skills"]["baseline"]}
    for c, vals in by_cat.items():
        base.setdefault(c, []).extend(vals)
    skills["baseline"] = base
    skills["only_prunable_baseline_item"] = None
    m2["skills"] = skills
    g = globals(); orig_sel, orig_req = g["selected_technology_skills"], g["required_ats_skill_displays"]
    g["selected_technology_skills"] = lambda _p, _m, _h: []
    g["required_ats_skill_displays"] = lambda _p, _m: []
    try:
        states = _build_skill_states_v3_1(plan, m2)
    finally:
        g["selected_technology_skills"], g["required_ats_skill_displays"] = orig_sel, orig_req
    for st in states:
        st["required_ats_terms"] = list(must)
        # tools that the JD names or a heading shows must survive the one-line Tools pruning
        st["matched_tools"] = sorted(set(st.get("matched_tools", [])) | {x for x in by_cat.get("tools", [])})
    return states


# heading technologies are always listed in Skills (hard rule; a verification round can never remove them)
def validate_selected_technology_skill_coverage(plan, master, resolved_skills, project_tech):
    return _validate_selected_technology_skill_coverage_v3_1(plan, master, resolved_skills, project_tech)


def adapt_header_tech(pid: str, vals: list[str], plan: dict[str, Any], master: dict[str, Any]) -> list[str]:
    """Technologies the posting names and this project's chosen bullets show move into the heading (up to two swaps),
    replacing heading items the posting does not name; the heading never gets longer than the canonical one."""
    jd = list(plan.get("_jd_pool_terms", []) or [])
    if not jd:
        return vals
    texts = " ".join(bullet_text(b) for b in (plan.get("bullets", {}) or {}).get(pid, []))
    pool = master["projects"][pid].get("tech", [])
    norm_pool = {normalize_skill_name(t, master).casefold(): t for t in pool}
    canon_len = len(", ".join(master["projects"][pid].get("header_priority_tech", vals)))
    out = list(vals)
    jdkeys = {x.casefold() for x in jd}
    langs = {x.casefold() for x in master["skills"]["supported_pool"].get("languages_databases", [])}
    frames = {x.casefold() for x in master["skills"]["supported_pool"].get("frameworks_libraries", [])}
    cands = []
    for t in jd:
        if t in out or (t.casefold() not in {p.casefold() for p in pool} and t.casefold() not in norm_pool):
            continue
        if re.search(r"(?<![A-Za-z])" + re.escape(t) + r"(?![A-Za-z])", texts):
            cands.append(t)
    cands.sort(key=lambda t: (0 if t.casefold() in langs else 1 if t.casefold() in frames else 2))
    for t in cands[:2]:
        spot = next((i for i in range(len(out) - 1, 0, -1) if out[i].casefold() not in jdkeys and out[i] not in cands), None)
        if spot is None:
            break
        cand = out[:spot] + [t] + out[spot + 1:]
        if len(", ".join(cand)) <= canon_len:
            out = cand
    return out


# --- Eligibility: internships that require enrollment past February 2027 ---------

_eligibility_blockers_v32 = eligibility_blockers


def eligibility_blockers(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, str]]:
    blockers = _eligibility_blockers_v32(plan, master)
    kinds = {b["type"] for b in blockers}
    raw = str(plan.get("_raw_jd_text", ""))
    role = str(plan.get("application", {}).get("role", ""))
    if "enrollment_required" not in kinds and re.search(r"\bintern(?:ship)?s?\b|\bco-?op\b", role + " " + raw[:600], re.I):
        for s in [x for x in raw.split("\n") if x.strip()]:
            if re.search(r"\b(?:actively|currently|must be|remain|continuing|returning)\b[^.]{0,60}\b(?:enrolled|enrollment|pursuing|student|to school)\b", s, re.I) and \
               re.search(r"full duration|duration of the (?:internship|program|co-?op)|throughout the (?:internship|program)|after the (?:internship|program)|return(?:ing)? to (?:school|university|their studies)|at least one (?:semester|quarter|term) (?:remaining|left)|graduat\w+ (?:after|no earlier)", s, re.I):
                blockers.append({"type": "enrollment_required", "requirement": s.strip()[:200],
                                 "reason": "The internship requires active enrollment for its full duration; the candidate graduates in February 2027, so a 2027 internship would start after graduation."})
                break
    return blockers


_gating_assessment_v32 = gating_assessment


def gating_assessment(plan: dict[str, Any], master: dict[str, Any], blockers: list[dict[str, str]]) -> dict[str, Any]:
    """v3.3.1: the pipeline never skips. Every former skip reason (sponsorship, clearance, seniority, stack gap,
    enrollment, role mismatch) is reported as a note; Jay decides whether to apply. Seniority notes that come only
    from bonus / nice-to-have lines are dropped, and they no longer cap Fit."""
    g = _gating_assessment_v32(plan, master, blockers)
    for b in blockers:
        if b.get("type") == "enrollment_required" and not any(x["type"] == "enrollment_required" for x in g["skip_reasons"]):
            g["skip_reasons"].append({"type": "enrollment_required", "reason": b.get("requirement", "")[:140]})
    raw = str(plan.get("_raw_jd_text", ""))
    hedged_lines = [l for l, _w, h in _v33_role_lines(raw) if h]
    notes = []
    for x in g["skip_reasons"]:
        if x.get("type") in ("seniority_gap", "seniority_title"):
            m = re.search(r"(\d+)\s*\+?\s*(?:\(\w+\)\s*)?years?", str(x.get("reason", "")))
            yrs = m.group(1) if m else None
            if yrs and hedged_lines and not any(re.search(r"\b" + yrs + r"\s*\+?\s*(?:\(\w+\)\s*)?years?", l) for l, _w, h in _v33_role_lines(raw) if not h):
                continue
        notes.append(x)
    caps_from = {x.get("type") for x in notes}
    if not (caps_from & {"citizenship", "clearance", "sponsorship_denied", "work_authorization_or_sponsorship", "enrollment_required"}):
        g["fit_cap"] = None
    g["warnings"] = list(g.get("warnings", [])) + [{"type": "note_" + str(x.get("type")), "reason": x.get("reason", "")} for x in notes]
    g["skip_reasons"] = []
    plan["_v33_notes"] = notes
    return g


# --- Cover letter: built only from evidence that is on this resume --------------

def _v33_selected_evidence(plan: dict[str, Any], pid: str) -> list[tuple[str, str]]:
    """(variant_id, main_evidence_id) for the bullets rendered under pid, in page order."""
    sel = (plan.get("bank_selection") or {}).get(pid) or []
    out = []
    for b in (plan.get("bullets") or {}).get(pid, []):
        if isinstance(b, dict):
            out.append((str(b.get("_variant_id") or b.get("id") or ""), str(b.get("main_evidence_id", ""))))
    if sel and len(sel) == len(out):
        out = [(sel[i], out[i][1]) for i in range(len(out))]
    return out


def _v33_project_sentences(plan: dict[str, Any], master: dict[str, Any], pid: str, vec: dict[str, float]) -> str:
    bank = master.get("cover_letter_bank", {}).get("letter_sentences", {}).get(pid, {})
    intro = bank.get("intro", "")
    pd = master["projects"][pid]
    head = pd.get("headline_evidence_id")
    picks = []
    for vid, eid in _v33_selected_evidence(plan, pid):
        s = bank.get(vid) or bank.get(eid)
        if not s:
            continue
        it = pd.get("evidence_items", {}).get(eid, {})
        score = (3 if eid == head else 0) + (2 if it.get("hero") else 0) + (2 if re.search(r"\d", s) else 0)
        ctx = globals().get("_V33_LETTER_CTX") or {}
        comp = str(ctx.get("company", ""))
        for tok in re.findall(r"[A-Z][A-Za-z]{3,}", comp):
            if re.search(r"\b" + re.escape(tok) + r"\b", s):
                score += 10
        terms = ctx.get("terms", [])
        score += 1.5 * sum(1 for t in terms if t and boundary_contains_plural(s, t))
        picks.append((score, s))
    picks.sort(key=lambda x: -x[0])
    body = [intro] + [s for _, s in picks[:1]]
    if picks and not re.search(r"\d", " ".join(body)):
        num = next((s for _, s in picks if re.search(r"\d", s)), None)
        if num:
            body.append(num)
    return " ".join(x for x in body if x)


def _v33_experience_key(plan: dict[str, Any], vec: dict[str, float], ranking: list[str]) -> str:
    cl = plan.get("cover_letter") or {}
    if isinstance(cl, dict) and cl.get("experience") in ("thesis_backend", "thesis_client", "hein", "hein_parallel", "godigital", "datamaven"):
        return cl["experience"]
    score = {
        "thesis_client": 1.6 * vec.get("customer", 0) + 0.3 * vec.get("fullstack", 0),
        "datamaven": vec.get("devops_cloud", 0) * 1.4,
        "godigital": vec.get("data_eng", 0) * 1.5,
        "hein": vec.get("llm_agents", 0) + vec.get("ml_dl", 0) + vec.get("model_api", 0) + vec.get("data_science", 0) + 0.6 * vec.get("data_eng", 0) + vec.get("recsys_search", 0) + vec.get("ai_apps", 0),
        "hein_parallel": vec.get("performance", 0) + vec.get("systems", 0) * 0.8 + 0.5 * vec.get("distributed", 0),
        "thesis_backend": vec.get("backend", 0) + vec.get("fullstack", 0) + vec.get("realtime", 0) + 0.6 * vec.get("distributed", 0) + vec.get("payments", 0) * 0.5,
    }
    title = str(plan.get("application", {}).get("role", ""))
    if re.search(r"forward[- ]deployed|solutions? (?:engineer|architect)|customer|client|consult", title, re.I):
        score["thesis_client"] += 1.0
    return max(score, key=lambda k: score[k])


_compose_bank_cover_letter_v32 = compose_bank_cover_letter


def compose_bank_cover_letter(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[dict[str, Any]]:
    failures = _compose_bank_cover_letter_v32(plan, master, raw_jd)
    if not plan.get("cover_letter_paragraphs") or plan.get("_cover_letter_mode") != "bank":
        return failures
    globals()["_V33_CTX"] = {"plan": plan, "raw_jd": raw_jd}
    cl = plan.get("cover_letter") or {}
    app = plan.get("application", {})
    company = str(app.get("company", "")).strip(); role = str(app.get("role", "")).strip()
    vec = plan.get("_jd_theme_vector") or jd_theme_vector(raw_jd, role)
    ranking = plan.get("ranking") or []
    old = plan["cover_letter_paragraphs"]
    # keep the v3.2 opening sentence(s) (role + company + validated hook), replace the evidence sentences
    p1_old = old[0]
    exp_bank = master.get("cover_letter_bank", {})
    old_exp = [v for v in exp_bank.get("experience", {}).values() if v in p1_old]
    head = p1_old.split(old_exp[0])[0].strip() if old_exp else " ".join(re.split(r"(?<=[.!?])\s+", p1_old)[:2])
    ek = _v33_experience_key(plan, vec, ranking)
    exp = exp_bank.get("experience_v33", {}).get(ek) or (old_exp[0] if old_exp else "")
    p1 = f"{head} {exp}".strip()
    _terms = [str(r.get("term", "")) for r in plan.get("jd_requirements", []) if isinstance(r, dict) and r.get("supported") and str(r.get("priority", "")).lower() in ("must", "high")]
    globals()["_V33_LETTER_CTX"] = {"company": company, "terms": _terms}
    projs = [_v33_project_sentences(plan, master, pid, vec) for pid in ranking[:2]]
    projs = [p for p in projs if p]
    if len(projs) == 2 and projs[1].startswith("I built "):
        projs[1] = "I also built " + projs[1][len("I built "):]
    if len(projs) == 2 and projs[1].startswith("I also built") and projs[0].startswith("I also built"):
        projs[0] = projs[0].replace("I also built", "I built", 1)
    if projs and projs[0].startswith("I also built"):
        projs[0] = projs[0].replace("I also built", "I built", 1)
    # logistics: internships never promise a start "soon after" graduation; remote roles never mention relocation
    loc = str(app.get("location", "")).strip()
    remote = bool(re.search(r"\bremote\b", loc + " " + raw_jd[:400], re.I)) and not re.search(r"hybrid|onsite|on-site|in office", loc, re.I)
    reloc = bool(loc) and loc.lower() not in ("not stated", "n/a", "unknown") and not remote and not re.search(r"buffalo", loc, re.I)
    intern = bool(re.search(r"\bintern(?:ship)?s?\b|\bco-?op\b", role, re.I))
    if intern:
        logistics = "My Master's in Computer Science at the University at Buffalo is expected in February 2027."
    else:
        logistics = "I graduate in February 2027 and can start soon after." + (" I am open to relocating." if reloc else "")
    old_p2 = old[1]
    closing = next((s for s in re.split(r"(?<=[.!?])\s+", old_p2) if s.startswith("I would welcome the chance to ")), "")
    p2 = " ".join(x for x in [*projs, logistics, closing] if x)
    plan["cover_letter_paragraphs"] = [p1, p2]
    plan["_v33_letter"] = {"experience": ek, "projects": ranking[:2]}
    return failures


_validate_cover_letter_v32_base = validate_cover_letter_v32


def validate_cover_letter_v32(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    cl = plan.get("cover_letter") or {}
    hook = str(cl.get("hook", "")).strip() if isinstance(cl, dict) else ""
    out = []
    for f in _validate_cover_letter_v32_base(plan, master):
        if f.get("type") == "cover_letter_banned_phrase":
            _app = plan.get("application", {})
            _txt = "\n".join(plan.get("cover_letter_paragraphs", []))
            for _n in sorted([str(_app.get("company", "")), str(_app.get("role", ""))], key=len, reverse=True):
                if _n.strip():
                    _txt = re.sub(re.escape(_n.strip()), " ", _txt, flags=re.I)
            left = [b for b in f.get("measured", []) if re.search(r"\b" + re.escape(str(b)) + r"\b", _txt, re.I)]
            if not left:
                continue
            f = dict(f); f["measured"] = left
        if f.get("type") == "cover_letter_unsupported_claim" and hook:
            # the hook describes the TEAM's work in the JD's words (it never claims Jay did it): gap terms there are fine
            _txt = "\n".join(plan.get("cover_letter_paragraphs", []))
            _app = plan.get("application", {})
            for _n in sorted([hook, str(_app.get("role", "")), str(_app.get("company", "")), str(cl.get("team_focus", ""))], key=len, reverse=True):
                if _n.strip():
                    _txt = re.sub(re.escape(_n.strip()), " ", _txt, flags=re.I)
            meas = [x for x in f.get("measured", []) if boundary_contains_plural(_txt, x)]
            if not meas:
                continue
            f = dict(f); f["measured"] = meas
        out.append(f)
    # mission echo: the hook must come from the role's own text, not the company blurb
    raw = str(plan.get("_raw_jd_text", ""))
    if hook and raw:
        role_txt = " ".join(l for l, w, _h in _v33_role_lines(raw) if _V33_LINE_MODE.get(l, 1.0) >= 0.6).lower()
        hw = re.findall(r"[a-z0-9][a-z0-9'&+#.-]*", hook.lower())
        rw = re.findall(r"[a-z0-9][a-z0-9'&+#.-]*", role_txt)
        rset = {" ".join(rw[i:i + 4]) for i in range(len(rw) - 3)}
        if not any(" ".join(hw[i:i + 4]) in rset for i in range(len(hw) - 3)):
            out.append(fail("cover_letter_hook_mission_echo", "cover_letter.hook", hook, "4+ consecutive words from the role, responsibilities or requirements (not the company/mission blurb)",
                            "Say what draws you to this team's actual work, using words from 'What you'll do' / requirements."))
    return out


# --- Quality gate (runs after the letter is written) -------------------------------

_final_output_scan_v32 = final_output_scan


def _v33_quality(out_dir: Path, names: dict[str, str]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    ctx = globals().get("_V33_CTX") or {}
    plan = ctx.get("plan") or {}
    master = globals().get("_V33_MASTER")
    fails, info = [], {}
    rp_path = out_dir / "resolved_plan.json"
    if not plan or master is None or not rp_path.exists():
        return fails, info
    rp = json.loads(rp_path.read_text(encoding="utf-8"))
    skills = (rp.get("skill_resolution") or {}).get("skills", {})
    raw_jd = str(plan.get("_raw_jd_text", ""))
    header = rp.get("project_tech", {})
    page = _v33_page_text(plan, master, header)
    jd_named = {normalize_skill_name(x, master).casefold() for x in (globals().get("_V33_SKILLS") or {}).get("jd_named", [])}
    unshown = []
    for cat, vals in skills.items():
        for x in vals:
            k = normalize_skill_name(x, master).casefold()
            if k in jd_named or _v33_shown(x, page, master) or x in master["skills"].get("universal_allowed", []) or (raw_jd and boundary_contains_plural(raw_jd, x)):
                continue
            unshown.append(x)
    thin = {cat: vals for cat, vals in skills.items() if vals and len(vals) < 3}
    info.update({"skills_not_shown_or_named": unshown, "skills_lines_under_3": thin})
    if unshown:
        fails.append(fail("v33_skill_not_shown_or_named", "TECHNICAL SKILLS", unshown, "every skill is named by the JD or shown on the page", "Pipeline defect: report it (the v3.3 gate should prevent this)."))
    # rendered page checks
    try:
        pdf = out_dir / names["resume_pdf"]
        with fitz.open(pdf) as doc:
            pg = doc[0]
            free = _v33_free_space(pg)
            info["free_space_pt"] = free
            info["pages"] = len(doc)
            txt = pg.get_text()
        sk = txt.split("TECHNICAL SKILLS", 1)[-1].split("CERTIFICATIONS", 1)[0]
        info["skills_rendered_lines"] = len([l for l in sk.splitlines() if l.strip() and "AWARDS" not in l and "1st Place" not in l and "Certified" not in l])
        if free < 10.0:
            fails.append(fail("v33_page_buffer", "layout", free, ">= 10pt free above the bottom margin", "Pipeline defect: the skills fitter should leave a 10pt buffer."))
    except Exception as e:  # never break a run on a measurement problem
        info["measure_error"] = str(e)[:120]
    # letter consistency: every number in the letter is on the resume page
    letter = "\n".join(plan.get("cover_letter_paragraphs", []))
    _app = plan.get("application", {})
    for _n in sorted([str(_app.get("company", "")), str(_app.get("role", ""))], key=len, reverse=True):
        if _n:
            letter = letter.replace(_n, " ")
    page_all = page
    nums = [n for n in numeric_tokens(letter) if not YEAR_RE.match(normalize_numeric(n).rstrip("%+"))]
    missing = [n for n in nums if normalize_numeric(n).rstrip("%+") not in {normalize_numeric(x).rstrip("%+") for x in numeric_tokens(page_all)}]
    info["letter_numbers_not_on_resume"] = missing
    if missing:
        fails.append(fail("v33_letter_number_not_on_resume", "cover_letter_paragraphs", missing, "every letter number appears on the resume", "Use only results the resume shows."))
    info["letter_words"] = sum(_letter_words(p) for p in plan.get("cover_letter_paragraphs", []))
    return fails, info


def final_output_scan(out_dir: Path, names: dict[str, str], outreach: dict[str, Any]) -> list[dict[str, Any]]:
    out = _final_output_scan_v32(out_dir, names, outreach)
    try:
        f, info = _v33_quality(Path(out_dir), names)
    except Exception as e:
        f, info = [], {"error": str(e)[:200]}
    try:
        tex = Path(out_dir) / names.get("resume_tex_clean", "")
        if tex.is_file():
            info["resume_tex_sha256"] = hashlib.sha256(tex.read_bytes()).hexdigest()
            (Path(out_dir) / "tex_sha256.txt").write_text(info["resume_tex_sha256"] + "  " + tex.name + "\n", encoding="utf-8")
    except Exception:
        pass
    (Path(out_dir) / "quality_v33.json").write_text(json.dumps(info, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return out + f


_prepare_runtime_cache_v32 = _prepare_runtime_cache


def _prepare_runtime_cache(master: dict[str, Any]) -> dict[str, Any]:
    globals()["_V33_MASTER"] = master
    if not v349c_on() and id(master) not in _V349C_RESTORED:   # v3.4.9c data_v349c off: the v3.4.9b data (before the v3.4.8b restore)
        v349c_restore_master(master)
        _V349C_RESTORED.add(id(master))
    if not v348b_on() and id(master) not in _V348B_RESTORED:   # v3.4.8b D1 off: the v3.4.8a facts (test switch / rollback)
        v348b_restore_master(master)
        _V348B_RESTORED.add(id(master))
    globals()["V33_MIN_BUFFER_PT"] = V349C_PAGE_BUFFER_PT if v349c_page_on() else 10.0   # v3.4.9c run 2 P5
    if v349c_page_on() and id(master) not in _V349C_PAGE_APPLIED:   # v3.4.9c run 2 P4
        v349c_page_master(master)
        _V349C_PAGE_APPLIED.add(id(master))
    return _prepare_runtime_cache_v32(master)



def _v33_free_space(pg) -> float:
    base = 0.0
    for b in pg.get_text("dict").get("blocks", []):
        for l in b.get("lines", []):
            for sp in l.get("spans", []):
                if sp.get("text", "").strip():
                    base = max(base, sp["origin"][1])
    return round(pg.rect.height - 0.21 * 72 - base, 1)


_run_pdflatex_v32 = run_pdflatex
V33_MIN_BUFFER_PT = 10.0


def run_pdflatex(tex_path: Path, cwd: Path) -> tuple[int, str, float]:
    rc, log, el = _run_pdflatex_v32(tex_path, cwd)
    pdf = Path(cwd) / (Path(tex_path).stem + ".pdf")
    tries = []
    for _ in range(0 if (v349c_layout_on() and V349C_CTX.get("skills_trim") is False) else 3):   # v3.4.9c run 4 L2: Skills filler leaves at step 2
        if rc != 0 or not pdf.exists():
            break
        try:
            with fitz.open(pdf) as d:
                pages = len(d); free = _v33_free_space(d[0])
        except Exception:
            break
        tries.append({"pages": pages, "free_pt": free})
        if pages == 1 and free >= V33_MIN_BUFFER_PT:
            break
        tex = Path(tex_path).read_text(encoding="utf-8")
        m = re.search(r"\\ifnum\\SkillTotalCount>(\d+) \\SkillStateFitsfalse\\fi", tex)
        if not m or int(m.group(1)) <= 4:
            break
        n = int(m.group(1)) - 1
        tex = re.sub(r"\\ifnum\\SkillTotalCount>\d+ \\SkillStateFitsfalse\\fi", lambda _m: "\\ifnum\\SkillTotalCount>%d \\SkillStateFitsfalse\\fi" % n, tex)
        prev_tex, prev = Path(tex_path).read_text(encoding="utf-8"), (rc, log)
        Path(tex_path).write_text(tex, encoding="utf-8")
        rc, log, el2 = _run_pdflatex_v32(tex_path, cwd); el += el2
        if "SKILLSTATEPASS" not in log:
            # the required skills need more lines than this budget: keep the previous page and report the buffer
            Path(tex_path).write_text(prev_tex, encoding="utf-8")
            rc, log, el3 = _run_pdflatex_v32(tex_path, cwd); el += el3
            tries.append({"note": "required skills need %d+ lines; buffer not reachable by trimming skills" % (n + 1)})
            break
    globals()["_V33_COMPILE"] = tries
    return rc, log, el


def load_skill_fit_cache() -> dict[str, Any]:
    return {}  # v3.3: always measure, so the page-buffer loop can act


def save_skill_fit_cache(cache: dict[str, Any]) -> None:
    return None


_auto_bank_selection_v32 = auto_bank_selection


def auto_bank_selection(raw_plan, bank, pairs=None):
    """v3.2 selector first; if its top-40 lists hold no verb-distinct 3/2/2 set, retry over every valid combination."""
    sel, info = _auto_bank_selection_v32(raw_plan, bank, pairs)
    if sel is not None:
        return sel, info
    import inspect
    src = inspect.getsource(_auto_bank_selection_v32).replace("[:40] or allc[:40]", "[:400] or allc[:400]")
    src = src.replace("def auto_bank_selection(", "def _v33_bank_selection_wide(", 1)
    ns: dict[str, Any] = {}
    exec(compile(src, "<v33_wide>", "exec"), globals(), ns)
    sel, info = ns["_v33_bank_selection_wide"](raw_plan, bank, pairs)
    if sel is not None:
        info = dict(info); info["widened"] = True
    return sel, info


_apply_auto_plan_fields_v33a = apply_auto_plan_fields


def apply_auto_plan_fields(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    auto_tag = raw_plan.get("tagline_id") in (None, "", "auto")
    _apply_auto_plan_fields_v33a(raw_plan, master, raw_jd)
    if not auto_tag:
        return
    v = raw_plan.get("_jd_theme_vector") or {}
    allowed = (master.get("role_families", {}).get(raw_plan.get("role_family"), {}) or {}).get("tagline_ids", [])
    pick = None
    if "llm_apps" in allowed and v.get("model_api", 0) >= 0.12:
        pick = "llm_apps"
    elif "ml_models" in allowed and v.get("ml_dl", 0) + v.get("data_science", 0) >= 0.3:
        pick = "ml_models"
    if pick:
        raw_plan["tagline_id"] = pick
        th = master.get("taglines", {}).get("options", {}).get(pick, {}).get("themes", [])
        raw_plan["jd_themes"] = list(dict.fromkeys(list(raw_plan.get("jd_themes", [])) + list(th)))


_hard_gaps_v32 = hard_gaps


def hard_gaps(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    hed = {str(r.get("term", "")).casefold() for r in plan.get("jd_requirements", []) if isinstance(r, dict) and r.get("hedged")}
    return [g for g in _hard_gaps_v32(plan, master) if str(g.get("term", "")).casefold() not in hed]


# ===========================================================================
# v3.3.2 additions
# ===========================================================================
import urllib.parse

_V33_THEME_RX["it_ops"] = (r"\bcorporate it\b|\bit (?:systems|operations|support|infrastructure|engineering)\b|\bidentity\b|\bsso\b|"
                           r"\bendpoints? management\b|\bmdm\b|\bgoogle workspace\b|\bokta\b|\bprovisioning\b|\bonboarding\b|\bsaas\b|\bhelp ?desk\b|\bintegrations?\b")
_V33_THEME_DAMP["it_ops"] = 0.8

_v33_experience_key_v331 = _v33_experience_key


def _v33_experience_key(plan, vec, ranking):
    if vec.get("it_ops", 0) >= 0.15 and not ((plan.get("cover_letter") or {}).get("experience")):
        return "datamaven"
    return _v33_experience_key_v331(plan, vec, ranking)

_V332_AI_TOOLS = re.compile(r"claude code|\bcursor\b|copilot|\bcodex\b|ai[- ](?:assisted|coding|powered) (?:development |coding )?tools?|ai coding|ai tools (?:throughout|across|in)|utilize ai tools|ai[- ]assisted development", re.I)
_V332_ALT_LINE = re.compile(r"\be\.?g\.?\b|such as|for example|or similar|or equivalent|of choice|one or more of|any of|\(.*\bor\b.*\)|, or ", re.I)


def _v332_supported_names(master: dict[str, Any]) -> list[str]:
    names = [x for vals in master["skills"]["supported_pool"].values() for x in vals]
    names += [t for p in master["projects"].values() for t in p.get("tech", [])]
    names += [a for a in master["skills"].get("normalization", {}).keys() if len(a) > 2]
    return [n for n in dict.fromkeys(names) if n and len(n) > 1]


def _v332_alternative_gaps(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[str]:
    """An unsupported item that appears only in example / either-or lists that ALSO name something Jay has
    ("SQL and NoSQL databases (e.g. Postgres, Redis, Elasticsearch, RabbitMQ)", "one IDE of choice (Visual Studio,
    VS Code, ...)") is an alternative, not a hard gap."""
    sup = _v332_supported_names(master)
    out = []
    lines = [l for l in raw_jd.splitlines() if l.strip()]
    for r in raw_plan.get("jd_requirements", []) or []:
        if not isinstance(r, dict) or r.get("supported") is not False or r.get("hedged"):
            continue
        spell = [s for s in [str(r.get("term", ""))] + [str(a) for a in r.get("aliases", [])] if len(s) > 1]
        hits = [l for l in lines if any(boundary_contains_plural(l, s) for s in spell)]
        if not hits:
            continue
        if all(_V332_ALT_LINE.search(l) and any(boundary_contains_plural(l, n) for n in sup if not any(n.casefold() == s.casefold() for s in spell)) for l in hits):
            if str(r.get("priority", "")).lower() in ("must", "high"):
                r["priority"] = "medium"
            r.pop("required_section", None)
            r["hedged"] = True
            r["alternative"] = True
            out.append(str(r.get("term", "")))
    return out


_apply_auto_plan_fields_v331 = apply_auto_plan_fields


def apply_auto_plan_fields(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    _apply_auto_plan_fields_v331(raw_plan, master, raw_jd)
    if raw_plan.get("_jd_requirements_auto"):
        alt = _v332_alternative_gaps(raw_plan, master, raw_jd)
        if alt:
            raw_plan["_hedged_requirements"] = list(dict.fromkeys(list(raw_plan.get("_hedged_requirements", [])) + alt))
            raw_plan["_alternative_requirements"] = alt
            _order = {"must": 0, "high": 1, "medium": 2}
            raw_plan["jd_requirements"] = sorted(raw_plan.get("jd_requirements", []), key=lambda r: _order.get(str(r.get("priority", "")).lower(), 2))
            if str(raw_plan.get("application", {}).get("fit", "")).lower() in ("", "auto", "low", "medium", "high"):
                musts = [r for r in raw_plan.get("jd_requirements", []) if r.get("priority") in ("must", "high")]
                sup = [r for r in musts if r.get("supported")]
                ratio = (len(sup) / len(musts)) if musts else 1.0
                raw_plan["application"]["fit"] = "High" if ratio >= 0.85 else ("Medium" if ratio >= 0.6 else "Low")
    # bullets that answer the posting's specific asks (only matter when that project is selected)
    prefer = list(raw_plan.get("prefer_variants", []) or [])
    vec = raw_plan.get("_jd_theme_vector") or {}
    if _V332_AI_TOOLS.search(raw_jd):
        raw_plan["_ai_coding_tools"] = True
        prefer.append("ripple.cc.a")
    if vec.get("data_eng", 0) >= 0.15:
        prefer.append("fraud.data.a")
    raw_plan["prefer_variants"] = list(dict.fromkeys(prefer))


_auto_project_scores_v331 = auto_project_scores


def auto_project_scores(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> dict[str, float]:
    if plan.get("_ai_coding_tools") and "ripple" in master["projects"]:
        # "AI coding tools (Claude Code, Cursor, Codex) across the SDLC": RIPPLE was written with Claude Code
        vec = plan.setdefault("_jd_theme_vector", jd_theme_vector(raw_jd, str(plan.get("application", {}).get("role", ""))))
        vec["devtools"] = max(vec.get("devtools", 0), 0.15)
    return _auto_project_scores_v331(plan, master, raw_jd)


_variant_score_v331 = _variant_score


def _variant_score(v, weights, themes, prefer, breakdown: bool = False):
    """A bullet with a measured result beats one without (+1 more than v3.2), so every project shows a number."""
    r = _variant_score_v331(v, weights, themes, prefer, breakdown)
    bonus = 1.0 if re.search(r"\d", str(v.get("text", ""))) else 0.0
    if breakdown:
        s, parts = r
        return s + bonus, parts + ([("metric_v332", bonus, "")] if bonus else [])
    return r + bonus


# --- LinkedIn outreach -------------------------------------------------------------

_V332_JOB_URL = re.compile(r"^https://(?:www\.)?linkedin\.com/jobs/view/[A-Za-z0-9-]+/?$")
_V332_CO_URL = re.compile(r"^https://(?:www\.)?linkedin\.com/company/([A-Za-z0-9-]+)/?$")
_V332_TEAM = [
    (r"\bIT\b|corporate systems|information technology", "IT systems"),
    (r"\bdata engineer", "data engineering"), (r"\bbackend|back-end", "backend engineering"), (r"full[- ]?stack", "full stack engineering"),
    (r"front[- ]?end", "frontend engineering"), (r"\b(?:sre|site reliability)\b", "site reliability"), (r"\bcloud\b", "cloud engineering"),
    (r"\bdevops|platform|infrastructure", "platform engineering"), (r"machine learning|\bml\b|deep learning", "machine learning"),
    (r"\bai\b|llm|agent", "AI engineering"), (r"\bdata scien", "data science"), (r"\b(?:qa|sdet|test)\b", "quality engineering"),
    (r"forward[- ]deployed", "forward deployed engineering"), (r"embedded|firmware|systems software", "systems software"),
    (r"developer technology", "developer technology"), (r"product engineer", "product engineering"),
]


def _v332_short_role(role: str, company: str = "") -> str:
    r = re.sub(r"\s*\([^)]*\)", "", str(role)).strip()
    if company and not company_is_placeholder(company):
        r = re.sub(r"^" + re.escape(company) + r"\s+", "", r, flags=re.I).strip()
    m = re.match(r"^(?:\d{4}\s+)?internships?\s*:\s*(.+)$", r, re.I)
    if m:
        r = m.group(1).strip() + " Internship"
    if " - " in r and (len(r) > 36 or re.search(r"grad|intern|20\d\d|remote|public sector|team", r.split(" - ", 1)[1], re.I)):
        r = r.split(" - ", 1)[0].strip()
    r = re.sub(r"\s*\|.*$", "", r).strip(" ,-")
    return r


def _v332_requisition(plan: dict[str, Any], raw_jd: str) -> str:
    rid = str(plan.get("application", {}).get("requisition_id", "") or "").strip()
    if rid:
        return rid
    m = re.search(r"(?:job\s+)?requisition\s*(?:id|#|number)?\s*[:#]?\s*\n?\s*([A-Z]{0,4}-?\d{5,9}(?:-\d+)?)", raw_jd, re.I) or \
        re.search(r"\b(?:req(?:uisition)?\.?\s*(?:id|#)|job\s*id)\s*[:#]?\s*([A-Z]{0,4}-?\d{5,9})", raw_jd, re.I) or \
        re.search(r"\b(JR\d{6,8}|R-\d{5,8})\b", raw_jd)
    return m.group(1) if m else ""


def _v332_proof(plan: dict[str, Any], master: dict[str, Any]) -> str:
    proofs = master.get("outreach_proofs", {})
    top = (plan.get("ranking") or [None])[0]
    best, best_s = "", -1.0
    for vid, eid in (_v33_selected_evidence(plan, top) if top else []):
        s = proofs.get(vid) or proofs.get(eid)
        if not s:
            continue
        it = master["projects"][top].get("evidence_items", {}).get(eid, {})
        sc = (3 if eid == master["projects"][top].get("headline_evidence_id") else 0) + (2 if it.get("hero") else 0) + (2 if re.search(r"\d", s) else 0)
        if plan.get("_ai_coding_tools") and vid.startswith("ripple.cc"):
            sc += 10
        if sc > best_s:
            best, best_s = s, sc
    vec = plan.get("_jd_theme_vector") or {}
    ek = (plan.get("_v33_letter") or {}).get("experience", "hein")
    exp_first = (ek == "godigital" and vec.get("data_eng", 0) >= 0.2) or (ek == "datamaven" and (vec.get("it_ops", 0) >= 0.15 or vec.get("devops_cloud", 0) >= 0.25)) \
        or (ek == "thesis_client" and vec.get("customer", 0) >= 0.2)
    if (exp_first or not best) and proofs.get("exp." + ek):
        best = proofs.get("exp." + ek)
    return best


_build_outreach_v331 = build_outreach


def build_outreach(plan: dict[str, Any], master: dict[str, Any], display_order: list[str]):
    base = _build_outreach_v331(plan, master, display_order)
    app = plan.get("application", {})
    company = str(app.get("company", "")).strip()
    co_ok = not company_is_placeholder(company)
    raw = str(plan.get("_raw_jd_text", ""))
    role = str(app.get("role", "")).strip()
    short = _v332_short_role(role, company) if not role_is_placeholder(role) else "the open engineering role"
    team = str(app.get("linkedin_team_area", "") or "").strip()
    if not team:
        team = next((t for rx, t in _V332_TEAM if re.search(rx, role, re.I)), "software engineering")
    eng = re.sub(r"engineering$", "engineer", team) if team.endswith("engineering") else team + " engineer"
    enc = lambda s: urllib.parse.quote(re.sub(r"\s+", " ", s).strip())
    li: dict[str, Any] = {"short_role": short, "team_area": team}
    job_url = str(app.get("linkedin_job_url", "") or "").strip()
    job_match = str(app.get("linkedin_job_match", "") or "").strip().lower()
    li["job_post"] = job_url if _V332_JOB_URL.match(job_url) else "not found"
    li["job_post_match"] = job_match if li["job_post"] != "not found" and job_match in ("exact", "possible") else ("" if li["job_post"] == "not found" else "exact")
    rid = _v332_requisition(plan, raw)
    li["requisition_id"] = rid
    li["job_search"] = "https://www.linkedin.com/jobs/search/?keywords=" + enc(f"{short} {company if co_ok else ''}")
    if rid:
        li["job_search_requisition"] = "https://www.linkedin.com/jobs/search/?keywords=" + enc(f"{rid} {company if co_ok else ''}")
    co_url = str(app.get("linkedin_company_url", "") or "").strip()
    m = _V332_CO_URL.match(co_url)
    li["company_page"] = f"https://www.linkedin.com/company/{m.group(1)}" if m else "not found"
    if m:
        root = f"https://www.linkedin.com/company/{m.group(1)}/people/?keywords="
        li["people"] = {"manager": root + enc(f"{team} manager"), "team_engineers": root + enc(eng),
                        "recruiters": root + enc("technical recruiter"), "ub_alumni": root + enc("University at Buffalo")}
    else:
        root = "https://www.linkedin.com/search/results/people/?keywords="
        li["people"] = {"manager": root + enc(f"{company} {team} manager"), "team_engineers": root + enc(f"{company} {eng}"),
                        "recruiters": root + enc(f"{company} technical recruiter"), "ub_alumni": root + enc(f"{company} University at Buffalo")}
    # contacts the posting names itself
    named = []
    for mm in re.finditer(r"([A-Z][a-z]+(?:\s[A-Z][a-z]+){1,2})\s*,?\s*\(?([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[a-z]{2,})\)?", raw):
        named.append({"name": mm.group(1), "email": mm.group(2)})
    li["named_in_posting"] = named
    at = f"at {company}" if co_ok else "on your team"
    rp = short if short.startswith("the ") else ("the " + short + ("" if re.search(r"intern", short, re.I) else " role"))
    proof = _v332_proof(plan, master)
    req = f" (req {rid})" if rid else ""
    notes = {
        "hiring_manager": f"Hi {{Name}}, I applied for {rp} {at}. {proof} I'd value connecting and being considered for your team. – Jay",
        "ub_alum": f"Hi {{Name}}, fellow UB CS grad student here. I applied for {rp} {at}. Would you be open to a quick chat about the team, or a referral if I seem a fit? Thanks, Jay",
        "recruiter": f"Hi {{Name}}, I applied for {rp} {at}{req}. {proof} Happy to share anything that helps your review. – Jay",
    }
    for k in list(notes):
        n = re.sub(r"\s+", " ", notes[k]).replace(" .", ".")
        if len(n) > 290:
            n = re.sub(r"\s+", " ", notes[k].replace(proof, "")).replace(" .", ".")
        if len(n) > 290 and k == "hiring_manager":
            n = f"Hi {{Name}}, I applied for {rp} {at}. I'd value connecting and being considered for your team. – Jay"
        notes[k] = n
    li["notes"] = notes
    li["notes_chars"] = {k: len(v) for k, v in notes.items()}
    # every number in a note must be on the resume
    page = _v33_page_text(plan, master, resolved_project_header_tech(master, plan.get("ranking", []), plan))
    pagenums = {normalize_numeric(x).rstrip("%+") for x in numeric_tokens(page)}
    _strip = lambda v: re.sub("|".join(re.escape(z) for z in [rid, company, role, short] if z) or "$^", " ", v)
    li["note_numbers_not_on_resume"] = [x for v in notes.values() for x in numeric_tokens(_strip(v))
                                        if normalize_numeric(x).rstrip("%+") not in pagenums and not YEAR_RE.match(normalize_numeric(x))]
    block = [f"Company LinkedIn: {li['company_page']}",
             f"LinkedIn job: {li['job_post']}" + (f" ({li['job_post_match']} match)" if li["job_post"] != "not found" else "") + f" | Job search: {li['job_search']}" + (f" | Req search: {li['job_search_requisition']}" if rid else ""),
             "People: Manager " + li["people"]["manager"] + " | Team engineers " + li["people"]["team_engineers"] + " | Recruiters " + li["people"]["recruiters"] + " | UB alumni " + li["people"]["ub_alumni"]]
    if named:
        block.append("Named in posting: " + "; ".join(f"{x['name']} <{x['email']}>" for x in named))
    block += [f"Note to hiring manager ({len(notes['hiring_manager'])} chars): {notes['hiring_manager']}",
              f"Note to UB alum ({len(notes['ub_alum'])} chars): {notes['ub_alum']}",
              f"Note to recruiter ({len(notes['recruiter'])} chars): {notes['recruiter']}"]
    li["block"] = "\n".join(block)
    base["linkedin"] = li
    return base



_gating_assessment_v332 = gating_assessment


def gating_assessment(plan: dict[str, Any], master: dict[str, Any], blockers: list[dict[str, str]]) -> dict[str, Any]:
    g = _gating_assessment_v332(plan, master, blockers)
    raw = str(plan.get("_raw_jd_text", ""))
    yrs = []
    for line, _w, hedged in _v33_role_lines(raw):
        if hedged:
            continue
        for m in re.finditer(r"(\d{1,2})\s*\+?\s*(?:\(\w+\)\s*)?(?:or more\s+)?years?", line, re.I):
            if re.search(r"experience|engineer|industry|hands-on|professional|working", line, re.I) and not re.search(r"degree|bachelor|master|ph\.?d", line[:m.start()], re.I):
                yrs.append(int(m.group(1)))
    if yrs:
        need = max(yrs)
        plan["_years_required"] = need
        if need >= 3 and not any(w.get("type") == "note_experience_years" for w in g.get("warnings", [])):
            g.setdefault("warnings", []).append({"type": "note_experience_years", "reason": f"Posting asks for {need}+ years; Jay has about 2 years of professional experience."})
        cap = "Low" if need >= 5 else ("Medium" if need >= 3 else None)
        if cap and (g.get("fit_cap") in (None, "High") or (g.get("fit_cap") == "Medium" and cap == "Low")):
            g["fit_cap"] = cap
    reqs = [r for r in plan.get("jd_requirements", []) if isinstance(r, dict)]
    if len(reqs) < 8 and g.get("fit_cap") in (None, "High"):
        g["fit_cap"] = "Medium"   # too few requirements parsed to call it High
    return g


# ===========================================================================
# v3.4 layer (2026-10-13)
# 1. Domain themes: edtech (learning platforms), integration (system-to-system APIs, serverless, retries),
#    healthcare (proven by Experience, never scores projects). "integrations" no longer means corporate IT.
# 2. A required/responsibility line asking for AI coding tools forces RIPPLE onto the page AND forces its
#    Claude Code bullet (it used to be a soft preference that lost on verb conflicts).
# 3. Cover letter: healthcare/clinical roles lead with the Thesis healthcare + client-requirements sentence;
#    the RIPPLE sentence names Claude Code when the posting asks for AI coding tools; full-time logistics
#    say the real month ("can start work that month"), never "soon after".
# 4. Quality gate: project bullets may not reuse an Experience verb; a forced bullet that did not land fails.
# ===========================================================================
PIPELINE_VERSION = "v3.4.0"

_V34_TECH_NEAR = r"(?:apis?|aws|serverless|events?|services?|endpoints?|webhooks?|queues?)"
_V33_THEME_RX["it_ops"] = (r"\bcorporate it\b|\bit (?:systems|operations|support|infrastructure|engineering)\b|\bidentity\b|\bsso\b|"
                           r"\bendpoints? management\b|\bmdm\b|\bgoogle workspace\b|\bokta\b|\bprovisioning\b|\bonboarding\b|\bsaas\b|\bhelp ?desk\b|"
                           r"\bintegrations?\b(?![^.]{0,45}\b" + _V34_TECH_NEAR + r"\b)(?! tests?\b| testing\b)")
_V33_THEME_RX["edtech"] = (r"\blearning (?:platforms?|programs?|activities|activity|experiences?|management|content|tools?|outcomes)\b|"
                           r"\bstudents?(?=,? (?:and )?(?:instructors|teachers|educators|faculty))|\binstructors?\b|\beducators?\b|"
                           r"\beducation(?:al)? technology\b|\bed[- ]?tech\b|\bmanaging courses\b|\bcourses? (?:management|content|catalog|creation)\b|"
                           r"\blessons?\b(?! learned)|\bquiz(?:zes)?\b|\bcurricul(?:um|a)\b(?! vitae)|\bclassrooms?\b|\btutoring\b|\blms\b|\bstudent progress\b|\bprogress displays?\b")
_V33_THEME_RX["healthcare"] = (r"\bhealth ?care\b|\bclinical\b|\bpatients?\b|\bmedical\b|\bhospitals?\b|\bpharma\w*|\btherapeutic\b|\blife sciences\b|"
                               r"\bbiotech\w*|\bregulatory\b|\bhipaa\b|\bfhir\b|\behr\b|\btele(?:health|medicine)\b|\bmedicines?\b")
_V33_THEME_RX["integration"] = (r"(?<!llm )(?<!ai )\bintegrations?\b(?=[^.]{0,45}\b" + _V34_TECH_NEAR + r"\b)|\b(?:api|system|service|third[- ]party|enterprise|application)[- ]integrations?\b|"
                                r"\bsystem[- ]to[- ]system\b|\bmiddleware\b|\bserverless\b|\blambda\b|\bstep functions\b|\bsqs\b|\bsns\b|\beventbridge\b|"
                                r"\bapi gateway\b|\bwebhooks?\b|\bmessage brokers?\b|\bretr(?:y|ies)\b|\berror handling\b|\bidempoten\w+|\bmulesoft\b|\bboomi\b|\bopenapi\b")
_V33_THEME_DAMP["integration"] = 0.8
_V33_THEME_DAMP["edtech"] = 0.9

_V332_AI_TOOLS = re.compile(_V332_AI_TOOLS.pattern + r"|ai development tools|agent[- ]generated code|ai[- ]generated code|\bcoding agents?\b", re.I)

_jd_theme_vector_v333 = jd_theme_vector


def jd_theme_vector(raw_jd: str, title: str = "", company: str = "") -> dict[str, float]:
    vec = _jd_theme_vector_v333(raw_jd, title, company)
    boost = []
    tl = str(title or "")
    if re.search(r"\bintegrations?\b|\bmiddleware\b|\binterfaces? engineer", tl, re.I):
        boost.append("integration")
    if re.search(r"\b(?:ed ?tech|education|learning|curriculum)\b", tl, re.I) and not re.search(r"machine learning|deep learning", tl, re.I):
        boost.append("edtech")
    if boost:
        for t in boost:
            vec[t] = vec.get(t, 0) + 0.15 / len(boost)
        tot = sum(vec.values()) or 1.0
        vec = {t: round(v / tot, 4) for t, v in vec.items()}
    return vec


def _v34_ai_tools_required(raw_jd: str) -> bool:
    """True when a non-hedged role line (responsibilities / requirements / role description) asks for AI coding tools."""
    for line, w, hedged in _v33_role_lines(raw_jd):
        if hedged or w < 0.95:
            continue
        if _V332_AI_TOOLS.search(line):
            return True
    return False


_V34_FORCE_RIPPLE = ["ripple.cc.c", "ripple.cc.a", "ripple.cc.b"]
_apply_auto_plan_fields_v332 = apply_auto_plan_fields


def apply_auto_plan_fields(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    _apply_auto_plan_fields_v332(raw_plan, master, raw_jd)
    if _v34_ai_tools_required(raw_jd) and "ripple" in master.get("projects", {}):
        raw_plan["_ai_coding_tools"] = True
        raw_plan["_v34_force"] = {"ripple": list(_V34_FORCE_RIPPLE)}
        prefer = [x for x in (raw_plan.get("prefer_variants") or []) if not str(x).startswith("ripple.cc.")]
        raw_plan["prefer_variants"] = list(dict.fromkeys(prefer + list(_V34_FORCE_RIPPLE)))


_auto_project_scores_v332 = auto_project_scores


def auto_project_scores(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> dict[str, float]:
    saved = plan.get("_jd_theme_vector")
    if isinstance(saved, dict) and "healthcare" in saved:
        plan["_jd_theme_vector"] = {k: v for k, v in saved.items() if k != "healthcare"}  # Experience proves healthcare, not projects
    try:
        scores = _auto_project_scores_v332(plan, master, raw_jd)
    finally:
        if saved is not None:
            vec = plan.get("_jd_theme_vector") or {}
            merged = dict(saved)
            if "devtools" in vec:
                merged["devtools"] = max(merged.get("devtools", 0), vec["devtools"])
            plan["_jd_theme_vector"] = merged
    for pid in (plan.get("_v34_force") or {}):
        if pid not in scores:
            continue
        top3 = sorted(scores, key=lambda k: (-scores[k], k))[:3]
        if pid not in top3 and len(top3) == 3:
            scores[pid] = round(scores[top3[2]] + 0.01, 3)
            plan.setdefault("_v34_notes", []).append(f"{pid} forced onto the page: a required line asks for AI coding tools")
    return scores


_project_combos_v332 = _project_combos


def _project_combos(variants, k, need_headline, scores, keep=40, pairs=None):
    variants, need_headline = v349_llm_pool(variants, need_headline)   # v3.4.9a fix 4
    force = set(globals().get("_V34_FORCE_IDS") or [])
    ids = {v["id"] for v in variants}
    if force & ids:
        out = _project_combos_v332(variants, k, need_headline, scores, keep=max(keep, 2000), pairs=pairs)
        forced = [c for c in out if force & {v["id"] for v in c[2]}]
        if forced:
            return forced[:keep]
        return out[:keep]
    return _project_combos_v332(variants, k, need_headline, scores, keep, pairs)


_auto_bank_selection_v333 = auto_bank_selection


def auto_bank_selection(raw_plan, bank, pairs=None):
    force = [i for pid, ids in (raw_plan.get("_v34_force") or {}).items() if pid in (raw_plan.get("ranking") or []) for i in ids]
    globals()["_V34_FORCE_IDS"] = force
    try:
        sel, info = _auto_bank_selection_v333(raw_plan, bank, pairs)
        if sel is None and force:
            globals()["_V34_FORCE_IDS"] = []
            sel, info = _auto_bank_selection_v333(raw_plan, bank, pairs)
            if sel is not None:
                info = dict(info); info["v34_forced_variant_not_placed"] = force
    finally:
        globals()["_V34_FORCE_IDS"] = []
    return sel, info


_v33_experience_key_v332 = _v33_experience_key


def _v33_experience_key(plan, vec, ranking):
    cl = plan.get("cover_letter") or {}
    if isinstance(cl, dict) and cl.get("experience"):
        return _v33_experience_key_v332(plan, vec, ranking)
    if vec.get("healthcare", 0) >= 0.05:
        return "thesis_client"  # healthcare platform modules + client requirements
    return _v33_experience_key_v332(plan, vec, ranking)


_v33_project_sentences_v332 = _v33_project_sentences


def _v33_project_sentences(plan: dict[str, Any], master: dict[str, Any], pid: str, vec: dict[str, float]) -> str:
    s = _v33_project_sentences_v332(plan, master, pid, vec)
    if pid != "ripple" or not plan.get("_v34_force"):
        return s
    bank = master.get("cover_letter_bank", {}).get("letter_sentences", {}).get("ripple", {})
    cc = bank.get("ripple.claude_code_dev", "")
    sel = _v33_selected_evidence(plan, "ripple")
    if not cc or cc in s or not any(e == "ripple.claude_code_dev" for _v, e in sel):
        return s
    nums = []
    for v, e in sel:
        t = bank.get(v) or bank.get(e)
        if t and re.search(r"\d", t) and e != "ripple.claude_code_dev":
            nums.append(t)
    return " ".join(x for x in [bank.get("intro", ""), cc] + nums[:1] if x)


_compose_bank_cover_letter_v333 = compose_bank_cover_letter


def compose_bank_cover_letter(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[dict[str, Any]]:
    ranking = list(plan.get("ranking") or [])
    swapped = False
    # a required AI-coding-tools line must be answered in the letter too: when RIPPLE is the #3 project, the letter's
    # second project becomes RIPPLE (the letter still names exactly two projects)
    if plan.get("_v34_force") and "ripple" in ranking[2:] \
            and any(e == "ripple.claude_code_dev" for _v, e in _v33_selected_evidence(plan, "ripple")):
        plan["ranking"] = [ranking[0], "ripple"] + [p for p in ranking[1:] if p != "ripple"]
        swapped = True
    try:
        failures = _compose_bank_cover_letter_v333(plan, master, raw_jd)
    finally:
        if swapped:
            plan["ranking"] = ranking
    paras = plan.get("cover_letter_paragraphs") or []
    if paras:
        plan["cover_letter_paragraphs"] = [p.replace("I graduate in February 2027 and can start soon after.",
                                                     "I graduate in February 2027 and can start work that month.") for p in paras]
    return failures


_clean_jd_text_v333 = clean_jd_text


def clean_jd_text(text: str) -> str:
    """Bare URLs (\"abbvie.com/...equal-employment-opportunity-employer.html\") are not requirements: drop them before parsing."""
    s = _clean_jd_text_v333(text)
    s = re.sub(r"(?:https?://|www\.)\S+", " ", s)
    # a pasted resume (LaTeX) or cover letter after the posting is not part of the posting
    removed = []
    m = re.search(r"\\documentclass[\s\S]*?(?:\\end\{document\}|\Z)", s)
    if m:
        s = s[:m.start()] + "\n" + s[m.end():]; removed.append("resume LaTeX")
    m = re.search(r"^\s*Dear (?:Hiring|Recruiting)[^\n]*\n[\s\S]*?(?:^\s*(?:Sincerely|Best regards|Regards),?[^\n]*\n(?:[^\n]*\n)?|\Z)", s, re.M)
    if m and re.search(r"\bI (?:am applying|built|graduate)\b", m.group(0)):
        s = s[:m.start()] + "\n" + s[m.end():]; removed.append("cover letter")
    globals()["_V34_JD_REMOVED"] = removed
    return s


_V34_EXPERIENCE_VERBS = None


def _v34_experience_verbs(master: dict[str, Any]) -> set[str]:
    out = set()
    for e in master.get("experience", []):
        for b in e.get("bullets", []):
            w = str(b).strip().split(" ", 1)[0]
            if w:
                out.add(w.casefold())
    return out


_v33_quality_v332 = _v33_quality


def _v33_quality(out_dir: Path, names: dict[str, str]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    fails, info = _v33_quality_v332(out_dir, names)
    ctx = globals().get("_V33_CTX") or {}
    plan = ctx.get("plan") or {}
    master = globals().get("_V33_MASTER")
    if not plan or master is None:
        return fails, info
    info["pipeline_version"] = PIPELINE_VERSION
    if globals().get("_V34_JD_REMOVED"):
        info["jd_pasted_material_removed"] = list(globals()["_V34_JD_REMOVED"])
    exp_verbs = _v34_experience_verbs(master)
    proj_verbs = []
    for pid, bl in (plan.get("bullets") or {}).items():
        for b in bl:
            t = bullet_text(b) if not isinstance(b, str) else b
            w = str(t).strip().split(" ", 1)[0]
            if w:
                proj_verbs.append(w)
    reused = sorted({w for w in proj_verbs if w.casefold() in exp_verbs})
    info["project_verbs_reusing_experience"] = reused
    if reused:
        fails.append(fail("v34_project_verb_reuses_experience_verb", "PERSONAL PROJECTS", reused, "no project bullet starts with a verb the Experience section uses", "Pipeline defect: the bank should not offer these verbs."))
    force = plan.get("_v34_force") or {}
    sel = plan.get("bank_selection") or {}
    missing = [pid for pid, ids in force.items() if pid in (plan.get("ranking") or []) and not (set(ids) & set(sel.get(pid, [])))]
    not_ranked = [pid for pid in force if pid not in (plan.get("ranking") or [])]
    info["v34_forced"] = {"forced": force, "missing_bullet": missing, "project_not_selected": not_ranked}
    if missing or not_ranked:
        fails.append(fail("v34_required_evidence_missing", "PERSONAL PROJECTS", missing + not_ranked, "the bullet a required JD line asks for is on the page", "Pipeline defect: report it."))
    if plan.get("_v34_notes"):
        info["v34_notes"] = plan["_v34_notes"]
    return fails, info


_jd_omission_warnings_v333 = jd_omission_warnings


def jd_omission_warnings(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[dict[str, Any]]:
    """Drop false omissions: "GitHub" inside "GitHub Actions", "C" inside "C#"/"C++"/".NET / C#", when the longer term is the real ask."""
    out = []
    for w in _jd_omission_warnings_v333(plan, master, raw_jd):
        t = str(w.get("target", ""))
        hits = list(re.finditer(r"(?<![\w+#.])" + re.escape(t) + r"(?![\w])", raw_jd))
        real = [h for h in hits if not re.match(r"\s*(?:#|\+\+|actions\b|copilot\b|pages\b)", raw_jd[h.end():h.end() + 10], re.I)]
        if hits and not real:
            continue
        out.append(w)
    return out


# ===========================================================================
# v3.4.1 additions
#   - bullet slots: a slot is one 2-line bank variant or a pair of 1-line variants from the same project
#   - skip verdicts for blocked postings (citizenship, clearance, no sponsorship) and a clean stop for
#     postings with no requirements (recruiting ads)
#   - sanitized model-written fields, false "C" hits, "Intelligent Systems" titles, letter lead experience,
#     JD-named synonyms, AI coding tools, authentication / terminal / logs mappings, ML fillers
# ===========================================================================
PIPELINE_VERSION = "v3.4.1"

import unicodedata as _v341_ud

# --- model-written fields ------------------------------------------------------------

_V341_BULLET_CHARS = "•∙·▪▫◦‣⁃●○■□►▶➢➤✓✔❖♦◆‧⋅"
_V341_PLAN_FIELDS = [("application", "company"), ("application", "role"), ("application", "location"), ("application", "visa_sponsorship"),
                     ("cover_letter", "hook"), ("cover_letter", "closing"), ("cover_letter", "team_focus"), (None, "tagline_text")]


def sanitize_model_text(s: Any) -> Any:
    """Plain text a LaTeX letter or resume can always compile: no list bullets, smart quotes, zero-width or control
    characters, emoji or other symbols. Words, digits, ordinary punctuation and accented letters are kept."""
    if not isinstance(s, str):
        return s
    t = s.replace(" ", " ").replace(" ", " ")
    t = re.sub(r"[​-‏⁠﻿­]", "", t)
    t = (t.replace("‘", "'").replace("’", "'").replace("‚", "'").replace("‛", "'").replace("′", "'")
          .replace("“", '"').replace("”", '"').replace("„", '"').replace("″", '"')
          .replace("…", "...").replace("‐", "-").replace("‑", "-").replace("‒", "-").replace("–", "-").replace("−", "-"))
    t = re.sub(r"\s*—\s*", ", ", t)
    bullets = "[" + re.escape(_V341_BULLET_CHARS) + "]"
    lines = []
    for line in t.split("\n"):
        line = re.sub(r"^\s*(?:" + bullets + r"|[*\-]\s)\s*", "", line)          # leading list marker
        line = re.sub(r"\s+" + bullets + r"\s+", ", ", line)                       # "A ∙ B" -> "A, B"
        line = re.sub(bullets, " ", line)
        lines.append(line)
    t = "\n".join(lines)
    t = _v341_ud.normalize("NFKC", t)
    t = "".join(ch for ch in t if ch in "\n\t" or _v341_ud.category(ch)[0] in "LMNPZ" or _v341_ud.category(ch) in ("Sm", "Sc"))
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\s+([,.;:!?])", r"\1", t)
    t = re.sub(r",\s*,", ",", t)
    return t.strip(" ,")


def sanitize_plan_fields(raw_plan: dict[str, Any]) -> list[str]:
    changed = []
    for sec, key in _V341_PLAN_FIELDS:
        box = raw_plan.get(sec) if sec else raw_plan
        if not isinstance(box, dict) or not isinstance(box.get(key), str):
            continue
        new = sanitize_model_text(box[key])
        if new != box[key]:
            box[key] = new
            changed.append(f"{sec}.{key}" if sec else key)
    return changed


# --- JD text: false "C" hits ---------------------------------------------------------------

_clean_jd_text_v34 = clean_jd_text


def clean_jd_text(text: str) -> str:
    """"Washington, D.C." and "Objective-C" do not ask for the C language, and "C/C++" asks for C++ (Jay has C, not C++)."""
    s = _clean_jd_text_v34(text)
    s = re.sub(r"\bD\.\s?C\.?(?=[\s,;)\]]|$)", "DC", s)
    s = re.sub(r"\bObjective[- ]C\b", "ObjectiveC", s, flags=re.I)
    s = re.sub(r"(?<![\w+#/])C\s*/\s*C\+\+", "C++", s)
    s = re.sub(r"(?<![\w+#/])C\+\+\s*/\s*C(?![\w+#])", "C++", s)
    return s


# --- theme vector -----------------------------------------------------------------------------

# "distributed training" is ML infrastructure, not distributed backend systems
_V33_THEME_RX["distributed"] = _V33_THEME_RX["distributed"].replace(
    r"\bdistributed\b", r"\bdistributed\b(?!\s+(?:training|deep learning|machine learning|ml\b|model training|inference))", 1)

# internal business tools (HR / finance / Microsoft 365 workflows) are the corporate-systems theme LaunchOps proves
_V33_THEME_RX["it_ops"] += (r"|\binternal (?:tools?|systems|applications|apps|dashboards?|platforms?)\b|\bbusiness (?:users|workflows|systems|processes)\b|"
                           r"\bmicrosoft 365\b|\bsharepoint\b|\bentra id\b|\bmicrosoft graph\b")

_V341_NOT_OS_SYSTEMS = re.compile(r"\b(intelligen\w*|information|business|enterprise|management|integration|internal|corporate)\s+systems?\b", re.I)
_jd_theme_vector_v34 = jd_theme_vector


def jd_theme_vector(raw_jd: str, title: str = "", company: str = "") -> dict[str, float]:
    """A title such as "Intelligent Systems" or "Business Systems" is not operating-systems work. "Intelligent
    systems" reads as AI applications; the other business phrases lose the word "systems" for the title boost."""
    t = str(title or "")
    if _V341_NOT_OS_SYSTEMS.search(t):
        t = re.sub(r"\bintelligen\w*\s+systems?\b", "AI", t, flags=re.I)
        t = _V341_NOT_OS_SYSTEMS.sub(lambda m: m.group(1), t)
    return _jd_theme_vector_v34(raw_jd, t, company)


# --- JD term mappings: authentication / terminal / logs (existing evidence only) --------------

_V341_CONCEPTS = {
    "authentication": "JWT", "user authentication": "JWT", "token-based authentication": "JWT",
    "in a terminal": "Linux", "the terminal": "Linux", "a terminal": "Linux", "command line": "Linux", "command-line": "Linux",
    "reading logs": "Debugging", "logs/errors": "Debugging", "application logs": "Debugging", "logs": "Debugging",
    "logging": "Application Monitoring",
}
for _k, _v in _V341_CONCEPTS.items():
    if _k not in _CONCEPT_TERMS:
        _CONCEPT_TERMS.append(_k)
    _CANON.setdefault(_k, _v)


# --- plan fields: sanitize first, AI coding tools -----------------------------------------------

_V34_FORCE_RIPPLE = ["ripple.cc.c", "ripple.cc.a", "ripple.cc.b", "ripple.cc.s1"]
_V341_AI_TOOL_DISPLAYS = ["Claude Code", "Cursor", "GitHub Copilot"]
_apply_auto_plan_fields_v34 = apply_auto_plan_fields


def apply_auto_plan_fields(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    raw_plan["_v341_sanitized"] = sanitize_plan_fields(raw_plan)
    _apply_auto_plan_fields_v34(raw_plan, master, raw_jd)
    if raw_plan.get("_v34_force"):
        raw_plan["_v34_force"] = {"ripple": list(_V34_FORCE_RIPPLE)}
        prefer = [x for x in (raw_plan.get("prefer_variants") or []) if not str(x).startswith("ripple.cc.")]
        raw_plan["prefer_variants"] = list(dict.fromkeys(prefer + list(_V34_FORCE_RIPPLE)))
    if re.search(r"\bnot an? (?:research )?(?:ml|machine learning|ai research|research ml|data science) role\b", raw_jd, re.I):
        raw_plan["_v341_no_ml_fillers"] = True


_jd_named_pool_terms_v34 = jd_named_pool_terms


def jd_named_pool_terms(raw_jd: str, master: dict[str, Any]) -> list[str]:
    """A posting that names AI coding tools ("Codex, Claude Code, ChatGPT, or similar") names every one Jay uses."""
    found = _jd_named_pool_terms_v34(raw_jd, master)
    if any(_V332_AI_TOOLS.search(l) for l, _w, _h in _v33_role_lines(raw_jd)):
        pool = master["skills"]["supported_pool"].get("tools_platforms", [])
        found = found + [x for x in _V341_AI_TOOL_DISPLAYS if x in pool and x not in found]
    return found


_high_priority_skill_displays_v34 = _high_priority_skill_displays


def _high_priority_skill_displays(plan: dict[str, Any], master: dict[str, Any]) -> list[str]:
    out = _high_priority_skill_displays_v34(plan, master)
    if plan.get("_ai_coding_tools"):
        pool = master["skills"]["supported_pool"].get("tools_platforms", [])
        out = out + [x for x in _V341_AI_TOOL_DISPLAYS if x in pool and x not in out]
    return out


# --- project ranking: generic hosting tools never force a project ----------------------------------

_V341_GENERIC_TOOLS = {"github"}
_auto_project_scores_v34 = auto_project_scores


def auto_project_scores(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> dict[str, float]:
    """Every project is on GitHub, so "GitHub" never forces the one project whose heading says "GitHub Actions"
    onto the page (Monti lost LaunchOps this way)."""
    tmp = []
    for r in plan.get("jd_requirements", []) or []:
        if isinstance(r, dict) and str(r.get("term", "")).casefold() in _V341_GENERIC_TOOLS and not r.get("hedged"):
            r["hedged"] = True; tmp.append(r)
    try:
        if _v347_on("ranker_v349"):   # v3.4.9a fix 5: greedy ties go to the legacy score, never to list order
            return v349_scores_by_score_ties(plan, master, raw_jd, _auto_project_scores_v34)
        return _auto_project_scores_v34(plan, master, raw_jd)
    finally:
        for r in tmp:
            r.pop("hedged", None)


# --- skills: JD-named synonyms, ML fillers ------------------------------------------------------

_build_skill_states_v34 = build_skill_states
_V341_ML_FILLERS = ["Machine Learning", "Deep Learning", "Model Evaluation", "CNNs", "RNNs", "GNNs", "GraphSAGE", "GAT", "Focal Loss", "Threshold Optimization"]


def build_skill_states(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    """A synonym group keeps every member the JD names literally ("SQL and relational databases" shows both).
    A posting that says it is not an ML role gets no ML filler skills."""
    raw = str(plan.get("_raw_jd_text", ""))
    groups = master["skills"].get("synonym_groups", [])
    keep = [g for g in groups if sum(1 for x in g if boundary_contains_plural(raw, x)) < 2]
    # a group with exactly one member the JD names shows that member, never a synonym in its place
    shadow = [y for g in keep if sum(1 for x in g if boundary_contains_plural(raw, x)) == 1 for y in g if not boundary_contains_plural(raw, y)]
    no_ml = bool(plan.get("_v341_no_ml_fillers"))
    if len(keep) == len(groups) and not no_ml and not shadow:
        return _build_skill_states_v34(plan, master)
    m2 = dict(master)
    m2["skills"] = dict(master["skills"])
    m2["skills"]["synonym_groups"] = keep
    never = list(master["skills"].get("never_filler", [])) + shadow
    if no_ml:
        never += _V341_ML_FILLERS
    m2["skills"]["never_filler"] = list(dict.fromkeys(never))
    plan["_v341_split_synonyms"] = [g for g in groups if g not in keep]
    states = _build_skill_states_v34(plan, m2)
    # a JD-derived synonym ("workflow automation" -> Agentic Workflows) yields to the member the JD names literally
    literal = {y: x for g in keep for x in g if boundary_contains_plural(raw, x) for y in g if y != x and not boundary_contains_plural(raw, y)}
    if literal:
        swapped = set()
        his = {str(x).casefold() for x in _high_priority_skill_displays(plan, master)}
        for st in states:
            req = {str(r).casefold() for r in st.get("required_ats_terms", [])} | his
            allv = {x for vals in st.get("skills", {}).values() for x in vals}
            for cat, vals in st.get("skills", {}).items():
                for i, x in enumerate(list(vals)):
                    lit = literal.get(x)
                    if not lit or lit in allv or supported_skill_category(lit, master) != cat:
                        continue
                    if x.casefold() in req:      # a required or high-priority term stays; the literal JD word joins it
                        vals.insert(vals.index(x) + 1, lit); swapped.add(f"{x} + {lit}")
                    else:
                        vals[vals.index(x)] = lit; swapped.add(f"{x} -> {lit}")
                    allv.add(lit)
            st["matched_tools"] = [literal.get(x, x) if literal.get(x) in allv else x for x in st.get("matched_tools", [])]
        if swapped:
            plan["_v341_literal_synonyms"] = sorted(swapped)
    return states


_V341_LABEL_CHARS = {"languages_databases": 24, "frameworks_libraries": 25, "ai_ml": 8, "software_engineering": 23, "tools": 8}


def _v341_est_lines(cat: str, vals: list[str]) -> int:
    if not vals:
        return 0
    return max(1, -(-(_V341_LABEL_CHARS.get(cat, 20) + sum(len(x) + 2 for x in vals)) // V349B_CTX.get("skill_chars", 104)))   # v3.4.9b: Letter / Times line


_build_skill_states_v341a = build_skill_states


def build_skill_states(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    """The smallest skills state must leave room for the 10pt page buffer: when its estimated lines reach the
    7-line maximum, heading technologies and fillers the posting does not ask for leave the 2-line categories of
    that state (larger states keep them, so the fitter still adds them back when the page has room)."""
    states = _build_skill_states_v341a(plan, master)
    if not states:
        return states
    cap = int(master["layout_rules"].get("skills_rendered_lines_max", 7))
    base = states[0].get("skills", {})
    total = sum(_v341_est_lines(c, v) for c, v in base.items())
    # the Tools fitter prunes unmatched tools itself; the tools that must survive (matched) must fit one line
    matched = {str(x) for x in states[0].get("matched_tools", [])}
    tools_must = lambda: [x for x in base.get("tools", []) if x in matched]
    over = lambda c: (_v341_est_lines(c, tools_must()) >= 2) if c == "tools" else (_v341_est_lines(c, base[c]) >= 2 and total >= cap)
    if not any(over(c) for c in base):
        plan["_v341_tight_unresolved"] = False
        return states
    header = resolved_project_header_tech(master, plan["ranking"], plan)
    protected = {str(x).casefold() for x in states[0].get("required_ats_terms", [])}
    protected |= {str(x).casefold() for x in selected_technology_skills(plan, master, header)}
    highs = {str(x).casefold() for x in _high_priority_skill_displays(plan, master)}
    raw = str(plan.get("_raw_jd_text", ""))
    added = {x.casefold() for x in _V341_AI_TOOL_DISPLAYS if not boundary_contains_plural(raw, x)}
    page = _v33_page_text(plan, master, header)
    # first skills the posting does not name, then AI tools added for an "or similar" list, then JD-named skills
    # the page already shows in a bullet or heading
    tiers = [lambda x: x.casefold() not in highs and x.casefold() not in added, lambda x: x.casefold() in added,
             lambda x: x.casefold() in highs and boundary_contains_plural(page, x)]
    dropped = []
    # an AI/ML line made only of fillers goes first: it costs a whole line and proves nothing the posting asked for
    jd_named = {str(x).casefold() for x in (globals().get("_V33_SKILLS") or {}).get("jd_named", [])}
    if total >= cap and base.get("ai_ml") and not any(str(x).casefold() in jd_named | protected | highs for x in base["ai_ml"]):
        dropped += list(base["ai_ml"]); total -= _v341_est_lines("ai_ml", base["ai_ml"])
        for st in states:
            if "ai_ml" in st.get("skills", {}):
                st["skills"]["ai_ml"] = []
    for tier in tiers:
        for cat in sorted(base, key=lambda c: -_v341_est_lines(c, base[c])):
            while over(cat):
                pool = tools_must() if cat == "tools" else base[cat]
                cand = [x for x in reversed(pool) if str(x).casefold() not in protected and tier(str(x))]
                if not cand:
                    break
                before = _v341_est_lines(cat, base[cat])
                base[cat] = [x for x in base[cat] if x != cand[0]]
                matched.discard(cand[0])
                dropped.append(cand[0])
                total -= before - _v341_est_lines(cat, base[cat])
    for st in states:
        st["matched_tools"] = [x for x in st.get("matched_tools", []) if x not in dropped]
    if dropped:
        plan["_v341_tight_skills"] = dropped
    plan["_v341_tight_unresolved"] = any(over(c) for c in base)
    return states


# --- skip verdicts ----------------------------------------------------------------------------------

_V341_SKIP_TYPES = {
    "citizenship": "the posting requires U.S. citizenship",
    "clearance": "the posting requires a U.S. security clearance, which needs U.S. citizenship",
    "work_authorization_or_sponsorship": "the posting will not sponsor a work visa, and Jay will need sponsorship after OPT",
}
_V341_SOFT_LINE = re.compile(r"\b(preferred|a plus|is a plus|nice to have|bonus|desired|desirable|not required|ideally|helpful|advantage)\b", re.I)


def _v341_norm(s: str) -> str:
    s = re.sub(r"\bU\.S\.", "US", str(s))
    return re.sub(r"\s+", " ", s).strip().casefold()


_V341_FIRM = re.compile(r"\b(must|required|requires|requirement|will not|won't|cannot|can't|unable|not eligible|not able|only|no (?:visa |immigration )?sponsorship|without (?:visa |immigration |employer )?sponsorship|unrestricted|mandatory)\b", re.I)
_V341_BONUS_HEAD = re.compile(r"\b(bonus|pluses|nice[- ]to[- ]have|stand out|extra credit|a plus|could include|may include|might include|optional)\b", re.I)


def _v341_blocker_is_firm(req: str, raw: str) -> bool:
    """A citizenship / clearance / sponsorship statement skips the posting unless it is worded as a preference
    ("clearance preferred", "a plus") or it sits in a bonus / stand-out section without firm wording ("must",
    "required", "will not", ...)."""
    r = _v341_norm(req)[:70]
    if not r:
        return False
    if _V341_SOFT_LINE.search(req) and not re.search(r"\b(must|required|will not|cannot|unable)\b", req, re.I):
        return False
    bonus = False
    for raw_line in re.sub(r"\bU\.S\.", "US", raw).splitlines():
        line = raw_line.strip()
        if not line:
            continue
        head = re.sub(r"[#*_]+", "", line).strip()
        if len(head.split()) <= 8 and not head.endswith(".") and (head.endswith(":") or head.istitle() or head.isupper() or line.startswith("#") or line.startswith("**")):
            bonus = bool(_V341_BONUS_HEAD.search(head))
        if r in _v341_norm(line):
            return bool(_V341_FIRM.search(line)) or not bonus
    return True


_gating_assessment_v34 = gating_assessment


def gating_assessment(plan: dict[str, Any], master: dict[str, Any], blockers: list[dict[str, str]]) -> dict[str, Any]:
    g = _gating_assessment_v34(plan, master, blockers)
    raw = str(plan.get("_raw_jd_text", ""))
    skips = []
    for b in blockers:
        t = b.get("type")
        if t in _V341_SKIP_TYPES and _v341_blocker_is_firm(b.get("requirement", ""), raw) and not any(x["type"] == t for x in skips):
            quote = re.sub(r"\s+", " ", str(b.get("requirement", ""))).strip()[:160]
            skips.append({"type": t, "reason": f"{_V341_SKIP_TYPES[t]} (\"{quote}\")"})
    reqs = [r for r in plan.get("jd_requirements", []) if isinstance(r, dict)]
    if not reqs:
        skips.append({"type": "no_requirements", "reason": "no job requirements were found; this reads as a recruiting ad, not a job posting"})
        g.setdefault("warnings", []).append({"type": "jd_no_requirements", "reason": "No requirements could be read from this text, so no package was built."})
    g["skip_reasons"] = skips + [x for x in g.get("skip_reasons", []) if x.get("type") not in {s["type"] for s in skips}]
    return g


def skip_verdict(report: dict[str, Any]) -> str:
    rs = report.get("skip_reasons", []) or []
    word = "stop" if rs and all(x.get("type") == "no_requirements" for x in rs) else "skip"
    return f"{word}: " + "; ".join(str(x.get("reason", x.get("type", ""))) for x in rs)


def write_skip_file(out_dir, report: dict[str, Any]) -> None:
    report["verdict"] = skip_verdict(report)
    (Path(out_dir) / "SKIP.txt").write_text(report["verdict"] + "\n", encoding="utf-8")


_fill_skip_report_v34 = fill_skip_report


def fill_skip_report(report: dict[str, Any], raw_plan: dict[str, Any], master: dict[str, Any], blockers, gate) -> None:
    _fill_skip_report_v34(report, raw_plan, master, blockers, gate)
    report["verdict"] = skip_verdict(report)
    report["pipeline_version"] = PIPELINE_VERSION


_apply_skip_v34 = apply_skip


def apply_skip(out_dir, report: dict[str, Any]) -> None:
    _apply_skip_v34(out_dir, report)
    write_skip_file(out_dir, report)


# --- cover letter: lead experience ------------------------------------------------------------------

_V341_DOC_RX = re.compile(r"\bdocument (?:processing|extraction|classification|understanding|intelligence|ai|parsing)\b|\b(?:data|information|metadata|entity) extraction\b|"
                          r"\bextract(?:ion|ing)?\b[^.]{0,40}\b(?:documents?|pdfs?|text|data|metadata|fields)\b|\bocr\b|\bsummariz\w+|\bllm[- ]powered\b|\bunstructured (?:data|documents|text)\b|"
                          r"\bparsing (?:documents|pdfs)\b|\bmetadata\b", re.I)
_v33_experience_key_v34 = _v33_experience_key


def _v33_experience_key(plan, vec, ranking):
    """The letter leads with the experience a reader in this role cares about most:
    LLM / document-extraction work -> HeinOnline (with the Thesis healthcare modules for healthcare postings);
    data and ML roles -> Go Digital ETL for data engineering, HeinOnline extraction otherwise."""
    cl = plan.get("cover_letter") or {}
    if isinstance(cl, dict) and cl.get("experience"):
        return _v33_experience_key_v34(plan, vec, ranking)
    raw = str(plan.get("_raw_jd_text", ""))
    role = str(plan.get("application", {}).get("role", ""))
    lines = [l for l, w, h in _v33_role_lines(raw) if w >= 0.95 and not h] + [role]
    doc_hits = sum(1 for l in lines if _V341_DOC_RX.search(l))
    ai = vec.get("llm_agents", 0) + vec.get("model_api", 0) + vec.get("ai_apps", 0)
    health = vec.get("healthcare", 0) >= 0.05
    if doc_hits >= 2 or (doc_hits and ai >= 0.05):
        return "hein_health" if health else "hein"
    if _is_data_ml_role(plan):
        if vec.get("data_eng", 0) >= max(vec.get("ml_dl", 0) + vec.get("data_science", 0), ai):
            return "godigital"
        return "hein_health" if health else "hein"
    return _v33_experience_key_v34(plan, vec, ranking)


# --- bullet slots -------------------------------------------------------------------------------------

def _v341_lines(v: dict[str, Any]) -> int:
    return int(v.get("lines", 2) or 2)


def _v341_units(pool, scores, pairs):
    """Slot units: each 2-line variant alone, or two 1-line variants with different evidence and verbs that do not conflict."""
    from itertools import combinations
    units = [((v,), scores[v["id"]]) for v in pool if _v341_lines(v) == 2]
    ones = [v for v in pool if _v341_lines(v) == 1]
    for a, b in combinations(ones, 2):
        if a["main_evidence_id"] == b["main_evidence_id"] or a["verb"].lower() == b["verb"].lower():
            continue
        if b["id"] in a.get("conflicts_with", []) or a["id"] in b.get("conflicts_with", []):
            continue
        if pairs and _redundant(a["id"], b["id"], pairs):
            continue
        hi, lo = sorted((scores[a["id"]], scores[b["id"]]), reverse=True)
        units.append(((a, b), hi + _V341_PAIR_WEIGHT * lo))
    return units


_V341_PAIR_WEIGHT = 0.4


def _v341_project_combos(pool, k, need_headline, scores, keep, pairs, force):
    from itertools import combinations
    units = _v341_units(pool, scores, pairs)
    out = []
    for combo in combinations(units, k):
        vs = [v for u, _s in combo for v in u]
        if len({v["main_evidence_id"] for v in vs}) != len(vs):
            continue
        if len({v["verb"].lower() for v in vs}) != len(vs):
            continue
        ids = {v["id"] for v in vs}
        if any(o in ids for v in vs for o in v.get("conflicts_with", [])):
            continue
        if pairs and any(_redundant(x["id"], y["id"], pairs) for x, y in combinations(vs, 2)):
            continue
        if need_headline and not any(v.get("headline") is True for v in vs):
            continue
        repeats = sum(len(salient_bigrams(str(x.get("text", ""))) & salient_bigrams(str(y.get("text", "")))) for x, y in combinations(vs, 2))
        out.append((sum(s for _u, s in combo) - 1.5 * repeats, sorted(ids), combo, vs))
    out.sort(key=lambda x: (-x[0], -sum(1 for v in x[3] if v.get("headline") is True), x[1]))
    if force:
        forced = [c for c in out if force & {v["id"] for v in c[3]}]
        if forced:
            out = forced
    return out[:keep]


def _v341_tight_penalty(raw_plan: dict[str, Any], pid: str, v: dict[str, Any]) -> float:
    """On a page whose skills cannot fit, a bullet that names a technology the posting does not ask for costs 3
    per technology: every technology on the page must also be listed in Skills."""
    if not raw_plan.get("_v341_tight"):
        return 0.0
    master = globals().get("_V33_MASTER") or {}
    techs = (master.get("projects", {}).get(pid, {}) or {}).get("tech", [])
    raw = str(raw_plan.get("_raw_jd_text", ""))
    extra = [t for t in technology_hits(str(v.get("text", "")), techs) if not boundary_contains_plural(raw, re.sub(r"\s*\(.*\)", "", t).split()[0])]
    return 3.0 * len(extra)


def auto_bank_selection(raw_plan, bank, pairs=None):
    """v3.4.1 slot selector: rank #1 gets 3 slots, #2 and #3 get 2. Every verb on the page differs. Identity first."""
    ranking = raw_plan.get("ranking", [])
    themes = {str(x).strip().lower() for x in raw_plan.get("jd_themes", [])}
    prefer = {str(x) for x in raw_plan.get("prefer_variants", [])}
    weights = _jd_keyword_weights(raw_plan)
    force_all = {i for pid, ids in (raw_plan.get("_v34_force") or {}).items() if pid in ranking for i in ids}

    def per_project(keep, use_force):
        res = []
        for rank, pid in enumerate(ranking):
            pool = []
            for v in bank.get("projects", {}).get(pid, []):
                if v.get("status") != "ok":
                    continue
                if v.get("optional") and not ({str(x).lower() for x in v.get("optional_themes", [])} & themes):
                    continue
                pool.append(v)
            scores = {v["id"]: _variant_score(v, weights, themes, prefer) - _v341_tight_penalty(raw_plan, pid, v) for v in pool}
            force = (force_all & {v["id"] for v in pool}) if use_force else set()
            allc = _v341_project_combos(pool, 3 if rank == 0 else 2, rank == 0, scores, keep * 10, pairs, force)
            ident = _IDENTITY_EVIDENCE.get(pid, set())
            combos = [c for c in allc if any(v.get("main_evidence_id") in ident for v in c[3])][:keep] or allc[:keep]
            if not combos:
                return None, {"project": pid, "reason": "no valid slot combination"}
            res.append(combos)
        return res, None

    def best_of(per):
        best = None
        for a in per[0]:
            va = {v["verb"].lower() for v in a[3]}
            for b in per[1]:
                vb = {v["verb"].lower() for v in b[3]}
                if va & vb:
                    continue
                for c in per[2]:
                    vc = {v["verb"].lower() for v in c[3]}
                    if (va | vb) & vc:
                        continue
                    total = a[0] + b[0] + c[0]
                    hl = sum(1 for combo in (a, b, c) for v in combo[3] if v.get("headline") is True)
                    key = (-total, -hl, a[1] + b[1] + c[1])
                    if best is None or key < best[0]:
                        best = (key, (a, b, c))
                    break
        return best

    best, info = None, {}
    for keep, use_force in ((40, True), (400, True), (400, False)):
        per, err = per_project(keep, use_force)
        if per is None:
            info = err
            continue
        best = best_of(per)
        if best is not None:
            if keep > 40:
                info["widened"] = True
            if force_all and not use_force:
                info["v34_forced_variant_not_placed"] = sorted(force_all)
            break
    if best is None:
        return None, info or {"reason": "no verb-distinct combination across projects"}

    sel, slots = {}, {}
    for pid, combo in zip(ranking, best[1]):
        ident = _IDENTITY_EVIDENCE.get(pid, set())
        def vkey(v):
            return (v.get("main_evidence_id") not in ident, not v.get("headline"), -_variant_score(v, weights, themes, prefer), v["id"])
        units = [sorted(u, key=vkey) for u, _s in combo[2]]
        units.sort(key=lambda u: min(vkey(v) for v in u))
        # one identity unit leads; a second identity unit moves to the end
        idn = [u for u in units if any(v.get("main_evidence_id") in ident for v in u)]
        for extra in idn[1:]:
            units.remove(extra); units.append(extra)
        slots[pid] = [[v["id"] for v in u] for u in units]
        sel[pid] = [i for u in slots[pid] for i in u]
    raw_plan["_v341_slots"] = slots
    allv = {v["id"]: v for pid in ranking for v in bank.get("projects", {}).get(pid, [])}
    why = {vid: [f"{t} +{w:g}" + (f" ({h})" if h else "") for t, w, h in _variant_score(allv[vid], weights, themes, prefer, breakdown=True)[1]]
           for ids in sel.values() for vid in ids}
    info.update({"score": -best[0][0], "breakdown": why, "slots": slots})
    return sel, info


def _v341_slots_from_ids(ids: list[str], index: dict[str, dict[str, Any]]):
    """Group a project's ids into slots: a 2-line variant alone, two consecutive 1-line variants together."""
    slots, pending, bad = [], [], []
    for i in ids:
        v = index.get(str(i))
        if v is None:
            continue
        if _v341_lines(v) == 2:
            if pending:
                bad.append(list(pending)); pending = []
            slots.append([str(i)])
        else:
            pending.append(str(i))
            if len(pending) == 2:
                slots.append(pending); pending = []
    if pending:
        bad.append(pending)
    return slots, bad


_expand_bank_plan_v34 = expand_bank_plan


def expand_bank_plan(raw_plan: dict[str, Any], bank: dict[str, Any], master: dict[str, Any]):
    """Slot counts replace bullet counts: rank #1 fills 3 slots and ranks #2/#3 fill 2 (each slot renders 2 lines)."""
    expanded, failures = _expand_bank_plan_v34(raw_plan, bank, master)
    if "_v341_slots" in raw_plan:
        expanded["_v341_slots"] = raw_plan["_v341_slots"]
    ranking = expanded.get("ranking") or raw_plan.get("ranking") or []
    sel = expanded.get("bank_selection") or raw_plan.get("bank_selection")
    if not isinstance(sel, dict) or len(ranking) != 3:
        return expanded, failures
    index = {str(v.get("id")): v for vs in bank.get("projects", {}).values() for v in vs}
    failures = [f for f in failures if f.get("type") != "bullet_allocation"]
    expected = {ranking[0]: 3, ranking[1]: 2, ranking[2]: 2}
    lines_map, slot_map = {}, {}
    for pid, want in expected.items():
        ids = sel.get(pid)
        if not isinstance(ids, list):
            continue
        slots, bad = _v341_slots_from_ids(ids, index)
        slot_map[pid] = slots
        lines_map[pid] = [_v341_lines(index[str(i)]) for i in ids if str(i) in index]
        if bad:
            failures.append(fail("bullet_slot_unpaired", pid, bad, "1-line variants come in adjacent pairs", "Pair each 1-line variant with a second 1-line variant from the same project."))
        if len(slots) != want:
            failures.append(fail("bullet_allocation", pid, len(slots), want, f"Fill exactly {want} bullet slots for {pid} (a slot is one 2-line variant or two 1-line variants)."))
    expanded["_v341_slots"] = slot_map
    expanded["_v341_lines"] = lines_map
    auto = raw_plan.get("bank_selection") in (None, "auto")
    if auto and not failures and not raw_plan.get("_v341_tight"):
        try:
            probe = deepcopy(expanded)
            build_skill_states(probe, master)
            tight = bool(probe.get("_v341_tight_unresolved"))
        except Exception:
            tight = False
        if tight:
            retry = deepcopy(raw_plan); retry["_v341_tight"] = True
            e2, f2 = expand_bank_plan(retry, bank, master)
            if not f2:
                e2["_v341_tight_reselected"] = True
                return e2, f2
    return expanded, failures


_validate_plan_v3_1_v34 = validate_plan_v3_1


def validate_plan_v3_1(plan: dict[str, Any], master: dict[str, Any], raw_jd: str, warnings: list[dict[str, Any]] | None = None, free_text_mode: bool = False) -> list[dict[str, Any]]:
    out = _validate_plan_v3_1_v34(plan, master, raw_jd, warnings=warnings, free_text_mode=free_text_mode)
    lines = plan.get("_v341_lines")
    if not isinstance(lines, dict):
        return out
    ranking = plan.get("ranking") or []
    expected = {ranking[0]: 3, ranking[1]: 2, ranking[2]: 2} if len(ranking) == 3 else {}
    kept = []
    for f in out:
        if f.get("type") == "bullet_allocation" and f.get("target") in expected:
            pid = f["target"]
            if sum(lines.get(pid, [])) == 2 * expected[pid] and len(lines.get(pid, [])) == len((plan.get("bullets") or {}).get(pid, [])):
                continue
        kept.append(f)
    return kept


def collect_project_bullets(pdf, lines, display_order, master):
    """v3.4.1: bullet starts are the leftmost indented x position (the bullet glyph); a project may now hold 1-line
    bullets only, so the most frequent x position is no longer always the continuation indent."""
    failures = []
    result: dict[str, list[list[dict[str, Any]]]] = {}
    heading_indices = []
    for pid in display_order:
        title_meta = master["projects"][pid].get("resume_title", {})
        name = title_meta.get("name") or project_title_text(master, pid)
        idx = find_line_index(lines, name)
        if idx is None:
            failures.append(fail("project_heading_missing", pid, "not found in PDF", name, "Check LaTeX assembly/project heading text."))
        else:
            heading_indices.append((pid, idx))
    education_idx = find_line_index(lines, "EDUCATION")
    if len(heading_indices) != len(display_order) or education_idx is None:
        return result, failures
    for k, (pid, idx) in enumerate(heading_indices):
        end = heading_indices[k + 1][1] if k + 1 < len(heading_indices) else education_idx
        segment = [x for x in lines[idx + 1:end] if x["text"].strip()]
        heading_x0 = lines[idx]["bbox"][0]
        indented = [x for x in segment if heading_x0 + 5.0 <= x["bbox"][0] <= heading_x0 + 100.0]
        if not indented:
            result[pid] = []
            continue
        start_x0 = min(x["bbox"][0] for x in indented)
        bullets: list[list[dict[str, Any]]] = []
        current = None
        for line in indented:
            x0 = line["bbox"][0]
            if x0 <= start_x0 + 2.0:
                if current:
                    bullets.append(current)
                current = [line]
            elif current is not None and x0 <= start_x0 + 40.0:
                current.append(line)
        if current:
            bullets.append(current)
        result[pid] = bullets
    return result, failures


_validate_pdf_v34 = validate_pdf
_V341_SLOT_GEOMETRY = {"rendered_bullet_count", "project_bullet_line_count", "project_bullet_second_line_fill"}


def validate_pdf(pdf_path, generated_tex, plan, master, display_order, ordered_bullets, warnings=None, bank_mode=True, pdf=None, lines=None):
    """Geometry by slot: each project renders its bank variants with the line count each variant was measured at
    (2, or 1 for a paired 1-line variant), and every project fills 2 lines per slot."""
    out = _validate_pdf_v34(pdf_path, generated_tex, plan, master, display_order, ordered_bullets, warnings=warnings, bank_mode=bank_mode, pdf=pdf, lines=lines)
    want = plan.get("_v341_lines")
    if not isinstance(want, dict):
        return out
    out = [f for f in out if f.get("type") not in _V341_SLOT_GEOMETRY]
    if pdf is None:
        pdf = fitz.open(pdf_path)
    if lines is None:
        lines = extract_pdf_lines(pdf)
    grouped, _gf = collect_project_bullets(pdf, lines, display_order, master)
    ranking = plan["ranking"]
    slots = {ranking[0]: 3, ranking[1]: 2, ranking[2]: 2}
    right_margin_pt = master["layout_rules"]["margins_in"]["right"] * 72.0
    min_fill = master["layout_rules"]["project_second_line_min_fill"]
    for pid in display_order:
        groups = grouped.get(pid, [])
        exp = want.get(pid, [])
        if len(groups) != len(exp):
            out.append(fail("rendered_bullet_count", pid, len(groups), len(exp), "Check project assembly and bullet parsing; preserve the 3/2/2 slot allocation."))
            continue
        if sum(len(g) for g in groups) != 2 * slots[pid]:
            out.append(fail("project_slot_line_total", pid, sum(len(g) for g in groups), 2 * slots[pid], "template/bank drift: rerun bank_check.py"))
        for j, (g, n) in enumerate(zip(groups, exp), 1):
            target = f"{pid}.bullet_{j}"
            if len(g) != n:
                out.append(fail("project_bullet_line_count", target, len(g), n, "template/bank drift: rerun bank_check.py"))
                continue
            if n == 2:
                second = g[1]
                page = pdf[second["page"]]
                x0, _, x1, _ = second["bbox"]
                avail = page.rect.width - right_margin_pt - x0
                ratio = (x1 - x0) / avail if avail > 0 else 0.0
                if ratio < min_fill:
                    out.append(fail("project_bullet_second_line_fill", target, {"fill_ratio": round(ratio, 4)}, {"min_fill_ratio": min_fill}, "template/bank drift: rerun bank_check.py"))
    return out


# --- quality report additions ------------------------------------------------------------------------

_v33_quality_v34 = _v33_quality


def _v33_quality(out_dir: Path, names: dict[str, str]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    _pp = (globals().get("_V33_CTX") or {}).get("plan") or {}
    _pl = _pp.get("_v349c_plain") if v349c_plain_on() else _pp.get("_v349c_out")   # fix1: also the run 7 written letter
    if isinstance(_pl, dict) and _pl.get("before"):   # v3.4.9c run 8: the run 7 letter's numbers stay checked
        _plan = (globals().get("_V33_CTX") or {}).get("plan")
        _now = _plan.get("cover_letter_paragraphs")
        _plan["cover_letter_paragraphs"] = list(_pl["before"])
        try:
            fails, info = _v33_quality_v34(out_dir, names)
        finally:
            _plan["cover_letter_paragraphs"] = _now
        info["letter_words"] = sum(_letter_words(p) for p in _now or [])
    else:
        fails, info = _v33_quality_v34(out_dir, names)
    if v349c_page_on() and isinstance(info.get("free_space_pt"), (int, float)):   # v3.4.9c run 2 P5: 10.5pt spare
        fails = [f for f in fails if f.get("type") != "v33_page_buffer"]
        if info["free_space_pt"] < V33_MIN_BUFFER_PT:
            fails.append(fail("v33_page_buffer", "layout", info["free_space_pt"], ">= %gpt free above the bottom margin" % V33_MIN_BUFFER_PT, "Pipeline defect: the skills fitter should leave the page buffer."))
        page = ""
        try:
            with fitz.open(out_dir / names["resume_pdf"]) as doc:
                page = "".join(p.get_text() for p in doc)
        except Exception:
            pass
        hit = [x for x in V349C_NEVER_RENDER if x in page]
        if hit:
            fails.append(fail("v349c_never_rendered", "resume", hit, "no hackathon award or AWS certification on the page", "Pipeline defect: report it."))
    plan = (globals().get("_V33_CTX") or {}).get("plan") or {}
    if plan:
        info["pipeline_version"] = PIPELINE_VERSION
        if plan.get("_v341_slots"):
            info["bullet_slots"] = plan["_v341_slots"]
        if plan.get("_v341_sanitized"):
            info["sanitized_fields"] = plan["_v341_sanitized"]
        if plan.get("_v341_tight_reselected"):
            info["bullets_reselected_for_page_buffer"] = True
        if plan.get("_v341_tight_skills"):
            info["skills_left_out_for_page_buffer"] = plan["_v341_tight_skills"]
        if plan.get("_v341_literal_synonyms"):
            info["synonyms_swapped_to_jd_wording"] = plan["_v341_literal_synonyms"]
        if plan.get("_v341_split_synonyms"):
            info["jd_named_synonyms_kept"] = plan["_v341_split_synonyms"]
        if plan.get("_v33_letter"):
            info["letter_experience"] = plan["_v33_letter"].get("experience")
    return fails, info


# ===========================================================================
# v3.4.2 layer (2026-10-15)
#   1. No eligibility skips: sponsorship, citizenship, clearance, graduation window and rising-senior programs
#      become blockers shown in Notes and in the tracker's Blockers column. Only a paste with zero parsed
#      requirements stops.
#   2. The AI/ML skills line appears only when the JD has an AI/ML theme or names AI/ML terms.
#   3. Language-led roles: a title or required/preferred line that singles out one language puts Jay's strongest
#      project in that language at #1 (Java -> LedgerFlow, C -> Pintos).
#   4. Testing evidence: LedgerFlow GitHub Actions CI bullets, RIPPLE's Claude Code output checked with its
#      241-test suite; preferred on testing / CI postings; GitHub Actions shows in the LedgerFlow heading.
#   5. Letter evidence chosen by the JD's top requirements; access-control, systems and testing sentences.
#   6. Closings name the posting's top responsibility in its own words plus Jay's matching proof.
#   7. "Kubernetes (local k3d)", OAuth/Auth0 for OAuth / SSO / authentication postings.
#   8. Claude API only with GoingOnce or LLM APIs; 1-line pair partners never re-describe the project;
#      at most 2 terms from one synonym group.
#   9. Internship letters for onsite roles say "I am open to relocating."
#  10. judge_packet.md per run (evidence inventory from master.json + JD + resume + letter).
#  11. Experience variant bank (off by default; test mode only).
# ===========================================================================
PIPELINE_VERSION = "v3.4.2"

_V342_AI_RX = re.compile(r"\bai\b|\bartificial intelligence\b|\bmachine learning\b|\bml\b|\bllms?\b|\blarge language models?\b|\bdeep learning\b|"
                         r"\bneural networks?\b|\bgenerative\b|\bgen ?ai\b|\bagentic\b|\bai agents?\b|\bnlp\b|\bnatural language processing\b|"
                         r"\bcomputer vision\b|\bpytorch\b|\btensorflow\b|\bprompt engineering\b|\bmodel (?:training|evaluation|serving|inference)\b|"
                         r"\bdata scien\w+|\bclaude code\b|\bcopilot\b|\bcoding agents?\b", re.I)
_V342_LLM_API_RX = re.compile(r"\bllm apis?\b|\bmodel apis?\b|\b(?:claude|anthropic|openai|gemini) apis?\b|\bai apis?\b|\bfoundation model apis?\b|"
                              r"\bllm providers?\b|\bmodel providers?\b|\bapis? (?:of|from|for) (?:llms?|large language models)\b", re.I)
_V342_AUTH_RX = re.compile(r"\boauth\w*\b|\bsso\b|\bsingle sign[- ]on\b|\bauthentication\b|\bauthn\b|\bauth0\b", re.I)
_V342_PERM_RX = re.compile(r"\bpermissions?\b|\baccess control\b|\bauthori[sz]ation\b|\bauthentication\b|\brbac\b|\broles? and permissions\b|"
                           r"\bsso\b|\boauth\w*\b|\baccess management\b|\bidentity\b|\bworkspaces?\b", re.I)
_V342_TEST_RX = re.compile(r"\btest(?:s|ing|able)?\b|\btdd\b|\btest[- ]driven\b|\btest design\b|\bci\s*/\s*cd\b|\bci\b|\bcontinuous (?:integration|delivery)\b|"
                           r"\bgithub actions\b|\bunit tests?\b|\bautomated tests?\b|\bqa\b", re.I)
_V342_CI_RX = re.compile(r"\bci\s*/\s*cd\b|\bci\b|\bcontinuous (?:integration|delivery)\b|\bgithub actions\b|\bbuild pipelines?\b", re.I)
_V342_SYSTEMS_TITLE = re.compile(r"\b(embedded|firmware|kernel|systems? software|operating systems?|low[- ]level|device|hardware)\b", re.I)
_V342_HARD_BLOCKERS = ("work_authorization_or_sponsorship", "citizenship", "clearance", "graduation_window", "student_audience", "enrollment_required")
_V342_BLOCKER_LABEL = {
    "work_authorization_or_sponsorship": "no visa sponsorship", "citizenship": "U.S. citizenship required", "clearance": "security clearance required",
    "graduation_window": "graduation window excludes February 2027", "student_audience": "program for rising seniors / continuing students",
    "enrollment_required": "enrollment required past February 2027", "seniority_gap": "years of experience", "seniority_title": "senior title",
    "primary_stack_gap": "main stack not in evidence", "location_outside_us": "location outside the U.S.", "role_mismatch": "not a software role",
}


def _v342_role_text(raw_jd: str, min_mode: float = 0.6, hedged: bool = True) -> list[str]:
    """Role lines (responsibilities, requirements, preferred) without company blurbs, benefits or EEO text."""
    out = []
    for line, w, h in _v33_role_lines(raw_jd):
        if _V33_LINE_MODE.get(line, 1.0) < min_mode or (h and not hedged):
            continue
        out.append(line)
    return out


def _v342_ai_gate(plan: dict[str, Any], raw_jd: str) -> bool:
    title = str(plan.get("application", {}).get("role", ""))
    if _V342_AI_RX.search(title) or any(_V342_AI_RX.search(l) for l in _v342_role_text(raw_jd)):
        return True
    vec = plan.get("_jd_theme_vector") or {}
    return (vec.get("llm_agents", 0) + vec.get("ml_dl", 0) + vec.get("model_api", 0) + vec.get("ai_apps", 0)) >= 0.08



_jd_omission_warnings_v341 = jd_omission_warnings


def jd_omission_warnings(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[dict[str, Any]]:
    """AI/ML terms on a posting with no AI/ML theme are left off on purpose (change 2), and "operating systems in production"
    is the verb, so neither is reported as omitted."""
    out = _jd_omission_warnings_v341(plan, master, raw_jd)
    if _v342_os_is_verb(raw_jd):
        out = [w for w in out if str(w.get("target", "")) != "Operating Systems"]
    if _v342_ai_gate(plan, raw_jd):
        return out
    ai = {str(x).casefold() for x in (master.get("skills", {}).get("supported_pool", {}).get("ai_ml_data") or [])}
    return [w for w in out if str(w.get("target", "")).casefold() not in ai]

# --- 1. eligibility: blockers, never skips ---------------------------------------------------------------

_V342_MON = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6, "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12}
_V342_STUDENT_RX = re.compile(r"\brising (?:junior|senior|sophomore|third[- ]year|fourth[- ]year|final[- ]year)s?\b|\bentering (?:their|your|the) (?:junior|senior|final|last) year\b|"
                              r"\bpenultimate year\b|\breturn(?:ing)? to (?:school|university|campus|their studies) (?:after|following|in the fall)\b", re.I)


def _v342_grad_window(raw_jd: str) -> str:
    """A sentence that sets a single graduation date Jay (February 2027) does not meet ("graduating in May 2027",
    "graduation date between June 2027 and ..." is handled by the v3.2 two-date check).
    v3.4.8b: grad_window_warning already applies the December 2026 rule to every date form."""
    hit = grad_window_warning(raw_jd)
    if hit or v348b_on():
        return hit
    jay = 2027 * 12 + 2
    for s in re.split(r"(?<=[.!?])\s+|\n", str(raw_jd)):
        if not re.search(r"graduat|class of|conferr|degree (?:completion|date)", s, re.I):
            continue
        dates = [(int(y) * 12 + _V342_MON[mo[:3].lower()]) for mo, y in re.findall(r"\b((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*)\.?,?\s+(20\d\d)\b", s, re.I)]
        if len(dates) != 1:
            continue
        d = dates[0]
        if re.search(r"\b(by|before|no later than|prior to|on or before)\b", s, re.I):
            ok = jay <= d
        elif re.search(r"\b(after|or later|no earlier than|later than|on or after|or after)\b", s, re.I):
            ok = jay >= d
        elif re.search(r"\b(between|through|from|until)\b", s, re.I):
            continue
        else:
            ok = abs(jay - d) <= 1
        if not ok:
            return s.strip()[:160]
    return ""


_eligibility_blockers_v341 = eligibility_blockers


def eligibility_blockers(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, str]]:
    blockers = _eligibility_blockers_v341(plan, master)
    kinds = {b.get("type") for b in blockers}
    raw = str(plan.get("_raw_jd_text", ""))
    gw = _v342_grad_window(raw)
    if gw and "graduation_window" not in kinds:
        blockers.append({"type": "graduation_window", "requirement": gw,
                         "reason": "The posting sets a graduation date that does not include Jay's February 2027 graduation."})
    if "student_audience" not in kinds:
        for line in raw.splitlines():
            if _V342_STUDENT_RX.search(line):
                blockers.append({"type": "student_audience", "requirement": line.strip()[:200],
                                 "reason": "The program is aimed at students with school left after the program; Jay graduates in February 2027."})
                break
    return blockers


_gating_assessment_v341b = gating_assessment


def gating_assessment(plan: dict[str, Any], master: dict[str, Any], blockers: list[dict[str, str]]) -> dict[str, Any]:
    """v3.4.2: only a paste with zero parsed requirements stops. Every eligibility blocker (sponsorship, citizenship,
    clearance, graduation window, rising-senior programs, enrollment) is a note: the package is always built."""
    g = _gating_assessment_v341b(plan, master, blockers)
    keep = [x for x in g.get("skip_reasons", []) if x.get("type") == "no_requirements"]
    moved = [x for x in g.get("skip_reasons", []) if x.get("type") != "no_requirements"]
    have = {w.get("type") for w in g.get("warnings", [])}
    for x in moved:
        if "note_" + str(x.get("type")) not in have:
            g.setdefault("warnings", []).append({"type": "note_" + str(x.get("type")), "reason": x.get("reason", "")})
            have.add("note_" + str(x.get("type")))
    for b in blockers:
        t = b.get("type")
        if t in ("graduation_window", "student_audience") and "note_" + t not in have:
            g.setdefault("warnings", []).append({"type": "note_" + t, "reason": f"{b.get('reason', '')} (\"{str(b.get('requirement', ''))[:140]}\")"})
            have.add("note_" + t)
    if any(b.get("type") in _V342_HARD_BLOCKERS for b in blockers):
        g["fit_cap"] = "Low"
    g["skip_reasons"] = keep
    plan["_v342_blockers"] = [b for b in blockers if b.get("type")]
    return g


def blockers_summary(blockers: list[dict[str, Any]]) -> str:
    out = []
    labels = dict(_V342_BLOCKER_LABEL, **(V348B_LABELS if v348b_on() else {}))   # v3.4.8b: December 2026
    for b in blockers or []:
        lab = labels.get(str(b.get("type")), str(b.get("type", "")).replace("_", " "))
        if lab and lab not in out:
            out.append(lab)
    return "; ".join(out)


# --- 2 / 7 / 8. skills -------------------------------------------------------------------------------------

def _v342_claude_api_ok(plan: dict[str, Any], raw_jd: str) -> bool:
    """Claude API is shown only when GoingOnce (which calls Claude) is on the page or the JD names LLM APIs.
    "Claude Code" in a RIPPLE bullet is a coding tool, not the Claude API."""
    bullets = " ".join(bullet_text(b) for vals in (plan.get("bullets") or {}).values() for b in vals)
    real = bool(re.search(r"\bClaude\b(?!\s+Code)", bullets))
    return ("goingonce" in (plan.get("ranking") or []) and real) or _v342_jd_names_llm_api(raw_jd)


def _v342_jd_names_llm_api(raw_jd: str) -> bool:
    return any(_V342_LLM_API_RX.search(l) for l in _v342_role_text(raw_jd, hedged=True))


_build_skill_states_v341b = build_skill_states


def build_skill_states(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    raw = str(plan.get("_raw_jd_text", ""))
    plan["_v342_no_ai_floor"] = True
    states = _build_skill_states_v341b(plan, master)
    if not states:
        return states
    header = resolved_project_header_tech(master, plan["ranking"], plan)
    closure = {str(x) for x in selected_technology_skills(plan, master, header)}
    required = {str(x).casefold() for x in states[0].get("required_ats_terms", [])}
    log = plan.setdefault("_v342_skills", {})
    # AI/ML line only for AI/ML postings (a technology a selected bullet names stays: closure is a hard rule)
    if not _v342_ai_gate(plan, raw):
        gone = set()
        for st in states:
            vals = st.get("skills", {}).get("ai_ml")
            if vals:
                kept = [x for x in vals if x in closure or x.casefold() in required]
                gone |= set(vals) - set(kept)
                st["skills"]["ai_ml"] = kept
        if gone:
            log["ai_ml_line_removed"] = sorted(gone)
    # Claude API: only with GoingOnce on the page or a JD that names LLM APIs
    if not _v342_claude_api_ok(plan, raw) and "claude api" not in required and "claude api" not in {str(x).casefold() for x in _high_priority_skill_displays(plan, master)}:
        hit = False
        for st in states:
            for cat, vals in st.get("skills", {}).items():
                if "Claude API" in vals:
                    vals.remove("Claude API"); hit = True
            st["matched_tools"] = [x for x in st.get("matched_tools", []) if x != "Claude API"]
        if hit:
            log["claude_api_removed"] = True
    # OAuth/Auth0 for OAuth / SSO / authentication postings
    if any(_V342_AUTH_RX.search(l) for l in _v342_role_text(raw, hedged=True)):
        cat = supported_skill_category("OAuth/Auth0", master) or "tools"
        for st in states:
            vals = st.setdefault("skills", {}).setdefault(cat, [])
            if "OAuth/Auth0" not in vals:
                vals.insert(min(2, len(vals)), "OAuth/Auth0")
            if cat == "tools" and "OAuth/Auth0" not in st.get("matched_tools", []):
                st.setdefault("matched_tools", []).append("OAuth/Auth0")
        log["oauth_added"] = True
        sk = globals().get("_V33_SKILLS")
        if isinstance(sk, dict) and "OAuth/Auth0" not in sk.get("jd_named", []):
            sk.setdefault("jd_named", []).append("OAuth/Auth0")   # named by the JD as OAuth / SSO / authentication
    # "experience operating systems in production" is the verb "operate", not Operating Systems (the course topic)
    if _v342_os_is_verb(raw) and "pintos" not in plan.get("ranking", []):
        for st in states:
            for cat, vals in st.get("skills", {}).items():
                if "Operating Systems" in vals:
                    vals.remove("Operating Systems"); log["operating_verb_not_os"] = True
    # Kubernetes is always scoped
    for st in states:
        for cat, vals in st.get("skills", {}).items():
            for i, x in enumerate(vals):
                if x == "Kubernetes":
                    vals[i] = "Kubernetes (local k3d)"
        st["matched_tools"] = ["Kubernetes (local k3d)" if x == "Kubernetes" else x for x in st.get("matched_tools", [])]
    # at most 2 terms from one synonym group, even when the JD names more
    cap = int(master["skills"].get("synonym_group_max_terms", 2))
    groups = master["skills"].get("synonym_groups", [])
    jd_order = [str(x) for x in (globals().get("_V33_SKILLS") or {}).get("jd_named", [])]
    trimmed = set()
    for st in states:
        allv = [x for vals in st.get("skills", {}).values() for x in vals]
        for gr in groups:
            present = [x for x in allv if x in gr]
            if len(present) <= cap:
                continue
            rank = lambda x: (0 if x.casefold() in required else 1, 0 if x in closure else 1, jd_order.index(x) if x in jd_order else 99, present.index(x))
            keep = sorted(present, key=rank)[:cap]
            for cat, vals in st["skills"].items():
                for x in list(vals):
                    if x in present and x not in keep:
                        vals.remove(x); trimmed.add(x)
            st["matched_tools"] = [x for x in st.get("matched_tools", []) if x not in trimmed]
    if trimmed:
        log["synonym_terms_trimmed"] = sorted(trimmed)
    # the Tools line is exactly one line: matched tools that are neither required nor named in a selected bullet or
    # heading may be pruned by the fitter ("GitHub" next to "GitHub Actions" first), so a longer scoped label
    # ("Kubernetes (local k3d)") never makes the page fail
    width = lambda xs: len("Tools: ") + sum(len(x) + 2 for x in xs)
    highs = {str(x).casefold() for x in _high_priority_skill_displays(plan, master)}
    for st in states:
        tools = st.get("skills", {}).get("tools", [])
        if "GitHub Actions" in tools and "GitHub" in tools:
            tools.remove("GitHub")   # "GitHub Actions" already shows the word GitHub (an ATS match for a GitHub requirement)
            st["matched_tools"] = [x for x in st.get("matched_tools", []) if x != "GitHub"]
        matched = [x for x in tools if x in set(st.get("matched_tools", []))]
        for x in reversed(list(matched)):
            if width(matched) <= 100:
                break
            if x.casefold() in required or x.casefold() in highs or x in closure or (x == "OAuth/Auth0" and log.get("oauth_added")):
                continue
            matched.remove(x)
            st["matched_tools"] = [y for y in st.get("matched_tools", []) if y != x]
            log.setdefault("tools_unprotected", []).append(x)
        if st is states[0] and width(matched) > 100:
            plan["_v341_tight_unresolved"] = True
    return states


_validate_selected_technology_skill_coverage_v341 = validate_selected_technology_skill_coverage


def validate_selected_technology_skill_coverage(plan, master, resolved_skills, project_tech):
    """"GitHub Actions" in Skills also shows GitHub."""
    out = _validate_selected_technology_skill_coverage_v341(plan, master, resolved_skills, project_tech)
    shown = " | ".join(x for vals in (resolved_skills or {}).get("skills", {}).values() for x in vals)
    keep = []
    for f in out:
        m = f.get("measured")
        if isinstance(m, list):
            m = [x for x in m if not (x == "GitHub" and "GitHub Actions" in shown)
                 and not (x == "Claude API" and not _v342_claude_api_ok(plan, str(plan.get("_raw_jd_text", ""))))]
            if not m:
                continue
            f = dict(f, measured=m)
        keep.append(f)
    return keep


_resolved_project_header_tech_v341 = resolved_project_header_tech


def resolved_project_header_tech(master: dict[str, Any], display_order: list[str], plan: dict[str, Any] | None = None) -> dict[str, list[str]]:
    out = _resolved_project_header_tech_v341(master, display_order, plan)
    for pid, vals in out.items():
        out[pid] = ["Kubernetes (local k3d)" if x == "Kubernetes" else x for x in vals]
    return out


_adapt_header_tech_v341 = adapt_header_tech


def adapt_header_tech(pid: str, vals: list[str], plan: dict[str, Any], master: dict[str, Any]) -> list[str]:
    """GitHub Actions joins the LedgerFlow heading when the CI bullet is on the page and the posting names it."""
    out = _adapt_header_tech_v341(pid, vals, plan, master)
    if pid != "ledgerflow" or "GitHub Actions" in out:
        return out
    raw = str(plan.get("_raw_jd_text", ""))
    on_page = any(isinstance(b, dict) and b.get("main_evidence_id") == "ledger.ci" for b in (plan.get("bullets") or {}).get(pid, []))
    if not on_page or not re.search(r"\bgithub actions\b", raw, re.I):
        return out
    jdkeys = {str(x).casefold() for x in plan.get("_jd_pool_terms", []) or []}
    spot = next((i for i in range(len(out) - 1, 0, -1) if out[i].casefold() not in jdkeys), None)
    if spot is None:
        return out
    return out[:spot] + ["GitHub Actions"] + out[spot + 1:]


# --- 3. language-led roles -------------------------------------------------------------------------------

_V342_LANGS = ["Java", "C", "C++", "C#", "Python", "Go", "Golang", "JavaScript", "TypeScript", "Rust", "Kotlin", "Scala", "Ruby", "Swift", "PHP"]
_V342_LANG_CUE = re.compile(r"\b(experience|proficien\w*|knowledge|skills?|familiar\w*|preferred|required|must|strong|expert\w*|fluen\w*|programming|coding|develop\w*|write|written|background)\b", re.I)


def _v342_langs_in(line: str) -> list[str]:
    s = clean_jd_text(line)
    found = []
    for lang in _V342_LANGS:
        if lang == "C":
            rx = r"(?<![\w+#/.-])C(?![\w+#/])"
        elif lang in ("C++", "C#"):
            rx = r"(?<![\w])" + re.escape(lang) + r"(?![\w+#])"
        elif lang == "Go":
            rx = r"(?<![\w])(?:Go|Golang)(?![\w])"
        elif lang == "Java":
            rx = r"(?<![\w])Java(?![\w]|Script)"
        else:
            rx = r"(?<![\w])" + re.escape(lang) + r"(?![\w])"
        if re.search(rx, s, 0 if len(lang) <= 2 else re.I):
            name = "Go" if lang == "Golang" else lang
            if name not in found:
                found.append(name)
    return found


_V342_DOMAIN_TITLE = re.compile(r"\b(AI|ML|machine learning|artificial intelligence|LLM|GenAI|data|analytics|front[- ]?end|UI|mobile|iOS|Android)\b", re.I)


def lead_language(title: str, raw_jd: str) -> str:
    """The one language a title or a required / preferred line singles out ("Java Developer", "Java preferred",
    "Experience programming in C"). A line that lists several languages never counts."""
    t = _v342_langs_in(title)
    if len(t) == 1:
        return t[0]
    if _V342_DOMAIN_TITLE.search(title or ""):
        # An AI / ML / data / frontend title already names what leads; a Java line in its body does not override it.
        return ""
    votes: dict[str, int] = {}
    for line in _v342_role_text(raw_jd, min_mode=0.6, hedged=False):
        langs = _v342_langs_in(line)
        if len(langs) != 1 or not _V342_LANG_CUE.search(line):
            continue
        strength = 2 if re.search(r"\b(preferred|required|must)\b", line, re.I) else 1
        votes[langs[0]] = max(votes.get(langs[0], 0), strength)
    if not votes:
        return ""
    top = max(votes.values())
    best = [k for k, v in votes.items() if v == top]
    return best[0] if len(best) == 1 else ""


_apply_auto_ranking_v341 = apply_auto_ranking


def apply_auto_ranking(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    auto = raw_plan.get("ranking") == "auto"
    _apply_auto_ranking_v341(raw_plan, master, raw_jd)
    if not auto:
        return
    lang = lead_language(str(raw_plan.get("application", {}).get("role", "")), raw_jd)
    pid = (master.get("language_lead_projects") or {}).get(lang) if lang else None
    if not pid or pid not in master.get("projects", {}):
        return
    ranking = list(raw_plan.get("ranking") or [])
    if ranking and ranking[0] == pid:
        raw_plan["_v342_lead_language"] = {"language": lang, "project": pid, "moved": False}
        return
    new = [pid] + [p for p in ranking if p != pid]
    new = new[:3]
    scores = dict(raw_plan.get("project_scores") or {})
    top = max(scores.values()) if scores else 0.0
    for i, p in enumerate(new):
        scores[p] = round(top + 4.0 - i, 3)
    for p in scores:
        if p not in new:
            scores[p] = min(scores[p], round(top, 3))
    raw_plan["project_scores"] = scores
    raw_plan["ranking"] = new
    raw_plan["_v342_lead_language"] = {"language": lang, "project": pid, "moved": True, "before": ranking}


_V342_LLM_REL = {"eval": r"\beval(?:uat\w+|s)?\b|eval harness|benchmark", "obs": r"observab\w*|tracing|\bmonitor\w*",
                 "guard": r"guardrail\w*|\bsafety\b", "cost": r"cost controls?|\bcosts?\b",
                 "fall": r"fallback\w*|failover|\bretr(?:y|ies)\b|fault[- ]toleran\w*", "rel": r"reliab\w*"}


def _v342_llm_reliability(raw_jd: str) -> list[str]:
    """Agent / LLM postings whose role lines stress how the system is run (evaluation, observability, guardrails,
    cost, fallbacks, reliability): the LLM engine (validators, provider failover, tests) proves that directly."""
    if globals().get("_V345_CTX", {}).get("no_llm_rel"):
        return []   # v3.4.5 (B1): the override was blocked (avoided project / preferred #1 displaced, no explicit line)
    text = " ".join(_v342_role_text(raw_jd))
    if not re.search(r"\bagent\w*|\bllms?\b|large language model", text, re.I):
        return []
    return [k for k, rx in _V342_LLM_REL.items() if re.search(rx, text, re.I)]


_apply_auto_ranking_v342a = apply_auto_ranking


def apply_auto_ranking(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    auto = raw_plan.get("ranking") == "auto"
    _apply_auto_ranking_v342a(raw_plan, master, raw_jd)
    if not auto or raw_plan.get("_v342_lead_language", {}).get("moved"):
        return
    hits = _v342_llm_reliability(raw_jd)
    ranking = list(raw_plan.get("ranking") or [])
    pid = "tailor_pipeline"
    if len(hits) < 4 or pid not in master.get("projects", {}) or pid in ranking or len(ranking) < 3:
        return
    scores = dict(raw_plan.get("project_scores") or {})
    out = ranking[2]
    scores[pid] = round(scores.get(out, 0.0) + 0.5, 3)
    raw_plan["project_scores"] = scores
    raw_plan["ranking"] = ranking[:2] + [pid]
    raw_plan["_v342_llm_reliability"] = {"signals": hits, "replaced": out}
    if not str(raw_plan.get("ranking_override_reason", "")).strip():
        raw_plan["ranking_override_reason"] = "v3.4.2 LLM-system reliability posting (" + ", ".join(hits) + "): the LLM engine's validators, provider failover and tests"


# --- 4. testing evidence ---------------------------------------------------------------------------------

_apply_auto_plan_fields_v341 = apply_auto_plan_fields


def apply_auto_plan_fields(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    _apply_auto_plan_fields_v341(raw_plan, master, raw_jd)
    lines = _v342_role_text(raw_jd, hedged=True)
    title = str(raw_plan.get("application", {}).get("role", ""))
    raw_plan["_v342_testing_jd"] = bool(_V342_TEST_RX.search(title)) or sum(1 for l in lines if _V342_TEST_RX.search(l)) >= 1
    raw_plan["_v342_testing_heavy"] = bool(re.search(r"\b(qa|sdet|test|quality)\b", title, re.I)) or sum(1 for l in lines if _V342_TEST_RX.search(l)) >= 3
    raw_plan["_v342_ci_named"] = any(_V342_CI_RX.search(l) for l in lines)
    raw_plan["_v342_permissions_jd"] = any(_V342_PERM_RX.search(l) for l in lines)
    vec = raw_plan.get("_jd_theme_vector") or jd_theme_vector(raw_jd, title)
    raw_plan["_v342_systems_jd"] = bool(_V342_SYSTEMS_TITLE.search(title)) or vec.get("systems", 0) >= 0.12
    if _v342_os_is_verb(raw_jd) and isinstance(raw_plan.get("jd_requirements"), list):
        def _os(r):
            return isinstance(r, dict) and any(str(x).casefold() == "operating systems" for x in [r.get("term", "")] + list(r.get("aliases", [])))
        dropped = [r for r in raw_plan["jd_requirements"] if _os(r)]
        if dropped:
            raw_plan["jd_requirements"] = [r for r in raw_plan["jd_requirements"] if not _os(r)]
            raw_plan["_v342_operating_verb"] = True


def _v342_os_is_verb(raw: str) -> bool:
    """"experience operating systems in production" uses the verb "operate"; it is not the Operating Systems topic."""
    occ = list(re.finditer(r"\boperating systems?\b", raw, re.I))
    verb = [m for m in occ if re.search(r"(?:experience|building|build|and|of)\s+$", raw[max(0, m.start() - 20):m.start()], re.I)
            or re.match(r"\s+(?:in production|at scale|reliably|that|for)\b", raw[m.end():m.end() + 20], re.I)]
    return bool(occ) and len(verb) == len(occ)


_V342_TEST_BONUS = {"ledger.ci": 4.0, "ripple.claude_code_dev": 1.5, "ripple.tests": 1.0, "ledger.chaos_runs": 0.5}
_variant_score_v341 = _variant_score


def _variant_score(v, weights, themes, prefer, breakdown: bool = False):
    r = _variant_score_v341(v, weights, themes, prefer, breakdown)
    plan = globals().get("_V342_PLAN") or {}
    bonus = 0.0
    if plan.get("_v342_testing_jd"):
        bonus = _V342_TEST_BONUS.get(str(v.get("main_evidence_id")), 0.0)
        if v.get("main_evidence_id") == "ledger.ci" and plan.get("_v342_ci_named"):
            bonus += 3.0
        if plan.get("_v341_tight"):
            bonus = 0.0    # a page whose skills cannot fit prefers bullets that add no new technology
    if plan.get("_v341_tight"):
        master = globals().get("_V33_MASTER") or {}
        raw = str(plan.get("_raw_jd_text", ""))
        tools = (master.get("skills", {}).get("supported_pool", {}) or {}).get("tools_platforms", [])
        txt = str(v.get("text", ""))
        extra = [t for t in tools if len(t) > 3 and re.search(r"(?<![\w])" + re.escape(t) + r"(?![\w])", txt) and not boundary_contains_plural(raw, t)]
        bonus -= 3.0 * len(extra)
    if plan.get("_v342_permissions_jd") and v.get("main_evidence_id") == "launchops.server_checks" and "other users' tasks" in str(v.get("text", "")):
        bonus += 2.0
    adj, why = v349_variant_adjust(v) if _v347_on("bullet_score_v349") else (0.0, [])   # v3.4.9a fix 4
    if breakdown:
        s, parts = r
        return s + bonus + adj, parts + ([("testing_v342", bonus, "")] if bonus else []) + why
    return r + bonus + adj


def _v342_identity_phrases(master: dict[str, Any], pid: str) -> list[str]:
    return [str(x).casefold() for x in (master.get("project_identity_phrases") or {}).get(pid, [])]


_v341_project_combos_v341 = _v341_project_combos


def _v341_project_combos(pool, k, need_headline, scores, keep, pairs, force):
    """v3.4.2: a 1-line pair partner never re-describes the project the other bullets already introduce
    ("Tested RIPPLE, the command-line AI agent that predicts change impact ...")."""
    out = _v341_project_combos_v341(pool, k, need_headline, scores, keep * 3, pairs, force)
    master = globals().get("_V33_MASTER") or {}
    pid = str(pool[0]["id"]).split(".")[0] if pool else ""
    ids = _v342_identity_phrases(master, pid)
    if not ids:
        return out[:keep]
    def restates(c):
        units = [u for u, _s in c[2]]
        for u in units:
            if len(u) != 2:
                continue
            for v in u:
                t = str(v.get("text", "")).casefold()
                if any(p in t for p in ids):
                    others = [w for w in c[3] if w is not v]
                    if any(any(p in str(w.get("text", "")).casefold() for p in ids) for w in others):
                        return True
        return False
    good = [c for c in out if not restates(c)]
    return (good or out)[:keep]


_auto_bank_selection_v341 = auto_bank_selection


def auto_bank_selection(raw_plan, bank, pairs=None):
    globals()["_V342_PLAN"] = raw_plan
    try:
        return _auto_bank_selection_v341(raw_plan, bank, pairs)
    finally:
        globals()["_V342_PLAN"] = None


# --- 5 / 6 / 9. cover letter -------------------------------------------------------------------------

_V342_PRI = {"must": 3.0, "high": 2.0, "medium": 1.0}


def _v342_req_terms(plan: dict[str, Any]) -> list[tuple[str, float]]:
    out = []
    for r in plan.get("jd_requirements", []) or []:
        if not isinstance(r, dict) or r.get("supported") is False:
            continue
        w = _V342_PRI.get(str(r.get("priority", "")).lower(), 0.5)
        for t in [r.get("term")] + list(r.get("aliases", []) or []):
            if t and len(str(t)) > 1:
                out.append((str(t), w))
    return out


def _v342_sentence_score(plan: dict[str, Any], s: str) -> float:
    return sum(w for t, w in _v342_req_terms(plan) if boundary_contains_plural(s, t))


_v33_project_sentences_v341 = _v33_project_sentences


def _v33_project_sentences(plan: dict[str, Any], master: dict[str, Any], pid: str, vec: dict[str, float]) -> str:
    """Letter sentences follow the posting's top requirements, not the bullet rank: each on-page evidence sentence
    scores by the must/high/medium requirement terms it names; access-control, testing and CI sentences win on
    postings that ask for them."""
    if pid == "ripple" and plan.get("_v34_force"):
        return _v33_project_sentences_v341(plan, master, pid, vec)
    bank = master.get("cover_letter_bank", {}).get("letter_sentences", {}).get(pid, {})
    intro = bank.get("intro", "")
    head = master["projects"][pid].get("headline_evidence_id")
    picks = []
    for vid, eid in _v33_selected_evidence(plan, pid):
        s = bank.get(vid) or bank.get(eid)
        if eid == "launchops.server_checks" and plan.get("_v342_permissions_jd") and bank.get("launchops.access_control"):
            s = bank["launchops.access_control"]
        if not s:
            continue
        sc = 3.0 * _v342_sentence_score(plan, s) + (1.0 if eid == head else 0.0) + (1.0 if re.search(r"\d", s) else 0.0)
        if eid == "launchops.server_checks" and plan.get("_v342_permissions_jd"):
            sc += 10.0
        if eid == "ledger.ci" and plan.get("_v342_testing_heavy"):
            sc += 10.0
        elif eid == "ledger.ci" and plan.get("_v342_ci_named"):
            sc += 6.0
        if eid in ("ripple.claude_code_dev", "ripple.tests") and plan.get("_v342_testing_heavy"):
            sc += 4.0
        picks.append((sc, s))
    picks.sort(key=lambda x: -x[0])
    body = [intro] + [s for _, s in picks[:1]]
    if picks and not re.search(r"\d", " ".join(body)):
        num = next((s for _, s in picks if re.search(r"\d", s)), None)
        if num:
            body.append(num)
    plan.setdefault("_v342_letter_sentences", {})[pid] = [s for _, s in picks[:2]]
    return " ".join(x for x in body if x)


_v33_experience_key_v341 = _v33_experience_key


def _v33_experience_key(plan, vec, ranking):
    """Embedded / systems roles lead with the Thesis IoT pipeline (real devices streaming data), never with LLM work."""
    cl = plan.get("cover_letter") or {}
    if isinstance(cl, dict) and cl.get("experience"):
        return _v33_experience_key_v341(plan, vec, ranking)
    if plan.get("_v342_systems_jd") and not plan.get("_ai_coding_tools") and not _is_data_ml_role(plan):
        return "thesis_iot"
    return _v33_experience_key_v341(plan, vec, ranking)


_V342_RESP_HEAD = re.compile(r"essential functions|key functions|primary functions|responsib|what you(?:'|’)?ll do|what you will do|you will|you(?:'|’)ll|in this role|the role|day[- ]to[- ]day|what you(?:'|’)ll be doing|your impact|key duties|duties|"
                             r"what you will be doing|the opportunity|your work|job description|about the job|what we need", re.I)
_V342_REQ_HEAD = re.compile(r"qualif|requirement|what you bring|about you|you have|you bring|skills|experience|who you are|must have|nice to have|preferred|bonus|benefit|perk|compens|salary|about us|eeo|equal", re.I)
_V342_GENERIC_RESP = re.compile(r"^(?:collaborat|communicat|partner|participat|work closely|work with|attend|learn|grow|support|assist|contribute to a|be part|develop skills|maintain the|help in|help me|review|make key)|"
                                r"\b(?:me|my|I|mentorship|confidential\w*|sales|policies)\b", re.I)
_V342_VERB_OK = re.compile(r"^(?:design|build|develop|create|implement|write|test|own|maintain|improve|scale|ship|deliver|integrate|automate|debug|troubleshoot|deploy|operate|"
                           r"monitor|optimi[sz]e|architect|engineer|support|help|work|make|keep|ensure|drive|lead|define|validate|verify|analy[sz]e|investigate|"
                           r"prototype|evaluate|extend|enhance|modernize|migrate|refactor|configure|manage|run|produce|code|program|contribute|solve|review|document)\b", re.I)


def _v342_heading(line: str) -> bool:
    head = re.sub(r"[#*_]+", "", line).strip()
    return len(head.split()) <= 8 and not head.endswith(".") and (head.endswith(":") or head.istitle() or head.isupper() or line.lstrip().startswith("#") or line.lstrip().startswith("**"))


def _v342_base(w: str) -> str:
    lw = w.lower()
    for cand in ([lw[:-3] + "y"] if lw.endswith("ies") else []) + ([lw[:-2]] if re.search(r"(?:ss|x|z|ch|sh)es$", lw) else []) + ([lw[:-1]] if lw.endswith("s") else []):
        if _V342_VERB_OK.search(cand) and _V342_VERB_OK.search(cand).end() == len(cand):
            return cand
    return lw


def _v342_base_verbs(text: str) -> str:
    """Job-ad third person ("Creates and executes designs") becomes the base form ("create and execute designs")."""
    toks = text.split(" ")
    if not toks:
        return text
    head = 0
    for i, t in enumerate(toks[:6]):
        core = t.rstrip(",")
        if i == 0 or (i > 0 and toks[i - 1].lower() in ("and", "or")) or (i > 0 and toks[i - 1].endswith(",")):
            b = _v342_base(core)
            if b != core.lower() and core[:1].isalpha():
                toks[i] = (b if i else b.capitalize()) + t[len(core):]
                head = i
    return " ".join(toks)


def top_responsibilities(raw_jd: str) -> list[str]:
    """The posting's top responsibility in its own words: the first concrete line under a responsibilities heading
    (else the first concrete role line), as a verb phrase of at most 16 words."""
    banned = [b.lower() for b in (globals().get("_V33_MASTER") or {}).get("cover_letter_rules", {}).get("banned_phrases", [])]
    section, cands, fallback = None, [], []
    for raw in str(raw_jd).splitlines():
        line = raw.strip()
        if not line:
            continue
        if _v342_heading(line):
            section = "resp" if _V342_RESP_HEAD.search(line) and not _V342_REQ_HEAD.search(line) else ("req" if _V342_REQ_HEAD.search(line) else "other")
            continue
        text = re.sub(r"^[-*•·▪◦‣>\d.)\s]+", "", line).strip()
        text = re.sub(r"^(?:you will|you'll|you’ll|will|as an? [^,]{3,40},\s*you will|responsible for|the role involves|in this role,? you will)\s+", "", text, flags=re.I).strip()
        text = re.split(r",?\s+(?:such as|e\.g\.|eg\.|including|like)\s+|\s+\(", text)[0].strip()
        text = _v342_base_verbs(text)
        if not text or re.search(r"\d|https?:|@|\$", text) or len(text.split()) < 4:
            continue
        text = re.sub(r"\bour\b", "its", re.sub(r"\byour\b", "the", text, flags=re.I), flags=re.I)
        if re.search(r"\b(?:we|us|you)\b", text, re.I):
            continue
        if any(b in text.lower() for b in banned) or _V342_GENERIC_RESP.search(text):
            continue
        if not _V342_VERB_OK.search(text):
            continue
        if section == "resp":
            cands.append(text)
        elif section in (None, "other"):
            fallback.append(text)
    pool = (cands or fallback)[:6]
    if not pool:
        return []
    def clause(t):
        return re.split(r";|:|\.\s|\.$|,\s+(?:ensuring|while|so that|which|with a focus)\b|\s+-\s+|\s+—\s+|\\|\s+(?:as part of|using|in order to|utilizing|leveraging)\s+", t)[0].strip().rstrip(".,")
    pool = [clause(t) for t in pool]
    def shape(pick):
        words = pick.split()
        if len(words) > 16:
            cut = " ".join(words[:16])
            m = re.match(r"(.+?)(?:,| and | or )[^,]*$", cut)
            pick = m.group(1) if m and len(m.group(1).split()) >= 6 else cut
            for _ in range(4):
                pick = re.sub(r"[\s,]+(?:and|or|to|of|for|with|the|a|an|in|on|are|is|be|that|as|part|from|by|at|across|its)$", "", pick)
        pick = pick.strip().rstrip("\\").strip()
        return pick[0].lower() + pick[1:] if pick and pick[:2] != pick[:2].upper() else pick
    good = [t for t in pool if 5 <= len(t.split()) <= 16]
    return [shape(t) for t in good + [t for t in pool if t not in good] if t]


def top_responsibility(raw_jd: str) -> str:
    """The posting's top responsibility in its own words: the first concrete line under a responsibilities heading
    (else the first concrete role line), as a verb phrase of at most 14 words."""
    r = top_responsibilities(raw_jd)
    return r[0] if r else ""


def _v342_unsupported_in(text: str, plan: dict[str, Any], master: dict[str, Any]) -> list[str]:
    hits = []
    for req in plan.get("jd_requirements", []) or []:
        if not isinstance(req, dict):
            continue
        term = str(req.get("term", "")); verbatim = str(req.get("verbatim", ""))
        if master_supports_requirement(term, [str(a) for a in req.get("aliases", [])], master):
            continue
        for c in [term] + ([verbatim] if len(verbatim.split()) <= 4 else []):
            if c and len(c) > 2 and boundary_contains_plural(text, c) and not master_supports_requirement(c, [], master):
                hits.append(c)
    for t in master.get("never_supported_terms", []) + list(plan.get("_jd_gap_terms", []) or []):
        if t and len(str(t)) > 1 and boundary_contains_plural(text, str(t)):
            hits.append(str(t))
    return hits


def _v342_closing(plan: dict[str, Any], master: dict[str, Any], raw_jd: str, company_ref: str, letter: str = "") -> tuple[str, dict[str, Any]]:
    ok = [r for r in top_responsibilities(raw_jd) if not _v342_unsupported_in(r, plan, master)]
    low = letter.lower()
    resp = next((r for r in ok if r.lower() not in low), ok[0] if ok else "")   # the opening already quotes one: close on the next
    proofs = master.get("cover_letter_bank", {}).get("closing_proofs", {})
    ranking = plan.get("ranking") or []
    letter_proj = (plan.get("_v33_letter") or {}).get("projects") or ranking[:2]
    order = list(dict.fromkeys(letter_proj))   # the letter names two projects at most: the proof comes from one of them
    cands = []
    for i, pid in enumerate(order):
        for _vid, eid in _v33_selected_evidence(plan, pid):
            p = proofs.get(eid)
            if p:
                score = 3.0 * _v342_sentence_score(plan, p) + 2.0 * sum(1 for w in re.findall(r"[a-z]{5,}", resp.lower()) if w in p.lower()) + (2.0 - i)
                if eid == "ledger.ci" and plan.get("_v342_testing_jd"):
                    score += 3.0
                if eid == "launchops.server_checks" and plan.get("_v342_permissions_jd"):
                    score += 3.0
                lsent = master.get("cover_letter_bank", {}).get("letter_sentences", {}).get(pid, {})
                said = [x for x in (lsent.get(_vid), lsent.get(eid), lsent.get("launchops.access_control") if eid == "launchops.server_checks" else None) if x]
                pname = " ".join(str(x.get("resume_title", {}).get("name", "")) for x in master["projects"].values()).lower()
                pw = {w for w in re.findall(r"[a-z]{4,}", p.lower()) if w not in _V342_STOP and w not in pname}
                seen = sum(1 for w in pw if w in low) / max(1, len(pw))
                if any(x in letter for x in said) or seen >= 0.6:
                    score -= 100.0   # the letter already says it: the close points to a different result whenever one exists
                cands.append((score, eid, p))
    ek = (plan.get("_v33_letter") or {}).get("experience")
    if plan.get("_v342_systems_jd") and proofs.get("exp.thesis_backend"):
        cands.append((1.0, "exp.thesis_backend", proofs["exp.thesis_backend"]))
    cands.sort(key=lambda x: -x[0])
    proof = cands[0][2] if cands else ""
    info = {"responsibility": resp, "proof": cands[0][1] if cands else "", "experience": ek}
    if resp and proof:
        lead = f"I want to help {company_ref} {resp}" if _V342_VERB_OK.search(resp) else f"I want to help {company_ref} with {resp}"
        s = f"{lead}, building on {proof}."
    elif resp:
        s = f"I want to help {company_ref} {resp}." if _V342_VERB_OK.search(resp) else f"I want to help {company_ref} with {resp}."
    else:
        fam = str(plan.get("role_family", ""))
        tmpl = master.get("cover_letter_bank", {}).get("family_closing", {}).get(fam, "build dependable, well-tested software with the team at {company}")
        poss = company_ref + ("'" if company_ref.endswith("s") else "'s")
        what = tmpl.replace("{company}'s", poss).replace("{company}", company_ref)
        s = f"I want to {what}, building on {proof}." if proof else f"I want to {what}."
        info["responsibility"] = ""
    return s, info


def validate_closing_v342(closing: str, plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[dict[str, Any]]:
    out = []
    c = re.sub(r"\s+", " ", str(closing or "")).strip()
    if not c:
        return out
    if re.match(r"(?i)i would welcome the chance", c):
        out.append(fail("cover_letter_closing_generic", "cover_letter.closing", c, "does not start with \"I would welcome the chance\"",
                        "Leave closing empty (the script writes it), or write one sentence naming the posting's top responsibility in its words plus your matching proof."))
    if len(c.split()) > 36 or not c.endswith(".") or len(re.split(r"(?<=[.!?])\s+", c)) != 1:
        out.append(fail("cover_letter_closing_shape", "cover_letter.closing", c, "one sentence, <= 36 words, ends with a period", "Shorten the closing to one sentence."))
    words = re.findall(r"[a-z0-9][a-z0-9'&+#.-]*", c.lower())
    role_words = re.findall(r"[a-z0-9][a-z0-9'&+#.-]*", " ".join(_v342_role_text(raw_jd)).lower())
    rset = {" ".join(role_words[i:i + 4]) for i in range(len(role_words) - 3)}
    if not (v349_from_one_line(c, raw_jd) if _v347_on("copy_rule_v349") else any(" ".join(words[i:i + 4]) in rset for i in range(len(words) - 3))):   # v3.4.9a fix 8
        out.append(fail("cover_letter_closing_not_from_jd", "cover_letter.closing", c, "4+ consecutive words from a responsibility line",
                        "Name the posting's top responsibility in its own words."))
    names = [str(p.get("resume_title", {}).get("name", "")) for p in master["projects"].values()] + ["Thesis", "HeinOnline", "Data Maven", "Go Digital", "Pintos"]
    if not any(n and n.lower() in c.lower() for n in names):
        out.append(fail("cover_letter_closing_no_proof", "cover_letter.closing", c, "names the project or job that proves it", "Add your matching proof (a project or job on the page)."))
    return out


_compose_bank_cover_letter_v341 = compose_bank_cover_letter


def compose_bank_cover_letter(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[dict[str, Any]]:
    cl = plan.get("cover_letter") if isinstance(plan.get("cover_letter"), dict) else None
    model_close = ""
    if cl is not None:
        model_close = re.sub(r"\s+", " ", str(cl.get("closing", "") or "")).strip()
        cl["closing"] = ""
    # the letter's second project is the one that better answers the posting's top requirements
    ranking = list(plan.get("ranking") or [])
    swapped = False
    if len(ranking) == 3 and not plan.get("_v34_force"):
        def proj_score(pid):
            return sum(_v342_sentence_score(plan, (master.get("cover_letter_bank", {}).get("letter_sentences", {}).get(pid, {}) or {}).get(v) or
                                            (master.get("cover_letter_bank", {}).get("letter_sentences", {}).get(pid, {}) or {}).get(e) or "")
                       for v, e in _v33_selected_evidence(plan, pid))
        if proj_score(ranking[2]) > proj_score(ranking[1]) + 2.0:
            plan["ranking"] = [ranking[0], ranking[2], ranking[1]]
            swapped = True
    try:
        failures = _compose_bank_cover_letter_v341(plan, master, raw_jd)
    finally:
        if swapped:
            plan["ranking"] = ranking
            if isinstance(plan.get("_v33_letter"), dict):
                plan["_v33_letter"]["second_by_requirements"] = True
        if cl is not None:
            cl["closing"] = model_close
    paras = plan.get("cover_letter_paragraphs") or []
    if not paras or plan.get("_cover_letter_mode") != "bank":
        return failures
    app = plan.get("application", {})
    company = str(app.get("company", "")).strip()
    agency = "your client" in " ".join(paras)
    company_ref = "your client" if agency else ("your team" if company_is_placeholder(company) else company)
    if model_close:
        cf = validate_closing_v342(model_close, plan, master, raw_jd)
        failures += cf
        closing = model_close if not cf else ""
        info = {"source": "plan"}
    else:
        closing, info = _v342_closing(plan, master, raw_jd, company_ref, " ".join(paras))
        info["source"] = "auto"
    p2 = paras[-1]
    sents = re.split(r"(?<=[.!?])\s+", p2)
    sents = [s for s in sents if not s.startswith("I would welcome the chance to ")]
    # 9. internship letters for onsite roles include relocation
    loc = str(app.get("location", "")).strip()
    remote = bool(re.search(r"\bremote\b", loc + " " + raw_jd[:400], re.I)) and not re.search(r"hybrid|onsite|on-site|in office", loc, re.I)
    reloc = bool(loc) and loc.lower() not in ("not stated", "n/a", "unknown") and not remote and not re.search(r"buffalo", loc, re.I)
    intern = bool(re.search(r"\bintern(?:ship)?s?\b|\bco-?op\b", str(app.get("role", "")), re.I))
    if intern and reloc and not any("relocat" in s for s in sents):
        idx = next((i for i, s in enumerate(sents) if "February 2027" in s), len(sents) - 1)
        sents.insert(idx + 1, "I am open to relocating.")
    if closing:
        cap = int(master.get("cover_letter_rules", {}).get("words_per_paragraph", {}).get(str(len(paras)), [0, 140])[1])
        base = _letter_words(" ".join(sents))
        total_cap = min(200, int((master.get("cover_letter_rules", {}).get("words_total") or [0, 200])[1]))
        others = sum(_letter_words(p) for p in paras[:-1])
        if (base + _letter_words(closing) > cap or others + base + _letter_words(closing) > total_cap) and info.get("source") == "auto":
            short = re.sub(r", building on (.+?)\.$", lambda m: ", building on " + m.group(1).split(",")[0] + ".", closing)
            if (base + _letter_words(short) > cap or others + base + _letter_words(short) > total_cap) and info.get("responsibility"):
                r = info["responsibility"]
                r2 = re.split(r",| and | that | for | with ", r)[0].strip()
                short = short.replace(r, r2) if len(r2.split()) >= 3 else short
            closing = short
            info["shortened"] = True
        sents.append(closing)
    paras[-1] = " ".join(s for s in sents if s)
    plan["cover_letter_paragraphs"] = paras
    plan["_v342_closing"] = dict(info, text=closing)
    return failures


_validate_cover_letter_v32_v341 = validate_cover_letter_v32


def validate_cover_letter_v32(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    out = [f for f in _validate_cover_letter_v32_v341(plan, master) if f.get("type") not in ("cover_letter_closing_shape",)
           or "I would welcome" not in str(f.get("expected", ""))]
    if v348b_on():   # v3.4.8b: graduation is December 2026; February 2027 appears only as the start date
        bad = v348b_text_problems(" ".join(str(p) for p in plan.get("cover_letter_paragraphs") or []))
        if bad:
            out.append(fail("cover_letter_graduation_date", "cover_letter_paragraphs", bad, "graduation December 2026; February 2027 only as the start date",
                            "Say 'I graduate in December 2026 and can start work in February 2027.'"))
    return out


# --- 10. judge packet ------------------------------------------------------------------------------------

def evidence_inventory_md(master: dict[str, Any]) -> str:
    """Generated from master.json on every run: every project's evidence lines, every Experience bullet with its
    anchors, the supported skills and the unsupported skills. The judge treats it as the complete record."""
    L = ["## EVIDENCE INVENTORY (generated from master.json; complete record of what Jay can claim)", ""]
    L.append("Anything in this inventory is verified evidence. A claim on the page that matches it is NOT a fabrication.")
    L.append("")
    L.append("### Experience (frozen wording; evidence anchors give the measured facts behind each number)")
    for e in master.get("experience", []):
        L.append(f"- **{e.get('role')} | {e.get('organization')}** ({e.get('dates')})")
        for b in e.get("bullets", []):
            L.append(f"  - {b}")
        if e.get("evidence_anchors"):
            L.append(f"  - Anchors: {e['evidence_anchors']}")
    L.append("")
    L.append("### Projects")
    for pid, p in master.get("projects", {}).items():
        L.append(f"#### {p.get('name')} ({p.get('context', '')}, {p.get('date', '')})")
        L.append(f"Tech: {', '.join(p.get('tech', []))}")
        for ev in p.get("evidence", []):
            L.append(f"- {ev}")
        if p.get("boundaries"):
            L.append(f"- Boundaries (do not claim): {p['boundaries']}")
        L.append("")
    sp = master.get("skills", {}).get("supported_pool", {})
    L.append("### Supported skills (Jay can back each one)")
    for cat, vals in sp.items():
        L.append(f"- {cat}: {', '.join(vals)}")
    L.append(f"- Scope rules: " + "; ".join(f"{k}: {v}" for k, v in master.get("skills", {}).get("scope_rules", {}).items()))
    L.append("")
    L.append("### Unsupported skills and claims (never claimed; a page that shows one is a defect)")
    L.append("- " + ", ".join(master.get("never_supported_terms", [])))
    L.append("- " + "; ".join(master.get("unsupported_claims", [])))
    return "\n".join(L) + "\n"


def write_judge_packet(out_dir: Path, plan: dict[str, Any], master: dict[str, Any], raw_jd: str, names: dict[str, str], report: dict[str, Any]) -> None:
    out_dir = Path(out_dir)
    app = plan.get("application", {})
    pdfs = [p for p in out_dir.glob("*.pdf") if "Cover_Letter" not in p.name and p.name != "build_resume.pdf"] or [p for p in out_dir.glob("build_resume.pdf")]
    resume = extract_pdftotext(pdfs[0]) if pdfs else ""
    letter = "".join(p.read_text(encoding="utf-8") for p in out_dir.glob("*_Cover_Letter.txt"))
    notes = [f"- {b.get('type')}: {b.get('reason', '')} (\"{str(b.get('requirement', ''))[:160]}\")" for b in report.get("eligibility_blockers", [])]
    flag = bool(master.get("experience_variants_enabled")) or bool(plan.get("_v342_exp_variants_test"))
    parts = [f"# JUDGE PACKET: {app.get('company', '')} | {app.get('role', '')}", "",
             f"Pipeline {PIPELINE_VERSION}; file key {names.get('key', '')}; experience_variants_enabled={'true' if flag else 'false'} "
             f"({'score the Experience section too' if flag else 'do not score Experience wording'}).", "",
             "## ELIGIBILITY NOTES (shown to Jay; never a document defect)", *(notes or ["- none"]), "",
             evidence_inventory_md(master),
             "## JOB POSTING", "", raw_jd.strip(), "",
             "## RESUME (PDF text)", "", "```text", resume.strip(), "```", "",
             "## COVER LETTER", "", "```text", letter.strip(), "```", ""]
    (out_dir / "judge_packet.md").write_text("\n".join(parts), encoding="utf-8")


# --- 11. Experience variant bank (off by default) -------------------------------------------------------

_V342_STOP = {"a", "an", "the", "and", "or", "of", "to", "for", "with", "in", "on", "by", "into", "from", "that", "this", "each", "its", "their", "as", "at", "plus",
              "while", "using", "which", "who", "so", "it", "them", "both", "also"}


def _v342_tokens(s: str) -> list[str]:
    return re.findall(r"[a-z0-9][a-z0-9+#.\-/]*[a-z0-9+#]|[a-z0-9]", str(s).lower().replace("$\\sim$", "~"))


def experience_variant_problems(original: str, variant: str, master: dict[str, Any]) -> list[str]:
    """Same facts, numbers and tools; only emphasis and word order change."""
    probs = []
    num = lambda s: sorted(re.findall(r"\d[\d,.]*\+?%?", s))
    if num(original) != num(variant):
        probs.append(f"numbers differ: {num(original)} vs {num(variant)}")
    pool = [x for vals in master["skills"]["supported_pool"].values() for x in vals] + \
           ["CrossRef API", "Tesseract", "Qwen3-VL 8B", "Qwen3.5-35B", "OCR/LLM vision", "EC2", "RDS", "VPC", "WebSocket", "Redis", "PostgreSQL", "Docker Compose", "WebRTC", "Pandas", "NumPy", "MySQL"]
    tools = lambda s: sorted({t for t in pool if len(t) > 1 and re.search(r"(?<![\w])" + re.escape(t) + r"(?![\w])", s)})
    if tools(original) != tools(variant):
        probs.append(f"tools differ: {tools(original)} vs {tools(variant)}")
    if original.split()[0] != variant.split()[0]:
        probs.append("opening verb changed")
    o = [w for w in _v342_tokens(original) if w not in _V342_STOP]
    v = [w for w in _v342_tokens(variant) if w not in _V342_STOP]
    stem = lambda w: re.sub(r"(ing|ed|es|s)$", "", w) if len(w) > 4 else w
    os_, vs_ = {stem(w) for w in o}, {stem(w) for w in v}
    new = sorted(vs_ - os_)
    lost = sorted(os_ - vs_)
    if len(new) > 2 or len(lost) > 2:
        probs.append(f"wording changes facts: new {new}, lost {lost}")
    return probs


def select_experience_variants(plan: dict[str, Any], master: dict[str, Any], test_mode: bool = False) -> list[dict[str, Any]]:
    """At most one variant per bullet, picked when its emphasis fits the posting's themes; the original is the default.
    Live runs use only variants Jay approved; test mode also tries the proposed ones."""
    vec = plan.get("_jd_theme_vector") or {}
    allowed = ("approved", "proposed") if test_mode else ("approved",)
    picks = []
    for e in (master.get("experience_variants") or {}).get("bullets", []):
        best, best_s = None, 0.0
        for v in e.get("variants", []):
            if v.get("status", "proposed") not in allowed:
                continue
            s = sum(vec.get(t, 0.0) for t in v.get("suits_themes", []))
            if s > best_s + 1e-9:
                best, best_s = v, s
        if best is not None and best_s >= 0.12:
            picks.append({"bullet_id": e["id"], "variant_id": best["id"], "original": e["original"], "text": best["text"], "score": round(best_s, 3)})
    return picks


def experience_variants_stage(plan: dict[str, Any], master: dict[str, Any], template_text: str, generated: str):
    """Swap the picked Experience bullets into the page. The byte check then compares against the template with the
    same swaps, so nothing else in Experience can change; bullet counts per job never change."""
    test_mode = bool(plan.get("_v342_exp_variants_test"))
    picks = select_experience_variants(plan, master, test_mode=test_mode)
    exp_template, used = template_text, []
    for p in picks:
        orig_tex = _v342_template_bullet(template_text, p["original"])
        if not orig_tex or orig_tex not in generated:
            continue
        probs = experience_variant_problems(p["original"], p["text"], master)
        if probs:
            continue
        new_tex = _v342_tex_text(p["text"])
        generated = generated.replace(orig_tex, new_tex, 1)
        exp_template = exp_template.replace(orig_tex, new_tex, 1)
        used.append({k: p[k] for k in ("bullet_id", "variant_id", "score")})
        plan.setdefault("_v342_exp_swaps", []).append({"original": p["original"], "text": p["text"]})
    return generated, exp_template, {"enabled": bool(master.get("experience_variants_enabled")), "test_mode": test_mode, "used": used}


def _v342_template_bullet(template_text: str, original: str) -> str | None:
    """The template's own LaTeX for an Experience bullet (matching on letters and digits only)."""
    key = re.sub(r"[^a-z0-9]", "", original.lower())
    for line in template_text.splitlines():
        s = line.strip()
        if s.startswith("\\item "):
            body = s[len("\\item "):]
            plain = re.sub(r"\$\\sim\$", "~", body).replace("\\%", "%").replace("\\&", "&")
            if re.sub(r"[^a-z0-9]", "", plain.lower()) == key:
                return body
    return None


def _v342_tex_text(text: str) -> str:
    t = text.replace("\\", "\\textbackslash{}").replace("%", "\\%").replace("&", "\\&").replace("#", "\\#").replace("_", "\\_")
    return t.replace("~", "$\\sim$")



_validate_pdf_v341 = validate_pdf


def validate_pdf(pdf_path, generated_tex, plan, master, display_order, ordered_bullets, warnings=None, bank_mode=True, pdf=None, lines=None):
    """Experience integrity with variants on: the page must equal master's Experience with exactly the checked swaps."""
    out = _validate_pdf_v341(pdf_path, generated_tex, plan, master, display_order, ordered_bullets, warnings=warnings, bank_mode=bank_mode, pdf=pdf, lines=lines)
    swaps = plan.get("_v342_exp_swaps") or []
    if not swaps:
        return out
    sw = {normalize_fixed_text(x["original"]): normalize_fixed_text(x["text"]) for x in swaps}
    canonical = [sw.get(normalize_fixed_text(b), normalize_fixed_text(b)) for role in master["experience"] for b in role["bullets"]]
    keep = []
    for f in out:
        if f.get("type") == "experience_integrity" and f.get("measured") == canonical:
            continue
        keep.append(f)
    return keep



# ===========================================================================
# v3.4.3 layer (2026-10-15)
#  1. Closing: a build/improve responsibility only, applicant as the actor, the proof that matches it, <= 30 words.
#  2. Skills: frameworks / libraries that are off-role for the posting leave the Skills line; each line is ordered
#     by posting relevance.  3. AI coding tools: only those the posting names.  4. Project headings may add a
#     posting-named technology master lists for that project.  5. "all 80 tests".  6. Agentic / ML-infrastructure
#     postings that ask for distributed systems keep LedgerFlow.  7. No job title -> stop.  8. Tracker rows update
#     only on an exact Company + Role match.  9. "Bachelor's + N years or Master's + M years" -> one note.
# 10. AI/ML only in preferred lines -> AI/ML Skills line shows only page-backed terms.  11 / 19. Hook rules.
# 12. "data classification" (governance) is not ML.  13. Posting-named supported skills are never trimmed.
# 14. Generic method phrases map to evidence.  15. No "..".  16. Job-board widget lines are removed.
# 17. New-grad layout.  18. GoingOnce / Fraud bank bullets.  Experience variants A-H approved.
# ===========================================================================
PIPELINE_VERSION = "v3.4.3"


def numeric_tokens(text: str) -> list[str]:
    """A digit glued to a letter is part of a name ("F1", "Qwen3", "EC2"), not a number the bullet states."""
    return re.findall(r"(?<![A-Za-z0-9_.])\$?\d[\d,]*(?:\.\d+)?(?:%|\+)?", text)


# --- 16. job-board widget lines --------------------------------------------------------------------------

_V343_WIDGET = re.compile(r"^\s*(?:let'?s strengthen your resume.*|\d+\s*out of\s*\d+\s*keywords? matched.*|improve my match|"
                          r"\d*\s*(?:low|medium|fair|good|high|strong|great|excellent|top)\s+match|match score:?\s*\d+%?|"
                          r"apply with (?:your )?(?:profile|resume)|show (?:more|less)|save job|easy apply)\s*$", re.I)
_clean_jd_text_v342 = clean_jd_text


def clean_jd_text(text: str) -> str:
    s = "\n".join(l for l in str(text).splitlines() if not _V343_WIDGET.match(l.replace("’", "'")))
    s = re.sub(r"(?im)^\s*let'?s strengthen your resume\s*\d*\s*out of\s*\d+\s*keywords? matched[^\n]*$", "", s)
    return _clean_jd_text_v342(s)


# --- 7. no job title -> stop -----------------------------------------------------------------------------

_V343_ALLOW_NO_TITLE = "--regression-allow-missing-title"
_V343_FLAGS = {"allow_missing_title": False}
if _V343_ALLOW_NO_TITLE in sys.argv:   # test-only: legacy fixtures saved without a title line (see 3_validation/manifest.json)
    sys.argv.remove(_V343_ALLOW_NO_TITLE)
    _V343_FLAGS["allow_missing_title"] = True


def _v343_norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode("ascii").casefold()
    s = s.replace("&", " and ")
    return " ".join(re.findall(r"[a-z0-9+#]+", s))


def title_missing(role: str, raw_jd: str) -> bool:
    """The posting must show the job title: a placeholder role, or a role that does not appear in the pasted
    posting (the model filled it in), stops the run with "stop: paste the job title line"."""
    if role_is_placeholder(role) or not str(role or "").strip():
        return True
    r, j = _v343_norm(role), _v343_norm(raw_jd)
    return bool(r) and f" {r} " not in f" {j} "


_early_skip_check_v342 = early_skip_check


def early_skip_check(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str):
    blockers, gate = _early_skip_check_v342(raw_plan, master, raw_jd)
    app = raw_plan.setdefault("application", {})
    if not _V343_FLAGS["allow_missing_title"] and title_missing(str(app.get("role", "")), raw_jd):
        gate["skip_reasons"] = [{"type": "no_title", "reason": "paste the job title line"}]
        app.pop("force", None)   # force never builds a package without a title
        raw_plan["_v343_no_title"] = True
    return blockers, gate


_skip_verdict_v342 = skip_verdict


def skip_verdict(report: dict[str, Any]) -> str:
    rs = report.get("skip_reasons", []) or []
    if any(x.get("type") == "no_title" for x in rs):
        return "stop: paste the job title line"
    return _skip_verdict_v342(report)


# --- 9. "Bachelor's + N years or Master's + M years" -> one note -------------------------------------------

_V343_DEGREE_YEARS = re.compile(r"bachelor'?s?[^.\n]{0,120}?(\d{1,2})\s*\+?\s*(?:or more\s+)?years?[^.\n]{0,80}?\bor\b[^.\n]{0,40}?master'?s?[^.\n]{0,80}?(\d{1,2})\s*\+?\s*(?:or more\s+)?years?", re.I)
_V343_DEGREE_YEARS_R = re.compile(r"master'?s?[^.\n]{0,120}?(\d{1,2})\s*\+?\s*(?:or more\s+)?years?[^.\n]{0,80}?\bor\b[^.\n]{0,40}?bachelor'?s?[^.\n]{0,80}?(\d{1,2})\s*\+?\s*(?:or more\s+)?years?", re.I)
_V343_JAY_YEARS = 2   # HeinOnline, Thesis, Data Maven and Go Digital add up to about 2 years


def degree_years_alternatives(raw: str) -> dict[str, Any] | None:
    for line in str(raw).splitlines():
        m = _V343_DEGREE_YEARS.search(line)
        if m:
            return {"line": line.strip(), "span": m.span(), "bachelors": int(m.group(1)), "masters": int(m.group(2))}
        m = _V343_DEGREE_YEARS_R.search(line)
        if m:
            return {"line": line.strip(), "span": m.span(), "bachelors": int(m.group(2)), "masters": int(m.group(1))}
    return None


def _v343_masters_only(raw: str, alt: dict[str, Any]) -> str:
    """The text the older year checks read: the alternative line becomes its Master's option, which Jay is on."""
    return str(raw).replace(alt["line"], f"Master's degree with {alt['masters']}+ years of relevant work experience")


_gating_assessment_v342 = gating_assessment


def gating_assessment(plan: dict[str, Any], master: dict[str, Any], blockers: list[dict[str, str]]) -> dict[str, Any]:
    if _v347_on("years_range_v349") and not plan.get("_v349_years"):   # v3.4.9a fix 2: a years range is read by its minimum
        raw0 = str(plan.get("_raw_jd_text", ""))
        plan["_raw_jd_text"] = v349_years_view(raw0)
        plan["_v349_years"] = True
        try:
            g = gating_assessment(plan, master, blockers)
        finally:
            plan["_raw_jd_text"] = raw0
            plan.pop("_v349_years", None)
        return v349_fit_blocker(v349_years_filter(g), blockers)
    if _v347_on("sql_parse") and any(isinstance(r, dict) and r.get("v347b_sql") for r in plan.get("jd_requirements") or []):
        keep = plan["jd_requirements"]   # v3.4.7b B3: the added SQL term changes coverage only, never the Fit caps
        plan["jd_requirements"] = [r for r in keep if not (isinstance(r, dict) and r.get("v347b_sql"))]
        try:
            return gating_assessment(plan, master, blockers)
        finally:
            plan["jd_requirements"] = keep
    raw = str(plan.get("_raw_jd_text", ""))
    alt = degree_years_alternatives(raw)
    if not alt:
        return v348b_gating(_gating_assessment_v342(plan, master, blockers))
    plan["_raw_jd_text"] = _v343_masters_only(raw, alt)
    saved = plan.get("jd_requirements")
    if isinstance(saved, list):
        plan["jd_requirements"] = [r for r in saved if not (isinstance(r, dict) and re.match(r"\d+\+ years of experience", str(r.get("term", ""))))]
    try:
        g = _gating_assessment_v342(plan, master, blockers)
    finally:
        plan["_raw_jd_text"] = raw
        if isinstance(saved, list):
            plan["jd_requirements"] = saved
    years_types = ("experience_years", "note_experience_years", "note_seniority_gap")
    g["warnings"] = [w for w in g.get("warnings", []) if w.get("type") not in years_types]
    g["skip_reasons"] = [x for x in g.get("skip_reasons", []) if x.get("type") != "seniority_gap"]
    b, mm = alt["bachelors"], alt["masters"]
    meets_m = _V343_JAY_YEARS >= mm
    meets_b = _V343_JAY_YEARS >= b
    reason = (f"Posting accepts a Bachelor's with {b}+ years or a Master's with {mm}+ years. Jay's Master's (conferred February 2027) with about "
              f"{_V343_JAY_YEARS} years of professional experience {'meets' if meets_m else 'does not meet'} the Master's option; "
              f"the Bachelor's option ({b}+ years) is {'met' if meets_b else 'not met'}.")
    g["warnings"].append({"type": "note_experience_years", "reason": reason})
    plan["_v343_degree_years"] = dict(alt, meets_masters=meets_m, meets_bachelors=meets_b)
    if not meets_m and not meets_b:
        cap = "Low" if min(b, mm) >= 5 else "Medium"
        if g.get("fit_cap") in (None, "High") or (g.get("fit_cap") == "Medium" and cap == "Low"):
            g["fit_cap"] = cap
    return v348b_gating(g)


# --- Experience variants (approved; relaxed check) ---------------------------------------------------------

def _v343_exp_job(original: str, master: dict[str, Any]) -> dict[str, Any] | None:
    key = normalize_fixed_text(original)
    for role in master.get("experience", []):
        if any(normalize_fixed_text(b) == key for b in role.get("bullets", [])):
            return role
    return None


def experience_variant_problems(original: str, variant: str, master: dict[str, Any]) -> list[str]:
    """v3.4.3 (Jay approved 2026-10-15): a variant may drop facts but never adds one. Its numbers and tools are a
    subset of the original's; at most 2 content words (4-letter stems) are new to that job's bullets and anchors.
    The opening verb may change (checked on the page: no other bullet may start with it); line count is checked
    by bank_check and on the page."""
    probs = []
    num = lambda s: set(re.findall(r"(?<![A-Za-z])\d[\d,.]*\+?%?", s.replace("k+", "")))
    extra_n = num(variant) - num(original)
    if extra_n:
        probs.append(f"new numbers: {sorted(extra_n)}")
    pool = [x for vals in master["skills"]["supported_pool"].values() for x in vals] + \
           ["CrossRef API", "Tesseract", "Qwen3-VL 8B", "Qwen3.5-35B", "OCR/LLM vision", "EC2", "RDS", "VPC", "WebSocket", "Redis", "PostgreSQL", "Docker Compose", "WebRTC", "Pandas", "NumPy", "MySQL"]
    tools = lambda s: {t for t in pool if len(t) > 1 and re.search(r"(?<![\w])" + re.escape(t) + r"(?![\w])", s)}
    extra_t = tools(variant) - tools(original)
    if extra_t:
        probs.append(f"new tools: {sorted(extra_t)}")
    job = _v343_exp_job(original, master)
    ctx = original + " " + (" ".join(job.get("bullets", [])) + " " + str(job.get("evidence_anchors", "")) if job else "")
    st = lambda s: {w[:4] for w in _v342_tokens(str(s).replace("/", " ")) if w not in _V342_STOP and re.match(r"[a-z]", w)}
    new = sorted(st(variant) - st(ctx))
    if len(new) > 2:
        probs.append(f"new wording beyond the job's facts: {new}")
    return probs


def select_experience_variants(plan: dict[str, Any], master: dict[str, Any], test_mode: bool = False) -> list[dict[str, Any]]:
    """One variant per bullet at most: "always" variants (D) whenever no themed one fits; themed ones when the
    posting's theme weight for them is >= 0.12."""
    vec = plan.get("_jd_theme_vector") or {}
    allowed = ("approved", "proposed") if test_mode else ("approved",)
    picks = []
    for e in (master.get("experience_variants") or {}).get("bullets", []):
        best, best_s = None, -1.0
        for v in e.get("variants", []):
            if v.get("status", "proposed") not in allowed:
                continue
            s = sum(vec.get(t, 0.0) for t in v.get("suits_themes", []))
            ok = s >= 0.12 or v.get("always")
            if ok and (s > best_s + 1e-9):
                best, best_s = v, s
        if best is not None:
            picks.append({"bullet_id": e["id"], "variant_id": best["id"], "original": e["original"], "text": best["text"], "score": round(max(best_s, 0.0), 3)})
    return picks


def experience_variants_stage(plan: dict[str, Any], master: dict[str, Any], template_text: str, generated: str):
    test_mode = bool(plan.get("_v342_exp_variants_test"))
    picks = select_experience_variants(plan, master, test_mode=test_mode)
    omitted = {normalize_fixed_text(b) for b in plan.get("_v343_omitted_exp_bullets", [])}
    page_starts = [str(bullet_text(b)).split()[0].lower() for vals in (plan.get("bullets") or {}).values() for b in vals if str(bullet_text(b)).split()]
    page_starts += [b.split()[0].lower() for r in master["experience"] for b in r["bullets"] if normalize_fixed_text(b) not in omitted]
    exp_template, used, skipped = template_text, [], []
    for p in picks:
        orig_tex = _v342_template_bullet(template_text, p["original"])
        if not orig_tex or orig_tex not in generated:
            continue
        probs = experience_variant_problems(p["original"], p["text"], master)
        v0, o0 = p["text"].split()[0].lower(), p["original"].split()[0].lower()
        if v0 != o0 and page_starts.count(v0) > 0:
            probs.append(f"opening verb {p['text'].split()[0]} already starts another bullet on the page")
        if probs:
            skipped.append({"variant_id": p["variant_id"], "problems": probs})
            continue
        new_tex = _v342_tex_text(p["text"])
        generated = generated.replace(orig_tex, new_tex, 1)
        exp_template = exp_template.replace(orig_tex, new_tex, 1)
        page_starts.append(v0)
        used.append({k: p[k] for k in ("bullet_id", "variant_id", "score")})
        plan.setdefault("_v342_exp_swaps", []).append({"original": p["original"], "text": p["text"]})
    return generated, exp_template, {"enabled": bool(master.get("experience_variants_enabled")), "test_mode": test_mode, "used": used, "skipped": skipped}



# --- 12. "data classification" in the governance sense is not ML ------------------------------------------

_V343_GOV_TERM = re.compile(r"\bdata classifications?\b|\bclassif(?:y|ying|ies) (?:the |all |sensitive |company |customer )?data\b|\bclassification of (?:the |sensitive |company |customer )?data\b", re.I)
_V343_GOV_CTX = re.compile(r"\b(storage|stor(?:e|ing)|retention|polic(?:y|ies)|privacy|complian\w*|handl\w+|governance|sensitiv\w*|security|secure|management|regulat\w+|confidential\w*|labeling)\b", re.I)


def _v343_mask_gov(raw: str) -> str:
    out = []
    for line in str(raw).splitlines():
        if _V343_GOV_TERM.search(line) and _V343_GOV_CTX.search(_V343_GOV_TERM.sub(" ", line)):
            line = _V343_GOV_TERM.sub("data handling", line)
        out.append(line)
    return "\n".join(out)


_parse_jd_requirements_v342 = parse_jd_requirements


def parse_jd_requirements(raw_jd: str, master: dict[str, Any], title: str = "") -> list[dict[str, Any]]:
    return _parse_jd_requirements_v342(_v343_mask_gov(raw_jd), master, title)


_jd_theme_vector_v342 = jd_theme_vector


_V343_THEME_MASK = [(re.compile(r"\bspark\b"), "kindle"),                       # "We spark listeners' imaginations" (verb, lower case)
                    (re.compile(r"\bmetrics examination\b", re.I), "issue checks"),   # 14. debugging methods, not model evaluation
                    (re.compile(r"\blog analysis\b", re.I), "log checks")]


def _v343_theme_text(raw: str) -> str:
    lines = []
    for line in str(raw).splitlines():
        if _V343_GOV_TERM.search(line) and _V343_GOV_CTX.search(_V343_GOV_TERM.sub(" ", line)):
            continue   # 12. a governance line ("handle data classification, storage, and management per policy") carries no theme
        for rx, rep in _V343_THEME_MASK:
            line = rx.sub(rep, line)
        lines.append(line)
    return "\n".join(lines)


def jd_theme_vector(raw_jd: str, title: str = "", company: str = "") -> dict[str, float]:
    return _jd_theme_vector_v342(_v343_theme_text(raw_jd), title, company)


# --- 3 / 13. posting-named terms: AI coding tools only as named; "AWS" names the AWS entry ------------------

_V332_AI_TOOLS = re.compile(_V332_AI_TOOLS.pattern + r"|ai tools? for (?:development|developer|coding|engineering)(?: productivity)?|ai (?:developer|productivity) tools?", re.I)
_V343_TOOL_NAMED = {"Cursor": re.compile(r"\bcursor\b", re.I), "GitHub Copilot": re.compile(r"\bcopilot\b", re.I), "Claude Code": re.compile(r"\bclaude code\b", re.I)}


def _v343_ai_tools_line(raw: str) -> bool:
    return any(_V332_AI_TOOLS.search(l) for l, _w, _h in _v33_role_lines(raw))


def _v343_ai_tool_ok(tool: str, raw: str) -> bool:
    """Cursor and GitHub Copilot only when the posting names them; Claude Code when it names it or asks for AI coding tools."""
    rx = _V343_TOOL_NAMED.get(tool)
    if rx is None:
        return True
    if rx.search(raw):
        return True
    return tool == "Claude Code" and _v343_ai_tools_line(raw)


_jd_named_pool_terms_v342 = jd_named_pool_terms


def jd_named_pool_terms(raw_jd: str, master: dict[str, Any]) -> list[str]:
    raw = _v343_mask_gov(raw_jd)
    found = _jd_named_pool_terms_v342(raw, master)
    found = [x for x in found if _v343_ai_tool_ok(x, raw)]
    if _v343_ai_tools_line(raw) and "Claude Code" not in found:
        found.append("Claude Code")
    pool = master["skills"]["supported_pool"].get("tools_platforms", [])
    if re.search(r"\bAWS\b|\bamazon web services\b", raw, re.I) and "AWS (EC2/RDS)" in pool and "AWS (EC2/RDS)" not in found:
        found.append("AWS (EC2/RDS)")
    return found


_high_priority_skill_displays_v342 = _high_priority_skill_displays


def _high_priority_skill_displays(plan: dict[str, Any], master: dict[str, Any]) -> list[str]:
    raw = str(plan.get("_raw_jd_text", ""))
    return [x for x in _high_priority_skill_displays_v342(plan, master) if _v343_ai_tool_ok(x, raw)]


_jd_gap_terms_v342 = jd_gap_terms


def jd_gap_terms(raw_jd: str, master: dict[str, Any]) -> list[str]:
    """"We spark listeners' imaginations" is a verb: Spark / PySpark count only capitalized."""
    out = _jd_gap_terms_v342(raw_jd, master)
    return [t for t in out if str(t) not in ("Spark", "PySpark") or re.search(r"\b(?:Py)?Spark\b", raw_jd)]


# --- 14. generic method phrases map to evidence --------------------------------------------------------------

_V343_METHOD_MAP = [
    (re.compile(r"\blog analysis\b|\banaly[sz]\w* logs\b", re.I), "Debugging", "log analysis"),
    (re.compile(r"\bmetrics examination\b|\bexamin\w+ metrics\b|\bmetrics? (?:analysis|review)\b", re.I), "Application Monitoring", "metrics examination"),
    (re.compile(r"\btestability\b", re.I), "Unit Testing", "testability"),
    (re.compile(r"\bdata (?:handling|classification)?,?\s*(?:and )?storage,? and management\b|\bdata storage(?: and management)?\b|\bdata management\b", re.I), "PostgreSQL", "storage, and management"),
]


def _v343_method_requirements(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    reqs = raw_plan.get("jd_requirements")
    if not isinstance(reqs, list) or not raw_plan.get("_jd_requirements_auto"):
        return
    have = {str(r.get("term", "")).casefold() for r in reqs if isinstance(r, dict)} | {str(a).casefold() for r in reqs if isinstance(r, dict) for a in r.get("aliases", []) or []}
    added = []
    cap = min(25, int(master.get("ats_rules", {}).get("jd_requirements_max", 25)))
    for line, _w, hedged in _v33_role_lines(raw_jd):
        for rx, term, verb in _V343_METHOD_MAP:
            m = rx.search(line)
            if not m or term.casefold() in have or len(reqs) >= cap:
                continue
            if not master_supports_requirement(term, [term], master):
                continue
            sec = _V33_LINE_MODE.get(line, 1.0)
            reqs.append({"term": term, "verbatim": m.group(0), "aliases": [term], "priority": "medium" if hedged or sec < 1.0 else "high", "supported": True, "_v343_method": True})
            have.add(term.casefold()); added.append({"term": term, "phrase": m.group(0)})
    if len(reqs) < cap and re.search(r"\bAWS\b", raw_jd) and "aws" not in have and "aws (ec2/rds)" not in have and master_supports_requirement("AWS (EC2/RDS)", ["AWS"], master):
        line = next((l for l in raw_jd.splitlines() if re.search(r"\bAWS\b", l)), "")
        hedged = bool(re.search(r"prefer|plus|nice|bonus", line, re.I)) or any(h for l, _w, h in _v33_role_lines(raw_jd) if l == line.strip())
        reqs.append({"term": "AWS (EC2/RDS)", "verbatim": "AWS", "aliases": ["AWS", "AWS (EC2/RDS)"], "priority": "medium" if hedged else "high", "supported": True})
        added.append({"term": "AWS (EC2/RDS)", "phrase": "AWS"})
    if added:
        order = {"must": 0, "high": 1, "medium": 2}
        reqs.sort(key=lambda r: order.get(str(r.get("priority", "")).lower(), 2) if isinstance(r, dict) else 3)
        raw_plan["_v343_method_terms"] = added


# --- 17. new-grad detection / 6. ML-infrastructure postings -----------------------------------------------

_V343_NEWGRAD = re.compile(r"\bnew[- ]grad(?:uate)?s?\b|\bnew college grad\w*\b|\buniversity grad(?:uate)?s?\b|\bearly[- ]careers?\b|\brecent (?:college |university )?grad(?:uate)?s?\b|"
                           r"\b(?:20(?:26|27))\s+(?:graduat\w+|grads?|class)\b|\bclass of 20(?:26|27)\b|\bgraduating (?:in |class of )?20(?:26|27)\b", re.I)
_V343_DATA_FINTECH = re.compile(r"\bdata (?:engineer\w*|analy\w+|scien\w+|platform|pipelines?)\b|\betl\b|\bfintech\b|\bfinancial (?:services|technology|data|systems)\b|\bbank\w*\b|"
                                r"\bpayments?\b|\bledger\w*\b|\bcomplian\w+\b|\baudit\w*\b|\banti[- ]money|\baml\b|\bkyc\b|\brisk\b|\btransactions? data\b", re.I)


def is_new_grad(title: str, raw_jd: str) -> bool:
    """Only an explicit new-grad / early-career posting (title or text); plain "entry level" does not count."""
    if re.search(r"\bgraduate\b", title or "", re.I) and not re.search(r"\b(?:graduate|grad) (?:student|research|assistant|intern)", title or "", re.I):
        return True
    return bool(_V343_NEWGRAD.search(title or "")) or bool(_V343_NEWGRAD.search(str(raw_jd)))


def keep_go_digital(plan: dict[str, Any], raw_jd: str) -> bool:
    """v3.4.5 (item 7): Go Digital stays only for data-engineering / analytics / fintech / compliance postings or
    postings that ask to analyze data (Macy's); ML engineering postings drop it."""
    title = str(plan.get("application", {}).get("role", ""))
    vec = plan.get("_jd_theme_vector") or {}
    if re.search(r"\bdata (?:engineer\w*|analy\w+|scien\w+|platform|pipelines?|warehous\w*)\b|\betl\b|\banalyt\w*|\bfintech\b|\bfinanc\w*|\bcomplian\w*|\baudit\w*|\bpayments?\b|\bbusiness intelligence\b", title, re.I):
        return True
    if re.search(r"\bmachine learning\b|\bml\b|\bai\b|\bdeep learning\b|\bllms?\b|\bcomputer vision\b|\bnlp\b|\bapplied scien\w+", title, re.I):
        return False   # ML engineering postings drop it
    if str(plan.get("role_family", "")) == "data_engineering" or vec.get("data_eng", 0) >= 0.15 or vec.get("payments", 0) >= 0.15:
        return True
    lines = _v342_role_text(raw_jd, hedged=False)
    if any(re.search(r"\bcomplian\w+|\baudit\w*|\bfintech\b|\bfinancial (?:services|data|systems)\b", l, re.I) for l in lines):
        return True
    return any(re.search(r"\banaly[sz]\w*\b[^.;]{0,40}\bdata\b|\bdata[^.;]{0,20}\banaly[sz]\w*|\banalytics\b|\b(?:identify|spot|find)\w* (?:\w+ ){0,2}trends\b", l, re.I) for l in lines)


_V343_MLINFRA = re.compile(r"\bml infra\w*|\bmachine learning infra\w*|\bml platform\b|\bml systems?\b|\bmlops\b|\bagentic\b|\bai agents?\b|\bagents?\b|\bllms?\b|\bmodel (?:training|serving|experiments?)\b|\bexperiment\w*\b", re.I)


def _v343_mlinfra_distributed(raw_plan: dict[str, Any], raw_jd: str) -> bool:
    title = str(raw_plan.get("application", {}).get("role", ""))
    lines = _v342_role_text(raw_jd, hedged=False)
    ml = bool(re.search(r"\bml\b|machine learning|\bai\b|agent|llm", title, re.I)) or sum(1 for l in lines if _V343_MLINFRA.search(l)) >= 2
    dist = any(re.search(r"\bdistributed (?:systems?|computing|backend|services)\b", l, re.I) for l in lines)
    return ml and dist


_apply_auto_plan_fields_v342 = apply_auto_plan_fields


def apply_auto_plan_fields(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    _apply_auto_plan_fields_v342(raw_plan, master, raw_jd)
    _v343_method_requirements(raw_plan, master, raw_jd)
    title = str(raw_plan.get("application", {}).get("role", ""))
    raw_plan["_v343_new_grad"] = is_new_grad(title, raw_jd)
    if raw_plan["_v343_new_grad"]:
        raw_plan["_v343_keep_godigital"] = keep_go_digital(raw_plan, raw_jd)
    raw_plan["_v343_ai_required"] = bool(_V342_AI_RX.search(title)) or any(_V342_AI_RX.search(l) for l in _v342_role_text(raw_jd, hedged=False))


# --- 6. agentic / ML-infrastructure postings that ask for distributed systems keep LedgerFlow ----------------

_V343_DIST_PROJECTS = ("ledgerflow", "launchops")
_apply_auto_ranking_v342b = apply_auto_ranking


def apply_auto_ranking(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    auto = raw_plan.get("ranking") == "auto"
    try:
        snap = deepcopy(raw_plan) if auto else None
        _apply_auto_ranking_v342b(raw_plan, master, raw_jd)
        if auto:
            _v345_check_llm_override(raw_plan, master, raw_jd, snap)
        _v345_goingonce_third(raw_plan, master, raw_jd, auto)
        if not auto or raw_plan.get("_v342_lead_language", {}).get("moved") or not _v343_mlinfra_distributed(raw_plan, raw_jd):
            return
        ranking = list(raw_plan.get("ranking") or [])
        if len(ranking) < 3 or any(p in ranking for p in _V343_DIST_PROJECTS) or "ledgerflow" not in master.get("projects", {}):
            return
        protected = {ranking[0]}
        if raw_plan.get("_v342_llm_reliability"):
            protected.add("tailor_pipeline")
        scores = dict(raw_plan.get("project_scores") or {})
        cands = [p for p in ranking[1:] if p not in protected]
        if not cands:
            return
        out = min(cands, key=lambda p: scores.get(p, 0.0))
        scores["ledgerflow"] = round(scores.get(out, 0.0) + 0.01, 3)
        keep = [p for p in ranking if p != out]
        new = [keep[0]] + sorted(keep[1:] + ["ledgerflow"], key=lambda p: -scores.get(p, 0.0))
        if scores["ledgerflow"] > scores.get(new[0], 0.0):
            scores["ledgerflow"] = round(scores.get(new[0], 0.0) - 0.01, 3)
            new = [keep[0]] + sorted(keep[1:] + ["ledgerflow"], key=lambda p: -scores.get(p, 0.0))
        raw_plan["project_scores"] = scores
        raw_plan["ranking"] = new
        raw_plan["_v343_distributed"] = {"replaced": out}
        _V345_CTX.setdefault("override", {})["displaced_v343"] = out
        if not str(raw_plan.get("ranking_override_reason", "")).strip():
            raw_plan["ranking_override_reason"] = "v3.4.3 agentic / ML-infrastructure posting that asks for distributed systems: LedgerFlow's distributed backend evidence replaces " + out
    finally:
        if auto and _v347_on("ranker_v349"):
            v349_rank(raw_plan, master)   # v3.4.9a fix 5: one scoring path decides the order
        if auto and _v347_on(V349C_MUST_FLAG):
            v349c_must_rank(raw_plan, master, raw_jd)   # v3.4.9c run 6: a must-have framework / language with one primary project leads


# --- 2 / 3 / 10 / 13. Technical Skills ------------------------------------------------------------------

_V343_AI_FRAMEWORKS = ("LangGraph", "Streamlit")
_V343_PYDANTIC = ("Pydantic",)
_V343_DATA_LIBS = ("Pandas", "NumPy", "scikit-learn", "PyTorch", "PyTorch Geometric", "NetworkX", "TensorFlow", "Matplotlib", "Librosa", "CatBoost")
_V343_AI_TOOL_NAMES = ("Cursor", "GitHub Copilot", "Claude Code")


def _v343_data_role(plan: dict[str, Any]) -> bool:
    fam = str(plan.get("role_family", ""))
    vec = plan.get("_jd_theme_vector") or {}
    return fam in ("data_science_ml", "data_engineering") or (vec.get("ml_dl", 0) + vec.get("data_science", 0) + vec.get("data_eng", 0)) >= 0.12 or _is_data_ml_role(plan)


def _v343_page_bullets(plan: dict[str, Any]) -> str:
    return " ".join(bullet_text(b) for vals in (plan.get("bullets") or {}).values() for b in vals)


def _v343_off_role(x: str, plan: dict[str, Any], raw: str, bullets: str, jd_keys: set[str], required: set[str]) -> bool:
    if x.casefold() in jd_keys or x.casefold() in required or boundary_contains_plural(raw, x):
        return False
    named_in_bullet = bool(re.search(r"(?<![\w])" + re.escape(x) + r"(?![\w])", bullets))
    if x in _V343_PYDANTIC:
        return not named_in_bullet
    if x in _V343_AI_FRAMEWORKS:
        return not plan.get("_v343_ai_required") and not _V342_AI_RX.search(str(plan.get("application", {}).get("role", "")))
    if x in _V343_DATA_LIBS:
        return not _v343_data_role(plan) and not named_in_bullet
    return False


_build_skill_states_v342 = build_skill_states


def build_skill_states(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    states = _build_skill_states_v342(plan, master)
    if not states:
        return states
    raw = str(plan.get("_raw_jd_text", ""))
    sk = globals().get("_V33_SKILLS") or {}
    jd_named = [str(x) for x in sk.get("jd_named", [])]
    jd_keys = {x.casefold() for x in jd_named} | {str(x).casefold() for x in plan.get("_jd_pool_terms", []) or []}
    required = {str(x).casefold() for x in states[0].get("required_ats_terms", [])}
    header = resolved_project_header_tech(master, plan["ranking"], plan)
    closure = {str(x) for x in selected_technology_skills(plan, master, header)}
    bullets = _v343_page_bullets(plan)
    vec = plan.get("_jd_theme_vector") or {}
    log = plan.setdefault("_v343_skills", {})
    # 3. AI coding tools only as the posting names them
    for st in states:
        for cat, vals in st.get("skills", {}).items():
            for x in list(vals):
                if x in _V343_AI_TOOL_NAMES and not _v343_ai_tool_ok(x, raw) and x not in closure:
                    vals.remove(x); log.setdefault("ai_tools_removed", []).append(x)
        st["matched_tools"] = [x for x in st.get("matched_tools", []) if not (x in _V343_AI_TOOL_NAMES and not _v343_ai_tool_ok(x, raw) and x not in closure)]
    # 10. AI/ML named only in preferred lines: the AI/ML line keeps only terms the page backs
    if not plan.get("_v343_ai_required") and not _V342_AI_RX.search(str(plan.get("application", {}).get("role", ""))):
        page = (bullets + " " + " ".join(x for v in header.values() for x in v)).casefold()
        pe = master["skills"].get("page_evidence", {})
        def backed(x):
            return x in closure or x.casefold() in page or any(str(p).casefold() in page for p in (pe.get(x) or []) if x not in ("Machine Learning", "Model Evaluation", "Deep Learning"))
        for st in states:
            vals = st.get("skills", {}).get("ai_ml")
            if vals:
                kept = [x for x in vals if backed(x) and x not in ("Machine Learning", "Model Evaluation") or x in closure]
                if kept != vals:
                    log["ai_ml_unbacked_removed"] = sorted(set(vals) - set(kept))
                st["skills"]["ai_ml"] = kept
    # 2. off-role frameworks / libraries leave the Skills section (the heading may still show them)
    off_removed = set()
    for st in states:
        vals = st.get("skills", {}).get("frameworks_libraries")
        if not vals:
            continue
        off = [x for x in vals if _v343_off_role(x, plan, raw, bullets, jd_keys, required)]
        for x in sorted(off, key=lambda y: _v33_relevance(y, vec)):
            if len(vals) > 3:
                vals.remove(x); off_removed.add(x)
                continue
            # the line keeps 3 entries: swap in an on-role framework the page already shows, about as wide
            have = {y.casefold() for v in st.get("skills", {}).values() for y in v}
            pool = [y for y in master["skills"]["supported_pool"].get("frameworks_libraries", []) if y in closure or re.search(r"(?<![\w])" + re.escape(y) + r"(?![\w])", bullets)]
            subs = [y for y in pool if y.casefold() not in have and len(y) <= len(x) + 2
                    and not _v343_off_role(y, plan, raw, bullets, jd_keys, required)]   # only a framework the page shows
            if not subs:
                if len(vals) > 1:   # nothing on the page to swap in: a shorter line beats an off-role entry
                    vals.remove(x); off_removed.add(x)
                continue
            sub = max(subs, key=lambda y: (y in closure, y.casefold() in jd_keys, _v33_relevance(y, vec)))
            vals[vals.index(x)] = sub; off_removed.add(x)
            log.setdefault("off_role_swapped", []).append(f"{x} -> {sub}")
    if off_removed:
        log["off_role_removed"] = sorted(off_removed)
        plan["_v343_offrole_removed"] = sorted(off_removed)
    # 13. posting-named supported skills stay in every state; a filler of the same line makes room
    cat_of = lambda x: supported_skill_category(x, master)
    catmap = {"languages_databases": "languages_databases", "frameworks_libraries": "frameworks_libraries", "ai_ml_data": "ai_ml", "software_engineering": "software_engineering", "tools_platforms": "tools"}
    protect = [x for x in jd_named if cat_of(x) and x not in off_removed and _v343_ai_tool_ok(x, raw)]
    for st in states:
        allv = {y.casefold() for v in st.get("skills", {}).values() for y in v}
        for x in protect:
            if x.casefold() in allv:
                continue
            c = catmap.get(cat_of(x), cat_of(x))
            if c not in st.get("skills", {}):
                continue
            if c == "ai_ml" and not st["skills"].get("ai_ml"):
                continue
            vals = st["skills"][c]
            filler = [y for y in vals if y.casefold() not in jd_keys and y.casefold() not in required and y not in closure]
            if not filler:
                continue   # a swap only: the line never grows, so the fitter's budget is unchanged
            vals.remove(min(filler, key=lambda y: _v33_relevance(y, vec)))
            vals.append(x); allv.add(x.casefold())
            if c == "tools":
                st.setdefault("matched_tools", []).append(x)
            log.setdefault("jd_named_protected", []).append(x)
    # order every line by posting relevance: required, posting-named, heading, then by theme relevance
    jd_order = {k: i for i, k in enumerate(x.casefold() for x in jd_named)}
    def rank(x):
        k = x.casefold()
        return (0 if k in required else (1 if k in jd_order else (2 if x in closure else 3)), jd_order.get(k, 99), -_v33_relevance(x, vec))
    for st in states:
        for c, vals in st.get("skills", {}).items():
            if c == "tools":
                continue
            vals[:] = sorted(vals, key=rank)
    if log.get("jd_named_protected"):
        log["jd_named_protected"] = sorted(set(log["jd_named_protected"]))
    if __import__("os").environ.get("V343_DEBUG_STATES"):
        Path(__import__("os").environ["V343_DEBUG_STATES"]).write_text(json.dumps({"log": log, "states": states}, indent=1, default=str), encoding="utf-8")
    return states


_validate_selected_technology_skill_coverage_v342 = validate_selected_technology_skill_coverage


def validate_selected_technology_skill_coverage(plan, master, resolved_skills, project_tech):
    """An off-role framework may stay in its project heading without a Skills entry (v3.4.3 change 2)."""
    out = _validate_selected_technology_skill_coverage_v342(plan, master, resolved_skills, project_tech)
    off = set(plan.get("_v343_offrole_removed") or []) | {x for x in _V343_AI_TOOL_NAMES if not _v343_ai_tool_ok(x, str(plan.get("_raw_jd_text", "")))}
    if _v347_on("skills_dedupe_v349"):   # v3.4.9a fix 9: a vendor API its project heading shows is not repeated in Tools
        off |= set(plan.get("_v349_api_removed") or [])
    keep = []
    for f in out:
        m = f.get("measured")
        if isinstance(m, list):
            m = [x for x in m if x not in off]
            if not m:
                continue
            f = dict(f, measured=m)
        keep.append(f)
    return keep


# --- 4. project headings may add a posting-named technology the project lists in master ------------------

_adapt_header_tech_v342 = adapt_header_tech


def adapt_header_tech(pid: str, vals: list[str], plan: dict[str, Any], master: dict[str, Any]) -> list[str]:
    out = _adapt_header_tech_v342(pid, vals, plan, master)
    raw = str(plan.get("_raw_jd_text", ""))
    if not raw:
        return out
    tech = master["projects"][pid].get("tech", [])
    jdkeys = {str(x).casefold() for x in plan.get("_jd_pool_terms", []) or []}
    have = " | ".join(out).casefold()
    adds = []
    for t in tech:
        name = t
        if t == "HTML/CSS/JavaScript":
            name = "JavaScript"
        if name.casefold() in have or name.casefold() not in jdkeys:
            continue
        if name == "Java" or (len(name) <= 2):
            continue
        adds.append(name)
    if not adds:
        return out
    canon = len(", ".join(out))
    off = set(plan.get("_v343_offrole_removed") or [])
    for name in adds[:1]:
        spots = [i for i in range(len(out) - 1, 0, -1) if out[i].casefold() not in jdkeys]
        spots.sort(key=lambda i: (0 if out[i] in off else 1, -i))
        if not spots:
            break
        i = spots[0]
        cand = out[:i] + [name] + out[i + 1:]
        if len(", ".join(cand)) <= canon + 4:
            out = cand
            plan.setdefault("_v343_heading_added", {})[pid] = name
    return out


_jd_omission_warnings_v342 = jd_omission_warnings


def jd_omission_warnings(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[dict[str, Any]]:
    """12. "data classification" in the governance sense is not the Classification skill."""
    out = _jd_omission_warnings_v342(plan, master, raw_jd)
    masked = _v343_mask_gov(raw_jd)
    def short_lowercase_only(x):   # "wherever you may go" never names Go; a 1-2 letter term must match its case
        return len(x) <= 2 and not re.search(r"(?<![\w+#.])" + re.escape(x) + r"(?![\w+#])", raw_jd)
    return [w for w in out if not (str(w.get("target", "")) == "Classification" and not boundary_contains_plural(masked, "Classification"))
            and not short_lowercase_only(str(w.get("target", "")))]


# --- 1. closing --------------------------------------------------------------------------------------------

_V343_BUILD = re.compile(r"^(?:design|build|develop|create|implement|write|code|program|test|deploy|integrate|monitor|improve|enhance|maintain|optimi[sz]e|"
                         r"ship|deliver|automate|debug|troubleshoot|scale|architect|engineer|prototype|extend|modernize|migrate|refactor|launch)\b", re.I)
_V343_GROWTH = re.compile(r"\b(?:work(?:ing)? alongside|alongside|mentor\w*|gain\w* (?:exposure|experience|knowledge)|exposure to|grow\w*|learn\w*|own(?:ing)? features|"
                          r"interview\w*|career|develop (?:your|their|new) skills|intimate knowledge|apply (?:computer science|engineering)|"
                          r"collaborat\w+|participat\w+|partner\w*|agile engineering team|as part of a team)\b", re.I)
_V343_PROOF_MAP = [
    ("permissions", re.compile(r"\bpermission\w*|\baccess control|\bauthori[sz]\w+|\bauthenticat\w+|\bsso\b|\boauth|\broles?\b|\bsecurity\b|\bidentity\b", re.I),
     ["launchops.server_checks"]),
    ("interactive", re.compile(r"\binteractive\b|\breal[- ]time\b|\blive\b|\bviewers?\b|\bcreators?\b|\bengag\w+|\b(?:user|interactive|viewer|live) experiences?\b|\buser[- ]facing|\bcustomer[- ]facing", re.I),
     ["launchops.live_quiz", "goingonce.interface_tests", "exp.thesis_backend"]),
    ("scale", re.compile(r"\bscal(?:e|able|ability|ing)\b|\bconcurren\w+|\bmillions?\b|\bhigh[- ](?:traffic|volume|throughput)|\bthroughput\b|\bdistributed\b|\brobust\b|\bfault[- ]toleran\w+", re.I),
     ["ledger.overspend_test", "ledger.chaos_runs", "ledger.kubernetes_demo", "launchops.live_quiz"]),
    ("integrations", re.compile(r"\bintegrat\w+|\bapis?\b|\bthird[- ]party|\bwebhooks?|\bevents?\b|\bsystem[- ]to[- ]system|\bmessag\w+", re.I),
     ["ledger.exactly_once_effect", "ledger.architecture"]),
    ("embedded", re.compile(r"\bembedded\b|\bfirmware\b|\bdevices?\b|\bkernel\b|\boperating systems?\b|\brobot\w*|\bhardware\b|\blow[- ]level\b|\bplatform software\b|\bsilicon\b|\bota\b", re.I),
     ["pintos.syscalls", "pintos.tests", "pintos.processes", "exp.thesis_backend"]),
    ("testing", re.compile(r"\btest\w*|\bquality\b|\bci\b|\bcontinuous integration|\breliab\w+|\bdefects?\b|\bverif\w+", re.I),
     ["ledger.ci", "ripple.tests", "tailor.tests", "pintos.tests", "ripple.claude_code_dev"]),
]
_V343_CLOSE_MAX = 30


def _v343_gerund_base(w: str) -> str:
    lw = w.lower()
    if not lw.endswith("ing") or len(lw) < 6:
        return w
    for cand in (lw[:-3], lw[:-3] + "e", lw[:-4]):
        if _V343_BUILD.match(cand) and _V343_BUILD.match(cand).end() == len(cand):
            return cand
    return w


def _v343_extra_responsibilities(raw_jd: str) -> list[str]:
    """Build / improve lines outside a "you will" list: gerund bullets ("Designing and building permissioning services")
    and "participation in design, coding, and testing"."""
    out = []
    for line, _w, _h in _v33_role_lines(raw_jd):
        t = re.sub(r"^[-*•·▪◦‣>\d.)\s]+", "", line).strip()
        m = re.match(r"(?i)(?:hands[- ]on )?(?:participation|involvement) in ((?:design|coding|testing|development|implementation)(?:,? (?:and )?(?:design|coding|testing|development|implementation))+)", t)
        if m:
            out.append("work on " + m.group(1).lower())
            continue
        toks = t.split(" ")
        if not toks or not toks[0].lower().endswith("ing"):
            continue
        conv = []
        for i, tok in enumerate(toks[:6]):
            core = tok.rstrip(",")
            if i == 0 or toks[i - 1].lower() in ("and", "or") or toks[i - 1].endswith(","):
                b = _v343_gerund_base(core)
                if b != core:
                    toks[i] = b + tok[len(core):]
                    conv.append(i)
        if 0 not in conv:
            continue
        text = " ".join(toks)
        text = re.split(r",?\s+(?:such as|e\.g\.|eg\.|including|like|for example)\s+|\s+\(|:\s", text)[0].strip().rstrip(".")
        text = re.sub(r"\bour\b", "its", re.sub(r"\byour\b", "the", text, flags=re.I), flags=re.I)
        if re.search(r"\d|\b(?:we|us|you)\b", text, re.I) or not 4 <= len(text.split()) <= 16:
            continue
        out.append(text[0].lower() + text[1:])
    return out


_V343_WORK_ON = re.compile(r"^work on (?:design|coding|testing|development|implementation)\b", re.I)


def closing_responsibilities(raw_jd: str, plan: dict[str, Any], master: dict[str, Any]) -> list[str]:
    out = []
    for r in list(dict.fromkeys(top_responsibilities(raw_jd) + _v343_extra_responsibilities(raw_jd))):
        if not (_V343_BUILD.match(r) or _V343_WORK_ON.match(r)) or _V343_GROWTH.search(r) or _v342_unsupported_in(r, plan, master):
            continue
        out.append(r)
    return out


def _v343_proof_candidates(plan: dict[str, Any], master: dict[str, Any]) -> dict[str, str]:
    """Closing proofs Jay can cite: evidence on the page from a project the letter names, plus Experience."""
    proofs = master.get("cover_letter_bank", {}).get("closing_proofs", {})
    letter_proj = (plan.get("_v33_letter") or {}).get("projects") or (plan.get("ranking") or [])[:2]
    cands = {}
    for pid in dict.fromkeys(letter_proj):
        for _vid, eid in _v33_selected_evidence(plan, pid):
            if proofs.get(eid):
                cands[eid] = proofs[eid]
        if pid == "launchops" and plan.get("_v342_permissions_jd") and proofs.get("launchops.server_checks"):
            if any(e == "launchops.server_checks" for _v, e in _v33_selected_evidence(plan, pid)):
                cands["launchops.server_checks"] = proofs["launchops.server_checks"]
    for k in ("exp.thesis_backend",):
        if proofs.get(k):
            cands[k] = proofs[k]
    return cands


def _v343_pick_proof(resp: str, plan: dict[str, Any], master: dict[str, Any], raw_jd: str, letter: str) -> tuple[str, str, str]:
    cands = _v343_proof_candidates(plan, master)
    low = letter.lower()
    def said(eid):
        p = cands[eid]
        words = {w for w in re.findall(r"[a-z]{5,}", p.lower()) if w not in _V342_STOP}
        names = " ".join(str(x.get("resume_title", {}).get("name", "")) for x in master["projects"].values()).lower()
        words = {w for w in words if w not in names}
        return words and sum(1 for w in words if w in low) / len(words) >= 0.75
    # responsibility text decides first; the posting's overall flags break ties
    order = [c for c in _V343_PROOF_MAP if c[1].search(resp)]
    flags = {"permissions": plan.get("_v342_permissions_jd"), "embedded": plan.get("_v342_systems_jd"), "testing": plan.get("_v342_testing_jd")}
    order += [c for c in _V343_PROOF_MAP if c not in order and flags.get(c[0])]
    for kind, _rx, eids in order:
        for eid in eids:
            if eid in cands and not said(eid):
                return kind, eid, cands[eid]
        for eid in eids:
            if eid in cands:
                return kind, eid, cands[eid]
    return "", "", ""


def _v343_words(s: str) -> int:
    return len(re.findall(r"\S+", s))


def _v343_closing(plan: dict[str, Any], master: dict[str, Any], raw_jd: str, company_ref: str, letter: str = "") -> tuple[str, dict[str, Any]]:
    """I want to <build/improve responsibility> at <company>, building on <matching proof>.  (<= 30 words, applicant acts)"""
    resps = closing_responsibilities(raw_jd, plan, master)
    low = letter.lower()
    resps = [r for r in resps if r.lower() not in low] or resps
    info: dict[str, Any] = {"rule": "v3.4.3"}
    for resp in resps[:3]:
        kind, eid, proof = _v343_pick_proof(resp, plan, master, raw_jd, letter)
        if not proof:
            continue
        r = resp[0].lower() + resp[1:] if resp[:2] != resp[:2].upper() else resp
        cuts = [r]
        for sep in (r" that ", r" for ", r" with ", r" across ", r" in "):
            head = re.split(sep, r)[0].strip().rstrip(",")
            if 3 <= len(head.split()) < len(r.split()) and head not in cuts:
                cuts.append(head)
        cuts = [cuts[0]] + sorted(cuts[1:], key=lambda x: -len(x.split()))
        opts = [(c, proof) for c in cuts] + [(c, proof.split(",")[0]) for c in cuts]
        s = ""
        for c, p in opts:
            s = f"I want to {c} at {company_ref}, building on {p}."
            if _v343_words(s) <= _V343_CLOSE_MAX:
                r = c
                break
        if _v343_words(s) <= _V343_CLOSE_MAX:
            info.update({"responsibility": resp, "proof": eid, "proof_kind": kind, "_resp": r, "_proof": proof, "_company": company_ref})
            return s, info
    # nothing qualifies: the role-family closing (the applicant is the actor)
    kind, eid, proof = _v343_pick_proof(" ".join(_v342_role_text(raw_jd)[:6]), plan, master, raw_jd, letter)
    if not proof:
        kind, eid, proof = _v343_pick_proof("testing", plan, master, raw_jd, letter)
    fam = str(plan.get("role_family", ""))
    tmpl = master.get("cover_letter_bank", {}).get("family_closing", {}).get(fam, "build dependable, well-tested software with the team at {company}")
    poss = company_ref + ("'" if company_ref.endswith("s") else "'s")
    what = tmpl.replace("{company}'s", poss).replace("{company}", company_ref)
    s = f"I want to {what}, building on {proof}." if proof else f"I want to {what}."
    if _v343_words(s) > _V343_CLOSE_MAX and proof:
        s = f"I want to {what}, building on {proof.split(',')[0]}."
    info.update({"responsibility": "", "proof": eid, "proof_kind": kind, "family": True})
    return s, info


_v342_closing = _v343_closing   # compose_bank_cover_letter (v3.4.2) calls it by name


_V343_DOTS = re.compile(r"(?<=[A-Za-z])\.\.(?!\.)")


def _v343_fix_dots(s: str) -> str:
    return _V343_DOTS.sub(".", s)


_V343_FIRST_PERSON = re.compile(r"\b(?:I|me|my|I'm|I am)\b")
_compose_bank_cover_letter_v342 = compose_bank_cover_letter


def compose_bank_cover_letter(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[dict[str, Any]]:
    failures = _compose_bank_cover_letter_v342(plan, master, raw_jd)
    paras = [_v343_fix_dots(p) for p in plan.get("cover_letter_paragraphs") or []]
    info = plan.get("_v342_closing") or {}
    closing = str(info.get("text") or "")
    if paras and closing and closing in paras[-1] and info.get("_resp"):
        rules = master.get("cover_letter_rules", {})
        cap = int(rules.get("words_per_paragraph", {}).get(str(len(paras)), [0, 140])[1])
        total_cap = min(200, int((rules.get("words_total") or [0, 200])[1]))
        def fits(c):
            last = paras[-1].replace(closing, c)
            return _letter_words(last) <= cap and sum(_letter_words(p) for p in paras[:-1]) + _letter_words(last) <= total_cap
        if not fits(closing):
            r, pr, co = info["_resp"], info["_proof"], info["_company"]
            cuts = []
            for sep in (r" that ", r" for ", r" with ", r" across ", r" in "):
                head = re.split(sep, r)[0].strip().rstrip(",")
                if 3 <= len(head.split()) < len(r.split()):
                    cuts.append(head)
            cuts = sorted(set(cuts), key=lambda x: -len(x.split()))
            pr2 = pr.split(",")[0]
            cands = [f"I want to {r} at {co}, building on {pr2}."] + [f"I want to {c2} at {co}, building on {p2}." for c2 in cuts for p2 in (pr, pr2)]
            for c in cands:
                if fits(c):
                    paras[-1] = paras[-1].replace(closing, c)
                    plan["_v342_closing"] = dict(info, text=c, shortened=True)
                    break
    plan["cover_letter_paragraphs"] = paras
    cl = plan.get("cover_letter") if isinstance(plan.get("cover_letter"), dict) else {}
    hook = re.sub(r"\s+", " ", str(cl.get("hook", "") or "")).strip()
    if hook and not _V343_FIRST_PERSON.search(hook):
        failures.append(fail("cover_letter_hook_describes_team", "cover_letter.hook", hook, "says what draws you to the work (I / me / my), not a description of the team",
                             "Rewrite the hook as what draws you to this work, naming the company's product or domain in the posting's words."))
    return failures


def hook_specific(hook: str, plan: dict[str, Any], raw_jd: str) -> bool:
    """19. The hook names the company's product / domain in the posting's words: it shares a content word with the
    job title or the first responsibility line. v3.4.7a: the test itself lives in v347_hook_detail (unchanged), so
    report.json can say why it failed (A6)."""
    return v347_hook_detail(hook, plan, raw_jd)["ok"]


_build_cover_letter_v342 = build_cover_letter


def build_cover_letter(plan: dict[str, Any], master: dict[str, Any], out_dir: Path, names: dict[str, str]):
    if v349c_plain_on() and isinstance(plan.get("_v349c_plain"), dict) and plan["_v349c_plain"].get("paragraphs"):   # v3.4.9c run 8
        plan["cover_letter_paragraphs"] = list(plan["_v349c_plain"]["paragraphs"])
        plan["_v342_closing"] = dict(plan["_v349c_plain"]["closing_info"])
    elif not v349c_plain_on() and isinstance(plan.get("_v349c_out"), dict) and plan["_v349c_out"].get("paragraphs"):   # fix1: run 7 letters
        plan["cover_letter_paragraphs"] = list(plan["_v349c_out"]["paragraphs"])
        plan["_v342_closing"] = dict(plan["_v349c_out"]["closing_info"])
    fails, info = _build_cover_letter_v342(plan, master, out_dir, names)
    cl = plan.get("cover_letter") if isinstance(plan.get("cover_letter"), dict) else {}
    hook = str(cl.get("hook", "") or "")
    if isinstance(info, dict):
        info["hook_specific"] = hook_specific(hook, plan, str(plan.get("_raw_jd_text", ""))) if hook else None
        if info["hook_specific"] is False and _v347_on("hook_reason_fix"):   # v3.4.7a A6: which test failed
            info["hook_specific_reason"] = v347_hook_reason(v347_hook_detail(hook, plan, str(plan.get("_raw_jd_text", ""))))
        if info["hook_specific"] and _v347_on("hook_fallback_v348"):   # v3.4.8a H: the verdict came from the fallback
            _d = v347_hook_detail(hook, plan, str(plan.get("_raw_jd_text", "")))
            if _d.get("role_text_source"):
                info["hook_specific_basis_v348"] = {k: _d[k] for k in ("role_text_source", "role_summary", "title_words", "shared_words") if k in _d}
        if isinstance(plan.get("_v342_closing"), dict):
            info["closing"] = plan["_v342_closing"]
        if v349c_plain_on() and isinstance(plan.get("_v349c_plain"), dict):   # v3.4.9c run 8
            info["plain_v349c"] = {k: v for k, v in plan["_v349c_plain"].items() if k not in ("before", "paragraphs", "closing_info")}
    for p in Path(out_dir).glob("*_Cover_Letter.txt"):
        t = p.read_text(encoding="utf-8")
        if _V343_DOTS.search(t):
            p.write_text(_v343_fix_dots(t), encoding="utf-8")
    v349b_note_letter(plan, out_dir)   # v3.4.9b: Letter fit steps compare letters
    return fails, info


_build_outreach_v342 = build_outreach


def build_outreach(plan: dict[str, Any], master: dict[str, Any], display_order: list[str]):
    out = _build_outreach_v342(plan, master, display_order)
    if isinstance(out, dict):
        for k, v in list(out.items()):
            if isinstance(v, str):
                out[k] = _v343_fix_dots(v)
    return out


_top_responsibilities_v342 = top_responsibilities
_V343_RESP_LEAD = re.compile(r"(?i)^\s*(?:as an? [^,]{3,60},\s*)?(?:you will|you'll|you’ll|in this role,? you will|you will be|your responsibilities)(?: be)?\s*(?:\.\.\.|…|:|-)?\s*$")


def top_responsibilities(raw_jd: str) -> list[str]:
    """"As a Software Development Engineer, you will..." introduces the responsibilities list like a heading."""
    lines = ["Responsibilities:" if _V343_RESP_LEAD.match(l) else l for l in str(raw_jd).splitlines()]
    return _top_responsibilities_v342("\n".join(lines))


# --- 17. new-grad layout ---------------------------------------------------------------------------------
# Education first, then Experience, Projects, Technical Skills, Certifications & Awards; the Go Digital internship
# is left off unless the role is data / fintech / compliance; projects #2 and #3 get a third slot when the bank has a
# third distinct evidence item for them (3/3/3, else 3/3/2, 3/2/3, 3/2/2). Everything else is unchanged.

_V343_LAYOUT: dict[str, Any] = {}
_V343_SECTIONS = ["EXPERIENCE", "PERSONAL PROJECTS", "EDUCATION", "TECHNICAL SKILLS", "CERTIFICATIONS \\& AWARDS"]
_V343_GODIGITAL_TEX = re.compile(r"\s*\\rolegap\s*\\noindent\\textbf\{[^{}]*\}\s*\$\|\$\s*Go Digital Technology Consulting.*?\\end\{itemize\}", re.S)


def _v343_set_layout(raw_plan: dict[str, Any], master: dict[str, Any]) -> None:
    ng = master.get("layout_rules", {}).get("new_grad") or {}
    _V343_LAYOUT.clear()
    if not raw_plan.get("_v343_new_grad") or not ng:
        return
    omit = str(ng.get("omit_experience", ""))
    drop = bool(omit) and not raw_plan.get("_v343_keep_godigital")
    _V343_LAYOUT.update({"new_grad": True, "order": list(ng.get("section_order", [])), "omit": omit if drop else "",
                         "slots_by_rank": list(ng.get("project_slots_by_rank", [3, 3, 3]))})
    master.setdefault("_v343_full", {"experience": deepcopy(master["experience"]), "section_order": list(master["layout_rules"]["section_order"])})
    master["layout_rules"]["section_order"] = list(ng.get("section_order", master["layout_rules"]["section_order"]))
    if drop:
        gone = [r for r in master["experience"] if r.get("organization") == omit]
        master["experience"] = [r for r in master["experience"] if r.get("organization") != omit]
        raw_plan["_v343_omitted_exp_bullets"] = [b for r in gone for b in r.get("bullets", [])]
    raw_plan["_v343_layout"] = {"new_grad": True, "section_order": _V343_LAYOUT["order"], "omitted_experience": _V343_LAYOUT["omit"] or None}


_apply_auto_plan_fields_v343a = apply_auto_plan_fields


def apply_auto_plan_fields(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    v349b_layout(master)   # v3.4.9b: Letter / Skills layout for the switched-on format flags
    if _v347_on("jd_sections_v349") and raw_plan.get("jd_requirements_extra"):   # v3.4.9a fix 1: no extra from an example / context line
        keep = []
        for x in raw_plan.get("jd_requirements_extra") or []:
            v = str((x or {}).get("verbatim") or (x or {}).get("term") or "") if isinstance(x, dict) else ""
            if v and v349_context_only(v, raw_jd):
                raw_plan.setdefault("_extra_rejected", []).append({"term": str(x.get("term", "")), "verbatim": v, "reason": "example or context line, not a requirement"})
                continue
            keep.append(x)
        raw_plan["jd_requirements_extra"] = keep
    _apply_auto_plan_fields_v343a(raw_plan, master, raw_jd)
    if _v347_on("or_groups"):   # v3.4.7b B2: a covered OR-group's other members are never hard gaps
        _v347b_or_hard_gaps(raw_plan, master, raw_jd)
    _v343_set_layout(raw_plan, master)
    _v345_set_coursework(raw_plan, master, raw_jd)


def _v343_slots(ranking: list[str]) -> dict[str, int]:
    by_rank = _V343_LAYOUT.get("slots_now") or [3, 2, 2]
    return v349b_slot_counts({pid: by_rank[i] if i < len(by_rank) else 2 for i, pid in enumerate(ranking)})   # v3.4.9b trim


_V343_SLOT_PLANS = ([3, 3, 3], [3, 3, 2], [3, 2, 3], [3, 2, 2])
_v341_project_combos_v342 = _v341_project_combos


def _v341_project_combos(pool, k, need_headline, scores, keep, pairs, force):
    pool = v349b_restrict_pool(pool)   # v3.4.9b: Letter page attempts only
    pool, need_headline = v349_llm_pool(pool, need_headline)   # v3.4.9a fix 4
    want = _V343_LAYOUT.get("k_by_pid") or {}
    pid = str(pool[0]["id"]).split(".")[0] if pool else ""
    return _v341_project_combos_v342(pool, v349b_slot_counts({pid: want.get(pid, k)})[pid], need_headline, scores, keep, pairs, force)


_auto_bank_selection_v342 = auto_bank_selection


def auto_bank_selection(raw_plan, bank, pairs=None):
    ranking = list(raw_plan.get("ranking") or [])
    if not _V343_LAYOUT.get("new_grad") or len(ranking) != 3 or not _V343_LAYOUT.get("omit"):
        _V343_LAYOUT["slots_now"] = [3, 2, 2]
        return _auto_bank_selection_v342(raw_plan, bank, pairs)
    # 3/3/3 only when the Go Digital lines make room (the page keeps its one-page buffer)
    tried = []
    for plan_slots in _V343_SLOT_PLANS[_V343_FLAGS.get("slot_start", 0):]:
        _V343_LAYOUT["slots_now"] = plan_slots
        _V343_LAYOUT["k_by_pid"] = {pid: plan_slots[i] for i, pid in enumerate(ranking)}
        try:
            sel, info = _auto_bank_selection_v342(raw_plan, bank, pairs)
        finally:
            _V343_LAYOUT["k_by_pid"] = {}
        tried.append(plan_slots)
        if sel is not None:
            raw_plan["_v343_slots_by_rank"] = plan_slots
            info["v343_slots_by_rank"] = plan_slots
            if len(tried) > 1:
                info["v343_slots_tried"] = tried
            return sel, info
    _V343_LAYOUT["slots_now"] = [3, 2, 2]
    return None, {"reason": "no slot combination", "v343_slots_tried": tried}


_expand_bank_plan_v342 = expand_bank_plan


def expand_bank_plan(raw_plan: dict[str, Any], bank: dict[str, Any], master: dict[str, Any]):
    expanded, failures = _expand_bank_plan_v342(raw_plan, bank, master)
    ranking = expanded.get("ranking") or raw_plan.get("ranking") or []
    if len(ranking) != 3:
        return expanded, failures
    want = _v343_slots(ranking)
    if "_v343_slots_by_rank" in raw_plan:
        expanded["_v343_slots_by_rank"] = raw_plan["_v343_slots_by_rank"]
    slot_map = expanded.get("_v341_slots") or {}
    keep = []
    for f in failures:
        if f.get("type") == "bullet_allocation" and f.get("target") in want and len(slot_map.get(f["target"], [])) == want[f["target"]]:
            continue
        keep.append(f)
    for pid, n in want.items():
        if pid in slot_map and len(slot_map[pid]) != n and not any(f.get("type") == "bullet_allocation" and f.get("target") == pid for f in keep):
            keep.append(fail("bullet_allocation", pid, len(slot_map[pid]), n, f"Fill exactly {n} bullet slots for {pid}."))
    return expanded, keep


_validate_plan_v3_1_v342 = validate_plan_v3_1


def validate_plan_v3_1(plan: dict[str, Any], master: dict[str, Any], raw_jd: str, warnings: list[dict[str, Any]] | None = None, free_text_mode: bool = False) -> list[dict[str, Any]]:
    out = _validate_plan_v3_1_v342(plan, master, raw_jd, warnings=warnings, free_text_mode=free_text_mode)
    if v349c_plain_on() and isinstance(plan.get("_v349c_plain"), dict):   # v3.4.9c run 8: plain three-paragraph letters
        out = out + v349c_plain_structure(plan, master)
    lines = plan.get("_v341_lines")
    ranking = plan.get("ranking") or []
    if not isinstance(lines, dict) or len(ranking) != 3:
        return out
    want = _v343_slots(ranking)
    return [f for f in out if not (f.get("type") == "bullet_allocation" and f.get("target") in want and sum(lines.get(f["target"], [])) == 2 * want[f["target"]])]


_assemble_latex_v342 = assemble_latex


def _v343_reorder(tex: str, order: list[str]) -> str:
    names = ["EXPERIENCE", "PERSONAL PROJECTS", "EDUCATION", "TECHNICAL SKILLS", "CERTIFICATIONS \\& AWARDS"]
    if v349c_page_on():   # v3.4.9c run 2 P4: no Certifications & Awards section
        names = [n for n in names if "\\section*{" + n + "}" in tex]
        order = [n for n in order if n.replace("&", "\\&") in names or n in names]
    starts = [tex.index("\\section*{" + n + "}") for n in names]
    if starts != sorted(starts):
        return tex
    end_doc = tex.rindex("\\end{document}")
    segs = {}
    for i, n in enumerate(names):
        nxt = starts[i + 1] if i + 1 < len(names) else end_doc
        end = tex.rindex("\\sectiondivider", starts[i], nxt) if i + 1 < len(names) else nxt
        segs[n] = tex[starts[i]:end]
    want = [n if n in segs else n.replace("&", "\\&") for n in order]
    if sorted(want) != sorted(names):
        return tex
    body = ""
    for i, n in enumerate(want):
        seg = segs[n]
        if i + 1 < len(want):
            if not seg.endswith("\t"):
                seg = seg.rstrip() + "\n\t"
            body += seg + "\\sectiondivider\n\t\n\t"
        else:
            body += seg
    return tex[:starts[0]] + body + tex[end_doc:]


def _v343_omit_godigital(tex: str) -> str:
    return _V343_GODIGITAL_TEX.sub("", tex, count=1)


def assemble_latex(template, skill_selector_tex, project_block, tagline_text, rolegap_pt=None):
    template = v349b_effective_template(template)   # v3.4.9b: switched-off format changes go back to the v3.4.9a template
    tex = _assemble_latex_v342(template, skill_selector_tex, project_block, tagline_text, rolegap_pt=rolegap_pt)
    tex = _v345_coursework_tex(tex)   # v3.4.5 (item 15)
    if not v348b_on():   # v3.4.8b D2 off: the v3.4.8a Education date line (v3.4.9c: also from the no-"Expected" line)
        tex = tex.replace(V348B_EDU_NEW, V348B_EDU_OLD).replace(V349C_EDU_NEW, V348B_EDU_OLD)
    if not _V343_LAYOUT.get("new_grad"):
        return tex
    if _V343_LAYOUT.get("omit"):
        tex = _v343_omit_godigital(tex)
    return _v343_reorder(tex, _V343_LAYOUT["order"])


_experience_byte_check_v342 = experience_byte_check


def experience_byte_check(template_text: str, generated_tex: str) -> list[dict[str, Any]]:
    template_text = v349b_effective_template(template_text)   # v3.4.9b
    generated_tex = v349b_strip_bold(generated_tex)   # v3.4.9b: bold spans are render-time only
    if _V343_LAYOUT.get("omit"):
        template_text = _v343_omit_godigital(template_text)
    return _experience_byte_check_v342(template_text, generated_tex)


def collect_project_bullets(pdf, lines, display_order, master):
    """v3.4.3: the project block ends at the next section heading after the last project (Education under the
    standard layout, Technical Skills under the new-grad layout)."""
    failures = []
    result: dict[str, list[list[dict[str, Any]]]] = {}
    heading_indices = []
    for pid in display_order:
        title_meta = master["projects"][pid].get("resume_title", {})
        name = title_meta.get("name") or project_title_text(master, pid)
        idx = find_line_index(lines, name)
        if idx is None:
            failures.append(fail("project_heading_missing", pid, "not found in PDF", name, "Check LaTeX assembly/project heading text."))
        else:
            heading_indices.append((pid, idx))
    if len(heading_indices) != len(display_order) or not heading_indices:
        return result, failures
    last = max(i for _p, i in heading_indices)
    heads = ("EDUCATION", "TECHNICAL SKILLS", "CERTIFICATIONS", "EXPERIENCE")
    end_idx = next((i for i in range(last + 1, len(lines)) if lines[i]["text"].strip() in heads or lines[i]["text"].strip().startswith("CERTIFICATIONS")), None)
    if end_idx is None:
        return result, failures
    for k, (pid, idx) in enumerate(heading_indices):
        end = heading_indices[k + 1][1] if k + 1 < len(heading_indices) else end_idx
        segment = [x for x in lines[idx + 1:end] if x["text"].strip()]
        heading_x0 = lines[idx]["bbox"][0]
        indented = [x for x in segment if heading_x0 + 5.0 <= x["bbox"][0] <= heading_x0 + 100.0]
        if not indented:
            result[pid] = []
            continue
        start_x0 = min(x["bbox"][0] for x in indented)
        bullets: list[list[dict[str, Any]]] = []
        current = None
        for line in indented:
            x0 = line["bbox"][0]
            if x0 <= start_x0 + 2.0:
                if current:
                    bullets.append(current)
                current = [line]
            elif current is not None and x0 <= start_x0 + 40.0:
                current.append(line)
        if current:
            bullets.append(current)
        result[pid] = bullets
    return result, failures


_validate_pdf_v342 = validate_pdf


def validate_pdf(pdf_path, generated_tex, plan, master, display_order, ordered_bullets, warnings=None, bank_mode=True, pdf=None, lines=None):
    generated_tex = v349b_strip_bold(generated_tex)   # v3.4.9b: bold spans are render-time only
    if _v347_on("letter_trims_v349b"):   # v3.4.9b: the one-line Interviewed bullet is the checked form of master's bullet
        generated_tex = generated_tex.replace(V349B_INTERVIEW_SHORT, V349B_INTERVIEW_LONG)
    if v349c_thesis_on():   # v3.4.9c run 3: the one-line mentor bullet is the checked form of master's bullet
        generated_tex = generated_tex.replace(V349C_MENTOR, V349B_INTERVIEW_LONG)
    if v349c_page_on():   # v3.4.9c run 2 P4: the Skills checks end at the page end (no Certifications & Awards heading)
        if lines is None:
            lines = extract_pdf_lines(pdf if pdf is not None else fitz.open(pdf_path))
        if find_line_index(lines, V349C_CERT_HEAD) is None:
            lines = list(lines) + [{"page": 0, "text": V349C_CERT_HEAD, "bbox": [0.0, 1e9, 0.0, 1e9]}]
    out = _validate_pdf_v342(pdf_path, generated_tex, plan, master, display_order, ordered_bullets, warnings=warnings, bank_mode=bank_mode, pdf=pdf, lines=lines)
    ranking = plan.get("ranking") or []
    if len(ranking) != 3:
        return out
    want = _v343_slots(ranking)
    return [f for f in out if not (f.get("type") == "project_slot_line_total" and f.get("target") in want and f.get("measured") == 2 * want[f["target"]])]


_v33_experience_key_v342 = _v33_experience_key


def _v33_experience_key(plan, vec, ranking):
    k = _v33_experience_key_v342(plan, vec, ranking)
    if _V343_LAYOUT.get("omit") and k == "godigital":
        return "hein"
    return k


_write_judge_packet_v342 = write_judge_packet


def write_judge_packet(out_dir: Path, plan: dict[str, Any], master: dict[str, Any], raw_jd: str, names: dict[str, str], report: dict[str, Any]) -> None:
    full = master.get("_v343_full")
    if full:
        m2 = dict(master); m2["experience"] = full["experience"]
        _write_judge_packet_v342(out_dir, plan, m2, raw_jd, names, report)
        lay = plan.get("_v343_layout") or {}
        p = Path(out_dir) / "judge_packet.md"
        txt = p.read_text(encoding="utf-8")
        note = (f"New-grad layout (v3.4.3 rule): sections ordered {' > '.join(lay.get('section_order') or [])}"
                + (f"; {lay['omitted_experience']} is left off the page on purpose (not a data / fintech / compliance role)." if lay.get("omitted_experience") else ".")
                + f" Project slots by rank: {plan.get('_v343_slots_by_rank') or [3, 2, 2]}.")
        txt = txt.replace("## ELIGIBILITY NOTES", "## LAYOUT NOTE\n" + note + "\n\n## ELIGIBILITY NOTES", 1)
        p.write_text(txt, encoding="utf-8")
        return
    _write_judge_packet_v342(out_dir, plan, master, raw_jd, names, report)


_main_v3_1_v342 = main_v3_1


def main_v3_1() -> int:
    """New-grad pages that lose their one-page buffer with a third slot on #2 / #3 are rebuilt with fewer slots."""
    argv = list(sys.argv)
    rc = _main_v3_1_v342()
    _v343_note_layout(argv)
    try:
        out_dir = Path(argv[argv.index("--out-dir") + 1])
    except (ValueError, IndexError):
        return rc
    for _ in range(len(_V343_SLOT_PLANS) - 1):
        try:
            rep = json.loads((out_dir / "report.json").read_text(encoding="utf-8"))
        except Exception:
            return rc
        slots = _V343_LAYOUT.get("slots_now") if _V343_LAYOUT.get("new_grad") else None
        if not slots or slots == [3, 2, 2] or not any(f.get("type") in ("page_count", "v33_page_buffer", "required_ats_terms_exceed_skill_budget") for f in rep.get("failures", [])):
            return rc
        _V343_FLAGS["slot_start"] = _V343_SLOT_PLANS.index(slots) + 1
        sys.argv = list(argv)
        rc = _main_v3_1_v342()
        _v343_note_layout(argv)
    return rc


def _v343_note_layout(argv: list[str]) -> None:
    """report.json records the layout used (new-grad order, omitted job, slots per rank)."""
    try:
        p = Path(argv[argv.index("--out-dir") + 1]) / "report.json"
        rep = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return
    lay = {"new_grad": bool(_V343_LAYOUT.get("new_grad")), "section_order": _V343_LAYOUT.get("order"), "omitted_experience": _V343_LAYOUT.get("omit") or None,
           "slots_by_rank": _V343_LAYOUT.get("slots_now") or [3, 2, 2]}
    if _V343_FLAGS.get("slot_start"):
        lay["slot_fallback"] = "a third slot on #2 / #3 did not fit one page with the buffer"
    rep["layout_v343"] = lay
    p.write_text(json.dumps(rep, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

# ===========================================================================
# v3.4.4 layer (2026-10-16)
#  A. Closing: never reuses a proof the letter already gives; the proof matches the claim (testing -> CI / test
#     suites, integrations -> LedgerFlow exactly-once, permissions -> LaunchOps server checks, interactive -> LaunchOps
#     live service, embedded -> Pintos / Thesis IoT, operations -> Thesis heartbeat monitor and failure response);
#     any build / improve line in the posting (rewritten with Jay as the actor) beats the role-family fallback; no
#     scale claim the evidence cannot back; <= 30 words; the connector varies (never "build ... building on"); a
#     closing that ends mid-phrase fails and falls back. The model may still set cover_letter.closing by hand.
#  C. The judge packet's evidence inventory lists every master evidence line (cover-letter evidence, approved
#     Experience variants, project evidence items, qualification facts, education, awards).
#  D. GoingOnce tests team-scoped; Pintos "Implemented"; the LLM engine's "three AI workers / 73%" bullet stays off
#     ML-infrastructure and agent postings; "operating systems in production" is not the Operating Systems skill;
#     headings keep ReactJS when a selected bullet shows React and the posting names it; "design patterns" prefers
#     LedgerFlow's outbox / idempotent-consumer bullet; preflight of required terms that appear only in Skills or a
#     heading (a bullet or approved variant that names them is preferred when master has one).
#  E. Letter experience sentence by role (code review / debugging / operations / mentorship -> Thesis review,
#     mentoring and failure response); letters <= 200 words as a reader counts them; RIPPLE wording.
#  F. Job-board widget sections removed (skill tags, H1B data, company profile, markdown widgets); informational
#     sponsorship text never creates a blocker; no ".." anywhere (letter, outreach, tracker).
#  G. Experience variant I (Agile / Scrum / code review / pull requests).  H. report.json verify_changes_v344 quotes
#     the JD line for every script change.  I. Tracker: 11 columns, Status "Applied".
# ===========================================================================
PIPELINE_VERSION = "v3.4.4"
import html as _v344_html
import os, pathlib

_V344_CTX: dict[str, Any] = {"changes": [], "jd_removed": []}


def _v344_change(change: str, jd_line: str) -> None:
    item = {"change": change, "jd_line": re.sub(r"\s+", " ", str(jd_line or "")).strip()[:240]}
    if item not in _V344_CTX["changes"]:
        _V344_CTX["changes"].append(item)


def _v344_jd_line(raw: str, rx) -> str:
    rx = re.compile(rx, re.I) if isinstance(rx, str) else rx
    for line in str(raw).splitlines():
        if rx.search(line):
            return line.strip()
    return ""


# --- F20. job-board widgets and markdown --------------------------------------------------------------------

_V344_DROP_LINE = re.compile(
    r"^\s*(?:"
    r"(?:image|svg)\s*\*\*.*"
    r"|\**\s*(?:let'?s strengthen your resume|almost there,? let'?s close the final gap).*"
    r"|\d+\s*\**\s*(?:low|fair|good|high|strong|great|excellent|top|medium)\s+match"
    r"|(?:linkedin|crunchbase|company-logo|company logo|glassdoor|twitter|facebook|instagram)"
    r"|founded in \d{4}"
    r"|\d[\d,]*\s*(?:-|–|to)\s*\d[\d,]*\+?\s+employees|\d[\d,]*\+?\s+employees"
    r"|.*\(data powered by [^)]*\).*"
    r"|distribution of different job fields receiving sponsorship|represents job field similar to this job"
    r")\s*$", re.I)
_V344_TAGS_HEAD = re.compile(r"^\s*(?:represents the skills you have|find out how your skills align\b.*)\s*$", re.I)
_V344_H1B_HEAD = re.compile(r"^\s*h-?1b sponsorship\s*$", re.I)
_V344_SECTION_WORDS = re.compile(r"^\s*#*\s*\**\s*(?:required|requirements?|preferred|qualifications?|responsibilities|benefits|company|about\b|skills you|education|"
                                 r"nice to have|what you|who you|minimum|basic|description|job description|the role|role)\b", re.I)


def _v344_unmarkdown(s: str) -> str:
    if re.search(r"&#x?[0-9a-f]+;|&(?:amp|nbsp|quot|lt|gt);", s, re.I):
        s = _v344_html.unescape(s).replace("\xa0", " ")
    s = re.sub(r"[ \t]*\\[ \t]*$", "", s, flags=re.M)           # markdown hard line breaks ("...us.\")
    s = re.sub(r"(?m)^(\s*)\\([-*+])\s", r"\1\2 ", s)          # escaped list markers ("\- Develop ...")
    return s


def _v344_drop_widgets(text: str) -> str:
    out, mode, removed = [], None, []
    for line in str(text).splitlines():
        t = line.strip()
        tn = t.replace("’", "'")
        if _V344_TAGS_HEAD.match(tn):
            mode = "tags"; removed.append(t); continue
        if _V344_H1B_HEAD.match(tn):
            mode = "h1b"; removed.append(t); continue
        if mode and t:
            short = len(t.split()) <= 4 and not t.endswith(".")
            info = bool(re.search(r"sponsorship|department of labor|track record|does not guarantee|job fields?|^\d+(?:\.\d+)?%$", tn, re.I))
            if not _V344_SECTION_WORDS.match(tn) and (short or (mode == "h1b" and info)):
                removed.append(t); continue
            mode = None
        elif mode and not t:
            continue
        if t and _V344_DROP_LINE.match(tn):
            removed.append(t); continue
        out.append(line)
    if removed:
        _V344_CTX["jd_removed"] = removed
    return "\n".join(out)


_clean_jd_text_v343 = clean_jd_text


def clean_jd_text(text: str) -> str:
    return _clean_jd_text_v343(_v344_drop_widgets(_v344_unmarkdown(str(text))))


_V344_SPONSOR_INFO = re.compile(r"track record of offering|does not guarantee sponsorship|data powered by|department of labor|receiving sponsorship|"
                                r"^\s*h-?1b sponsorship\s*$|sponsorship (?:data|history|statistics)", re.I)
_eligibility_blockers_v343 = eligibility_blockers


def eligibility_blockers(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, str]]:
    """Informational sponsorship text (job-board H1B data) never creates a no-sponsorship blocker; only the
    employer's own requirement text can."""
    out = _eligibility_blockers_v343(plan, master)
    out = [b for b in out if not (b.get("type") == "work_authorization_or_sponsorship" and _V344_SPONSOR_INFO.search(str(b.get("requirement", ""))))]
    if _v347_on("sponsorship_polarity"):   # v3.4.7b B1: only clearly negative employer text blocks
        out = _v347b_sponsor_blockers(out, plan, master)
    if v348b_on():   # v3.4.8b D4: graduation December 2026, start February 2027
        out = v348b_date_blockers(out, plan)
    if _v347_on("start_date_parse_v348"):   # v3.4.8c T: more start-date forms (Timing note only)
        out = v348c_start_date_note(out, plan)
    return out


# --- F21. no ".." anywhere ----------------------------------------------------------------------------------

def _v344_fix_dots_obj(o):
    if isinstance(o, str):
        return _v343_fix_dots(o)
    if isinstance(o, list):
        return [_v344_fix_dots_obj(x) for x in o]
    if isinstance(o, dict):
        return {k: _v344_fix_dots_obj(v) for k, v in o.items()}
    return o


_build_outreach_v343 = build_outreach


_V345_REFERRAL_ASK = "Would you be open to a quick chat about the team, or a referral if I seem a fit?"
_V345_ADVICE_ASK = "Would you be open to a short chat so I can get your advice on the team?"


def _v345_no_referral(o):
    if isinstance(o, str):   # any sentence that asks for a referral becomes the advice ask
        o = o.replace(_V345_REFERRAL_ASK, _V345_ADVICE_ASK)
        return re.sub(r"[^.?!]*\breferrals?\b[^.?!]*[.?!]", lambda m_: (" " if m_.group(0)[:1] == " " else "") + _V345_ADVICE_ASK, o, flags=re.I)
    if isinstance(o, list):
        return [_v345_no_referral(x) for x in o]
    if isinstance(o, dict):
        return {k: _v345_no_referral(v) for k, v in o.items()}
    return o


def build_outreach(plan: dict[str, Any], master: dict[str, Any], display_order: list[str]):
    """v3.4.5 (item 19): the UB-alum note asks for a short advice conversation about the team, never a referral
    (master outreach.sentence3_rule)."""
    out = _v345_no_referral(_v344_fix_dots_obj(_build_outreach_v343(plan, master, display_order)))
    li = out.get("linkedin") if isinstance(out, dict) and isinstance(out.get("linkedin"), dict) else None
    if li and isinstance(li.get("notes"), dict) and isinstance(li.get("notes_chars"), dict):
        li["notes_chars"] = {k: len(v) for k, v in li["notes"].items()}
    company = str(plan.get("application", {}).get("company", "")).strip()
    if li is not None and _v347_on("outreach_v348"):   # v3.4.8a O: new notes (four audiences) in notes, notes_chars and block
        _v348_outreach(li, plan, master)
    if li is not None and company_is_placeholder(company) and _v347_on("outreach_fix"):   # v3.4.7a A5
        _v347_outreach_no_company(li, company)
    if li is not None and _v347_on("outreach_v348"):   # v3.4.8a O: markdown block (after A5, so its links leave out the company)
        li["block_md"] = v348_block_md(li, company)
    return out


# --- D12. "operating systems in production" is not the Operating Systems skill ----------------------------------

_V344_OPERATING = re.compile(r"\boperat(?:e|es|ing)\s+((?:[\w-]+\s+){0,2}?)(systems?|services?|infrastructure|software|platforms?)(?=\s+(?:in production|at scale|reliably|24/7|in the cloud))", re.I)


def _v344_mask(raw: str) -> str:
    return _V344_OPERATING.sub(lambda m: "running " + m.group(1) + m.group(2), str(raw))


_parse_jd_requirements_v343 = parse_jd_requirements


def parse_jd_requirements(raw_jd: str, master: dict[str, Any], title: str = "") -> list[dict[str, Any]]:
    """v3.4.5: salary currency codes are masked; literal stack lines count in every section (A1 / A2).
    v3.4.9a fix 1: the reader works on v349_jd_view (preferred headings, About You, context lists, and/or)."""
    raw = _v345_mask_currency(v349_jd_view(raw_jd) if _v347_on("jd_sections_v349") else raw_jd)
    reqs = _parse_jd_requirements_v343(_v344_mask(raw), master, title)
    reqs = _v345_stack_merge(reqs, raw, master, title, lambda r, m, t: _parse_jd_requirements_v343(_v344_mask(r), m, t))
    if _v347_on("sql_parse"):   # v3.4.7b B3: a literal SQL in a database requirement line is a requirement term
        reqs = _v347b_add_sql(reqs, clean_jd_text(raw))
    if v348b_on():   # v3.4.8b: the met graduation requirement names the real date (master qualification_facts)
        reqs = [dict(r, term="graduation in December 2026") if isinstance(r, dict) and r.get("term") == "graduation in 2027" else r for r in reqs]
    if _v347_on("jd_sections_v349"):   # v3.4.9a fix 1: every verbatim is still the posting's own text
        for r in reqs:
            if isinstance(r, dict) and r.get("verbatim"):
                r["verbatim"] = v349_raw_verbatim(str(r["verbatim"]), raw_jd)
    return reqs


_jd_named_pool_terms_v343 = jd_named_pool_terms


def jd_named_pool_terms(raw_jd: str, master: dict[str, Any]) -> list[str]:
    return _jd_named_pool_terms_v343(_v344_mask(raw_jd), master)


_jd_omission_warnings_v343 = jd_omission_warnings


def jd_omission_warnings(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[dict[str, Any]]:
    return _jd_omission_warnings_v343(plan, master, _v344_mask(raw_jd))


_jd_gap_terms_v343 = jd_gap_terms


def jd_gap_terms(raw_jd: str, master: dict[str, Any]) -> list[str]:
    return _jd_gap_terms_v343(_v344_mask(raw_jd), master)


_build_skill_states_v343 = build_skill_states


def build_skill_states(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    if master.get("_v349b_layout_9a") and not V349B_CTX.get("ref"):   # v3.4.9b: bullets are picked as on the v3.4.9a page
        return v349c_python_first(v349b_states_keep_9a_pick(plan, master), plan, master)   # v3.4.9c run 4 L4
    if _v347c_active(plan):   # v3.4.7c C1: Skills come from the page as it was before the Fleet swap (Skills never change)
        with _v347c_pre_swap(plan):
            _V348C_S["inner"] = True
            try:
                states = build_skill_states(plan, master)
            finally:
                _V348C_S["inner"] = False
        return v349c_python_first(v349b_skills_cap5(v349_skills_hygiene(v348c_skills_lines(states, plan, master), plan, master), plan, master), plan, master)   # v3.4.8c S: on the page as rendered; v3.4.9a fix 9; v3.4.9b Skills cap
    raw = plan.get("_raw_jd_text")
    masked = _v344_mask(raw) if raw else raw
    if raw and masked != raw:
        plan["_raw_jd_text"] = masked
        try:
            states = _build_skill_states_v343(plan, master)
        finally:
            plan["_raw_jd_text"] = raw
        for st in states:   # the OS skill never comes from "operating ... in production"
            for cat, vals in st.get("skills", {}).items():
                if "Operating Systems" in vals and not re.search(r"\boperating systems?\b(?!\s+in production)", masked, re.I) and "pintos" not in (plan.get("ranking") or []):
                    vals.remove("Operating Systems")
        return v349c_python_first(v349b_skills_cap5(v349_skills_hygiene(v348c_skills_lines(_v345_skill_fix(states, plan, master), plan, master), plan, master), plan, master), plan, master)   # v3.4.9a fix 9; v3.4.9b Skills cap
    return v349c_python_first(v349b_skills_cap5(v349_skills_hygiene(v348c_skills_lines(_v345_skill_fix(_build_skill_states_v343(plan, master), plan, master), plan, master), plan, master), plan, master), plan, master)   # v3.4.9b Skills cap


# --- G. Experience variant I -----------------------------------------------------------------------------------

def _v344_variant_entry(text: str, master: dict[str, Any]) -> dict[str, Any] | None:
    key = normalize_fixed_text(text)
    for e in (master.get("experience_variants") or {}).get("bullets", []):
        for v in e.get("variants", []):
            if normalize_fixed_text(v.get("text", "")) == key:
                return v
    return None


_experience_variant_problems_v343 = experience_variant_problems


def experience_variant_problems(original: str, variant: str, master: dict[str, Any]) -> list[str]:
    """v3.4.4: a variant may add exactly the master-recorded facts in its allowed_additions (variant I: Agile/Scrum and
    "reviewed and merged team pull requests", both Thesis evidence anchors); everything else is the v3.4.3 check."""
    v = _v344_variant_entry(variant, master) or {}
    adds = list(v.get("allowed_additions") or [])
    probs = []
    if adds:
        job = _v343_exp_job(original, master) or {}
        rec = (str(job.get("evidence_anchors", "")) + " " + " ".join(x for vals in (master.get("cover_letter_evidence") or {}).values() for x in vals)).lower()
        for a in adds:
            core = re.sub(r"^(?:using|with|and)\s+", "", a.lower())
            if core not in rec and not all(w in rec for w in re.findall(r"[a-z]+", core)):
                probs.append(f"allowed addition not recorded in master: {a}")
        stripped = variant
        for a in adds:
            stripped = stripped.replace(a, " ")
        variant = re.sub(r"\s+", " ", stripped).replace(" :", ":").replace(" ,", ",").replace(", and .", ".").strip()
    return probs + _experience_variant_problems_v343(original, variant, master)


_select_experience_variants_v343 = select_experience_variants


def select_experience_variants(plan: dict[str, Any], master: dict[str, Any], test_mode: bool = False) -> list[dict[str, Any]]:
    picks = _select_experience_variants_v343(plan, master, test_mode=test_mode)
    raw = str(plan.get("_raw_jd_text", ""))
    allowed = ("approved", "proposed") if test_mode else ("approved",)
    for e in (master.get("experience_variants") or {}).get("bullets", []):
        for v in e.get("variants", []):
            if v.get("status") not in allowed or not v.get("suits_jd"):
                continue
            line = _v344_jd_line(raw, v["suits_jd"])
            if not line:
                continue
            picks = [p for p in picks if p["bullet_id"] != e["id"]]
            picks.append({"bullet_id": e["id"], "variant_id": v["id"], "original": e["original"], "text": v["text"], "score": 1.0, "_jd_line": line})
            break
    # v3.4.5 (item 12): defect / debugging / operational-excellence / on-call / monitoring lines are ops themes, so the
    # heartbeat variant (suits devops_cloud / it_ops) is considered even when the theme weight is low
    ops = next((l for l in _v342_role_text(raw) if _V345_OPS_LINE.search(l)), "")
    if ops:
        for e in (master.get("experience_variants") or {}).get("bullets", []):
            if any(p["bullet_id"] == e["id"] for p in picks):
                continue
            v = next((x for x in e.get("variants", []) if x.get("status") in allowed and {"it_ops", "devops_cloud"} & set(x.get("suits_themes") or [])
                      and re.search(r"\bheartbeat\b|\bmonitor", str(x.get("text", "")), re.I)), None)
            if v:
                picks.append({"bullet_id": e["id"], "variant_id": v["id"], "original": e["original"], "text": v["text"], "score": 0.12, "_jd_line": ops})
    if v349c_thesis_on():   # v3.4.9c run 3: Thesis first bullet I by default, E on requirements / stakeholder-heavy postings
        heavy = v349c_reqs_heavy(raw)
        want = V349C_THESIS_REQS if heavy else V349C_THESIS_DEFAULT
        e = next((x for x in (master.get("experience_variants") or {}).get("bullets", []) if x.get("id") == "exp.thesis.1"), None)
        v = next((x for x in (e or {}).get("variants", []) if x.get("id") == want and x.get("status") in allowed), None)
        if e and v:
            picks = [p for p in picks if p["bullet_id"] != e["id"]]
            picks.append({"bullet_id": e["id"], "variant_id": v["id"], "original": e["original"], "text": v["text"], "score": 1.0,
                          "_jd_line": heavy[0] if heavy else str(plan.get("application", {}).get("role", ""))})
    # v3.4.6 (item 5): a verb-only variant (J) replaces its bullet's opening verb whenever another Experience bullet on
    # the page (original or chosen variant) opens with the same verb, so two Experience bullets never open alike
    picks += _v346_verb_only_picks(plan, master, picks, allowed)
    return picks


_V344_THEME_QUOTE = {
    "llm_agents": r"\bAI\b|\bLLMs?\b|\bagent|machine learning|\bmodels?\b", "ai_apps": r"\bAI\b|\bLLMs?\b|generative", "model_api": r"\bAI\b|\bLLMs?\b|\bmodels?\b",
    "ml_dl": r"machine learning|\bML\b|\bmodels?\b|deep learning", "data_eng": r"\bdata\b|pipeline|\bETL\b", "backend": r"backend|back-end|\bAPIs?\b|services",
    "integration": r"integrat|\bAPIs?\b", "realtime": r"real[- ]time|streaming|\blive\b", "systems": r"embedded|firmware|\bC\b|operating system|device|low[- ]level",
    "devops_cloud": r"cloud|\bAWS\b|deploy|infrastructure|DevOps|monitor", "it_ops": r"operat|support|monitor|\bIT\b", "security": r"secur|access|permission|auth",
    "customer": r"client|customer|stakeholder",
}


def _v344_variant_jd_line(raw: str, variant: dict[str, Any], title: str) -> str:
    for t in variant.get("suits_themes", []) or []:
        rx = _V344_THEME_QUOTE.get(t)
        if rx:
            for line in _v342_role_text(raw):
                if re.search(rx, line, re.I if not rx.startswith(r"\bAI") else 0):
                    return line
    return title


_experience_variants_stage_v343 = experience_variants_stage


def experience_variants_stage(plan: dict[str, Any], master: dict[str, Any], template_text: str, generated: str):
    template_text = v349b_effective_template(template_text)   # v3.4.9b
    gen, exp_template, info = _experience_variants_stage_v343(plan, master, template_text, generated)
    if _v347_on("bold_results_v349b"):   # v3.4.9b: bold results at render time (after the Experience variants)
        gen = v349b_bold_tex(gen)
    raw = str(plan.get("_raw_jd_text", ""))
    title = str(plan.get("application", {}).get("role", ""))
    picks = {p["variant_id"]: p for p in select_experience_variants(plan, master, test_mode=bool(plan.get("_v342_exp_variants_test")))}
    for u in info.get("used", []):
        vid = u.get("variant_id")
        v = next((x for e in (master.get("experience_variants") or {}).get("bullets", []) for x in e.get("variants", []) if x.get("id") == vid), {})
        if v.get("verb_only"):   # v3.4.6 (item 5): a script rule, not a posting line
            _v346_internal_change(f"Experience variant {v.get('label', vid)} ({vid}, verb-only: another Experience bullet on the page opens with {v.get('avoids_repeat_verb', '')})")
            continue
        line = (picks.get(vid) or {}).get("_jd_line") or (title if v.get("always") else _v344_variant_jd_line(raw, v, title))
        why = "for every role" if v.get("always") else f"suits {v.get('suits', '')}"
        _v344_change(f"Experience variant {v.get('label', vid)} ({vid}, {why})", line)
    return gen, exp_template, info


# --- D11 / D14 / D15. bank selection preferences -----------------------------------------------------------------

_V344_AGENT_TITLE = re.compile(r"\bagent\w*|\bagentic\b|\bml infra\w*|\bmachine learning infra\w*|\bml platform\b|\bmlops\b|\bml systems?\b", re.I)
_V344_AGENT_LINE = re.compile(r"\bagentic\b|\bai agents?\b|\bmulti-agent\b|\bagent (?:framework|orchestration|systems?|workflows?|tools?)\b|\bml infra\w*|"
                              r"\bmachine learning infra\w*|\bml platform\b|\bmlops\b|\bmodel serving\b|\btraining infrastructure\b|\bml lifecycle\b", re.I)
_V344_RUNTIME_IDS = ("tailor_pipeline.runtime.",)
_V344_RUNTIME_PREFER = ["tailor_pipeline.failover.a", "tailor_pipeline.failover.s1",
                        "tailor_pipeline.claims.a", "tailor_pipeline.claims.b", "tailor_pipeline.claims.s1"]
_V344_PATTERNS_PREFER = ["ledgerflow.eo.a", "ledgerflow.eo.c", "ledgerflow.eo.b"]


def _v344_agent_posting(raw_plan: dict[str, Any], raw: str) -> str:
    title = str(raw_plan.get("application", {}).get("role", ""))
    if _V344_AGENT_TITLE.search(title):
        return title
    lines = [l for l in _v342_role_text(raw) if _V344_AGENT_LINE.search(l)]
    return lines[0] if len(lines) >= 2 else ""


def _v344_name_rx(name: str):
    return re.compile(r"(?<![\w+#])" + re.escape(name) + r"(?![\w+#])", re.I)


_auto_bank_selection_v343 = auto_bank_selection


def auto_bank_selection(raw_plan, bank, pairs=None):
    if V349B_CTX.get("trim") and not V349B_CTX.get("in_abs"):   # v3.4.9b: the Letter page keeps the v3.4.9a bullet order
        V349B_CTX["in_abs"] = True
        try:
            sel, info = auto_bank_selection(raw_plan, bank, pairs)
        finally:
            V349B_CTX["in_abs"] = False
        return v349b_ref_order(sel), info
    """v3.4.5 (item 13): ML pages show LedgerFlow's architecture as two Java services (Spring Boot is off-role there)
    unless the posting names Spring; other pages keep the Spring Boot line. Falls back to the full bank."""
    bank = v348c_selection_bank(raw_plan, bank)   # v3.4.8c W / F1: new wordings take their old ids' place; F1 is swap-only
    fb = _v345_filter_bank(raw_plan, bank)
    if fb is not bank:
        sel, info = _v345_auto_bank_core(raw_plan, fb, pairs)
        if sel is not None:
            if _v347_on("bullet_relevance") or _v347_on("strict_fleet"):   # v3.4.7b B4 / v3.4.7c C1: within-project relevance, fail-closed
                sel, info = _v347b_bullet_relevance(raw_plan, fb, pairs, sel, info, _v347b_rerun_factory(raw_plan, fb, pairs, _v345_auto_bank_core))
                return v349_fleet_last_resort(raw_plan, fb, pairs, sel, info, _v345_auto_bank_core)   # v3.4.9a fix 5
            return sel, info
    sel, info = _v345_auto_bank_core(raw_plan, bank, pairs)
    if sel is not None and (_v347_on("bullet_relevance") or _v347_on("strict_fleet")):
        sel, info = _v347b_bullet_relevance(raw_plan, bank, pairs, sel, info, _v347b_rerun_factory(raw_plan, bank, pairs, _v345_auto_bank_core))
        return v349_fleet_last_resort(raw_plan, bank, pairs, sel, info, _v345_auto_bank_core)   # v3.4.9a fix 5
    return sel, info


def _v345_filter_bank(raw_plan, bank):
    ranking = list(raw_plan.get("ranking") or [])
    if "ledgerflow" not in ranking:
        return bank
    raw = str(raw_plan.get("_raw_jd_text", ""))
    ml = _v345_ml_posting(raw_plan, raw) and not re.search(r"\bspring\b", raw, re.I)
    fb = deepcopy(bank)
    for v in fb.get("projects", {}).get("ledgerflow", []):
        if ml and v.get("main_evidence_id") == "ledger.architecture" and "Spring Boot" in str(v.get("text", "")):
            v["status"] = "excluded_v345"
        elif not ml and v.get("id") == "ledgerflow.arch.s2":
            v["status"] = "excluded_v345"
    return fb


def _v345_auto_bank_core(raw_plan, bank, pairs=None):
    raw = str(raw_plan.get("_raw_jd_text", ""))
    ranking = list(raw_plan.get("ranking") or [])
    prefer = list(raw_plan.get("prefer_variants") or [])
    bank2 = bank
    # 11. the LLM engine's "three AI workers / 73%" bullet reads as resume automation on ML-infrastructure / agent postings
    agent = _v344_agent_posting(raw_plan, raw)
    if agent and "tailor_pipeline" in ranking:
        bank2 = deepcopy(bank)
        for v in bank2.get("projects", {}).get("tailor_pipeline", []):
            if str(v.get("id", "")).startswith(_V344_RUNTIME_IDS):
                v["status"] = "excluded_v344"
            elif v.get("id") in _V344_RUNTIME_PREFER:
                v["headline"] = True   # failover / claim checks lead the project in place of the runtime bullet
        prefer += _V344_RUNTIME_PREFER
        raw_plan["_v344_runtime_excluded"] = True
        _v344_change("LLM engine: the three-AI-workers runtime bullet is left off; its failover and claim-check bullets are preferred (ML-infrastructure / agent posting)", agent)
    # 14. software design patterns -> LedgerFlow's transactional outbox / idempotent consumer bullet
    dp = _v344_jd_line(raw, r"\bdesign patterns?\b")
    if dp and "ledgerflow" in ranking:
        prefer += _V344_PATTERNS_PREFER
        _v344_change("LedgerFlow: the transactional outbox / idempotent consumer bullet is preferred (the posting names design patterns)", dp)
    # 15. required terms with bullet evidence in the bank: prefer a bullet that names them
    exp_text = " ".join(b for r in (globals().get("_V33_MASTER") or {}).get("experience", []) for b in r.get("bullets", []))
    pref15 = {}
    for r in ([] if _V344_CTX.get("no_preflight") else raw_plan.get("jd_requirements") or []):
        if not isinstance(r, dict) or not r.get("supported") or str(r.get("priority", "")).lower() not in ("must", "high"):
            continue
        names = [str(r.get("term", ""))] + [str(a) for a in r.get("aliases", []) or []]
        names = [n for n in dict.fromkeys(names) if n and len(n) > 2 and not re.search(r"degree|experience|years|graduate|internship", n, re.I)]
        if not names or any(_v344_name_rx(n).search(exp_text) for n in names):
            continue
        hits = [v["id"] for pid in ranking for v in bank2.get("projects", {}).get(pid, []) if v.get("status") == "ok" and any(_v344_name_rx(n).search(str(v.get("text", ""))) for n in names)]
        if 0 < len(hits) <= 3:
            pref15[str(r.get("term"))] = hits
            prefer += hits
            _v344_change(f"Preflight: a bullet that names {r.get('term')} is preferred ({', '.join(hits)})", r.get("verbatim") or r.get("term"))
    raw_plan["_v344_preflight_prefer"] = pref15
    _V344_CTX["preflight_prefer"] = pref15
    # v3.4.5 items 6 / 8 / 14: Fraud names IEEE-CIS (ML postings: edge-ablation and leakage bullets); warehouse /
    # logistics postings: GoingOnce's Fleet bullet; NoSQL postings: LaunchOps's MongoDB quiz bullet
    pref345 = [] if _V344_CTX.get("no_preflight") else _v345_bank_prefer(raw_plan, raw, ranking)
    prefer += pref345
    _V345_CTX["bank_prefer"] = pref345
    old = raw_plan.get("prefer_variants")
    raw_plan["prefer_variants"] = list(dict.fromkeys(prefer))
    try:
        sel, info = _auto_bank_selection_v343(raw_plan, bank2, pairs)
        if sel is None and pref345:
            raw_plan["prefer_variants"] = [x for x in raw_plan["prefer_variants"] if x not in pref345 or x in _V345_IEEE_PREFER]
            sel, info = _auto_bank_selection_v343(raw_plan, bank2, pairs)
        if sel is not None and "fraud" in ranking and not _v345_names_ieee(sel.get("fraud", []), bank2):
            b3 = deepcopy(bank2)
            for v in b3.get("projects", {}).get("fraud", []):
                if v.get("headline") and "IEEE-CIS" not in str(v.get("text", "")):
                    v["status"] = "excluded_v345"
            sel3, info3 = _auto_bank_selection_v343(raw_plan, b3, pairs)
            if sel3 is not None and _v345_names_ieee(sel3.get("fraud", []), b3):
                sel, info = sel3, info3
                _v344_change("Fraud: a bullet that names the IEEE-CIS dataset leads the project (the Elliptic bullet's \"independent\" needs a referent)", _v345_ml_line(raw) or str(raw_plan.get("application", {}).get("role", "")))
        if sel is None and pref15:
            raw_plan["prefer_variants"] = [x for x in raw_plan["prefer_variants"] if x not in {i for ids in pref15.values() for i in ids}]
            sel, info = _auto_bank_selection_v343(raw_plan, bank2, pairs)
        if sel is None and agent and bank2 is not bank:
            raw_plan["prefer_variants"] = [x for x in raw_plan["prefer_variants"] if x not in _V344_RUNTIME_PREFER]
            sel, info = _auto_bank_selection_v343(raw_plan, bank2, pairs)
        if sel is None:
            raw_plan["prefer_variants"] = list(old or [])
            sel, info = _auto_bank_selection_v343(raw_plan, bank2, pairs)
        if sel is None and agent and bank2 is not bank:
            sel, info = _auto_bank_selection_v343(raw_plan, bank, pairs)
            if sel is not None:
                _v344_change("LLM engine: no valid page without the runtime bullet, so it stays (exception to the agent-posting rule)", agent)
        return sel, info
    finally:
        raw_plan["prefer_variants"] = old if old is not None else []


_expand_bank_plan_v344 = expand_bank_plan


def expand_bank_plan(raw_plan: dict[str, Any], bank: dict[str, Any], master: dict[str, Any]):
    """On an agent / ML-infrastructure posting (item 11) the LLM engine's failover or claim-check bullet leads the
    project in place of the runtime bullet, so it satisfies the rank #1 headline rule."""
    plan, failures = _expand_bank_plan_v344(raw_plan, bank, master)
    rank = list(raw_plan.get("ranking") or [])
    bs = plan.get("bank_selection") if isinstance(plan.get("bank_selection"), dict) else {}
    sel = set(bs.get(rank[0], []) if rank else [])
    if (raw_plan.get("_v344_runtime_excluded") or plan.get("_v344_runtime_excluded")) and rank and rank[0] == "tailor_pipeline" and sel & set(_V344_RUNTIME_PREFER):
        failures = [f for f in failures if f.get("type") != "rank1_missing_headline_variant"]
    return plan, failures


# --- D13. headings keep ReactJS when a selected bullet shows React and the posting names it -----------------------

_adapt_header_tech_v344 = adapt_header_tech


def adapt_header_tech(pid: str, vals: list[str], plan: dict[str, Any], master: dict[str, Any]) -> list[str]:
    out = _adapt_header_tech_v344(pid, vals, plan, master)
    raw = str(plan.get("_raw_jd_text", ""))
    if _v345_ml_posting(plan, raw) and len(out) > 3:   # v3.4.5 (item 13): off-role frameworks leave ML pages (heading and Skills)
        named = {t.casefold() for t in jd_named_pool_terms(raw, master)}
        drop = [x for x in out if x in _V345_ML_OFF_ROLE and x.casefold() not in named]
        if drop:
            out = [x for x in out if x not in drop]
            plan.setdefault("_v345_heading_dropped", {})[pid] = drop
    if not re.search(r"\breact(?:\.?js)?\b", raw, re.I) or any(re.match(r"react", x, re.I) for x in out):
        return out
    tech = [str(t) for t in master["projects"].get(pid, {}).get("tech", [])]
    rname = next((t for t in tech if re.match(r"react", t, re.I)), None)
    if not rname:
        return out
    bl = " ".join(bullet_text(b) for b in (plan.get("bullets") or {}).get(pid, []))
    if not re.search(r"\bReact\b", bl):
        return out
    name = "ReactJS"
    jdkeys = {str(x).casefold() for x in plan.get("_jd_pool_terms", []) or []}
    canon = len(", ".join(out))
    spots = [i for i in range(len(out) - 1, 0, -1) if out[i].casefold() not in jdkeys and not re.match(r"react", out[i], re.I)]
    for i in spots:
        cand = out[:i] + [name] + out[i + 1:]
        if len(", ".join(cand)) <= canon + 6:
            plan.setdefault("_v344_heading_react", {})[pid] = out[i]
            _v344_change(f"{master['projects'][pid].get('resume_title', {}).get('name', pid)} heading keeps ReactJS (a selected bullet shows React; replaces {out[i]})", _v344_jd_line(raw, r"\breact"))
            return cand
    if len(", ".join(out + [name])) <= canon + 9:
        _v344_change(f"{master['projects'][pid].get('resume_title', {}).get('name', pid)} heading keeps ReactJS (a selected bullet shows React)", _v344_jd_line(raw, r"\breact"))
        return out + [name]
    return out


# --- C. complete evidence inventory -----------------------------------------------------------------------------

_evidence_inventory_md_v343 = evidence_inventory_md


def evidence_inventory_md(master: dict[str, Any]) -> str:
    """Every master evidence line, not only anchors: cover-letter evidence, approved Experience variants, every project
    evidence item, qualification facts, education and awards."""
    base = _evidence_inventory_md_v343(master)
    head, sep, tail = base.partition("### Supported skills")
    L = []
    cle = master.get("cover_letter_evidence") or {}
    if cle:
        L.append("### Additional verified facts (master.json cover_letter_evidence; usable in letters and approved Experience variants)")
        for cat, vals in cle.items():
            for x in vals:
                if not re.match(r"(?i)do not ", str(x)):
                    L.append(f"- {cat.replace('_', ' ')}: {x}")
        L.append("")
    ev = (master.get("experience_variants") or {}).get("bullets", [])
    if ev:
        L.append("### Approved Experience variants (verified wording; the page may show one in place of the original line)")
        for e in ev:
            for v in e.get("variants", []):
                if v.get("status") == "approved":
                    extra = f" (adds the master-recorded facts: {'; '.join(v['allowed_additions'])})" if v.get("allowed_additions") else ""
                    L.append(f"- {v.get('label')} [{e.get('job')}]: {v.get('text')}{extra}")
        L.append("")
    L.append("### Project evidence items (every verified fact behind the project bullets)")
    for pid, p in master.get("projects", {}).items():
        shown = {normalize_fixed_text(x) for x in p.get("evidence", [])}
        items = [(k, it) for k, it in (p.get("evidence_items") or {}).items() if isinstance(it, dict) and it.get("text") and normalize_fixed_text(it["text"]) not in shown]
        if items:
            L.append(f"#### {p.get('name')}")
            for k, it in items:
                L.append(f"- {it['text']}")
    L.append("")
    qf = master.get("qualification_facts") or []
    if qf:
        L.append("### Qualification facts (Jay meets these)")
        L.append("- " + "; ".join(str(x) for x in qf))
        L.append("")
    edu = master.get("education") or {}
    if edu:
        L.append("### Education")
        L.append("- " + json.dumps(edu, ensure_ascii=False)[:1200])
        L.append("")
    aw = master.get("awards") or []
    if aw:
        L.append("### Awards")
        for a in aw:
            L.append("- " + (a if isinstance(a, str) else json.dumps(a, ensure_ascii=False)))
        L.append("")
    return head + "\n".join(L) + "\n" + sep + tail


# --- E16. letter experience sentence by role ---------------------------------------------------------------------

_V344_OPS = {
    "code_review": re.compile(r"\bcode (?:&|and) design reviews?\b|\bcode reviews?\b|\bpull requests?\b|\bpeer[- ]review\w*|\breview(?:ing)? (?:code|solutions)\b", re.I),
    "debugging": re.compile(r"\bdebug\w*|\btroubleshoot\w*|\bdefects?\b|\blog analysis\b|\broot[- ]cause\w*|\bresolve (?:issues|bugs|problems)\b", re.I),
    "operations": re.compile(r"\boperational excellence\b|\bon[- ]call\b|\bincidents?\b|\bproduction (?:issues|support|incidents|systems)\b|\bobservability\b|"
                             r"\bsite reliability\b|\bmonitor(?:ing)? (?:and|the|of|production|services|systems|health)\b|\boperat(?:e|es) (?:services|systems|software)\b|"
                             r"\boperating (?:services|software)\b|\boperating systems in production\b", re.I),
    "mentorship": re.compile(r"\bmentor\w*|\binterview process\b|\binterviewing\b", re.I),
}
_V344_REQS = re.compile(r"\b(?:gather|clarify|collect|elicit|translate)\w*\b[^.]{0,40}\brequirements\b|\brequirements? gathering\b", re.I)
_V344_STAKE = re.compile(r"\bstakeholders?\b|\bgather\w* (?:and \w+ )?requirements\b|\brequirements? gathering\b|\bbusiness (?:users|teams|partners|requirements)\b|\bclients?\b|\bend users\b|\bcross-functional partners\b", re.I)


def _v344_ops_categories(raw: str) -> dict[str, str]:
    cats = {}
    for line in _v342_role_text(raw):
        for k, rx in _V344_OPS.items():
            if k not in cats and rx.search(line) and not (k == "mentorship" and re.search(r"\b(?:receive|receiving|get|gain|with|alongside|from)\s+(?:\w+\s+){0,2}mentor", line, re.I)):
                cats[k] = line
    return cats


_v33_experience_key_v344 = _v33_experience_key


def _v33_experience_key(plan, vec, ranking):
    k = _v33_experience_key_v344(plan, vec, ranking)
    cl = plan.get("cover_letter") or {}
    if isinstance(cl, dict) and cl.get("experience"):
        return k
    raw = str(plan.get("_raw_jd_text", ""))
    sensor = _v345_sensor_line(plan, raw)
    if sensor and x33_has(plan, "thesis_iot"):
        plan["_v345_sensor_line"] = sensor
        if k != "thesis_iot":
            _v344_change("Letter experience sentence: Thesis Mumbai Tech IoT device pipeline (sensor / IoT / device posting)", sensor)
        return "thesis_iot"
    cats = _v344_ops_categories(raw)
    stake = [l for l in _v342_role_text(raw) if _V344_STAKE.search(l)]
    reqs = [l for l in _v342_role_text(raw) if _V344_REQS.search(l)]
    data_ml = k in ("hein", "godigital", "hein_health") or _is_data_ml_role(plan)
    if reqs and not data_ml:
        if k != "thesis_client":
            _v344_change("Letter experience sentence: Thesis Mumbai Tech requirements gathering (the posting asks for requirements work)", reqs[0])
        return "thesis_client"
    use = len(cats) >= 2 or (len(cats) == 1 and k in ("thesis_backend", "thesis_client", "datamaven", "hein_parallel"))
    if k in ("hein", "godigital", "hein_health") or _is_data_ml_role(plan):
        use = False   # data / ML roles anchor the letter to HeinOnline or Go Digital (validate_data_ml_cover_paragraph_2)
    jd_role = "\n".join(l for l in raw.splitlines() if not re.search(r"insurance|benefit|dental|vision|401|wellness|leave|perks", l, re.I))
    if use and len(re.findall(r"\bclinical\b|\bpatients?\b|\bhealth ?care\b|\bmedical\b|\bpharma\w*", jd_role, re.I)) >= 2:
        use = False   # healthcare postings keep the healthcare Thesis sentence
    if use and stake and len(cats) < 2:
        use = False
    if use and k == "thesis_iot" and len(cats) < 3:
        use = False   # embedded / systems roles lead with the IoT pipeline unless operations dominate
    if use:
        plan["_v344_letter_ops"] = cats
        line = next(iter(cats.values()))
        _v344_change("Letter experience sentence: Thesis Mumbai Tech code review, mentoring and failure response (" + ", ".join(k2.replace("_", " ") for k2 in cats) + ")", line)
        return "thesis_ops"
    if stake and k == "thesis_client":
        _v344_change("Letter experience sentence: Thesis Mumbai Tech requirements gathering (stakeholder / requirements posting)", stake[0])
    return k


# --- A. closing -------------------------------------------------------------------------------------------------

_V344_STOP = set("a an the and or of to for with in on by into from that this each its their as at plus while using which who so it them both also my i "
                 "where whose every all any one your our under over than then when only".split())
_V344_PROJECT_WORDS = {"ledgerflow", "ripple", "launchops", "goingonce", "pintos", "llm", "engine", "fraud", "thesis", "mumbai", "tech", "heinonline"}


def _v344_content(s: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9][a-z0-9'+#-]*", str(s).lower()) if w not in _V344_STOP and w not in _V344_PROJECT_WORDS and len(w) >= 3]


def closing_repeats_letter(proof: str, body: str) -> list[str]:
    """A closing proof repeats the letter when it shares a number, a three-word content phrase or at least half of its
    content words with the letter body (3_validation/audit_v344.py applies the same test)."""
    why = []
    body = re.sub(r"Dear Hiring Manager,|Sincerely,|Jay Niketan Pathare", " ", str(body))
    nums = set(re.findall(r"\d[\d,.]*", proof))
    shared = sorted(n for n in nums if re.search(r"(?<![\d])" + re.escape(n) + r"(?![\d])", body))
    if shared:
        why.append(f"number {shared}")
    pc, bc = _v344_content(proof), _v344_content(body)
    tri = {" ".join(bc[i:i + 3]) for i in range(len(bc) - 2)}
    t = [" ".join(pc[i:i + 3]) for i in range(len(pc) - 2) if " ".join(pc[i:i + 3]) in tri]
    if t:
        why.append(f"phrase '{t[0]}'")
    ps, bs = {w[:5] for w in pc}, {w[:5] for w in bc}
    if ps and len(ps & bs) / len(ps) >= 0.5:
        why.append(f"words {sorted(ps & bs)}")
    return why


_V344_KINDS = [
    ("permissions", re.compile(r"\bpermission\w*|\baccess control|\bauthori[sz]\w+|\bauthenticat\w+|\bsso\b|\boauth|\bidentity\b|\baccount (?:security|takeover)|\bsecur\w+", re.I),
     ["launchops.server_checks", "exp.datamaven_access"]),
    ("interactive", re.compile(r"\binteractive\b|\breal[- ]time\b|\blive\b|\bviewers?\b|\bcreators?\b|\bengag\w+|\buser[- ]facing|\bcustomer[- ]facing|\bresponsive\b|\bfront[- ]?end\b|\buser interfaces?\b|\bUI\b", re.I),
     ["launchops.live_quiz", "goingonce.interface_tests", "exp.thesis_iot"]),
    ("embedded", re.compile(r"\bembedded\b|\bfirmware\b|\bdevices?\b|\bkernel\b|\boperating systems?\b|\brobot\w*|\bhardware\b|\blow[- ]level\b|\bsilicon\b|\bota\b|\bsystems? software\b|\bequipment\b|\bsensors?\b|\bC\b", re.I),
     ["pintos.syscalls", "pintos.processes", "pintos.safety", "pintos.tests", "exp.thesis_iot"]),
    ("operations", re.compile(r"\bmonitor\w*|\boperat(?:e|es|ing|ional)\b|\bincidents?\b|\bon[- ]call\b|\buptime\b|\bobservab\w+|\bproduction (?:issues|support|systems)\b|"
                              r"\btroubleshoot\w*|\bdebug\w*|\brestor\w+|\bsupport\b|\bhealth\w*\b|\bkeep\b", re.I),
     ["exp.thesis_heartbeat"]),
    ("integrations", re.compile(r"\bintegrat\w+|\bapis?\b|\bendpoints?\b|\bthird[- ]party|\bwebhooks?|\bevent[- ]driven|\bmessag\w+|\bdata sources?\b|\bservices?\b|\bback[- ]?end\b|\bmicroservices?\b", re.I),
     ["ledger.exactly_once_effect"]),
    ("code", re.compile(r"\b(?:write|writing|review\w*)\b[^.]{0,40}\bcode\b|\bcode reviews?\b|\bpull requests?\b|\bcoding\b", re.I),
     ["exp.thesis_review", "ledger.ci", "ripple.tests", "pintos.tests"]),
    ("testing", re.compile(r"\btest\w*|\bquality\b|\bci\b|\bcontinuous integration|\breliab\w+|\bdefects?\b|\bverif\w+|\bmaintainab\w+|\bwell[- ]tested|\brobust\b|\bdependab\w+|\bclean\b|\bcode\b|\bsoftware\b", re.I),
     ["ledger.ci", "ripple.tests", "pintos.tests", "tailor.tests", "ledger.chaos_runs", "ripple.git_verification"]),
    ("architecture", re.compile(r"\barchitect\w*|\bdesign\b|\bcomplex systems?\b|\bfoundations?\b|\bframeworks?\b|\blibrar(?:y|ies)\b|\btooling\b|\btools?\b", re.I),
     ["ledger.exactly_once_effect", "launchops.server_checks", "goingonce.deterministic", "ripple.analysis_tools", "tailor.claim_validation", "pintos.safety"]),
    ("scale", re.compile(r"\bscal\w+|\bconcurren\w+|\bdistributed\b|\bfault[- ]toleran\w+|\bhigh[- ]availab\w+|\bperforman\w+", re.I),
     ["ledger.overspend_test", "ledger.chaos_runs", "ledger.kubernetes_demo"]),
    ("ml", re.compile(r"\bmachine learning\b|\bml models?\b|\bmodels?\b(?=[^.]{0,30}\b(?:train|evaluat|select|experiment))|\b(?:train|evaluat|select)\w*\b[^.]{0,30}\bmodels?\b|\bexperiments?\b|\bablation\b|\bbaselines?\b", re.I),
     ["fraud.ablation", "fraud.leakage", "fraud.model_compare", "fraud.elliptic", "fraud.graphsage", "ripple.evaluation"]),
    ("ai", re.compile(r"\bai\b|\bllms?\b|\bagents?\b|\bmodels?\b|\bmachine learning\b|\bml\b|\bevaluat\w+", re.I),
     ["ripple.evaluation", "ripple.git_verification", "ripple.analysis_tools", "tailor.claim_validation", "tailor.provider_failover", "fraud.graphsage", "fraud.elliptic"]),
    ("data", re.compile(r"\bdata\b|\bpipelines?\b|\betl\b|\bsql\b|\bdatabases?\b|\banalytic\w*", re.I),
     ["ledger.exactly_once_effect", "fraud.dataset", "exp.thesis_iot"]),
]
_V344_SCALE_CLAIM = re.compile(r"\bmillions?\b|\bbillions?\b|\bhundreds of (?:millions|thousands)\b|\blarge[- ]scale\b|\bat scale\b|\bmassive(?:ly)?\b|\bhigh[- ](?:traffic|volume|throughput)\b|"
                               r"\bplanet[- ]scale\b|\bglobal[- ]scale\b|\bconcurrent users\b|\bworld'?s largest\b|\binternet[- ]scale\b|\bthousands of (?:transactions|requests|users)\b", re.I)
_V344_DANGLE = re.compile(r"(?:\b(?:of|to|for|with|and|or|the|a|an|in|on|at|by|from|into|across|as|its|their|our|your|such|including|like|via|per|than|that|which|while|both|either|"
                          r"more|most|less|various|other)|[,;:(\-–]|\b\w+-(?:driven|based|facing|level|oriented|ready|scale|time|class|quality)"
                          r"|\b(?:adapt|respond|contribute|depend|scale|relate|adhere|conform|comply|belong|refer|react|cater|attend|subscribe|appl(?:y|ies))s?)\s*$", re.I)   # v3.4.5: verbs that need a complement ("systems that adapt")
_V344_GROWTH_RX = re.compile(_V343_GROWTH.pattern + r"|\bfamiliarity\b|\bunderstand\w*\b|\blearn\w*|\bexplor\w+|\bstay on top\b|\bfoster\b|\bpassion\b", re.I)


class _V344Growth:
    """Growth / learning language, where "machine learning" and "deep learning" are technologies, not growth."""
    def search(self, t: str):
        return _V344_GROWTH_RX.search(re.sub(r"(?i)\b(?:machine|deep|reinforcement) learning\b", "ML", str(t)))


_V344_GROWTH = _V344Growth()
_V344_LEAD = re.compile(r"^(?:(?:you will|you'll|you’ll|will|also|we need you to|you are expected to|expect to|responsible for|responsibilities include|a track record of|track record of|a record of|"
                        r"work on|assist (?:with|in)|"
                        r"(?:previous|prior|some|relevant|solid|real-world|academic or professional)\s+(?:experience|exposure)(?: in| with| at)?|"
                        r"(?:proven |demonstrated |hands-on |practical |professional |strong )?(?:experience|ability|skills?)(?: in| with| to| for| at)?|ability to|able to|"
                        r"excited to|eager to|you can|can|must be able to|be able to|help(?: us)?(?: to)?)\s+)+", re.I)


def _v344_base_verb(w: str) -> str:
    core = w.rstrip(",").lower()
    for cand in (core, core[:-1] if core.endswith("s") and not core.endswith("ss") else "", core[:-2] if core.endswith("es") else "", _v343_gerund_base(core).lower()):
        if cand and _V343_BUILD.match(cand) and _V343_BUILD.match(cand).end() == len(cand):
            return cand
    return ""


def _v344_actor_phrase(sent: str) -> str:
    """A posting line rewritten with Jay as the actor: "Experience building web applications" -> "build web
    applications"; "Implements tasks within the SDLC" -> "implement tasks within the SDLC"."""
    if _v347_on("copy_rule_v349"):   # v3.4.9a fix 8: "Design  develop modules" -> "design and develop modules"
        sent = v349_verb_pair(re.sub(r"\s+", " ", str(sent)))
    t = re.sub(r"^[^\w(]+|^\d+[.)]\s*", "", str(sent)).strip().rstrip(".;:")
    t = re.sub(r"\*\*|__", "", t)
    t = re.sub(r"(?i)[,;]?\s+(?:is |are )?(?:strongly |highly )?(?:preferred|required|desired|a plus|a bonus|nice to have|a strong plus)\s*$", "", t)   # "... applications preferred"
    help_ = bool(re.match(r"(?i)^help(?: us)?(?: to)?\s", t))
    t = _V344_LEAD.sub("", t)
    toks = t.split(" ")
    if not toks or not toks[0]:
        return ""
    b0 = _v344_base_verb(toks[0])
    if not b0:
        return ""
    third = toks[0].rstrip(",").lower().endswith("s") and not toks[0].rstrip(",").lower().endswith("ss") and b0 != toks[0].rstrip(",").lower()
    toks[0] = b0 + ("," if toks[0].endswith(",") else "")
    for i in range(1, min(len(toks), 7)):
        prev = toks[i - 1].lower()
        if prev in ("and", "or") or prev.endswith(","):
            b = _v344_base_verb(toks[i])
            w = toks[i].rstrip(",")
            if not b and third and re.fullmatch(r"[a-z]+(?:es|s)", w) and prev in ("and", "or"):
                b = w[:-3] + "y" if w.endswith("ies") else (w[:-2] if re.search(r"(?:sh|ch|ss|x)es$", w) else w[:-1])   # "creates and executes"
            if b:
                toks[i] = b + ("," if toks[i].endswith(",") else "")
    out = " ".join(toks)
    out = re.sub(r"\byour\b", "the", out, flags=re.I)
    out = re.sub(r"\bour\b", "the", out, flags=re.I)
    out = re.sub(r"\bwe\b|\bus\b", "", out, flags=re.I).replace("  ", " ").strip()
    if help_ and not out.lower().startswith("help"):
        out = "help " + out
    return out


def _v344_cuts(r: str) -> list[str]:
    cuts = [r]
    for sep in (r",? (?:such as|including|like|e\.g\.)\b", r" \(", r":", r", ", r" that ", r" which ", r" for ", r" with ", r" across ", r" using ", r" in ", r" within ",
                r" so ", r" while ", r" and (?=[a-z]+ing\b)", r" to (?=[a-z]+ )"):
        for m in re.finditer(sep, r):
            if sep == r", " and re.match(r"^(?:[^,\s]+(?: [^,\s]+){0,2},\s*)*(?:(?:and|or)\s|[^,\s]+(?: [^,\s]+){0,2},? (?:and|or) )", r[m.end():]):
                continue   # inside a list ("moving money, selling, and shopping"): cutting here leaves a fragment
            head = r[:m.start()].strip().rstrip(",")
            if len(head.split()) >= 3 and head not in cuts:
                cuts.append(head)
    return sorted(dict.fromkeys(cuts), key=lambda x: -len(x.split()))


def _v344_resp_ok(c: str, plan: dict[str, Any], master: dict[str, Any], body_low: str) -> bool:
    if not (3 <= len(c.split()) <= 18) or _V344_DANGLE.search(c) or c.count("(") != c.count(")") or ":" in c:
        return False
    if _v347_on("copy_rule_v349") and v349_bare_singular_tail(c):
        return False   # v3.4.9a fix 8: "services for control plane" -> stop at "services"
    if _V344_GROWTH.search(c) or _V344_SCALE_CLAIM.search(c) or _v342_unsupported_in(c, plan, master):
        return False
    if re.search(r"\d|\b(?:we|us|you)\b|[\"“”]", c, re.I):
        return False
    if re.match(r"^\w+(?:,? (?:and|or) |, )\w+ing\b", c):
        return False   # "write and reviewing code": the second verb was not rewritten
    if re.search(r"\b(?:and|or) (?!(?:engineering|testing|training|learning|processing|computing|monitoring|logging|networking|programming|modeling|modelling|"
                 r"scheduling|messaging|onboarding|building|billing|pricing|ranking|routing|caching|streaming|tooling|tracking|reporting|forecasting|"
                 r"planning|marketing|accounting|banking|shipping|gaming|hosting|mapping|matching|supporting|existing|underlying|emerging|evolving|growing|leading|cutting)\b)[a-z]+ing\b", c):
        return False   # "troubleshoot issues and documenting findings"
    if re.match(r"^\S+ (?:experience|skills?|knowledge|background|fluency|proficiency|expertise|languages?)\b", c, re.I):
        return False   # "programming experience in C++" is a requirement, not a responsibility
    toks = c.split()
    i = 0
    while i < len(toks) and (_v344_base_verb(toks[i]) or toks[i].lower().rstrip(",") in ("and", "or", "help")):
        i += 1
    obj = " ".join(toks[i:])
    if "," in obj and not re.search(r",? (?:and|or) [^,]+$", obj):
        return False   # a list cut before its last item ("pipelines, APIs, data workflows")
    if not obj or re.match(r"(?i)(?:with|in|on|at|for|to|from|using|as|into|through)\b", obj):
        return False   # no object ("help design, build, test"; "debug with debuggers")
    if re.match(r"(?i)(?:a |strong |good |lasting |working |the )?(?:strict )?(?:relationships?|rapport|trust|connections?|partnerships?|networks?|careers?|skills?|confidentiality|compliance|polic(?:y|ies)|procedures?|patterns|principles)\b", obj):
        return False   # "build a rapport with ...": not an engineering responsibility
    if re.match(r"(?i)(?:code|program|test|engineer|support)$", toks[0]) and re.match(r"\w+(?:ance|ence|ment|tion|sion|ity|ness)\b", obj):
        return False   # "code maintenance including debugging": the first word is a noun
    if re.search(r"(?i)\b(?:these|those|them|they|above|following|aforementioned)\b", c):
        return False   # refers to text outside the closing
    w = c.lower().split()
    if c.lower() in body_low or (len(w) >= 4 and " ".join(w[:4]) in body_low) or (len(w) >= 4 and " ".join(w[1:4]) in body_low):
        return False   # the hook already says it
    cl = plan.get("cover_letter") if isinstance(plan.get("cover_letter"), dict) else {}
    hook_low = str((cl or {}).get("hook", "") or "").lower()
    tech_words = {x.lower() for pr in master.get("projects", {}).values() for t in pr.get("tech", []) for x in re.findall(r"[\w+#.]+", str(t))}
    def _plain(g):   # a phrase of technology names ("Java and Spring Boot") is not a repeated idea
        return sum(1 for x in g if x not in tech_words and x not in _V344_STOP) >= 2
    if hook_low and any(" ".join(w[i:i + 4]) in hook_low and _plain(w[i:i + 4]) for i in range(len(w) - 3)):
        return False   # repeats four words of the hook ("for satellite ground systems")
    return True


def closing_candidates(raw_jd: str, plan: dict[str, Any], master: dict[str, Any], body: str) -> list[tuple[str, str]]:
    """(responsibility, source line): build / improve lines first (v3.4.3 order), then every role line and sentence
    rewritten with Jay as the actor; each trimmed to the longest clean head without unsupported terms or scale claims."""
    src = []
    company = str(plan.get("application", {}).get("company", "") or "").strip()
    company = "" if company_is_placeholder(company) else company
    for r in closing_responsibilities(raw_jd, plan, master):
        src.append((r, r))
    for line in _v342_role_text(raw_jd) + [l for l in str(raw_jd).splitlines() if re.search(r"\byou(?:'ll|’ll| will)\b", l, re.I)]:
        if sum(ch.isupper() for ch in line) > 0.6 * max(1, sum(ch.isalpha() for ch in line)):
            line = line.lower()   # an all-caps posting
        for sent in re.split(r"(?<=[.;!?])\s+", re.sub(r"^[-*•·\s]+", "", line.strip())):
            sent = re.sub(r"^\|?\s*[^|]*\|\s*([^|]+?)\s*\|.*$", r"\1", sent) if sent.count("|") >= 2 else sent   # a table row: its responsibility cell
            subj = re.match(r"(?i)^(?:" + (re.escape(company) + r"|" if company else "") + r"we(?:'re|’re| are)?|(?:the|our|this) (?:[\w-]+ ){0,2}teams?(?: is| are)?|our (?:software )?engineers|"
                            r"(?:the|this) (?:[\w()/-]+ ){0,3}(?:engineer|developer|scientist|intern|candidate|person|hire)(?: will)?(?: also)?)\s+(?=\w)", sent)
            if subj:
                sent = sent[subj.end():]
            m = re.search(r"(?i)\byou(?:'ll|’ll| will)(?: be)?\s+(.+)$", sent)
            to = re.search(r"(?i)\bto ((?:help )?(?:design|build|develop|create|implement|write|test|deploy|integrate|monitor|improve|enhance|maintain|optimi[sz]e|ship|deliver|automate|"
                           r"debug|troubleshoot|scale|architect|engineer|prototype|extend|modernize|migrate|refactor|launch)\b.+)$", sent)
            for cand in ([m.group(1)] if m else []) + [sent] + ([to.group(1)] if to else []):
                p = _v344_actor_phrase(cand)
                if p:
                    src.append((p, line.strip()))
    low = str(body).lower()
    out, seen = [], set()
    for r, line in src:
        if _V344_SCALE_CLAIM.search(r):
            continue   # 4. a scale claim the evidence cannot back: choose another responsibility
        r = r[0].lower() + r[1:] if r[:2] != r[:2].upper() else r
        for c in _v344_cuts(r):
            if c.lower() in seen:
                continue
            if _v344_resp_ok(c, plan, master, low):
                seen.add(c.lower())
                out.append((c, line))
                break
    return out


def _v344_letter_projects(plan: dict[str, Any], master: dict[str, Any], body: str) -> list[str]:
    """The projects the letter already names (the letter names at most two, so the closing proof comes from one of
    them or from Experience)."""
    low = str(body).lower()
    out = []
    for pid in plan.get("ranking") or []:
        p = master["projects"].get(pid, {})
        names = [p.get("resume_title", {}).get("name", ""), str(p.get("name", "")).split(" — ")[0], p.get("short_name") or ""] + list(p.get("letter_aliases") or [])
        names += {"tailor_pipeline": ["LLM engine", "LLM pipeline"], "fraud": ["fraud"], "pintos": ["Pintos"]}.get(pid, [])
        if any(n and n.lower() in low for n in names):
            out.append(pid)
    return out


def _v344_proof_pool(plan: dict[str, Any], master: dict[str, Any], body: str = "") -> list[str]:
    """Proofs Jay can cite: a closing proof from a project the letter names (selected evidence first) or from
    Experience on the page."""
    proofs = master.get("cover_letter_bank", {}).get("closing_proofs", {})
    ranking = _v344_letter_projects(plan, master, body) if body else list(plan.get("ranking") or [])
    omitted = " ".join(plan.get("_v343_omitted_exp_bullets") or [])
    pre = {"ledgerflow": "ledger.", "launchops": "launchops.", "ripple": "ripple.", "pintos": "pintos.", "tailor_pipeline": "tailor.", "fraud": "fraud.", "goingonce": "goingonce."}
    sel = {e for pid in ranking for _v, e in _v33_selected_evidence(plan, pid)}
    pool = [k for k in proofs if not k.startswith("_") and (k.startswith("exp.") or any(k.startswith(pre.get(pid, "~")) for pid in ranking))]
    if "Go Digital" in omitted or "ETL workflow" in omitted:
        pool = [k for k in pool if k != "exp.godigital"]
    return sorted(pool, key=lambda k: (0 if k in sel or k.startswith("exp.") else 1))


def _v344_kind_order(resp: str) -> list[tuple]:
    """Kinds the responsibility names: its object first (the words after the leading verbs), then its verbs; permissions
    and embedded lead when named anywhere."""
    toks = resp.split()
    i = 0
    while i < len(toks) and (_v344_base_verb(toks[i]) or toks[i].lower().rstrip(",") in ("and", "or", "help")):
        i += 1
    obj, verbs = " ".join(toks[i:]), " ".join(toks[:i])
    hits = []
    for j, c in enumerate(_V344_KINDS):
        mo, mv = c[1].search(obj), c[1].search(verbs)
        if mo or mv:
            hits.append((0 if c[0] in ("permissions", "embedded") else (1 if mo else 2), mo.start() if mo else (mv.start() if mv else 0), j, c))
    return [h[3] for h in sorted(hits, key=lambda h: h[:3])]


def _v344_pick_proof(resp: str, plan: dict[str, Any], master: dict[str, Any], body: str, used: set[str] | None = None, strict: bool = False) -> tuple[str, str, str]:
    proofs = master.get("cover_letter_bank", {}).get("closing_proofs", {})
    pool = _v344_proof_pool(plan, master, body)
    by_id = _v347_on("proof_on_page_v349")   # v3.4.9a fix 7: the proof's bullet is on the page, checked by evidence id
    if by_id:
        on_page = v349_page_evidence(plan, master)
        pool = [e for e in pool if v349_proof_eid(e) in on_page]
        sib_of = v349_proof_siblings(proofs, pool) if V349_CTX.get("sib") else {}   # fix 7b: another on-page proof of that project
    letter_sent = master.get("cover_letter_bank", {}).get("letter_sentences", {})
    page_nums = set(re.findall(r"\d[\d,.]*\d|\d", " ".join(str(b.get("text", "")) for bs in (plan.get("bullets") or {}).values() for b in bs if isinstance(b, dict))
                                + " " + " ".join(str(x) for r in master.get("experience", []) for x in r.get("bullets", []))))

    def repeats(eid):
        if not by_id and any(n not in page_nums for n in re.findall(r"\d[\d,.]*\d|\d", proofs[eid])):
            return True   # every letter number appears on the resume
        if closing_repeats_letter(proofs[eid], body):
            return True
        return any(isinstance(s, str) and len(s) > 20 and s in body for v in letter_sent.values() if isinstance(v, dict) for k, s in v.items() if k == eid)
    order = _v344_kind_order(resp)
    if strict:
        order = order[:2]
    elif order:
        order = order + [c for c in _V344_KINDS if c[0] == "testing" and c not in order]
    flags = {"permissions": plan.get("_v342_permissions_jd"), "embedded": plan.get("_v342_systems_jd"), "testing": plan.get("_v342_testing_jd") or True}
    if not order and not strict:
        order = [c for c in _V344_KINDS if flags.get(c[0])]
    # v3.4.5 (item 10): relevance beats novelty. When the posting's lead proof (permissions) is already in the letter,
    # a related fact from the same project comes first, never an unrelated one.
    related = proofs.get("_related") or {}
    lead = next((c for c in _V344_KINDS if c[0] == "permissions"), None) if flags.get("permissions") else None
    if lead and lead not in order[:1]:
        sib = [r for e in lead[2] if e in pool and e in proofs and repeats(e) for r in related.get(e, [])]
        if sib:
            order = [("permissions", lead[1], sib)] + order
    for kind, _rx, eids in order:
        for eid in eids:
            if eid in pool and eid in proofs and eid not in (used or set()):
                if not repeats(eid):
                    return kind, eid, proofs[eid]
                for r in related.get(eid, []):
                    if r in pool and r in proofs and not repeats(r) and r not in (used or set()):
                        return kind, r, proofs[r]
            elif by_id and eid not in pool:
                for r in sib_of.get(eid, []):
                    if r in proofs and not repeats(r) and r not in (used or set()):
                        return kind, r, proofs[r]
    return "", "", ""


def _v344_connector(resp: str, company: str, proof: str = "") -> str:
    if re.search(r"\bbuild\w*", resp + " " + proof, re.I) or re.search(r"\bbuilt\b", proof):
        return "drawing on"
    return ("building on", "drawing on")[sum(map(ord, company)) % 2]


def _v344_where(company_ref: str) -> str:
    return {"your team": "on your team", "your client": "for your client"}.get(company_ref, f"at {company_ref}")


def closing_problems(c: str, company: str = "") -> list[str]:
    """v3.4.4 closing validation: one sentence, <= 30 words (a model-written closing may run to 36), no "build ...
    building on", no clause that ends mid-phrase."""
    probs = []
    s = re.sub(r"\s+", " ", str(c or "")).strip()
    if not s.endswith(".") or len(re.split(r"(?<=[.!?])\s+(?=[A-Z])", s)) != 1:
        probs.append("not one sentence ending with a period")
    if re.search(r"\bbuild\w*\b.*\bbuilding on\b", s, re.I):
        probs.append("\"build ... building on\"")
    head = re.split(r",\s+(?:building on|drawing on|backed by|bringing)\b", s)[0]
    head = re.sub(r"\s+(?:at|on|for)\s+(?:your team|your client|" + re.escape(company or "~~") + r")\s*$", "", head)
    if _V344_DANGLE.search(head):
        probs.append("ends mid-phrase")
    if company and company not in ("your team", "your client") and company not in s and company.rstrip(".") not in s:
        probs.append("company not named in full")
    return probs


def _v344_closing(plan: dict[str, Any], master: dict[str, Any], raw_jd: str, company_ref: str, body: str, budget: int = 30, exclude_resp: set[str] | None = None) -> tuple[str, dict[str, Any]]:
    if _v347_on(V349C_CLOSING_FLAG) and not V349C_CTX.get("closing_inner"):   # v3.4.9c run 7 / fix1: grounded responsibility
        V349C_CTX["closing_inner"] = True
        try:
            return v349c_grounded_closing(plan, master, raw_jd, company_ref, body, budget, plain=False, exclude=set(exclude_resp or ()))
        finally:
            V349C_CTX["closing_inner"] = False
    if _v347_on("proof_on_page_v349") and V349_CTX.get("sib") is None:   # v3.4.9a fix 7b: before the role-family closing,
        V349_CTX["sib"] = False                                          # search again with same-project on-page proofs
        try:
            s, inf = _v344_closing(plan, master, raw_jd, company_ref, body, budget, exclude_resp)
            if inf.get("family"):
                V349_CTX["sib"] = True
                s2, inf2 = _v344_closing(plan, master, raw_jd, company_ref, body, budget, exclude_resp)
                if not inf2.get("family"):
                    s, inf = s2, dict(inf2, proof_sibling_v349=True)
        finally:
            V349_CTX["sib"] = None
        return s, inf
    if (_v347_on("closing_proof_map_v348") or _v347_on("closing_specific_v348")) and not _V348C_C.get("inner"):   # v3.4.8c C1 / C2
        return v348c_closing(plan, master, raw_jd, company_ref, body, budget, exclude_resp)
    where = _v344_where(company_ref)
    cands = closing_candidates(raw_jd, plan, master, body)
    # pass 1: the proof matches what the responsibility names; pass 2: any matching kind, then the testing proofs
    tries = [(r, l, True) for r, l in cands] + [(r, l, False) for r, l in cands]
    tries = [(r, l, st, n) for r, l, st in tries for n in (1, 4)]
    for resp, line, strict, n_proofs in tries:
        if exclude_resp and resp in exclude_resp:
            continue
        for c in _v344_cuts(resp):
            if not _v344_resp_ok(c, plan, master, body.lower()) or not _v345_clause_end_ok(c, line):
                continue
            if _v347_on(V349C_CLOSING_FLAG) and exclude_resp and c in exclude_resp:   # v3.4.9c run 7: a set-aside responsibility
                continue
            used: set[str] = set()
            for _ in range(n_proofs):   # the best-matching proof with any cut first; then the next proofs
                # the proof matches what the closing says (the cut), then, loosely, the whole posting line
                kind, eid, proof = _v344_pick_proof(c, plan, master, body, used=used, strict=strict)
                if not proof and not strict:
                    kind, eid, proof = _v344_pick_proof(resp, plan, master, body, used=used, strict=False)
                if not proof:
                    break
                used.add(eid)
                conn = _v344_connector(c, company_ref, proof)
                s = f"I want to {c} {where}, {conn} {proof}."
                if len(s.split()) <= min(budget, 30) and not closing_problems(s, company_ref if where.startswith("at ") else ""):
                    return s, {"rule": "v3.4.4", "responsibility": c, "jd_line": line, "proof": eid, "proof_kind": kind, "_proof": proof, "connector": conn}
    # nothing qualifies: the role-family closing (the applicant is the actor), with a proof the letter has not used
    if os.environ.get("V344_DEBUG"):
        dbg = {"cands": [[r, [k[0] for k in _v344_kind_order(r)], _v344_pick_proof(r, plan, master, body)[1]] for r, _l in cands],
               "role_text": _v342_role_text(raw_jd)[:40], "pool": _v344_proof_pool(plan, master, body)}
        pathlib.Path(os.environ["V344_DEBUG"]).write_text(json.dumps(dbg, indent=1))
    fam = str(plan.get("role_family", ""))
    tmpl = master.get("cover_letter_bank", {}).get("family_closing", {}).get(fam, "build dependable, well-tested software with the team at {company}")
    poss = company_ref + ("'" if company_ref.endswith("s") else "'s")
    what = tmpl.replace("{company}'s", poss).replace("{company}", company_ref)
    if company_ref in ("your team", "your client"):
        what = what.replace("with the team at your team", "with your team").replace("at your client", "for your client")
    conn = _v344_connector(what, company_ref)
    used: set[str] = set()
    for _ in range(8):
        kind, eid, proof = _v344_pick_proof(" ".join(_v342_role_text(raw_jd)[:6]), plan, master, body, used=used)
        conn = _v344_connector(what, company_ref, proof)
        s = f"I want to {what}, {conn} {proof}." if proof else f"I want to {what}."
        if not proof or len(s.split()) <= min(budget, 30):
            break
        used.add(eid)
    return s, {"rule": "v3.4.4", "responsibility": "", "proof": eid, "proof_kind": kind, "_proof": proof, "connector": conn, "family": True}


# --- E17 / E18 / A. letter assembly ---------------------------------------------------------------------------------

_V344_LETTER_MAX = 200
_V344_LETTER_FRAME = 7   # "Dear Hiring Manager," + "Sincerely," + "Jay Niketan Pathare"


def _v344_words(paras: list[str]) -> int:
    return sum(len(p.split()) for p in paras) + _V344_LETTER_FRAME


_compose_bank_cover_letter_v344 = compose_bank_cover_letter


def compose_bank_cover_letter(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[dict[str, Any]]:
    closing_on = _v347_on(V349C_CLOSING_FLAG)
    if (v349c_plain_on() or closing_on) and not V349C_CTX.get("plain_inner"):   # v3.4.9c run 8 / fix1 (written letter apart)
        V349C_CTX["plain_inner"] = True
        try:
            _V347_FLAGS[V349C_CLOSING_FLAG] = False   # fix1: page decisions see the run 6 letter (closing_v349c off)
            failures = compose_bank_cover_letter(plan, master, raw_jd)
        finally:
            _V347_FLAGS[V349C_CLOSING_FLAG] = closing_on
            V349C_CTX["plain_inner"] = False
        if plan.get("_cover_letter_mode") != "bank" or not plan.get("cover_letter_paragraphs"):
            return failures
        if not v349c_plain_on():   # fix1, closing_v349c with run 7 letters: compose the written letter again, then restore the plan
            snap = deepcopy(plan)
            V349C_CTX["plain_inner"] = True
            try:
                out_fail = compose_bank_cover_letter(plan, master, raw_jd)
                out = {"paragraphs": list(plan.get("cover_letter_paragraphs") or []), "closing_info": dict(plan.get("_v342_closing") or {})}
            finally:
                V349C_CTX["plain_inner"] = False
                plan.clear()
                plan.update(snap)
            plan["_v349c_out"] = dict(out, before=list(plan["cover_letter_paragraphs"]))
            return failures + [f for f in out_fail if f not in failures]
        pl = v349c_plain_letter(plan, master, raw_jd, list(plan["cover_letter_paragraphs"]))
        plan["_v349c_plain"] = dict(pl, before=list(plan["cover_letter_paragraphs"]))   # written by build_cover_letter
        probs = v349c_plain_problems(pl["paragraphs"], plan, master, pl)
        plan["_v349c_plain"]["problems"] = probs
        if probs:
            failures.append(fail("v349c_plain_letter", "cover_letter", probs, "three plain paragraphs, 120-154 body words, posting connection, at most one result, no tool names / digits / we-our-us",
                                 "Pipeline defect: report it."))
        return failures
    if _v347_on("copy_rule_v349"):   # v3.4.9a fix 8: no "our / we / us" from the posting
        voice = v349_hook_voice(plan)
        if voice:
            return voice
    if _v347c_active(plan):   # v3.4.7c C1: the letter is written as before the Fleet swap; only its Fleet sentence changes
        with _v347c_pre_swap(plan):
            failures = compose_bank_cover_letter(plan, master, raw_jd)
        return failures + _v347c_letter_swap(plan, master)
    if v348b_on() and not plan.get("_v348b_mode"):   # v3.4.8b D3: the logistics sentence names December 2026 + February 2027
        return _v348b_compose(plan, master, raw_jd)
    failures = _compose_bank_cover_letter_v344(plan, master, raw_jd)
    paras = list(plan.get("cover_letter_paragraphs") or [])
    if not paras or plan.get("_cover_letter_mode") != "bank":
        return failures
    # v3.4.6 (item 3): the internship logistics sentence states start availability too (cover_letter_rules.p2)
    paras = [p.replace(_V346_INTERN_LOGISTICS, _V346_INTERN_LOGISTICS_START) for p in paras]
    if plan.get("_v348b_mode") == "early":   # v3.4.8b: a letter the longer sentence pushes past 200 words is refitted
        paras = v348b_letter(paras)
    if _v347_on("relocation_fix"):   # v3.4.7a A1: Buffalo, NY only is local; remote postings never mention relocation
        paras = _v347_relocation(paras, plan, raw_jd)
    old = plan.get("_v342_closing") or {}
    old_text = str(old.get("text") or "")
    if old_text and old_text in paras[-1]:
        paras[-1] = paras[-1].replace(old_text, "").strip()
    # E18. RIPPLE wording (never "RIPPLE, whose AI-generated code")
    paras = [re.sub(r"RIPPLE, whose AI-generated code I checked against its full test suite", "RIPPLE, which Claude Code helped me write and I checked with its 241-test suite", p) for p in paras]
    # v3.4.5 (item 5): on ML / AI / agent postings the LLM engine is introduced by its failover or claim-check fact
    paras = _v345_engine_intro(paras, plan, master, raw_jd)
    # E16. one pull-request sentence only
    if any("pull requests" in p for p in paras[:1]):
        paras = [paras[0]] + [" ".join(s for s in re.split(r"(?<=[.!?])\s+", p) if "pull requests" not in s) for p in paras[1:]]
    app = plan.get("application", {})
    company = str(app.get("company", "")).strip()
    # the role title already names the company ("Macy's 2027 Tech ... role at Macy's"): drop the repeat
    role_t = str(app.get("role", "") or "")
    if company and not company_is_placeholder(company) and re.search(r"(?<!\w)" + re.escape(company.rstrip(".")) + r"(?!\w)", role_t):
        paras[0] = paras[0].replace(f"{role_t} role at {company}.", f"{role_t} role.", 1)
    agency = "your client" in " ".join(paras)
    company_ref = "your client" if agency else ("your team" if company_is_placeholder(company) else company)
    company_ref = company_ref.rstrip(".") if company_ref.endswith("..") else company_ref
    x33 = master.get("cover_letter_bank", {}).get("experience_v33", {})
    letter_sents = [s for v in (plan.get("_v342_letter_sentences") or {}).values() for s in v]

    def trim_body(ps: list[str], need: int) -> list[str]:
        """Shorten the body until it leaves `need` words for the closing: the short Thesis sentence first, then an
        extra evidence sentence from the project with the most sentences (each project keeps one)."""
        ps = list(ps)
        if _v344_words(ps) + need <= _V344_LETTER_MAX:
            return ps
        if x33.get("thesis_ops") and x33["thesis_ops"] in ps[0] and x33.get("thesis_ops_short"):
            ps[0] = ps[0].replace(x33["thesis_ops"], x33["thesis_ops_short"])
        for _ in range(3):
            if _v344_words(ps) + need <= _V344_LETTER_MAX:
                break
            sents = re.split(r"(?<=[.!?])\s+", ps[-1])
            cands = [s for s in sents if s in letter_sents]
            if len(cands) < 2:
                break
            by_pid = {}
            for pid, ss in (plan.get("_v342_letter_sentences") or {}).items():
                for s in ss:
                    if s in sents:
                        by_pid.setdefault(pid, []).append(s)
            pid = max(by_pid, key=lambda p: (len(by_pid[p]), list(by_pid).index(p)))
            if len(by_pid[pid]) < 2:
                break
            drop = by_pid[pid][-1]
            ps[-1] = " ".join(s for s in sents if s != drop)
            plan.setdefault("_v344_letter_trimmed", []).append(drop)
        return ps

    cl = plan.get("cover_letter") if isinstance(plan.get("cover_letter"), dict) else {}
    model_close = re.sub(r"\s+", " ", str((cl or {}).get("closing", "") or "")).strip()
    info: dict[str, Any] = {}
    closing = ""
    if model_close and old.get("source") == "plan" and old_text == model_close:
        body = " ".join(paras)
        probs = closing_problems(model_close, company_ref if company_ref not in ("your team", "your client") else "")
        rep = closing_repeats_letter(model_close.split(",", 1)[-1], body)
        if not probs and not rep:
            closing, info = model_close, {"rule": "v3.4.4", "source": "plan"}
        else:
            plan.setdefault("_v344_warnings", []).append({"type": "cover_letter_closing_replaced", "reason": "; ".join(probs + [f"repeats a letter proof ({', '.join(rep)})" if rep else ""]).strip("; ")})
    if not closing:
        for need in (30, 26, 22):
            ps = trim_body(paras, need)
            room = _V344_LETTER_MAX - _v344_words(ps)
            s, inf = _v344_closing(plan, master, raw_jd, company_ref, " ".join(ps), budget=min(30, room))
            if len(s.split()) <= room:
                paras, closing, info = ps, s, dict(inf, source="auto")
                break
        if not closing:
            s, inf = _v344_closing(plan, master, raw_jd, company_ref, " ".join(paras), budget=30)
            closing, info = s, dict(inf, source="auto")
    closing = _v343_fix_dots(closing)
    # v3.4.5 (item 9): the final closing gets the shape and repeat checks again (model-written and auto alike)
    _ref = company_ref if company_ref not in ("your team", "your client") else ""
    _probs = closing_problems(closing, _ref)
    _proof = str(info.get("_proof") or (closing.split(", ", 1)[-1] if ", " in closing else ""))
    _rep = closing_repeats_letter(_proof, " ".join(paras)) if _proof and not info.get("family") else []
    if _probs or _rep:
        failures.append(fail("cover_letter_closing_final_check", "cover_letter.closing", closing, "one complete sentence that ends at a clause boundary and repeats no letter proof",
                             "Pipeline defect: report it (" + "; ".join(_probs + [f"repeats {', '.join(_rep)}" if _rep else ""]).strip("; ") + ")."))
    paras[-1] = (paras[-1] + " " + closing).strip()
    plan["cover_letter_paragraphs"] = [_v343_fix_dots(p) for p in paras]
    plan["_v342_closing"] = dict(info, text=closing)
    if info.get("jd_line"):
        _v344_change(f"Closing responsibility \"{info.get('responsibility')}\" with proof {info.get('proof')} ({info.get('proof_kind')})", info["jd_line"])
    if _v344_words(plan["cover_letter_paragraphs"]) > _V344_LETTER_MAX:
        failures.append(fail("cover_letter_over_200_words", "cover_letter", _v344_words(plan["cover_letter_paragraphs"]), "<= 200 words including greeting and sign-off",
                             "Pipeline defect: report it (the script trims the letter)."))
    if re.search(r"whose AI-generated code", " ".join(plan["cover_letter_paragraphs"])):
        failures.append(fail("cover_letter_ripple_wording", "cover_letter", "RIPPLE, whose AI-generated code", "Claude Code helped write RIPPLE; Jay checked its output with the 241-test suite", "Pipeline defect."))
    return failures


_validate_closing_v342_v344 = validate_closing_v342


def validate_closing_v342(closing: str, plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[dict[str, Any]]:
    """A model-written closing (item 6): one sentence <= 36 words, 4+ consecutive words from a responsibility line,
    the company named in full and the proof project named. It ending mid-phrase also fails."""
    out = _validate_closing_v342_v344(closing, plan, master, raw_jd)
    c = re.sub(r"\s+", " ", str(closing or "")).strip()
    company = str(plan.get("application", {}).get("company", "")).strip()
    if c and company and not company_is_placeholder(company) and company not in c and company.rstrip(".") not in c:
        out.append(fail("cover_letter_closing_company", "cover_letter.closing", c, f"names the company in full ({company})", "Name the company exactly as the posting does."))
    if c and _V344_DANGLE.search(re.split(r",\s+(?:building on|drawing on|backed by|bringing)\b", c)[0]):
        out.append(fail("cover_letter_closing_shape", "cover_letter.closing", c, "no clause that ends mid-phrase", "Rewrite the closing as one complete sentence."))
    return out


_write_judge_packet_v344 = write_judge_packet


def write_judge_packet(out_dir: Path, plan: dict[str, Any], master: dict[str, Any], raw_jd: str, names: dict[str, str], report: dict[str, Any]) -> None:
    """The packet shows the posting as the pipeline read it: job-board widgets removed (item 20) and markdown heading
    marks dropped, so a pasted "## Description" line cannot split the judge batch."""
    jd = re.sub(r"(?m)^\s*#{1,6}\s+", "", clean_jd_text(str(raw_jd)))
    out = _write_judge_packet_v344(out_dir, plan, master, jd, names, report)
    _v345_packet_pdf_text(Path(out_dir))   # v3.4.5 (item 16): layout-aware PyMuPDF text, so dates and GPA stay in Education
    return out


# --- B / H / I. post-run: tracker, "..", preflight, verify changes -----------------------------------------------

V344_TRACKER_COLUMNS = ["Company", "Role", "Date Applied", "Location", "Projects Used", "Fit (High/Medium/Low)", "Resume File Name", "Status", "Source", "Outcome Date", "Blockers"]


def tracker_row_v344(row: dict[str, Any]) -> dict[str, Any]:
    out = {c: row.get(c, "") for c in V344_TRACKER_COLUMNS}
    out["Status"] = "Applied"
    return _v344_fix_dots_obj(out)


def preflight_v344(report: dict[str, Any], plan_fields: dict[str, Any] | None = None) -> dict[str, Any]:
    """Required (must / high) JD terms that the page shows only in Skills or a project heading."""
    only = []
    for c in report.get("ats_coverage", []) or []:
        if str(c.get("priority", "")).lower() not in ("must", "high") or not c.get("supported"):
            continue
        surf = {str(c.get("surface", ""))} | {str(x) for x in c.get("also_in", []) or []}
        if surf & {"bullet", "experience", "education/experience", "tagline"} or not (surf & {"skills", "header"}):
            continue
        only.append({"term": c.get("term"), "jd": c.get("verbatim"), "shown_in": sorted(x for x in surf if x)})
    return {"skills_or_heading_only": only}


_main_v3_1_v342_inner = _main_v3_1_v342


def _main_v3_1_v342():
    """Each (re)build starts a fresh change log (the new-grad slot fallback rebuilds the package)."""
    _V344_CTX["changes"] = []
    _V344_CTX["preflight_prefer"] = {}
    return _main_v3_1_v342_inner()


_main_v3_1_v344 = main_v3_1


def main_v3_1() -> int:
    argv = list(sys.argv)
    if not V349B_CTX.get("outer"):   # v3.4.9b: the build, then the Letter fit steps
        rc = v349b_main(argv)
        if v349c_page_wanted(argv, V349C_SPACING_FLAG):   # v3.4.9c run 5: adaptive spacing on the finished page
            v349c_spacing(argv)
        return rc
    if not _V347C_CTX.get("inner"):   # v3.4.7c C1: a failed Fleet swap retries another bullet, then keeps the Fleet bullet
        return _v347c_retry(argv)
    try:   # v3.4.7a: per-fix switches (master.json v347_flags)
        v347_load_flags(json.loads(Path(argv[argv.index("--master") + 1]).read_text(encoding="utf-8")))
    except Exception:
        v347_load_flags(None)
    _V347_CTX.update({"heading": {}, "company": ""})
    _V344_CTX["changes"] = []
    _V344_CTX["jd_removed"] = []
    _V344_CTX["no_preflight"] = False
    _V345_CTX.update({"override": {}, "no_coursework": False, "coursework_on": False, "stack_gaps": [], "stack_terms": [], "jd_named": []})
    _V347C_CTX.update({"swaps": [], "kept": [], "letter": {}})
    V349_CTX["ranking"] = None
    V349C_CTX["must"] = None   # v3.4.9c run 6
    V349_CTX["fleet"] = None
    V349_CTX["page_evidence"] = None
    rc = _main_v3_1_v344()
    try:
        out_dir = Path(argv[argv.index("--out-dir") + 1])
    except (ValueError, IndexError):
        return rc
    rp = out_dir / "report.json"
    if not rp.exists():
        return rc
    # 15. a preflight-preferred bullet that costs the page its one-page buffer is dropped: rebuild without it
    try:
        fails = {f.get("type") for f in json.loads(rp.read_text(encoding="utf-8")).get("failures", [])}
    except Exception:
        fails = set()
    if _V345_CTX.get("coursework_on") and fails & {"page_count", "v33_page_buffer"}:
        # v3.4.5 (item 15): the optional coursework line never costs the page its one-page buffer
        _V345_CTX["no_coursework"] = True
        _V344_CTX["jd_removed"] = []
        _V343_FLAGS.pop("slot_start", None)
        sys.argv = list(argv)
        rc = _main_v3_1_v344()
        _V345_CTX["no_coursework"] = False
        _V344_CTX["changes"].append({"change": "Coursework line dropped: it did not fit one page with the buffer", "jd_line": _V345_CTX.get("coursework_line", "")})
        try:
            fails = {f.get("type") for f in json.loads(rp.read_text(encoding="utf-8")).get("failures", [])}
        except Exception:
            fails = set()
    if _V344_CTX.get("preflight_prefer") and fails & {"page_count", "v33_page_buffer", "required_ats_terms_exceed_skill_budget"}:
        dropped = ", ".join(_V344_CTX["preflight_prefer"])
        _V344_CTX["no_preflight"] = True
        _V344_CTX["jd_removed"] = []
        _V343_FLAGS.pop("slot_start", None)
        sys.argv = list(argv)
        rc = _main_v3_1_v344()
        _V344_CTX["changes"].append({"change": f"Preflight preference dropped ({dropped}): the preferred bullet did not fit one page with the buffer", "jd_line": dropped})
    try:
        rep = json.loads(rp.read_text(encoding="utf-8"))
    except Exception:
        return rc
    tp = out_dir / "tracker_row.json"
    if tp.exists():
        row = tracker_row_v344(json.loads(tp.read_text(encoding="utf-8")))
        if _v347_on("company_key_v349"):   # v3.4.9a fix 10: the key an existing tracker row is matched on
            row["company_key"] = v349_company_key(row.get("Company", ""))
        tp.write_text(json.dumps(row, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        rep["tracker_row"] = row
    op = out_dir / "outreach.json"
    if op.exists():
        op.write_text(json.dumps(_v344_fix_dots_obj(json.loads(op.read_text(encoding="utf-8"))), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    for k in ("outreach", "cover_letter"):
        if k in rep:
            rep[k] = _v344_fix_dots_obj(rep[k])
    for p in out_dir.glob("*_Cover_Letter.txt"):
        t = p.read_text(encoding="utf-8")
        if _V343_DOTS.search(t):
            p.write_text(_v343_fix_dots(t), encoding="utf-8")
        n = len(t.split())
        rep.setdefault("cover_letter", {})["words_total"] = n
        if n > _V344_LETTER_MAX and rep.get("status") == "PASS" and not rep.get("skip"):
            rep["status"] = "FAIL"
            rep.setdefault("failures", []).append(fail("cover_letter_over_200_words", p.name, n, "<= 200 words including greeting and sign-off", "Pipeline defect: report it."))
    if not rep.get("skip"):
        rep["preflight_v344"] = preflight_v344(rep)
        pref = _V344_CTX.get("preflight_prefer") or {}
        for x in rep["preflight_v344"]["skills_or_heading_only"]:
            x["bullet_evidence"] = "preferred: " + ", ".join(pref[x["term"]]) if x["term"] in pref else "no bank bullet or approved variant names it"
    rep["verify_changes_v344"] = list(_V344_CTX["changes"])
    if _V344_CTX["jd_removed"]:
        rep["jd_widgets_removed_v344"] = list(_V344_CTX["jd_removed"])
    _v345_post_run(rep, out_dir, argv)
    _v347_post_run(rep, out_dir, argv)
    _v347b_post_run(rep, out_dir, argv)
    _v347c_post_run(rep, out_dir, argv)
    _v348_post_run(rep, out_dir, argv)   # v3.4.8a O2
    _v348b_post_run(rep, out_dir, argv)   # v3.4.8b: Education date and graduation wording
    _v348c_post_run(rep, out_dir, argv)   # v3.4.8c: W / F / S / J / C logs and checks
    v349_post_run(rep, out_dir, argv)   # v3.4.9a logs
    v349b_post_run(rep, out_dir, argv)   # v3.4.9b format log
    rp.write_text(json.dumps(rep, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if rep.get("status") != "PASS" and rc == 0:   # v3.4.6: a post-run validator failure fails the build
        rc = 2
    return rc


# ===========================================================================
# v3.4.5 layer (2026-10-16). New helper names only: every fix is made in the FINAL definition of the function it
# changes (earlier copies are dead code), so no name gains another definition.
#  A. JD parsing: "About the Team / Role / Job / Position" ends a company intro; literal "Stack:" / "Tech stack:" /
#     "Technologies:" lines count in every section; currency codes in salary text are never requirements; stack-only
#     technologies Jay lacks are "stack gaps" (reported, never capping Fit); every JD-named supported skill shows.
#  B. Project selection: an auto override never inserts an avoided project or displaces preferred_projects[0]
#     without an explicit quoted LLM-evaluation / failover line; Fraud names IEEE-CIS; Go Digital only on data /
#     analytics / fintech / compliance postings; warehouse postings prefer GoingOnce's Fleet bullet.
#  C. Closing: the quoted span ends at a clause boundary of the posting line; complement-taking verbs dangle; the
#     final closing is checked for repeats; relevance beats novelty within the same project.
#  D. Experience / Skills / Education: ops themes for variant G; JD-named terms show; NoSQL -> MongoDB bullet;
#     coursework line on new-grad AI/ML postings; GPA inline and one right-aligned date per degree line.
#  F. Verify quotes only from role sections; UB-alum note asks for advice, not a referral; tracker failure banner.
# ===========================================================================
PIPELINE_VERSION = "v3.4.6"
_V345_CTX: dict[str, Any] = {"stack_gaps": [], "stack_terms": []}
_V345_STACK_LINE = re.compile(r"^[\s>*_\-•·]*(?:\*\*)?\s*(?:tech(?:nology)?\s+stack|stack|technologies)\s*(?:\*\*)?\s*:\s*(?:\*\*)?\s*(.+?)\s*$", re.I)
_V345_CURRENCY = re.compile(r"(?<![A-Za-z])(?:CAD|USD|EUR|GBP|AUD|INR|CHF|JPY|SGD|NZD)(?![A-Za-z])")
_V345_MONEY_LINE = re.compile(r"[$€£¥₹]\s?\d|\bsalary\b|\bcompensation\b|\bpay (?:range|scale|band)\b|\bbase pay\b|\bper (?:hour|year|annum)\b|\bequity\b|\bbonus\b", re.I)


def _v345_mask_currency(raw: str) -> str:
    """Salary lines lose their currency codes (CAD, USD, EUR...), so "$137,852 - $157,061 CAD" is never a requirement."""
    return "\n".join(_V345_CURRENCY.sub("", l) if _V345_MONEY_LINE.search(l) else l for l in str(raw).splitlines())


def _v345_stack_lines(raw: str) -> list[tuple[str, str]]:
    out = []
    for l in str(raw).splitlines():
        t = re.sub(r"\*\*|__", "", l).strip()
        m = _V345_STACK_LINE.match(t)
        if m and len(m.group(1).split()) <= 40:
            out.append((l, m.group(1)))
    return out


def _v345_req_key(term: str, master: dict[str, Any]) -> str:
    return _norm_term(str(term), master).casefold()


def _v345_stack_merge(reqs: list[dict[str, Any]], raw: str, master: dict[str, Any], title: str, parse) -> list[dict[str, Any]]:
    """A1 / A2: stack-line technologies Jay has become (medium) requirements wherever the line sits; ones he lacks that
    no other line asks for are stack gaps (reported in Notes, never capping Fit)."""
    stack = _v345_stack_lines(raw)
    _V345_CTX["stack_gaps"], _V345_CTX["stack_terms"] = [], []
    if not stack:
        return reqs
    lex = _lexicon(master)
    terms = []
    for _l, items in stack:
        for _pos, tok in _find_terms(items, lex):
            terms.append((tok, _norm_term(tok, master)))
    if not terms:
        return reqs
    drop = {l for l, _i in stack}
    rest = "\n".join(l for l in str(raw).splitlines() if l not in drop)
    other = {str(r.get("term", "")).casefold() for r in parse(rest, master, title)}
    have = {str(r.get("term", "")).casefold(): r for r in reqs}
    out = list(reqs)
    for tok, term in terms:
        k = term.casefold()
        _V345_CTX["stack_terms"].append(term)
        r = have.get(k)
        sup = r.get("supported") if r else master_supports_requirement(term, [term], master)
        if sup:
            if r is None:
                e = {"term": term, "verbatim": tok, "aliases": list(dict.fromkeys(_CANON_ALIAS.get(term, [term]))), "priority": "medium", "supported": True, "stack_line": True}
                out.append(e); have[k] = e
            else:
                r["stack_line"] = True
        elif k not in other:
            out = [x for x in out if str(x.get("term", "")).casefold() != k]
            have.pop(k, None)
            if tok not in _V345_CTX["stack_gaps"]:
                _V345_CTX["stack_gaps"].append(tok)
    return out



# --- B1 (item 4). auto ranking overrides --------------------------------------------------------------------------

_V345_LLM_EVAL_LINE = re.compile(
    r"\bllm (?:evaluation|evals?|benchmark\w*|reliability|observability|quality)\b|\bevals\b|\beval(?:uation)? (?:harness|framework|suite|pipeline)s?\b|"
    r"\bevaluat\w+ (?:of )?(?:the )?(?:llm|model|ai)[- ](?:generated )?(?:outputs?|responses?|generations?|answers?)\b|\bevaluat\w+ (?:of )?(?:llms?|large language models?)(?! agents?)\b|"
    r"\b(?:llm|model|provider) failover\b|\bfailover (?:between|across) (?:llm |model |ai )?providers\b|\bfallback (?:llms?|models?|providers?)\b|\bmulti-provider\b", re.I)


def _v345_llm_eval_line(raw_jd: str) -> str:
    """The posting line (role sections only) that explicitly asks for LLM evaluation or provider failover; generic
    words such as "cost", "reliability" or "evaluation" alone never count."""
    return next((l for l in _v342_role_text(raw_jd) if _V345_LLM_EVAL_LINE.search(l)), "")


def _v345_override_problem(raw_plan: dict[str, Any], master: dict[str, Any]) -> str:
    prof = role_family_profile(raw_plan, master) or {}
    info = raw_plan.get("_v342_llm_reliability") or {}
    pid, out = "tailor_pipeline", info.get("replaced", "")
    pref = list(prof.get("preferred_projects") or [])
    if pid in (prof.get("avoid_projects") or []):
        return f"inserts {pid}, which the {raw_plan.get('role_family')} family avoids"
    if pref and out == pref[0]:
        return f"displaces {out}, the {raw_plan.get('role_family')} family's first preferred project"
    return ""


def _v345_check_llm_override(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str, snap: dict[str, Any] | None) -> None:
    """B1: the v3.4.2 LLM-reliability override is auto-written; it may not insert an avoided project or displace the
    family's preferred_projects[0] unless a quoted posting line explicitly asks for LLM evaluation / provider failover."""
    info = raw_plan.get("_v342_llm_reliability")
    if not info or snap is None:
        return
    problem = _v345_override_problem(raw_plan, master)
    line = _v345_llm_eval_line(raw_jd)
    if problem and not line:
        raw_plan.clear(); raw_plan.update(snap)
        _V345_CTX["no_llm_rel"] = True
        try:
            _apply_auto_ranking_v342b(raw_plan, master, raw_jd)
        finally:
            _V345_CTX["no_llm_rel"] = False
        raw_plan["_v345_override"] = {"blocked": "v3.4.2 LLM-system reliability override (" + ", ".join(info.get("signals", [])) + ")", "why": problem + "; no posting line explicitly asks for LLM evaluation or provider failover"}
    else:
        raw_plan["_v345_override"] = {"reason": raw_plan.get("ranking_override_reason", ""), "displaced": info.get("replaced", ""), "jd_line": line}
    _V345_CTX.setdefault("override", {}).update(raw_plan["_v345_override"])


_V345_SAFETY = re.compile(r"\bcontent (?:quality|safety|moderation)\b|\btrust (?:and|&) safety\b|\bmoderation\b|\bharmful content\b|\babuse\b|\bspam\b|\bpolicy[- ]violating\b", re.I)


def _v345_goingonce_third(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str, auto: bool) -> None:
    """Item 4: on agent / content-safety ML postings GoingOnce (a multi-agent system) beats the LLM engine as #3,
    unless a posting line explicitly asks for LLM evaluation / provider failover."""
    ranking = list(raw_plan.get("ranking") or [])
    if not auto or len(ranking) != 3 or ranking[2] != "tailor_pipeline" or "goingonce" in ranking or "goingonce" not in master.get("projects", {}):
        return
    if str(raw_plan.get("role_family", "")) not in ("data_science_ml", "ai_llm") or _v345_llm_eval_line(raw_jd):
        return
    lines = _v342_role_text(raw_jd)
    agent = sum(1 for l in lines if _V344_AGENT_LINE.search(l) or re.search(r"\bllm[- ]powered agents?\b|\bllm agents?\b", l, re.I))
    safety = sum(1 for l in lines if _V345_SAFETY.search(l))
    if agent < 2 and not (agent and safety):
        return
    scores = dict(raw_plan.get("project_scores") or {})
    t = scores.get("tailor_pipeline", 0.0)
    scores["goingonce"], scores["tailor_pipeline"] = round(t + 0.01, 3), round(min(t, scores.get(ranking[1], t)) - 0.5, 3)
    raw_plan["project_scores"] = scores
    raw_plan["ranking"] = ranking[:2] + ["goingonce"]
    raw_plan["_v345_override"] = dict(raw_plan.get("_v345_override") or {}, goingonce_third="GoingOnce replaces the LLM engine as #3 (agent / content-safety ML posting)")
    _V345_CTX.setdefault("override", {}).update(raw_plan["_v345_override"])
    _v344_change("Ranking: GoingOnce replaces the LLM engine as #3 (agent / content-safety ML posting; no line asks for LLM evaluation or provider failover)",
                 next((l for l in lines if _V345_SAFETY.search(l)), "") or next((l for l in lines if _V344_AGENT_LINE.search(l)), ""))
    if str(raw_plan.get("ranking_override_reason", "")).startswith("v3.4.2 LLM-system reliability"):
        raw_plan["ranking_override_reason"] = ""



# --- items 6 / 8 / 14. bank preferences ------------------------------------------------------------------------------

_V345_IEEE_PREFER = ["fraud.sage.b", "fraud.sage.a"]
_V345_FRAUD_ML_PREFER = ["fraud.edgeabl.a", "fraud.leak.a"]
_V345_ML_LINE = re.compile(r"\bmachine learning\b|\bml\b|\bmodels?\b|\bdeep learning\b|\bpytorch\b|\btensorflow\b|\bmodel evaluation\b", re.I)
_V345_WAREHOUSE = re.compile(r"\bwarehous\w*|\blogistic\w*|\bsupply chain\b|\bfulfil+ment\b|\bcold storage\b|\bfreight\b|\bdistribution cent\w+|\binventory\b|\btransportation\b|\bshipping\b", re.I)


def _v345_ml_line(raw: str) -> str:
    return next((l for l in _v342_role_text(raw) if _V345_ML_LINE.search(l)), "")


def _v345_ml_posting(raw_plan: dict[str, Any], raw: str) -> bool:
    title = str(raw_plan.get("application", {}).get("role", ""))
    if re.search(r"\bmachine learning\b|\bml\b|\bdeep learning\b|\bdata scien\w+|\bapplied scien\w+|\bcomputer vision\b", title, re.I):
        return True
    vec = raw_plan.get("_jd_theme_vector") or {}
    return str(raw_plan.get("role_family", "")) == "data_science_ml" and vec.get("ml_dl", 0) >= 0.1


def _v345_names_ieee(ids: list[str], bank: dict[str, Any]) -> bool:
    texts = {v.get("id"): str(v.get("text", "")) for v in bank.get("projects", {}).get("fraud", [])}
    return any("IEEE-CIS" in texts.get(i, "") for i in ids)


def _v345_bank_prefer(raw_plan: dict[str, Any], raw: str, ranking: list[str]) -> list[str]:
    out = []
    if "fraud" in ranking:
        out += _V345_IEEE_PREFER
        if _v345_ml_posting(raw_plan, raw):
            out += _V345_FRAUD_ML_PREFER
            _v344_change("Fraud: the edge-type ablation and leakage-control bullets are preferred (ML posting)", _v345_ml_line(raw) or str(raw_plan.get("application", {}).get("role", "")))
    if "goingonce" in ranking:
        w = next((l for l in _v342_role_text(raw) if _V345_WAREHOUSE.search(l)), "")
        title = str(raw_plan.get("application", {}).get("role", ""))
        fire = w or _V345_WAREHOUSE.search(title) or _V345_WAREHOUSE.search(str(raw_plan.get("application", {}).get("company", "")))
        if _v347_on("bullet_relevance"):   # v3.4.7b B4: "shipping ML systems" is not logistics; supply-chain / warehouse / fleet postings only
            w = v347b_logistics_line(raw_plan, raw)
            fire = bool(w)
            if not fire and V347B_AI_PREFER and v347b_ai_posting(raw_plan, _v342_role_text(raw)):
                out += [x for x in _V347B_AI_GOINGONCE if x.endswith(".a")]
        if fire:
            out.append("goingonce.fleet.a")
            _v344_change("GoingOnce: the Fleet agent bullet is preferred (warehouse / logistics posting)", w or title)
    if "launchops" in ranking:
        n = next((l for l in _v342_role_text(raw) if re.search(r"\bnosql\b|\bmongo\w*", l, re.I)), "")
        if n:
            out.append("launchops.quiz.a")
            _v344_change("LaunchOps: the MongoDB quiz-service bullet is preferred, so NoSQL is backed by a bullet", n)
    return out



# --- items 9 / 11. closing span and letter lead ------------------------------------------------------------------------

_V345_BOUNDARY_WORDS = set("and or but for with in on across within using that which while so to through by from into at as via including such like where when "
                           "whether among between over under without after before during per throughout "
                           "preferred required desired helpful plus is are".split())   # "... applications preferred", "... is a plus"


def _v345_clause_end_ok(c: str, line: str) -> bool:
    """Item 9: the quoted responsibility span ends at a clause boundary of the original posting line: the line ends
    there, or punctuation or a connecting word follows (never mid noun phrase, as in "build ML | systems")."""
    words = re.findall(r"[A-Za-z0-9][\w'’+#./-]*", str(c).lower())
    toks = [(m.group(0).lower(), m.end()) for m in re.finditer(r"[A-Za-z0-9][\w'’+#./-]*", str(line))]
    if not words or not toks:
        return True
    tail = words[-min(3, len(words)):]
    n = len(tail)
    for i in range(len(toks) - n + 1):
        if [t for t, _e in toks[i:i + n]] == tail:
            end = toks[i + n - 1][1]
            rest = str(line)[end:]
            if not rest.strip() or re.match(r"\s*[,;:.!?)\]|/–—-]", rest):
                return True
            nxt = toks[i + n][0] if i + n < len(toks) else ""
            if nxt.rstrip(".,;:!?") in _V345_BOUNDARY_WORDS:
                return True
    # the tail was rewritten (actor phrase) or not found verbatim: fall back to the dangle check alone
    return not any([t for t, _e in toks[i:i + n]] == tail for i in range(len(toks) - n + 1))


_V345_SENSOR = re.compile(r"\bsensors?\b|\biot\b|\binternet of things\b|\b(?:embedded|edge|connected|iot|hardware|medical|smart|industrial) devices?\b|"
                          r"\bdevice (?:data|telemetry|firmware|drivers?|fleet)\b|\btelemetry\b", re.I)


def x33_has(plan: dict[str, Any], key: str) -> bool:
    m = globals().get("_V33_MASTER") or {}
    return bool(((m.get("cover_letter_bank") or {}).get("experience_v33") or {}).get(key))


def _v345_sensor_line(plan: dict[str, Any], raw: str) -> str:
    """Item 11: a sensor / IoT / device posting (two role lines, or the title) leads the letter with the Thesis IoT
    pipeline."""
    title = str(plan.get("application", {}).get("role", ""))
    lines = [l for l in _v342_role_text(raw) if _V345_SENSOR.search(l)]
    if _V345_SENSOR.search(title) or len(lines) >= 2:
        return lines[0] if lines else title
    return ""



# --- item 5. the LLM engine's letter introduction ------------------------------------------------------------------------

_V345_ENGINE = "I also built an LLM Application Optimization Engine in Python"


def _v345_ai_posting(plan: dict[str, Any], raw_jd: str) -> bool:
    title = str(plan.get("application", {}).get("role", ""))
    return str(plan.get("role_family", "")) in ("data_science_ml", "ai_llm") or bool(_V342_AI_RX.search(title)) or bool(_v344_agent_posting(plan, raw_jd)) or _v345_ml_posting(plan, raw_jd)


def _v345_engine_intro(paras: list[str], plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[str]:
    ls = ((master.get("cover_letter_bank") or {}).get("letter_sentences") or {}).get("tailor_pipeline") or {}
    intro = str(ls.get("intro", ""))
    also = True
    if intro and not any(intro in p for p in paras) and any(intro.replace("I also built", "I built", 1) in p for p in paras):
        intro, also = intro.replace("I also built", "I built", 1), False   # the engine opens the paragraph ("I built ...")
    if not intro or not any(intro in p for p in paras) or not _v345_ai_posting(plan, raw_jd):
        return paras
    page = " ".join(str(bullet_text(b)) for b in (plan.get("bullets") or {}).get("tailor_pipeline", []))
    fo = [ls[k] for k in ("tailor_pipeline.failover.a", "tailor_pipeline.failover.b", "tailor.provider_failover") if ls.get(k)]
    cl = ls.get("tailor.claim_validation", "")
    text = " ".join(paras)
    fo_page = bool(re.search(r"Novita", page) and re.search(r"\b3\b", page))
    cl_page = bool(re.search(r"\breject", page, re.I))
    if cl and cl in text and cl_page:
        new, drop = f"{_V345_ENGINE} whose checks reject any generated claim that its source evidence does not support.", [cl]
    elif fo_page:
        new, drop = f"{_V345_ENGINE} that falls back from Gemini to Novita's model API after 3 failed attempts.", [x for x in fo if x in text]
    elif cl_page:
        new, drop = f"{_V345_ENGINE} whose checks reject any generated claim that its source evidence does not support.", [cl] if cl in text else []
    else:
        new, drop = f"{_V345_ENGINE} that grounds every generated claim in verified evidence.", [ls.get("tailor.pipeline", "")]
    if not also:
        new = new.replace("I also built", "I built", 1)
    out = []
    for p in paras:
        if intro in p:
            p = p.replace(intro, new)
            for d in drop:
                if d:
                    p = re.sub(r"\s*" + re.escape(d), "", p)
        out.append(re.sub(r"\s{2,}", " ", p).strip())
    plan["_v345_engine_intro"] = new
    _v344_change("Letter: the LLM engine is introduced by its " + ("claim checks" if "reject" in new else ("provider failover" if "Novita" in new else "evidence grounding")) + " (ML / AI / agent posting), never as a resume tool",
                 _v345_ml_line(raw_jd) or str(plan.get("application", {}).get("role", "")))
    return out



# --- A3 / item 13. Skills: every JD-named supported skill shows; off-role entries leave ML pages ------------------------------

_V345_POOLCAT = {"languages_databases": "languages_databases", "frameworks_libraries": "frameworks_libraries", "ai_ml_data": "ai_ml",
                 "software_engineering": "software_engineering", "tools_platforms": "tools"}
_V345_VENDOR_APIS = ("Gemini API", "Novita API", "Groq API", "Claude API", "CrossRef API")
_V345_ML_OFF_ROLE = ("Spring Boot", "Full-Stack Development", "Spring MVC", "Spring Kafka", "Django Channels", "Vite")


def _v345_cat_of(master: dict[str, Any]) -> dict[str, str]:
    return {x: _V345_POOLCAT[k] for k, vals in master["skills"]["supported_pool"].items() if k in _V345_POOLCAT for x in vals}


def v345_jd_named_skills(plan: dict[str, Any], master: dict[str, Any]) -> list[str]:
    """Supported pool skills the posting names (literally, through master normalization, or on a stack line)."""
    cat_of = _v345_cat_of(master)
    raw = str(plan.get("_raw_jd_text", ""))
    named = [t for t in jd_named_pool_terms(raw, master) if t in cat_of]
    named += [t for t in _V345_CTX.get("stack_terms", []) if t in cat_of]
    for r in plan.get("jd_requirements", []) or []:
        if isinstance(r, dict) and r.get("supported") and not r.get("hedged") and str(r.get("term", "")) in cat_of:
            named.append(str(r["term"]))
    # v3.4.6 (item 2): a web application server / ASGI / async server line with LaunchOps on the page names Daphne/ASGI
    if _V346_DAPHNE in cat_of and _v346_asgi_line(plan, raw):
        named.insert(0, _V346_DAPHNE)
        sk = globals().get("_V33_SKILLS")
        if isinstance(sk, dict) and _V346_DAPHNE not in sk.get("jd_named", []):
            sk.setdefault("jd_named", []).append(_V346_DAPHNE)   # named by the JD as a web application server (as OAuth/Auth0)
    return [t for t in dict.fromkeys(named) if t not in _V343_AI_TOOL_NAMES or _v343_ai_tool_ok(t, raw)]


def _v345_skill_fix(states: list[dict[str, Any]], plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    """Item 3 (A3) and item 13. States are a ladder (state 0 is the base; each later state adds optional skills and the
    TeX selector keeps the longest prefix that fits). A JD-named supported skill first replaces, in the base, a vendor API
    that no bullet or heading names; the rest become the first ladder steps, ahead of every optional skill the posting
    does not name. Technologies the page check requires (bullets and headings) always stay in the base."""
    if not states:
        return states
    cat_of = _v345_cat_of(master)
    named = v345_jd_named_skills(plan, master)
    nk = {t.casefold() for t in named}
    raw = str(plan.get("_raw_jd_text", ""))
    _ptech = resolved_project_header_tech(master, plan.get("ranking") or [], plan)
    header = {x for v in _ptech.values() for x in v}
    # the page check's own list (bullets + headings, through master aliases): these never leave Skills
    sel = {str(x).casefold() for x in selected_technology_skills(plan, master, _ptech)}
    ml = _v345_ml_posting(plan, raw)
    vec = plan.get("_jd_theme_vector") or {}
    btxt = json.dumps(plan.get("bullets") or {}).casefold()
    named_in_text = lambda x: bool(re.search(r"(?<![\w])" + re.escape(x.casefold()) + r"(?![\w])", btxt))
    log = plan.setdefault("_v345_skills", {})
    base = json.loads(json.dumps(states[0]))
    req = {str(x).casefold() for x in base.get("required_ats_terms", [])} | sel
    removed: set[str] = set()

    def drop_off_role(sk):
        if not ml:   # item 13: off-role entries leave ML pages
            return
        for vals in sk.values():
            for x in list(vals):
                if x in _V345_ML_OFF_ROLE and x.casefold() not in nk and x.casefold() not in req and len(vals) > 2:
                    vals.remove(x); removed.add(x)

    sk = base.setdefault("skills", {})
    drop_off_role(sk)
    have = {y.casefold() for v in sk.values() for y in v}
    pending = []
    for t in named:
        if t.casefold() in have:
            continue
        c = cat_of[t]
        free = lambda x: x.casefold() not in nk and x.casefold() not in req and x not in header and not named_in_text(x)
        vend = sorted(x for v in sk.values() for x in v if x in _V345_VENDOR_APIS and free(x))
        out = vend[0] if vend else None
        if out is None:   # no vendor API to give up: the term becomes an early ladder step instead
            pending.append(t); continue
        for v in sk.values():
            if out in v:
                v.remove(out)
        removed.add(out)
        log.setdefault("vendor_api_dropped" if vend else "filler_dropped", []).append(out)
        sk.setdefault(c, []).append(t); have.add(t.casefold())
        log.setdefault("jd_named_added", []).append(t)
    # a heading technology the page check would report stays in Skills (the Fleet bullet can replace the one naming it)
    for f_ in validate_selected_technology_skill_coverage(plan, master, {"skills": sk}, _ptech):
        for x in f_.get("measured") or []:
            if _v343_off_role(x, plan, raw, _v343_page_bullets(plan), {str(y).casefold() for y in plan.get("_jd_pool_terms", []) or []},
                             {str(y).casefold() for y in base.get("required_ats_terms", [])}):
                # v3.4.3 change 2: an off-role framework may stay in its heading without a Skills entry
                plan.setdefault("_v343_offrole_removed", []).append(x); continue
            if x in cat_of and x.casefold() not in have:
                sk.setdefault(cat_of[x], []).append(x); have.add(x.casefold())
                log.setdefault("heading_tech_added", []).append(x)
    ladder = [base]
    for t in pending:
        st = json.loads(json.dumps(ladder[-1])); st["skills"].setdefault(cat_of[t], []).append(t)
        ladder.append(st); log.setdefault("jd_named_ladder", []).append(t)
    for prev, cur in zip(states, states[1:]):
        add = {c: [x for x in v if x not in prev.get("skills", {}).get(c, [])] for c, v in cur.get("skills", {}).items()}
        add = {c: [x for x in v if x not in removed and x.casefold() not in {y.casefold() for vv in ladder[-1]["skills"].values() for y in vv}] for c, v in add.items()}
        if not any(add.values()):
            continue
        st = json.loads(json.dumps(ladder[-1]))
        for c, v in add.items():
            st["skills"].setdefault(c, []).extend(v)
        for k_, v_ in cur.items():
            if k_ != "skills":
                st[k_] = json.loads(json.dumps(v_))
        drop_off_role(st["skills"])
        ladder.append(st)
    log["jd_named"] = named
    _V345_CTX["jd_named"] = named
    if len(ladder) > 26:
        log["ladder_truncated"] = [x for st in ladder[26:] for v in st["skills"].values() for x in v][:10]
    return ladder[:26]



# --- items 15 / 16. Education: coursework line; judge packet text ------------------------------------------------------------

def _v345_set_coursework(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    """Item 15: "Relevant coursework: <master education.masters.coursework>" under the Master's degree, only on
    new-grad AI/ML postings or when the posting asks for coursework."""
    if V349B_CTX.get("no_coursework"):   # v3.4.9b: Letter fit step 2
        _V345_CTX["no_coursework"] = True
    cw = list(((master.get("education") or {}).get("masters") or {}).get("coursework") or [])
    if v349c_cw_on():   # v3.4.9c run 3: top-3 matching courses, new-grad pages only
        title = str(raw_plan.get("application", {}).get("role", ""))
        top, sc = v349c_top_courses("\n".join([title] + _v342_role_text(raw_jd)))
        top = [c for c in top if c in cw]
        on = bool(raw_plan.get("_v343_new_grad")) and len(top) == 3 and not _V345_CTX.get("no_coursework")
        _V345_CTX["coursework_on"] = on
        _V345_CTX["coursework"] = top if on else []
        _V345_CTX["coursework_line"] = title
        raw_plan["_v349c_course_scores"] = {c: n for c, n, _ in sc}
        if on:
            raw_plan["_v345_coursework"] = top
            _v344_change("Education: relevant coursework line (" + ", ".join(top) + ") (new-grad page; top 3 of " + ", ".join(f"{c} {n}" for c, n, _ in sc if n) + ")", title)
        return
    ask = next((l for l in _v342_role_text(raw_jd) if re.search(r"\bcoursework\b|\bcourse work\b|\brelevant courses\b", l, re.I)), "")
    ng_ai = bool(raw_plan.get("_v343_new_grad")) and _v345_ai_posting(raw_plan, raw_jd)
    on = bool(cw) and (ng_ai or bool(ask)) and not _V345_CTX.get("no_coursework")
    _V345_CTX["coursework_on"] = on
    _V345_CTX["coursework"] = cw if on else []
    _V345_CTX["coursework_line"] = ask or str(raw_plan.get("application", {}).get("role", ""))
    if on:
        raw_plan["_v345_coursework"] = cw
        _v344_change("Education: relevant coursework line (" + ", ".join(cw) + ") " + ("(the posting asks for coursework)" if ask else "(new-grad AI/ML posting)"),
                     ask or _v345_ml_line(raw_jd) or str(raw_plan.get("application", {}).get("role", "")))


def _v345_coursework_tex(tex: str) -> str:
    cw = _V345_CTX.get("coursework") or []
    if v349c_page_on():   # v3.4.9c run 2 P3: the coursework line sits under the two-line Education's Master's line
        m = re.search(r"\\noindent\\textbf\{Master's in Computer Science\}, University at Buffalo \(SUNY\)[^\n]*\\\\\n", tex)
        if not cw or not m:
            return tex
        return tex[:m.end()] + "\t\\textit{Relevant coursework:} " + latex_escape(", ".join(cw)) + " \\\\\n" + tex[m.end():]
    anchor = "University at Buffalo, The State University of New York, Buffalo, NY \\\\[3.5pt]"
    if not cw or anchor not in tex:
        return tex
    line = "University at Buffalo, The State University of New York, Buffalo, NY \\\\\n\tRelevant coursework: " + latex_escape(", ".join(cw)) + " \\\\[3.5pt]"
    return tex.replace(anchor, line, 1)


def v345_pdf_text(pdf: Path) -> str:
    """Layout-aware page text (PyMuPDF, blocks sorted top-left to bottom-right; right-aligned dates stay on their
    line); falls back to pdftotext -layout when PyMuPDF is missing."""
    try:
        import fitz
        with fitz.open(str(pdf)) as d:
            return "\n".join(pg.get_text("text", sort=True) for pg in d)
    except Exception:
        p = subprocess.run(["pdftotext", "-layout", str(pdf), "-"], capture_output=True)
        return p.stdout.decode("utf-8", errors="replace")


def _v345_packet_pdf_text(out_dir: Path) -> None:
    p = out_dir / "judge_packet.md"
    pdfs = [x for x in out_dir.glob("*.pdf") if "Cover_Letter" not in x.name and x.name != "build_resume.pdf"] or list(out_dir.glob("build_resume.pdf"))
    if not p.exists() or not pdfs:
        return
    txt = p.read_text(encoding="utf-8")
    head, sep, rest = txt.partition("## RESUME (PDF text)\n\n```text\n")
    if not sep:
        return
    _old, sep2, tail = rest.partition("\n```\n")
    body = re.sub(r"[ \t]+\n", "\n", v345_pdf_text(pdfs[0])).strip()
    p.write_text(head + "## RESUME (PDF text, PyMuPDF layout-aware)\n\n```text\n" + body + sep2 + tail, encoding="utf-8")



_V345_OPS_LINE = re.compile(r"\bdefects?\b|\bdebug\w*|\boperational excellence\b|\bon[- ]call\b|\bmonitor\w*|\btroubleshoot\w*|\bincidents?\b|\blog analysis\b|"
                            r"\bproduction (?:issues|support|incidents)\b|\buptime\b|\bobservability\b", re.I)



# --- A1 / A5 / B1 / A3. post-run report: stack gaps, verify quotes, override header, JD-named skills ----------------------------

def v345_role_section_lines(raw: str) -> list[str]:
    """Lines under Responsibilities / Requirements / Preferred / role-description headings ("About the Team and
    Role"), never company-intro text, benefits or EEO; a posting with no such heading falls back to its role text."""
    out, section, structured = [], "pre", False
    for rw in str(raw).splitlines():
        st = re.sub(r"^[^\w(]+", "", rw.strip()).strip()
        st = re.sub(r"[*_#]+$", "", st).strip()
        if not st:
            continue
        if _is_heading(st, rw):
            sec = _section_of(st)
            if sec:
                section = sec
                structured = structured or sec in ("resp", "required", "preferred")
                continue
        if section in ("resp", "required", "preferred", "skills_list"):
            out.append(st)
    return out if structured else [l for l in _v342_role_text(raw) if not _v345_intro_like(l)]


def _v345_intro_like(line: str) -> bool:
    return bool(re.search(r"\b(?:our mission|we are a|is a (?:privately held|global|leading|cloud)|founded in|headquartered|a cloud workspace|millions of (?:monthly )?(?:users|visitors))\b", line, re.I))


_V345_ALWAYS_TERMS = r"\bteams?\b|\blead\w*|\bdeliver\w*|\bend[- ]to[- ]end\b|\brequirements\b|\bcollaborat\w+|\bscope\b|\bownership\b"
_V345_CHANGE_STOP = set("the and for with from that this when its into only one page letter sentence bullet bullets preferred posting project projects names named "
                        "closing responsibility proof variant experience engine kind left off line lines leads lead replaces replace stays keeps never "
                        "role roles suits every script change changes heading shows selected selects".split())


def _v345_change_rx(change: str, master: dict[str, Any]):
    m = re.search(r"Experience variant \w+ \((exp\.[\w.]+)", change)
    if m:
        v = next((x for e in (master.get("experience_variants") or {}).get("bullets", []) for x in e.get("variants", []) if x.get("id") == m.group(1)), {})
        parts = [_V344_THEME_QUOTE[t] for t in v.get("suits_themes") or [] if t in _V344_THEME_QUOTE]
        if v.get("suits_jd"):
            parts.append(v["suits_jd"])
        if re.search(r"heartbeat", str(v.get("text", "")), re.I):
            parts.append(_V345_OPS_LINE.pattern)
        return re.compile("|".join(parts) if parts else _V345_ALWAYS_TERMS, re.I)
    table = [(r"^Closing responsibility \"([^\"]+)\"", None), (r"names (.+?) is preferred", None),
             (r"LLM engine|GoingOnce replaces", _V344_AGENT_LINE.pattern + r"|\bllms?\b|\bagents?\b|" + _V345_SAFETY.pattern),
             (r"^Fraud", _V345_ML_LINE.pattern), (r"Fleet agent", _V345_WAREHOUSE.pattern), (r"NoSQL", r"\bnosql\b|\bmongo\w*"),
             (r"design patterns", r"\bdesign patterns?\b"), (r"ReactJS", r"\breact"), (r"requirements gathering", _V344_REQS.pattern + "|" + _V344_STAKE.pattern),
             (r"code review, mentoring", "|".join(r.pattern for r in _V344_OPS.values())), (r"IoT", _V345_SENSOR.pattern),
             (r"Daphne/ASGI", _V346_ASGI_RX.pattern), (r"coursework", r"\bcoursework\b|" + _V345_ML_LINE.pattern + r"|\bllms?\b|\bai\b|\btransformer"), (r"^Letter: the LLM engine", _V345_ML_LINE.pattern + r"|\bai\b|\bllms?\b|\bagent")]
    for pat, rx in table:
        mm = re.search(pat, change)
        if mm:
            if rx is None:
                words = [w for w in re.findall(r"[A-Za-z][\w+#.-]{2,}", mm.group(1)) if w.lower() not in _V345_CHANGE_STOP and w.lower() not in _V344_STOP]
                rx = "|".join(r"(?<![\w])" + re.escape(w) + r"(?![\w])" for w in words) or r"$^"
            return re.compile(rx, re.I)
    words = [w for w in re.findall(r"[A-Za-z][\w+#.-]{3,}", re.sub(r"\([^)]*\)", "", change)) if w.lower() not in _V345_CHANGE_STOP]
    return re.compile("|".join(r"(?<![\w])" + re.escape(w) + r"(?![\w])" for w in words) or r"$^", re.I)


def _v345_norm(s: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[*_`]+", "", str(s))).strip().casefold()


def v345_fix_verify_quotes(changes: list[dict[str, Any]], raw: str, title: str, master: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Item 18 (A5): each verify quote is a Responsibilities / Requirements / role-description line (never company
    intro text such as the Poe line, never the bare title) that contains a term of the changed item; a quote that
    fails is replaced by the best role line, or left empty and marked when no line names the item."""
    roles = v345_role_section_lines(raw)
    nroles = [_v345_norm(l) for l in roles]
    log = {"replaced": [], "unquoted": []}
    out = []
    for c in changes:
        c = dict(c)
        q, nq = str(c.get("jd_line", "")), _v345_norm(c.get("jd_line", ""))
        rx = _v345_change_rx(str(c.get("change", "")), master)
        if c.get("internal"):
            out.append(c); continue
        in_role = bool(nq) and any(nq[:200] in r or (len(r) > 20 and r in nq) for r in nroles)
        ok = in_role and nq != _v345_norm(title) and bool(rx.search(q))
        hits = lambda l: len({m_.group(0).casefold() for m_ in rx.finditer(l)})
        best = max(roles, key=hits, default="")
        if ok and best and hits(best) >= hits(q) + 2:   # a line that names the item more fully replaces a generic one
            ok = False
        if not ok:
            if best and rx.search(best):
                c["jd_line"] = re.sub(r"\s+", " ", best).strip()[:240]
                log["replaced"].append(str(c.get("change", ""))[:80])
            else:
                c["jd_line"] = ""
                c["change"] = str(c.get("change", "")) + " (no posting line names it; script rule)"
                log["unquoted"].append(str(c.get("change", ""))[:80])
        out.append(c)
    return out, log


def _v345_term_key(t: str, master: dict[str, Any]) -> str:
    k = _norm_term(str(t), master).casefold()
    return {"apache spark": "spark", "apache airflow": "airflow", "retrieval-augmented generation": "rag", "vector database": "vector databases"}.get(k, k)


def v345_unreported_gaps(rep: dict[str, Any], master: dict[str, Any]) -> list[str]:
    """A1 / G4: every jd_gap_terms_detected term is in hard_gaps or in the stack-gaps note."""
    hard = {_v345_term_key(g.get("term", "") if isinstance(g, dict) else g, master) for g in rep.get("hard_gaps", []) or []}
    note = " ".join(str(n) for n in rep.get("notes", []) or [] if str(n).startswith("Stack gaps"))
    out = []
    for t in rep.get("jd_gap_terms_detected", []) or []:
        if _v345_term_key(t, master) in hard:
            continue
        if not re.search(r"(?<![\w])" + re.escape(str(t)) + r"(?![\w])", note):
            out.append(str(t))
    return out


def _v345_post_run(rep: dict[str, Any], out_dir: Path, argv: list[str]) -> None:
    if rep.get("skip"):
        return
    try:
        master = json.loads(Path(argv[argv.index("--master") + 1]).read_text(encoding="utf-8"))
        raw = clean_jd_text(Path(argv[argv.index("--jd") + 1]).read_text(encoding="utf-8"))
    except Exception:
        return
    try:
        rp_ = json.loads((out_dir / "resolved_plan.json").read_text(encoding="utf-8"))
    except Exception:
        rp_ = {}
    title = str((rep.get("tracker_row") or {}).get("Role", ""))
    notes = [n for n in rep.get("notes", []) or [] if not str(n).startswith(("Stack gaps", "Ranking override"))]
    # A1: stack gaps and every other non-hard gap term are reported; they never cap Fit
    hard = {_v345_term_key(g.get("term", "") if isinstance(g, dict) else g, master) for g in rep.get("hard_gaps", []) or []}
    stack = set(_V345_CTX.get("stack_gaps") or [])
    soft = [t for t in rep.get("jd_gap_terms_detected", []) or [] if _v345_term_key(t, master) not in hard]
    for t in stack:
        if t not in soft and _v345_term_key(t, master) not in hard:
            soft.append(t)
            rep.setdefault("jd_gap_terms_detected", []).append(t)
    if soft:
        notes.append("Stack gaps (named in the posting but not hard requirements, so Fit is not capped): "
                     + ", ".join(f"{t} (stack line)" if t in stack else t for t in soft) + ".")
    rep["stack_gaps_v345"] = sorted(stack)
    # B1: report header shows any ranking override reason and the displaced project
    ov = dict(_V345_CTX.get("override") or {})
    reason = str(rp_.get("ranking_override_reason", "") or "")
    disp = ov.get("displaced") or ov.get("displaced_v343") or ""
    if reason or ov.get("blocked") or ov.get("goingonce_third"):
        hdr = {"reason": reason, "displaced": disp, "jd_line": ov.get("jd_line", "")}
        if ov.get("blocked"):
            hdr["blocked"] = ov["blocked"] + ": " + str(ov.get("why", ""))
        if ov.get("goingonce_third"):
            hdr["goingonce_third"] = ov["goingonce_third"]
        rep["ranking_override_v345"] = hdr
        if reason:
            notes.append(f"Ranking override: {reason}" + (f" (displaced {disp})" if disp else "") + ".")
        if ov.get("blocked"):
            notes.append(f"Ranking override blocked: {hdr['blocked']}.")
    rep["notes"] = notes
    # A5: verify quotes
    rep["verify_changes_v344"], log = v345_fix_verify_quotes(rep.get("verify_changes_v344", []), raw, title, master)
    rep["verify_quotes_v345"] = log
    intro = [c for c in rep["verify_changes_v344"] if c.get("jd_line") and _v345_intro_like(c["jd_line"])]
    # A3: every supported skill the posting names shows in Skills
    pdf = out_dir / "build_resume.pdf"
    page = v345_pdf_text(pdf) if pdf.exists() else ""
    m_ = re.search(r"TECHNICAL SKILLS(.*?)(?:CERTIFICATIONS|$)", page, re.S)
    sk = re.sub(r"\s+", " ", m_.group(1)) if m_ else ""
    named = list(_V345_CTX.get("jd_named") or [])
    missing_named = [t for t in named if sk and t.casefold() not in sk.casefold()]
    rep["jd_named_skills_v345"] = {"named": named, "missing": missing_named}
    fails = []
    gaps_left = v345_unreported_gaps(rep, master)
    if gaps_left:
        fails.append(fail("jd_gap_terms_unreported", "notes", gaps_left, "every jd_gap_terms_detected term in hard_gaps or the stack-gaps note", "Pipeline defect: report it."))
    if intro:
        fails.append(fail("verify_quote_company_intro", "verify_changes_v344", [c["jd_line"][:80] for c in intro], "quotes from role sections only", "Pipeline defect: report it."))
    if re.search(r"\breferral\b", json.dumps(rep.get("outreach", {})), re.I):
        fails.append(fail("outreach_referral_ask", "outreach", "referral", "an advice conversation, never a referral first", "Pipeline defect: report it."))
    if missing_named:   # every one was offered ahead of unnamed optional skills; only the Skills line budget keeps it out
        rep["notes"].append("Skills full (named by the posting and supported, but no room after the required terms): " + ", ".join(missing_named) + ".")
    fails += _v346_post_run(rep, out_dir, rp_, raw)
    if fails and rep.get("status") == "PASS":
        rep["status"] = "FAIL"
    rep.setdefault("failures", []).extend(fails)


# ===========================================================================
# v3.4.6 layer (2026-10-16). Five small fixes; new helper names only, and every change to an existing function is made
# in its FINAL definition (no name gains another definition).
#  1. Bank: RIPPLE ripple.tools.b says "code-analysis" (master: "7 code-analysis tools").
#  2. Skills: a web application server / ASGI / async server line with LaunchOps on the page shows Daphne/ASGI.
#  3. Letter: internship logistics state start availability; every letter's second paragraph must (build fails).
#  4. Tagline: a model-written tagline_text may name a domain / scope phrase only when a selected bullet or an
#     Experience line on the page backs it (build fails, naming the phrase). Checked term list, not exact phrases.
#  5. Experience variant J (verb-only): two Experience bullets never open with the same verb (build fails).
# ===========================================================================
_V346_DAPHNE = "Daphne/ASGI"
_V346_ASGI_RX = re.compile(r"\b(?:web )?application servers?\b|\bapp servers?\b|\basgi\b|\basync(?:hronous)? (?:web |python |http )?servers?\b", re.I)
_V346_INTERN_LOGISTICS = "My Master's in Computer Science at the University at Buffalo is expected in February 2027."
_V346_INTERN_LOGISTICS_START = "My Master's in Computer Science at the University at Buffalo is expected in February 2027, and I can start any time from that month."
_V346_START_RX = re.compile(r"\b(?:can|could|am able to|am available to|available to) start\b|\bstart (?:work|date)\b|\bavailable (?:from|starting)\b", re.I)


def _v346_internal_change(change: str) -> None:
    """A change that follows a script rule rather than a posting line (verify quotes leave it unquoted)."""
    item = {"change": change, "jd_line": "", "internal": True}
    if item not in _V344_CTX["changes"]:
        _V344_CTX["changes"].append(item)


# --- item 2. Daphne/ASGI ---------------------------------------------------------------------------------------

def _v346_asgi_line(plan: dict[str, Any], raw: str) -> str:
    """The posting line asking for a web application server / ASGI / async server, when LaunchOps (Daphne) is on the
    page; "" otherwise (no filler on postings that do not ask)."""
    if "launchops" not in list(plan.get("ranking") or [])[:3]:
        return ""
    lines = _v342_role_text(raw) or [l.strip() for l in str(raw).splitlines() if l.strip()]
    line = next((l for l in lines if _V346_ASGI_RX.search(l)), "")
    if not line:
        line = next((l.strip() for l in str(raw).splitlines() if _V346_ASGI_RX.search(l) and not _v345_intro_like(l)), "")
    if line:
        _v344_change("Skills: Daphne/ASGI (LaunchOps runs on Daphne) shows for the posting's web application server line", line)
    return line


# --- item 5. verb-only Experience variant ----------------------------------------------------------------------------

def _v346_verb_only_picks(plan: dict[str, Any], master: dict[str, Any], picks: list[dict[str, Any]], allowed) -> list[dict[str, Any]]:
    """Variant J (verb-only, approved): used whenever another Experience bullet on the page, as rendered (original or
    its chosen variant), opens with the verb J replaces. Bullets of omitted roles do not count."""
    out = []
    omitted = {normalize_fixed_text(b) for b in plan.get("_v343_omitted_exp_bullets", []) or []}
    entries = (master.get("experience_variants") or {}).get("bullets", [])
    chosen = {p["bullet_id"]: p["text"] for p in picks}
    by_orig = {normalize_fixed_text(e["original"]): e["id"] for e in entries}
    for e in entries:
        if e["id"] in chosen:
            continue
        v = next((x for x in e.get("variants", []) if x.get("verb_only") and x.get("status") in allowed), None)
        key = normalize_fixed_text(e["original"])
        if not v or key in omitted:
            continue
        verb = str(v.get("avoids_repeat_verb") or e["original"].split()[0])
        others = [chosen.get(by_orig.get(normalize_fixed_text(b), ""), b) for r in master.get("experience", []) for b in r.get("bullets", [])
                  if normalize_fixed_text(b) != key and normalize_fixed_text(b) not in omitted]
        hit = next((o for o in others if o.split() and o.split()[0] == verb), "")
        if hit:
            out.append({"bullet_id": e["id"], "variant_id": v["id"], "original": e["original"], "text": v["text"], "score": 0.0, "_jd_line": "", "_repeat_of": hit[:60]})
    return out


# --- item 4. tagline scope check ------------------------------------------------------------------------------------
# Domain / scope nouns a tagline may name only with evidence on the page. Each entry is a category and a word pattern;
# a hit marks its phrase (the part of the tagline between commas and joining words), and every content word of that
# phrase must then appear in ONE selected bullet or Experience line.
V346_TAGLINE_SCOPE_TERMS = [
    ("business domain", r"e-?commerce|commerce|retail|shopping|marketplaces?|payments?|fintech|banking|financ\w*|insurance|healthcare|health|medical|clinical|"
                        r"pharma\w*|biotech\w*|edtech|education\w*|gaming|games?|media|entertainment|advertis\w*|ads|marketing|logistics|supply[- ]chains?|"
                        r"warehous\w*|transportation|automotive|vehicles?|robot\w*|aerospace|defen[cs]e|energy|telecom\w*|travel|real[- ]estate|legal|"
                        r"government|public[- ]sector|crypto\w*|blockchain|web3"),
    ("platform / product scope", r"platforms?|infrastructure|integrations?|enterprise|saas|cloud|aws|azure|gcp|mobile|ios|android|devices?|iot|embedded|"
                                 r"firmware|hardware|connected|consumer|ecosystems?"),
    ("trust / policy domain", r"safety|content|moderation|trust|abuse|fraud|risk|compliance|privacy|security|secure|identity|permissions?|"
                              r"access[- ]control|authentication|authori[sz]ation|auth"),
    ("product area", r"search|recommendations?|recommender|ranking|personali[sz]ation|computer[- ]vision|speech|voice|audio|video|nlp|generative|creative"),
    ("scale / live scope", r"live|streaming|real[- ]time|large[- ]scale|global|millions?|billions?|high[- ]traffic|internet[- ]scale|planet[- ]scale"),
]
_V346_SCOPE_RX = [(c, re.compile(r"(?<![\w-])(?:" + p + r")(?![\w])", re.I)) for c, p in V346_TAGLINE_SCOPE_TERMS]
_V346_TAG_JOIN = re.compile(r"[,;:]|\s(?:and|or|with|for|in|across|on|using|via|including|plus|from|to|at|into|that|which)\s", re.I)
_V346_TAG_QUALIFIERS = set("reliable maintainable tested well-tested robust scalable dependable repeatable efficient modern clean high-quality "
                           "production-ready production-grade collaborative".split())
_V346_TAG_STOP = set("a an the of their its his this these those at by as".split())


def _v346_words(s: str) -> list[str]:
    return re.findall(r"[a-z0-9][a-z0-9+#./-]*[a-z0-9+#]|[a-z0-9]", str(s).lower().replace("’", "'"))


def _v346_norm(w: str) -> str:
    w = w.lower().rstrip(".")
    for suf, rep in (("ies", "y"), ("es", ""), ("s", ""), ("ed", ""), ("ing", "")):
        if w.endswith(suf) and len(w) - len(suf) >= 3 and not w.endswith("ss"):
            return w[: len(w) - len(suf)] + rep
    return w


def _v346_word_match(a: str, b: str) -> bool:
    a, b = _v346_norm(a), _v346_norm(b)
    if a == b or a.rstrip("e") == b.rstrip("e"):
        return True
    short, long_ = sorted((a, b), key=len)
    return len(short) >= 5 and long_.startswith(short) and len(long_) - len(short) <= 4


def v346_tagline_phrases(tagline: str) -> list[tuple[str, str, list[str]]]:
    """(phrase, category, content words) for every tagline phrase that contains a domain / scope term."""
    t = re.sub(r"^Master's CS student\s+", "", str(tagline).replace("’", "'").strip(), flags=re.I).rstrip(".")
    t = re.sub(r"^(?:building|who builds|focused on|with|experienced in|working on|developing|creating)\s+", "", t, flags=re.I)
    out = []
    for chunk in _V346_TAG_JOIN.split(" " + t + " "):
        chunk = chunk.strip()
        if not chunk:
            continue
        cat = next((c for c, rx in _V346_SCOPE_RX if rx.search(chunk)), "")
        if not cat:
            continue
        words = [w for w in _v346_words(chunk) if w not in _V346_TAG_STOP and w not in _V346_TAG_QUALIFIERS]
        out.append((chunk, cat, words))
    return out


def v346_page_lines(tex: str) -> dict[str, list[str]]:
    """Experience and project bullet lines of the rendered page (LaTeX unescaped)."""
    out: dict[str, list[str]] = {"experience": [], "projects": []}
    sec = ""
    for raw in str(tex).splitlines():
        m = re.search(r"\\section\*\{([^}]*)\}", raw)
        if m:
            name = m.group(1).upper()
            sec = "experience" if "EXPERIENCE" in name else ("projects" if "PROJECT" in name else "")
            continue
        s = raw.strip()
        if sec and s.startswith("\\item "):
            s = s[len("\\item "):]
            s = s.replace("$\\sim$", "~").replace("\\%", "%").replace("\\&", "&").replace("\\_", "_").replace("\\#", "#").replace("$|$", "|")
            s = re.sub(r"\\textbf\{([^}]*)\}|\\textit\{([^}]*)\}", lambda mm: mm.group(1) or mm.group(2) or "", s)
            out[sec].append(re.sub(r"\s+", " ", s).strip())
    return out


def v346_tagline_unsupported(tagline: str, lines: list[str]) -> list[dict[str, Any]]:
    """Scope phrases no single selected bullet or Experience line backs (every content word of the phrase in that line)."""
    toks = []
    for l in lines:
        ws = _v346_words(l)
        toks.append(set(ws) | {p for w in ws for p in re.split(r"[-/]", w) if p})
    def has(w: str, ts: set[str]) -> bool:   # the word, or every part of a hyphenated / slashed word
        parts = [p for p in re.split(r"[-/]", w) if p]
        return any(_v346_word_match(w, x) for x in ts) or (len(parts) > 1 and all(any(_v346_word_match(p, x) for x in ts) for p in parts))

    bad = []
    for phrase, cat, words in v346_tagline_phrases(tagline):
        if not any(all(has(w, ts) for w in words) for ts in toks):
            bad.append({"phrase": phrase, "category": cat, "words": words})
    return bad


# --- item 3. start availability ------------------------------------------------------------------------------------

def v346_letter_p2(text: str) -> str:
    parts = [re.sub(r"\s+", " ", p).strip() for p in re.split(r"\n\s*\n", str(text).strip()) if p.strip()]
    body = [p for p in parts if not p.startswith("Dear ") and not p.startswith(("Sincerely", "Best regards", "Regards"))]
    if v349c_plain_on() and len(body) == 3:   # v3.4.9c run 8: a plain letter's logistics sentence is in paragraph 3
        return body[2]
    return body[1] if len(body) >= 2 else (body[-1] if body else "")


def v346_start_clause_ok(text: str) -> bool:
    """cover_letter_rules.p2: the logistics sentence states when Jay can start (full-time and internship letters)."""
    return bool(_V346_START_RX.search(v346_letter_p2(text)))


# --- post-run validators (items 2-5) ------------------------------------------------------------------------------

def _v346_post_run(rep: dict[str, Any], out_dir: Path, rp_: dict[str, Any], raw: str) -> list[dict[str, Any]]:
    fails: list[dict[str, Any]] = []
    out_dir = Path(out_dir)
    texs = [p for p in out_dir.glob("*.tex") if p.name != "build_resume.tex"] or list(out_dir.glob("build_resume.tex"))
    tex = texs[0].read_text(encoding="utf-8") if texs else ""
    page = v346_page_lines(tex)
    checks: dict[str, Any] = {}
    # item 4: tagline scope phrases need a selected bullet or Experience line behind them
    tag_id, tag = str(rp_.get("tagline_id", "")), str(rp_.get("tagline_text", ""))
    if tag_id == "custom" and tag:
        bad = v346_tagline_unsupported(tag, page["projects"] + page["experience"])
        checks["tagline"] = {"tagline_text": tag, "scope_phrases": [p for p, _c, _w in v346_tagline_phrases(tag)], "unsupported": bad}
        if bad:
            fails.append(fail("tagline_unsupported_scope", "tagline_text",
                              "; ".join(f"\"{b['phrase']}\" ({b['category']}: no selected bullet or Experience line names {' + '.join(b['words'])})" for b in bad),
                              "every domain / scope phrase in tagline_text is backed by one selected bullet or Experience line on the page",
                              "Rewrite tagline_text to describe only work shown on the page (or use tagline_id); this check cannot be switched off from plan.json."))
    else:
        checks["tagline"] = {"tagline_id": tag_id, "checked": False, "why": "pre-approved master tagline"}
    # item 5: no two Experience bullets open with the same verb
    verbs = [l.split()[0] for l in page["experience"] if l.split()]
    rep_v = sorted({v for v in verbs if verbs.count(v) > 1})
    checks["experience_opening_verbs"] = verbs
    if rep_v:
        fails.append(fail("experience_repeat_opening_verb", "experience", rep_v, "every Experience bullet opens with a different verb",
                          "Pipeline defect: the verb-only variant J should have applied; report it."))
    # item 3: the letter's second paragraph states start availability
    for p in out_dir.glob("*_Cover_Letter.txt"):
        ok = v346_start_clause_ok(p.read_text(encoding="utf-8"))
        checks["letter_start_clause"] = ok
        if not ok:
            fails.append(fail("cover_letter_start_availability_missing", p.name, v346_letter_p2(p.read_text(encoding="utf-8"))[-160:],
                              ("paragraph 2 logistics: graduation December 2026 + start work February 2027 (+ relocation when onsite)" if v348b_on() else
                               "paragraph 2 logistics: graduation February 2027 + when Jay can start (+ relocation when onsite)"), "Pipeline defect: report it."))
    # item 2: a web application server / ASGI posting with LaunchOps on the page shows Daphne/ASGI
    line = next((l for l in (_v342_role_text(raw) or str(raw).splitlines()) if _V346_ASGI_RX.search(l)), "") if raw else ""
    if line and "launchops" in list(rp_.get("ranking") or [])[:3]:
        shown = "Daphne" in tex
        checks["daphne_asgi"] = {"jd_line": line.strip()[:160], "shown": shown}
        if not shown:
            fails.append(fail("asgi_server_not_shown", "skills", "Daphne/ASGI missing", "Daphne/ASGI in Skills or the LaunchOps heading when the posting asks for a web application server",
                              "Pipeline defect: report it."))
    rep["checks_v346"] = checks
    return fails


# ===========================================================================
# v3.4.7a layer (2026-10-18). Low-risk build: six narrow fixes, each behind its own flag in master.json "v347_flags"
# (default true). With every flag false the outputs are byte-identical to v3.4.6 (3_validation/diff_gate_v347.py).
# New helper names only; every change to an existing function is made in its FINAL definition.
#  A1 relocation_fix   : the Buffalo exception is Buffalo, NY only; remote postings never mention relocation.
#  A2 heading_tech_fix : a JD-named technology added to headings stays only on the project whose bullets best show it.
#  A3 identity_fix     : employer statements in the posting body; Notes line on a mismatch; one organization per letter.
#  A4 report_fix       : unquoted verify_changes_v344 entries move to internal_changes with a reason.
#  A5 outreach_fix     : people searches leave out a "Not stated" company; the block says it is not stated.
#  A6 hook_reason_fix  : report.json says which hook-specificity test failed.
# Test-only switch (like --regression-allow-missing-title): --regression-v347-flags-off=all | name,name  (the
# flags-off equivalence test; master.json is hash-locked, so the regression cannot edit it).
# ===========================================================================
PIPELINE_VERSION = "v3.4.9c"
V347_FLAG_NAMES = ("relocation_fix", "heading_tech_fix", "identity_fix", "report_fix", "outreach_fix", "hook_reason_fix",
                   "sponsorship_polarity", "or_groups", "sql_parse", "bullet_relevance",   # v3.4.7b: B1 to B4
                   "strict_fleet",   # v3.4.7c: C1
                   "outreach_v348", "employer_phrasings_v348", "hook_fallback_v348",   # v3.4.8a: O, E, H
                   "graduation_dec2026_v348",   # v3.4.8b: graduation December 2026, start February 2027
                   "start_date_parse_v348", "bank_wording_v348", "fleet_language_model_v348", "fleet_repick_v348",   # v3.4.8c: T, W, F1, F2
                   "skills_lines_v348", "heading_move_v348", "closing_proof_map_v348", "closing_specific_v348",   # v3.4.8c: S, J, C1, C2
                   "jd_sections_v349", "years_range_v349", "fit_guard_v349", "bullet_score_v349", "ranker_v349", "date_order_v349", "proof_on_page_v349",
                   "copy_rule_v349", "skills_dedupe_v349", "company_key_v349",   # v3.4.9a: fixes 1-10
                   "bank_format_v349b", "format_letter_v349b", "bold_results_v349b", "skills_cap5_v349b", "letter_trims_v349b",   # v3.4.9b: format build
                   "data_v349c",   # v3.4.9c run 1: data (coursework, Education date, hackathon letter sentence)
                   "page_v349c",   # v3.4.9c run 2: page (reference preamble, header, two-line Education, no Certifications & Awards)
                   "thesis_v349c", "coursework_v349c",   # v3.4.9c run 3: Thesis bullets; top-3 coursework on new-grad pages
                   "layout_v349c",   # v3.4.9c run 4: new-grad 3/2/2, per-page fit order, Skills 6th line, Python first
                   "spacing_v349c",   # v3.4.9c run 5: adaptive vertical spacing after the content fits
                   "must_framework_v349c",   # v3.4.9c run 6: a must-have framework / language with one primary project leads
                   "closing_v349c",   # v3.4.9c run 7: the closing's responsibility is one its proof's evidence demonstrates
                   "letters_plain_v349c")   # v3.4.9c run 8: plain three-paragraph letters
_V347_FLAGS: dict[str, bool] = {k: True for k in V347_FLAG_NAMES}
_V347_OFF: set[str] = set()
for _a in list(sys.argv):
    if _a.startswith("--regression-v347-flags-off="):   # test-only
        sys.argv.remove(_a)
        _v = _a.split("=", 1)[1]
        _V347_OFF |= set(V347_FLAG_NAMES) if _v == "all" else {x.strip() for x in _v.split(",") if x.strip()}


V349C_ALL_FLAGS = ("data_v349c", "page_v349c", "thesis_v349c", "coursework_v349c", "layout_v349c", "spacing_v349c", "must_framework_v349c",
                   "closing_v349c", "letters_plain_v349c")


def v347_load_flags(master: dict[str, Any] | None) -> dict[str, bool]:
    """master.json v347_flags (missing names default to true), then the test-only off switch."""
    fl = dict((master or {}).get("v347_flags") or {})
    _V347_FLAGS.clear()
    _V347_FLAGS.update({k: bool(fl.get(k, True)) and k not in _V347_OFF for k in V347_FLAG_NAMES})
    # v3.4.9c: with all nine v3.4.9c flags off the outputs are the v3.4.9b outputs, version string included
    globals()["PIPELINE_VERSION"] = "v3.4.9b" if not any(_V347_FLAGS.get(k, True) for k in V349C_ALL_FLAGS) else "v3.4.9c"
    return dict(_V347_FLAGS)


def _v347_on(name: str) -> bool:
    return bool(_V347_FLAGS.get(name, True))


# --- A1. relocation ----------------------------------------------------------------------------------------------
_V347_BUFFALO_NY = re.compile(r"(?<![A-Za-z])(?<![A-Za-z] )Buffalo\s*,\s*(?:NY|N\.Y\.|New York)\b", re.I)
_V347_RELOC = "I am open to relocating."
_V347_RELOC_RX = re.compile(r"\s*I am (?:also )?open to relocating\.")


def v347_relocation_wanted(loc: str, raw_jd: str) -> bool | None:
    """True: onsite / hybrid outside Buffalo, NY (letter says it). False: remote (never says it). None: Buffalo, NY or
    no location (leave the letter as it is)."""
    loc = str(loc or "").strip()
    remote = bool(re.search(r"\bremote\b", loc + " " + str(raw_jd)[:400], re.I)) and not re.search(r"hybrid|onsite|on-site|in office", loc, re.I)
    if remote:
        return False
    if not loc or loc.lower() in ("not stated", "n/a", "unknown") or _V347_BUFFALO_NY.search(loc):
        return None
    return True


def _v347_relocation(paras: list[str], plan: dict[str, Any], raw_jd: str) -> list[str]:
    want = v347_relocation_wanted(str(plan.get("application", {}).get("location", "")), raw_jd)
    if want is False:
        return [_V347_RELOC_RX.sub("", p) for p in paras]
    if want and not any("relocat" in p for p in paras):
        i = next((k for k in range(len(paras) - 1, -1, -1) if "February 2027" in paras[k]), None)
        if i is not None:
            sents = re.split(r"(?<=[.!?])\s+", paras[i])
            j = next(k for k, s in enumerate(sents) if "February 2027" in s)
            sents.insert(j + 1, _V347_RELOC)
            paras = paras[:i] + [" ".join(sents)] + paras[i + 1:]
    return paras


# --- A2. heading technology placement ------------------------------------------------------------------------------
# A framework or library a bullet names shows its language (a React bullet shows JavaScript); a technology's other
# spellings count as naming it.
_V347_LANG_FROM = {"JavaScript": r"React(?:JS|\.js)?|Node(?:\.js)?|TypeScript|Vite",
                   "Python": r"Django|Flask|FastAPI|Pydantic|pytest|PyTorch|LangGraph|Streamlit|asyncio", "Java": r"Spring(?: Boot)?"}
_V347_FORMS = {"ReactJS": r"React(?:JS|\.js)?", "PostgreSQL": r"Postgre(?:SQL|s)", "Kubernetes (local k3d)": r"Kubernetes|k3d", "Apache Kafka": r"Kafka",
               "Daphne/ASGI": r"Daphne|ASGI"}


def _v347_forms(x: str) -> str:
    return _V347_FORMS.get(x, re.escape(re.sub(r"\s*\(.*?\)$", "", x)))


def v347_bullets_show(texts: list[str], x: str) -> int:
    rx = _v347_forms(x) + ("|" + _V347_LANG_FROM[x] if x in _V347_LANG_FROM else "")
    return sum(1 for t in texts if re.search(r"(?<![\w])(?:" + rx + r")(?![\w])", str(t), re.I))


def v347_jd_names(raw: str, x: str) -> bool:
    rx = _v347_forms(x) + ("|Javascript|JS" if x == "JavaScript" else "")
    return bool(re.search(r"(?<![\w])(?:" + rx + r")(?![\w])", str(raw), re.I if len(x) > 2 else 0))


def _v347_core(master: dict[str, Any], pid: str) -> list[str]:
    return ["Kubernetes (local k3d)" if x == "Kubernetes" else x for x in master["projects"][pid].get("header_priority_tech", [])]


def v347_heading_removals(heads: dict[str, list[str]], bullets: dict[str, list[str]], order: list[str], raw: str, master: dict[str, Any]) -> dict[str, list[str]]:
    """{pid: [technology that leaves its heading]}. Only technologies added to a heading (not its core stack,
    master header_priority_tech) and named by the posting are considered. One that only this project shows stays."""
    added: dict[str, list[str]] = {}
    for pid in order:
        for x in heads.get(pid, []):
            if x not in _v347_core(master, pid) and v347_jd_names(raw, x):
                added.setdefault(x, []).append(pid)
    rem: dict[str, list[str]] = {}
    for x, holders in added.items():
        sc = {pid: v347_bullets_show(bullets.get(pid, []), x) for pid in order}
        showing = [p for p in holders if sc[p] > 0]
        if showing:
            keep = max(showing, key=lambda p: (sc[p], -order.index(p)))
            drop = [p for p in holders if p != keep]
        else:
            others = [p for p in order if p not in holders and (x in heads.get(p, []) or sc[p] > 0)]
            drop = list(holders) if others else holders[1:]
        for p in drop:
            rem.setdefault(p, []).append(x)
    return rem


def _v347_heading_placement(out: dict[str, list[str]], master: dict[str, Any], display_order: list[str], plan: dict[str, Any]) -> dict[str, list[str]]:
    """The technology leaves the rendered heading and its slot is not refilled. Applied in build_project_block only:
    Skills (which always list heading technologies), their order and the page checks are computed from the full
    heading set, so they are unchanged; every item left on the heading is still in Skills."""
    raw = str(plan.get("_raw_jd_text", "") or "")
    if not raw:
        return out
    overrides = plan.get("project_tech", {}) or {}
    if _v347_on("date_order_v349") and plan.get("ranking"):   # v3.4.9a fix 6: headings follow rank, not the date order of the page
        display_order = [p for p in plan["ranking"] if p in display_order] + [p for p in display_order if p not in plan["ranking"]]
    order = [p for p in display_order if p in out]
    bullets = {pid: [bullet_text(b) for b in (plan.get("bullets") or {}).get(pid, [])] for pid in order}
    rem = v347_heading_removals(out, bullets, order, raw, master)
    log = {}
    for pid, xs in rem.items():
        if pid in overrides:   # the plan's own project_tech is never moved
            continue
        out[pid] = [x for x in out[pid] if x not in xs]
        shown_by = {x: [p for p in order if p != pid and (x in out.get(p, []) or v347_bullets_show(bullets.get(p, []), x))] for x in xs}
        log[pid] = [{"left": x, "shown_by": shown_by[x]} for x in xs]
    if log:
        plan["_v347_heading"] = log
        _V347_CTX.setdefault("heading", {}).update(log)
    if _v347_on("heading_move_v348"):   # v3.4.8c J
        out = v348c_heading_move(out, log, bullets, order, master, overrides)
        _V348C_J["rendered"] = {k: list(v) for k, v in out.items()}
        _V348C_J["ats_fixed"] = []
    return out


# --- A3. hiring identity -------------------------------------------------------------------------------------------
_V347_ORG = r"((?:[A-Z][\w&.'’-]*)(?:[ \t]+(?:[A-Z][\w&.'’-]*|of|and|&)){0,5})"
_V347_OPENINGS = re.compile(r"(?m)(?:^|(?<=[.!?]\s))" + _V347_ORG + r"(?:,[^.\n]{0,160}?)?\s+(?i:has\s+(?:multiple\s+|several\s+|\d+\s+|many\s+)?(?:job\s+)?openings?)\b")
_V347_HIRING = re.compile(r"(?m)(?:^|(?<=[.!?]\s))" + _V347_ORG + r"\s+(?i:is\s+(?:currently\s+|now\s+)?hiring)\b")
_V347_SEND_TO = re.compile(r"(?i)send\s+(?:your\s+)?(?:resumes?|cvs?|résumés?)\s+(?:\w+\s+){0,3}?to\s*:?\s*\**\s*([A-Za-z0-9._%+-]+@([A-Za-z0-9-]+)(?:\.[A-Za-z0-9-]+)*\.[a-z]{2,})")
_V347_LABEL = re.compile(r"(?im)^[\s*#_]*company[\s*_]*:[\s*_]*([^\n*]+?)[\s*_]*$")
_V347_SUFFIX = re.compile(r"\b(?:llc|inc|corp|corporation|co|ltd|limited|technologies|technology|group|holdings|plc|lp|llp)\b\.?", re.I)


def _v347_org_key(s: str) -> list[str]:
    return re.sub(r"[^a-z0-9 ]", "", _V347_SUFFIX.sub("", str(s).lower())).split()


def v347_same_org(a: str, b: str) -> bool:
    ka, kb = _v347_org_key(a), _v347_org_key(b)
    return bool(ka and kb and (ka[0] == kb[0] or " ".join(ka) in " ".join(kb) or " ".join(kb) in " ".join(ka)))


def v347_hiring_identity(raw: str, company: str) -> dict[str, Any]:
    """Employer statements in the posting body ("<Org> ... has openings", "<Org> is hiring", "send resume to
    <...@domain>") and any board / header "company:" label. Never renames anything."""
    import html as _html
    t = re.sub(r"\*\*", "", _html.unescape(str(raw)))
    emp = [m.group(1).strip() for rx in (_V347_OPENINGS, _V347_HIRING) for m in rx.finditer(t)]
    if _v347_on("employer_phrasings_v348"):   # v3.4.8a E: "<Org> is searching for / is looking for / is seeking / seeks / is recruiting"
        emp += [o for o in v348_employer_statements(t) if o not in emp]
    mails = [(m.group(1), m.group(2)) for m in _V347_SEND_TO.finditer(t)]
    labels = [m.group(1).strip() for m in _V347_LABEL.finditer(t)]
    employer = emp[0] if emp else (mails[0][1] if mails else "")
    d: dict[str, Any] = {"employer_statements": emp, "send_resume_to": [a for a, _b in mails], "header_labels": labels, "employer": employer,
                         "company": company, "matches_company": bool(employer) and v347_same_org(employer, company)}
    note = ""
    if employer and not company_is_placeholder(company) and not v347_same_org(employer, company):
        note = f"Posted under {company}; the posting names {employer} as the employer."
    else:
        lab = next((x for x in labels if not v347_same_org(x, company)), "")
        if lab and employer and v347_same_org(employer, company):
            note = f"Posted under {lab}; the posting names {employer} as the employer."
    d["note"] = note
    d["other_orgs"] = sorted({o for o in emp + labels if o and not v347_same_org(o, company)})
    return d


def v347_letter_second_org(letter: str, company: str, other_orgs: list[str]) -> list[str]:
    """Letter sentences that name an organization from the posting other than application.company."""
    body = re.sub(r"Dear Hiring Manager,|Sincerely,|Jay Niketan Pathare", " ", str(letter))
    out = []
    for s in re.split(r"(?<=[.!?])\s+", re.sub(r"\s+", " ", body).strip()):
        if any(re.search(r"(?<!\w)" + re.escape(o) + r"(?!\w)", s, re.I) for o in other_orgs):
            out.append(s)
    return out


# --- A6. hook specificity detail -----------------------------------------------------------------------------------

def v347_hook_detail(hook: str, plan: dict[str, Any], raw_jd: str) -> dict[str, Any]:
    """hook_specific's one test, with its inputs: the hook shares a content word with the job title or the first
    responsibility line."""
    title = str(plan.get("application", {}).get("role", ""))
    resp = (top_responsibilities(raw_jd) or [""])[0]
    first = ""
    for raw in str(raw_jd).splitlines():
        t = re.sub(r"^[-*•·\s]+", "", raw).strip()
        if t and resp and resp.split()[0].lower() in t.lower()[:40] and len(t.split()) >= 4:
            first = t
            break
    generic = _V342_STOP | {"software", "engineer", "engineering", "developer", "development", "team", "work", "role", "build", "help", "want", "with", "about",
                            "company", "drawn", "interested", "opportunity", "level", "senior", "junior", "intern", "internship", "early", "careers", "career",
                            "graduate", "grad", "tech", "technology", "projects", "systems", "system", "drive", "draws"}
    words = lambda s: {w for w in re.findall(r"[a-z][a-z-]{3,}", s.lower()) if w not in generic}
    hw, tw, rw = words(hook), words(title), words(first or resp)
    d = {"ok": bool(hw & (tw | rw)), "hook_words": sorted(hw), "title_words": sorted(tw), "first_responsibility_line": (first or resp)[:200],
         "first_responsibility_words": sorted(rw)}
    if _v347_on("hook_fallback_v348"):   # v3.4.8a H: normalized title; role summary when the posting lists no responsibilities
        nd = _v348_hook_fallback(d, hook, plan, raw_jd, words)
        if nd["ok"] != d["ok"]:
            return nd
    return d


def v347_hook_reason(d: dict[str, Any]) -> dict[str, Any]:
    if d.get("role_text_source") == "role_summary":   # v3.4.8a H
        why = "no responsibility line was found, and the hook shares no content word with the job title or the role summary"
    elif not d.get("first_responsibility_line"):
        why = "no first responsibility line was found, and the hook shares no content word with the job title"
    elif not d.get("hook_words"):
        why = "the hook has no content words (only generic ones)"
    else:
        why = "the hook shares no content word with the job title or the first responsibility line"
    return {"test": "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line", "failed": why,
            "hook_words": d.get("hook_words", []), "title_words": d.get("title_words", []),
            "first_responsibility_line": d.get("first_responsibility_line", ""), "first_responsibility_words": d.get("first_responsibility_words", []),
            **({"role_summary": d.get("role_summary", ""), "role_summary_words": d.get("role_summary_words", [])} if d.get("role_text_source") == "role_summary" else {})}


# --- A5. outreach when the company is not stated -------------------------------------------------------------------

def _v347_outreach_no_company(li: dict[str, Any], company: str) -> None:
    """People searches leave the company keyword out (a "Not stated" company is not a name); the block says so."""
    import urllib.parse as _up
    key = _up.quote(re.sub(r"\s+", " ", company).strip() + " ")
    strip = lambda u: u.replace("keywords=" + key, "keywords=") if isinstance(u, str) else u
    li["people"] = {k: strip(v) for k, v in (li.get("people") or {}).items()}
    li["company_status"] = "not stated in the posting"
    block = str(li.get("block", "") or "")
    if block:
        block = block.replace("keywords=" + key, "keywords=")
        li["block"] = "Company: not stated in the posting, so the people searches leave the company out\n" + block


# --- A4 / A3 report post-run ---------------------------------------------------------------------------------------
_V347_UNQUOTED_SUFFIX = " (no posting line names it; script rule)"


def v347_split_changes(changes: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """(posting-driven entries, each quoting a JD line; internal entries, each with a reason)."""
    keep, internal = [], []
    for c in changes or []:
        if str(c.get("jd_line", "") or "").strip():
            keep.append(c)
            continue
        ch = str(c.get("change", ""))
        if ch.endswith(_V347_UNQUOTED_SUFFIX):
            ch, why = ch[: -len(_V347_UNQUOTED_SUFFIX)], "script rule: no posting line names it"
        elif "verb-only" in ch:
            why = "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"
        elif c.get("internal"):
            why = "script rule, not posting-driven"
        else:
            why = "no posting line quoted"
        internal.append({"change": ch, "reason": why})
    return keep, internal


def _v347_post_run(rep: dict[str, Any], out_dir: Path, argv: list[str]) -> None:
    if rep.get("skip"):
        return
    fails: list[dict[str, Any]] = []
    if _v347_on("report_fix"):
        keep, internal = v347_split_changes(rep.get("verify_changes_v344", []))
        rep["verify_changes_v344"] = keep
        if internal:
            rep["internal_changes"] = internal
    if _v347_on("heading_tech_fix") and _V347_CTX.get("heading"):
        rep["heading_tech_v347"] = _V347_CTX["heading"]
    if _v347_on("identity_fix"):
        try:
            raw = clean_jd_text(Path(argv[argv.index("--jd") + 1]).read_text(encoding="utf-8"))
        except Exception:
            raw = ""
        company = str((rep.get("tracker_row") or {}).get("Company", "") or _V347_CTX.get("company", ""))
        idt = v347_hiring_identity(raw, company) if raw else {}
        if idt and (idt.get("employer") or idt.get("header_labels")):
            rep["hiring_identity_v347"] = {k: idt[k] for k in ("employer", "employer_statements", "send_resume_to", "header_labels", "matches_company")}
            if idt.get("note"):
                rep.setdefault("notes", []).append(idt["note"])
        others = (idt or {}).get("other_orgs") or []
        for p in Path(out_dir).glob("*_Cover_Letter.txt"):
            bad = v347_letter_second_org(p.read_text(encoding="utf-8"), company, others) if others else []
            if bad:
                fails.append(fail("cover_letter_two_organizations", "cover_letter.hook", bad[:2],
                                  f"the letter names only application.company ({company}) as an organization",
                                  f"Rewrite cover_letter.hook (and any model sentence) so it names only {company}; other organizations from the posting go in Notes."))
    if fails:
        if rep.get("status") == "PASS":
            rep["status"] = "FAIL"
        rep.setdefault("failures", []).extend(fails)


_V347_CTX: dict[str, Any] = {"heading": {}, "company": ""}


# ===========================================================================
# v3.4.7b layer (2026-10-18). Four narrow fixes, each behind its own flag in master.json "v347_flags" (default true).
# With these four flags false the outputs are byte-identical to v3.4.7a (3_validation/diff_gate_v347b.py).
# New helper names only; every change to an existing function is made in its FINAL definition.
#  B1 sponsorship_polarity : a sponsorship blocker needs clearly NEGATIVE employer text; positive / neutral / badge
#                            text goes to Notes; unclear text keeps the v3.4.7a behaviour and Notes says so.
#  B2 or_groups            : "at least one of:" lists and inline "A, B, or C" are OR-groups; a covered group's other
#                            members are never hard gaps or stack gaps. hallucinations / grounding count as covered
#                            by the claim-check evidence (coverage mapping only, no new bullet text).
#  B3 sql_parse            : a literal "SQL" in a database requirement line becomes a requirement term.
#  B4 bullet_relevance     : GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / fleet postings;
#                            within a selected project a bullet changes only when a candidate outscores it by
#                            V347B_MARGIN points (fail-closed: projects, order, slot counts and lines never change).
# ===========================================================================
_V347B_CTX: dict[str, Any] = {}


def _v347b_reset() -> None:
    _V347B_CTX.clear()
    _V347B_CTX.update({"sponsor": None, "or_hard": [], "or_ambiguous": [], "sql": None, "bullets": None})


_v347b_reset()


# --- B1. sponsorship polarity ----------------------------------------------------------------------------------
_V347B_SP_MENTION = re.compile(r"sponsor|\bvisas?\b|h-?1-?b\b|green card|work authori[sz]ation|authori[sz]ed to work|citizenship", re.I)
_V347B_SP_NEG = re.compile(
    r"(?:will not|won't|cannot|can't|can ?not|unable to|does not|doesn't|do not|don't|is not able to|are not able to|not able to|will be unable to|are unable to|is unable to)"
    r"\s+(?:currently\s+|be able to\s+|now\s+)?(?:(?:offer|provide|support|consider|pursue|file|extend)\w*\s+(?:any\s+)?)?(?:visa\s+|h-?1-?b\s+|employment\s+|employer\s+|immigration\s+|work\s+)?sponsor"
    r"|authori[sz]ed to work[^.]{0,100}?without[^.]{0,40}?sponsor"
    r"|without (?:the need for |requiring |needing |need of )?(?:current or future |now or in the future |future |any )?(?:visa |employer |company |immigration |h-?1-?b |employment )?sponsorship"
    r"|\bno (?:visa |immigration |employer |h-?1-?b |work |employment )?sponsorship"
    r"|sponsorship (?:is |will )?(?:not|n't) (?:be )?(?:available|offered|provided|possible|supported)"
    r"|not eligible for[^.]{0,30}sponsorship"
    r"|(?:us |u\.s\. )?citizenship (?:is )?(?:required|mandatory)|must be (?:a )?(?:us |u\.s\. )?citizens?\b"
    r"|green card (?:holders? )?(?:is |are )?(?:required|only)|citizens? or (?:green card holders?|permanent residents?) only"
    r"|(?:will not|won't|cannot|can't|can ?not|unable to|does not|doesn't|do not|don't|not able to)\s+(?:be able to\s+)?(?:offer|provide|support|consider|extend|file|pursue|assist with|accept|process)\b[^.]{0,50}?(?:sponsor|visas?\b|immigration|petition|work permit)"
    r"|(?:sponsorship|visa|immigration)[^.]{0,60}?(?:will not|won't|not) be (?:considered|provided|offered|available|supported)", re.I)
_V347B_SP_BADGE = re.compile(r"sponsor likely|department of labor|\bdol\b|data powered by|receiving sponsorship|track record of (?:offering|sponsoring)|"
                             r"sponsorship (?:data|history|statistics|rate)|h-?1-?b (?:data|filings?|statistics|history)|does not guarantee sponsorship|"
                             r"^\s*h-?1-?b sponsorship\s*$", re.I)
_V347B_SP_POS = re.compile(r"sponsorship (?:is |may be )?(?:available|provided|offered|possible)|(?:will|can|does|do|is able to|are able to|happy to|willing to|open to)\s+"
                           r"(?:also\s+)?(?:provide\s+|offer\s+)?(?:visa\s+|h-?1-?b\s+)?sponsor|\bha(?:s|ve) sponsored\b|\bwe sponsor\b|eligible for (?:visa |h-?1-?b )?sponsorship|"
                           r"visa sponsorship: yes|sponsorship provided", re.I)
_V347B_SP_NEUTRAL = re.compile(r"sponsorship\W{0,3}(?:not stated|not specified|unknown|n/?a)\b|regardless of (?:visa|immigration|citizenship)", re.I)


def v347b_sponsor_polarity(text: str) -> str:
    """negative | badge | positive | neutral | unclear | none (no sponsorship / authorization wording)."""
    low = re.sub(r"\bU\.S\.", "US", " ".join(str(text).split()))
    if _V347B_SP_NEG.search(low):
        return "negative"
    if not _V347B_SP_MENTION.search(low):
        return "none"
    if _V347B_SP_BADGE.search(low):
        return "badge"
    if _V347B_SP_POS.search(low):
        return "positive"
    if _V347B_SP_NEUTRAL.search(low):
        return "neutral"
    if not re.search(r"sponsor|\bvisas?\b|h-?1-?b\b", low, re.I):
        return "none"   # plain "authorized to work" / citizenship wording: not a sponsorship statement (v3.4.7a rules apply)
    if len(low.split()) <= 3 and not low.rstrip().endswith((".", "!", "?")):
        return "none"   # a heading ("Visa policy", "Visa Sponsorship"); the statement under it is classified on its own
    return "unclear"


def _v347b_sentences(raw: str) -> list[str]:
    """Sentences and lines; a short sponsorship heading followed by a short value line with no sponsorship word of its
    own ("Visa Sponsorship" / "Case by case") is read as one statement ("Visa Sponsorship: Case by case")."""
    raw = re.sub(r"\bU\.S\.", "US", str(raw))
    out = [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n", raw) if s.strip()]
    i = 0
    while i < len(out) - 1:
        a, b = out[i], out[i + 1]
        if (len(a.split()) <= 3 and not a.endswith((".", "!", "?", ":")) and re.search(r"sponsor|\bvisas?\b|h-?1-?b\b", a, re.I)
                and len(b.split()) <= 6 and not _V347B_SP_MENTION.search(b) and not _V344_SECTION_WORDS.match(b)
                and v347b_sponsor_polarity(a) == "none"):
            out[i:i + 2] = [a + ": " + b]
        i += 1
    return out


def _v347b_sponsor_blockers(out: list[dict[str, Any]], plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    sents = _v347b_sentences(str(plan.get("_raw_jd_text", "")))
    found = [{"text": s[:200], "polarity": p} for s in sents for p in [v347b_sponsor_polarity(s)] if p != "none"]
    log: dict[str, Any] = {"statements": found, "blocker_before": None, "blocker_after": None, "action": "none"}
    keep = []
    for b in out:
        if b.get("type") != "work_authorization_or_sponsorship":
            keep.append(b)
            continue
        req = str(b.get("requirement", ""))
        pol = v347b_sponsor_polarity(req)
        log["blocker_before"] = {"requirement": req, "polarity": pol}
        if pol in ("negative", "unclear", "none"):   # FAIL-CLOSED: anything not clearly positive keeps the v3.4.7a blocker
            keep.append(b)
            log["action"] = "kept (" + {"negative": "negative wording", "unclear": "wording unclear: v3.4.7a behaviour"}.get(pol, "authorization wording: v3.4.7a behaviour") + ")"
            log["blocker_after"] = log["blocker_before"]
            continue
        neg = next((x["text"] for x in found if x["polarity"] == "negative"), "")
        if neg:   # the first match was positive text; the employer's negative statement elsewhere still blocks
            keep.append(dict(b, requirement=neg))
            log["action"] = "kept (requirement moved to the negative statement)"
            log["blocker_after"] = {"requirement": neg, "polarity": "negative"}
        else:
            log["action"] = f"removed ({pol} wording is information, not a blocker)"
    _V347B_CTX["sponsor"] = log if found or log["blocker_before"] else None
    return keep


def v347b_sponsor_notes(log: dict[str, Any] | None) -> list[str]:
    if not log:
        return []
    notes = []
    info = [x for x in log["statements"] if x["polarity"] in ("positive", "badge", "neutral")]
    if info:
        lab = {"positive": "employer says it sponsors", "badge": "job-board badge / sponsorship data", "neutral": "neutral"}
        notes.append("Sponsorship information (not a blocker): " + "; ".join(f"\"{x['text'][:100]}\" ({lab[x['polarity']]})" for x in info[:3]) + ".")
    unclear = [x for x in log["statements"] if x["polarity"] == "unclear"]
    if unclear:
        notes.append("Sponsorship wording unclear: check manually (\"" + unclear[0]["text"][:120] + "\").")
    return notes


# --- B2. OR-groups ------------------------------------------------------------------------------------------------
_V347B_LIST_HEAD = re.compile(r"\b(?:at least one of|one or more of|any of)\b[^:]{0,40}:\s*(?:the following\s*:?)?\s*$", re.I)
_V347B_INLINE_LEAD = re.compile(r"\b(?:such as|including|like|e\.g\.,?|for example,?|in at least one of|in one or more of|one or more of|any of)\s+", re.I)
_V347B_CLAIMCHECK = re.compile(r"\bhallucinat\w*|\bgrounding\b|\bgrounded (?:answers?|outputs?|responses?)", re.I)
_V347B_AGENT_MEMBER = re.compile(r"\b(?:llm|ai) agents?\b|\bagent(?:ic)? (?:products?|systems?|workflows?|applications?)\b|\bmulti-agent\b|\bai agent products?\b|\bllm agent products?\b", re.I)
_V347B_FILLER = re.compile(r"^(?:experience (?:with|in)|knowledge of|proficiency (?:with|in)|familiarity with)\s+|\s+(?:products?|systems?|development|tools?|frameworks?|platforms?|experience)$", re.I)


def _v347b_strip(line: str) -> str:
    s = re.sub(r"\*\*|__|`", "", str(line)).strip()
    return re.sub(r"^\s*(?:[-*+•·]|\d+[.)])\s*", "", s).strip()


def v347b_or_groups(raw: str) -> list[dict[str, Any]]:
    """[{kind, line, members, ambiguous}] for list groups ("at least one of the following:" + list lines) and inline
    groups ("languages such as A, B, or C") in one requirement line."""
    lines = [_v347b_strip(l) for l in str(raw).splitlines()]
    groups: list[dict[str, Any]] = []
    i = 0
    while i < len(lines):
        l = lines[i]
        if l and _V347B_LIST_HEAD.search(l):
            mem, j, why = [], i + 1, ""
            while j < len(lines):
                t = lines[j]
                if not t:
                    if mem:
                        break
                    j += 1
                    continue
                if t.endswith(".") or t.endswith(":") or len(t.split()) > 16:
                    break
                mem.append(t)
                j += 1
                if len(mem) > 8:
                    why = "more than 8 list lines"
                    break
            if len(mem) < 2:
                why = why or "fewer than 2 list lines after the lead-in"
            groups.append({"kind": "list", "line": l[:200], "members": mem, "ambiguous": why})
            i = j
            continue
        if l and re.search(r"\bor\b", l):
            for m in _V347B_INLINE_LEAD.finditer(l):
                seg = re.split(r"[.;:()]|\s+(?:and|with|to|for|in order)\s+(?!or\b)", l[m.end():])[0]
                if not re.search(r"\bor\b", seg):
                    continue
                items = [x.strip(" ,") for x in re.split(r",\s*(?:or\s+|and/or\s+)?|\s+or\s+|\s+and/or\s+", seg) if x.strip(" ,")]
                items = [re.sub(r"^(?:or|and)\s+", "", x) for x in items]
                if len(items) >= 2:
                    long_ = [x for x in items if len(x.split()) > 4]
                    groups.append({"kind": "inline", "line": l[:200], "members": items[:12], "ambiguous": "an item longer than 4 words" if long_ else ""})
        i += 1
    return groups


def _v347b_supported_set(master: dict[str, Any]) -> set[str]:
    cache = master.setdefault("_runtime_cache", {})
    if "v347b_supported" not in cache:
        names = {n.casefold() for n in _v332_supported_names(master)}
        names |= {re.sub(r"\s*\(.*\)$", "", n) for n in names if "(" in n}   # "AWS (EC2/RDS)" -> "aws"
        if "postgresql" in names:
            names.add("postgres")
        cache["v347b_supported"] = names
    return cache["v347b_supported"]


def v347b_member_covered(member: str, master: dict[str, Any]) -> str:
    """Why an OR-group member counts as covered ("" = not covered). Short names must be supported terms as a whole
    (after the usual normalization); longer members are covered only by the agent / claim-check mappings."""
    m = _V347B_FILLER.sub("", _V347B_FILLER.sub("", member.strip())).strip()
    if not m:
        return ""
    bad = [t for t in list(master.get("never_supported_terms", [])) + [str(x) for x in master.get("unsupported_claims", [])] if boundary_contains_plural(m, t)]
    if bad:
        return ""
    sup = _v347b_supported_set(master)
    for cand in (m, _norm_term(m, master)):
        if cand and cand.casefold() in sup:
            return "supported term " + _norm_term(m, master)
    if _V347B_AGENT_MEMBER.search(member):
        return "agent evidence (RIPPLE AI agent; GoingOnce multi-agent prototype)"
    if _V347B_CLAIMCHECK.search(member):
        return "claim-check evidence (RIPPLE zero-unsupported-claims evaluation and claim checks; LLM engine claim checks)"
    return ""


def v347b_or_cleared(raw: str, master: dict[str, Any]) -> tuple[dict[str, dict[str, Any]], list[dict[str, Any]]]:
    """{member casefold: {member, line, covered_by}} for every member of a covered, unambiguous OR-group, and the
    ambiguous groups (kept on the v3.4.7a behaviour)."""
    cleared, amb, inside = {}, [], set()
    for g in v347b_or_groups(raw):
        if g["ambiguous"]:
            amb.append(g)
            continue
        cov = [(x, v347b_member_covered(x, master)) for x in g["members"]]
        hit = next(((x, w) for x, w in cov if w), None)
        if not hit:
            continue
        inside |= {g["line"]} | (set(g["members"]) if g["kind"] == "list" else set())
        for x, w in cov:
            if not w:
                cleared.setdefault(x.casefold(), {"member": x, "line": g["line"], "covered_by": f"{hit[0]} ({hit[1]})"})
    # FAIL-CLOSED: a term that any other posting line names on its own stays a gap
    others = [l for l in (_v347b_strip(x) for x in str(raw).splitlines()) if l and l[:200] not in inside and l not in inside]
    for k in list(cleared):
        if any(boundary_contains_plural(l, cleared[k]["member"]) for l in others):
            cleared[k]["named_elsewhere"] = True
    return cleared, amb


def _v347b_in_cleared(term_spellings: list[str], cleared: dict[str, dict[str, Any]], raw: str = "") -> dict[str, Any] | None:
    """The cleared OR-group member that names the term, unless the member (or the term) is also named on a posting
    line outside every covered OR-group (then the term stays a gap: FAIL-CLOSED)."""
    inside = {i["line"] for i in cleared.values()} | {i["member"] for i in cleared.values()}
    others = [l for l in (_v347b_strip(x) for x in str(raw).splitlines()) if l and l[:200] not in inside and l not in inside] if raw else []
    for key, info in cleared.items():
        for s in term_spellings:
            if s and len(s) > 1 and boundary_contains_plural(info["member"], s):
                if info.get("named_elsewhere") or any(boundary_contains_plural(l, s) for l in others):
                    return None
                return info
    return None


def _v347b_relevant_amb(amb: list[dict[str, Any]], terms: list[str]) -> list[dict[str, Any]]:
    """Ambiguous groups are reported only when they name a gap term (where the reading would have mattered)."""
    return [g for g in amb if any(t and boundary_contains_plural(g["line"] + " " + " ".join(g["members"]), t) for t in terms)]


_V347B_FIT_ORDER = {"Low": 0, "Medium": 1, "High": 2}


def _v347b_or_hard_gaps(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    """B2 for requirements: an unsupported requirement that is a member of a covered OR-group is hedged (never a
    hard gap). Fit is recomputed the v3.3.2 way and rises at most one level; it never drops."""
    if not raw_plan.get("_jd_requirements_auto"):
        return
    cleared, amb = v347b_or_cleared(raw_jd, master)
    unsup = [str(x) for r in raw_plan.get("jd_requirements", []) or [] if isinstance(r, dict) and r.get("supported") is False and not r.get("hedged")
             for x in [r.get("term", ""), r.get("verbatim", "")] + list(r.get("aliases", []) or [])]
    _V347B_CTX["or_ambiguous"] = [{"line": g["line"], "members": g["members"], "why": g["ambiguous"]} for g in _v347b_relevant_amb(amb, unsup)]
    _V347B_CTX["or_cleared"] = cleared
    _V347B_CTX["or_raw"] = raw_jd
    if not cleared:
        return
    done = []
    for r in raw_plan.get("jd_requirements", []) or []:
        if not isinstance(r, dict) or r.get("supported") is not False or r.get("hedged"):
            continue
        spell = [str(r.get("term", "")), str(r.get("verbatim", ""))] + [str(a) for a in r.get("aliases", []) or []]
        info = _v347b_in_cleared(spell, cleared, raw_jd)
        if not info:
            continue
        if str(r.get("priority", "")).lower() in ("must", "high"):
            r["priority"] = "medium"
        r.pop("required_section", None)
        r["hedged"] = True
        r["alternative"] = True
        done.append({"term": str(r.get("term", "")), "member": info["member"], "line": info["line"], "covered_by": info["covered_by"]})
    if not done:
        return
    _V347B_CTX["or_hard"] = done
    raw_plan["_hedged_requirements"] = list(dict.fromkeys(list(raw_plan.get("_hedged_requirements", [])) + [d["term"] for d in done]))
    app = raw_plan.get("application", {})
    before = str(app.get("fit", ""))
    if before.lower() in ("", "auto", "low", "medium", "high"):
        _order = {"must": 0, "high": 1, "medium": 2}
        raw_plan["jd_requirements"] = sorted(raw_plan.get("jd_requirements", []), key=lambda r: _order.get(str(r.get("priority", "")).lower(), 2))
        musts = [r for r in raw_plan.get("jd_requirements", []) if r.get("priority") in ("must", "high")]
        sup = [r for r in musts if r.get("supported")]
        ratio = (len(sup) / len(musts)) if musts else 1.0
        new = "High" if ratio >= 0.85 else ("Medium" if ratio >= 0.6 else "Low")
        b0 = _V347B_FIT_ORDER.get(before.capitalize(), None)
        if b0 is not None:   # guards: at most one level up, never down
            n0 = _V347B_FIT_ORDER[new]
            n0 = max(b0, min(n0, b0 + 1))
            new = [k for k, v in _V347B_FIT_ORDER.items() if v == n0][0]
        app["fit"] = new
        _V347B_CTX["or_fit"] = {"before": before, "after": new}


def v347b_or_report(rep: dict[str, Any], master: dict[str, Any], raw: str) -> list[str]:
    """B2 for stack gaps (report / Notes only: jd_gap_terms keeps every term, so claim checks still block them)."""
    cleared, amb = v347b_or_cleared(raw, master)
    gap_terms = [str(t) for t in list(rep.get("jd_gap_terms_detected", []) or []) + list(rep.get("stack_gaps_v345", []) or [])]
    seen = {g["line"] for g in _V347B_CTX.get("or_ambiguous") or []}
    _V347B_CTX["or_ambiguous"] = list(_V347B_CTX.get("or_ambiguous") or []) + [
        {"line": g["line"], "members": g["members"], "why": g["ambiguous"]} for g in _v347b_relevant_amb(amb, gap_terms) if g["line"] not in seen]
    notes = []
    moved = []
    if cleared:
        terms = list(rep.get("jd_gap_terms_detected", []) or [])
        stack = list(rep.get("stack_gaps_v345", []) or [])
        hard = {_v345_term_key(g.get("term", "") if isinstance(g, dict) else g, master) for g in rep.get("hard_gaps", []) or []}
        for t in dict.fromkeys(terms + stack):
            if _v345_term_key(t, master) in hard:
                continue
            info = _v347b_in_cleared([str(t)], cleared, raw)
            if info:
                moved.append({"term": t, "line": info["line"], "covered_by": info["covered_by"]})
        if moved:
            mv = {m["term"] for m in moved}
            rep["jd_gap_terms_detected"] = [t for t in terms if t not in mv]
            rep["stack_gaps_v345"] = [t for t in stack if t not in mv]
            old = [n for n in rep.get("notes", []) or [] if str(n).startswith("Stack gaps")]
            rest = [n for n in rep.get("notes", []) or [] if not str(n).startswith("Stack gaps")]
            soft = [t for t in rep["jd_gap_terms_detected"] if _v345_term_key(t, master) not in hard]
            for t in rep["stack_gaps_v345"]:
                if t not in soft:
                    soft.append(t)
            new = []
            if soft and old:
                new.append("Stack gaps (named in the posting but not hard requirements, so Fit is not capped): "
                           + ", ".join(f"{t} (stack line)" if t in rep["stack_gaps_v345"] else t for t in soft) + ".")
            i = next((k for k, n in enumerate(rep.get("notes", []) or []) if str(n).startswith("Stack gaps")), len(rest))
            rep["notes"] = rest[:i] + new + rest[i:]
            notes.append("OR-group alternatives Jay does not have (the posting accepts any one, and another option is covered, so they are not gaps): "
                         + ", ".join(m["term"] for m in moved) + ".")
    hard_done = _V347B_CTX.get("or_hard") or []
    if hard_done:
        notes.append("OR-group: " + "; ".join(f"{d['term']} is one option of \"{d['line'][:80]}\" (covered by {d['covered_by'].split(' (')[0]}), so it is not a hard gap" for d in hard_done) + ".")
    amb = _V347B_CTX.get("or_ambiguous") or []
    if amb:
        notes.append("OR-group list unclear (kept the v3.4.7a reading): \"" + amb[0]["line"][:100] + "\".")
    if moved or hard_done or amb:
        rep["or_groups_v347b"] = {"stack_gaps_cleared": moved, "hard_gaps_cleared": hard_done, "ambiguous": amb,
                                  **({"fit": _V347B_CTX["or_fit"]} if _V347B_CTX.get("or_fit") else {})}
    return notes


# --- B3. SQL in a database requirement line -----------------------------------------------------------------------
_V347B_DB_LINE = re.compile(r"\b(?:databases?|rdbms|dbms|data ?stores?|relational)\b", re.I)
_V347B_SQL = re.compile(r"(?<![A-Za-z])SQL(?![A-Za-z])")


def v347b_sql_line(raw: str) -> str:
    for l in _v342_role_text(raw):
        if _V347B_DB_LINE.search(l) and _V347B_SQL.search(l):
            return l.strip()
    return ""


def _v347b_add_sql(reqs: list[dict[str, Any]], raw: str) -> list[dict[str, Any]]:
    if any(isinstance(r, dict) and str(r.get("term", "")).casefold() == "sql" for r in reqs):
        return reqs
    line = v347b_sql_line(raw)
    if not line:
        return reqs
    _V347B_CTX["sql"] = {"line": line[:200]}
    return list(reqs) + [{"term": "SQL", "priority": "medium", "supported": True, "verbatim": "SQL", "aliases": ["SQL"], "v347b_sql": True}]


# --- B4. bullet relevance within a project -----------------------------------------------------------------------
V347B_MARGIN = 6   # a candidate must outscore the 7a bullet by at least this many points
# v3.4.7c: the strict reading ("only supply-chain / warehouse / logistics / vehicle-fleet postings show the Fleet
# bullet") is the real rule C1, master.json v347_flags "strict_fleet" (it replaces the v3.4.7b V347B_STRICT_FLEET switch).
V347B_AI_PREFER = os.environ.get("V347B_AI_PREFER") == "1"
_V347B_LOGISTICS = re.compile(r"\bwarehous\w*|\blogistic\w*|\bsupply[- ]chains?\b|\bfulfil+ment\b|\bcold storage\b|\bfreight\b|\bdistribution cent\w+|"
                              r"\binventory\b|\btransportation\b|\b(?:vehicle|truck|delivery|rental|car|van|bus)\s+fleets?\b|\bfleet (?:management|operations|vehicles?|logistics|maintenance)\b|\btrucking\b|\bshipments?\b|"
                              r"\bshipping\b(?=\s+(?:and receiving|carriers?|costs?|rates?|labels?|logistics|operations|routes?|containers?|lanes?|docks?|centers?|partners?\b(?! conversation)))|\b(?:ground|freight|parcel|package|order|outbound|inbound) shipping\b", re.I)
_V347B_FLEET_ID = "goingonce.fleet.a"
_V347B_AI_GOINGONCE = ("goingonce.agents.a", "goingonce.agents.s1", "goingonce.negotiate.a", "goingonce.determ.a")
_V347B_LIMIT_LINE = re.compile(r"\bhallucinat\w*|\bgrounding\b|llm (?:limitations?|challenges?)|knowledge cutoffs?|\bunsupported claims?\b|\bfactual(?:ity)?\b", re.I)
_V347B_CLAIM_BULLET = re.compile(r"\bclaims?\b", re.I)
_V347B_STOP = set("""a an the and or of to in on for with by from at as is are be been was were this that these those it its into via per using use used
your you our we they their them will can may must should would could also plus such other than more most very well across within over under
work working experience years year strong ability able skills skill knowledge understanding including include team teams role build building built
new real every each any all both one two three who what which while when where so not no""".split())


def v347b_logistics_line(raw_plan: dict[str, Any], raw: str) -> str:
    w = next((l for l in _v342_role_text(raw) if _V347B_LOGISTICS.search(l)), "")
    if w:
        return w
    for s in (str(raw_plan.get("application", {}).get("role", "")), str(raw_plan.get("application", {}).get("company", ""))):
        if _V347B_LOGISTICS.search(s):
            return s
    return ""


_V347B_AI_RX = re.compile(r"\b(?:ai|ml|llm|machine learning|agents?|genai|generative|deep learning|data scien\w+)\b", re.I)


def v347b_ai_posting(raw_plan: dict[str, Any], lines: list[str]) -> bool:
    """AI / ML / LLM / agent posting: the title or the first 30 role lines name AI, ML, LLMs, agents or data science."""
    return bool(_V347B_AI_RX.search(str(raw_plan.get("application", {}).get("role", "")) + " " + " ".join(lines[:30])))


def _v347b_stems(text: str) -> set[str]:
    return {w[:6] for w in re.findall(r"[a-z][a-z0-9+#-]{2,}", str(text).casefold().replace("-", " ")) if w not in _V347B_STOP}


def v347b_bullet_score(v: dict[str, Any], post: set[str], ai: bool, limits: bool) -> int:
    s = len(_v347b_stems(" ".join([str(v.get("text", ""))] + [str(x) for x in v.get("jd_terms", []) or []])) & post)
    vid = str(v.get("id", ""))
    if ai and (vid in _V347B_AI_GOINGONCE or vid in V348C_F1_IDS):   # v3.4.8c F1: same fact as goingonce.determ.a
        s += 3
    if limits and vid.startswith(("ripple.", "tailor_pipeline.")) and _V347B_CLAIM_BULLET.search(str(v.get("text", ""))):
        s += 3
    return s


def _v347b_bullet_relevance(raw_plan, bank, pairs, sel, info, rerun):
    """B4: one swap at most per project, FAIL-CLOSED (any change to projects, slot counts, line count or the other
    bullets keeps the v3.4.7a selection)."""
    raw = str(raw_plan.get("_raw_jd_text", ""))
    lines = _v342_role_text(raw)
    post = _v347b_stems(" ".join(lines))
    ai = v347b_ai_posting(raw_plan, lines)
    limits = any(_V347B_LIMIT_LINE.search(l) for l in lines)
    logi = v347b_logistics_line(raw_plan, raw)
    vmap = {v.get("id"): v for p in bank.get("projects", {}).values() for v in p}
    log: dict[str, Any] = {"margin": V347B_MARGIN, "ai_posting": ai, "llm_limitation_line": limits, "logistics_line": logi[:160], "projects": {}, "swaps": []}
    cur = {k: list(v) for k, v in sel.items()}
    strict = _v347_on("strict_fleet") and not logi and not _V347C_CTX.get("off")   # v3.4.7c C1: the Fleet bullet leaves every non-logistics page
    _V347C_CTX["swaps"], _V347C_CTX["kept"] = [], []
    for pid, ids in sel.items():
        pool = [v for v in bank.get("projects", {}).get(pid, []) if v.get("status") == "ok"]
        if strict and _V347B_FLEET_ID in ids[1:]:   # v3.4.8c F1: the plain-code bullet without "Claude" (after the Claude one failed)
            pool += v348c_f1_candidates(bank, pid)
        sc = {v["id"]: v347b_bullet_score(v, post, ai, limits) for v in pool}
        log["projects"][pid] = {"selected": {i: sc.get(i) for i in ids}}
        if len(ids) < 2:
            continue
        weak = min(ids[1:], key=lambda i: (sc.get(i, 0), -ids.index(i)))   # the lead bullet (headline rule) never moves
        forced = strict and _V347B_FLEET_ID in ids[1:]
        if forced:
            weak = _V347B_FLEET_ID
        elif not _v347_on("bullet_relevance"):
            continue
        used_ev = {vmap[i].get("main_evidence_id") for i in cur[pid] if i in vmap and i != weak}
        verbs = {str(vmap[i].get("verb", "")).casefold() for p2 in cur.values() for i in p2 if i in vmap and i != weak}
        cands = [v for v in pool if v["id"] not in cur[pid] and v.get("lines") == vmap.get(weak, {}).get("lines")
                 and v.get("main_evidence_id") not in used_ev and str(v.get("verb", "")).casefold() not in verbs
                 and (logi or v["id"] != _V347B_FLEET_ID) and not (forced and v["id"] in (_V347C_CTX.get("exclude") or []))]
        if not cands:
            if forced:
                _V347C_CTX["kept"].append({"project": pid, "bullet": weak, "reason": "no other bullet with the same line count, a new evidence id and a unique verb"})
            continue
        f1c = [v for v in cands if forced and v["id"] in V348C_F1_IDS]   # v3.4.8c F1: the plain-code bullet is a last resort
        if f1c and len(f1c) < len(cands):
            cands = [v for v in cands if v not in f1c]
        else:
            f1c = []
        best = max(cands, key=lambda v: (sc[v["id"]], -pool.index(v)))
        diff = sc[best["id"]] - sc.get(weak, 0)
        log["projects"][pid]["best_candidate"] = {best["id"]: sc[best["id"]]}
        b4 = _v347_on("bullet_relevance") and diff >= V347B_MARGIN   # a B4 swap keeps its B4 log even where C1 also applies
        if not b4 and not forced:
            continue
        trial = {k: list(v) for k, v in cur.items()}
        trial[pid] = [best["id"] if i == weak else i for i in trial[pid]]
        res = rerun(trial, weak, best["id"])
        if f1c and not b4 and (res is None or {k: list(v) for k, v in res[0].items()} != trial):   # v3.4.8c F1 last resort
            alt = max(f1c, key=lambda v: (sc[v["id"]], -pool.index(v)))
            trial2 = {k: list(v) for k, v in cur.items()}
            trial2[pid] = [alt["id"] if i == weak else i for i in trial2[pid]]
            res2 = rerun(trial2, weak, alt["id"])
            if res2 is not None and {k: list(v) for k, v in res2[0].items()} == trial2:
                best, trial, res = alt, trial2, res2
        if res is None or {k: list(v) for k, v in res[0].items()} != trial:
            if b4:
                log["projects"][pid]["kept"] = f"swap {weak} -> {best['id']} not valid on the page (fail-closed)"
                log["projects"][pid]["rerun"] = None if res is None else res[0]
            if forced:
                _V347C_CTX["kept"].append({"project": pid, "bullet": weak, "candidate": best["id"], "reason": "the selector does not reproduce the swap (fail-closed)"})
            continue
        sel, info = res
        cur = {k: list(v) for k, v in sel.items()}
        if b4:
            log["swaps"].append({"project": pid, "before": weak, "after": best["id"], "score_before": sc.get(weak, 0), "score_after": sc[best["id"]], "margin": diff})
        else:
            _V347C_CTX["swaps"].append({"project": pid, "before": weak, "after": best["id"], "score_after": sc[best["id"]],
                                        "_vb": deepcopy(vmap[weak]), "_va": deepcopy(best)})
    if strict and _v347_on("fleet_repick_v348") and _V347B_FLEET_ID in (cur.get("goingonce") or []):   # v3.4.8c F2
        res = v348c_fleet_repick(raw_plan, bank, pairs, cur, rerun)
        if res is not None:
            sel, info = res
            cur = {k: list(v) for k, v in sel.items()}
    _V347B_CTX["bullets"] = log
    if os.environ.get("V347B_DEBUG"):   # test-only: V347B_DEBUG=<path> dumps the B4 log (never set it inside Sources)
        Path(os.environ["V347B_DEBUG"]).write_text(json.dumps(log, indent=1, default=str), encoding="utf-8")
    return sel, info


def _v347b_rerun_factory(raw_plan, bank, pairs, core):
    """Re-run the v3.4.7a selector with the replaced bullet excluded and the new one preferred."""
    def rerun(trial, out_id, in_id):
        b2 = deepcopy(bank)
        for p in b2.get("projects", {}).values():
            for v in p:
                if v.get("id") == out_id:
                    v["status"] = "excluded_v347b"
                elif v.get("id") == in_id and v.get("status") == V348C_SWAP_ONLY:   # v3.4.8c F1
                    v["status"] = "ok"
        old = raw_plan.get("prefer_variants")
        raw_plan["prefer_variants"] = list(dict.fromkeys(list(old or []) + [in_id]))
        keep = v349_rerun_state(raw_plan)   # v3.4.9a fix 5: a rerun whose result is not taken leaves no state behind
        try:
            res = _v347b_sel_or_none(core(raw_plan, b2, pairs))
            if keep is not None and (res is None or {k: list(v) for k, v in res[0].items()} != trial):
                v349_restore_state(raw_plan, keep)
            return res
        finally:
            raw_plan["prefer_variants"] = old if old is not None else []
    rerun.core = core   # v3.4.8c F2 re-picks with the same selector
    return rerun


def _v347b_sel_or_none(res):
    sel, info = res
    return None if sel is None else (sel, info)


# --- post-run -------------------------------------------------------------------------------------------------------
def _v347b_post_run(rep: dict[str, Any], out_dir: Path, argv: list[str]) -> None:
    if rep.get("skip"):
        return
    try:
        master = json.loads(Path(argv[argv.index("--master") + 1]).read_text(encoding="utf-8"))
        raw = clean_jd_text(Path(argv[argv.index("--jd") + 1]).read_text(encoding="utf-8"))
    except Exception:
        return
    add = []
    if _v347_on("sponsorship_polarity"):
        log = _V347B_CTX.get("sponsor")
        add += v347b_sponsor_notes(log)
        if log and log.get("blocker_before"):
            rep["sponsorship_v347b"] = {k: log[k] for k in ("blocker_before", "blocker_after", "action")}
    if _v347_on("or_groups"):
        add += v347b_or_report(rep, master, raw)
    if _v347_on("sql_parse") and _V347B_CTX.get("sql"):
        cov = next((c for c in rep.get("ats_coverage", []) or [] if str(c.get("term", "")).casefold() == "sql"), None)
        rep["sql_term_v347b"] = dict(_V347B_CTX["sql"], status=(cov or {}).get("status", "not reported"), surface=(cov or {}).get("surface"))
    if _v347_on("bullet_relevance") and (_V347B_CTX.get("bullets") or {}).get("swaps"):
        rep["bullet_relevance_v347b"] = {k: _V347B_CTX["bullets"][k] for k in ("margin", "swaps", "logistics_line", "ai_posting", "llm_limitation_line")}
    if add:
        rep.setdefault("notes", []).extend(add)


# ===========================================================================
# v3.4.7c layer (2026-10-18). One rule, behind master.json v347_flags "strict_fleet" (default true). With it false the
# outputs are byte-identical to v3.4.7b (3_validation/diff_gate_v347c.py). New helper names only; changes to existing
# functions are made in their FINAL definitions (_v347b_bullet_relevance, auto_bank_selection, build_skill_states,
# _v33_project_sentences, main_v3_1).
#  C1 strict_fleet : GoingOnce's Fleet bullet appears only on supply-chain / warehouse / logistics / vehicle-fleet
#                    postings (the v3.4.7b B4 logistics test). Elsewhere it is replaced by the best-scoring other
#                    GoingOnce bullet with the same line count, a new evidence id and a unique verb, and only when the
#                    selector reproduces that exact swap (FAIL-CLOSED: otherwise the Fleet bullet stays). Projects,
#                    order, slot counts, Skills, Fit and the letter never change, apart from the bullet itself and, where
#                    the letter carried the Fleet fact, that one sentence (it becomes the replacement bullet's sentence).
# ===========================================================================
from contextlib import contextmanager
_V347C_CTX: dict[str, Any] = {"swaps": [], "kept": [], "letter": {}}
_V347C_BULLET_KEYS = ("text", "verb", "main_evidence_id", "supporting_evidence_ids", "claims", "jd_terms")


def _v347c_active(plan: dict[str, Any], pid: str | None = None) -> list[dict[str, Any]]:
    """The C1 swaps whose replacement bullet is on this plan's page (for one project, or all)."""
    sel = plan.get("bank_selection") if isinstance(plan.get("bank_selection"), dict) else {}
    return [w for w in _V347C_CTX.get("swaps") or [] if (pid is None or w["project"] == pid)
            and w["after"] in (sel.get(w["project"]) or []) and w["before"] not in (sel.get(w["project"]) or [])]


@contextmanager
def _v347c_pre_swap(plan: dict[str, Any]):
    """Temporarily put the Fleet bullet back (selection ids and expanded bullet), restoring the page afterwards."""
    swaps = _v347c_active(plan)
    keep_sel, keep_b = plan.get("bank_selection"), plan.get("bullets")
    sel, bullets = deepcopy(keep_sel), deepcopy(keep_b)
    for w in swaps:
        pid = w["project"]
        sel[pid] = [w["before"] if i == w["after"] else i for i in sel[pid]]
        if isinstance(bullets, dict):
            for k, b in enumerate(bullets.get(pid) or []):
                if isinstance(b, dict) and b.get("text") == w["_va"].get("text"):
                    nb = dict(b)
                    nb.update({x: deepcopy(w["_vb"][x]) for x in _V347C_BULLET_KEYS if x in w["_vb"]})
                    for x in ("_variant_id", "id"):
                        if x in nb:
                            nb[x] = w["before"]
                    bullets[pid][k] = nb
    plan["bank_selection"], plan["bullets"] = sel, bullets
    try:
        yield
    finally:
        plan["bank_selection"], plan["bullets"] = keep_sel, keep_b


def _v347c_sentence(master: dict[str, Any], pid: str, v: dict[str, Any]) -> str:
    bank = ((master.get("cover_letter_bank") or {}).get("letter_sentences") or {}).get(pid) or {}
    return str(bank.get(v.get("id")) or bank.get(v.get("main_evidence_id")) or "")


def _v347c_letter_swap(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    """The Fleet bullet's letter sentence becomes the replacement bullet's sentence; nothing else in the letter changes.
    A closing built on the Fleet proof, or a letter over 200 words, fails (the run retries another bullet)."""
    fails: list[dict[str, Any]] = []
    paras = list(plan.get("cover_letter_paragraphs") or [])
    for w in _v347c_active(plan):
        if w.get("letter") is False:   # v3.4.8c F2: a re-picked bullet that did not replace Fleet leaves the letter alone
            continue
        pid = w["project"]
        old, new = _v347c_sentence(master, pid, w["_vb"]), _v347c_sentence(master, pid, w["_va"])
        cp = ((master.get("cover_letter_bank") or {}).get("closing_proofs") or {}).get(str(w["_vb"].get("main_evidence_id")), "")
        closing = str((plan.get("_v342_closing") or {}).get("text") or "")
        if cp and cp in closing:
            fails.append(fail("v347c_fleet_closing", "cover_letter.closing", closing, "a closing that does not rest on the Fleet bullet", "C1 retries another bullet."))
        if not old or not any(old in p for p in paras):
            continue
        if not new or any(new in p for p in paras):
            fails.append(fail("v347c_letter_sentence", "cover_letter", old, "a replacement sentence for the Fleet fact", "C1 retries another bullet."))
            continue
        paras = [p.replace(old, new) for p in paras]
        ls = (plan.get("_v342_letter_sentences") or {}).get(pid)
        if isinstance(ls, list):
            plan["_v342_letter_sentences"][pid] = [new if x == old else x for x in ls]
        _V347C_CTX["letter"] = {"project": pid, "before": old, "after": new}
    plan["cover_letter_paragraphs"] = paras
    if _V347C_CTX.get("letter") and _v344_words(paras) > _V344_LETTER_MAX:
        fails.append(fail("cover_letter_over_200_words", "cover_letter", _v344_words(paras), "<= 200 words including greeting and sign-off", "C1 retries another bullet."))
    return fails


def _v347c_retry(argv: list[str]) -> int:
    """C1 FAIL-CLOSED: a build whose Fleet swap does not pass (Skills would have to change, the letter would pass 200
    words, ...) is rebuilt with the next replacement bullet; when none passes, with the Fleet bullet (v3.4.7b page)."""
    _V347C_CTX.update({"inner": True, "exclude": [], "off": False, "tried": [], "f2": []})
    try:
        out_dir = Path(argv[argv.index("--out-dir") + 1]) if "--out-dir" in argv else None
        for k in range(4):
            if k:
                _V343_FLAGS.pop("slot_start", None)
            sys.argv = list(argv)
            rc = main_v3_1()
            swaps = [w["after"] for w in _V347C_CTX.get("swaps") or []]
            try:
                rep = json.loads((out_dir / "report.json").read_text(encoding="utf-8")) if out_dir else {}
            except Exception:
                rep = {}
            if not swaps or rep.get("status") == "PASS":
                return rc
            _V347C_CTX["tried"].append({"after": swaps, "failures": sorted({str(f.get("type")) for f in rep.get("failures", []) or []})})
            _V347C_CTX["exclude"] = list(_V347C_CTX["exclude"]) + swaps
        _V347C_CTX["off"] = True
        _V343_FLAGS.pop("slot_start", None)
        sys.argv = list(argv)
        return main_v3_1()
    finally:
        _V347C_CTX["inner"] = False
        if os.environ.get("V347C_DEBUG"):   # test-only: V347C_DEBUG=<path> dumps the C1 attempts (never set it inside Sources)
            Path(os.environ["V347C_DEBUG"]).write_text(json.dumps({k: v for k, v in _V347C_CTX.items() if k in ("tried", "exclude", "off", "kept", "letter")}
                                                                  | {"swaps": [{k: x[k] for k in ("project", "before", "after")} for x in _V347C_CTX.get("swaps") or []]}, indent=1), encoding="utf-8")


def _v347c_post_run(rep: dict[str, Any], out_dir: Path, argv: list[str]) -> None:
    if rep.get("skip") or not _v347_on("strict_fleet") or not _V347C_CTX.get("swaps"):
        return
    try:
        rp_ = json.loads((out_dir / "resolved_plan.json").read_text(encoding="utf-8"))
    except Exception:
        rp_ = {}
    sel = rp_.get("bank_selection") or {}
    swaps = [w for w in _V347C_CTX["swaps"] if w["after"] in (sel.get(w["project"]) or [])]
    if not swaps:
        return
    log = {"rule": "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found",
           "swaps": [{"project": w["project"], "before": w["before"], "after": w["after"], "before_text": w["_vb"].get("text"),
                      "after_text": w["_va"].get("text"), "lines": w["_va"].get("lines"), "verb": w["_va"].get("verb")} for w in swaps]}
    if _V347C_CTX.get("letter"):
        log["letter_sentence"] = dict(_V347C_CTX["letter"])
    rep["strict_fleet_v347c"] = log



# ===========================================================================
# v3.4.8a layer (2026-10-19). Low-risk build: resumes, letters and tracker rows never change. Three changes, each
# behind its own flag in master.json "v347_flags" (default true); with all three false every output equals v3.4.7c
# (3_validation/diff_gate_v348a.py). New helper names only; every change to an existing function is made in its FINAL
# definition (build_outreach, v347_hiring_identity, v347_hook_detail, v347_hook_reason, build_cover_letter, main_v3_1).
#  O outreach_v348          : report.json outreach.linkedin.block_md (markdown links, each note in its own text block),
#                             four short notes in Jay's own voice (hiring manager, engineers, recruiters, UB alumni),
#                             2-3 templates per audience picked by a stable hash of company + role; the O2 validator
#                             fails the build on a bad note. outreach.linkedin.block stays (plain, with the new notes).
#  E employer_phrasings_v348: "<Org> is searching for / is looking for / is seeking / seeks / is recruiting" are
#                             employer statements (A3); <Org> must be a proper name. Notes only, never a rename.
#  H hook_fallback_v348     : a posting with no responsibility line checks the hook against its role summary; job
#                             titles are normalized ("Developer-" -> "Developer"). Report-level only.
# ===========================================================================
import hashlib as _v348_hashlib

# --- O. outreach -------------------------------------------------------------------------------------------------
V348_PROJECT_NAMES = ("RIPPLE", "LedgerFlow", "LaunchOps", "GoingOnce", "Fraud", "Pintos", "Optimization Engine")
V348_BANNED = ("referral", "considered", "opportunity to", "I am excited", "passionate", "Not stated")
V348_NOTE_MAX = 300
V348_AUDIENCES = ("hiring_manager", "engineer", "recruiter", "ub_alum")
V348_DOMAIN_FALLBACK = "backend systems"
# Each template: (with a company, without one). {Name} stays for Jay; {Company}, {the_role} and {domain} are filled.
# {domain} is only ever something Jay works on or enjoys, never tied to one employer (master outreach.domain_phrases_v348).
V348_TEMPLATES: dict[str, list[tuple[str, str]]] = {
    "ub_alum": [
        ("Hi {Name}, I'm a CS grad student at UB and came across your profile while reading about {Company}. I'd love to hear how you made the jump from UB and what your work there looks like. Would you be open to a quick chat sometime? Thanks, Jay",
         "Hi {Name}, I'm a CS grad student at UB and came across your profile while reading about your team. I'd love to hear how you made the jump from UB and what your work looks like now. Would you be open to a quick chat sometime? Thanks, Jay"),
        ("Hi {Name}, fellow UB grad student here. I've been working mostly on {domain}, and your path to {Company} caught my eye. If you ever have a few minutes, I'd really like to hear what it's been like on your side. Thanks, Jay",
         "Hi {Name}, fellow UB grad student here. I've been working mostly on {domain}, and your path after UB caught my eye. If you ever have a few minutes, I'd really like to hear what it's been like on your side. Thanks, Jay"),
        ("Hi {Name}, I'm doing my MS in CS at UB and saw that you went from UB to {Company}. I'd be curious how you found your way there and what a normal week looks like for you. Open to a short chat sometime? Best, Jay",
         "Hi {Name}, I'm doing my MS in CS at UB and saw your path after UB. I'd be curious how you found your way to your current team and what a normal week looks like for you. Open to a short chat sometime? Best, Jay"),
    ],
    "engineer": [
        ("Hi {Name}, I'm a CS grad student at UB who enjoys working on {domain}. I've been reading about what the engineering team at {Company} builds and would love to connect and hear how you like the work. Thanks, Jay",
         "Hi {Name}, I'm a CS grad student at UB who enjoys working on {domain}. I've been reading about what your engineering team builds and would love to connect and hear how you like the work. Thanks, Jay"),
        ("Hi {Name}, I came across your profile while looking into engineering at {Company}. I work mostly on {domain} and I'm curious how your team approaches it. Happy to connect if you're open to it. Best, Jay",
         "Hi {Name}, I came across your profile while looking into your team's engineering work. I work mostly on {domain} and I'm curious how your team approaches it. Happy to connect if you're open to it. Best, Jay"),
        ("Hi {Name}, I'm a grad student at UB and have spent a lot of my time on {domain}. I'd love to connect and hear what you're working on at {Company} and what you like most about the team. Thanks, Jay",
         "Hi {Name}, I'm a grad student at UB and have spent a lot of my time on {domain}. I'd love to connect and hear what you're working on and what you like most about your team. Thanks, Jay"),
    ],
    "hiring_manager": [
        ("Hi {Name}, I recently applied for {the_role} on your team. I'm finishing my MS in CS at UB, with startup and internship experience, and lately I've focused on {domain}. Glad to connect and share more if it helps. Thanks, Jay",
         "Hi {Name}, I recently applied for {the_role} on your team. I'm finishing my MS in CS at UB, with startup and internship experience, and lately I've focused on {domain}. Glad to connect and share more if it helps. Thanks, Jay"),
        ("Hi {Name}, I applied for {the_role} at {Company} and wanted to say hello. I'm a CS grad student at UB with startup experience, and most of my recent focus has been {domain}. Glad to connect either way. Best, Jay",
         "Hi {Name}, I applied for {the_role} on your team and wanted to say hello. I'm a CS grad student at UB with startup experience, and most of my recent focus has been {domain}. Glad to connect either way. Best, Jay"),
        ("Hi {Name}, I saw {the_role} at {Company} and sent in my application. A bit about me: I'm wrapping up my master's at UB, I've worked at a startup and in internships, and I enjoy working on {domain}. Would be glad to connect. Thanks, Jay",
         "Hi {Name}, I saw {the_role} on your team and sent in my application. A bit about me: I'm wrapping up my master's at UB, I've worked at a startup and in internships, and I enjoy working on {domain}. Would be glad to connect. Thanks, Jay"),
    ],
    "recruiter": [
        ("Hi {Name}, I applied for {the_role} at {Company} and thought I'd reach out. I'm wrapping up my MS in CS at UB, with startup and internship experience, and I enjoy working on {domain}. Happy to answer anything that helps on your side. Thanks, Jay",
         "Hi {Name}, I applied for {the_role} on your team and thought I'd reach out. I'm wrapping up my MS in CS at UB, with startup and internship experience, and I enjoy working on {domain}. Happy to answer anything that helps on your side. Thanks, Jay"),
        ("Hi {Name}, quick hello. I put in an application for {the_role} at {Company}. I'm a CS grad student at UB with startup experience, mostly focused on {domain}, and I'd be glad to connect. Best, Jay",
         "Hi {Name}, quick hello. I put in an application for {the_role} on your team. I'm a CS grad student at UB with startup experience, mostly focused on {domain}, and I'd be glad to connect. Best, Jay"),
        ("Hi {Name}, I wanted to say hello since I recently applied for {the_role} at {Company}. I'm finishing my master's in CS at UB and have startup and internship experience. Lately I've been focused on {domain}. Happy to share more anytime. Best, Jay",
         "Hi {Name}, I wanted to say hello since I recently applied for {the_role} on your team. I'm finishing my master's in CS at UB and have startup and internship experience. Lately I've been focused on {domain}. Happy to share more anytime. Best, Jay"),
    ],
}
V348_OPEN_ROLE = "the open role"
V348_HEADINGS = {"hiring_manager": ("1. Hiring manager", "Find hiring managers", "manager"),
                 "engineer": ("2. Software engineers / team members", "Find engineers", "team_engineers"),
                 "recruiter": ("3. Technical recruiters", "Find technical recruiters", "recruiters"),
                 "ub_alum": ("4. University at Buffalo alumni", "Find UB alumni", "ub_alumni")}
V348_PLAIN_LABELS = {"hiring_manager": "Note to hiring manager", "engineer": "Note to engineers", "recruiter": "Note to recruiter", "ub_alum": "Note to UB alum"}


def v348_note_problems(note: str, requisition_id: str = "") -> list[str]:
    """The O2 validator. Every problem is a build failure."""
    n = str(note or "")
    probs = []
    if len(n) > V348_NOTE_MAX:
        probs.append(f"over {V348_NOTE_MAX} characters ({len(n)})")
    if re.search(r"\d", n):
        probs.append("contains a digit")
    for p in V348_PROJECT_NAMES:
        if re.search(r"(?<![A-Za-z])" + re.escape(p) + r"(?![A-Za-z])", n, re.I):
            probs.append(f"names a project ({p})")
    rid = str(requisition_id or "").strip()
    if rid and rid.lower() in n.lower():
        probs.append("contains the requisition ID")
    for b in V348_BANNED:
        if b.lower() in n.lower():
            probs.append(f"contains \"{b}\"")
    if "!" in n:
        probs.append("contains an exclamation mark")
    if "—" in n or "–" in n:
        probs.append("contains an em or en dash")
    if not re.search(r"(?:Thanks|Best), Jay$", n):
        probs.append("does not end \"Thanks, Jay\" or \"Best, Jay\"")
    if "{Name}" not in n:
        probs.append("lost the {Name} placeholder")
    return probs


def v348_template_index(company: str, role: str, audience: str, n: int) -> int:
    """Stable choice: the same company + role always gets the same template; different postings get different ones."""
    key = (re.sub(r"\s+", " ", str(company)).strip().lower() + "|" + re.sub(r"\s+", " ", str(role)).strip().lower() + "|" + audience).encode("utf-8")
    return int(_v348_hashlib.sha256(key).hexdigest(), 16) % n


def v348_domain(plan: dict[str, Any], master: dict[str, Any]) -> tuple[str, str]:
    """(domain phrase, role family) from master outreach.domain_phrases_v348 (each phrase backed by master evidence)."""
    fam = str(plan.get("role_family", "") or "")
    if not fam or fam == "auto":
        fam = str((plan.get("_resolved_fields") or {}).get("role_family", "") or "")
    phrases = ((master.get("outreach") or {}).get("domain_phrases_v348") or {})
    d = phrases.get(fam) or phrases.get("general_swe") or {}
    return str(d.get("phrase") or V348_DOMAIN_FALLBACK), fam


def v348_the_role(short_role: str) -> str:
    s = re.sub(r"\s+", " ", v348_normalize_title(short_role or "")).strip()   # "Developer- Full Stack" -> "Developer Full Stack"
    if not s:
        return V348_OPEN_ROLE
    if s.lower().startswith("the "):
        return s
    return "the " + s + ("" if re.search(r"intern", s, re.I) else " role")


def v348_fill(tpl: str, company: str, the_role: str, domain: str) -> str:
    return re.sub(r"\s+", " ", tpl.replace("{Company}", company).replace("{the_role}", the_role).replace("{domain}", domain)).strip()


def v348_pick_note(audience: str, company: str, role: str, short_role: str, domain: str, requisition_id: str = "") -> dict[str, Any]:
    """First passing note from: the hashed template with company and role, then "the open role", then no company
    (notes say "your team"), then the next template in the same order."""
    tpls = V348_TEMPLATES[audience]
    co_ok = bool(company) and not company_is_placeholder(company)
    start = v348_template_index(company, role, audience, len(tpls))
    tried = []
    for k in range(len(tpls)):
        i = (start + k) % len(tpls)
        with_co, no_co = tpls[i]
        tries = ([(with_co, company, v348_the_role(short_role)), (with_co, company, V348_OPEN_ROLE)] if co_ok else []) + \
                [(no_co, "", v348_the_role(short_role)), (no_co, "", V348_OPEN_ROLE)]
        for tpl, co, the_role in tries:
            note = v348_fill(tpl, co, the_role, domain)
            probs = v348_note_problems(note, requisition_id)
            if not probs:
                return {"note": note, "template": f"{audience}.{'ABC'[i]}", "company_named": bool(co) and "{Company}" in tpl,
                        "role_named": the_role != V348_OPEN_ROLE and "{the_role}" in tpl}
            tried.append({"template": f"{audience}.{'ABC'[i]}", "problems": probs})
    return {"note": "", "template": "", "problems": tried}


def _v348_md_text(s: str) -> str:
    return str(s).replace("\\", "\\\\").replace("[", "\\[").replace("]", "\\]")


def v348_block_md(li: dict[str, Any], company: str) -> str:
    """The markdown block the model prints exactly: every link a markdown link, every note alone in a text block."""
    import urllib.parse as _up
    co_ok = bool(company) and not company_is_placeholder(company)
    cname = _v348_md_text(re.sub(r"\s+", " ", company).strip())
    if co_ok:
        cp = str(li.get("company_page", "") or "")
        url = cp if cp.startswith("https://") else "https://www.linkedin.com/search/results/companies/?keywords=" + _up.quote(re.sub(r"\s+", " ", company).strip())
        head = [f"Company: [{cname} on LinkedIn]({url})"]
    else:
        head = ["Company: not stated in the posting"]
    jp = str(li.get("job_post", "") or "")
    head.append(f"Job post: [view]({jp})" if jp.startswith("https://") else f"Job post: [search]({li.get('job_search', '')})")
    if li.get("requisition_id") and li.get("job_search_requisition"):
        head.append(f"Req: [search]({li['job_search_requisition']})")
    out = [" · ".join(head)]
    notes = li.get("notes") or {}
    people = li.get("people") or {}
    for aud in V348_AUDIENCES:
        h, label, pkey = V348_HEADINGS[aud]
        out += ["", f"### {h}", f"[{label}{' at ' + cname if co_ok else ''}]({people.get(pkey, '')})", "```text", str(notes.get(aud, "")), "```"]
    return "\n".join(out)


def _v348_outreach(li: dict[str, Any], plan: dict[str, Any], master: dict[str, Any]) -> None:
    """New notes (all four audiences) replace the old ones in notes, notes_chars and the plain block."""
    app = plan.get("application", {}) or {}
    company = re.sub(r"\s+", " ", str(app.get("company", "") or "")).strip()
    role = re.sub(r"\s+", " ", str(app.get("role", "") or "")).strip()
    domain, fam = v348_domain(plan, master)
    rid = str(li.get("requisition_id", "") or "")
    notes, picks, problems = {}, {}, {}
    for aud in V348_AUDIENCES:
        r = v348_pick_note(aud, company, role, str(li.get("short_role", "") or ""), domain, rid)
        notes[aud] = r["note"]
        picks[aud] = r["template"]
        if not r["note"]:
            problems[aud] = r.get("problems", [])
    li["notes"] = notes
    li["notes_chars"] = {k: len(v) for k, v in notes.items()}
    li["note_numbers_not_on_resume"] = []
    li["notes_v348"] = {"domain": domain, "role_family": fam, "templates": picks}
    if problems:
        li["notes_v348"]["problems"] = problems
    block = str(li.get("block", "") or "")
    keep = [ln for ln in block.splitlines() if not ln.startswith("Note to ")]
    li["block"] = "\n".join(keep + [f"{V348_PLAIN_LABELS[a]} ({len(notes[a])} chars): {notes[a]}" for a in V348_AUDIENCES])


def _v348_post_run(rep: dict[str, Any], out_dir: Path, argv: list[str]) -> None:
    """O2: every outreach note passes the validator, else the build fails."""
    if rep.get("skip") or not _v347_on("outreach_v348"):
        return
    li = (rep.get("outreach") or {}).get("linkedin") if isinstance(rep.get("outreach"), dict) else None
    if not isinstance(li, dict):
        return
    rid = str(li.get("requisition_id", "") or "")
    bad = {a: v348_note_problems((li.get("notes") or {}).get(a, ""), rid) for a in V348_AUDIENCES}
    bad = {a: p for a, p in bad.items() if p}
    if not li.get("block_md"):
        bad["block_md"] = ["missing"]
    if bad:
        if rep.get("status") == "PASS":
            rep["status"] = "FAIL"
        rep.setdefault("failures", []).append(fail("outreach_note_invalid", "outreach.linkedin.notes", bad,
                                                   "every note: <=300 characters, no digits, project names, requisition IDs or banned words, ends Thanks, Jay / Best, Jay, keeps {Name}",
                                                   "Pipeline defect: report it."))


# --- E. employer phrasings ---------------------------------------------------------------------------------------
_V348_SEEKS = re.compile(r"(?m)(?:^|(?<=[.!?]\s))" + _V347_ORG + r"(?:\s*\([A-Z][A-Za-z&]{1,9}\))?(?:,[^.\n]{0,160}?,)?\s+"
                         r"(?i:is\s+(?:currently\s+|now\s+)?(?:searching\s+for|looking\s+for|seeking|recruiting)|seeks)\b")
_V348_NOT_NAME = {"we", "the", "our", "this", "that", "your", "you", "they", "it", "he", "she", "a", "an", "who", "each", "every", "company", "client",
                  "team", "employer", "candidate", "partner", "role", "position", "hiring", "recruiter", "organization", "department", "group", "everyone"}


def v348_employer_statements(t: str) -> list[str]:
    """"<Org> is searching for / is looking for / is seeking / seeks / is recruiting": <Org> is a capitalized proper
    name at a sentence start (an optional "(ABC)" acronym or ", <appositive>," may follow), never "We", "The team",
    "Our client" and the like."""
    out = []
    for m in _V348_SEEKS.finditer(str(t)):
        o = m.group(1).strip()
        if not o or o.split()[0].lower() in _V348_NOT_NAME:
            continue
        out.append(o)
    return out


# --- H. vague-posting hook fallback ------------------------------------------------------------------------------
_V348_ROLE_HEAD = re.compile(r"(?i)^[\s#*_]*(?:the role|about the role|about this role|role overview|role summary|position summary|job summary|the position|about the position)[\s*_:]*$")
_V348_HIRING_TO = re.compile(r"\bis\s+(?:currently\s+|now\s+)?hiring\s+(?:an?|one|two|several|multiple)?\b.*?\bto\s+\w+")
_V348_ABOUT_JOB = re.compile(r"(?i)\b(?:this role|the role|this position|the position|you will|you'll|we are looking|we're looking|is seeking|is looking for|is searching for|join (?:our|the))\b")


def v348_normalize_title(title: str) -> str:
    """Trailing hyphens and punctuation leave title tokens ("Developer-" -> "Developer")."""
    return re.sub(r"(?<=\w)[-–—_.,:;!?]+(?=\s|$)", "", str(title or ""))


def v348_role_summary(raw_jd: str) -> str:
    """The posting's role summary: a "<Org> is hiring a ... to ..." sentence, else the paragraph under "The Role" /
    "About the role", else the first descriptive paragraph about the job."""
    lines = [l.strip() for l in str(raw_jd).splitlines()]
    for l in lines:
        for s in re.split(r"(?<=[.!?])\s+", l):
            if _V348_HIRING_TO.search(s):
                return s
    for i, l in enumerate(lines):
        if _V348_ROLE_HEAD.match(l):
            for nxt in lines[i + 1:i + 6]:
                if len(nxt.split()) >= 8:
                    return nxt
    for l in lines:
        if len(l.split()) >= 12 and _V348_ABOUT_JOB.search(l):
            return l
    return ""


def _v348_hook_fallback(d: dict[str, Any], hook: str, plan: dict[str, Any], raw_jd: str, words) -> dict[str, Any]:
    """The 7a detail recomputed with a normalized title and, when the posting has no responsibility line, the role
    summary as role text. Used only when the verdict differs from the 7a test (so a fixture whose verdict does not
    flip reports exactly what it did before)."""
    title = v348_normalize_title(str(plan.get("application", {}).get("role", "")))
    hw, tw = set(d.get("hook_words") or []), words(title)
    if d.get("first_responsibility_line"):
        rw, src, summ = set(d.get("first_responsibility_words") or []), "first_responsibility_line", ""
    else:
        summ = v348_role_summary(raw_jd)
        rw, src = words(summ), "role_summary"
    nd = dict(d, ok=bool(hw & (tw | rw)), title_words=sorted(tw), role_text_source=src)
    if src == "role_summary":
        nd.update(role_summary=summ[:200], role_summary_words=sorted(rw))
    nd["shared_words"] = sorted(hw & (tw | rw))
    return nd



# ===========================================================================
# v3.4.8b layer (2026-10-19). ONE FACT CHANGE, confirmed by Jay and the university: Jay graduates in December 2026
# (was February 2027); he can start work in February 2027 (unchanged). Graduation and start date are two separate facts
# everywhere. One flag in master.json "v347_flags": graduation_dec2026_v348 (default true); false restores v3.4.8a
# byte for byte (3_validation/diff_gate_v348b.py). New helper names only; every change to an existing function is made
# in its FINAL definition (grad_window_warning, _grad_window_ok, _v342_grad_window, eligibility_blockers,
# gating_assessment, blockers_summary, parse_jd_requirements, compose_bank_cover_letter, validate_cover_letter_v32,
# _v346_post_run, assemble_latex, _prepare_runtime_cache, main_v3_1).
#  D1 facts   : master.json education.masters / candidate_eligibility / qualification_facts say December 2026 and
#               February 2027 as two facts; the computed OPT date is gone. Flag off puts the v3.4.8a values back in the
#               loaded master (V348B_OLD_MASTER), so the flag-off build reads exactly what v3.4.8a read.
#  D2 resume  : Education "August 2025 -- Expected December 2026" (Resume_Template_CURRENT.tex).
#  D3 letters : "I graduate in December 2026 and can start work in February 2027." / internships "My Master's in
#               Computer Science at the University at Buffalo is expected in December 2026, and I can start work in
#               February 2027." Swapped after the closing is chosen; a letter the longer sentence would push past 200
#               words is rebuilt with the new sentence in place, so the existing 200-word budget refits it.
#  D4 timing  : graduation windows (one-month tolerance, as the v3.4.2 single-date check), graduating-class notes,
#               enrollment-required internships and rising-senior reasons use December 2026; start-date checks use
#               February 2027. Internships that require enrollment during or after the internship, or that start after
#               December 2026, get the enrollment blocker (a note; never a skip). Timing notes read "Graduates December
#               2026; available to start February 2027 (subject to OPT/EAD approval)".
# ===========================================================================
V348B_FLAG = "graduation_dec2026_v348"
V348B_GRAD, V348B_START = "December 2026", "February 2027"
V348B_TIMING = "Graduates December 2026; available to start February 2027 (subject to OPT/EAD approval)."
V348B_OLD_TEMPLATE_SHA256 = "1309898bfed1baf5dbf59950b8bd479b1b37c29974818f96587fb249ceb2d4fb"   # the v3.4.8a template (Education line only differs)
V348B_EDU_OLD, V348B_EDU_NEW = "August 2025 -- Expected February 2027", "August 2025 -- Expected December 2026"
V348B_FT_OLD = "I graduate in February 2027 and can start work that month."
V348B_FT_NEW = "I graduate in December 2026 and can start work in February 2027."
V348B_INTERN_NEW = "My Master's in Computer Science at the University at Buffalo is expected in December 2026, and I can start work in February 2027."
V348B_LABELS = {"graduation_window": "graduation window excludes December 2026", "enrollment_required": "enrollment required past December 2026"}
V348B_REASONS = {
    "graduation_window": "The posting sets a graduation date that does not include Jay's December 2026 graduation.",
    "student_audience": "The program is aimed at students with school left after the program; Jay graduates in December 2026.",
    "enrollment_during_after": "The internship requires enrollment during or after it; Jay graduates in December 2026 and can start work in February 2027.",
    "enrollment_start_after": "The internship starts after Jay's December 2026 graduation; Jay can start work in February 2027.",
}
# the v3.4.8a master values, restored into the loaded master when the flag is off (test switch / rollback)
V348B_OLD_MASTER = {
    "education.masters": {"dates": "August 2025 -- Expected February 2027", "coursework_completion": "December 16, 2026",
                          "degree_conferral": "February 1, 2027", "earliest_post_completion_opt": "February 2, 2027, subject to approved OPT/EAD"},
    "qualification_facts": {"graduation in December 2026": "graduation in 2027", "graduating in December 2026": "graduating in 2027",
                            "December 2026 graduate": "2027 graduate"},
    "cover_letter_rules.p2": "Two selected projects with real metrics, one logistics sentence (graduation February 2027, start soon after, open to relocating when onsite), then one closing sentence naming the company.",
    "cover_letter_bank._rules[1]": "P1 = role/company + hook + experience sentence. P2 = rank #1 project + rank #2 project + logistics (graduation February 2027, relocation when onsite) + closing.",
}
_V348B_RESTORED: set[int] = set()
_V348B_JAY = 2026 * 12 + 12
_V348B_START_M = 2027 * 12 + 2
_V348B_MON = {m: i for i, m in enumerate("jan feb mar apr may jun jul aug sep oct nov dec".split(), 1)}
_V348B_SEASON = {"spring": 5, "summer": 8, "fall": 12, "autumn": 12, "winter": 12}
_V348B_TOK = re.compile(r"\b((?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|spring|summer|fall|autumn|winter)[a-z]*"
                        r"(?:\s*/\s*(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|spring|summer|fall|autumn|winter)[a-z]*)*)\.?,?\s+(20\d\d)\b", re.I)
_V348B_RANGE = re.compile(r"\s(?:-|–|—|to|through|thru|until)\s|\bbetween\b|\bfrom\b", re.I)
_V348B_INTERN_TITLE = re.compile(r"\bintern(?:ship)?s?\b|\bco-?op\b", re.I)
_V348B_INTERN_HEAD = re.compile(r"\binternship program\b|\bsummer internship\b|\|\s*internship\s*\||\binternships?:", re.I)
_V348B_ENROLL_A = re.compile(r"\b(?:actively|currently|must be|remain|continuing|returning)\b[^.]{0,60}\b(?:enrolled|enrollment|pursuing|student|to school)\b", re.I)
_V348B_ENROLL_B = re.compile(r"full duration|duration of the (?:internship|program|co-?op)|throughout the (?:internship|program)|after the (?:internship|program)|"
                             r"return(?:ing)? to (?:school|university|their studies)|at least one (?:semester|quarter|term) (?:remaining|left)|graduat\w+ (?:after|no earlier)|"
                             r"during (?:the|your) (?:internship|program|co-?op)|while (?:interning|on the internship)|at the time of (?:the )?(?:internship|program)", re.I)


def v348b_on() -> bool:
    return _v347_on(V348B_FLAG)


def v348b_months(s: str) -> list[int]:
    """Month indexes (year * 12 + month) of every "<Month|Season> <year>" in s; "May/June 2027" gives both; a season
    is its usual graduation month (spring May, summer August, fall / winter December)."""
    out = []
    for m in _V348B_TOK.finditer(str(s)):
        for part in re.split(r"\s*/\s*", m.group(1)):
            k = part.lower()
            v = _V348B_SEASON.get(k) if k.startswith(tuple(_V348B_SEASON)) else _V348B_MON.get(k[:3])
            if v:
                out.append(int(m.group(2)) * 12 + v)
    return out


def v348b_window_ok(s: str, jay: int = _V348B_JAY) -> bool | None:
    """Does Jay's graduation month fall inside the graduation window this text states? One month of tolerance (the
    v3.4.2 single-date rule): a range "December 2026 - June 2027" includes him, "May 2027 - May 2027" does not, a bare
    "2027" includes him (December 2026 is one month before it). None when the text states no year. A "<year> Start"
    names a start date, not a graduation."""
    s = re.sub(r"\b20\d\d\s+start\b", " ", str(s), flags=re.I)
    t = v348b_months(s)
    bare = [int(y) for y in re.findall(r"\b(20[2-3]\d)\b", _V348B_TOK.sub(" ", s))]
    oks = []
    if len(t) >= 2:
        oks.append(min(t) - 1 <= jay <= max(t) + 1 if _V348B_RANGE.search(s) else any(abs(jay - d) <= 1 for d in t))
    elif len(t) == 1:
        d = t[0]
        if re.search(r"\b(by|before|no later than|prior to|on or before)\b", s, re.I):
            oks.append(jay <= d + 1)
        elif re.search(r"\b(after|or later|no earlier than|later than|on or after|or after)\b", s, re.I):
            oks.append(jay >= d - 1)
        else:
            oks.append(abs(jay - d) <= 1)
    for y in bare:
        oks.append(y * 12 <= jay <= y * 12 + 13)
    return any(oks) if oks else None


def v348b_grad_window(raw_jd: str) -> str:
    """The first sentence that sets a graduation date or window Jay's December 2026 graduation is outside of."""
    for s in re.split(r"(?<=[.!?])\s+|\n", str(raw_jd)):
        if not re.search(r"graduat|class of|conferr|degree (?:completion|date)", s, re.I):
            continue
        if not v348b_months(re.sub(r"\b20\d\d\s+start\b", " ", s, flags=re.I)):
            continue
        if v348b_window_ok(s) is False:
            return s.strip()[:160]
    return ""


def v348b_internship(role: str, raw: str) -> bool:
    return bool(_V348B_INTERN_TITLE.search(role) or _V348B_INTERN_TITLE.search(str(raw).split("\n", 1)[0]) or _V348B_INTERN_HEAD.search(str(raw)[:800]))


def v348b_intern_years(role: str, raw: str) -> list[int]:
    """Years the internship itself runs in: a year in the title, or a month / season / "<year> intern" on an
    internship or start line (graduation, pay and deadline lines never count)."""
    ys = [int(y) for y in re.findall(r"\b(20[2-3]\d)\b", role)]
    for l in str(raw)[:1500].splitlines():
        if re.search(r"graduat|salary|usd|\$|posted|apply|deadline|end date", l, re.I):
            continue
        if re.search(r"\bintern|\bco-?op\b|\bstart", l, re.I):
            ys += [d // 12 if d % 12 else d // 12 - 1 for d in v348b_months(l)]
            ys += [int(y) for y in re.findall(r"\b(20[2-3]\d)\s+(?:summer\s+)?intern", l, re.I)]
    return ys


def v348b_enrollment(role: str, raw: str) -> tuple[str, str] | None:
    """("during_after" | "start_after", posting line) for an internship that requires enrollment during or after the
    internship (unless it clearly ends by December 2026), or that starts after December 2026; None otherwise."""
    if not v348b_internship(role, raw) and not re.search(r"\bintern(?:ship)?s?\b|\bco-?op\b", role + " " + str(raw)[:600], re.I):
        return None
    ys = v348b_intern_years(role, raw)
    done = bool(ys) and all(y <= 2026 for y in ys)
    req = next((s.strip() for s in str(raw).split("\n") if s.strip() and _V348B_ENROLL_A.search(s) and _V348B_ENROLL_B.search(s)), "")
    if req and not done:
        return ("during_after", req[:200])
    if v348b_internship(role, raw) and any(y >= 2027 for y in ys):
        line = role if re.search(r"\b20[2-3]\d\b", role) else next((l for l in str(raw).splitlines() if re.search(r"\b20(?:2[7-9])\b", l)), role)
        return ("start_after", line.strip()[:200])
    return None


def v348b_date_blockers(out: list[dict[str, str]], plan: dict[str, Any]) -> list[dict[str, str]]:
    """D4 on the final blocker list: date reasons say December 2026 / February 2027; an enrollment blocker on an
    internship that ends by December 2026 is dropped; a missing one is added (during / after / starts after)."""
    raw = str(plan.get("_raw_jd_text", ""))
    role = str(plan.get("application", {}).get("role", ""))
    en = v348b_enrollment(role, raw)
    res = []
    for b in out:
        t = b.get("type")
        if t in ("graduation_window", "student_audience"):
            b = dict(b, reason=V348B_REASONS[t])
        elif t == "enrollment_required":
            if not en:
                continue
            b = dict(b, reason=V348B_REASONS["enrollment_" + en[0]])
        elif t == "graduation_year":
            m = re.search(r"targets (\d{4}) graduates", str(b.get("reason", "")))
            y = int(m.group(1)) if m else 0
            if y >= 2027:
                continue
            b = dict(b, reason=(f"Timing check: the posting targets {y} graduates. {V348B_TIMING} Confirm the hiring cycle before applying." if y < 2026 else
                                f"Timing check: the posting targets {y} graduates, and a {y} hiring cycle may start before February 2027. {V348B_TIMING} Confirm the start date before applying."))
        elif t == "start_date":
            b = dict(b, reason=f"Timing check: the posting mentions a start before February 2027. {V348B_TIMING}")
        res.append(b)
    if en and not any(b.get("type") == "enrollment_required" for b in res):
        res.append({"type": "enrollment_required", "requirement": en[1], "reason": V348B_REASONS["enrollment_" + en[0]]})
    return res


_V348B_TEXT = ((re.compile(r"do not include February 2027"), "do not include December 2026"),
               (re.compile(r"Jay's Master's \(conferred February 2027\)"), "Jay's Master's (expected December 2026)"))


def v348b_text(s: Any) -> Any:
    """Graduation wording inside older layers' warning text (start-date text never changes)."""
    if not isinstance(s, str):
        return s
    for rx, new in _V348B_TEXT:
        s = rx.sub(new, s)
    return s


def v348b_gating(g: dict[str, Any]) -> dict[str, Any]:
    if v348b_on():
        g["warnings"] = [dict(w, reason=v348b_text(w.get("reason"))) if "reason" in w else w for w in g.get("warnings", [])]
    return g


def v348b_letter(paras: list[str]) -> list[str]:
    """D3: the two logistics sentences (graduation December 2026, start February 2027)."""
    return [p.replace(V348B_FT_OLD, V348B_FT_NEW).replace(_V346_INTERN_LOGISTICS_START, V348B_INTERN_NEW) for p in paras]


def _v348b_compose(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> list[dict[str, Any]]:
    """The letter is written as before, then its logistics sentence is swapped (nothing else changes). If the new
    sentence would take the letter past 200 words, the letter is rebuilt with the new sentence in place, so the
    existing 200-word budget (closing / trim) refits it."""
    import copy as _copy
    snap, changes = _copy.deepcopy(plan), list(_V344_CTX.get("changes") or [])
    plan["_v348b_mode"] = "late"
    try:
        failures = compose_bank_cover_letter(plan, master, raw_jd)
    finally:
        plan.pop("_v348b_mode", None)
    paras = list(plan.get("cover_letter_paragraphs") or [])
    if not paras or plan.get("_cover_letter_mode") != "bank":
        return failures
    new = v348b_letter(paras)
    if _v344_words(new) <= _V344_LETTER_MAX:
        plan["cover_letter_paragraphs"] = new
        return failures
    plan.clear()
    plan.update(snap)
    _V344_CTX["changes"] = changes
    plan["_v348b_mode"] = "early"
    try:
        failures = compose_bank_cover_letter(plan, master, raw_jd)
    finally:
        plan.pop("_v348b_mode", None)
    plan["cover_letter_paragraphs"] = v348b_letter(list(plan.get("cover_letter_paragraphs") or []))
    plan["_v348b_letter_refit"] = True
    return failures


def v348b_restore_master(master: dict[str, Any]) -> None:
    """Flag off: the loaded master gets the v3.4.8a values back (education, qualification facts, letter rules)."""
    edu = master.setdefault("education", {}).setdefault("masters", {})
    for k in ("graduation", "available_to_start_work", "graduation_confirmed"):
        edu.pop(k, None)
    edu.update(V348B_OLD_MASTER["education.masters"])
    ce = master.get("candidate_eligibility") or {}
    for k in ("graduation", "available_to_start_work"):
        ce.pop(k, None)
    qmap = V348B_OLD_MASTER["qualification_facts"]
    master["qualification_facts"] = [qmap.get(q, q) for q in master.get("qualification_facts", [])]
    master.setdefault("cover_letter_rules", {})["p2"] = V348B_OLD_MASTER["cover_letter_rules.p2"]
    rules = master.setdefault("cover_letter_bank", {}).get("_rules")
    if isinstance(rules, list) and len(rules) > 1:
        rules[1] = V348B_OLD_MASTER["cover_letter_bank._rules[1]"]


_V348B_GRAD_FEB = re.compile(r"(?i)\b(?:graduat\w*|expected|conferr\w*|degree)\b[^.]{0,40}\bFebruary 2027\b|\bFebruary 2027\b[^.]{0,20}\bgraduat")


def v348b_text_problems(text: str) -> list[str]:
    """February 2027 may appear only as the start date, never as a graduation date."""
    p = []
    for s in re.split(r"(?<=[.!?])\s+|\n", str(text)):
        if "February 2027" in s and _V348B_GRAD_FEB.search(s) and not re.search(r"start (?:work )?in February 2027|available to start February 2027", s):
            p.append(s.strip()[:160])
    return p


def _v348b_post_run(rep: dict[str, Any], out_dir: Path, argv: list[str]) -> None:
    """D2 / D3 checks on the handed-over files (build fails): the resume shows "August 2025 -- December 2026" (v3.4.9c;
    "Expected December 2026" with data_v349c off); no resume, letter or report line states a February 2027 graduation."""
    if not v348b_on() or rep.get("skip"):
        return
    fails = []
    edu_want = V349C_EDU_NEW if v349c_on() else V348B_EDU_NEW
    for p in out_dir.glob("*.tex"):
        if p.name in ("build_resume.tex", "Resume_Template_CURRENT.tex"):
            continue
        t = p.read_text(encoding="utf-8")
        if edu_want not in t or (v349c_on() and "Expected" in t):
            fails.append(fail("v348b_education_date", p.name, "Education date line", edu_want, "Pipeline defect: report it."))
    for p in out_dir.glob("*_Cover_Letter.txt"):
        bad = v348b_text_problems(p.read_text(encoding="utf-8"))
        if bad:
            fails.append(fail("v348b_letter_graduation_date", p.name, bad, "graduation December 2026; February 2027 only as the start date", "Pipeline defect: report it."))
    bad = v348b_text_problems(json.dumps({k: rep.get(k) for k in ("notes", "warnings", "eligibility_blockers")}, ensure_ascii=False).replace("\\n", "\n"))
    if bad:
        fails.append(fail("v348b_report_graduation_date", "report.json", bad, "graduation December 2026; February 2027 only as the start date", "Pipeline defect: report it."))
    if fails:
        rep.setdefault("failures", []).extend(fails)
        rep["status"] = "FAIL"


# ===========================================================================
# v3.4.8c layer (2026-10-19). Visible-quality build, one fix at a time; each fix behind its own master.json
# "v347_flags" entry (default true). With every v3.4.8c flag false the outputs are byte-identical to v3.4.8b
# (3_validation/diff_gate_v348c.py). New helper names only; every change to an existing function is made in its FINAL
# definition. bullet_bank.json gains new variant ids for W and F1 only (old ids stay and are used only with the flag off).
#  T  start_date_parse_v348 : the start-date check also reads "2026 Start", "Start date: 12/01/2026", "Target start
#                             date: ...", "commit to an onboarding date by end of year 2026", "start in (early/late)
#                             2026". A start before February 2027 adds the Timing note (never a skip, never a Fit change).
# ===========================================================================
V348C_START_FORMS = (
    ("year_start", re.compile(r"\b(20\d\d)\s+start\b", re.I)),
    ("start_date_mdy", re.compile(r"\bstart date\s*[:\-]?\s*(\d{1,2})/(\d{1,2})/(20\d\d)\b", re.I)),
    ("onboarding_date", re.compile(r"\bonboarding date\b[^.\n]{0,60}?\b(20\d\d)\b", re.I)),
    ("start_in_year", re.compile(r"\bstart(?:s|ing)?\s+in\s+(?:(?:early|late|mid)[- ]?)?(20\d\d)\b", re.I)),
)


def v348c_start_before(text: str) -> tuple[str, str] | None:
    """(form, posting line) of the first start statement that falls before February 2027. A bare year counts as its
    latest month (December), so only a year of 2026 or earlier is before February 2027 ("start in 2027" is not)."""
    for line in re.split(r"(?<=[.!?])\s+|\n", str(text)):
        for name, rx in V348C_START_FORMS:
            for m in rx.finditer(line):
                ym = (int(m.group(3)), int(m.group(1))) if name == "start_date_mdy" else (int(m.group(1)), 12)
                if ym < (2027, 2):
                    return name, line.strip()[:200]
    return None


def v348c_start_date_note(out: list[dict[str, str]], plan: dict[str, Any]) -> list[dict[str, str]]:
    """T: add the Timing start-date note when the older check missed a start before February 2027."""
    if any(b.get("type") == "start_date" for b in out):
        return out
    role = str(plan.get("application", {}).get("role", ""))
    hit = v348c_start_before(role + "\n" + str(plan.get("_raw_jd_text", "")))
    if not hit:
        return out
    reason = (f"Timing check: the posting mentions a start before February 2027. {V348B_TIMING}" if v348b_on() else
              "Timing check: the posting mentions a start before the candidate's February 2027 graduation; OPT work can begin only after graduation and EAD approval.")
    return out + [{"type": "start_date", "requirement": hit[1], "reason": reason}]


# --- W / F1 ---------------------------------------------------------------------------------------------------
#  W  bank_wording_v348      : four bank variants get reworded copies under new ids (bullet_bank.json "v348c"
#                             .replaces); with the flag on the new id takes the old id's place in the selector (same
#                             position, same preferences and forced lists), with it off the new ids are never chosen.
#  F1 fleet_language_model_v348 : goingonce.determ.b states goingonce.determ.a's fact without naming Claude (so it adds
#                             no Skills term). It is never an ordinary candidate: only the C1 Fleet replacement uses
#                             it, after the Claude-named bullet has failed on that page, and only as the last resort
#                             (when no other bullet qualifies, or the best other one is not reproduced by the selector).
# ---------------------------------------------------------------------------
V348C_SWAP_ONLY = "swap_only_v348c"
V348C_F1_IDS = ("goingonce.determ.b",)
V348C_W_STATUS_OFF, V348C_W_STATUS_RETIRED = "excluded_v348c", "retired_v348c"


def v348c_bank_meta(v: dict[str, Any]) -> dict[str, Any]:
    return v.get("v348c") if isinstance(v.get("v348c"), dict) else {}


def v348c_w_map(bank: dict[str, Any]) -> dict[str, str]:
    """old id -> new id for the W rewordings in this bank (v3.4.9b: and the switched-on bank_format_v349b ones)."""
    return {v348c_bank_meta(v)["replaces"]: v["id"] for vs in bank.get("projects", {}).values() for v in vs
            if v348c_bank_meta(v).get("replaces") and (v348c_bank_meta(v).get("flag") != "bank_format_v349b" or v349b_letter_bank())}


def v349b_rewording_on(v: dict[str, Any]) -> bool:
    """Is this new wording switched on? bank_wording_v348 (v3.4.8c W) or bank_format_v349b (v3.4.9b, Letter only)."""
    m = v348c_bank_meta(v)
    return v349b_letter_bank() if m.get("flag") == "bank_format_v349b" else _v347_on("bank_wording_v348")


def v348c_selection_bank(raw_plan: dict[str, Any], bank: dict[str, Any]) -> dict[str, Any]:
    """The selector's view of the bank. W on: each new wording sits at its old id's position and the old id is retired;
    the plan's preferred / forced ids follow (old id -> new id). W off: the new wordings are excluded. F1 variants are
    swap-only. A bank without v3.4.8c variants is returned unchanged."""
    if not any(v348c_bank_meta(v) for vs in bank.get("projects", {}).values() for v in vs) or bank.get("_v348c_view"):
        return bank
    w_on = _v347_on("bank_wording_v348")
    wmap = {o: n for o, n in v348c_w_map(bank).items() if v349b_rewording_on(next(v for vs in bank["projects"].values() for v in vs if v["id"] == n))}   # v3.4.9b: per flag
    fb = deepcopy(bank)
    fb["_v348c_view"] = True
    for pid, vs in fb.get("projects", {}).items():
        new = {v348c_bank_meta(v)["replaces"]: v for v in vs if v348c_bank_meta(v).get("replaces") and v349b_rewording_on(v)}
        out = []
        for v in vs:
            m = v348c_bank_meta(v)
            if m.get("replaces"):
                if not v349b_rewording_on(v):
                    v["status"] = V348C_W_STATUS_OFF
                    out.append(v)
                continue
            if m.get("fallback_for"):
                v["status"] = V348C_SWAP_ONLY
            if v.get("id") in new:
                v["status"] = V348C_W_STATUS_RETIRED
                out.append(new[v["id"]])
            out.append(v)
        fb["projects"][pid] = out
    if wmap:
        tr = lambda ids: list(dict.fromkeys(wmap.get(i, i) for i in ids))
        if raw_plan.get("prefer_variants"):
            raw_plan["prefer_variants"] = tr(raw_plan["prefer_variants"])
        if isinstance(raw_plan.get("_v34_force"), dict):
            raw_plan["_v34_force"] = {k: tr(v) for k, v in raw_plan["_v34_force"].items()}
    return fb


def v348c_f1_candidates(bank: dict[str, Any], pid: str) -> list[dict[str, Any]]:
    """F1: the swap-only plain-code bullet without "Claude", once the Claude-named one has been tried and failed."""
    if not _v347_on("fleet_language_model_v348"):
        return []
    tried = set(_V347C_CTX.get("exclude") or [])
    return [dict(v, status="ok") for v in bank.get("projects", {}).get(pid, []) if v.get("status") == V348C_SWAP_ONLY
            and v348c_bank_meta(v).get("fallback_for") in tried]


# --- post-run ---------------------------------------------------------------------------------------------------
#  F2 fleet_repick_v348     : on a non-logistics page where the in-place Fleet swap fails, Fleet leaves the GoingOnce
#                             candidates BEFORE selection and the normal selector picks the GoingOnce set (other
#                             GoingOnce bullets may change; with F1 on, the plain-code bullet is the one without
#                             "Claude"). Valid only when every other project's bullets, the slot count and line count
#                             are unchanged; Skills, headings and the letter are written from the page before the
#                             re-pick (only the letter's Fleet sentence changes). FAIL-CLOSED: any build failure retries,
#                             then the 8b page stays and report.json fleet_v348c says why.
def v348c_f2_active(plan: dict[str, Any]) -> bool:
    return any(w.get("kind") == "F2" for w in _v347c_active(plan))


def v348c_fleet_repick(raw_plan, bank, pairs, cur, rerun):
    """F2: the selector's GoingOnce set with Fleet (and every bullet a failed attempt used) removed beforehand; the
    swap entries pair each removed bullet with an added one of the same line count, Fleet first."""
    core = getattr(rerun, "core", None)
    log = {"before": list(cur.get("goingonce") or [])}
    _V347C_CTX.setdefault("f2", []).append(log)
    if core is None:
        log["kept"] = "no selector to re-run"
        return None
    excl = {_V347B_FLEET_ID} | set(_V347C_CTX.get("exclude") or [])
    f1 = _v347_on("fleet_language_model_v348")
    res = None
    for pin in (False, True):   # the plain re-pick first; then with every other project held to its current bullets
        b2 = deepcopy(bank)
        for pid_, vs_ in b2.get("projects", {}).items():
            if pin and pid_ != "goingonce" and pid_ in cur:
                for v in vs_:
                    if v.get("id") not in cur[pid_]:
                        v["status"] = "excluded_v348c_f2"
        fb_ids = {v348c_bank_meta(w).get("fallback_for") for w in b2.get("projects", {}).get("goingonce", [])} - {None}
        for v in b2.get("projects", {}).get("goingonce", []):
            m = v348c_bank_meta(v)
            if v.get("id") in excl or (f1 and v.get("id") in fb_ids):
                v["status"] = "excluded_v348c_f2"
            elif f1 and m.get("fallback_for") and v.get("status") == V348C_SWAP_ONLY:
                v["status"] = "ok"
        saved = [(d, deepcopy(dict(d))) for d in (raw_plan, _V344_CTX, _V345_CTX)]   # the re-pick leaves no selector logs behind
        if _v347_on("ranker_v349"):   # v3.4.9a fix 5: nor its slot plan (a 3/3/3 page was checked as 3/3/2)
            saved.append((_V343_LAYOUT, deepcopy(dict(_V343_LAYOUT))))
        try:
            r_ = core(raw_plan, b2, pairs)
        except Exception as e:   # never let the re-pick break a build: keep the page
            log["kept"] = f"selector error: {e}"[:200]
            continue
        finally:
            for d, snap in saved:
                d.clear()
                d.update(snap)
        if r_ is None or r_[0] is None:
            log["kept"] = "the selector finds no valid GoingOnce set without the Fleet bullet"
            continue
        new = {k: list(v) for k, v in r_[0].items()}
        if set(new) != set(cur) or any(new[k] != cur[k] for k in cur if k != "goingonce"):
            log["kept"] = "the re-pick changes another project's bullets"
            continue
        if _V347B_FLEET_ID in (new.get("goingonce") or []) or not new.get("goingonce"):
            log["kept"] = "the re-pick keeps the Fleet bullet"
            continue
        res = r_
        log["pinned"] = pin
        log.pop("kept", None)
        break
    if res is None:
        return None
    vmap = {v.get("id"): v for p_ in b2.get("projects", {}).values() for v in p_}
    old_g, new_g = list(cur.get("goingonce") or []), list(new.get("goingonce") or [])
    log["after"] = new_g
    ln = lambda ids: sorted(int(vmap.get(i, {}).get("lines", 2)) for i in ids)
    removed, added = [i for i in old_g if i not in new_g], [i for i in new_g if i not in old_g]
    if ln(old_g) != ln(new_g) or len(removed) != len(added) or ln(removed) != ln(added):
        log["kept"] = "the re-pick changes the GoingOnce slot or line count"
        return None
    sents = ((((globals().get("_V33_MASTER") or {}).get("cover_letter_bank") or {}).get("letter_sentences") or {}).get("goingonce") or {})
    fl = int(vmap[_V347B_FLEET_ID].get("lines", 2))
    first = sorted([a for a in added if int(vmap[a].get("lines", 2)) == fl], key=lambda a: (not (sents.get(a) or sents.get(vmap[a].get("main_evidence_id"))), added.index(a)))[0]
    rest_r, rest_a = [r for r in removed if r != _V347B_FLEET_ID], [a for a in added if a != first]
    rest_r.sort(key=lambda r: (int(vmap[r].get("lines", 2)), old_g.index(r)))
    rest_a.sort(key=lambda a: (int(vmap[a].get("lines", 2)), new_g.index(a)))
    pairs_ = [(_V347B_FLEET_ID, first)] + list(zip(rest_r, rest_a))
    for b_, a_ in pairs_:
        _V347C_CTX.setdefault("swaps", []).append({"project": "goingonce", "before": b_, "after": a_, "score_after": None, "kind": "F2",
                                                   "letter": b_ == _V347B_FLEET_ID, "_vb": deepcopy(vmap[b_]), "_va": deepcopy(vmap[a_])})
    log["pairs"] = [list(x) for x in pairs_]
    return res


#  S  skills_lines_v348      : "Languages & Databases" lists languages first, then databases, each group in its current
#                             (posting-relevance) order; only the order changes (S1). A line with fewer than 3 items
#                             gains the master-supported languages / databases that the page itself shows in its
#                             project or Experience bullets (posting mentions first, then page mentions), up to 3 (S2).
#                             Every ladder state of the TeX selector gets the same rule; no other Skills line changes.
V348C_LANGS = ("Python", "Java", "JavaScript", "HTML/CSS", "C", "Go", "SQL")   # SQL is a language here ("Python, SQL + PostgreSQL")
V348C_DBS = ("PostgreSQL", "MongoDB", "MySQL", "NoSQL", "Relational Databases")
_V348C_S: dict[str, Any] = {"inner": False, "log": {}}


def v348c_shown(term: str, text: str) -> int:
    t = term.replace("HTML/CSS", "HTML")
    return len(re.findall(r"(?<![\w+#/.-])" + re.escape(t) + r"(?![\w+#-])", text))


def v348c_page_body(plan: dict[str, Any], master: dict[str, Any]) -> str:
    omitted = {normalize_fixed_text(b) for b in plan.get("_v343_omitted_exp_bullets", []) or []}
    exp = [b for r in master.get("experience", []) for b in r.get("bullets", []) if normalize_fixed_text(b) not in omitted]
    return _v343_page_bullets(plan) + "\n" + "\n".join(exp)


def v348c_skills_lines(states: list[dict[str, Any]], plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    if _V348C_S.get("inner") or not _v347_on("skills_lines_v348") or not states:
        return states
    pool = list(((master.get("skills") or {}).get("supported_pool") or {}).get("languages_databases") or [])
    body = v348c_page_body(plan, master)
    raw = str(plan.get("_raw_jd_text", ""))
    cands = [x for x in V348C_LANGS + V348C_DBS if x in pool and v348c_shown(x, body)]
    cands.sort(key=lambda x: (-v348c_shown(x, raw), -v348c_shown(x, body), (V348C_LANGS + V348C_DBS).index(x)))
    log = {"states": []}
    for st in states:
        vals = (st.get("skills") or {}).get("languages_databases")
        if vals is None:
            continue
        before = list(vals)
        if len(vals) < 3:
            have = {x.casefold() for v in st["skills"].values() for x in v}
            for x in cands:
                if len(vals) >= 3:
                    break
                if x.casefold() not in have:
                    vals.append(x); have.add(x.casefold())
        vals[:] = [x for x in vals if x not in V348C_DBS] + [x for x in vals if x in V348C_DBS]
        log["states"].append({"before": before, "after": list(vals)})
    _V348C_S["log"] = log
    return states


def v348c_skills_post(rep: dict[str, Any], tex: str) -> None:
    m = re.search(r"\\textbf\{Languages \\& Databases:\}\s*(.*?)\s*$", tex, re.M)
    if not m:
        return
    shown = [x.strip() for x in m.group(1).replace("\\&", "&").split(",") if x.strip()]
    st = next((x for x in _V348C_S.get("log", {}).get("states", []) if x["after"] == shown), None)
    if st is None or st["after"] == st["before"]:
        return
    body = "\n".join(l for l in tex.splitlines() if l.strip().startswith("\\item") and "\\textbf{" not in l[:16])
    added = [x for x in st["after"] if x not in st["before"]]
    rep["skills_lines_v348c"] = {"before": st["before"], "after": st["after"], "s2_added": added,
                                 "s2_not_on_page": [x for x in added if not v348c_shown(x, body)]}


#  J  heading_move_v348      : when the A2 rule takes a posting-named technology off a heading and no rendered heading
#                             names it any more, it joins the heading of the selected project whose bullets show it
#                             (most bullets, then page order), only when that heading has fewer than 4 technologies.
#                             Nothing is displaced (core stack included) and Skills never change (they come from the
#                             full heading set, as in A2). report.json ats_coverage lists "header" in also_in only when
#                             a rendered heading (its title or technologies) shows the term.
_V348C_J: dict[str, Any] = {"log": {}, "rendered": None, "ats_fixed": []}


def v348c_heading_move(out, log, bullets, order, master, overrides):
    moved: dict[str, Any] = {}
    for pid, items in log.items():
        for it in items:
            x = it["left"]
            if any(x in out.get(p, []) for p in order):
                continue
            cands = [(v347_bullets_show(bullets.get(p, []), x), -k, p) for k, p in enumerate(order)
                     if p != pid and p not in overrides and v347_bullets_show(bullets.get(p, []), x)]
            if not cands:
                continue
            n, _k, best = max(cands)
            if len(out.get(best, [])) >= 4:
                moved.setdefault("kept_off", []).append({"tech": x, "from": pid, "to": best, "reason": "that heading already has 4 technologies"})
                continue
            out[best] = list(out.get(best, [])) + [x]
            moved.setdefault("moved", []).append({"tech": x, "from": pid, "to": best, "bullets_showing": n})
    _V348C_J["log"] = moved
    return out


def v348c_header_also_in(entry: dict[str, Any], needles: list[str], master: dict[str, Any]) -> None:
    rend = _V348C_J.get("rendered")
    if rend is None or "header" not in (entry.get("also_in") or []):
        return
    heads = [x for pid, vals in rend.items() for x in [project_title_text(master, pid)] + [str(v) for v in vals]]
    if matches_in_surfaces({"header": heads}, [n for n in needles if n], plural=True):
        return
    entry["also_in"] = [x for x in entry["also_in"] if x != "header"]
    if not entry["also_in"]:
        del entry["also_in"]
    _V348C_J.setdefault("ats_fixed", []).append(entry.get("term"))


#  C1 closing_proof_map_v348 : the closing proof follows what the responsibility names. Model training / optimization /
#                             accuracy / latency -> Fraud's measured results (GraphSAGE 0.9259 against about 0.858
#                             AUC-ROC, the edge-type ablation, the leakage controls) when Fraud is on the page; an "AI"
#                             responsibility whose v3.4.8b proof was a Git-diff or Fraud fact -> RIPPLE's evaluation
#                             (then RIPPLE's claim checks, the LLM engine's claim validation or failover). Integrations,
#                             permissions, interactive, testing and operations already map to LedgerFlow exactly-once,
#                             LaunchOps server checks, the live quiz / GoingOnce interface, CI and test suites and the
#                             Thesis heartbeat (v3.4.4 kinds, unchanged). The proof is a project on the page and never a
#                             fact the letter already gives (then another fact of the same project).
#  C2 closing_specific_v348  : a generic responsibility moves to a posting responsibility that names the product, users
#                             or domain. Specificity (v348c_spec) = +1 per word naming the product, team or users (a users
#                             word such as customers / merchants, or a content word whose 6-letter stem the posting's
#                             description uses: its title, headers and paragraphs), -1 per generic word (V348C_GENERIC);
#                             quality adjectives (V348C_QUALITY) and verbs count 0. Switch only when the v3.4.8b
#                             responsibility scores <= 0 and a candidate scores at least 2 higher with at least 2 domain
#                             words, comes from a responsibility line (a list item or a "you will" sentence, never the
#                             company's mission or a boast such as "the most powerful ... on the market"), does not name
#                             the company (the closing adds it), and has a proof of its own kind (strict v3.4.4 match)
#                             that the line names itself, not through a generic word or a quality adjective ("permissioning"
#                             -> LaunchOps server checks); otherwise the 8b closing stays.
#                             Both rules change only the closing sentence: a role-family closing, or one that does not
#                             fit the word budget, stays; every closing validator runs on the new sentence.
V348C_GENERIC = {"software", "components", "component", "building", "blocks", "applications", "application", "solutions", "features", "products",
                 "systems", "system", "tools", "code", "services", "platforms", "technology", "technologies"}
V348C_STOP = set("""a an the and or of to for with in on by into from that this each its their as at plus while using which who so it them both also
my i where whose every all any one your our under over than then when only across new existing high quality help build improve design develop
create implement write test deploy integrate monitor enhance maintain optimize optimise ship deliver automate debug troubleshoot scale architect
engineer prototype extend modernize migrate refactor launch work working make makes using use used directly real world real-world""".split())
V348C_ML = re.compile(r"\bmodels?\b|\bml\b|\bmachine learning\b|\bneural\b", re.I)
V348C_ML_RES = re.compile(r"\btrain\w*|\boptimi[sz]\w*|\baccura\w*|\blatenc\w*|\bfine[- ]tun\w*", re.I)
V348C_ML_PROOFS = ("fraud.graphsage_result", "fraud.edge_ablation_result", "fraud.edge_ablation", "fraud.leakage")
V348C_AI_PROOFS = ("ripple.evaluation", "ripple.analysis_tools", "tailor.claim_validation", "tailor.provider_failover")
V348C_AI_OLD = ("ripple.git_verification", "fraud.graphsage", "fraud.elliptic")
V348C_FACT = {"fraud.graphsage_result": "fraud.graphsage", "fraud.edge_ablation_result": "fraud.edge_ablation"}   # the letter fact a proof restates
V348C_PRE = {"ledgerflow": "ledger.", "launchops": "launchops.", "ripple": "ripple.", "pintos": "pintos.", "tailor_pipeline": "tailor.", "fraud": "fraud.", "goingonce": "goingonce."}
V348C_C2_MARGIN, V348C_C2_DOMAIN = 2, 2
V348C_BOAST = re.compile(r"\bmost \w+|\bbest\b|\bon the market\b|\bworld'?s\b|\bleading\b|\bnext[- ]generation\b|\bgenerational\b|\bfrontier\b", re.I)
V348C_QUALITY = set("""scalable scalability reliable reliability innovative intuitive high-performance performance efficient efficiency effectiveness
robust maintainable quality high-quality clean quickly safely modern next generation production-level production business requirements value
experiences experience capabilities real standards end-to-end complex tasks secure world-class best leading cutting-edge large various multiple
stack full-stack technical generic internal skilled motivated ideal great strong skills company generational inflection point opportunity
mission role team teams rapidly""".split())
V348C_USERS = set("""customers customer users user merchants clients patients students employees businesses firms enterprises creators viewers
advertisers drivers riders members partners shoppers sellers buyers doctors clinicians teachers learners consumers players""".split())
_V348C_C: dict[str, Any] = {"inner": False}


def v348c_role_text(raw: str) -> str:
    return re.split(r"(?im)^\s*(?:benefits|what we offer|perks|equal opportunity|about us)\b", str(raw))[0]


def v348c_domain_stems(raw: str) -> set[str]:
    """The posting's own description of its product, team and users: the non-bullet lines of the role text (title,
    headers, paragraphs), as 6-letter stems."""
    lines = [l.strip() for l in v348c_role_text(raw).splitlines() if l.strip() and not re.match(r"^[-*•·]|^\d+[.)]", l.strip())]
    return {w[:6] for l in lines for w in re.findall(r"[a-z][a-z'-]+", l.lower())}


def v348c_spec(resp: str, raw: str) -> tuple[int, int]:
    """(specificity, domain words): +1 for each word naming the product, team or users (a users word, or a content word
    whose stem the posting's description uses), -1 for each generic word; quality adjectives and verbs count 0."""
    dom_st = v348c_domain_stems(raw)
    sc = dom = 0
    for w in re.findall(r"[a-z][a-z'-]+", str(resp).lower()):
        if w in V348C_GENERIC:
            sc -= 1
        elif w in V348C_USERS or (w not in V348C_STOP and w not in V348C_QUALITY and len(w) >= 4 and w[:6] in dom_st):
            sc += 1; dom += 1
    return sc, dom


def v348c_resp_ok(c: str, plan: dict[str, Any], master: dict[str, Any], low: str, raw: str) -> bool:
    """_v344_resp_ok, where an "-ing" word the posting also uses as a plural noun ("permissioning" / "permissions")
    is a noun, not a second verb."""
    if _v344_resp_ok(c, plan, master, low):
        return True
    words = set(re.findall(r"[a-z]+", str(raw).lower()))
    alt = re.sub(r"\b(and|or) ([a-z]+)ing\b", lambda m: f"{m.group(1)} {m.group(2)}s" if m.group(2) + "s" in words else m.group(0), c)
    return alt != c and _v344_resp_ok(alt, plan, master, low)


def v348c_repeats(eid: str, plan: dict[str, Any], master: dict[str, Any], body: str) -> bool:
    """The v3.4.4 repeat test of _v344_pick_proof; a proof that restates a letter fact (V348C_FACT) repeats it too."""
    bank = master.get("cover_letter_bank", {})
    proofs, letter_sent = bank.get("closing_proofs", {}), bank.get("letter_sentences", {})
    page_nums = set(re.findall(r"\d[\d,.]*\d|\d", " ".join(str(b.get("text", "")) for bs in (plan.get("bullets") or {}).values() for b in bs if isinstance(b, dict))
                               + " " + " ".join(str(x) for r in master.get("experience", []) for x in r.get("bullets", []))))
    if any(n not in page_nums for n in re.findall(r"\d[\d,.]*\d|\d", proofs[eid])):
        return True
    if closing_repeats_letter(proofs[eid], body):
        return True
    keys = {eid, V348C_FACT.get(eid, eid)}
    return any(isinstance(x, str) and len(x) > 20 and x in body for v in letter_sent.values() if isinstance(v, dict) for k, x in v.items() if k in keys)


def v348c_c1_proofs(c: str, kind0: str, eid0: str, plan: dict[str, Any], master: dict[str, Any], body: str, fresh: bool = False) -> list[tuple[str, str, str]] | None:
    """C1: the proofs the map names for this responsibility (None: the map leaves the v3.4.8b proof). fresh: a C2
    responsibility, where every AI responsibility takes the map's AI proofs (RIPPLE's evaluation first)."""
    if not _v347_on("closing_proof_map_v348"):
        return None
    on = set((plan.get("bullets") or {}).keys())
    if V348C_ML.search(c) and V348C_ML_RES.search(c) and "fraud" in on and not str(eid0).startswith("fraud."):
        kind, ids = "ml_results", V348C_ML_PROOFS
    elif kind0 == "ai" and (eid0 in V348C_AI_OLD or fresh):
        kind, ids = "ai", V348C_AI_PROOFS
    else:
        return None
    proofs = master.get("cover_letter_bank", {}).get("closing_proofs", {})
    page = v349_page_evidence(plan, master) if _v347_on("proof_on_page_v349") else None   # v3.4.9a fix 7: by evidence id
    return [(kind, i, proofs[i]) for i in ids if i in proofs and any(i.startswith(V348C_PRE[pid]) for pid in on if pid in V348C_PRE)
            and not v348c_repeats(i, plan, master, body) and (page is None or v349_proof_eid(i) in page)]


def v348c_closing(plan, master, raw_jd, company_ref, body, budget, exclude_resp):
    _V348C_C["inner"] = True
    try:
        s0, i0 = _v344_closing(plan, master, raw_jd, company_ref, body, budget, exclude_resp)
        lim = min(budget, 30)
        if i0.get("family") or not i0.get("responsibility") or len(s0.split()) > lim:
            return s0, i0
        where = _v344_where(company_ref)
        ref = company_ref if where.startswith("at ") else ""
        low = body.lower()

        def sentence(cut, line, kind, eid, proof, rule):
            conn = _v344_connector(cut, company_ref, proof)
            s_ = f"I want to {cut} {where}, {conn} {proof}."
            if len(s_.split()) <= lim and not closing_problems(s_, ref):
                return s_, {"rule": "v3.4.4", "responsibility": cut, "jd_line": line, "proof": eid, "proof_kind": kind, "_proof": proof, "connector": conn}
            return None

        def for_resp(c, line, kind0, eid0, strict, cuts=None):
            """The closing for one responsibility: its cuts, longest first; C1's proofs where the map applies."""
            for cut in (cuts or _v344_cuts(c)):
                if cuts is None and (not _v344_resp_ok(cut, plan, master, low) or not _v345_clause_end_ok(cut, line)):
                    continue
                k0, e0 = kind0, eid0
                if k0 is None:   # C2: the proof kind comes from what the line names, not from a generic word or a quality adjective
                    plain = " ".join(w for w in cut.split() if w.lower().strip(",.") not in V348C_QUALITY | V348C_GENERIC | {"service", "reliably"})
                    k0, e0, _p = _v344_pick_proof(plain, plan, master, body, strict=strict)
                    if k0 not in [k[0] for k in _v344_kind_order(plain)]:
                        continue   # a posting-wide lead proof (permissions) the line itself does not name
                c1 = v348c_c1_proofs(cut, k0, e0, plan, master, body, fresh=kind0 is None)
                if c1 is None:
                    if kind0 is not None or not e0:
                        continue
                    picks = [(k0, e0, _p)]
                else:
                    picks = c1
                for kind, eid, proof in picks:
                    out = sentence(cut, line, kind, eid, proof, "")
                    if out:
                        return out, c1 is not None
            return None

        r0, line0 = str(i0["responsibility"]), str(i0.get("jd_line") or i0["responsibility"])
        sp0 = v348c_spec(r0, raw_jd)
        log = {"before": s0, "before_proof": i0.get("proof"), "specificity_before": sp0[0]}
        if _v347_on("closing_specific_v348") and sp0[0] <= 0:   # C2
            company = str(plan.get("application", {}).get("company", "") or "").strip()
            src_ = []
            for line in _v342_role_text(raw_jd):
                for sent in re.split(r"(?<=[.;!?])\s+", re.sub(r"^[-*•·\s]+", "", line.strip())):
                    ph = _v344_actor_phrase(sent)
                    if ph:
                        src_.append((ph[0].lower() + ph[1:] if ph[:2] != ph[:2].upper() else ph, line.strip()))
            src_ += closing_candidates(raw_jd, plan, master, body)
            cands, seen = [], set()
            for n, (r, line) in enumerate(src_):
                if (exclude_resp and r in exclude_resp) or _V344_SCALE_CLAIM.search(r):
                    continue
                if not re.match(r"^\s*(?:[-*•·]|\d+[.)])", line) and not re.search(r"\byou(?:'ll|’ll| will)\b", line, re.I):
                    continue   # a responsibility line (a list item or a "you will" sentence), never the company's mission
                if V348C_BOAST.search(r):
                    continue   # "the most powerful ... platform on the market": the company's claim, not Jay's work
                for cut in _v344_cuts(r):
                    if cut.lower() in seen or (company and not company_is_placeholder(company) and company.lower() in cut.lower()):
                        continue
                    sp = v348c_spec(cut, raw_jd)
                    if sp[0] >= sp0[0] + V348C_C2_MARGIN and sp[1] >= V348C_C2_DOMAIN and v348c_resp_ok(cut, plan, master, low, raw_jd) and _v345_clause_end_ok(cut, line):
                        seen.add(cut.lower())
                        cands.append((-sp[0], n, cut, line, sp))
            if os.environ.get("V348C_DEBUG"):   # test-only: V348C_DEBUG=<path> dumps the C2 candidates (never set it inside Sources)
                Path(os.environ["V348C_DEBUG"]).write_text(json.dumps({"before": [r0, sp0], "cands": [[c[2], c[4]] for c in sorted(cands)]}, indent=1))
            for _neg, _n, cut, line, sp in sorted(cands, key=lambda x: (x[0], x[1])):
                got = for_resp(cut, line, None, None, True, cuts=[cut])
                if got:
                    (s_, inf), c1 = got
                    inf["v348c"] = dict(log, rule="C2" + ("+C1" if c1 else ""), specificity_after=sp[0], domain_words=sp[1])
                    return s_, inf
        got = for_resp(r0, line0, i0.get("proof_kind"), i0.get("proof"), True)   # C1 on the v3.4.8b responsibility
        if got and got[1]:
            s_, inf = got[0]
            if s_ != s0:
                inf["v348c"] = dict(log, rule="C1")
                return s_, inf
        return s0, i0
    finally:
        _V348C_C["inner"] = False


def _v348c_post_run(rep: dict[str, Any], out_dir: Path, argv: list[str]) -> None:
    """v3.4.8c report logs (and, for later fixes, checks that fail the build)."""
    if rep.get("skip"):
        return
    try:
        rp_ = json.loads((out_dir / "resolved_plan.json").read_text(encoding="utf-8"))
        bank = json.loads(Path(argv[argv.index("--bank") + 1] if "--bank" in argv else Path(__file__).with_name("bullet_bank.json")).read_text(encoding="utf-8"))
    except Exception:
        return
    sel = rp_.get("bank_selection") or {}
    on_page = {i for ids in sel.values() for i in ids}
    cl_ = (rep.get("cover_letter") or {}).get("closing")
    if isinstance(cl_, dict) and cl_.get("v348c"):
        rep["closing_v348c"] = dict(cl_["v348c"], after=cl_.get("text"), after_proof=cl_.get("proof"))
    if _v347_on("heading_move_v348"):
        lg = dict(_V348C_J.get("log") or {})
        if _V348C_J.get("ats_fixed"):
            lg["ats_header_claims_removed"] = list(dict.fromkeys(_V348C_J["ats_fixed"]))
        if lg:
            rep["heading_move_v348c"] = lg
    if _v347_on("skills_lines_v348"):
        try:
            texs = [x for x in out_dir.glob("*.tex") if x.name != "build_resume.tex"] or list(out_dir.glob("build_resume.tex"))
            if texs:
                v348c_skills_post(rep, texs[0].read_text(encoding="utf-8"))
        except OSError:
            pass
    if _v347_on("bank_wording_v348"):
        b9 = {v["id"] for vs in bank.get("projects", {}).values() for v in vs if v348c_bank_meta(v).get("flag") == "bank_format_v349b"}
        wmap = {o: n for o, n in v348c_w_map(bank).items() if n not in b9}   # v3.4.9b rewordings are logged in format_v349b
        took = [n for o, n in wmap.items() if n in on_page]
        if took:
            rep["bank_wording_v348c"] = {"selected": took, "replaces": {n: o for o, n in wmap.items() if n in took}}
    if _v347_on("strict_fleet") and (_v347_on("fleet_repick_v348") or _v347_on("fleet_language_model_v348")):
        logi = str(((rep.get("bullet_relevance_v347b") or {}).get("logistics_line")) or "")
        if not logi:
            try:
                rawp = json.loads(Path(argv[argv.index("--plan") + 1]).read_text(encoding="utf-8"))
                logi = v347b_logistics_line(rawp, clean_jd_text(Path(argv[argv.index("--jd") + 1]).read_text(encoding="utf-8")))
            except Exception:
                logi = ""
        f2 = [x for x in (_V347C_CTX.get("f2") or []) if x.get("pairs") or x.get("kept")]
        fl = _V347B_FLEET_ID in (sel.get("goingonce") or [])
        log = {}
        if fl:
            if logi:
                log = {"fleet_on_page": True, "logistics_line": logi[:160]}
            else:
                why = next((x["kept"] for x in reversed(f2) if x.get("kept")), "")
                tried = [t.get("after") for t in _V347C_CTX.get("tried") or []]
                log = {"fleet_on_page": True, "kept_reason": (why or "every replacement failed the page checks") + (f" (tried: {tried})" if tried else "")}
        elif any(w.get("kind") == "F2" for w in _V347C_CTX.get("swaps") or [] if w["after"] in (sel.get("goingonce") or [])):
            done = next(x for x in reversed(f2) if x.get("pairs"))
            log = {"repick": {"before": done["before"], "after": done["after"], "pairs": done["pairs"]}}
        if log:
            rep["fleet_v348c"] = log


# ===========================================================================
# v3.4.9a layer (2026-10-19). Core-fixes build, one fix at a time; each fix behind its own master.json "v347_flags"
# entry (default true). With every v3.4.9a flag false the outputs are byte-identical to v3.4.8c
# (3_validation/diff_gate_v349a.py). New helper names only; every change to an existing function is made in its FINAL
# definition. Jay graduates in December 2026 and starts work in February 2027 (both unchanged).
#  1 jd_sections_v349 : the JD reader. "What sets you apart" / "Nice to have" / "Bonus" / "Ways to stand out" /
#                       "Preferred" headings are preferred; "About You" alone is not a requirements heading when a
#                       sub-heading follows it (the sub-heading decides); "Some examples:", "for example", "for
#                       instance", "examples include", "projects like" lists are context, never requirements or hard
#                       gaps; "A and/or B" reads as "A or B" (alternatives); a parenthetical in the company's voice
#                       ("(we use PostgreSQL and SQL Server)") is context. A model jd_requirements_extra item whose
#                       text appears only in such context is rejected.
# ===========================================================================
V349_PREF_HEAD = re.compile(r"(?:what\s+)?sets\s+you\s+apart|what\s+makes\s+you\s+stand\s+out", re.I)
V349_ABOUT_YOU = re.compile(r"about\s+you", re.I)
V349_LIST_CUE = re.compile(r"\b(?:some examples|for example|for instance|examples include|examples of (?:this|these|our) (?:work|projects)|projects like|things like)\b", re.I)
V349_INLINE_CUE = re.compile(r",?\s*\b(?:for example|for instance|examples include|projects like)\b", re.I)
V349_VOICE_PAREN = re.compile(r"\s*\((?=[^()]*\b(?:[Ww]e|[Oo]ur|us)\b)[^()]*\)")
V349_BULLET = re.compile(r"^\s*(?:[-*+•·▪●–]|\\-|\d+[.)])\s+")


def _v349_head_text(line: str) -> str:
    return re.sub(r"[#*_`\\]+", "", str(line)).strip().strip(":").strip("  ").strip()


def _v349_is_head(line: str) -> bool:
    """A short heading line ("## **What sets you apart**", "About You:", "ABOUT YOU"); never a bullet or a sentence."""
    if V349_BULLET.match(line):
        return False
    t = _v349_head_text(line)
    t = re.sub(r"[^\w)'’]+$", "", t).strip()
    if not t or len(t.split()) > 8 or t.endswith((".", ",", ";")):
        return False
    raw = str(line).strip()
    words = [w for w in t.split() if len(w) > 3 and w[0].isalpha()]
    return raw.startswith(("#", "**")) or raw.rstrip("*_ \\").endswith(":") or t.isupper() or (bool(words) and all(w[0].isupper() for w in words))


def v349_headings_view(raw_jd: str) -> str:
    """Fix 1, headings only: a "What sets you apart" heading reads as "Preferred Qualifications:" and an "About You"
    heading that a sub-heading follows is dropped (the sub-heading decides). Every other line is unchanged."""
    lines = str(raw_jd).split("\n")
    out = []
    for i, ln in enumerate(lines):
        if _v349_is_head(ln):
            t = re.sub(r"[^\w\s'’]+", " ", _v349_head_text(ln)).strip()
            if V349_PREF_HEAD.fullmatch(" ".join(t.split())):
                out.append("Preferred Qualifications:")
                continue
            if V349_ABOUT_YOU.fullmatch(" ".join(t.split())):
                nxt = next((x for x in lines[i + 1:] if x.strip() and x.strip() not in ("\\", "&#x20;")), "")
                if _v349_is_head(nxt):
                    out.append("")
                    continue
        out.append(ln)
    return "\n".join(out)


def v349_context_lines(raw_jd: str) -> set[int]:
    """Indexes of the list lines that follow an example lead-in ("Some examples:", "for example:", "projects like:"),
    up to the next heading or the next non-list paragraph."""
    lines = str(raw_jd).split("\n")
    ctx: set[int] = set()
    i = 0
    while i < len(lines):
        ln = lines[i]
        if V349_LIST_CUE.search(ln) and re.search(r":\s*\**\s*\\?\s*$", ln):
            j, seen = i + 1, False
            while j < len(lines):
                t = lines[j]
                if not t.strip() or t.strip() in ("\\",):
                    j += 1
                    continue
                if V349_BULLET.match(t):
                    ctx.add(j); seen = True; j += 1
                    continue
                break
            i = j if seen else i + 1
            continue
        i += 1
    return ctx


def v349_jd_view(raw_jd: str) -> str:
    """Fix 1: the posting as the requirement reader sees it. Headings per v349_headings_view; example-list lines and
    the tail of an inline example ("..., for example how a customer ...") removed; "and/or" read as "or"; a
    parenthetical in the company's voice removed. Only the requirement reader uses this view."""
    t = v349_headings_view(raw_jd)
    lines = t.split("\n")
    ctx = v349_context_lines(t)
    out = []
    for i, ln in enumerate(lines):
        if i in ctx:
            out.append("")
            continue
        m = V349_LIST_CUE.search(ln)
        if m:
            head = ln[:m.start()]
            if re.search(r":\s*\**\s*\\?\s*$", ln):
                ln = head.rstrip(" ,;-")   # the lead-in keeps its own sentence ("You'll contribute to projects across our stack.")
            else:
                op = head.rfind("(")
                if op > head.rfind(")") and ln.find(")", m.end()) > 0:
                    ln = ln[:op].rstrip() + ln[ln.find(")", m.end()) + 1:]   # "(for example, ...)"
                else:
                    end = re.search(r"[.;!?](?:\s|$)", ln[m.end():])
                    ln = ln[:m.start()].rstrip(" ,;-") + ("." + ln[m.end() + end.end():] if end else ".")
        ln = re.sub(r"(?i)\s*\band\s*/\s*or\b\s*", " or ", ln)
        ln = V349_VOICE_PAREN.sub("", ln)
        out.append(ln)
    return "\n".join(out)


def v349_raw_verbatim(v: str, raw_jd: str) -> str:
    """A verbatim read from v349_jd_view, as the posting spells it: "A or B" back to "A and/or B", or the longest
    head of the line that the posting has word for word (a removed parenthetical or example tail is never quoted)."""
    raw = str(raw_jd)
    if not v or v in raw:
        return v
    ors = [m.start() for m in re.finditer(r" or ", v)]
    for cand in [v.replace(" or ", " and/or ")] + [v[:k] + " and/or " + v[k + 4:] for k in ors]:
        if cand in raw:
            return cand
    words = v.split(" ")
    for n in range(len(words) - 1, 2, -1):
        head = " ".join(words[:n]).rstrip(" ,;:.(")
        for cand in (head, head.replace(" or ", " and/or ")):
            if len(cand) >= 12 and cand in raw:
                return cand
    return v


# 2 years_range_v349 : "0-3 years" / "1-3 years" mean a minimum of 0 / 1 year; a years warning (and its Fit cap) follows the
#                     minimum and fires only when the minimum is at least 3.
V349_YEARS_RANGE = re.compile(r"\b(\d{1,2})\s*(?:-|–|—|to)\s*\d{1,2}(\s*\+?\s*(?:\(\w+\)\s*)?years?\b)", re.I)
V349_YEARS_TYPES = ("experience_years", "note_experience_years")


V349_YEARS_HISTORY = re.compile(r"\b(?:for|over|in)\s+(?:more than|over|nearly|almost|the (?:past|last))\s+\d{1,2}\s*\+?\s*years?\b(?!\s+of\b)", re.I)


def v349_years_view(raw: str) -> str:
    """The posting as the years checks read it: every "A-B years" / "A to B years" range becomes "A years", and a company
    history phrase ("has been revolutionizing commerce for more than 25 years") is not a years ask."""
    return V349_YEARS_HISTORY.sub("for a long time", V349_YEARS_RANGE.sub(lambda m: m.group(1) + m.group(2), str(raw)))


def v349_years_filter(g: dict[str, Any]) -> dict[str, Any]:
    """Drop a years warning whose stated minimum is below 3 ("asks 2+ years", "Posting asks for 1+ years")."""
    keep = []
    for w in g.get("warnings", []) or []:
        m = re.search(r"\basks (?:for )?(\d{1,2})\+ years", str(w.get("reason", "")))
        if w.get("type") in V349_YEARS_TYPES and m and int(m.group(1)) < 3:
            continue
        keep.append(w)
    g["warnings"] = keep
    return g


# 3 fit_guard_v349 : preferred, example or context items never make Fit Low. Low comes only from a must-have gap (an
#                    unsupported or partial hard gap of priority "must", from a required section, or whose posting text
#                    says "required" / "must have") or from a blocker (an eligibility blocker other than a Timing note).
V349_CTX: dict[str, Any] = {"fit_raised": False}
V349_TIMING_NOTES = ("start_date", "graduation_year")


def v349_must_gap(gaps: list[dict[str, Any]]) -> bool:
    for g in gaps or []:
        if g.get("status") not in ("unsupported", "partial"):
            continue
        if str(g.get("priority", "")).lower() == "must" or g.get("required_section") or re.search(r"\brequired\b|\bmust\s+have\b", str(g.get("verbatim", "")), re.I):
            return True
    return False


def v349_fit_guard(value: str, gaps: list[dict[str, Any]]) -> str:
    V349_CTX["fit_raised"] = False
    if str(value) == "Low" and not v349_must_gap(gaps):
        V349_CTX["fit_raised"] = True
        return "Medium"
    return value


def v349_fit_blocker(g: dict[str, Any], blockers: list[dict[str, str]]) -> dict[str, Any]:
    """A blocker keeps the Low that fix 3 would otherwise lift."""
    if _v347_on("fit_guard_v349") and V349_CTX.get("fit_raised") and any(b.get("type") not in V349_TIMING_NOTES for b in blockers or []):
        g["fit_cap"] = "Low"
    return g


def v349_context_only(text: str, raw_jd: str) -> bool:
    """True when `text` is in the posting but not in its requirement view (it sits only in example / context text)."""
    sq = lambda s: re.sub(r"\s+", " ", re.sub(r"[*_#`]+", "", str(s))).strip().casefold()
    v, r = sq(text), sq(raw_jd)
    return bool(v) and v in r and v not in sq(v349_jd_view(raw_jd))


# 4 bullet_score_v349 : no flat number bonus (v3.2 +1 "metric", v3.3.2 +1 "metric_v332"); a number only breaks ties between
#                       equally relevant bullets (+0.01). The LLM engine's resume-wording bullets ("write resume bullets",
#                       "resume-generation") never appear unless the posting is about documents or resumes; its failover
#                       and claim-check bullets are preferred (+1).
V349_RESUME_WORDING = re.compile(r"\bwrite (?:\w+ )?resume bullets\b|\bresume-generation\b", re.I)
V349_DOCS_POSTING = re.compile(r"\bresumes?\b|\brésumés?\b|\bCVs?\b|\bcover letters?\b|\bdocument (?:generation|processing|automation|understanding|intelligence|AI)\b", re.I)
V349_LLM_PREFERRED = {"tailor.provider_failover": 1.0, "tailor.claim_validation": 1.0}
def v349_variant_adjust(v: dict[str, Any]) -> tuple[float, list[tuple[str, float, str]]]:
    """Fix 4's change to a bullet's score (applied at the end of the final _variant_score)."""
    adj, why = 0.0, []
    if re.search(r"\d", str(v.get("text", ""))):
        adj -= 2.0 - 0.01; why.append(("number_tiebreak_v349", -1.99, ""))
    b = V349_LLM_PREFERRED.get(str(v.get("main_evidence_id")), 0.0) if str(v.get("id", "")).startswith("tailor_pipeline.") else 0.0
    if b:
        adj += b; why.append(("llm_preferred_v349", b, ""))
    return adj, why


def v349_llm_pool(pool: list[dict[str, Any]], need_headline: bool) -> tuple[list[dict[str, Any]], bool]:
    """Drop the LLM engine's resume-wording bullets unless the posting is about documents or resumes. Its only headline
    bullets are resume-wording ones, so the rank-1 headline requirement is lifted with them."""
    if not _v347_on("bullet_score_v349") or not pool or not str(pool[0].get("id", "")).startswith("tailor_pipeline."):
        return pool, need_headline
    plan = globals().get("_V342_PLAN") or {}
    if V349_DOCS_POSTING.search(str(plan.get("_raw_jd_text", ""))):
        return pool, need_headline
    keep = [v for v in pool if not V349_RESUME_WORDING.search(str(v.get("text", "")))]
    return keep, need_headline and any(v.get("headline") is True for v in keep)




# 5 ranker_v349 : one scoring path. The theme-first standalone score orders the projects and the legacy v3.2 score
#                 (requirement coverage plus the family's preferences) breaks ties instead of being discarded; a tie is
#                 never broken by list order. The family's anchor (preferred_projects[0]) leads when it is on the page
#                 unless another project beats it clearly (by V349_CLEAR points on standalone + legacy / 2). Overrides
#                 still choose which projects are on the page; a lead language the posting singles out still leads.
V349_CLEAR, V349_LEGACY_W = 2.0, 0.5


def v349_fleet_last_resort(raw_plan, bank, pairs, sel, info, core):
    """C1's swaps and F2's re-pick keep the other projects' bullets, so a page whose GoingOnce block became rank 1 (three
    slots) can keep the Fleet bullet when no same-shape swap exists (lumen). The Fleet bullet still leaves every
    non-logistics page: the selector runs once more without it, and the page checks then judge that page as usual."""
    if not _v347_on("ranker_v349") or not _v347_on("strict_fleet") or _V347C_CTX.get("off") or sel is None:
        return sel, info
    if _V347B_FLEET_ID not in (sel.get("goingonce") or []) or v347b_logistics_line(raw_plan, str(raw_plan.get("_raw_jd_text", ""))):
        return sel, info
    b2 = deepcopy(bank)
    for v in b2.get("projects", {}).get("goingonce", []):
        if v.get("id") == _V347B_FLEET_ID:
            v["status"] = "excluded_v349"
    keep = v349_rerun_state(raw_plan)
    saved = [(d, deepcopy(dict(d))) for d in (_V344_CTX, _V345_CTX, _V347C_CTX)]
    try:
        res = core(raw_plan, b2, pairs)
    except Exception:
        res = (None, {})
    if res is None or res[0] is None or _V347B_FLEET_ID in (res[0].get("goingonce") or []):
        v349_restore_state(raw_plan, keep)
        for d, snap in saved:
            d.clear(); d.update(snap)
        V349_CTX["fleet"] = {"kept": "the selector finds no page without the Fleet bullet"}
        return sel, info
    _V347C_CTX["swaps"], _V347C_CTX["kept"] = [], []   # the letter and Skills follow the new selection, not a swap
    V349_CTX["fleet"] = {"before": list(sel.get("goingonce") or []), "after": list(res[0].get("goingonce") or [])}
    return res


def v349_rerun_state(raw_plan: dict[str, Any]):
    """The B4 / C1 swap rerun runs the whole selector, which records its slot plan in the plan and the layout. A rerun
    whose result is not taken (fail-closed) must not leave its fallback slot plan behind: the kept selection is then
    checked against the wrong slot counts (lumen: a 3/3/3 page checked as 3/3/2)."""
    if not _v347_on("ranker_v349"):
        return None
    return {k: v for k, v in raw_plan.items() if k != "prefer_variants"}, dict(_V343_LAYOUT)


def v349_restore_state(raw_plan: dict[str, Any], keep) -> None:
    plan_keys, layout = keep
    for k in [k for k in raw_plan if k != "prefer_variants" and k not in plan_keys]:
        del raw_plan[k]
    raw_plan.update(plan_keys)
    _V343_LAYOUT.clear()
    _V343_LAYOUT.update(layout)


def v349_scores_by_score_ties(plan: dict[str, Any], master: dict[str, Any], raw_jd: str, inner) -> dict[str, float]:
    """Run the ranker with the active projects listed by legacy score (then id): the greedy pick's last tie-break is
    the active list's order, so this makes a tie fall to the legacy score instead of master.json's list order."""
    legacy = _auto_project_scores_v32(dict(plan), master, raw_jd)
    rules = dict(master.get("project_selection_rules") or {})
    active = [p for p in rules.get("active_project_ids", list(master["projects"])) if p in master["projects"]]
    rules["active_project_ids"] = sorted(active, key=lambda p: (-float(legacy.get(p, 0.0)), p))
    m2 = dict(master)
    m2["project_selection_rules"] = rules
    scores = inner(plan, m2, raw_jd)
    keys = list(master["projects"])
    return {k: scores[k] for k in keys if k in scores} | {k: v for k, v in scores.items() if k not in keys}


def v349_rank(raw_plan: dict[str, Any], master: dict[str, Any]) -> None:
    info = raw_plan.get("_v33_rank") or {}
    ranking = list(raw_plan.get("ranking") or [])
    st, lg = dict(info.get("standalone") or {}), dict(info.get("legacy_v32_scores") or {})
    if len(ranking) != 3 or not st:
        return
    S = lambda p: float(st.get(p, 0.0)) + V349_LEGACY_W * float(lg.get(p, 0.0))
    order = sorted(ranking, key=lambda p: (-float(st.get(p, 0.0)), -float(lg.get(p, 0.0)), p))
    prof = role_family_profile(raw_plan, master) or {}
    a = (prof.get("preferred_projects") or [None])[0]
    reason = "highest standalone score"
    if a in order and order[0] == a:
        reason = f"anchor {a} has the highest standalone score"
    elif a in order:
        if S(order[0]) >= S(a) + V349_CLEAR:
            reason = f"{order[0]} beats the anchor {a} clearly ({S(order[0]):.2f} vs {S(a):.2f})"
        else:
            reason = f"anchor {a} leads: {order[0]} does not beat it clearly ({S(order[0]):.2f} vs {S(a):.2f})"
            order = [a] + [p for p in order if p != a]
    ll = raw_plan.get("_v342_lead_language") or {}
    if ll.get("moved") and ll.get("project") in order and order[0] != ll["project"]:
        order = [ll["project"]] + [p for p in order if p != ll["project"]]
        reason = f"lead language {ll.get('language')}: {ll['project']} leads"
    scores = dict(raw_plan.get("project_scores") or {})
    if order != ranking and scores:
        top = max(float(v) for v in scores.values())
        for p in scores:
            if p not in order:
                scores[p] = min(float(scores[p]), round(top, 3))
        for i, p in enumerate(order):
            scores[p] = round(top + 3.0 - i, 3)
        raw_plan["project_scores"] = scores
        raw_plan["ranking"] = order
    V349_CTX["ranking"] = {"rank": order, "before_v349": ranking, "standalone": {p: st.get(p) for p in order},
                           "legacy": {p: lg.get(p) for p in order}, "combined": {p: round(S(p), 3) for p in order},
                           "anchor": a, "reason": reason}


def v349_post_run(rep: dict[str, Any], out_dir: Path, argv: list[str]) -> None:
    if rep.get("skip"):
        return
    if V349_CTX.get("ranking"):
        rep["ranking_v349"] = V349_CTX["ranking"]
    if _v347_on(V349C_MUST_FLAG) and V349C_CTX.get("must"):   # v3.4.9c run 6
        rep["must_framework_v349c"] = V349C_CTX["must"]
        mu = V349C_CTX["must"]
        if mu.get("applied") and mu.get("after") and isinstance(rep.get("ranking_v349"), dict):   # run 9: the final rank
            rk = rep["ranking_v349"]
            rep["ranking_v349"] = dict(rk, rank=list(mu["after"]), rank_before_must_v349c=list(rk.get("rank") or []),
                                       reason=str(rk.get("reason", "")) + f"; must_framework_v349c: {mu.get('project')} leads (required by the posting)")
    if V349_CTX.get("fleet"):
        rep["fleet_v349"] = V349_CTX["fleet"]
    if _v347_on("proof_on_page_v349") and V349_CTX.get("page_evidence") is not None:
        cl = (rep.get("cover_letter") or {}).get("closing")
        proof = str(cl.get("proof") or "") if isinstance(cl, dict) else ""
        page = v349_final_page_evidence(out_dir, argv)
        if page is None:
            return
        rep["closing_proof_v349"] = {"proof": proof, "evidence": v349_proof_eid(proof) if proof else None,
                                     "on_page": (v349_proof_eid(proof) in page) if proof else None, "page_evidence": page}
        if proof and v349_proof_eid(proof) not in page and rep.get("status") == "PASS":
            rep["status"] = "FAIL"
            rep.setdefault("failures", []).append(fail("closing_proof_not_on_page", "cover letter closing", proof, page, "Pipeline defect: report it."))



# 6 date_order_v349 : the page lists the three projects newest to oldest by master.json date, ties broken by rank; the
#                     ranking (and so each project's slot count) is unchanged.
def v349_date_order(ranking: list[str], master: dict[str, Any]) -> list[str]:
    """The v3.2 date order (parse_month_year on each project's master date), ties broken by rank."""
    r = list(ranking)
    return sorted(r, key=lambda p: (-parse_month_year(master["projects"][p]["date"])[0], -parse_month_year(master["projects"][p]["date"])[1], r.index(p)))


# 7 proof_on_page_v349 : the closing's proof is an evidence id whose bullet the page shows: a project proof is the
#                        main_evidence_id of a bank bullet on the page; an Experience proof needs its Experience line on
#                        the page (a kept bullet whose original and every approved variant carry the fact). No digit
#                        matching. With no proof on the page, the closing falls back to the role-family closing.
V349_EXP_PROOF = {"exp.thesis_heartbeat": r"\bheartbeat\b", "exp.thesis_review": r"\bpull requests?\b", "exp.datamaven_access": r"\bVPC\b",
                  "exp.datamaven": r"\bEC2\b", "exp.hein": r"\bCrossRef\b|\bHeinOnline\b", "exp.godigital": r"\bETL workflow\b",
                  "exp.thesis_iot": r"\bIoT\b", "exp.thesis_backend": r"\bIoT\b|\bWebSocket\b", "exp.thesis_client": r"\bclient meetings\b|\bhealthcare platform\b"}


V349_PROOF_EVIDENCE = {"fraud.graphsage_result": "fraud.graphsage", "fraud.edge_ablation_result": "fraud.edge_ablation",
                       "launchops.ownership": "launchops.workflow"}   # closing proofs named apart from the evidence they cite


def v349_proof_eid(proof: str) -> str:
    return V349_PROOF_EVIDENCE.get(proof, proof)


def v349_proof_siblings(proofs: dict[str, Any], pool: list[str]) -> dict[str, list[str]]:
    """Fix 7b: for each project proof, the on-page proofs (pool) of the same project, in closing_proofs order."""
    ids = [k for k in proofs if not k.startswith("_") and not k.startswith("exp.")]
    return {k: [r for r in ids if r != k and r.split(".")[0] == k.split(".")[0] and r in pool] for k in ids}


def v349_page_evidence(plan: dict[str, Any], master: dict[str, Any]) -> set[str]:
    out = {e for pid in (plan.get("ranking") or []) for _v, e in _v33_selected_evidence(plan, pid) if e}
    omitted = set(plan.get("_v343_omitted_exp_bullets") or [])
    variants = {str(b.get("original", "")): [str(v.get("text", "")) for v in b.get("variants", []) if v.get("approved", True)]
                for b in (master.get("experience_variants") or {}).get("bullets", [])}
    kept = [str(x) for r in master.get("experience", []) for x in r.get("bullets", []) if str(x) not in omitted]
    for eid, rx in V349_EXP_PROOF.items():
        if any(re.search(rx, t) and all(re.search(rx, v) for v in variants.get(t, [])) for t in kept):
            out.add(eid)
    V349_CTX["page_evidence"] = set(out)
    return out


def v349_final_page_evidence(out_dir: Path, argv: list[str]) -> list[str] | None:
    """The evidence ids the finished page shows (resolved_plan.json bank bullets; Experience lines in the .tex)."""
    try:
        rp_ = json.loads((out_dir / "resolved_plan.json").read_text(encoding="utf-8"))
        bank = json.loads(Path(argv[argv.index("--bank") + 1] if "--bank" in argv else Path(__file__).with_name("bullet_bank.json")).read_text(encoding="utf-8"))
        texs = [x for x in out_dir.glob("*.tex") if x.name != "build_resume.tex"] or list(out_dir.glob("build_resume.tex"))
        tex = texs[0].read_text(encoding="utf-8")
    except Exception:
        return None
    main_id = {v["id"]: v.get("main_evidence_id") for vs in bank.get("projects", {}).values() for v in vs}
    page = {main_id.get(i) for ids in (rp_.get("bank_selection") or {}).values() for i in ids} - {None}
    m = re.search(r"\\section\*\{EXPERIENCE\}(.*?)\\section\*\{", tex, re.S)
    exp = m.group(1) if m else ""
    page |= {e for e, rx in V349_EXP_PROOF.items() if re.search(rx, exp)}
    return sorted(page)




# 8 copy_rule_v349 : the hook and a model closing need 3+ content words from ONE responsibility line (not 4 consecutive
#                    words); a closing phrase stops before a trailing bare singular phrase ("services for control
#                    plane" -> "services"); a "Design  develop" verb pair gets its "and"; the hook never says "our",
#                    "we" or "us" in the posting's voice ("our backend systems" -> "DoorDash's backend systems").
V349_HOOK_GENERIC = {"want", "help", "team", "work", "role", "join", "company", "like", "would", "chance", "opportunity"}
V349_BARE_PREP = re.compile(r"\b(?:for|of|in|on|at|to|with|from|across|within|into|over)\s+((?:[\w-]+\s+){0,2}([\w-]+))$")
V349_DET = re.compile(r"(?i)^(?:the|a|an|all|each|every|our|your|their|its|this|these|those|any|many|multiple|various|several|some|both)\b")
V349_MASS = {"code", "software", "hardware", "equipment", "data", "analysis", "speed", "infrastructure", "production", "latency", "scalability",
             "reliability", "quality", "security", "performance", "research", "testing", "feedback", "work", "support", "design", "development",
             "documentation", "traffic", "scale", "time", "end", "call", "demand", "practice", "place", "mind", "learning", "information", "logic",
             "storage", "compute", "content", "safety", "commerce", "health", "finance", "accuracy", "efficiency", "observability", "automation"}
V349_PAIR_SECOND = {"develop", "implement", "deploy", "maintain", "deliver", "create", "build", "design", "architect"}


def v349_content_words(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z][a-z0-9+#-]*", str(text).lower()) if w not in _STOP and w not in V349_HOOK_GENERIC and len(w) > 1}


def v349_from_one_line(text: str, raw_jd: str) -> bool:
    """3 or more of the sentence's content words appear in one responsibility line of the posting."""
    own = v349_content_words(text)
    return any(len(own & v349_content_words(l)) >= 3 for l in _v342_role_text(raw_jd))


def v349_bare_singular_tail(c: str) -> bool:
    m = V349_BARE_PREP.search(str(c).strip())
    if not m or V349_DET.match(m.group(1)) or "," in m.group(1):
        return False
    if re.search(r"\b(?:that|which|who|whom|where)\b", str(c)[:m.start()], re.I):
        return False   # a relative clause ("the dashboard that thousands of small businesses use") ends in its verb
    w = m.group(2)
    return not (w.lower().endswith(("s", "ing")) or w[:1].isupper() or w.lower() in V349_MASS)


def v349_verb_pair(sent: str) -> str:
    m = re.match(r"^(\W*)([A-Za-z]+) ([A-Za-z]+)\b", sent)
    if m and _v344_base_verb(m.group(2)) and m.group(3).lower() in V349_PAIR_SECOND and m.group(2).lower() != m.group(3).lower():
        return sent[:m.end(2)] + " and" + sent[m.end(2):]
    return sent


def v349_hook_voice(plan: dict[str, Any]) -> list[dict[str, Any]]:
    cl = plan.get("cover_letter")
    if not isinstance(cl, dict) or not cl.get("hook"):
        return []
    company = str(plan.get("application", {}).get("company", "") or "").strip()
    poss = (company + ("'" if company.endswith("s") else "'s")) if company and not company_is_placeholder(company) else "the team's"
    hook = re.sub(r"\b[Oo]ur\b", poss, str(cl["hook"]))
    hook = v349_verb_pair_in_hook(hook)
    cl["hook"] = hook
    if re.search(r"\b(?:we|us|ours)\b", hook, re.I):
        return [fail("cover_letter_hook_voice", "cover_letter.hook", hook, "no \"we\" or \"us\" from the posting's voice",
                     "Say what the team does in your own voice (the company's name, not \"we\")." )]
    return []


def v349_verb_pair_in_hook(hook: str) -> str:
    m = re.match(r"(?i)^(i want to (?:help )?)(.*)$", hook)
    return m.group(1) + v349_verb_pair(m.group(2)) if m else hook


# 9 skills_dedupe_v349 : Technical Skills hygiene on every ladder state: one name per alias group (React + ReactJS ->
#                        ReactJS); formats (JSON, HTML/CSS, ...) sit on the Languages line, never Tools; a vendor API the
#                        rendered project headings already show is not repeated in Tools unless the posting names it.
#                        A posting-named term is never dropped (a merge keeps its group, a move keeps it on the page).
V349_ALIAS = (("ReactJS", ("React", "ReactJS", "React.js")), ("Node.js", ("Node.js", "NodeJS", "Node")), ("PostgreSQL", ("PostgreSQL", "Postgres")))
V349_FORMATS = ("JSON", "HTML/CSS", "HTML", "CSS", "XML", "YAML", "Markdown")
_V349_SK: dict[str, Any] = {"log": []}


def v349_rendered_heading_tech(plan: dict[str, Any], master: dict[str, Any]) -> set[str]:
    try:
        ranking = list(plan.get("ranking") or [])
        display = build_display_order(ranking, master)
        heads = resolved_project_header_tech(master, display, plan)
        if _v347_on("heading_tech_fix") and plan.get("bullets"):
            saved = (deepcopy(plan.get("_v347_heading")), "_v347_heading" in plan, deepcopy(_V347_CTX.get("heading")), "heading" in _V347_CTX,
                     deepcopy(dict(_V348C_J)))
            try:   # a read-only look at the rendered headings: the placement's logs stay as the page build writes them
                heads = _v347_heading_placement({k: list(v) for k, v in heads.items()}, master, display, plan)
            finally:
                (plan.__setitem__("_v347_heading", saved[0]) if saved[1] else plan.pop("_v347_heading", None))
                (_V347_CTX.__setitem__("heading", saved[2]) if saved[3] else _V347_CTX.pop("heading", None))
                _V348C_J.clear(); _V348C_J.update(saved[4])
        return {t for pid in display for t in heads.get(pid, [])}
    except Exception:
        return set()


def v349_skills_hygiene(states: list[dict[str, Any]], plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    if not _v347_on("skills_dedupe_v349") or not states:
        return states
    raw = str(plan.get("_raw_jd_text", ""))
    named = lambda t: bool(re.search(r"(?<![\w-])" + re.escape(t) + r"(?![\w-])", raw, re.I))
    heads = None
    log = []
    for st in states:
        sk = st.get("skills") or {}
        before = {k: list(v) for k, v in sk.items()}
        for canon, names in V349_ALIAS:   # K1
            hits = [(cat, x) for cat, vals in sk.items() for x in vals if x in names]
            if len({x for _c, x in hits}) < 2:
                continue
            cat0, x0 = hits[0]
            said = [n for n in names if re.search(r"(?<![\w-])" + re.escape(n) + r"(?![\w-]|\.js)", raw)]
            keep_as = said[0] if len(said) == 1 else canon   # the posting's own spelling stays (an ATS verbatim term)
            for cat, vals in sk.items():
                vals[:] = [keep_as if (cat == cat0 and x == x0) else x for x in vals if x not in names or (cat == cat0 and x == x0)]
        tools = sk.get("tools")
        langs = sk.get("languages_databases")
        if tools is not None and langs is not None:   # K2
            moved = [x for x in tools if x in V349_FORMATS]
            if moved:
                tools[:] = [x for x in tools if x not in V349_FORMATS]
                lang_part = [x for x in langs if x not in V348C_DBS]
                db_part = [x for x in langs if x in V348C_DBS]
                lang_part += [x for x in moved if x not in langs]
                langs[:] = lang_part + db_part
        if tools:   # K3
            if heads is None:
                heads = v349_rendered_heading_tech(plan, master)
            gone = [x for x in tools if re.search(r"\bAPI$", x) and x in heads and not named(x.split()[0])]
            if gone:
                tools[:] = [x for x in tools if x not in gone]
                plan["_v349_api_removed"] = sorted(set(plan.get("_v349_api_removed") or []) | set(gone))
        if before != sk:
            log.append({"before": before, "after": {k: list(v) for k, v in sk.items()}})
    _V349_SK["log"] = log
    return states


# 10 company_key_v349 : tracker_row.json carries "company_key" (lowercase, punctuation and legal / generic suffixes
#                       removed). The instructions update an existing row when company_key AND role match (keeping the
#                       longer official name) and append otherwise, so "Akamai" and "Akamai Technologies" share a row.
V349_CO_SUFFIX = re.compile(r"(?:\s+(?:inc|incorporated|llc|ltd|limited|corp|corporation|co|company|plc|gmbh|technologies|information services))+$")


def v349_company_key(name: str) -> str:
    k = str(name or "").lower().replace("&", " and ").replace("'", "").replace("\u2019", "")
    k = re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]+", " ", k)).strip()
    return V349_CO_SUFFIX.sub("", k).strip() or k


# ===========================================================================
# v3.4.9b layer (2026-10-20). FORMAT BUILD: US Letter page, Times (mathptmx), the reference CV's tighter section spacing
# and header, bold numeric results, 5-line Skills. Each change sits behind its own master.json "v347_flags" entry
# (default true); with every v3.4.9b flag false the outputs are byte-identical to v3.4.9a (3_validation/
# diff_gate_v349b.py). New helper names only; every change to an existing function is made in its FINAL definition.
# Resumes only: letters, tracker rows and outreach never change. Jay graduates in December 2026 and starts work in
# February 2027 (both unchanged).
#  bank_format_v349b   : bank variants that fail the Letter geometry get reworded copies under new ids (bullet_bank.json
#                        "v348c": {"flag": "bank_format_v349b", "replaces": old id}); old ids are used only with the
#                        flag (or format_letter_v349b) off.
#  format_letter_v349b : Resume_Template_CURRENT.tex is the Letter template (letterpaper, mathptmx, header with the
#                        visible LinkedIn / GitHub addresses and no portfolio, section dividers 0.2em / 0.25em, role gap
#                        3pt); 2-line project bullets need a second-line fill >= 0.30 on Letter (Jay, 2026-10-20). Off:
#                        the v3.4.9a A4 template is rebuilt from the shipped one (V349B_FORMAT_PAIRS).
#  bold_results_v349b  : render-time \textbf around a numeric result plus up to 3 following words, at most 2 spans per
#                        Experience / project bullet. Stripping the spans gives the unbolded text exactly.
#  skills_cap5_v349b   : Skills render in at most 5 lines, one per category (filler leaves first; JD-named supported
#                        skills stay, else the existing "Skills full" note).
#  letter_trims_v349b  : the two lines General_CV_reference.tex saves: the Interviewed Experience bullet in one line
#                        (same facts minus "introducing them to the production projects and tech stack") and no AWS
#                        Cloud Practitioner line on the page (it stays in master and the context .md).
# ===========================================================================
# ===========================================================================
# v3.4.9c run 1 (2026-10-22): data. One flag, data_v349c (master.json v347_flags, default true). With it off the outputs
# are byte-identical to v3.4.9b: the loaded master gets its v3.4.9b data back (v349c_restore_master) and the template
# gets the "Expected December 2026" Education date back (v349b_effective_template). New helper names only; the changed
# functions are the FINAL definitions of v349b_effective_template, v349b_template_sha, _v348b_post_run and
# _prepare_runtime_cache.
#  1 coursework: master education.masters.coursework = the nine courses (Agentic AI is no longer coursework; as a skill it stays).
#  2 Education : "August 2025 -- December 2026" (no "Expected") in the template, master dates and the post-run check.
#  3 letter    : the GoingOnce letter sentence no longer says "We won 1st place."
# ===========================================================================
V349C_FLAG = "data_v349c"
V349C_EDU_NEW = "August 2025 -- December 2026"
V349C_OLD_TEMPLATE_SHA256 = "137af61ba9f7d50c7893a743d180314d8029bf58f4b7c15ca8594804e3aaf288"   # the v3.4.9b template
V349C_OLD_MASTER = {   # the v3.4.9b master values, restored into the loaded master when the flag is off
    "education.masters.dates": "August 2025 -- Expected December 2026",
    "education.masters.coursework": ["Agentic AI", "Machine Learning", "Deep Learning"],
    "cover_letter_bank.letter_sentences.projects.goingonce": "On a four-person hackathon team, I built mainly the negotiation and fleet agents for GoingOnce, a LangGraph car marketplace where a human approves every simulated bid. We won 1st place.",
    "cover_letter_evidence.coursework": ["Graduate Agentic AI coursework exists separately from RIPPLE; never merge coursework into RIPPLE or Professional Experience."],
    "layout_rules.education_v345": "v3.4.5: each degree line carries the degree (Master's: GPA inline after the degree name) and one right-aligned date; the institution follows on its own line. Optional line under the Master's institution: \"Relevant coursework: Agentic AI, Machine Learning, Deep Learning\" (education.masters.coursework), shown only on new-grad AI/ML postings or when the posting asks for coursework.",
}
_V349C_RESTORED: set[int] = set()


def v349c_on() -> bool:
    return _v347_on(V349C_FLAG)


def v349c_restore_master(master: dict[str, Any]) -> None:
    """Flag off: the loaded master gets the v3.4.9b data back (Education date, coursework, GoingOnce letter sentence)."""
    edu = master.setdefault("education", {}).setdefault("masters", {})
    edu["dates"] = V349C_OLD_MASTER["education.masters.dates"]
    edu["coursework"] = list(V349C_OLD_MASTER["education.masters.coursework"])
    ((master.setdefault("cover_letter_bank", {}).setdefault("letter_sentences", {}).setdefault("projects", {})))["goingonce"] = V349C_OLD_MASTER["cover_letter_bank.letter_sentences.projects.goingonce"]
    if "coursework" in (master.get("cover_letter_evidence") or {}):
        master["cover_letter_evidence"]["coursework"] = list(V349C_OLD_MASTER["cover_letter_evidence.coursework"])
    if "education_v345" in (master.get("layout_rules") or {}):
        master["layout_rules"]["education_v345"] = V349C_OLD_MASTER["layout_rules.education_v345"]


# ===========================================================================
# v3.4.9c run 2 (2026-10-22): page. One flag, page_v349c (master.json v347_flags, default true). With it off the outputs
# are byte-identical to v3.4.9c run 1: the template gets its run 1 blocks back (v349b_effective_template) and nothing
# below runs. Changes (Trial2_Standard_airy.tex / Trial2_NewGrad_646_airy.tex):
#  P1 preamble : the Standard reference preamble on every page (new-grad pages too), with one approved deviation:
#                geometry top 0.25in, bottom 0.2in, left/right 0.3in (the references use 0.4in; Jay 2026-10-22: 0.4in
#                and the NewGrad spacing cost Skills items / bullets on 6 GATE16 pages).
#  P2 header   : \rolegap after the name line; contact separators \hspace{0.5em}|\hspace{0.5em}.
#  P3 education: two lines (Master's, University at Buffalo (SUNY), GPA | Bachelor's, VESIT); coursework under the Master's line.
#  P4 awards   : no Certifications & Awards section; the AWS certification and the hackathon leave the loaded master's
#                awards, evidence and section order, and bank variants that name them are never selected.
#  P5 buffer   : one US Letter page with at least 10.5pt spare (V33_MIN_BUFFER_PT).
#  P6 content  : the run 1 page decides the content: v349b_main runs the Letter fit on the run 1 template first and the
#                page_v349c page starts at the attempt it kept (same slots, bullets, coursework decision and letter).
# Changed FINAL definitions: v349b_effective_template, v349b_template_sha, assemble_latex, _v345_coursework_tex,
# _v343_reorder, replace_section_body, validate_pdf, _v33_quality, load_bullet_bank, _prepare_runtime_cache, v349b_main
# (its body moves to the new helper _v349c_fit).
# ===========================================================================
V349C_PAGE_FLAG = "page_v349c"
V349C_RUN1_TEMPLATE_SHA256 = "afe49385a5fca7cf6dd4d0a2bc57c7f44f1d80b443f2e743296ce9a7ee11efc1"   # the v3.4.9c run 1 template
V349C_PAGE_PAIRS = (   # (run 1 template text, shipped page_v349c text)
    ("\\documentclass[10pt, letterpaper]{article}\n\\usepackage[utf8]{inputenc}\n\\usepackage{cmap}\n\\usepackage[T1]{fontenc}\n\\usepackage{mathptmx}\n\\usepackage{amsmath}\n\\usepackage{amsfonts}\n\\usepackage{amssymb}\n\\usepackage[hidelinks]{hyperref}\n\\usepackage[top=0.21in, bottom=0.21in, left=0.3in, right=0.3in]{geometry}\n\\usepackage{parskip}\n\\renewcommand{\\labelitemi}{$\\bullet$} % extracts as a real bullet character for ATS parsers\n\\setlength{\\parindent}{0pt}\n\\setlength{\\parskip}{0.4pt}\n\\linespread{0.98}\n\\hyphenpenalty=10000\n\\exhyphenpenalty=10000\n\\tolerance=1000\n\\emergencystretch=1em\n\n\\newcommand{\\sectiondivider}{\\vspace{0.2em}\\hrule\\vspace{0.25em}}\n\\newcommand{\\rolegap}{\\vspace{3pt}} % extra air between roles/projects; lower to 2pt if page 2 appears\n\n\\makeatletter\n\\renewcommand{\\section}{\\@startsection{section}{1}{\\z@}%\n\t{-0.2em \\@plus -0.1ex \\@minus -0.1ex}%\n\t{0.1ex \\@plus 0.1ex}%\n\t{\\normalfont\\large\\bfseries}}\n\\makeatother\n\n\\pagestyle{empty}\n\n",
     "\\documentclass[10pt, letterpaper]{article}\n\\usepackage[utf8]{inputenc}\n\\usepackage{cmap}\n\\usepackage[T1]{fontenc}\n\\usepackage{mathptmx}\n\\usepackage{amsmath}\n\\usepackage{amsfonts}\n\\usepackage{amssymb}\n\\usepackage[hidelinks]{hyperref}\n\\usepackage[top=0.25in, bottom=0.2in, left=0.3in, right=0.3in]{geometry}\n\\usepackage{parskip}\n\\renewcommand{\\labelitemi}{$\\bullet$}\n\\setlength{\\parindent}{0pt}\n\\setlength{\\parskip}{0.4pt}\n\\linespread{0.98}\n\\hyphenpenalty=10000\n\\exhyphenpenalty=10000\n\\tolerance=1000\n\\emergencystretch=1em\n\\newcommand{\\sectiondivider}{\\vspace{0.46em}\\hrule\\vspace{0.43em}}\n\\newcommand{\\rolegap}{\\vspace{5.2pt}}\n\\makeatletter\n\\renewcommand{\\section}{\\@startsection{section}{1}{\\z@}{-0.36em \\@plus -0.1ex \\@minus -0.1ex}{0.26ex \\@plus 0.1ex}{\\normalfont\\large\\bfseries}}\n\\makeatother\n\\pagestyle{empty}\n"),
    ("\t\t\\textbf{\\Large Jay Niketan Pathare} \\\\\n\t\t\\href{mailto:jayadmit456@gmail.com}{jayadmit456@gmail.com} | +1(716)303-9924 | NY, US | \\href{https://www.linkedin.com/in/jaypathare3}{linkedin.com/in/jaypathare3} | \\href{https://github.com/Jaypath456}{github.com/Jaypath456} \\\\\n",
     "\t\t\\textbf{\\Large Jay Niketan Pathare} \\\\\n\t\t\\rolegap\n\t\t\\href{mailto:jayadmit456@gmail.com}{jayadmit456@gmail.com}\\hspace{0.5em}|\\hspace{0.5em}+1(716)303-9924\\hspace{0.5em}|\\hspace{0.5em}NY, US\\hspace{0.5em}|\\hspace{0.5em}\\href{https://www.linkedin.com/in/jaypathare3}{linkedin.com/in/jaypathare3}\\hspace{0.5em}|\\hspace{0.5em}\\href{https://github.com/Jaypath456}{github.com/Jaypath456} \\\\\n"),
    ("\t\\noindent\\textbf{Master's in Computer Science} $|$ GPA: 3.85 / 4.0 \\hfill \\textit{August 2025 -- December 2026} \\\\\n\tUniversity at Buffalo, The State University of New York, Buffalo, NY \\\\[3.5pt]\n\t\\noindent\\textbf{Bachelor of Engineering, Information Technology} \\hfill \\textit{August 2019 -- May 2023} \\\\\n\tVivekanand Education Society's Institute of Technology, Mumbai University, India\n",
     "\t\\noindent\\textbf{Master's in Computer Science}, University at Buffalo (SUNY) $|$ GPA: 3.85 / 4.0 \\hfill \\textit{August 2025 -- December 2026} \\\\\n\t\\noindent\\textbf{Bachelor of Engineering, Information Technology}, VESIT, Mumbai University, India \\hfill \\textit{August 2019 -- May 2023}\n"),
    ("\t\\end{itemize}\n\t\\sectiondivider\n\t\n\t\\section*{CERTIFICATIONS \\& AWARDS}\n\t\\begin{itemize}\n\t\t\\setlength{\\itemsep}{0pt}\n\t\t\\item \\textbf{1st Place, ACV Auctions + Copart Challenge} $|$ AI for Good Hackathon Design Challenge, UB \\hfill \\textit{October 2026}\n\t\\end{itemize}\n\t\n\\end{document}",
     "\t\\end{itemize}\n\t\n\\end{document}"),
)
V349C_PAGE_BUFFER_PT = 10.5
V349C_CERT_HEAD = "CERTIFICATIONS & AWARDS"
V349C_HIDDEN_AWARDS = ("1st Place, ACV Auctions + Copart Challenge", "AWS Certified Cloud Practitioner")
V349C_NEVER_RENDER = ("1st Place", "Copart", "Cloud Practitioner")
_V349C_PAGE_APPLIED: set[int] = set()


V349C_CTX: dict[str, Any] = {"choice": None}


def v349c_page_on() -> bool:
    return _v347_on(V349C_PAGE_FLAG)


def v349c_page_wanted(argv: list[str], flag: str = V349C_PAGE_FLAG) -> bool:
    """page_v349c (or another flag) as the run will load it (master.json flag and the test-only off switch)."""
    try:
        fl = json.loads(Path(argv[argv.index("--master") + 1]).read_text(encoding="utf-8")).get("v347_flags") or {}
    except Exception:
        return False
    return bool(fl.get(flag, True)) and flag not in _V347_OFF


V349C_LOCK_FLAGS = (V349C_PAGE_FLAG, "thesis_v349c", "coursework_v349c")   # off while the content is decided (run 2 decisions)


def v349c_page_master(master: dict[str, Any]) -> None:
    """P4 (run time only): the awards, the hackathon evidence and the Certifications & Awards heading leave the loaded master."""
    master["awards"] = [a for a in (master.get("awards") or []) if (a.get("title") if isinstance(a, dict) else str(a)) not in V349C_HIDDEN_AWARDS]
    go = (master.get("projects") or {}).get("goingonce") or {}
    if isinstance(go.get("evidence"), list):
        go["evidence"] = [e for e in go["evidence"] if not any(x in str(e) for x in V349C_NEVER_RENDER[:1])]
    if isinstance(go.get("evidence_items"), dict):
        go["evidence_items"].pop("goingonce.award", None)
    lr = master.get("layout_rules") or {}
    for d in (lr, lr.get("new_grad") or {}):
        if isinstance(d.get("section_order"), list):
            d["section_order"] = [x for x in d["section_order"] if x != V349C_CERT_HEAD]


# ===========================================================================
# v3.4.9c run 3 (2026-10-22): Thesis bullets and coursework. Two independent flags (master.json v347_flags, default true).
#  thesis_v349c    : the Thesis first bullet is variant I (Agile/Scrum; reviewed and merged team pull requests, both
#                    master-recorded Thesis facts) by default and variant E (requirements first) only on
#                    requirements / stakeholder-heavy postings (a role line asks for requirements work, or two or more
#                    role lines name stakeholders / clients / business users); the mentor bullet is one line
#                    (V349C_MENTOR). Off: the run 2 selection and the v3.4.9b one-line Interviewed bullet.
#  coursework_v349c: new-grad pages only. Each course scores one point per listed term the role text names (word match,
#                    case-insensitive, plural allowed); the line shows the top 3 (ties: table order) when at least 2
#                    courses score, on one line under the Master's line. Off: the run 2 coursework rule.
# Changed FINAL definitions: select_experience_variants, _v345_set_coursework, validate_pdf, v349b_effective_template,
# v349b_template_sha; v349b_main / _v349c_fit decide the content with these flags off (run 2 decisions).
# ===========================================================================
V349C_THESIS_FLAG, V349C_CW_FLAG = "thesis_v349c", "coursework_v349c"
V349C_RUN2_TEMPLATE_SHA256 = "1bdb13f9b1c3c19ca08c7409e9fa99a4e8c8f697c8bfc11405afabf39105cc61"   # the v3.4.9c run 2 template
V349C_THESIS_DEFAULT, V349C_THESIS_REQS = "exp.thesis.1.I", "exp.thesis.1.E"
V349C_MENTOR = "Interviewed about 20 student candidates, onboarded and mentored the hires through weekly coding rounds over their first 3 weeks."
V349C_COURSE_TERMS = (   # (master course name, JD terms), in table order (ties)
    ("Operating Systems", ("operating systems", "linux", "kernel", "concurrency", "processes", "systems")),
    ("Algorithms Analysis & Design", ("algorithms", "data structures", "complexity", "problem solving")),
    ("Intro to Machine Learning", ("machine learning", "ML", "models", "training", "classification")),
    ("Data Intensive Computing", ("distributed", "big data", "data pipelines", "large-scale", "parallel")),
    ("Computer Security", ("security", "authentication", "encryption", "vulnerabilities")),
    ("Data Models & Query Languages", ("SQL", "database", "data modeling", "query", "schema")),
    ("Project Development", ("software development", "SDLC", "agile", "delivery")),
    ("Project Management", ("project management", "scrum", "stakeholders", "planning")),
    ("Deep Learning", ("deep learning", "neural networks", "PyTorch", "NLP", "computer vision")),
)


def v349c_thesis_on() -> bool:
    return _v347_on(V349C_THESIS_FLAG)


def v349c_cw_on() -> bool:
    return _v347_on(V349C_CW_FLAG)


def v349c_reqs_heavy(raw_jd: str) -> list[str]:
    """The role lines that make a posting requirements / stakeholder-heavy (empty when it is not)."""
    lines = _v342_role_text(raw_jd)
    reqs = [l for l in lines if _V344_REQS.search(l)]
    stake = [l for l in lines if _V344_STAKE.search(l)]
    return reqs[:1] or (stake[:2] if len(stake) >= 2 else [])


def _v349c_term_rx(term: str) -> re.Pattern:
    body = re.escape(term).replace(r"\ ", r"[\s-]+")
    return re.compile(r"(?<![A-Za-z0-9])" + body + (r"(?:s|es)?" if not term.endswith("s") else "") + r"(?![A-Za-z0-9])", re.I)


def v349c_course_scores(text: str) -> list[tuple[str, int, list[str]]]:
    """[(course, score, matched terms)] in table order."""
    out = []
    for course, terms in V349C_COURSE_TERMS:
        hit = [t for t in terms if _v349c_term_rx(t).search(text)]
        out.append((course, len(hit), hit))
    return out


def v349c_top_courses(text: str) -> tuple[list[str], list[tuple[str, int, list[str]]]]:
    """The top 3 courses (ties broken by table order) when at least 2 courses match; [] otherwise."""
    sc = v349c_course_scores(text)
    if sum(1 for _, n, _ in sc if n > 0) < 2:
        return [], sc
    order = sorted(range(len(sc)), key=lambda i: (-sc[i][1], i))
    return [sc[i][0] for i in order[:3]], sc


# ===========================================================================
# v3.4.9c run 4 (2026-10-22): layout. One flag, layout_v349c (master.json v347_flags, default true). Off: the run 3
# path (content decided with the run 2-3 flags off, then rendered) and the run 3 Skills, byte for byte.
#  L1 slots    : new-grad pages show 3/2/2 project slots (6/4/4 lines), a subset of the reference page's slots (each
#                choice of left-out slots is tried in a fixed order; the letter must stay the reference letter).
#  L2 fit      : per page only, never global: (1) the coursework line leaves, (2) Skills filler leaves (the page-buffer
#                Skills budget trim), (3) one bullet slot leaves the lowest-ranked project with two or more.
#  L3 Skills   : at most 5 lines; a 6th line only when every item that needs it is named in the posting.
#  L4 Python   : first on the Languages line on AI/ML postings (role family ai_llm / data_science_ml).
#  Go Digital  : unchanged (v3.4.5 keep_go_digital: hidden on new-grad pages except data / fintech / compliance).
# Changed FINAL definitions: v349b_main, _v349c_fit, run_pdflatex, v349b_skills_cap5, build_skill_states.
# ===========================================================================
V349C_LAYOUT_FLAG = "layout_v349c"
V349C_NG_SLOTS = (3, 2, 2)
V349C_AI_FAMILIES = ("ai_llm", "data_science_ml")
V349C_LAYOUT_MAX_TRIES = 30


def v349c_layout_on() -> bool:
    return _v347_on(V349C_LAYOUT_FLAG)


def v349c_required_in_skills(states: list[dict[str, Any]], plan: dict[str, Any], master: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """v3.4.9c run 6 fix (data_v349c): a required ATS term (must / high, supported) that no Skills line holds and the page
    does not show joins its Skills category. Before run 1 the master coursework list carried "Agentic AI" and the ATS
    check counted it from the Education text although the coursework line was not printed (assetwatch)."""
    master = master if master is not None else globals().get("_V33_MASTER")
    if not v349c_on() or not states or master is None:
        return states
    req = [str(x) for x in states[0].get("required_ats_terms") or []]
    have = {str(x).casefold() for v in (states[0].get("skills") or {}).values() for x in v}
    try:
        page = _v33_page_text(plan, master, resolved_project_header_tech(master, plan["ranking"], plan))
    except Exception:
        return states
    added, opened = [], set()
    for t in req:
        if t.casefold() in have or boundary_contains_plural(page, t):   # the ATS check's word match, not the looser shown-on-page test
            continue
        cat = supported_skill_category(t, master)
        cat = {"ai_ml_data": "ai_ml", "tools_platforms": "tools"}.get(cat, cat)
        if not cat:
            continue
        if not (states[0].get("skills") or {}).get(cat):
            opened.add(cat)
        for st in states:
            st.setdefault("skills", {}).setdefault(cat, [])
            if t not in st["skills"][cat]:
                st["skills"][cat].append(t)
        added.append(t)
    if added:
        plan["_v349c_required_added"] = added
        # a posting-named required term that opens a Skills line may use one more line (run 4 L3: a 6th line only
        # for terms the posting names)
        lr = master.get("layout_rules") or {}
        base = int(master.setdefault("_v349c_skills_max_base", int(lr.get("skills_rendered_lines_max", 5))))
        if opened:
            lr["skills_rendered_lines_max"] = base + len(opened)
            plan["_v349b_skills_six"] = plan.get("_v349b_skills_six") or "+".join(added)
    return states


def v349c_python_first(states: list[dict[str, Any]], plan: dict[str, Any], master: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """L4: Python leads the Languages & Databases line on AI/ML postings."""
    states = v349c_required_in_skills(states, plan, master)   # v3.4.9c run 6 fix (data_v349c)
    if not v349c_layout_on() or str(plan.get("role_family", "")) not in V349C_AI_FAMILIES:
        return states
    for st in states or []:
        vals = (st.get("skills") or {}).get("languages_databases")
        if isinstance(vals, list) and "Python" in vals and vals[0] != "Python":
            vals.remove("Python")
            vals.insert(0, "Python")
            plan["_v349c_python_first"] = True
    return states


def v349c_layout_cands(slots: dict[str, Any], ranking: list[str], new_grad: bool, terms: dict[str, list[str]] | None = None, extra: bool = False) -> list[tuple[Any, ...]]:
    """L1 / L2 attempts in order: (pool by project, coursework allowed?, slots by project, Skills filler may leave?, phase).
    Slot choices that lose the fewest page technologies (bank jd_terms no kept bullet carries) come first, so Skills
    keep their items; ties keep the fixed order (later slots leave first)."""
    k = {q: len(slots.get(q) or []) for q in ranking}
    tgt = {q: min(k[q], n) for q, n in zip(ranking, V349C_NG_SLOTS)} if new_grad else dict(k)
    per = []
    for q in ranking:
        sl = [list(x) for x in slots.get(q) or []]
        n_drop = len(sl) - tgt[q]
        per.append([(q, [x for j, x in enumerate(sl) if j not in set(drop)]) for drop in itertools.combinations(list(reversed(range(len(sl)))), n_drop)])
    base = [{q: kept for q, kept in c} for c in itertools.product(*per)]
    if terms:
        def lost(b: dict[str, Any]) -> int:
            keep = {t.casefold() for q in ranking for x in b[q] for i in x for t in terms.get(i, [])}
            gone = {t.casefold() for q in ranking for x in (slots.get(q) or []) if x not in b[q] for i in x for t in terms.get(i, [])}
            return len(gone - keep)
        base = [b for _, b in sorted(enumerate(base), key=lambda e: (lost(e[1]), e[0]))]
    pool = lambda b: {q: [i for x in b[q] for i in x] for q in ranking}
    kk = lambda b: {q: len(b[q]) for q in ranking}
    out = [(pool(b), False, kk(b), False, "fits") for b in base]                      # (1) the coursework line may leave inside the build
    out += [(pool(b), True, kk(b), True, "skills_filler") for b in base]              # (2) Skills filler leaves
    for b in base:                                                                     # (3) one bullet slot leaves
        qs = [x for x in reversed(ranking) if len(b[x]) >= 2]
        for q in (qs[1:] if extra else qs[:1]):   # v3.4.9c run 6 fix: extra = the higher-ranked projects (after the fallback page misses)
            for drop in reversed(range(len(b[q]))):
                b2 = dict(b); b2[q] = [x for j, x in enumerate(b[q]) if j != drop]
                out.append((pool(b2), True, kk(b2), True, "one_slot"))
    if extra:
        return [c for c in out if c[4] == "one_slot"][:V349C_LAYOUT_MAX_TRIES]
    return out[:V349C_LAYOUT_MAX_TRIES]


# ===========================================================================
# v3.4.9c run 5 (2026-10-22): adaptive spacing. One flag, spacing_v349c (master.json v347_flags, default true). Off:
# the run 4 page, byte for byte. After the build has decided and validated the page, one airiness parameter t in
# [0, 1] is binary-searched in 9 steps (lo = 0, hi = 1; mid = (lo + hi) / 2; a page is accepted when it is one US
# Letter page with at least 10.5pt spare; equal spare counts as accepted) and the largest accepted t is kept:
#   \sectiondivider before 0.2em -> 1.0em, after 0.25em -> 0.8em; \rolegap 3pt -> 10pt; \section skip before
#   0.2em -> 0.7em, after 0.1ex -> 0.6ex; itemsep 0pt -> 1.5pt.
# Only these vertical lengths change: no text, bullet, Skills, ranking, coursework or margin changes. report.json
# records spacing_v349c (t, the 9 steps, spare). Changed FINAL definition: main_v3_1.
# ===========================================================================
V349C_SPACING_FLAG = "spacing_v349c"
V349C_SPACING_STEPS = 9
V349C_SPACING_MIN_PT = 10.5
_V349C_SP_DIV = re.compile(r"\\newcommand\{\\sectiondivider\}\{\\vspace\{[^{}]*\}\\hrule\\vspace\{[^{}]*\}\}")
_V349C_SP_GAP = re.compile(r"\\newcommand\{\\rolegap\}\{\\vspace\{[^{}]*\}\}")
_V349C_SP_SEC = re.compile(r"(\\renewcommand\{\\section\}\{\\@startsection\{section\}\{1\}\{\\z@\}%?\s*)\{-[0-9.]+em( \\@plus -0\.1ex \\@minus -0\.1ex)\}(%?\s*)\{[0-9.]+ex( \\@plus 0\.1ex)\}")
_V349C_SP_ITEM = re.compile(r"\\setlength\{\\itemsep\}\{0pt\}")


def v349c_spacing_tex(tex: str, t: float) -> str | None:
    """The page at airiness t (None when the spacing lines are not all found exactly once)."""
    f = lambda a, b: "%.4f" % (a + (b - a) * t)
    if len(_V349C_SP_DIV.findall(tex)) != 1 or len(_V349C_SP_GAP.findall(tex)) != 1 or len(_V349C_SP_SEC.findall(tex)) != 1:
        return None
    tex = _V349C_SP_DIV.sub(lambda m: "\\newcommand{\\sectiondivider}{\\vspace{%sem}\\hrule\\vspace{%sem}}" % (f(0.2, 1.0), f(0.25, 0.8)), tex, count=1)
    tex = _V349C_SP_GAP.sub(lambda m: "\\newcommand{\\rolegap}{\\vspace{%spt}}" % f(3.0, 10.0), tex, count=1)
    tex = _V349C_SP_SEC.sub(lambda m: m.group(1) + "{-%sem%s}" % (f(0.2, 0.7), m.group(2)) + m.group(3) + "{%sex%s}" % (f(0.1, 0.6), m.group(4)), tex, count=1)
    return _V349C_SP_ITEM.sub(lambda m: "\\setlength{\\itemsep}{%spt}" % f(0.0, 1.5), tex)


def _v349c_spacing_measure(tex: str, work: Path) -> tuple[int, float]:
    work.mkdir(parents=True, exist_ok=True)
    (work / "build_resume.tex").write_text(tex, encoding="utf-8")
    subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "build_resume.tex"], cwd=work, capture_output=True, text=True)
    try:
        with fitz.open(work / "build_resume.pdf") as d:   # unrounded spare (the 10.5pt test is not met by rounding up)
            y = max((sp["origin"][1] for b in d[0].get_text("dict").get("blocks", []) for l in b.get("lines", []) for sp in l.get("spans", []) if sp.get("text", "").strip()), default=0.0)
            return len(d), d[0].rect.height - 0.21 * 72 - y
    except Exception:
        return 0, -1.0


def v349c_spacing(argv: list[str]) -> None:
    """Run 5: the largest accepted airiness t for the finished page (see the layer note)."""
    try:
        out_dir = Path(argv[argv.index("--out-dir") + 1])
        rep = json.loads((out_dir / "report.json").read_text(encoding="utf-8"))
    except Exception:
        return
    build = out_dir / "build_resume.tex"
    texs = sorted(p for p in out_dir.glob("*.tex") if not p.name.startswith("build_") and p.name != "Resume_Template_CURRENT.tex")
    if rep.get("status") != "PASS" or rep.get("skip") or not build.exists() or not texs:
        return
    src, hand = build.read_text(encoding="utf-8"), texs[0].read_text(encoding="utf-8")
    work = out_dir / "_spacing_v349c"
    ok = lambda r: r[0] == 1 and r[1] >= V349C_SPACING_MIN_PT
    info: dict[str, Any] = {"t": None, "steps": []}
    if v349c_spacing_tex(src, 0.0) is None or v349c_spacing_tex(hand, 0.0) is None:
        info["note"] = "spacing lines not found; page unchanged"
    elif not ok(_v349c_spacing_measure(v349c_spacing_tex(src, 0.0), work)):
        info["note"] = "t = 0 misses one page with 10.5pt spare; page unchanged"
    else:
        lo, hi = 0.0, 1.0
        for _ in range(V349C_SPACING_STEPS):
            mid = (lo + hi) / 2
            r = _v349c_spacing_measure(v349c_spacing_tex(src, mid), work)
            info["steps"].append({"t": mid, "pages": r[0], "spare_pt": r[1], "accepted": ok(r)})
            lo, hi = (mid, hi) if ok(r) else (lo, mid)
        info["t"] = lo
        build.write_text(v349c_spacing_tex(src, lo), encoding="utf-8")
        texs[0].write_text(v349c_spacing_tex(hand, lo), encoding="utf-8")
        subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "build_resume.tex"], cwd=out_dir, capture_output=True, text=True)
        with fitz.open(out_dir / "build_resume.pdf") as d:
            info["pages"], info["spare_pt"] = len(d), _v33_free_space(d[0])
        info["spare_pt_unrounded"] = round(_v349c_spacing_measure(v349c_spacing_tex(src, lo), work)[1], 3)
        sha = hashlib.sha256(texs[0].read_bytes()).hexdigest()
        if (out_dir / "tex_sha256.txt").exists():
            (out_dir / "tex_sha256.txt").write_text(sha + "  " + texs[0].name + "\n", encoding="utf-8")
        q = out_dir / "quality_v33.json"
        if q.exists():
            qq = json.loads(q.read_text(encoding="utf-8"))
            qq.update({"free_space_pt": info["spare_pt"], "resume_tex_sha256": sha})
            q.write_text(json.dumps(qq, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        if isinstance(rep.get("format_v349b"), dict):
            rep["format_v349b"]["free_space_pt"] = info["spare_pt"]
        try:
            _v345_packet_pdf_text(out_dir)
        except Exception:
            pass
    import shutil
    shutil.rmtree(work, ignore_errors=True)
    rep["spacing_v349c"] = info
    (out_dir / "report.json").write_text(json.dumps(rep, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


# ===========================================================================
# v3.4.9c run 6 (2026-10-22): must-have framework rule. One flag, must_framework_v349c (master.json v347_flags, default
# true). Off: the run 5 ranking, byte for byte. When a programming language or framework (master skills pools) is a MUST
# requirement - named in a required, unhedged qualification line ("experience in", "proficiency", "knowledge of",
# "required", "years of"...; not a responsibility, a "Stack:" list, a "helpful / not mandatory / plus / preferred" line,
# "one of / such as / or similar" alternatives or a list of three or more technologies, not "X or Y") -
# and exactly one project is its primary evidence, that project becomes rank 1 when it is already one of the three
# selected projects (the project set never changes; otherwise the ranking stays). Primary evidence: the project's stack (master tech) names the term AND
# either the stack leads with it or the project's identity / headline evidence text names it. Several must terms that
# point to different projects decide nothing. report.json: must_framework_v349c. Changed FINAL definitions:
# apply_auto_ranking, v349_post_run, main_v3_1 (context reset).
# ===========================================================================
V349C_MUST_FLAG = "must_framework_v349c"
V349C_MUST_LANGS = ("Python", "Java", "JavaScript", "C", "Go")
V349C_MUST_ALIASES = {"ReactJS": ("ReactJS", "React", "React.js"), "Django REST Framework": ("Django REST Framework", "Django REST", "DRF"), "Go": ("Go", "Golang")}
V349C_MUST_HEDGE = re.compile(r"\([^()]*\b(?:a plus|plus|preferred|nice to have|bonus|ideally|desired)\b[^()]*\)|[\w.+#/-]+(?:\s+[\w.+#/-]+)?\s+(?:is\s+|are\s+)?(?:a plus|preferred|nice to have|a bonus)\b", re.I)
V349C_MUST_ALT = re.compile(r"\b(?:or|and/or)\b|/", re.I)
# a requirement line states a qualification (not a responsibility, a stack list or a "helpful" line)
V349C_MUST_CUE = re.compile(r"\bexperience (?:in|with|using|building)\b|\bproficien\w*|\bexpertise (?:in|with)\b|\bknowledge of\b|\bskills? (?:in|with)\b|"
                            r"\brequired\b|\bmust\b|\byears? of\b|\bbackground in\b|\bfluen\w+", re.I)
V349C_MUST_LINE_HEDGE = re.compile(r"\bhelpful\b|\bnot (?:mandatory|required|necessary)\b|\bnice[- ]to[- ]have\b|\bplus\b|\bpreferred\b|\bbonus\b|\bdesir\w+|\bideally\b|\bnot a must\b", re.I)
V349C_MUST_STACK = re.compile(r"^\W*(?:(?:our|the|tech(?:nology)?)\s+)?(?:stack|front[- ]?end|back[- ]?end|tools?|technologies|tech)\s*:|\bwe use\b|\bour stack\b", re.I)
V349C_MUST_LIST = re.compile(r"\bone of\b|\bany of\b|\bat least (?:one|two|three|\d+)\b|\bof the following\b|\bsuch as\b|\be\.g\.|\bsimilar\b|\bequivalent\b|\bor (?:another|other|a similar|related)\b", re.I)
V349C_CTX.setdefault("must", None)


def _v349c_term_re(alias: str) -> re.Pattern:
    return re.compile(r"(?<![\w#+.])" + re.escape(alias) + r"(?![\w#+])", 0 if len(alias) <= 2 else re.I)


def v349c_primary_projects(term: str, master: dict[str, Any]) -> list[str]:
    al = V349C_MUST_ALIASES.get(term, (term,))
    out = []
    for pid, p in (master.get("projects") or {}).items():
        tech = [str(x) for x in p.get("tech") or []]
        if not any(_v349c_term_re(a).search(x) for a in al for x in tech):
            continue
        lead = bool(tech) and any(_v349c_term_re(a).match(tech[0]) for a in al)
        ev = p.get("evidence_items") or {}
        ids = set(_IDENTITY_EVIDENCE.get(pid, set())) | ({p["headline_evidence_id"]} if p.get("headline_evidence_id") else set())
        txt = " ".join(str((ev.get(i) or {}).get("text", "")) for i in sorted(ids))
        if lead or any(_v349c_term_re(a).search(txt) for a in al):
            out.append(pid)
    return out


def v349c_must_terms(raw_jd: str, master: dict[str, Any]) -> list[tuple[str, str]]:
    """[(term, required line)] for languages / frameworks the posting requires (unhedged required lines only)."""
    pool = list(V349C_MUST_LANGS) + [str(x) for x in ((master.get("skills") or {}).get("supported_pool") or {}).get("frameworks_libraries", [])]
    found = []
    for line, w, h in _v33_role_lines(raw_jd):
        if h or w < 1.0:
            continue
        clean = V349C_MUST_HEDGE.sub(" ", line)
        if V349C_MUST_STACK.search(line) or not V349C_MUST_CUE.search(clean) or V349C_MUST_LINE_HEDGE.search(clean) or V349C_MUST_LIST.search(clean):
            continue   # a stack list, a responsibility, a "helpful / not mandatory" line or a list of alternatives
        if sum(1 for t2 in pool for a2 in V349C_MUST_ALIASES.get(t2, (t2,)) if _v349c_term_re(a2).search(clean)) >= 3 and re.search(r",", clean):
            continue   # several languages / frameworks listed side by side: none of them alone is the must
        for t in pool:
            if any(x[0] == t for x in found):
                continue
            for a in V349C_MUST_ALIASES.get(t, (t,)):
                m = _v349c_term_re(a).search(clean)
                if m and not V349C_MUST_ALT.search(clean[max(0, m.start() - 12):m.start()]) and not V349C_MUST_ALT.search(clean[m.end():m.end() + 12]):
                    found.append((t, line.strip()))
                    break
    return found


def v349c_must_rank(raw_plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> None:
    ranking = list(raw_plan.get("ranking") or [])
    if len(ranking) != 3:
        return
    hits = []
    for t, line in v349c_must_terms(raw_jd, master):
        prim = v349c_primary_projects(t, master)
        if len(prim) == 1:
            hits.append({"term": t, "project": prim[0], "line": line[:200]})
    info: dict[str, Any] = {"must_terms": hits, "before": ranking}
    projs = sorted({h["project"] for h in hits})
    if len(projs) != 1:
        info["applied"] = False
        info["reason"] = "no must term with one primary project" if not projs else "must terms point to different projects: " + ", ".join(projs)
    elif projs[0] not in ranking:
        info.update({"applied": False, "project": projs[0], "reason": f"{projs[0]} is not one of the three selected projects (the project set is kept)"})
    else:
        pid = projs[0]
        new = [pid] + [p for p in ranking if p != pid]
        info.update({"applied": new != ranking, "project": pid, "after": new})
        if new != ranking:
            scores = dict(raw_plan.get("project_scores") or {})
            top = max([float(v) for v in scores.values()] or [0.0])
            for p in scores:
                if p not in new:
                    scores[p] = min(float(scores[p]), round(top, 3))
            for i, p in enumerate(new):
                scores[p] = round(top + 3.0 - i, 3)
            raw_plan["project_scores"] = scores
            raw_plan["ranking"] = new
            _v344_change(f"Ranking: {pid} leads - the posting requires {', '.join(h['term'] for h in hits)} and {pid} is its one primary project", hits[0]["line"])
    V349C_CTX["must"] = info


# ===========================================================================
# v3.4.9c run 7 (2026-10-22): grounded closings. One flag, closing_v349c (master.json v347_flags, default true). Off: the
# run 6 closing, byte for byte. A responsibility closing ("I want to <responsibility> at <company>, <connector> <proof>.")
# is kept only when every specific word of the responsibility is demonstrated by its proof: the word is part of the
# proof kind the master's closing-proof map ties to that proof (cover_letter_bank.closing_proofs _rule), or it appears
# in the proof's own evidence (closing proof text; the project's evidence item text, claim atoms, terms, stack and tags;
# for an Experience proof, that job's bullets and evidence anchors). Generic verbs, qualities and nouns ("build",
# "scalable", "software") are not claims. An unsupported responsibility is set aside and the next candidate is tried;
# when none qualifies, the existing role-family closing is used. report.json: closing_v349c. Changed FINAL definition:
# _v344_closing.
# ===========================================================================
V349C_CLOSING_FLAG = "closing_v349c"
V349C_CLOSING_TRIES = 8
V349C_GENERIC = set("""a an the and or of to in on for with across into from by at as that this these those our their your its it is are be all any each other
build builds building built develop develops developing design designs designing write writes writing maintain maintains maintaining help helps
support supports supporting deliver delivers delivering create creates creating implement implements implementing test tests testing deploy deploys
deploying ship shipping own owning improve improves improving enhance enhancing contribute contributing work working use using make making keep
ensure ensuring drive driving collaborate partner run running enable enabling power powers include including new existing
software code applications application app apps systems system features components component solutions solution platform platforms products product
functionality team teams tools tool projects project technology technologies production world real-world real quality high-quality well services service
scalable maintainable clean efficient reliable robust documented well-documented well-engineered engineered modern best practices simple performant
fast quickly safely high generic core key critical various multiple end-to-end full complex large""".split())
V349C_PROOF_PROJECT = {"ledger": "ledgerflow", "launchops": "launchops", "ripple": "ripple", "pintos": "pintos", "tailor": "tailor_pipeline", "fraud": "fraud", "goingonce": "goingonce"}


def v349c_proof_corpus(key: str, master: dict[str, Any]) -> str:
    """The evidence a closing proof stands for (lower case)."""
    proofs = (master.get("cover_letter_bank") or {}).get("closing_proofs") or {}
    parts = [str(proofs.get(key, ""))]
    if key.startswith("exp."):
        rx = V349_EXP_PROOF.get(key)
        for r in master.get("experience") or []:
            if rx and any(re.search(rx, str(b)) for b in r.get("bullets") or []):
                parts += [str(b) for b in r.get("bullets") or []] + [str(r.get("evidence_anchors", "")), str(r.get("role", "")), str(r.get("organization", ""))]
    else:
        p = (master.get("projects") or {}).get(V349C_PROOF_PROJECT.get(key.split(".")[0], ""), {})
        e = (p.get("evidence_items") or {}).get(v349_proof_eid(key), {})
        parts += [str(e.get("text", ""))] + [str(x) for x in list(e.get("claim_atoms") or []) + list(e.get("terms") or [])]
        parts += [str(x) for x in list(p.get("tech") or []) + list(p.get("tags") or [])]
    return " ".join(parts).lower()


def v349c_closing_unsupported(resp: str, key: str, kind: str, master: dict[str, Any]) -> list[str]:
    """The specific words of a closing responsibility that its proof does not demonstrate ([] = supported)."""
    covered: set[int] = set()
    rx = next((c[1] for c in _V344_KINDS if c[0] == kind), None)
    if rx is not None:
        for mm in rx.finditer(resp):
            covered |= set(range(mm.start(), mm.end()))
    cor = v349c_proof_corpus(key, master)
    out = []
    for mm in re.finditer(r"[A-Za-z][A-Za-z0-9+#/-]*", resp):
        w = mm.group(0).lower().strip("-/")
        if w in V349C_GENERIC or len(w) < 2 or any(i in covered for i in range(mm.start(), mm.end())):
            continue
        if not v349c_word_in(w, cor):   # v3.4.9c fix1: plurals, front-end / back-end / full-stack spellings, compounds
            out.append(w)
    return out


V349C_EQUIV = {"frontend": ("front end", "front-end", "frontend"), "front-end": ("front end", "front-end", "frontend"),
               "backend": ("back end", "back-end", "backend"), "back-end": ("back end", "back-end", "backend"),
               "full-stack": ("full stack", "full-stack", "fullstack"), "fullstack": ("full stack", "full-stack", "fullstack")}   # spellings only
V349C_COMPOUND_TAIL = {"powered", "based", "driven", "facing", "level", "grade", "ready", "oriented"}


def v349c_word_in(w: str, cor: str) -> bool:
    """A responsibility word is in the proof's evidence: the same word or its singular ("APIs" -> "API"), one of the
    listed spellings, or, for a compound, the whole term or each specific part of 4+ letters ("customer-facing")."""
    if w in V349C_EQUIV:
        return any(e in cor for e in V349C_EQUIV[w])
    if "-" in w or "/" in w:   # the whole term ("low-level", "ai-powered"), else every specific part of 4+ letters
        if any(v in cor for v in (w, w.replace("-", " "), w.replace("-", ""))):
            return True
        parts = [p for p in re.split(r"[-/]", w) if p and p not in V349C_GENERIC and p not in V349C_COMPOUND_TAIL]
        return bool(parts) and all(len(p) >= 4 for p in parts) and all(v349c_word_in(p, cor) for p in parts)
    n = w[:-3] + "y" if w.endswith("ies") and len(w) > 4 else (w[:-1] if w.endswith("s") and not w.endswith("ss") and len(w) > 3 else w)
    stem = n[:5] if len(n) > 5 else n
    return bool(re.search(r"(?<![a-z])" + re.escape(stem), cor))


def v349c_family_unsupported(plan: dict[str, Any], master: dict[str, Any], inf: dict[str, Any]) -> list[str]:
    """A role-family closing's claim words its proof does not demonstrate."""
    tmpl = master.get("cover_letter_bank", {}).get("family_closing", {}).get(str(plan.get("role_family", "")), "build dependable, well-tested software with the team at {company}")
    claim = re.sub(r"\s+", " ", tmpl.replace("{company}'s", " ").replace("{company}", " ")).strip()
    return v349c_closing_unsupported(claim, str(inf.get("proof") or ""), str(inf.get("proof_kind") or ""), master)


V349C_FAMILY_QUALITY = {"apply", "careful", "trustworthy", "grow", "they"}


def v349c_claim_in_master(claim: str, master: dict[str, Any]) -> list[str]:
    """A family claim's words that no master evidence (any closing proof's evidence) demonstrates ([] = supported)."""
    keys = list(((master.get("cover_letter_bank") or {}).get("closing_proofs") or {}).keys())
    cor = " ".join(v349c_proof_corpus(k, master) for k in keys)
    out = []
    for mm in re.finditer(r"[A-Za-z][A-Za-z0-9+#/-]*", re.sub(r"(?i)\bmachine learning\b", "ml", claim)):
        w = mm.group(0).lower().strip("-/")
        if w in V349C_GENERIC or w in V349C_FAMILY_QUALITY or len(w) < 2:
            continue
        stem = w[:5] if len(w) > 5 else w
        if not re.search(r"(?<![a-z])" + re.escape(stem), cor):
            out.append(w)
    return out


def v349c_family_closing(plan: dict[str, Any], master: dict[str, Any], raw_jd: str, company_ref: str, body: str, budget: int) -> tuple[str, dict[str, Any]]:
    """The existing role-family closing (as _v344_closing ends), for a posting with no supported responsibility."""
    fam = str(plan.get("role_family", ""))
    tmpl = master.get("cover_letter_bank", {}).get("family_closing", {}).get(fam, "build dependable, well-tested software with the team at {company}")
    if v349c_claim_in_master(re.sub(r"\s+", " ", tmpl.replace("{company}'s", " ").replace("{company}", " ")), master):
        tmpl = master.get("cover_letter_bank", {}).get("family_closing", {}).get("general_swe", "build dependable, well-tested software with the team at {company}")   # no master evidence demonstrates this family claim ("catch defects")
    poss = company_ref + ("'" if company_ref.endswith("s") else "'s")
    what = tmpl.replace("{company}'s", poss).replace("{company}", company_ref)
    if company_ref in ("your team", "your client"):
        what = what.replace("with the team at your team", "with your team").replace("at your client", "for your client")
    conn = _v344_connector(what, company_ref)
    used: set[str] = set()
    kind = eid = proof = None
    claim = re.sub(r"\s+", " ", tmpl.replace("{company}'s", " ").replace("{company}", " ")).strip()
    for _ in range(12):
        kind, eid, proof = _v344_pick_proof(" ".join(_v342_role_text(raw_jd)[:6]), plan, master, body, used=used)
        if proof and v349c_closing_unsupported(claim, str(eid), str(kind or ""), master):
            used.add(eid)   # the proof must demonstrate the family claim too ("keep systems healthy" needs an operations proof)
            continue
        conn = _v344_connector(what, company_ref, proof)
        s = f"I want to {what}, {conn} {proof}." if proof else f"I want to {what}."
        if not proof or len(s.split()) <= min(budget, 30):
            break
        used.add(eid)
    else:
        kind = eid = proof = None
        conn = _v344_connector(what, company_ref)
        s = f"I want to {what}."
    return s, {"rule": "v3.4.4", "responsibility": "", "proof": eid, "proof_kind": kind, "_proof": proof, "connector": conn, "family": True}


# ===========================================================================
# v3.4.9c run 8 (2026-10-22): plain letters. One flag, letters_plain_v349c (master.json v347_flags, default true). Off:
# the run 7 letter, byte for byte. The letter is rebuilt in three paragraphs (120-160 words, greeting and sign-off not
# counted) from master.json cover_letter_bank.plain_v349c, sentences that restate master evidence in everyday words:
#  P1 the role and company, and one connection to the posting (the plan's hook when it is plain, else a posting
#     responsibility); P2 the letter's Experience sentence (descriptive) and the rank #1 project; P3 the graduation /
#     start sentence (full-time: "I graduate in December 2026 and can start work in February 2027."; internships keep
#     their sentence), the relocation sentence when the run 7 letter had one, the run 7 closing (same responsibility,
#     proof and connector; the proof in its plain wording) and a thank-you.
# At most one concrete achievement (the project sentence, or the closing proof when that is a result; the project
# sentence then uses its descriptive form). No tool or library names, digits (except the graduation / start sentence and
# the posting's own role title or company name), hackathon or certification words, or standalone "we / our / us". A run 7
# closing whose responsibility names a tool or carries a digit is picked again for the plain letter with it set aside.
# The run 7 letter stays in the plan until build_cover_letter writes the plain one, so every page decision (fit steps that
# compare letters, "every letter number is on the resume") sees the run 7 letter and resumes stay as in run 7.
# Changed FINAL definitions: compose_bank_cover_letter (outer guard), _v344_closing (run 7 wrapper), validate_plan_v3_1,
# v346_letter_p2, build_cover_letter, v349b_note_letter, _v33_quality.
# ===========================================================================
V349C_PLAIN_FLAG = "letters_plain_v349c"
V349C_NOT_TOOLS = {"Concurrency", "File Systems", "Focal Loss", "GNN", "Kernel Development", "Operating Systems", "Process Lifecycle",
                   "Relational Databases", "Thread Synchronization", "Server-Sent Events", "live answers only", "local k3d"}   # v3.4.9c run 9: concepts
V349C_PLAIN_MIN, V349C_PLAIN_MAX = 120, 154   # body words; with the greeting and sign-off (6 words) at most 160
V349C_PLAIN_FT = "I graduate in December 2026 and can start work in February 2027."
V349C_PLAIN_THANKS = "Thank you for considering my application."
V349C_PLAIN_PAD = "I would welcome the chance to talk about how I can help."
V349C_PLAIN_AI_OWN = "An AI coding assistant helped me write it, and I checked its work with its full test suite."   # master ripple.claude_code_dev
V349C_PLAIN_AI = "An AI coding assistant helped me write RIPPLE, a tool that predicts which files and tests a code change will affect, and I checked its work with its full test suite."
V349C_PLAIN_AI_SHORT = "An AI coding assistant helped me write RIPPLE, and I checked its work with its full test suite."
V349C_PLAIN_BANNED = re.compile(r"\bhackathon\w*|\b1st place\b|\bfirst place\b|\bcopart\b|\bcertif\w*|\bcloud practitioner\b", re.I)
V349C_PLAIN_PRON = re.compile(r"(?<![\w'’])(?:we|our|us)(?![\w'’])", re.I)
V349C_PLAIN_ACH_PROOFS = {"ledger.chaos_runs", "ledger.overspend_test", "ledger.exactly_once_effect", "ledger.kubernetes_demo", "ledger.latency",
                          "ripple.evaluation", "pintos.tests", "fraud.graphsage_result", "fraud.edge_ablation_result"}


def v349c_plain_on() -> bool:
    return _v347_on(V349C_PLAIN_FLAG)


def v349c_tool_names(master: dict[str, Any]) -> list[str]:
    """Tool, library, language and platform names Jay's master lists (skills pools and project stacks)."""
    pool = (master.get("skills") or {}).get("supported_pool") or {}
    names = [str(x) for k in ("languages_databases", "frameworks_libraries", "tools_platforms") for x in pool.get(k, [])]
    for p in (master.get("projects") or {}).values():
        names += [str(x) for x in p.get("tech") or []]
    out = set()
    for n in names:
        for part in re.split(r"\s*[/(),]\s*", n):
            part = re.sub(r"\s+\d[\d.]*$", "", part.strip())
            if part and not re.fullmatch(r"(?i)only|live answers|answers|local", part) and part not in V349C_NOT_TOOLS:
                out.add(part)
    out |= {"REST", "RESTful", "Claude Code", "Claude", "GitHub Actions", "GitHub", "Kafka", "Kubernetes", "Docker", "AWS", "React", "Spring", "CrossRef", "OCR", "Tesseract",
            "WebSocket", "WebSockets", "Redis", "PostgreSQL", "MySQL", "MongoDB", "Django", "Python", "Java", "JavaScript", "GraphSAGE", "PyTorch", "LangGraph", "Streamlit"}
    return sorted(out, key=lambda x: (-len(x), x))


V349C_COMMON_TOOLS = ("Swift", "SwiftUI", "UIKit", "Xcode", "Objective-C", "Kotlin", "Rust", "Ruby on Rails", "Ruby", "PHP", "Scala", "Perl",
                      "C++", "C#", ".NET", "ASP.NET", "TypeScript", "Angular", "Vue.js", "Vue", "Svelte", "Next.js", "Node.js", "Hibernate",
                      "Terraform", "Ansible", "Jenkins", "CircleCI", "GCP", "Azure", "Snowflake", "Databricks", "Hadoop", "Airflow", "Tableau",
                      "Power BI", "Looker", "Salesforce", "ServiceNow", "Oracle", "Elasticsearch", "Cassandra", "DynamoDB", "BigQuery",
                      "Redshift", "Kinesis", "Figma", "Jira", "Selenium", "Cypress", "Playwright", "Jest", "JUnit", "pytest", "TensorFlow",
                      "Keras", "Hugging Face", "OpenAI", "LangChain", "LlamaIndex", "MATLAB", "Simulink", "LabVIEW", "Verilog", "VHDL", "ROS",
                      "Linux", "Unix", "PowerShell", "GraphQL", "gRPC", "Kafka", "Spark", "PySpark", "NumPy", "Pandas", "SQL", "NoSQL")   # matched case-sensitively


def v349c_tools_in(text: str, master: dict[str, Any]) -> list[str]:
    t = re.sub(r"\bGo Digital\b|\bData Maven\b", "", str(text))   # employers, not tools
    hit = []
    for n in v349c_tool_names(master):
        rx = r"(?<![\w#+.])" + re.escape(n) + r"(?![\w#+])"
        if re.search(rx, t, 0 if len(n) <= 2 else re.I):
            hit.append(n)
    for n in V349C_COMMON_TOOLS:   # v3.4.9c run 9: industry tools Jay does not list (Swift, Kotlin, ...)
        if n not in hit and re.search(r"(?<![\w#+.])" + re.escape(n) + r"(?![\w#+])", t):
            hit.append(n)
    return hit


def v349c_resp_plain(resp: str, master: dict[str, Any]) -> list[str]:
    """Why a closing responsibility cannot go into a plain letter ([] = it can)."""
    out = [f"tool: {x}" for x in v349c_tools_in(resp, master)]
    if re.search(r"\d", resp):
        out.append("digit")
    if V349C_PLAIN_PRON.search(resp):
        out.append("we / our / us")
    return out


def v349c_plain_words(paras: list[str]) -> int:
    return sum(len(p.split()) for p in paras)


def v349c_drop_tool_tail(text: str, master: dict[str, Any]) -> str:
    """Drop a phrase that only lists tools: '... applications with Java and Spring Boot.' -> '... applications.';
    '... code in Python/Django and JavaScript/React while owning ...' -> '... code while owning ...'."""
    names = v349c_tool_names(master)
    tool = "|".join(re.escape(n) for n in names)
    rx = re.compile(r"\s+(?:with|using|in|on|via|through)\s+((?:(?:" + tool + r")(?![\w#+])(?:\s*(?:,\s*(?:and|or)?|/|&|\band\b|\bor\b)\s*)?)+)(?=[\s.!?,;]|$)", re.I)
    out = text
    for m in reversed(list(rx.finditer(text))):
        seg = m.group(1)
        if not v349c_tools_in(seg, master) or re.search(r"(?:,|/|&|\band|\bor)\s*$", seg.strip()) and not seg.strip().endswith(tuple(names)):
            continue
        out = out[:m.start()] + out[m.end():]
    return re.sub(r"\s+([.,;!?])", r"\1", out)


def v349c_plain_api(text: str) -> str:
    """'REST APIs' -> 'APIs': the interface style is a technical name, the APIs are the work."""
    return re.sub(r"\bREST(?:ful)?\s+(?=APIs?\b|services?\b|endpoints?\b|interfaces?\b)", "", str(text))


V349C_DANGLING = {"end", "to", "and", "or", "of", "the", "a", "an", "with", "for", "in", "on", "at", "by", "from", "across", "including", "into", "such",
                  "as", "like", "via", "using", "our", "their", "its"}


def v349c_tool_rx(master: dict[str, Any]) -> str:
    """One tool name: Jay's names (case-insensitive above 2 characters) and the common industry names (exact case)."""
    names = sorted(set(v349c_tool_names(master)) | set(V349C_COMMON_TOOLS), key=lambda x: (-len(x), x))
    alt = [re.escape(n) if len(n) <= 2 or n in V349C_COMMON_TOOLS else "(?i:" + re.escape(n) + ")" for n in names]
    return r"(?<![\w#+.])(?:" + "|".join(alt) + r")(?![\w#+])"


def v349c_detool(text: str, master: dict[str, Any]) -> str:
    """Tool names out of a hook or responsibility, in plain words: '... with Java and Spring Boot' and 'using Python and
    SQL' leave, 'use Python' -> 'write code', a tool used as an adjective leaves ('React dashboards' -> 'dashboards')."""
    one = v349c_tool_rx(master)
    lst = one + r"(?:(?:\s*,\s*(?:and\s+|or\s+)?|\s*/\s*|\s*&\s*|\s+and\s+|\s+or\s+|\s+)" + one + r")*"
    t = v349c_plain_api(str(text))
    t = re.sub(r"\s+(?:with|using|in|on|via|through)\s+" + lst, "", t)
    t = re.sub(r"\b([Uu]se|[Uu]ses|[Uu]sing)\s+" + lst, lambda m: {"use": "write code", "uses": "writes code", "using": "writing code"}[m.group(1).lower()], t)
    t = re.sub(r"(?:\s*,\s*(?:and\s+|or\s+)?|\s+and\s+|\s+or\s+)" + lst + r"(?=[.,;!?]|$)", "", t)
    t = re.sub(lst + r"-(?:based|powered|driven|native)\s+", "", t)
    t = re.sub(lst + r"\s+(?=[a-z])", "", t)
    t = re.sub(r"\s+([.,;!?])", r"\1", re.sub(r"\s{2,}", " ", t)).strip()
    return t


def v349c_hook_ok(hook: str, plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> bool:
    """A plain hook: no tool / digit / we-our-us, no hackathon or certification word, and specific to the posting (the
    pipeline's hook test, or 3+ content words from one responsibility line)."""
    return (bool(hook) and not v349c_resp_plain(hook, master) and not V349C_PLAIN_BANNED.search(hook)
            and (bool(v347_hook_detail(hook, plan, raw_jd).get("ok")) or v349_from_one_line(hook, raw_jd)))


def v349c_plain_hook(plan: dict[str, Any], master: dict[str, Any], raw_jd: str) -> tuple[str, str]:
    """P1's connection to the posting: the plan's hook when it is plain (a closing list of tools dropped), else a posting
    responsibility."""
    cl = plan.get("cover_letter") if isinstance(plan.get("cover_letter"), dict) else {}
    hook0 = re.sub(r"\s+", " ", str((cl or {}).get("hook", "") or "")).strip()
    for h in (v349c_drop_tool_tail(v349c_plain_api(hook0), master), v349c_detool(hook0, master)) if hook0 else ():
        h = h if h.endswith((".", "!", "?")) else h + "."
        if v349c_hook_ok(h.rstrip(".!?"), plan, master, raw_jd):   # v3.4.9c run 9: plain and specific to the posting
            return h, "plan hook"
    used = str((plan.get("_v342_closing") or {}).get("responsibility") or "")
    for r, _line in closing_candidates(raw_jd, plan, master, ""):
        r = v349c_detool(r, master)
        last = (re.findall(r"[A-Za-z]+", r)[-1:] or [""])[0].lower()
        dangling = last in V349C_DANGLING and not r.lower().endswith("end to end")   # a cut phrase ("build features end")
        if r != used and len(r.split()) >= 3 and not dangling and v349c_hook_ok(r, plan, master, raw_jd):
            return f"I was drawn to this role because it involves the chance to {r}.", "posting responsibility"
    return "I was drawn to this role because of the work the posting describes.", "generic"


def v349c_another(sent: str, which: str) -> str:
    """'I also built LaunchOps, ...' -> 'Another project is LaunchOps, ...'; 'I also built fraud detection models ...' ->
    'In another project, I built fraud detection models ...' (no name or article to stand after 'is')."""
    m = re.match(r"I also built (\S+)", sent)
    if not m:
        return sent
    if m.group(1)[:1].isupper() or m.group(1) in ("a", "an"):
        return which[:1].upper() + which[1:] + " project is " + sent[len("I also built "):]
    return f"In {which} project, I built " + sent[len("I also built "):]


def v349c_plain_letter(plan: dict[str, Any], master: dict[str, Any], raw_jd: str, before: list[str]) -> dict[str, Any]:
    bank = (master.get("cover_letter_bank") or {}).get("plain_v349c") or {}
    app = plan.get("application", {})
    company, role = str(app.get("company", "")).strip(), str(app.get("role", "")).strip()
    joined = " ".join(before)
    intern = V348B_INTERN_NEW in joined
    reloc = _V347_RELOC in joined
    named = bool(company) and not company_is_placeholder(company)
    # P1: the run 7 letter's opening sentence (role and company; it already handles a missing role or company), then one
    # connection to the posting
    p0 = str(before[0]).strip() if before else ""
    m0 = re.match(r"I am applying for .*?\brole\b.*?[.!?](?=\s|$)", p0)   # "the Jr. Machine Learning ... role at X." is one sentence
    first = m0.group(0) if m0 else re.split(r"(?<=[.!?])\s+", p0)[0]
    if first.startswith("I am applying for "):
        p1 = first
    elif named and not re.search(r"(?<!\w)" + re.escape(company.rstrip(".")) + r"(?!\w)", role):
        p1 = f"I am applying for the {role} role at {company}."
    else:
        p1 = f"I am applying for the {role} role."
    hook, hook_src = v349c_plain_hook(plan, master, raw_jd)
    def assemble(closing: str, cl: dict[str, Any]) -> dict[str, Any]:
        pkey = str(cl.get("proof") or "")
        proof = (bank.get("proofs") or {}).get(pkey, "")
        proof_in = bool(proof) and proof in closing
        # P2: Experience (descriptive) and the rank #1 project (its result unless the closing proof is one)
        ek = str((plan.get("_v33_letter") or {}).get("experience") or "thesis_client")
        exps = bank.get("experience") or {}
        exp = exps.get(ek) or exps.get("thesis_client", "")
        rank = list(plan.get("ranking") or [])
        ach_proof = proof_in and pkey in V349C_PLAIN_ACH_PROOFS
        pid = rank[0] if rank else ""
        pj = ((bank.get("projects_plain") or {}) if ach_proof else (bank.get("projects") or {})).get(pid, "")
        p2 = [exp, pj]
        grad = V348B_INTERN_NEW if intern else V349C_PLAIN_FT
        p3 = [grad] + ([_V347_RELOC] if reloc else []) + [closing, V349C_PLAIN_THANKS]
        proof_pid = V349C_PROOF_PROJECT.get(pkey.split(".")[0], "") if proof_in else ""
        ai = ""
        if plan.get("_ai_coding_tools") and "ripple" in rank and pkey != "ripple.claude_code_dev":   # v3.4.9c run 9: the posting asks for AI coding tools
            ai = V349C_PLAIN_AI_OWN if pid == "ripple" else V349C_PLAIN_AI
        fill: list[str] = []   # project descriptions added to reach 120 words (no result)
        paras = lambda: [f"{p1} {hook}", " ".join(x for x in p2 + ([ai] if ai else []) + fill if x), " ".join(x for x in p3 if x)]
        for k in (1, 2):   # v3.4.9c run 9: the second, then the third project before the courtesy sentence
            if v349c_plain_words(paras()) < V349C_PLAIN_MIN and len(rank) > k and rank[k] != proof_pid and not (ai and rank[k] == "ripple"):
                fill.append(v349c_another((bank.get("projects_plain") or {}).get(rank[k], ""), "another" if not fill else "a third"))
        if v349c_plain_words(paras()) < V349C_PLAIN_MIN:
            p3.insert(-1, V349C_PLAIN_PAD)
        if v349c_plain_words(paras()) > V349C_PLAIN_MAX and ek == "thesis_ops":
            p2[0] = exps.get("thesis_ops_short", exp)
        while v349c_plain_words(paras()) > V349C_PLAIN_MAX and fill:
            fill.pop()
        if v349c_plain_words(paras()) > V349C_PLAIN_MAX and ai == V349C_PLAIN_AI:
            ai = V349C_PLAIN_AI_SHORT
        if v349c_plain_words(paras()) > V349C_PLAIN_MAX:
            p3.remove(V349C_PLAIN_THANKS)
        out = [_v343_fix_dots(re.sub(r"\s+", " ", x).strip()) for x in paras()]
        return {"paragraphs": out, "closing": closing, "closing_info": dict(cl, text=closing), "proof_key": pkey if proof_in else "", "experience": ek, "project": pid,
                "achievements": int(bool(pj) and not ach_proof) + int(ach_proof), "hook_source": hook_src,
                "exempt": [x for x in (role, company) if x], "internship": intern, "relocation": reloc, "family": bool(cl.get("family"))}

    if _v347_on(V349C_CLOSING_FLAG):   # v3.4.9c fix1: the grounded closing, checked against this plain letter's own body
        ref = "your client" if "your client" in joined else ("your team" if not named else company)

        def accept(sent: str, info: dict[str, Any]) -> bool:
            res = assemble(sent, info)
            rest = " ".join(res["paragraphs"]).replace(sent, " ")
            return not closing_repeats_letter(str(info.get("_proof") or "") or sent, rest)
        sent, cl = v349c_grounded_closing(plan, master, raw_jd, ref, joined + " " + hook, 30, plain=True, accept=accept)
        return assemble(sent, cl)
    # closing: the run 7 closing (same responsibility, proof and connector), its proof in plain words
    cl = dict(plan.get("_v342_closing") or {})
    if cl.get("responsibility") and v349c_resp_plain(str(cl["responsibility"]), master):
        ref = "your client" if "your client" in joined else ("your team" if not named else company)
        V349C_CTX["plain_closing"] = True
        try:
            s_, inf = _v344_closing(plan, master, raw_jd, ref, joined, budget=30, exclude_resp={str(cl["responsibility"])})
        finally:
            V349C_CTX["plain_closing"] = False
        setaside = [{"responsibility": cl["responsibility"], "proof": cl.get("proof"), "unsupported": v349c_resp_plain(str(cl["responsibility"]), master)}]
        cl = dict(inf, text=_v343_fix_dots(s_), source="auto", plain_set_aside=setaside)
    closing = str(cl.get("text") or "")
    pkey, old_proof = str(cl.get("proof") or ""), str(cl.get("_proof") or "")
    proof = (bank.get("proofs") or {}).get(pkey, "")
    if old_proof and old_proof in closing:
        closing = closing.replace(old_proof, proof) if proof else closing
    elif pkey and proof and ", " in closing:
        head, tail = closing.split(", ", 1)
        conn = str(cl.get("connector") or "")
        closing = f"{head}, {conn} {proof}." if conn and tail.startswith(conn) else closing
    closing = _v343_fix_dots(closing)
    return assemble(closing, cl)


def v349c_plain_problems(paras: list[str], plan: dict[str, Any], master: dict[str, Any], info: dict[str, Any]) -> list[str]:
    out = []
    if len(paras) != 3:
        out.append(f"{len(paras)} paragraphs (want 3)")
    n = v349c_plain_words(paras)
    if not V349C_PLAIN_MIN <= n <= V349C_PLAIN_MAX:
        out.append(f"{n} words (want {V349C_PLAIN_MIN}-{V349C_PLAIN_MAX})")
    text = " ".join(paras)
    app = plan.get("application", {})
    role, company = str(app.get("role", "")), str(app.get("company", ""))
    if role and not company_is_placeholder(role) and role not in text:
        out.append("role missing")
    if company and not company_is_placeholder(company) and company.rstrip(".") not in text:
        out.append("company missing")
    grad = V348B_INTERN_NEW if info.get("internship") else V349C_PLAIN_FT
    if grad not in text:
        out.append("graduation / start sentence missing")
    rest = text.replace(grad, " ")
    for x in info.get("exempt") or []:
        if x:
            rest = rest.replace(x, " ")
    if re.search(r"\d", rest):
        out.append("digit outside the graduation sentence: " + ", ".join(sorted(set(re.findall(r"\S*\d\S*", rest))))[:120])
    tools = v349c_tools_in(rest, master)
    if tools:
        out.append("tool names: " + ", ".join(tools))
    if V349C_PLAIN_BANNED.search(text):
        out.append("hackathon / certification wording")
    if V349C_PLAIN_PRON.search(rest):
        out.append("we / our / us")
    if int(info.get("achievements", 0)) > 1:
        out.append("more than one concrete achievement")
    if not info.get("proof_key") and not info.get("family"):
        out.append("closing without a proof")
    if not info.get("hook_source") or info.get("hook_source") == "generic":   # v3.4.9c run 9: the hook must be specific
        out.append("no specific connection to the posting")
    return out


V349C_PLAIN_DATA_ML_EXP = {"godigital", "hein", "hein_parallel", "hein_health", "thesis_iot"}


def v349c_plain_structure(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    """The plain letter's versions of the two-paragraph count and the data / ML Experience anchor checks."""
    cover = (plan.get("_v349c_plain") or {}).get("paragraphs") or []
    out = []
    if not isinstance(cover, list) or len(cover) != 3 or not all(isinstance(x, str) and x.strip() for x in cover):
        out.append(fail("cover_letter_paragraph_count", "cover_letter_paragraphs", len(cover) if isinstance(cover, list) else type(cover).__name__, 3,
                        "Use exactly three plain paragraphs (letters_plain_v349c)."))
        out[-1]["type"] = "v349c_plain_paragraph_count"
    if _is_data_ml_role(plan):
        ek = str((plan.get("_v349c_plain") or {}).get("experience") or "")
        sent = ((master.get("cover_letter_bank") or {}).get("plain_v349c") or {}).get("experience", {}).get(ek, "")
        if ek not in V349C_PLAIN_DATA_ML_EXP or not sent or len(cover) < 2 or sent not in cover[1]:
            out.append(fail("v349c_plain_data_ml_experience", "cover_letter_paragraphs[1]", cover[1] if len(cover) > 1 else "",
                            "the plain Go Digital, HeinOnline or Thesis device-feed Experience sentence",
                            "For data/ML roles, paragraph 2 anchors to one fixed Experience item; projects may be mentioned additionally."))
    return out


# ===========================================================================
# v3.4.9c fix1 (2026-10-23): targeted repair. Fix 1, closing_v349c: v349c_grounded_closing tries every posting
# responsibility (and the two halves of a coordinated one) against every on-page proof; it keeps the first pair whose
# proof evidence shows every specific word (v349c_closing_unsupported), whose wording is a real responsibility
# (v349c_meaningful) and whose proof does not repeat the letter. Otherwise the role-family closing, with an on-page proof
# that shows the family claim when one exists. Fix 2: compose_bank_cover_letter keeps the run 6 letter (closing_v349c
# off) in the plan for page decisions; the grounded closing goes only into the written letter.
# ===========================================================================
V349C_VAGUE = {"best", "results", "great", "amazing", "awesome", "impactful", "innovative", "cutting-edge", "breakthrough", "world-class",
               "excellent", "exceptional", "outstanding", "expected", "things", "stuff", "life", "needs", "value", "success", "goals",
               "impact", "mission", "vision", "ideas", "opportunities", "initiatives", "efforts", "part", "takes", "difference", "future",
               "excellence", "passion", "growth", "career", "journey", "culture", "environment", "fun", "others", "everything",
               "anything", "something", "responsibilities", "tasks", "duties", "assignments", "custom", "tailored", "key", "various",
               "modern", "latest", "next-generation", "state-of-the-art", "transformational", "meaningful", "exciting"}
V349C_AUX = {"are", "is", "be", "was", "were", "will", "can", "should", "must", "may", "been", "being"}


def v349c_meaningful(c: str) -> bool:
    """A real responsibility, not a vague fragment: at least one specific content word after the leading verbs (not
    generic, not vague), no auxiliary verb straight after them ("engineer are expected") and no question word ("build
    or integrate, how")."""
    words = [w.lower().strip("-/") for w in re.findall(r"[A-Za-z][A-Za-z0-9+#/-]*", c)]
    if any(w in ("how", "what", "why", "whatever", "whether") for w in words):
        return False
    toks = c.split()
    i = 0
    while i < len(toks) and (_v344_base_verb(toks[i]) or toks[i].lower().rstrip(",") in ("and", "or", "help")):
        i += 1
    if i < len(toks) and toks[i].lower().rstrip(",") in V349C_AUX:
        return False
    spec = [p for w in words[i:] for p in re.split(r"[-/]", w)
            if p and p not in V349C_GENERIC and p not in V349C_VAGUE and p not in _V344_STOP and p not in V349C_COMPOUND_TAIL and len(p) >= 3]
    return bool(spec)


def v349c_splits(c: str) -> list[tuple[str, bool]]:
    """The responsibility and, for "X and <verb> Y", each half that is a responsibility of its own ((text, is_head))."""
    out = [(c, False)]
    for mm in re.finditer(r",? and ", c):
        head, tail = c[:mm.start()].strip().rstrip(","), c[mm.end():].strip()
        if tail.split() and _v344_base_verb(tail.split()[0]):
            if len(head.split()) >= 3:
                out.append((head, True))
            if len(tail.split()) >= 3:
                out.append((tail, False))
    return list(dict.fromkeys(out))


def v349c_kind_of(c: str, eid: str) -> str:
    return next((k for k, rx, eids in _V344_KINDS if eid in eids and rx.search(c)), "")


def v349c_closing_pool(plan: dict[str, Any], master: dict[str, Any], body: str, plain: bool) -> list[str]:
    """On-page proofs: every project on the page (plain letters) or the projects the letter names, and Experience."""
    pool = _v344_proof_pool(plan, master, "" if plain else body)
    if _v347_on("proof_on_page_v349"):
        on_page = v349_page_evidence(plan, master)
        pool = [e for e in pool if v349_proof_eid(e) in on_page]
    return pool


def v349c_support_map(c: str, eid: str, kind: str, master: dict[str, Any]) -> dict[str, str]:
    """For the report: each specific word of the responsibility and the evidence text that shows it."""
    cor = v349c_proof_corpus(eid, master)
    rx = next((x[1] for x in _V344_KINDS if x[0] == kind), None)
    out = {}
    for mm in re.finditer(r"[A-Za-z][A-Za-z0-9+#/-]*", c):
        w = mm.group(0).lower().strip("-/")
        if w in V349C_GENERIC or len(w) < 2:
            continue
        if rx is not None and rx.search(mm.group(0)):
            out[w] = f"proof kind {kind}"
            continue
        n = w.split("-")[0] if "-" in w else w
        n = n[:-1] if n.endswith("s") and not n.endswith("ss") and len(n) > 3 else n
        hit = re.search(r"(?<![a-z])" + re.escape(n[:5] if len(n) > 5 else n), cor)
        out[w] = cor[max(0, hit.start() - 30):hit.end() + 40].strip() if hit else "(spelling list)"
    return out


def v349c_grounded_closing(plan: dict[str, Any], master: dict[str, Any], raw_jd: str, company_ref: str, body: str, budget: int = 30,
                           plain: bool = False, accept=None, exclude: set[str] | None = None) -> tuple[str, dict[str, Any]]:
    bank = master.get("cover_letter_bank", {})
    proofs = bank.get("closing_proofs", {})
    ptext = (lambda k: (bank.get("plain_v349c") or {}).get("proofs", {}).get(k, "")) if plain else (lambda k: str(proofs.get(k, "") or ""))
    where = _v344_where(company_ref)
    low = str(body).lower()
    pool = v349c_closing_pool(plan, master, body, plain)
    co = company_ref if where.startswith("at ") else ""
    tried, seen = 0, set()
    for resp, line in closing_candidates(raw_jd, plan, master, body):
        for cut in _v344_cuts(resp):
            for c, head in v349c_splits(cut):
                if c in seen or (exclude and c in exclude):
                    continue
                seen.add(c)
                if not _v344_resp_ok(c, plan, master, low) or (not head and not _v345_clause_end_ok(c, line)) or not v349c_meaningful(c):
                    continue
                if plain and v349c_resp_plain(c, master):
                    continue
                tried += 1
                order = [e for k in _v344_kind_order(c) for e in k[2]] + pool
                for eid in dict.fromkeys(e for e in order if e in pool):
                    pt = ptext(eid)
                    if not pt:
                        continue
                    kind = v349c_kind_of(c, eid)
                    if v349c_closing_unsupported(c, eid, "", master):   # every specific word in the proof's own evidence (no kind shortcut)
                        continue
                    conn = _v344_connector(c, company_ref, pt)
                    sent = _v343_fix_dots(f"I want to {c} {where}, {conn} {pt}.")
                    if len(sent.split()) > min(budget, 30) or closing_problems(sent, co) or (accept is None and closing_repeats_letter(pt, body)):
                        continue   # with accept (plain letters) the repeat check runs on the written letter, not on body
                    info = {"rule": "v3.4.9c fix1", "responsibility": c, "jd_line": line, "proof": eid, "proof_kind": kind, "_proof": pt, "connector": conn,
                            "closing_v349c": {"selector": "every on-page proof", "candidates_tried": tried, "evidence": v349c_support_map(c, eid, "", master)}}
                    if accept is None or accept(sent, info):
                        return sent, info
    # no supported specific closing: the role-family closing, with an on-page proof that shows its claim when one exists
    fam = str(plan.get("role_family", ""))
    fc = bank.get("family_closing", {})
    tmpl = fc.get(fam, "build dependable, well-tested software with the team at {company}")
    if v349c_claim_in_master(re.sub(r"\s+", " ", tmpl.replace("{company}'s", " ").replace("{company}", " ")), master):
        tmpl = fc.get("general_swe", "build dependable, well-tested software with the team at {company}")
    poss = company_ref + ("'" if company_ref.endswith("s") else "'s")
    what = tmpl.replace("{company}'s", poss).replace("{company}", company_ref)
    if company_ref in ("your team", "your client"):
        what = what.replace("with the team at your team", "with your team").replace("at your client", "for your client")
    general = fc.get("general_swe", "build dependable, well-tested software with the team at {company}")
    for tm in dict.fromkeys((tmpl, general)):   # the family's claim, then the general claim, each only with a proof that shows it
        wh = tm.replace("{company}'s", poss).replace("{company}", company_ref)
        if company_ref in ("your team", "your client"):
            wh = wh.replace("with the team at your team", "with your team").replace("at your client", "for your client")
        claim = re.sub(r"\s+", " ", tm.replace("{company}'s", " ").replace("{company}", " ")).strip()
        order = [e for k in _v344_kind_order(claim) for e in k[2]] + pool
        for eid in dict.fromkeys(e for e in order if e in pool):
            pt = ptext(eid)
            kind = v349c_kind_of(claim, eid)
            bad = [w for w in v349c_closing_unsupported(re.sub(r"(?i)\bmachine learning\b", "ML", claim), eid, "", master) if w not in V349C_FAMILY_QUALITY | {"dependable"}]
            if not pt or bad:
                continue
            conn = _v344_connector(wh, company_ref, pt)
            sent = _v343_fix_dots(f"I want to {wh}, {conn} {pt}.")
            if len(sent.split()) > min(budget, 30) or closing_problems(sent, co) or (accept is None and closing_repeats_letter(pt, body)):
                continue
            info = {"rule": "v3.4.9c fix1", "responsibility": "", "proof": eid, "proof_kind": kind, "_proof": pt, "connector": conn, "family": True,
                    "closing_v349c": {"selector": "role-family (no supported responsibility)" + ("" if tm == tmpl else ", general claim"), "candidates_tried": tried,
                                      "evidence": v349c_support_map(claim, eid, "", master)}}
            if accept is None or accept(sent, info):
                return sent, info
    sent = _v343_fix_dots(f"I want to {what}.")
    return sent, {"rule": "v3.4.9c fix1", "responsibility": "", "proof": "", "proof_kind": "", "_proof": "", "connector": _v344_connector(what, company_ref),
                  "family": True, "closing_v349c": {"selector": "role-family, no proof shows its claim", "candidates_tried": tried}}


V349B_FLAGS = ("bank_format_v349b", "format_letter_v349b", "bold_results_v349b", "skills_cap5_v349b", "letter_trims_v349b")
V349B_A4_TEMPLATE_SHA256 = "dc2817783de41f8fb43daa252bb134334a074d87230de6182d06f0bf89544dfb"   # the v3.4.9a template
V349B_FORMAT_PAIRS = (   # (v3.4.9a A4 text, shipped Letter text)
    ("\\documentclass[10pt, a4paper]{article}", "\\documentclass[10pt, letterpaper]{article}"),
    ("\\usepackage[T1]{fontenc}\n", "\\usepackage[T1]{fontenc}\n\\usepackage{mathptmx}\n"),
    ("\\newcommand{\\sectiondivider}{\\vspace{0.30em}\\hrule\\vspace{0.4em}}", "\\newcommand{\\sectiondivider}{\\vspace{0.2em}\\hrule\\vspace{0.25em}}"),
    ("\\newcommand{\\rolegap}{\\vspace{3.5pt}}", "\\newcommand{\\rolegap}{\\vspace{3pt}}"),
    ("\t\t\\href{mailto:jayadmit456@gmail.com}{jayadmit456@gmail.com} | +1(716)303-9924 | NY, US | \\href{https://jay-portfolio-black-eight.vercel.app/}{Portfolio} | \\href{https://www.linkedin.com/in/jaypathare3}{LinkedIn} | \\href{https://github.com/Jaypath456}{GitHub} \\\\",
     "\t\t\\href{mailto:jayadmit456@gmail.com}{jayadmit456@gmail.com} | +1(716)303-9924 | NY, US | \\href{https://www.linkedin.com/in/jaypathare3}{linkedin.com/in/jaypathare3} | \\href{https://github.com/Jaypath456}{github.com/Jaypath456} \\\\"),
)
V349B_AWARD_FIRST = "\t\t\\item \\textbf{1st Place, ACV Auctions + Copart Challenge} $|$ AI for Good Hackathon Design Challenge, UB \\hfill \\textit{October 2026}\n"
V349B_AWARD_AWS = "\t\t\\item \\textbf{AWS Certified Cloud Practitioner} \\hfill \\textit{July 2024}\n"
V349B_INTERVIEW_LONG = "Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds over their first 3 weeks and introducing them to the production projects and tech stack."
V349B_INTERVIEW_SHORT = "Interviewed about 20 student candidates and onboarded the hires through weekly coding rounds over their first 3 weeks."
V349B_TRIM_PAIRS = (   # (v3.4.9a text, shipped text)
    ("\t\t\\item " + V349B_INTERVIEW_LONG + "\n", "\t\t\\item " + V349B_INTERVIEW_SHORT + "\n"),
    (V349B_AWARD_FIRST + V349B_AWARD_AWS, V349B_AWARD_FIRST),
)
V349B_CTX: dict[str, Any] = {"skill_chars": 104}


def v349b_on(name: str) -> bool:
    return _v347_on(name)


def v349b_letter_bank() -> bool:
    """New bank wordings are Letter wordings: used only with bank_format_v349b and format_letter_v349b both on."""
    return v349b_on("bank_format_v349b") and v349b_on("format_letter_v349b")


def v349b_effective_template(text: str) -> str:
    """The template a build uses: the shipped (Letter) file, with each switched-off v3.4.9b change put back to its
    v3.4.9a text. Idempotent (a v3.4.9a template comes back unchanged)."""
    t = str(text)
    if not v349c_page_on():   # v3.4.9c run 2: page_v349c off puts the run 1 template blocks back
        for old, new in V349C_PAGE_PAIRS:
            if new in t and old not in t and not ("\\section*{CERTIFICATIONS" in old and "\\section*{CERTIFICATIONS" in t):
                t = t.replace(new, old, 1)
    if not v349c_thesis_on():   # v3.4.9c run 3: thesis_v349c off puts the v3.4.9b one-line Interviewed bullet back
        t = t.replace("\t\t\\item " + V349C_MENTOR + "\n", "\t\t\\item " + V349B_INTERVIEW_SHORT + "\n", 1)
    if not v349b_on("letter_trims_v349b"):
        for old, new in V349B_TRIM_PAIRS:
            if new in t and (old not in t or old in new):
                t = t.replace(new, old, 1)
    if not v349b_on("format_letter_v349b"):
        for old, new in V349B_FORMAT_PAIRS:
            if new in t and (old not in t or old in new):
                t = t.replace(new, old, 1)
    if not v349c_on():   # v3.4.9c: data_v349c off puts the v3.4.9b Education date back
        t = t.replace(V349C_EDU_NEW, V348B_EDU_NEW, 1)
    return t


def v349b_template_sha() -> str:
    """The template hash that keys the Skills fit (skills_text_hash): the v3.4.9a one with format_letter_v349b off."""
    if not v349c_on():   # v3.4.9c: data_v349c off keys the cache as v3.4.9b did
        return V349C_OLD_TEMPLATE_SHA256 if v349b_on("format_letter_v349b") else V349B_A4_TEMPLATE_SHA256
    if not v349c_page_on():   # v3.4.9c run 2: page_v349c off keys the cache as run 1 did
        return V349C_RUN1_TEMPLATE_SHA256 if v349b_on("format_letter_v349b") else V349B_A4_TEMPLATE_SHA256
    if not v349c_thesis_on():   # v3.4.9c run 3: thesis_v349c off keys the cache as run 2 did
        return V349C_RUN2_TEMPLATE_SHA256 if v349b_on("format_letter_v349b") else V349B_A4_TEMPLATE_SHA256
    return EXPECTED_TEMPLATE_SHA256 if v349b_on("format_letter_v349b") else V349B_A4_TEMPLATE_SHA256


def v349b_layout(master: dict[str, Any]) -> None:
    """Run-time layout for the switched-on v3.4.9b changes (master.json layout_v349b); master.json itself is unchanged."""
    lay = master.get("layout_v349b") or {}
    lr = master.get("layout_rules") or {}
    V349B_CTX["skill_chars"] = 104
    V349B_CTX["skills"] = {}
    if not lay or master.get("_v349b_applied"):
        return
    master["_v349b_applied"] = True
    if v349b_on("format_letter_v349b") or v349b_on("skills_cap5_v349b"):
        master["_v349b_layout_9a"] = deepcopy(lr)
    if v349b_on("format_letter_v349b"):
        f = lay.get("format_letter_v349b") or {}
        lr["paper"] = f.get("paper", "letterpaper")
        lr["rolegap_pt"] = f.get("rolegap_pt", lr.get("rolegap_pt"))
        lr["project_second_line_min_fill"] = f.get("project_second_line_min_fill", lr.get("project_second_line_min_fill"))
        V349B_CTX["skill_chars"] = int(f.get("skill_line_chars_estimate", 104))
    if v349b_on("skills_cap5_v349b"):
        s = lay.get("skills_cap5_v349b") or {}
        lr["skills_rendered_lines_max"] = int(s.get("skills_rendered_lines_max", 5))
        lr["skills_category_line_limits"] = dict(s.get("skills_category_line_limits") or {})


# --- bold_results_v349b ------------------------------------------------------------------------------------------
V349B_STOP = set("""of and or with with to in for by against from on at so that the a an into across over per through while plus
using as than via within under after before without its their is are was were then when where which who each""".split())
V349B_NOT_AFTER = re.compile(r"\b(?:every|first|last|within|per|after|before|until|capped at|up to|a cap of)\s+$|[\w.\-/]$", re.I)
V349B_NUM = re.compile(
    r"(?P<pre>(?:(?:about|over|nearly|almost|exactly|roughly|approximately|more than)\s+)|\$\\sim\$\s*|\\\$)?"
    r"(?P<num>\d+(?:[.,]\d+)*)(?P<suf>(?:k\+|K\+|\+|k|K|M|x|ms|s|h|GB|MB|TB)?(?:\\%\+?)?)"
    r"(?P<of>\s+of\s+\d+(?:[.,]\d+)*(?:\\%)?)?(?![\w\-])")
V349B_WORD = re.compile(r" ([A-Za-z][A-Za-z'\-]*)")


def v349b_result_spans(tex_text: str, max_spans: int = 2, max_words: int = 3) -> list[tuple[int, int]]:
    """(start, end) spans to bold in one escaped bullet: a number that reads as a result (not a year, a model or
    version name, an interval such as "every 5 minutes" / "first 3 weeks", or a cap such as "capped at 25") plus up
    to 3 following words (stopping at a function word or punctuation). Result-marked numbers (%, +, k, "N of N",
    about / over / ~ / $) first, then the rest in page order; at most max_spans."""
    s = str(tex_text)
    cands = []
    for m in V349B_NUM.finditer(s):
        a = m.start()
        if V349B_NOT_AFTER.search(s[:a]):
            continue
        n = m.group("num")
        if re.fullmatch(r"(?:19|20)\d\d", n) and not m.group("suf") and not m.group("of"):
            continue
        b = m.end()
        k = 0
        while k < max_words:
            w = V349B_WORD.match(s, b)
            if not w or w.group(1).lower() in V349B_STOP:
                break
            b = w.end(); k += 1
        marked = bool(m.group("pre") or m.group("of") or re.search(r"\\%|\+|k|K|x", m.group("suf") or ""))
        if not marked and re.search(r"\bonly\s+$", s[:a], re.I):   # "funded for only 50" is a setup, not a result
            continue
        cands.append((0 if marked else 1, a, a, b))
    pick = sorted(cands)[:max_spans]
    return sorted((a, b) for _p, _o, a, b in pick)


def v349b_bold_text(tex_text: str) -> str:
    s = str(tex_text)
    if "\\textbf{" in s or "\\href{" in s:
        return s
    out, last = [], 0
    for a, b in v349b_result_spans(s):
        out.append(s[last:a] + "\\textbf{" + s[a:b] + "}")
        last = b
    return "".join(out) + s[last:]


V349B_ITEM = re.compile(r"^(\s*\\item )(.*)$")
V349B_SECTION = re.compile(r"\\section\*\{([^}]*)\}")


def v349b_bold_tex(tex: str) -> str:
    """Bold results in the Experience and project bullets of a resume .tex; headings, dates, Skills, links, the
    education and awards lines are never touched."""
    sec, out = "", []
    for line in str(tex).split("\n"):
        m = V349B_SECTION.search(line)
        if m:
            sec = m.group(1)
        if sec in ("EXPERIENCE", "PERSONAL PROJECTS"):
            mi = V349B_ITEM.match(line)
            if mi and not line.lstrip().startswith("%"):
                line = mi.group(1) + v349b_bold_text(mi.group(2))
        out.append(line)
    return "\n".join(out)


V349B_BOLD_SPAN = re.compile(r"\\textbf\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}")


def v349b_strip_bold(tex: str) -> str:
    """Inverse of v349b_bold_tex: removes \\textbf{...} inside Experience / project bullet lines only."""
    sec, out = "", []
    for line in str(tex).split("\n"):
        m = V349B_SECTION.search(line)
        if m:
            sec = m.group(1)
        if sec in ("EXPERIENCE", "PERSONAL PROJECTS") and V349B_ITEM.match(line):
            line = V349B_BOLD_SPAN.sub(lambda x: x.group(1), line)
        out.append(line)
    return "\n".join(out)


# --- skills_cap5_v349b -------------------------------------------------------------------------------------------
def v349b_skills_cap5(states: list[dict[str, Any]], plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    """Skills in at most 5 lines, one per category. When the smallest state's category runs to 2 lines (Letter / Times
    estimate), items leave it from the end in this order: filler (not named by the posting, not required, not a page
    technology); JD-named skills that are not must / high priority and that the page already shows in a bullet or
    heading; other such JD-named skills (they are listed in the existing "Skills full" note). Must / high priority
    terms, required ATS terms and page technologies always stay: when they alone need a second line, that category
    may use the line of a category the page does not show (AI/ML without its line), so the Skills block never passes
    5 lines (logged as _v349b_skills_two_line). The same items leave every larger state. _v341_tight_unresolved is set
    only if the 5-line block still cannot hold them."""
    if not _v347_on("skills_cap5_v349b") or not states or _V348C_S.get("inner"):
        return states
    base = states[0].setdefault("skills", {})
    matched = {str(x) for x in states[0].get("matched_tools", [])}
    pool = lambda c: [x for x in base.get(c, []) if x in matched] if c == "tools" else list(base.get(c, []))
    est = lambda c: _v341_est_lines(c, pool(c))
    over = [c for c in base if est(c) >= 2]
    if not over:
        plan["_v341_tight_unresolved"] = False
        return states
    cf = lambda x: str(x).casefold()
    header = resolved_project_header_tech(master, plan["ranking"], plan)
    page = _v33_page_text(plan, master, header)
    hard = {cf(x) for x in states[0].get("required_ats_terms", [])} | {cf(x) for x in selected_technology_skills(plan, master, header)}
    keep = hard | {cf(x) for x in _high_priority_skill_displays(plan, master)}
    named = {cf(x) for x in (globals().get("_V33_SKILLS") or {}).get("jd_named", [])} | {cf(x) for x in matched}
    tiers = [lambda x: cf(x) not in named | keep,
             lambda x: cf(x) in named and cf(x) not in keep and _v33_shown(x, page, master),
             lambda x: cf(x) in named and cf(x) not in keep,
             lambda x: cf(x) not in hard and v349b_ats_off_skills(x, plan, page)]
    dropped = []
    for tier in tiers:
        for c in over:
            while est(c) >= 2:
                cand = [x for x in reversed(pool(c)) if tier(x)]
                if not cand:
                    break
                base[c] = [y for y in base[c] if y != cand[0]]
                matched.discard(cand[0])
                dropped.append(cand[0])
    for st in states:
        for c, vals in st.get("skills", {}).items():
            st["skills"][c] = [x for x in vals if x not in dropped]
        st["matched_tools"] = [x for x in st.get("matched_tools", []) if x not in dropped]
    if dropped:
        plan["_v349b_skills_dropped"] = list(dict.fromkeys(list(plan.get("_v349b_skills_dropped") or []) + dropped))
    lim = master["layout_rules"]["skills_category_line_limits"]
    still = [c for c in base if est(c) >= 2]
    if still and sum(min(est(c), 2) if c in still else 1 for c in base if pool(c) or c == "tools") <= int(master["layout_rules"]["skills_rendered_lines_max"]) \
            and all(est(c) <= 2 for c in still) and "tools" not in still:
        for c in still:
            lim[c] = 2
        plan["_v349b_skills_two_line"] = sorted(set(plan.get("_v349b_skills_two_line") or []) | set(still))
        still = []
    if still and v349c_layout_on():   # v3.4.9c run 4 L3: items the posting does not name leave before a 6th line is used
        for c in still:
            while est(c) >= 2:
                cand = [x for x in reversed(pool(c)) if cf(x) not in named]
                if not cand:
                    break
                base[c] = [y for y in base[c] if y != cand[0]]
                matched.discard(cand[0])
                dropped.append(cand[0])
        for st in states:
            for c2, vals in st.get("skills", {}).items():
                st["skills"][c2] = [x for x in vals if x not in dropped]
        still = [c for c in still if est(c) >= 2]
        if dropped:
            plan["_v349b_skills_dropped"] = list(dict.fromkeys(list(plan.get("_v349b_skills_dropped") or []) + dropped))
    if not still:
        pass
    elif still and all(est(c) <= 2 for c in still) and "tools" not in still and len(still) == 1:
        # required / must / high terms that the bullets do not show cannot leave Skills (ATS check): this page keeps a
        # 6th line for that one category (logged as _v349b_skills_six)
        lim[still[0]] = 2
        master["layout_rules"]["skills_rendered_lines_max"] = int(((master.get("layout_v349b") or {}).get("skills_cap5_v349b") or {}).get("skills_rendered_lines_max", 5)) + 1
        plan["_v349b_skills_two_line"] = sorted(set(plan.get("_v349b_skills_two_line") or []) | set(still))
        plan["_v349b_skills_six"] = still[0]
        still = []
    plan["_v341_tight_unresolved"] = bool(still)
    V349B_CTX["skills"] = {"dropped": list(plan.get("_v349b_skills_dropped") or []), "two_line": list(plan.get("_v349b_skills_two_line") or []), "unresolved": still,
                           "six": plan.get("_v349b_skills_six")}
    return states

def v349b_ats_off_skills(skill: str, plan: dict[str, Any], page: str) -> bool:
    """A must / high Skills item may leave Skills only when every posting requirement it answers is still found (term,
    verbatim or alias, as validate_ats_coverage reads it) in the page's bullets, Experience or project headings."""
    reqs = [r for r in plan.get("jd_requirements") or [] if isinstance(r, dict)]
    hit = [r for r in reqs if any(str(n).casefold() == str(skill).casefold() for n in [r.get("term"), r.get("verbatim")] + list(r.get("aliases") or []) if n)]
    text = str(page) + "\n" + str(plan.get("tagline_text") or "")
    return bool(hit) and all(any(boundary_contains_plural(text, str(n)) for n in [r.get("verbatim"), r.get("term")] + list(r.get("aliases") or []) if n) for r in hit)


def v349b_states_keep_9a_pick(plan: dict[str, Any], master: dict[str, Any]) -> list[dict[str, Any]]:
    """The tight-Skills bullet re-pick (_v341_tight_unresolved, v3.4.1) decides on the v3.4.9a page (A4 estimate,
    7-line Skills), so the Letter page carries the same bullets as v3.4.9a; the Skills states themselves follow the
    Letter layout (5 lines). Only the re-pick signal is taken from the v3.4.9a computation."""
    m9 = dict(master)
    m9["layout_rules"] = master["_v349b_layout_9a"]
    probe = deepcopy(plan)
    saved_flags, saved_chars = dict(_V347_FLAGS), V349B_CTX.get("skill_chars", 104)
    V349B_CTX["ref"] = True
    try:
        _V347_FLAGS["skills_cap5_v349b"] = False
        V349B_CTX["skill_chars"] = 104
        build_skill_states(probe, m9)
        ref = bool(probe.get("_v341_tight_unresolved"))
        _V347_FLAGS.clear(); _V347_FLAGS.update(saved_flags)
        V349B_CTX["skill_chars"] = saved_chars
        states = build_skill_states(plan, master)
    finally:
        V349B_CTX["ref"] = False
        _V347_FLAGS.clear(); _V347_FLAGS.update(saved_flags)
        V349B_CTX["skill_chars"] = saved_chars
    plan["_v349b_letter_tight_unresolved"] = bool(plan.get("_v341_tight_unresolved"))
    plan["_v341_tight_unresolved"] = ref
    return states


def v349b_post_run(rep: dict[str, Any], out_dir: Path, argv: list[str]) -> None:
    """report.json log of the v3.4.9b format (only with a v3.4.9b flag on, so flags-off reports are unchanged)."""
    on = [k for k in V349B_FLAGS if v349b_on(k)]
    if not on or rep.get("skip"):
        return
    info: dict[str, Any] = {"flags_on": on}
    try:
        q = json.loads((out_dir / "quality_v33.json").read_text(encoding="utf-8"))
        info["free_space_pt"] = q.get("free_space_pt")
        info["skills_rendered_lines"] = q.get("skills_rendered_lines")
    except Exception:
        pass
    sk = V349B_CTX.get("skills") or {}
    if sk.get("dropped"):
        info["skills_left_out"] = sk["dropped"]
    if sk.get("two_line"):
        info["skills_two_line_categories"] = sk["two_line"]
    if sk.get("six"):
        info["skills_sixth_line"] = sk["six"]
    if v349b_on("bold_results_v349b"):
        texs = sorted(p for p in out_dir.glob("*.tex") if not p.name.startswith("build_"))
        if texs:
            t = texs[0].read_text(encoding="utf-8")
            info["bold_spans"] = len(re.findall(r"\\textbf\{", v349b_section_text(t))) - len(re.findall(r"\\textbf\{", v349b_section_text(v349b_strip_bold(t))))
    try:
        sel = json.loads((out_dir / "resolved_plan.json").read_text(encoding="utf-8")).get("bank_selection") or {}
        bank = json.loads(Path(argv[argv.index("--bank") + 1] if "--bank" in argv else Path(__file__).with_name("bullet_bank.json")).read_text(encoding="utf-8"))
        b9 = {v["id"]: v348c_bank_meta(v)["replaces"] for vs in bank.get("projects", {}).values() for v in vs if v348c_bank_meta(v).get("flag") == "bank_format_v349b"}
        took = {n: o for n, o in b9.items() if f'"{n}"' in json.dumps(sel) and v349b_letter_bank()}
        if took:
            info["bank_format_v349b"] = took
    except Exception:
        pass
    rep["format_v349b"] = info


def v349b_section_text(tex: str) -> str:
    sec, out = "", []
    for line in str(tex).split("\n"):
        m = V349B_SECTION.search(line)
        if m:
            sec = m.group(1)
        if sec in ("EXPERIENCE", "PERSONAL PROJECTS") and V349B_ITEM.match(line):
            out.append(line)
    return "\n".join(out)


# --- Letter fit steps (format_letter_v349b) ------------------------------------------------------------------------
# A page that misses one Letter page with the 10pt buffer: (1) a new-grad slot fallback from 3/3/3 keeps a subset of
# the 3/3/3 bullets and the same letter (each candidate drop is tried); (2) the optional coursework line leaves;
# (3) one bullet slot leaves the lowest-ranked project with two or more, again keeping a subset and the same letter.
def v349b_note_letter(plan: dict[str, Any], out_dir: Path) -> None:
    """Called by build_cover_letter: records each attempt's letter and bullets (only inside v349b_main)."""
    if not V349B_CTX.get("watch"):
        return
    try:
        txt = "\n".join(p.read_text(encoding="utf-8") for p in sorted(Path(out_dir).glob("*_Cover_Letter.txt")))
    except Exception:
        txt = None
    _pl = plan.get("_v349c_plain") if v349c_plain_on() else plan.get("_v349c_out")
    if isinstance(_pl, dict):   # v3.4.9c run 8 / fix1: compare the letter the page was chosen for (the run 6 letter)
        txt = "\n".join(_pl.get("before") or [])
    V349B_CTX["letters"].append({"slots": list(_V343_LAYOUT.get("slots_now") or []), "sel": deepcopy(plan.get("bank_selection") or {}), "letter": txt})


def v349b_restrict_pool(pool: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Called by _v341_project_combos: a Letter page attempt picks only from the v3.4.9a page's bullets."""
    trim = V349B_CTX.get("trim")
    if not trim or not pool:
        return pool
    pid = str(pool[0]["id"]).split(".")[0]
    return [b for b in pool if b["id"] in trim["pool"][pid]] if pid in trim["pool"] else pool


def v349b_ref_order(sel: dict[str, list[str]] | None) -> dict[str, list[str]] | None:
    """A Letter page attempt lists each project's bullets in the v3.4.9a page's order (a reworded variant takes the
    place of the one it replaces)."""
    order = (V349B_CTX.get("trim") or {}).get("order") or {}
    if not isinstance(sel, dict):
        return sel
    rew = (V349B_CTX.get("trim") or {}).get("rew") or {}
    rank = lambda pid, i: order.get(pid, []).index(rew.get(i, i)) if rew.get(i, i) in order.get(pid, []) else len(order.get(pid, []))
    return {pid: sorted(ids, key=lambda i: rank(pid, i)) if isinstance(ids, list) else ids for pid, ids in sel.items()}


def v349b_slot_counts(out: dict[str, int]) -> dict[str, int]:
    """Called by _v343_slots: a trim attempt's slot count."""
    trim = V349B_CTX.get("trim")
    return {pid: trim["k"].get(pid, n) for pid, n in out.items()} if trim else out   # (k by project)


def v349b_subset_ok(first: dict[str, Any], last: dict[str, Any]) -> bool:
    """The fit page keeps the earlier letter and only bullets the earlier page had."""
    return last.get("letter") == first.get("letter") and all(set(ids) <= set(first["sel"].get(pid, [])) for pid, ids in (last.get("sel") or {}).items())


def _v349b_report(argv: list[str]) -> dict[str, Any]:
    try:
        return json.loads((Path(argv[argv.index("--out-dir") + 1]) / "report.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def _v349b_log(argv: list[str], key: str, val: Any) -> None:
    rep = _v349b_report(argv)
    if rep:
        rep.setdefault("format_v349b", {})[key] = val
        (Path(argv[argv.index("--out-dir") + 1]) / "report.json").write_text(json.dumps(rep, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _v349b_unfit(rep: dict[str, Any]) -> bool:
    return v349b_on("format_letter_v349b") and rep.get("status") != "PASS" and not rep.get("skip") \
        and bool({str(f.get("type")) for f in rep.get("failures") or []} & {"page_count", "v33_page_buffer"})


def v349b_reworded(argv: list[str]) -> dict[str, str]:
    """{new variant id: the id it replaces} for the bank_format_v349b rewordings in use."""
    try:
        bank = json.loads(Path(argv[argv.index("--bank") + 1] if "--bank" in argv else Path(__file__).with_name("bullet_bank.json")).read_text(encoding="utf-8"))
        return {v["id"]: v348c_bank_meta(v)["replaces"] for vs in bank.get("projects", {}).values() for v in vs
                if v348c_bank_meta(v).get("flag") == "bank_format_v349b"}
    except Exception:
        return {}


def v349b_letter_wanted(argv: list[str]) -> bool:
    try:
        fl = json.loads(Path(argv[argv.index("--master") + 1]).read_text(encoding="utf-8")).get("v347_flags") or {}
    except Exception:
        return False
    return bool(fl.get("format_letter_v349b", True)) and "format_letter_v349b" not in _V347_OFF


def v349b_main(argv: list[str]) -> int:
    """Called once by main_v3_1 (outermost). With format_letter_v349b on, the v3.4.9a page is built first (the five
    v3.4.9b flags off) as the reference; the Letter page then uses the same bullets (same slots, same letter). If it
    misses one Letter page with the 10pt buffer: the optional coursework line leaves, then one bullet slot leaves the
    lowest-ranked project that has two or more (a subset of the reference bullets; the letter must stay the same)."""
    V349B_CTX.update({"outer": True, "watch": True, "letters": [], "subset": None, "trim": None, "no_coursework": False})
    try:
        if not v349b_letter_wanted(argv):
            return _v349b_run(argv)
        if v349c_page_wanted(argv, V349C_LAYOUT_FLAG):   # v3.4.9c run 4: the new slot / fit order decides on the shipped page
            return _v349c_fit(argv, "layout")
        if not v349c_page_wanted(argv):
            return _v349c_fit(argv, None)
        # v3.4.9c run 2: the run 1 page decides the content (fit attempt: slots, coursework); the page_v349c page renders it
        # (v3.4.9c run 3: the Thesis and coursework changes are off while the content is decided, as in run 2)
        saved = set(_V347_OFF)
        _V347_OFF.update(V349C_LOCK_FLAGS)
        try:
            _v349c_fit(argv, None)
        finally:
            _V347_OFF.clear()
            _V347_OFF.update(saved)
        return _v349c_fit(argv, V349C_CTX.get("choice"))
    finally:
        V349B_CTX.update({"outer": False, "watch": False, "subset": None, "trim": None, "no_coursework": False})


def _v349c_fit(argv: list[str], force: Any) -> int:
    """The v3.4.9b Letter fit (body of v349b_main). The reference page is always the v3.4.9a page on the run 1
    template (page_v349c off). V349C_CTX["choice"] records the attempt that was kept ("early", a candidate index or
    "fallback"); force starts the attempts at that choice (v3.4.9c run 2: same content as the run 1 page)."""
    V349B_CTX.update({"letters": [], "subset": None, "trim": None, "no_coursework": False})
    V349C_CTX["choice"] = None
    if True:
        saved = set(_V347_OFF)
        _V347_OFF.update(V349B_FLAGS)
        _V347_OFF.update(V349C_LOCK_FLAGS)   # v3.4.9c runs 2-3: the reference is the run 1 template's v3.4.9a page with run 2 content
        try:
            _v349b_run(argv)
        finally:
            _V347_OFF.clear()
            _V347_OFF.update(saved)
        out_dir = Path(argv[argv.index("--out-dir") + 1])
        rep = _v349b_report(argv)
        try:
            slots = json.loads((out_dir / "quality_v33.json").read_text(encoding="utf-8")).get("bullet_slots") or {}
            ranking = list(json.loads((out_dir / "resolved_plan.json").read_text(encoding="utf-8")).get("ranking") or [])
            cw = any("Relevant coursework" in t.read_text(encoding="utf-8") for t in out_dir.glob("*.tex") if not t.name.startswith("build_"))
        except Exception:
            slots, ranking, cw = {}, [], False
        if rep.get("status") != "PASS" or rep.get("skip") or not V349B_CTX["letters"] or not slots or len(ranking) != 3:
            V349C_CTX["choice"] = "early"
            return _v349b_run(argv)
        ref = V349B_CTX["letters"][-1]
        lay = rep.get("layout_v343") or {}
        # new-grad pages: the slot plan loop starts at 3/2/2 (no slot retries); the counts come from the reference
        start = len(_V343_SLOT_PLANS) - 1 if lay.get("new_grad") else None
        rew = v349b_reworded(argv)   # a reworded variant stands in for the variant it replaces
        pool = {q: [i for x in slots.get(q) or [] for i in x] for q in ranking}
        k = {q: len(slots.get(q) or []) for q in ranking}
        # the coursework line is never added when the v3.4.9a page has none
        cands = [({}, not cw, None)] + ([({}, True, None)] if cw else [])
        for pid in reversed(ranking):
            sl = [list(x) for x in slots.get(pid) or []]
            if len(sl) >= 2:
                cands += [({pid: [i for j, x in enumerate(sl) if j != drop for i in x]}, True, (pid, len(sl) - 1)) for drop in reversed(range(len(sl)))]
        tried, log = 0, []
        first = force if isinstance(force, int) else (9 if force == "fallback" else 0)
        order = list(enumerate(cands[:9]))[first:]
        if force == "layout":   # v3.4.9c run 4 L1 / L2
            try:
                bank = json.loads(Path(argv[argv.index("--bank") + 1] if "--bank" in argv else Path(__file__).with_name("bullet_bank.json")).read_text(encoding="utf-8"))
                terms = {v["id"]: [str(t) for t in v.get("jd_terms") or []] for vs in bank.get("projects", {}).values() for v in vs}
            except Exception:
                terms = {}
            order = [(i, (None, c[1], c[2], c[3], c[4], c[0])) for i, c in enumerate(v349c_layout_cands(slots, ranking, bool(lay.get("new_grad")), terms))]
        if isinstance(force, int) and order and order[0][1][1] and v349c_page_wanted(argv, "coursework_v349c"):
            # v3.4.9c run 3: the kept attempt first with the coursework rule's line allowed (it never costs the buffer:
            # a page that misses it goes on to the same attempt without the line)
            order.insert(0, (order[0][0], (order[0][1][0], False, order[0][1][2])))
        for ci, (extra, nc, cut, *lx) in order:
            if lx:   # v3.4.9c run 4: (Skills filler may leave?, phase, pool) with cut = slots by project
                V349C_CTX["skills_trim"], phase, lpool = lx
                V349B_CTX["trim"] = {"pool": {q: v + [n for n, o in rew.items() if o in v] for q, v in lpool.items()}, "k": dict(cut),
                                     "order": {q: list(v) for q, v in (ref.get("sel") or {}).items()}, "rew": rew}
            else:
                V349B_CTX["trim"] = {"pool": {q: v + [n for n, o in rew.items() if o in v] for q, v in {**pool, **extra}.items()}, "k": {**k, **({cut[0]: cut[1]} if cut else {})},
                                     "order": {q: list(v) for q, v in (ref.get("sel") or {}).items()}, "rew": rew}
            V349B_CTX["no_coursework"] = nc
            rc = _v349b_run(argv, start)
            tried += 1
            got = _v349b_report(argv)
            last = dict(V349B_CTX["letters"][-1]) if V349B_CTX["letters"] else {}
            last["sel"] = {q: [rew.get(i, i) for i in v] for q, v in (last.get("sel") or {}).items()}
            same = bool(last) and v349b_subset_ok(ref, last)
            log.append({"cut": (dict(cut) if isinstance(cut, dict) else list(cut)) if cut else None, "no_coursework": nc, "status": got.get("status"), "same_letter_and_subset": same,
                        "failures": sorted({str(f.get("type")) for f in got.get("failures") or []})})
            if lx:
                log[-1]["phase"] = lx[1]
            if got.get("status") == "PASS" and same:
                V349C_CTX["choice"] = ci
                if lx:
                    V349C_CTX["skills_trim"] = True
                    got["layout_v349c"] = {"slots_by_rank": [V349B_CTX["trim"]["k"][q] for q in ranking], "phase": lx[1], "tries": tried, "attempts": log,
                                           "coursework_shown": any("Relevant coursework" in t.read_text(encoding="utf-8") for t in out_dir.glob("*.tex") if not t.name.startswith("build_"))}
                    (out_dir / "report.json").write_text(json.dumps(got, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
                if lay:
                    got["layout_v343"] = dict(lay, slots_by_rank=[V349B_CTX["trim"]["k"][q] for q in ranking])
                    (out_dir / "report.json").write_text(json.dumps(got, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
                if not lx and ((nc and cw) or cut):   # v3.4.9c run 5 fix: a layout attempt is logged in layout_v349c (its cut is a dict)
                    _v349b_log(argv, "letter_fit", {"coursework_dropped": nc and cw, "slot_left": {"project": cut[0], "slots": cut[1]} if cut else None, "tries": tried, "attempts": log})
                return rc
        V349B_CTX.update({"trim": None, "no_coursework": False})
        V349C_CTX["choice"] = "fallback"
        V349C_CTX["skills_trim"] = True
        rc = _v349b_run(argv)
        if force == "layout" and not V349C_CTX.get("extra_round") and _v349b_unfit(_v349b_report(argv)):
            # v3.4.9c run 6 fix (layout_v349c): the fallback page misses one page with the buffer too, so step (3) also
            # tries one slot from the higher-ranked projects (as the v3.4.9b fit did for vindexa)
            more = [(i, (None, c[1], c[2], c[3], c[4], c[0])) for i, c in enumerate(v349c_layout_cands(slots, ranking, bool(lay.get("new_grad")), terms, extra=True), start=len(order))]
            if more:
                V349C_CTX["extra_round"] = True
                try:
                    return _v349c_fit_more(argv, more, ref, rew, ranking, lay, out_dir, start, log, tried)
                finally:
                    V349C_CTX["extra_round"] = False
        _v349b_log(argv, "letter_fit", {"tries": tried, "attempts": log, "note": "no coursework / one-slot trim kept the v3.4.9a bullets and letter on one Letter page"})
        return rc


def _v349c_fit_more(argv, more, ref, rew, ranking, lay, out_dir, start, log, tried) -> int:
    """v3.4.9c run 6 fix: the extra one-slot layout attempts (same acceptance as _v349c_fit); none passing gives the
    fallback page again (unchanged from run 5)."""
    for ci, (extra, nc, cut, strim, phase, lpool) in more:
        V349C_CTX["skills_trim"] = strim
        V349B_CTX["trim"] = {"pool": {q: v + [n for n, o in rew.items() if o in v] for q, v in lpool.items()}, "k": dict(cut),
                             "order": {q: list(v) for q, v in (ref.get("sel") or {}).items()}, "rew": rew}
        V349B_CTX["no_coursework"] = nc
        rc = _v349b_run(argv, start)
        tried += 1
        got = _v349b_report(argv)
        last = dict(V349B_CTX["letters"][-1]) if V349B_CTX["letters"] else {}
        last["sel"] = {q: [rew.get(i, i) for i in v] for q, v in (last.get("sel") or {}).items()}
        same = bool(last) and v349b_subset_ok(ref, last)
        log.append({"cut": dict(cut), "no_coursework": nc, "status": got.get("status"), "same_letter_and_subset": same,
                    "failures": sorted({str(f.get("type")) for f in got.get("failures") or []}), "phase": phase + "_higher_ranked"})
        if got.get("status") == "PASS" and same:
            V349C_CTX["choice"] = ci
            V349C_CTX["skills_trim"] = True
            got["layout_v349c"] = {"slots_by_rank": [V349B_CTX["trim"]["k"][q] for q in ranking], "phase": phase + "_higher_ranked", "tries": tried, "attempts": log,
                                   "coursework_shown": any("Relevant coursework" in t.read_text(encoding="utf-8") for t in out_dir.glob("*.tex") if not t.name.startswith("build_"))}
            if lay:
                got["layout_v343"] = dict(lay, slots_by_rank=[V349B_CTX["trim"]["k"][q] for q in ranking])
            (out_dir / "report.json").write_text(json.dumps(got, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
            return rc
    V349B_CTX.update({"trim": None, "no_coursework": False})
    V349C_CTX["choice"] = "fallback"
    V349C_CTX["skills_trim"] = True
    rc = _v349b_run(argv)
    _v349b_log(argv, "letter_fit", {"tries": tried, "attempts": log, "note": "no coursework / one-slot trim kept the v3.4.9a bullets and letter on one Letter page"})
    return rc


def _v349b_run(argv: list[str], start: int | None = None) -> int:
    V349B_CTX["letters"] = []
    _V343_FLAGS.pop("slot_start", None)
    if start:
        _V343_FLAGS["slot_start"] = start
    sys.argv = list(argv)
    return main_v3_1()


if __name__ == "__main__":
    raise SystemExit(main_v3_1())
