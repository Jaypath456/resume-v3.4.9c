# Resume pipeline v3.4.9c: changes (2026-10-22)

Built from Resume_Pipeline_3_4_9b.zip in nine verified runs (checkpoints Resume_Pipeline_3_4_9c_1.zip ... _8.zip). Every
change sits behind its own master.json `v347_flags` entry (default true): `data_v349c`, `page_v349c`, `thesis_v349c`,
`coursework_v349c`, `layout_v349c`, `spacing_v349c`, `must_framework_v349c`, `closing_v349c`, `letters_plain_v349c`
(47 flags). With all nine off (test-only `--regression-v347-flags-off=...`, or `V347_FLAGS_OFF=...` for run_all.py) every
GATE16 output equals the unmodified v3.4.9b output byte for byte, the "v3.4.9b" version label included. Facts: Jay
graduates in December 2026 and can start work in February 2027. No new evidence.

Hash lock: pipeline b04aa71d | master 019e5b87 | bank 914805e9 | template a3aaddd9 | context md b43948bf.
bank_check.py and plan_template.json unchanged.

## Runs
1. data_v349c: Education "August 2025 -- December 2026" (no "Expected"); coursework = the nine courses Jay listed; Agentic AI
   is a skill, not coursework; letter bank sentence "We won 1st place." removed. Run 6 adds: a required posting term the
   page does not show joins its Skills category (it had been counted from the unprinted coursework list: assetwatch).
2. page_v349c: Standard reference layout (name line, "|" separators, Education on two lines, no Certifications & Awards
   section). Approved deviations: 0.3in side margins (not 0.4in) and Standard spacing on every page (not NewGrad spacing);
   the page is not an exact match of the Trial2 visual spec. The fit keeps the run 1 page's content choice.
3. thesis_v349c: first Thesis bullet variant I (Agile/Scrum, reviewed and merged pull requests), E when a role line asks for
   requirements; mentoring line "Interviewed about 20 student candidates, onboarded and mentored the hires ...".
   coursework_v349c: new-grad pages only, one line, top 3 courses by posting terms.
4. layout_v349c: new-grad 3/2/2 slots chosen from the reference page; fit fallback per page (coursework, Skills filler,
   one slot); Skills at most 5 lines; Python first on AI/ML Languages lines. Approved exception (cardinal): a Skills item
   may leave when its only bullet leaves with the 3/2/2 reduction. Run 6 adds: when the fallback page also misses the
   buffer, one slot from a higher-ranked project is tried too (vindexa 2/2/2, as v3.4.9b did).
5. spacing_v349c: after the page is fixed, spacing grows (binary search, 9 steps) to the largest step that keeps one US
   Letter page with at least 10.5pt unrounded spare; margins untouched. The page buffer is 10.5pt.
6. must_framework_v349c: a required language / framework (unhedged qualification line; not a responsibility, stack list,
   preferred line, alternatives or 3+ technology list) with exactly one primary project already among the three makes
   that project rank 1 (ebsco_sde1 React -> LaunchOps, bti Java -> LedgerFlow). The project set never changes.
7. closing_v349c: a closing's responsibility must be demonstrated, word by word (generic verbs and qualities aside), by its
   proof's master evidence; else the next responsibility, else the role-family closing (its claim must be in master
   evidence, else general_swe). Unsupported claims such as "optimize ... latency" or "feature stores" are gone.
8. letters_plain_v349c: three plain paragraphs, 120-160 words, at most one concrete achievement, no tool or library names,
   no digits outside the graduation sentence (and the posting's own title / company), no hackathon or certification
   references, no "we / our / us"; grounded closing, relocation and internship wording kept. The Run 7 letter stays in the
   plan for every page decision, so resumes, tracker rows and outreach do not change.
9. Release: PIPELINE_VERSION "v3.4.9c" ("v3.4.9b" when all nine flags are off); docs, instructions and hash lock.
   Plain-letter fixes found on the full 128 run (letters_plain_v349c): opening sentence kept whole ("Jr. ... role"), a
   third project fills a letter under 120 words, "In another project, I built ...", hooks de-tooled and checked against
   the posting (no cut or generic hooks), common industry tool names counted, skill-pool concepts not.
   report.json ranking_v349.rank now shows the final ranking after a must-have promotion (it kept the ranker's order, so
   golden_check read rank1 LedgerFlow on ebsco_sde1 although the page gives LaunchOps the most bullets); report only.
   A posting that requires AI coding tools keeps that evidence in plain words ("An AI coding assistant helped me write
   RIPPLE, and I checked its work with its full test suite."); a short letter is filled with project descriptions
   before the courtesy sentence.

Code: final definitions only, plus new helpers in "v3.4.9c run N" blocks. No file renamed (CHANGES_v3_4_9b.md is a copy of
the old CHANGES.md). Migration: re-upload the 4 changed Sources (pipeline, master.json, template, context md; all 7 is
fine) and paste the new instructions.

## Validation
- 128 fixtures, all nine flags on: exit 0 on 128/128; 126 PASS on one US Letter page with 10.51-10.77pt spare (unrounded),
  plus the 2 expected stops (fonzi, cisco_no_title). Grep gates: no "Expected", "1st Place", "Copart", "Cloud Practitioner"
  or Agentic AI coursework in any resume or letter; no tool names, digits (outside the graduation sentence and the
  posting's own title / company) or standalone we/our/us in any letter.
- Letters: 126/126 three paragraphs, 127-160 words with greeting and sign-off (median 136.5), at most one achievement,
  posting connection (plan hook 125, posting responsibility 1). Tracker rows and outreach identical to Run 6 on 126/126.
  Resumes identical to Run 6 on 125/126; vindexa differs (Run 7 closing + the letter-keeping fit step; see NOTES).
- All nine flags off: GATE16 byte-identical to the unmodified v3.4.9b outputs (16/16), template rebuilt exactly (dc281778
  with the v3.4.9b format flags off too). Flags on: GATE16 identical to the same fixtures in the 128 run (determinism).
- Selftests v341-v349b: all pass (14 files). bank_check: 120 variants, 0 failing; Experience 10/10. golden_check 12/12
  (ebsco_sde1 now LaunchOps rank1). score_all: resume 9.96 (tuned 9.97, holdouts 9.80, as v3.4.9b), letter 9.98.
- audit_v344 (unchanged): exit 1. Role-family closings 87/126 = 69.0% (cap 10%; v3.4.9b 10.3%): Run 7 keeps a
  responsibility only when its proof shows every specific word. 31 "closing repeats a letter proof" lines: 30 are
  proof-less family closings (the audit then compares the whole closing, company name included); 1 is giga_swe.
- Validation tools changed (not Sources): older selftests accept v3.4.9c, pin the nine flags off where they compare with
  older baselines, expect the v3.4.9c Education line, the page without Certifications and the 47 flags; score_all.py accepts
  the v3.4.9c mentoring line, the page without Certifications and "AI coding assistant" for the AI-coding-tools rule.
