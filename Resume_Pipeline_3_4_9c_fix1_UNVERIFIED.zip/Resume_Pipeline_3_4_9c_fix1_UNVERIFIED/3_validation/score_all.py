"""Automated proxy scorer: python3 score_all.py [OUT_DIR]  -> per-fixture resume/letter scores + mean/min.
Scores the measurable parts of RUBRIC.md. The judgment parts (phrasing, tone) are scored by an LLM judge (JUDGE_PROMPT.md).
v3.4.2: {"verdict": "stop"} (no requirements) scores 10/10 only when the run stops with no package. {"verdict": "skip"}
(a blocked posting) now expects the FULL package plus the blocker in report.eligibility_blockers and the tracker's
Blockers column (-1 each if missing); any skipped package scores 0. v3.4.2 checks: AI/ML line on a non-AI posting,
bare Kubernetes, Claude API without GoingOnce / LLM APIs, synonym stacking, Pintos wording, generic "I would welcome"
closings, onsite internship letters without relocation. v3.4.3: {"verdict": "stop_no_title"} scores 10/10 only when the run
stops with "stop: paste the job title line" and no package; Experience is scored (every Experience line is the original or
an approved variant); new-grad layout and one page; "..", "80 of 80", unnamed Cursor / Copilot, off-role frameworks in
Skills, closings over 30 words, hook specificity on fixtures marked hook_test, and the per-fixture expectations
skills_include / skills_exclude / no_gap_terms / fit. Fixtures not run in OUT_DIR are listed and left out. Summaries are printed per group: the original v3.4.0
fixtures, the new v3.4.1 tuning fixtures, and the held-out fixtures (never tuned against)."""
import json, re, sys, pathlib, os
H = pathlib.Path(__file__).resolve().parent
OUT = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path(os.environ.get("OUT", H / "out"))
man = json.loads((H / "manifest.json").read_text())
import importlib.util as _u
_sp = _u.spec_from_file_location("rp_score", H.parent / "1_upload_to_ChatGPT_Sources" / "resume_pipeline_v3_2.py"); _rp = _u.module_from_spec(_sp)
_argv = sys.argv; sys.argv = [sys.argv[0]]; _sp.loader.exec_module(_rp); sys.argv = _argv
MASTER = json.loads((H.parent / "1_upload_to_ChatGPT_Sources" / "master.json").read_text())
EXP_OK = {}
for _r in MASTER["experience"]:
    for _b in _r["bullets"]:
        EXP_OK.setdefault(_rp.normalize_fixed_text(_b), _b)
for _e in (MASTER.get("experience_variants") or {}).get("bullets", []):
    for _v in _e.get("variants", []):
        if _v.get("status") == "approved":
            EXP_OK.setdefault(_rp.normalize_fixed_text(_v["text"]), _v["text"])
if hasattr(_rp, "V349B_INTERVIEW_SHORT"):   # v3.4.9b letter_trims_v349b: the reference's short form of the Interviewed line
    EXP_OK.setdefault(_rp.normalize_fixed_text(_rp.V349B_INTERVIEW_SHORT), _rp.V349B_INTERVIEW_SHORT)
if hasattr(_rp, "V349C_MENTOR"):   # v3.4.9c thesis_v349c (approved): the HeinOnline mentoring line
    EXP_OK.setdefault(_rp.normalize_fixed_text(_rp.V349C_MENTOR), _rp.V349C_MENTOR)

def load(p):
    try: return json.loads(p.read_text())
    except Exception: return None

rows = []
not_run = []
group = {}
for mf in man:
    n = mf["name"]; d = OUT / n / "out"
    group[n] = "holdout" if mf.get("holdout") else ({"v341": "v341_tune", "v342": "v342_new", "v343": "v343_new", "v344": "v344_new", "v345": "v345_new", "v347": "v347_new"}.get(mf.get("suite"), "v340_original"))
    if not (d / "report.json").exists():
        not_run.append(n); continue
    rep = load(d / "report.json"); rp = load(d / "resolved_plan.json"); q = load(d / "quality_v33.json") or {}
    verdict = (mf.get("expect") or {}).get("verdict")
    skipped = bool(rep and rep.get("status") == "PASS" and rep.get("skip") and not rep.get("forced"))
    blocked_why = []
    if verdict == "stop":
        types = {x.get("type") for x in (rep or {}).get("skip_reasons", [])}
        ok = skipped and (d / "SKIP.txt").exists() and not list(d.glob("*.pdf")) and "no_requirements" in types
        rows.append((n, 10.0 if ok else 0.0, 10.0 if ok else 0.0, [] if ok else [f"expected verdict stop, got " + ("skip " + ",".join(sorted(types)) if skipped else str((rep or {}).get("status")))])); continue
    if verdict == "stop_no_title":
        ok = skipped and (rep or {}).get("verdict") == "stop: paste the job title line" and not list(d.glob("*.pdf"))
        rows.append((n, 10.0 if ok else 0.0, 10.0 if ok else 0.0, [] if ok else [f"expected 'stop: paste the job title line', got {(rep or {}).get('verdict') or (rep or {}).get('status')}"])); continue
    if verdict == "skip":
        # v3.4.2: an eligibility blocker never skips; the package is built and the blocker shows in Notes and the tracker
        tr = (rep or {}).get("tracker_row") or {}
        if not (rep or {}).get("eligibility_blockers"):
            blocked_why.append("R-1 blocked posting: no eligibility blocker reported")
        if not str(tr.get("Blockers", "")).strip():
            blocked_why.append("R-1 blocked posting: tracker Blockers column empty")
    if skipped:
        rows.append((n, 0.0, 0.0, ["posting was skipped but a package was expected: " + ",".join(x.get("type", "") for x in rep.get("skip_reasons", []))])); continue
    if not rep or rep.get("status") != "PASS" or not rp:
        rows.append((n, 0.0, 0.0, ["run did not PASS"])); continue
    ded_r, ded_l, why = float(len(blocked_why)), 0.0, list(blocked_why)
    order = rp.get("ranking") or rp.get("display_order") or []
    ex = mf.get("expect", {})
    if ex.get("top1") and order and order[0] not in ex["top1"]:
        ded_r += 1; why.append(f"R-1 #1 project {order[0]} not in {ex['top1']}")
    for p in ex.get("include", []):
        if p not in order: ded_r += 1; why.append(f"R-1 missing {p}")
    if ex.get("include_any") and not set(ex["include_any"]) & set(order):
        ded_r += 1; why.append(f"R-1 none of {ex['include_any']}")
    for p in ex.get("exclude", []):
        if p in order: ded_r += 1; why.append(f"R-1 off-target {p}")
    f = q.get("v34_forced") or {}
    if f.get("missing_bullet") or f.get("project_not_selected"):
        ded_r += 1; why.append("R-1 required evidence bullet missing")
    for s in q.get("skills_not_shown_or_named", []) or []:
        ded_r += 0.5; why.append(f"R-0.5 unbacked skill {s}")
    import subprocess
    pdfs = [x for x in d.glob("*.pdf") if "Cover_Letter" not in x.name]
    page = subprocess.run(["pdftotext", "-layout", str(pdfs[0]), "-"], capture_output=True, text=True).stdout if pdfs else ""
    page_n = re.sub(r"\s+", " ", page)
    def on_page(t):
        t = str(t)
        return bool(re.search(r"(?<![\w+#.])" + re.escape(t) + r"(?![\w+#])", page_n, 0 if len(t) <= 2 else re.I)) or (t == "AWS (EC2/RDS)" and "AWS" in page_n)
    om = [w for w in rep.get("warnings", []) if w.get("type") == "jd_supported_skill_term_omitted" and not on_page(w.get("target"))]
    if om:
        ded_r += min(1.0, 0.25 * len(om)); why.append("R-%.2f JD-named supported term not on the page: %s" % (min(1.0, 0.25 * len(om)), ", ".join(str(w.get("target")) for w in om)))
    for v in q.get("project_verbs_reusing_experience", []) or []:
        ded_r += 0.25; why.append(f"R-0.25 project verb repeats Experience: {v}")
    if q.get("pages", 1) != 1: ded_r += 2; why.append("R-2 not one page")
    if q.get("free_space_pt", 99) < 10: ded_r += 0.5; why.append("R-0.5 page buffer")
    letter = ""
    for t in d.glob("*_Cover_Letter.txt"): letter = t.read_text()
    jd = (H / "jds" / (n + ".txt")).read_text()
    if "soon after" in letter: ded_l += 0.75; why.append("L-0.75 vague start ('soon after')")
    for x in q.get("letter_numbers_not_on_resume", []) or []:
        ded_l += 1; why.append(f"L-1 letter number not on resume {x}")
    if (q.get("letter_words") or 0) > 200: ded_l += 0.5; why.append("L-0.5 over 200 words")
    if f.get("forced") and "Claude Code" not in letter and "AI coding assistant" not in letter:   # v3.4.9c: plain letters name no tools
        ded_l += 1; why.append("L-1 letter skips the required AI-coding-tools evidence")
    # v3.4.4: LaTeX lines are Jay's own resume pasted into a fixture, not posting text
    jd_role = "\n".join(l for l in jd.splitlines() if not re.search(r"insurance|benefit|dental|vision|401|wellness|leave|perks|\\item\b", l, re.I))
    hc = len(re.findall(r"\bclinical\b|\bpatients?\b|\bhealth ?care\b|\bmedical\b|\bpharma\w*", jd_role, re.I))
    if hc >= 2 and not re.search(r"healthcare|patient", letter, re.I): ded_l += 0.5; why.append("L-0.5 healthcare posting, letter leads with non-healthcare experience")
    loc = mf.get("location", "")
    remote = bool(re.search(r"\bremote\b", loc, re.I)) and not re.search(r"hybrid|onsite|on-site", loc, re.I)
    if remote and "relocat" in letter: ded_l += 0.5; why.append("L-0.5 relocation on a remote role")
    # --- v3.4.2 checks ---
    sk = (rp.get("skill_resolution") or {}).get("skills", {}) or {}
    jd_role = "\n".join(l for l in jd.splitlines() if not re.search(r"benefit|insurance|401|equal opportunity|eeo|about us", l, re.I))
    ai_rx = r"\bai\b|artificial intelligence|machine learning|\bml\b|\bllms?\b|language models?|deep learning|neural|generative|gen ?ai|agentic|\bagents?\b|\bnlp\b|computer vision|pytorch|tensorflow|prompt|data scien|claude code|copilot|model (?:training|evaluation|serving|inference)"
    if sk.get("ai_ml") and not re.search(ai_rx, jd_role + " " + mf.get("role", ""), re.I):
        ded_r += 0.5; why.append("R-0.5 AI/ML skills line on a posting with no AI/ML theme")
    if re.search(r"(?<!local )\bKubernetes\b(?! \(local k3d\)| cluster| setup)", page_n):
        ded_r += 0.5; why.append("R-0.5 bare Kubernetes on the page")
    tools_txt = " ".join(x for v in sk.values() for x in v)
    if "Claude API" in tools_txt and "goingonce" not in order and not re.search(r"llm apis?|model apis?|claude api|anthropic|openai api|gemini api", jd, re.I):
        ded_r += 0.5; why.append("R-0.5 Claude API without GoingOnce or an LLM-API posting")
    groups = [["Agentic AI", "AI Agents", "Agentic Workflows"], ["Real-Time Monitoring", "Application Monitoring", "Heartbeat Monitoring"]]
    for g in groups:
        if sum(1 for x in g if x in tools_txt) > 2:
            ded_r += 0.25; why.append(f"R-0.25 synonym stacking {g}")
    if "user memory access" in page_n:
        ded_r += 0.25; why.append("R-0.25 Pintos wording differs from master ('memory access')")
    if re.search(r"(?m)I would welcome the chance", letter):
        ded_l += 0.5; why.append("L-0.5 generic closing ('I would welcome the chance')")
    onsite = not remote and loc and not re.search(r"not stated|buffalo", loc, re.I)
    if re.search(r"\bintern(?:ship)?s?\b|\bco-?op\b", mf.get("role", ""), re.I) and onsite and "relocat" not in letter:
        ded_l += 0.5; why.append("L-0.5 onsite internship letter without relocation")
    # --- v3.4.3 checks ---
    exp_tex = page.split("EXPERIENCE", 1)[-1].split("PERSONAL PROJECTS", 1)[0] if "EXPERIENCE" in page else ""
    rep_tex = ""
    for t in d.glob("*.tex"):
        if t.name != "build_resume.tex": rep_tex = t.read_text()
    if r"\section*{EXPERIENCE}" in rep_tex:
        blk = rep_tex.split(r"\section*{EXPERIENCE}", 1)[1].split(r"\sectiondivider", 1)[0]
        blk = re.sub(r"\\textbf\{([^{}]*)\}", r"\1", blk)   # v3.4.9b: bold results are render-time markup
        items = [_rp.normalize_fixed_text(x) for x in re.findall(r"\\item\s+(.+)", blk)]
        bad_exp = [x for x in items if x not in EXP_OK]
        if bad_exp:
            ded_r += 1; why.append(f"R-1 Experience line is neither the original nor an approved variant: {bad_exp[0][:60]}")
    lay = rep.get("layout_v343") or {}
    ng = _rp.is_new_grad(mf.get("role", ""), _rp.clean_jd_text(jd))
    if ng:
        secs = ("EDUCATION", "EXPERIENCE", "PERSONAL PROJECTS", "TECHNICAL SKILLS") + (("CERTIFICATIONS",) if "CERTIFICATIONS" in page or "AWARDS" in page else ())
        pos = [page.find(x) for x in secs]   # v3.4.9c page_v349c: no Certifications & Awards section on the page
        if -1 in pos or pos != sorted(pos):
            ded_r += 1; why.append("R-1 new-grad posting without the new-grad section order")
        if lay.get("omitted_experience") and "Go Digital" in page:
            ded_r += 0.5; why.append("R-0.5 Go Digital shown on a new-grad page that omits it")
    elif page.find("EDUCATION") < page.find("EXPERIENCE"):
        ded_r += 1; why.append("R-1 new-grad layout on a posting that is not new grad")
    if "80 of 80" in page or "80 of 80" in letter:
        ded_r += 0.25; why.append("R-0.25 'all 80 of 80 tests'")
    if re.search(r"[A-Za-z]\.\.(?!\.)", letter):
        ded_l += 0.5; why.append("L-0.5 '..' in the letter")
    for tool, rx in (("Cursor", r"\bcursor\b"), ("GitHub Copilot", r"\bcopilot\b")):
        if tool in tools_txt and not re.search(rx, jd, re.I):
            ded_r += 0.25; why.append(f"R-0.25 {tool} not named by the posting")
    fw = sk.get("frameworks_libraries", []) or []
    bullets_txt = page_n
    if any(x in fw for x in ("LangGraph", "Streamlit")) and not re.search(ai_rx, jd_role + " " + mf.get("role", ""), re.I):
        ded_r += 0.25; why.append("R-0.25 LangGraph / Streamlit in Skills on a non-AI posting")
    if "Pydantic" in fw and not re.search(r"pydantic", jd, re.I):
        ded_r += 0.25; why.append("R-0.25 Pydantic in Skills, not named by the posting")
    close = [x for x in re.findall(r"I want to [^.]*(?:\.[A-Za-z][^.]*)*\.", letter)]
    if close and len(close[-1].split()) > 30:
        ded_l += 0.25; why.append("L-0.25 closing over 30 words")
    if mf.get("hook_test") and (rep.get("cover_letter") or {}).get("hook_specific") is False:
        ded_l += 0.5; why.append("L-0.5 hook does not name the company's product / domain")
    for t in ex.get("skills_include", []):
        if not re.search(r"(?<![\w])" + re.escape(t) + r"(?![\w])", tools_txt):
            ded_r += 0.5; why.append(f"R-0.5 {t} missing from Skills")
    for t in ex.get("skills_exclude", []):
        if re.search(r"(?<![\w])" + re.escape(t) + r"(?![\w])", tools_txt):
            ded_r += 0.5; why.append(f"R-0.5 {t} in Skills")
    for t in ex.get("no_gap_terms", []):
        if t in (rep.get("jd_gap_terms_detected") or []):
            ded_r += 0.25; why.append(f"R-0.25 {t} reported as a gap")
    if ex.get("fit") and rep.get("effective_fit") != ex["fit"]:
        ded_r += 0.5; why.append(f"R-0.5 Fit {rep.get('effective_fit')} (expected {ex['fit']})")
    # --- v3.4.4 checks ---
    for b in ex.get("no_blockers", []):
        if any(x.get("type") == b for x in (rep.get("eligibility_blockers") or [])):
            ded_r += 1; why.append(f"R-1 unexpected blocker {b}")
    if ex.get("fit_in") and rep.get("effective_fit") not in ex["fit_in"]:
        ded_r += 0.5; why.append(f"R-0.5 Fit {rep.get('effective_fit')} not in {ex['fit_in']}")
    if ex.get("jd_removed"):
        cleaned = _rp.clean_jd_text(jd)
        for t in ex["jd_removed"]:
            if t in cleaned:
                ded_r += 0.25; why.append(f"R-0.25 job-board widget text kept: {t}")
    if len(letter.split()) > 200:
        ded_l += 0.5; why.append(f"L-0.5 letter {len(letter.split())} words (whole letter)")
    ci = (rep.get("cover_letter") or {}).get("closing") or {}
    if ci.get("text") and ci.get("_proof") and _rp.closing_repeats_letter(ci["_proof"], letter.replace(ci["text"], " ")):
        ded_l += 0.5; why.append("L-0.5 closing repeats a proof the letter already gives")
    for fn in ("outreach.json", "tracker_row.json"):
        if (d / fn).exists() and re.search(r"[A-Za-z]\.\.(?!\.)", (d / fn).read_text()):
            ded_l += 0.25; why.append(f"L-0.25 '..' in {fn}")
    trr = load(d / "tracker_row.json") or {}
    if [k for k in trr if k != "company_key"] != list(_rp.V344_TRACKER_COLUMNS) or trr.get("Status") != "Applied":   # v3.4.9a: company_key is a matching key, not a sheet column
        ded_r += 0.5; why.append("R-0.5 tracker_row.json columns / Status not v3.4.4")
    rows.append((n, round(10 - min(ded_r, 10), 2), round(10 - min(ded_l, 10), 2), why))
w = max([len(r[0]) for r in rows] or [8])
for n, r, l, why in rows:
    print(f"{n:<{w}}  resume {r:5.2f}  letter {l:5.2f}  " + ("; ".join(why) if why else "-"))
def summary(label, sel):
    if not sel:
        return
    rs = [r[1] for r in sel]; ls = [r[2] for r in sel]
    low = [r[0] for r in sel if min(r[1], r[2]) < 9.5]
    print(f"{label:<14} fixtures {len(sel):3d} | resume mean {sum(rs)/len(rs):.2f} min {min(rs):.2f} | letter mean {sum(ls)/len(ls):.2f} min {min(ls):.2f} | below 9.5: {len(low)}" + (f" ({', '.join(low)})" if low else ""))
print()
for g in ("v340_original", "v341_tune", "v342_new", "v343_new", "v344_new", "v345_new", "v347_new", "holdout"):
    summary(g, [r for r in rows if group[r[0]] == g])
summary("all", rows)
if not_run:
    print(f"not run ({len(not_run)}): " + ", ".join(not_run))
