"""v3.4.8b self-test: python3 selftest_v348b.py  -> prints each check and exits 1 on any failure.
One fact change: Jay graduates in December 2026 and can start work in February 2027 (two separate facts).
Facts in master.json and the context md; the date strings; both letter sentences; the graduation-window rule (a
"graduating December 2026 - June 2027" window -> no blocker; "May 2027 - May 2027" -> blocker); an enrollment-required
2027 internship -> enrollment blocker; a "start January 2027" posting -> Timing note; the flag (off = v3.4.8a facts);
end-to-end builds of zoro (full-time sentence + Education line) and nvidia (internship sentence + blocker), a flag-off
build identical to baseline_v348a, the instructions and the hash lock."""
import hashlib, json, pathlib, re, shutil, subprocess, sys, tempfile, importlib.util
H = pathlib.Path(__file__).resolve().parent
SRC = H.parent / "1_upload_to_ChatGPT_Sources"
sys.argv = [sys.argv[0]]
spec = importlib.util.spec_from_file_location("rp", SRC / "resume_pipeline_v3_2.py"); rp = importlib.util.module_from_spec(spec); spec.loader.exec_module(rp)
master = json.loads((SRC / "master.json").read_text())
sys.path.insert(0, str(H)); import diff_gate_v347 as gate   # noqa: E402
import diff_gate_v348b as gate8b   # noqa: E402
MAN = {m["name"]: m for m in json.loads((H / "manifest.json").read_text())}
TPL = json.loads((SRC / "plan_template.json").read_text())
BASE = H / "baseline_v348a"
FLAG = "graduation_dec2026_v348"
FT = "I graduate in December 2026 and can start work in February 2027."
IN = "My Master's in Computer Science at the University at Buffalo is expected in December 2026, and I can start work in February 2027."
TIMING = "Graduates December 2026; available to start February 2027 (subject to OPT/EAD approval)"
V349B_OFF = "--regression-v347-flags-off=bank_format_v349b,format_letter_v349b,bold_results_v349b,skills_cap5_v349b,letter_trims_v349b,page_v349c,thesis_v349c,coursework_v349c,layout_v349c"   # v3.4.9b: these end-to-end checks compare with A4 baselines, so the format flags are off (v3.4.9c: and the run 2 page)
bad = []


def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else f"  -> {detail}"))
    if not ok:
        bad.append(name)


check("pipeline version v3.4.8b or later", rp.PIPELINE_VERSION in ("v3.4.8b", "v3.4.8c", "v3.4.9a", "v3.4.9b"), rp.PIPELINE_VERSION)   # v3.4.8c build keeps these checks
fl = master.get("v347_flags") or {}
check("flag: graduation_dec2026_v348 in master.json, true", fl.get(FLAG) is True, fl)
check("flag: fifteen flags known and true (23 in v3.4.8c, 33 since v3.4.9a, 38 since v3.4.9b, 39 with data_v349c, 40 with page_v349c, 42 with thesis_v349c and coursework_v349c, 43 with layout_v349c)", FLAG in rp.V347_FLAG_NAMES and len(rp.V347_FLAG_NAMES) in (15, 23, 33, 38, 39, 40, 42, 43) and all(fl.get(k) is True for k in rp.V347_FLAG_NAMES))
off = json.loads(json.dumps(master)); off["v347_flags"][FLAG] = False
got = rp.v347_load_flags(off)
check("flag: false turns only this change off", got[FLAG] is False and all(v for k, v in got.items() if k != FLAG), got)
rp.v347_load_flags(master)

# ---- D1 facts -----------------------------------------------------------------------------------------------------
edu = master["education"]["masters"]
check("D1 master: dates August 2025 -- December 2026 (v3.4.9c: no \"Expected\")", edu.get("dates") == "August 2025 -- December 2026", edu.get("dates"))
check("D1 master: graduation December 2026, start February 2027 (two facts)", edu.get("graduation") == "December 2026" and edu.get("available_to_start_work", "").startswith("February 2027"), edu)
check("D1 master: no degree_conferral / computed OPT date left", "degree_conferral" not in edu and "earliest_post_completion_opt" not in edu, sorted(edu))
check("D1 master: candidate_eligibility carries both facts", master["candidate_eligibility"].get("graduation") == "December 2026" and master["candidate_eligibility"].get("available_to_start_work", "").startswith("February 2027"))
qf = master.get("qualification_facts") or []
check("D1 master: qualification facts name December 2026, none say graduation in 2027",
      "graduation in December 2026" in qf and not any(re.search(r"graduat\w* in 2027|^2027 graduate", q) for q in qf), [q for q in qf if "2027" in q or "2026" in q])
def strings(o, path=""):
    if isinstance(o, dict):
        for k, v in o.items():
            yield from strings(v, path + "." + k)
    elif isinstance(o, list):
        for v in o:
            yield from strings(v, path)
    elif isinstance(o, str):
        yield path + ": " + o


feb = [x for x in strings(master) if "February 2027" in x and "start" not in x.lower()]   # the key or the text names the start
check("D1 master: every master.json value that names February 2027 names it as the start date", not feb, feb[:3])
md = (SRC / "Master_Resume_Context_LEAN_CURRENT_v3_2.md").read_text(encoding="utf-8")
check("D1 md: section 0-v348b first", md.find("## 0-v348b)") != -1 and md.find("## 0-v348b)") < md.find("## 0-v348a)"))
check("D1 md: Education dates line", "Dates: August 2025 -- Expected December 2026" in md)
feb = [l for l in md.splitlines() if "February 2027" in l and not re.search(r"\bstart", l)]
check("D1 md: every line that names February 2027 names it as the start date", not feb, feb[:3])
check("D1 md: no 'graduates (in) February 2027' / 'expected in February 2027' / 'Expected February 2027'", not re.search(r"graduat\w* (?:in )?February 2027|xpected (?:in )?February 2027|conferred February 2027", md))
check("D1 md: no computed OPT date", "February 2, 2027" not in md and "February 1, 2027" not in md)
check("D1 md pointer in master.json matches", master["source"]["master_markdown_sha256"] == hashlib.sha256(md.encode("utf-8")).hexdigest())

# ---- D2 resume ----------------------------------------------------------------------------------------------------
tpl = (SRC / "Resume_Template_CURRENT.tex").read_text(encoding="utf-8")
check("D2 template: Education reads August 2025 -- December 2026 (v3.4.9c: no \"Expected\")", "\\textit{August 2025 -- December 2026}" in tpl and "Expected" not in tpl and "February 2027" not in tpl)
check("D2 template pointer in master.json matches", master["source"]["template_sha256"] == hashlib.sha256(tpl.encode("utf-8")).hexdigest())
rp.v347_load_flags(off)
check("D2 flag off: assemble step restores the v3.4.8a line", tpl.replace(rp.V349C_EDU_NEW, rp.V348B_EDU_OLD) != tpl and "Expected February 2027" in tpl.replace(rp.V349C_EDU_NEW, rp.V348B_EDU_OLD))
rp.v347_load_flags(master)

# ---- D3 letters ---------------------------------------------------------------------------------------------------
check("D3 full-time sentence", rp.V348B_FT_NEW == FT, rp.V348B_FT_NEW)
check("D3 internship sentence", rp.V348B_INTERN_NEW == IN, rp.V348B_INTERN_NEW)
sw = rp.v348b_letter(["P1.", "I built X. " + rp.V348B_FT_OLD + " I am open to relocating.", "I built Y. " + rp._V346_INTERN_LOGISTICS_START])
check("D3 swap: both forms replaced, nothing else", sw == ["P1.", "I built X. " + FT + " I am open to relocating.", "I built Y. " + IN], sw)
for s in (FT, IN):
    check(f"D3 start clause validator passes: {s[:40]}...", rp.v346_start_clause_ok(f"Dear Hiring Manager,\n\nI am applying.\n\nI built X. {s} I want to build Y at Z.\n\nSincerely,\nJay Niketan Pathare\n"))
    check(f"D3 graduation-date check passes: {s[:40]}...", not rp.v348b_text_problems(s))
for s in ("I graduate in February 2027 and can start work that month.", "My Master's is expected in February 2027."):
    check(f"D3 graduation-date check FAILS the old sentence: {s[:40]}...", bool(rp.v348b_text_problems(s)))
out = rp._v347_relocation(["Dear", "I built X. " + FT + " I want to build Y at Z."], {"application": {"location": "Buffalo Grove, IL (Onsite)"}}, "")
check("D3 relocation still follows the logistics sentence", "start work in February 2027. I am open to relocating. I want" in out[1], out[1])

# ---- D4 eligibility and timing ------------------------------------------------------------------------------------
W = rp.v348b_window_ok
check("D4 window: 'graduating December 2026 - June 2027' includes Jay", W("MS in CS, graduating December 2026 - June 2027") is True)
check("D4 window: 'between December 2026 and June 2027' includes Jay", W("graduating between December 2026 and June 2027.") is True)
check("D4 window: 'December 2026 or May/June 2027' includes Jay", W("Graduating in December 2026 or May/June 2027") is True)
check("D4 window: 'Winter 2026 - Spring 2027' includes Jay", W("graduated either in Winter 2026 - Spring 2027.") is True)
check("D4 window: 'graduating in 2026' includes Jay", W("degree, graduating in 2026") is True)
check("D4 window: 'by June 2027' includes Jay", W("will graduate by June 2027") is True)
check("D4 window: 'May 2027 - May 2027' excludes Jay", W("Student eligibility: Graduating May 2027 - May 2027") is False)
check("D4 window: 'graduating in May 2027' excludes Jay", W("Must be graduating in May 2027.") is False)
check("D4 window: 'graduating in 2025' excludes Jay", W("graduating in 2025") is False)
check("D4 window: '2026 Start' is not a graduation date", W("Application Security Engineer Graduate (TikTok) - 2026 Start (BS/MS)") is None)
check("D4 window helper: no blocker for 'graduating December 2026 - June 2027'", rp.v348b_grad_window("Requirements:\n- MS in CS, graduating December 2026 - June 2027\n") == "")
check("D4 window helper: blocker for 'Graduating May 2027 - May 2027'", rp.v348b_grad_window("Student eligibility: Graduating May 2027 - May 2027\n") != "")


def blockers(role, jd):
    plan = {"application": {"role": role, "company": "Acme", "location": "Austin, TX"}, "_raw_jd_text": jd, "jd_requirements": []}
    return rp.eligibility_blockers(plan, master)


b = blockers("Software Engineer, New Grad", "Software Engineer, New Grad\nRequirements:\n- MS in CS, graduating December 2026 - June 2027\n- Python\n")
check("D4 e2e blockers: 'graduating December 2026 - June 2027' window -> no blocker", not any(x["type"] == "graduation_window" for x in b), b)
b = blockers("Software Engineering Intern", "Software Engineering Intern\nRequirements:\n- Graduating May 2027 - May 2027\n")
check("D4 e2e blockers: 'May 2027 - May 2027' window -> graduation_window naming December 2026",
      any(x["type"] == "graduation_window" and "December 2026" in x["reason"] for x in b), b)
b = blockers("Software Engineering Intern (Summer 2027)", "Software Engineering Intern (Summer 2027)\nRequirements:\n- Must be actively enrolled in a degree program for the full duration of the internship.\n- Python\n")
check("D4 e2e blockers: enrollment-required 2027 internship -> enrollment_required", any(x["type"] == "enrollment_required" and "December 2026" in x["reason"] for x in b), b)
b = blockers("2027 Summer Internship - Software", "2027 Summer Internship - Software\nThe Summer Internship Program runs June to August 2027.\nRequirements:\n- Python\n")
check("D4 e2e blockers: an internship that starts after December 2026 -> enrollment_required (start_after)", any(x["type"] == "enrollment_required" and "starts after" in x["reason"] for x in b), b)
b = blockers("Software Engineering Co-op (Fall 2026)", "Software Engineering Co-op (Fall 2026)\nRequirements:\n- Must be currently enrolled during the co-op term and return to school after the program.\n")
check("D4 e2e blockers: an internship that ends by December 2026 -> no enrollment blocker", not any(x["type"] == "enrollment_required" for x in b), b)
b = blockers("Software Engineer", "Software Engineer\nAble to work from our New York office starting in January 2027.\nRequirements:\n- Python\n")
st = [x for x in b if x["type"] == "start_date"]
check("D4 e2e blockers: 'start January 2027' posting -> Timing note with both dates", st and TIMING in st[0]["reason"] and "before February 2027" in st[0]["reason"], b)
b = blockers("Software Engineer", "Software Engineer\nStart date: March 2027.\nRequirements:\n- Python\n")
check("D4 e2e blockers: 'start March 2027' -> no Timing note", not any(x["type"] == "start_date" for x in b), b)
b = blockers("Software Engineer (2025 Graduates)", "Software Engineer (2025 Graduates)\nRequirements:\n- Python\n")
gy = [x for x in b if x["type"] == "graduation_year"]
check("D4 e2e blockers: a 2025-graduates posting -> Timing note", gy and TIMING in gy[0]["reason"], b)
check("D4 labels: tracker Blockers say December 2026", rp.blockers_summary([{"type": "graduation_window"}, {"type": "enrollment_required"}]) == "graduation window excludes December 2026; enrollment required past December 2026")
for x in ("v348b_date_blockers",):
    check(f"D4 no OPT date in any reason ({x})", "February 2, 2027" not in json.dumps(rp.V348B_REASONS))

# ---- flag off: the v3.4.8a master facts come back ------------------------------------------------------------------
m2 = json.loads(json.dumps(master)); rp.v347_load_flags(off); rp.v348b_restore_master(m2)
check("flag off: master restore gives the v3.4.8a education and qualification facts",
      m2["education"]["masters"].get("dates") == "August 2025 -- Expected February 2027" and "graduation in 2027" in m2["qualification_facts"] and "graduation" not in m2["education"]["masters"])
check("flag off: graduation window back to February 2027", rp.grad_window_warning("Student eligibility: Graduating May 2027 - May 2027") != "" and rp._grad_window_ok("graduating in 2026") is False)
rp.v347_load_flags(master)


# ---- end-to-end ---------------------------------------------------------------------------------------------------
def run(name, extra=()):
    m = MAN[name]
    td = pathlib.Path(tempfile.mkdtemp()); dd = td / name; dd.mkdir()
    plan = json.loads(json.dumps(TPL)); a = plan["application"]
    a.update({"company": m["company"], "role": m["role"], "location": m["location"], "visa_sponsorship": "Not stated in the posting.", "source": "Audit", "application_date": "2026-10-13"})
    plan["cover_letter"]["team_focus"] = m["team_focus"]; plan["cover_letter"]["hook"] = m.get("hook", "")
    if m.get("closing") and not m["closing"].startswith("I would welcome the chance"): plan["cover_letter"]["closing"] = m["closing"]
    a.update(m.get("app_extra", {}))
    if m.get("tagline"): plan["tagline_text"] = m["tagline"]
    for k in ("prefer_variants", "jd_requirements_extra"):
        if m.get(k): plan[k] = m[k]
    (dd / "plan.json").write_text(json.dumps(plan, indent=1))
    subprocess.run([sys.executable, "-I", "resume_pipeline_v3_2.py", V349B_OFF, "--template", "Resume_Template_CURRENT.tex", "--master", "master.json", "--plan", str(dd / "plan.json"),
                    "--jd", str(H / "jds" / (name + ".txt")), "--out-dir", str(dd / "out")] + (["--regression-allow-missing-title"] if m.get("legacy_no_title") else []) + list(extra),
                   cwd=SRC, capture_output=True, text=True)
    snap = td / "snap"; gate.snapshot(str(td), str(snap))
    return td, snap / name


for name, sent in (("zoro_fullstack", FT), ("nvidia", IN)):
    td, sn = run(name, ["--regression-v347-flags-off=start_date_parse_v348,bank_wording_v348,fleet_language_model_v348,fleet_repick_v348,skills_lines_v348,heading_move_v348,closing_proof_map_v348,closing_specific_v348,jd_sections_v349,years_range_v349,fit_guard_v349,bullet_score_v349,ranker_v349,date_order_v349,proof_on_page_v349,copy_rule_v349,skills_dedupe_v349,company_key_v349"])   # v3.4.8c: its changes go off where a build is compared with baseline_v348a
    r = json.loads((sn / "report.json").read_text())
    tex, letter = (sn / "resume.tex").read_text(), (sn / "letter.txt").read_text()
    check(f"e2e {name}: PASS", r["status"] == "PASS", r.get("failures"))
    check(f"e2e {name}: Education line August 2025 -- December 2026", "August 2025 -- December 2026" in tex and "Expected" not in tex and "February 2027" not in tex)
    check(f"e2e {name}: letter logistics sentence", sent in letter, letter[-400:])
    check(f"e2e {name}: letter <= 200 words", len(letter.split()) <= 200, len(letter.split()))
    check(f"e2e {name}: no February 2027 graduation in letter or notes", not gate8b.grad_feb(letter) and not gate8b.grad_feb(json.dumps(r.get("notes"))))
    bt = (BASE / name / "resume.tex").read_text().splitlines(); nt = tex.splitlines()
    check(f"e2e {name}: resume differs from baseline_v348a only in the Education line", len(bt) == len(nt) and [i for i, (x, y) in enumerate(zip(bt, nt)) if x != y] == [i for i, x in enumerate(bt) if "Expected February 2027" in x])
    if name == "nvidia":
        check("e2e nvidia: enrollment blocker names December 2026", any(x["type"] == "enrollment_required" and "December 2026" in x["reason"] for x in r.get("eligibility_blockers", [])))
    shutil.rmtree(td, ignore_errors=True)

for name in ("zoro_fullstack", "nvidia", "harvey"):
    td, sn = run(name, ["--regression-v347-flags-off=" + FLAG + ",data_v349c,page_v349c,thesis_v349c,coursework_v349c,layout_v349c,start_date_parse_v348,bank_wording_v348,fleet_language_model_v348,fleet_repick_v348,skills_lines_v348,heading_move_v348,closing_proof_map_v348,closing_specific_v348,jd_sections_v349,years_range_v349,fit_guard_v349,bullet_score_v349,ranker_v349,date_order_v349,proof_on_page_v349,copy_rule_v349,skills_dedupe_v349,company_key_v349"])
    sub = td / "base"; sub.mkdir(); shutil.copytree(BASE / name, sub / name)
    dd = gate.diffs(sub, sn.parent)
    check(f"flag off: {name} identical to baseline_v348a (timing normalized)", not dd, dd[:3])
    shutil.rmtree(td, ignore_errors=True)

# ---- instructions and hash lock ------------------------------------------------------------------------------------
ins = (H.parent / "2_PROJECT_INSTRUCTIONS_paste.txt").read_text(encoding="utf-8")
check("instructions under 7,600 characters", len(ins) < 7600, len(ins))
check("instructions: version v3.4.8b or later", "v3.4.8b" in ins or "v3.4.8c" in ins or "v3.4.9a" in ins or "v3.4.9b" in ins)
check("D5 instructions: 'Jay graduates December 2026 and starts work February 2027'", "Jay graduates December 2026 and starts work February 2027" in ins and "graduates February 2027" not in ins)
feb = [l for l in ins.splitlines() if "February 2027" in l and not re.search(r"\bstart", l)]
check("D5 instructions: every line that names February 2027 names it as the start date", not feb, feb)
for f in ("resume_pipeline_v3_2.py", "master.json", "bullet_bank.json", "Resume_Template_CURRENT.tex", "Master_Resume_Context_LEAN_CURRENT_v3_2.md"):
    hsh = hashlib.sha256((SRC / f).read_bytes()).hexdigest()
    check(f"hash lock lists {f}", f"{f} sha256={hsh}" in ins)
check("bank unchanged (v3.4.8c: only the W / F1 variants are new)", hashlib.sha256((SRC / "bullet_bank.json").read_bytes()).hexdigest()[:8] in ("d56f0743", "6ce82778", "914805e9"))
check("D5 outreach templates name no dates", not re.search(r"\d|January|February|March|December|graduat", json.dumps(getattr(rp, "V348_TEMPLATES", {}))))

print(f"\n{len(bad)} failing" if bad else "\nall checks pass")
sys.exit(1 if bad else 0)
