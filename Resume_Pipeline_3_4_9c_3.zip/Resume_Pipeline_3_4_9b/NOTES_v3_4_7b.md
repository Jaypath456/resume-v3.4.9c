# Resume pipeline v3.4.7b: notes

Built 2026-10-18 from Resume_Pipeline_3_4_7a.zip. Four fixes (B1 to B4), each behind its own master.json `v347_flags`
switch (default true), on top of the 7a safety tooling. Details in CHANGES.md; every changed output line, with the
fix that caused it, in DIFF_REPORT_v347b.md.

## What Jay needs to do

1. **Sources: re-upload 3 of the 7 files.** Changed: `resume_pipeline_v3_2.py`, `master.json` (4 new `v347_flags`
   entries and the new md pointer), `Master_Resume_Context_LEAN_CURRENT_v3_2.md` (new section 0-v347b). Unchanged:
   `bullet_bank.json`, `Resume_Template_CURRENT.tex`, `plan_template.json`, `bank_check.py`. Uploading all 7 is fine.
2. **Project instructions: paste the new `2_PROJECT_INSTRUCTIONS_paste.txt`** (7,581 characters; limit 7,600). Only the
   version ("pipeline v3.4.7b") and the hash lock changed; the new rules live in the context .md section 0-v347b.
3. **Tracker sheet: nothing new.**
4. **One decision (alml Fleet bullet), below.** Nothing is needed if you accept the shipped behaviour.

## Hash lock

| File | sha256 |
|---|---|
| resume_pipeline_v3_2.py | 3332eea0… (full value in the instructions) |
| master.json | 5ea23649… |
| bullet_bank.json | d56f0743… (unchanged) |
| Resume_Template_CURRENT.tex | 1309898b… (unchanged) |
| Master_Resume_Context_LEAN_CURRENT_v3_2.md | b86a9f06… |
| plan_template.json | 4358f1e0… (unchanged) |
| bank_check.py | 81b28185… (unchanged) |

## Acceptance

| Check | Result |
|---|---|
| Baseline | `3_validation/baseline_v347a/`: all 124 fixtures run on the unmodified 7a Sources, saved before any change |
| Determinism (7a code) | IDENTICAL: two 7a runs, normalizing only report `timestamps.*` and `pdflatex_calls[*].duration_ms` |
| Determinism (7b code) | IDENTICAL: two full 7b runs, same normalization |
| All 4 new flags off | IDENTICAL to baseline_v347a on all 124 fixtures; the only listed difference is the `pipeline_version` label on the two stop reports (fonzi, cisco_no_title), the only reports that carry it |
| Predictions | `predict_v347b.py` (restates each rule without the new code) wrote `predicted_changes_v347b.json` from the baseline |
| Diff gate | **PASS**: 582 changed lines in 39 fixtures, 0 unpredicted on the 53 originals and 20 holdouts, 0 unjustified elsewhere, 0 guard failures. 12 predicted changes did not happen (listed in the report): 6 B2 report changes where the predictor (written to over-predict) saw an OR-group but no member Jay has, e.g. wpp's "dbt, Airflow, BigQuery, Snowflake", so nothing clears; and 6 B4 "may pick another bullet once the Fleet trigger stops" warnings where the selector kept its choice |
| G0 projects | no project heading name changed on any fixture (selection and order held) |
| B1 guard | negative-wording blockers 8 before, 8 after |
| B2 guard | Fit changed on 2 fixtures, none dropped: zoro Low -> High (B1 removed the badge blocker; Fit recomputed), alml Medium -> High (B2, one level). No negative-blocker fixture changed Fit |
| B4 guard | bullets changed on 5 of 120 existing fixtures (cap 12): list with scores below |
| Fixtures | 124: 122 pass + 2 expected stops |
| score_all | 10.00 / 10.00 on v340_original (53), v341_tune (36), v342_new (6), v343_new (2), v344_new (2), v345_new (1); v347_new (4) resume 10.00, letter 9.88 (zoro hook, as in 7a) |
| Holdouts (20, never tuned) | resume 9.85, letter 9.97, unchanged; below 9.5: acme_cloud, twitch, linkedin_ai (as before) |
| audit_v344 | PASS: 122 built, 11 fallback closings (9.0%), longest closing 30 words, longest letter 200 words |
| bank_check | 113/113 ok, 10/10 Experience variants ok |
| selftests | v341 to v347a pass; new selftest_v347b passes (25 labelled sponsorship phrasings, OR-group / SQL / bullet unit checks, end-to-end builds of the 4 postings, 4 flags-off builds equal to baseline_v347a, a one-flag rollback, instructions and hash lock) |
| Names defined more than once | 61 (unchanged) |

## The four real postings

| Posting | Asked | Result |
|---|---|---|
| zoro_fullstack | no sponsorship blocker; keeps relocation line; Ruby not a gap | Met. Blockers none; Notes: "Sponsorship information (not a blocker): "H1B Sponsor Likely" (job-board badge / sponsorship data)." Letter keeps "I am open to relocating." Ruby is an OR-group alternative ("Python, Ruby or Javascript"; Python covered), not a stack gap. Fit Low -> High |
| alml_engineer | no Fleet bullet; OR-groups covered; no "Not%20stated" in outreach | **Partly met.** OR-group covered (recommendation systems is one option of "at least one of", and the LLM-agent option is covered), Fit Medium -> High. Outreach has no "Not%20stated" (fixed in 7a, still true). **The Fleet bullet is still on the page**: see the decision below |
| ust_software_engineer | unchanged apart from SQL coverage | SQL is now a covered requirement term and moves one place earlier in Skills (B3 allows this). **Also changed:** B2 clears its inline OR-groups, so the Notes line "Stack gaps: C#, SQL Server, Azure, GCP" becomes "OR-group alternatives Jay does not have ...". Same rule as zoro's Ruby; resume bullets, projects and Fit (High) unchanged |
| meritore_capgemini | letter names one employer | Met: the letter names only Meritore Technologies LLC. Output identical to 7a |

## Decision for Jay: the alml Fleet bullet

The trigger is fixed. In 7a, alml got the Fleet bullet because the old warehouse rule matched the word "shipping" in
"a track record of shipping ML systems into production". B4 makes that rule fire only on supply-chain / warehouse /
logistics / vehicle-fleet wording, so it no longer fires on alml (or on "shipping software").

With the trigger gone, GoingOnce's normal bullet choice on alml still picks Fleet as its second bullet. The scored
alternative (the plain-code-with-saved-fallback bullet, `goingonce.determ.a`) scores 6 against Fleet's 3, a margin of 3,
below the swap margin of 6, so FAIL-CLOSED keeps the existing choice. Two ways to force it off both break the 10%
blast-radius cap you set, so I stopped and am reporting them instead of shipping:

| Variant | Existing fixtures whose bullets change | List |
|---|---|---|
| AI-preference (AI postings always prefer agents / Negotiate / fallback bullets) | 14 of 120 (cap 12) | amplitude (holdout), booz_allen, brillio, cdi, flowgen, harvey, inspire11, lumen (holdout), monti, quora, raydar_swe, research_phd, roblox, vindexa; plus alml |
| Strict (Fleet only ever on logistics postings) | 22 of 120 | amplitude, anthropic_it, booz_allen, brillio, bti, cardinal, cdi, flowgen, harvey, inspire11, monti, ng_fullstack, quora, raydar_swe, research_phd, roblox, rocketmoney, rockstar, sparkline, tiktok_appsec, twitch_se1, vindexa; plus alml, meritore, zoro |

Both are in the code behind test-only switches (`V347B_AI_PREFER=1`, `V347B_STRICT_FLEET=1`, off by default) so either
can be turned into a real rule later. My recommendation: keep the shipped margin rule, and if you want Fleet gone from AI
postings, approve the AI-preference variant as a deliberate change (it also helps quora, booz_allen and monti, which
already swap under the margin rule).

## B4 bullet changes (shipped, margin 6)

| Fixture | Group | Removed -> added | Scores (margin) |
|---|---|---|---|
| booz_allen | v341_tune | goingonce.fleet.a -> goingonce.determ.a | 3 -> 11 (8) |
| monti | v341_tune | goingonce.fleet.a -> goingonce.determ.a | 3 -> 11 (8) |
| quora | v345_new | goingonce.fleet.a -> goingonce.determ.a | 3 -> 10 (7) |
| raydar_swe | v341_tune | goingonce.fleet.a -> goingonce.determ.a | 3 -> 10 (7) |
| roblox | v341_tune | fraud.compare.a -> fraud.leak.a | 1 -> 9 (8) |

No holdout changed bullets. Full bullet text is in DIFF_REPORT_v347b.md. B4 also logs its scores in report.json
(`bullet_relevance_v347b`) whenever it swaps.

## Self-scores on the four postings (0 to 10)

| Dimension | zoro | alml | ust | meritore |
|---|---|---|---|---|
| Experience selection | 9.5 | 9.5 | 9.5 | 9.5 |
| Experience quality | 9.5 | 9.5 | 9.5 | 9.5 |
| Project selection | 9.5 | 9.5 | 9.5 | 9.5 |
| Project bullet quality | 9.0 | 8.5 | 9.5 | 9.0 |
| Skills selection | 9.5 | 9.0 | 9.5 | 9.5 |
| ATS | 9.5 | 9.0 | 9.5 | 9.5 |
| Senior technical HR | 9.0 | 8.5 | 9.5 | 9.0 |

Below 9.5, and why:
- **zoro project bullets / HR 9.0:** the Fleet bullet (rental cars, truckloads) sits on a full-stack e-commerce posting;
  the interface bullet is the stronger match. Zoro's letter hook is the stand-in that scores "not specific" (9.5, as in 7a).
- **alml project bullets 8.5, HR 8.5:** the Fleet bullet on an AI/ML engineer posting reads as off-topic to a reviewer;
  the fallback or Negotiate bullet would show the LLM engineering the posting asks for (see the decision above).
- **alml Skills / ATS 9.0:** "Languages & Databases" shows only Python and SQL, which is honest (the posting names no
  other language Jay has) but thin; ats_summary still lists recommendation systems as unsupported (it is, B2 only stops
  it counting as a gap).
- **meritore project bullets / HR 9.0:** same Fleet bullet on a general software posting (unchanged from 7a; the Strict
  variant would remove it).

## Assumptions

- **Sponsorship polarity.** "Negative" is the employer's own refusal wording (will not / cannot / unable to / does not
  sponsor, without sponsorship now or in the future, no visa sponsorship, citizenship or green card required,
  "sponsorship requests will not be considered"). Plain authorization wording ("must possess unrestricted permanent US
  work authorization", audit05) is not a sponsorship statement, so it keeps the 7a blocker. Roblox's "the Company may not
  be able to employ candidates for certain visa categories" is unclear: blocker kept plus "check manually". A bare
  heading ("Visa Sponsorship") is classified by the line under it ("Case by case" -> unclear, pinterest).
- **OR-groups.** A member named on its own on another posting line stays a gap (us_cold's Angular). A list of fewer than
  2 or more than 8 members, or a lead-in with no list, is ambiguous and clears nothing. Fit from B2 rises at most one level.
- **SQL.** A `v347b_sql` term affects coverage and Skills order only; it is removed before Fit is computed.
- **B4 margin 6** (score points from posting-line word overlap plus the stated AI / claim-check bonuses). The lead bullet
  of a project never moves; at most one swap per project; the replacement must have the same line count and a unique
  verb; a swap is kept only if the full rebuild reproduces it exactly.
- **bullet_bank.json and the template are not edited**; the bank's informational `built_with` pointer still names the
  older master hash (nothing checks it).
- `tools/` (rehash script and scans) stays out of the zip, as before.
