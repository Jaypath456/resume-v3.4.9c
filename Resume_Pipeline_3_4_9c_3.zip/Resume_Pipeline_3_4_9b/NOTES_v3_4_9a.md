# NOTES v3.4.9a (2026-10-20)

Built from Resume_Pipeline_3_4_8c.zip with the 8c safety method: baseline_v348c saved from the unmodified 8c outputs,
determinism checked, then one fix at a time (predictions frozen before the code, own flag, all fixtures run, gate
against the previous snapshot, new snapshot, golden check). Hash log of the frozen predictors:
3_validation/predict_v349a_*.py with their sha256 in this file's "Predictor freeze" section.

## What Jay needs to do

1. Re-upload 3 Sources: resume_pipeline_v3_2.py (2714d282), master.json (9dd92973), Master_Resume_Context .md
   (f89d59eb). bullet_bank.json, Resume_Template_CURRENT.tex, plan_template.json and bank_check.py are unchanged.
2. Paste 2_PROJECT_INSTRUCTIONS_paste.txt (7,593 characters).
3. Two open decisions (cards in the thread): EBSCO rank #1 (golden row 11 of 12) and the audit's role-family share
   (10.3%, cap 10%). Shipped as recommended: LedgerFlow stays rank #1 on EBSCO; the strict closing-proof rule stays.

## Acceptance results

| Check | Result |
|---|---|
| Determinism (two full runs, all flags on) | IDENTICAL, 128 fixtures |
| Ten new flags off vs baseline_v348c | IDENTICAL (version label only on the two stop reports) |
| Per-fix gates 1-10, then 7b | all PASS, 0 unpredicted, 0 guard failures (3 excepted by amendment 7-A1/7-A2 at fix 7) |
| golden_report.md | **11 / 12 PASS** (ebsco_sde1 FAILS on rank1 only; see Open items) |
| All fixtures | 126 PASS + 2 expected stops (fonzi, cisco_no_title); 126 resumes, all one page |
| bank_check | 118/118 ok, 10/10 Experience variants ok |
| selftests v341-v348c, v349a | all 13 pass |
| audit_v344 | **FAIL by one closing**: 13 role-family closings of 126 built (10.3%, cap 10%); every other audit check passes |
| Instructions | 7,593 characters (< 7,600) |

score_all (resume / letter means; 8c numbers from the same run with the ten flags off):

| Group | v3.4.8c | v3.4.9a | Change |
|---|---|---|---|
| v340_original (57) | 10.00 / 9.98 | 10.00 / 9.98 | none |
| v341_tune (36) | 10.00 / 10.00 | 9.97 / 10.00 | research_phd resume 10.0 -> 9.0 ("R-1 off-target launchops") |
| v342-v347 new | 10.00 / 10.00 | 10.00 / 10.00 | none |
| holdout (20) | 9.85 / 9.97 | **9.80** / 9.97 | twitch resume 9.0 -> 8.0 ("off-target pintos; off-target fraud") |
| golden v349 (4, counted in "all") | 10.0 / 9.5-10.0 | same | giga_swe and ebsco_sde1 letters 9.5: the plan stand-in hook does not name the product (test input, not code) |

Both score drops come from fix 5's one scoring path changing the third project (research_phd: GoingOnce ->
LaunchOps; twitch: RIPPLE -> Pintos), which the old manifest marks as off-target. Both were predicted by
predict_v349a_5.py and are listed in DIFF_REPORT_v349a.md with their scores. The manifest was not edited to hide them.

## Per fix: what changed and the golden rows it fixed

| Fix | Flag | Fixtures changed | Golden rows flipped to PASS |
|---|---|---|---|
| 1 JD reader | jd_sections_v349 | 10 | giga_swe set (LLM engine out, LedgerFlow in, so its resume-wording bullet goes); ebsco_sde1 loses the SQL Server and infrastructure-as-code hard gaps and the React/ReactJS double (row still failing) |
| 2 Years | years_range_v349 | 29 (notes / Fit only) | ebsco_sde1 loses note_experience_years (still failing) |
| 3 Fit | fit_guard_v349 | 1 (flowgen Low -> Medium) | none |
| 4 Bullets | bullet_score_v349 | 60 (bullets only) | none on its own |
| 5 Ranking | ranker_v349 | set changed on 4 of 122 existing (3.3%, stop limit 25%); 20 changed set, rank1 or order | **meritore_jpc** (set and rank1; "10 tool calls" gone) |
| 6 Page order | date_order_v349 | 99 reordered | **giga_swe, zoro_fullstack, alml_engineer, doordash_mdx, figure, elevenlabs, macys** |
| 7 Closing proof | proof_on_page_v349 | closings on 126 report lines; letters on the pages whose proof was off the page | none |
| 7b Closing proof follow-up | proof_on_page_v349 | 9 closings | none (role-family closings 22 -> 13) |
| 8 Copy rule | copy_rule_v349 | 2 (akamai closing, doordash hook) | **akamai_se** ("services for control plane" gone) |
| 9 Skills | skills_dedupe_v349 | 24 (Skills lines only) | ebsco_sde1: JSON leaves Tools (still failing on rank1) |
| 10 Tracker | company_key_v349 | 126 (company_key line) | none |

ust_software_engineer and audible passed from the start and stayed PASS. The per-snapshot reasons are in
3_validation/golden_history.json and golden_report.md.

Fix 7b was added after fix 10: audit_v344 showed fix 7 had doubled the role-family closings (11 -> 22). Its predictions
(predict_v349a_7b.py) were written before its code. It only touches pages whose closing would be the role-family one.

## Amendments (gaps found in a run, never edits to the frozen predictions)

- 2-A1 nvidia_ai_cloud: "for more than 25 years" (company history) is not a years ask, so the false 25+ years note goes.
- 4-A1 akamai_se, 4-A2 chewy, 4-A3 ixl: a project heading follows its bullets after a fix-4 swap (one technology in or
  out); the project, title and slot count are unchanged.
- 7-A1 / 7-A2 lumen: the old closing proof (LLM engine failover) is not on the page. The new closing lets the v3.4.8c F2
  GoingOnce re-pick succeed, so one GoingOnce bullet and the letter's GoingOnce sentence change (Fleet stays off).
- 8-A1 akamai_se: the closing_v348c report lines change with the new closing (the C2 move).
- 9-A1 every fixture whose Skills change: the skills_text_hash report line.

## Assumptions (no questions asked)

- rank1 is the project with the most bullet slots (report.json ranking), as the request defines it. Headings and
  Skills stay by rank, so only the order of the blocks and the tracker's Projects Used follow the date.
- Date ties (LedgerFlow and GoingOnce are both October 2026) keep rank order.
- An anchor project "beats" others unless another project leads by 2 points on standalone + legacy/2.
- The closing proof check uses the evidence ids on the final page; Fraud's result proofs map to their bullets
  (fraud.graphsage_result -> fraud.graphsage, fraud.edge_ablation_result -> fraud.edge_ablation) and
  launchops.ownership -> launchops.workflow.
- "our" in the hook becomes the company possessive ("DoorDash's backend systems"); "we" / "us" fails the build.
- Alias groups: React / ReactJS / React.js -> ReactJS unless the posting names exactly one spelling, which is kept.
- company_key is a matching key in tracker_row.json, not a sheet column (the sheet keeps its 11 columns). score_all and
  audit_v344 now accept that one extra key.
- The golden stand-in plans (4 new postings) are test inputs written for this build; they copy no "our / we / us" and
  no posting typo.

## Open items

1. **EBSCO rank #1.** golden_set.json wants LaunchOps as rank #1 on ebsco_sde1; fix 5 gives LedgerFlow (combined 26.9
   vs RIPPLE 22.5, LaunchOps 16.9). No general rule moves it without changing other pages (a "JavaScript is a must"
   rule would also change roblox). Shipped with LedgerFlow (recommended on the card); the row is 11/12.
2. **Role-family closings 10.3%.** acme_cloud and audit06 have no on-page proof the letter does not already state, and
   a third project would break the two-projects-per-letter rule. Shipped strict (recommended on the card).
3. perplexity's closing reads "engineer are responsible for end-to-end projects from training" (unchanged since
   v3.4.8c; not one of the ten fixes).
4. predict_v349a_10.py strips a broader suffix list (services, group, holdings) than the code; no fixture differed.

## Selftests

All 13 pass on the final Sources: selftest_v341 to v346, v347a, v347b, v347c, v348a, v348b, v348c and v349a
(selftest_v342 keeps its six SKIP lines for the draft-variant checks v3.4.3 replaced).

Older selftests accept v3.4.9a and 33 flags. selftest_v348c runs its v3.4.8c end-to-end checks with the ten v3.4.9a
flags off (they compare with baseline_v348b, made before these fixes); selftest_v345's Quora check reads rank #1 from
ranking_v349.

## Predictor freeze

```
25d0d8c19e1f76607716a1712e90616bf6109df621bb268ab79650625348cc86  predict_v349a_1.py
605e40e8bc5c047c5c8ccbf77970b7cab569ebb442d8c0d327d2bd7415175cf1  predicted_changes_v349a_1.json
Mon Oct 19 23:02:46 UTC 2026
aebcaf97875a61ac2acd03214036cde9afbefb4d0ea938473106115b360e9e07  predict_v349a_2.py
Mon Oct 19 23:07:06 UTC 2026
f5d2b82d640caa107f90a51d7c09e813d3b82b6b6579c4871a066fb3f22da3eb  predict_v349a_3.py
Mon Oct 19 23:08:16 UTC 2026
8294316e612aa5f3a6a1836006791098a78efb7dcff53c02d55940b74daa2927  predict_v349a_4.py
Mon Oct 19 23:15:13 UTC 2026
700544737e2ed7c1c2c907d55121cf0ecb707d5021df9c9277ff4868772fc3be  predict_v349a_5.py
Mon Oct 19 23:44:44 UTC 2026
1d80e4540c94898cea9c42290e2b3cc27a7ae54e694415821079d8353c66b8a6  predict_v349a_6.py
Mon Oct 19 23:50:43 UTC 2026
49eb7e84dcc1de721846c889044a0548392e8844ee09338aa9882d380c5a4613  predict_v349a_7.py
Mon Oct 19 23:53:02 UTC 2026
predict_v349a_8.py c99e530b467fbba5c9df34f36811764dc9cf118e3a5399661cf2332dc796a4a3 2026-10-20T00:08:03Z
predict_v349a_9.py 44e23628421cf75178d09672c1e7b391caa35963ec8196ec104a322f6221dd86 2026-10-20T03:11:04Z
predict_v349a_10.py 5a4bdc29446cf0980670d7a9f5b21dc3785fd347df18aec9f6592ac9d6738c2c 2026-10-20T03:12:01Z
predict_v349a_7b.py 4007015818933fe1b94897e7f352442d464146f14acf06b85436b650201adc44 2026-10-20T05:05:15Z
predicted_changes_v349a_7b.json 74ba11b5c60a02484af4511191223d2dbe05e8a7c6f01de1688449405ac88a4c
```
