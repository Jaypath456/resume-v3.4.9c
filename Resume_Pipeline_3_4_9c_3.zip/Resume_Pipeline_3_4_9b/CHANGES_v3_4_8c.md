# Resume pipeline v3.4.8c: changes (2026-10-19)

Built from Resume_Pipeline_3_4_8b.zip. A visible-quality build, done one fix at a time in the order T, W, F, S, J, C.
For each fix: predictions written and frozen before its code (`3_validation/predict_v348c_<FIX>.py` ->
`predicted_changes_v348c_<FIX>.json`, never edited afterwards; gaps found later are in
`predicted_changes_v348c_<FIX>_amendments.json`), the fix behind its own master.json `v347_flags` entry (default true),
all 124 fixtures run, the gate `diff_gate_v348c.py gate <FIX> <previous snapshot> <new snapshot>` passed, and the new
snapshot saved (`3_validation/snap_v348c_T`, `_W`, `_F`, `_S`, `_J`, `_C`). Every changed line is attributed to exactly one
fix in DIFF_REPORT_v348c.md.

With the eight new flags off (test-only `--regression-v347-flags-off=...`, or `V347_FLAGS_OFF=...` for run_all.py) every
fixture equals `3_validation/baseline_v348b/` (the unmodified 8b outputs). The facts are unchanged: Jay graduates in
December 2026 and can start work in February 2027.

Hash lock: pipeline fb67023f | master a5641f0c | bank 6ce82778 | template dc281778 (unchanged) | context md cf22e3fc.
plan_template.json (4358f1e0) and bank_check.py (81b28185) are unchanged.

Code changes edit only final definitions (`eligibility_blockers`, `auto_bank_selection`, `_v347b_bullet_relevance`,
`_v347b_rerun_factory`, `_v347c_retry`, `_v347c_letter_swap`, `build_project_block`, `build_skill_states`,
`_v347_heading_placement`, `validate_ats_coverage`, `_v344_closing`, `main_v3_1`), plus `V347_FLAG_NAMES` (23 flags) and
`PIPELINE_VERSION` ("v3.4.8c"); new helpers live in a "v3.4.8c layer" before `if __name__`. Names defined more than once
stay 61. No file is renamed (CHANGES_v3_4_8b.md is a copy of the old CHANGES.md).

## T. Start-date parsing (flag `start_date_parse_v348`)

"2026 Start", "Start date: 12/01/2026", "Target start date: 12/01/2026", "commit to an onboarding date by end of year 2026"
and "start in (early / late / mid) 2026" count as a start before February 2027 (a bare year counts as December, so
"start in 2027" does not). They add the Timing note "Timing check: the posting mentions a start before February 2027.
Graduates December 2026; available to start February 2027 (subject to OPT/EAD approval)." Never a blocker, never a Fit
change. Changed: cdi, tiktok_appsec (report notes and the tracker Blockers "start date" label only).

## W. Bank wording (flag `bank_wording_v348`)

New bank variants with the same facts (bullet_bank.json `v348c.replaces`); the old ids stay and are used only with the
flag off. With the flag on the new id takes the old id's place in the selector.
- goingonce.ui.c replaces goingonce.ui.a (no filler tail).
- ripple.git.c replaces ripple.git.b: "Validated every finished code change with RIPPLE's own Git-diff check, which runs
  after the change is made, reads its Git diff, and flags unexpected edits, missing tests, and stale callers."
- ripple.eff.b replaces ripple.eff.a: "Measured agent usage at about 10 tool calls and about 17 model calls per run, with
  under one duplicate call."
- ripple.cc.d replaces ripple.cc.a: "... checking its output with RIPPLE's 241-test suite ..."
Every variant passes bank_check (2-line geometry or 1-line fill, unique verb, not an Experience verb). 22 resume pages
change (listed in NOTES); 63 fixtures change in all (the rest only in report lines that name the variant id).

## F. Fleet off non-logistics pages (flags `fleet_language_model_v348` = F1, `fleet_repick_v348` = F2)

- F1: goingonce.determ.b, the plain-code bullet without "Claude" (2 lines, verb "Kept", adds no Skills term, same
  evidence as goingonce.determ.a), with its letter sentence. It is a last resort of the v3.4.7c in-place swap: used only
  when no other GoingOnce bullet qualifies or the best one is not reproduced by the selector.
- F2: where the in-place swap still fails, Fleet is removed from the GoingOnce candidates before selection and the
  normal selector picks the GoingOnce set (unpinned first, then with the other projects held to their bullets). Only
  GoingOnce bullet lines change, plus the letter's Fleet sentence; projects, order, slot counts, headings and Skills are
  the 8b ones. FAIL-CLOSED: the 8b page stays and report.json `fleet_v348c` says why.
- Result: all 16 non-logistics pages that still showed Fleet in 8b lose it; us_cold (a warehouse posting) keeps it,
  logged with its logistics line.

## S. Skills lines (flag `skills_lines_v348`)

"Languages & Databases" lists languages first, then databases, each group in its current order (S1). A line with fewer
than 3 items gains master-supported languages / databases that the page's own bullets show, up to 3 (S2: alml, quora,
research_phd gain PostgreSQL). No other Skills line moves; report.json `skills_lines_v348c` logs the change. 99 fixtures.

## J. Heading move (flag `heading_move_v348`)

When the v3.4.7a A2 rule takes a posting-named technology off a heading and no other heading names it, it joins the
heading of the selected project whose bullets show it, only if that heading has fewer than 4 technologies (never a
fifth, nothing displaced, Skills unchanged). ats_coverage lists "header" in also_in only when a rendered heading shows
the term. 10 pages gain "JavaScript" on the LaunchOps heading; meridian_sw logs a move it could not make (4 already).

## C. Closings (flags `closing_proof_map_v348` = C1, `closing_specific_v348` = C2)

- C1 proof map: model training / optimization / accuracy / latency -> Fraud's measured results when Fraud is on the page
  (new master proofs fraud.graphsage_result and fraud.edge_ablation_result restate master facts; then the edge-type
  ablation and the leakage controls); an AI responsibility whose 8b proof was a Git-diff or Fraud fact -> RIPPLE's
  evaluation (then RIPPLE's claim checks, the LLM engine's claim validation or failover). Never a letter fact.
- C2 specificity: score = +1 per word naming the product, team or users, -1 per generic word; switch only when the 8b
  responsibility scores <= 0 and a responsibility line scores at least 2 higher with at least 2 domain words, is not a
  mission line or boast, and names its own proof kind. Otherwise the 8b closing stays.
- Only the closing sentence changes; a family closing or one over the word budget stays; all validators pass.
  8 closings change (alml, audit12, doordash_mdx, elevenlabs, figure, flowgen, klaviyo, lumen).

## Tooling

`3_validation/diff_gate_v348c.py` (snapshot / identical / per-fix gate with guards), `predict_v348c_*.py`, the
amendment files, `selftest_v348c.py`; selftests v342 to v348b accept v3.4.8c and turn the eight new flags off wherever
a build is compared with an older baseline. Test-only debug hook: `V348C_DEBUG=<path>` writes one run's C2 candidates.
