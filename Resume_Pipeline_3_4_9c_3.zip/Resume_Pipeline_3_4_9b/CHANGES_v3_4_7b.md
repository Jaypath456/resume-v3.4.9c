# Resume pipeline v3.4.7b: changes (2026-10-18)

Built from Resume_Pipeline_3_4_7a.zip. Four fixes (B1 to B4), each behind its own switch in master.json `v347_flags`
(`sponsorship_polarity`, `or_groups`, `sql_parse`, `bullet_relevance`; default true). With all four off, every fixture
equals `3_validation/baseline_v347a/` (the unmodified 7a outputs), apart from the version label on the two stop reports.

Hash lock: pipeline 3332eea0 | master 5ea23649 | bank d56f0743 (unchanged) | template 1309898b (unchanged) |
context md b86a9f06. plan_template.json and bank_check.py are unchanged. Code changes edit only the final definitions of
eligibility_blockers, apply_auto_plan_fields, parse_jd_requirements, gating_assessment, _v345_bank_prefer,
auto_bank_selection and main_v3_1, plus new helpers in a "v3.4.7b layer" block before `if __name__`; names defined more
than once stay 61. bullet_bank.json and Resume_Template_CURRENT.tex are not edited.

Changed Sources: `resume_pipeline_v3_2.py`, `master.json` (4 new `v347_flags` entries; md pointer),
`Master_Resume_Context_LEAN_CURRENT_v3_2.md` (new section 0-v347b). Other changed files: `2_PROJECT_INSTRUCTIONS_paste.txt`
(version and hash lock only), `0_SETUP_STEPS.txt`, selftest_v342 to v347a (version checks only), new `selftest_v347b.py`,
`predict_v347b.py`, `predicted_changes_v347b.json`, `diff_gate_v347b.py`, `baseline_v347a/`. The old CHANGES.md is now
CHANGES_v3_4_7a.md.

---

## Safety steps (same as 7a)

1. `baseline_v347a/`: all 124 fixtures on the unmodified 7a Sources. Two 7a runs identical (determinism).
2. `predict_v347b.py` restates each rule without the new code and writes `predicted_changes_v347b.json` from the baseline.
3. `diff_gate_v347b.py gate`: every changed line must match a prediction (unpredicted on originals / holdouts fails),
   plus guards: no project heading changes (G0); negative sponsorship blockers before == after (B1); Fit never drops and
   rises at most one level unless B1 removed a non-negative blocker (B1 / B2); bullets change on at most 10% of existing
   fixtures (B4). Result PASS (DIFF_REPORT_v347b.md).
4. Two 7b runs identical; all-flags-off run identical to baseline_v347a.

## B1 sponsorship polarity (`sponsorship_polarity`)

Each sponsorship sentence is classed negative / positive / neutral / badge / unclear / none (a short heading such as
"Visa Sponsorship" is read together with a short value line under it). Only a negative sentence keeps a sponsorship
blocker; if the 7a blocker came from a positive, neutral or badge line and a negative sentence exists elsewhere, the
blocker moves to that sentence. Unclear wording keeps the 7a blocker (FAIL-CLOSED) and Notes says
"Sponsorship wording unclear: check manually (...)". Positive, neutral and badge lines go to Notes as
"Sponsorship information (not a blocker): ...". Plain authorization wording ("unrestricted permanent US work
authorization") is not a sponsorship statement and keeps 7a behaviour. Log: report.json `sponsorship_v347b`.
- zoro_fullstack: blocker "H1B Sponsor Likely" (badge) removed; Fit recomputed Low -> High; tracker Blockers empty.
- Kept: audit03, audit04, audit06, audit07, cardinal, fidelity, inspire11, meridian_bank (negative, 8 = 8);
  roblox (unclear), audit05 (authorization wording).
- Notes only: anthropic_it, flowgen (positive), paypal (neutral), pinterest (unclear, no blocker in 7a).

## B2 OR-groups (`or_groups`)

"at least one of (the following):", "one or more of" and "any of" followed by list lines, and an inline "A, B, or C"
(after "such as / including / like / e.g. / in at least one of ..."), form one OR-group. If any member is covered (a
supported term, the agent evidence for agent members, or the claim-check evidence for "hallucinations" / "grounding"),
the other members leave the hard-gap and stack-gap lists and never lower Fit; Notes lists them as "OR-group
alternatives Jay does not have (...)". FAIL-CLOSED: a member also named on its own on another line stays a gap (us_cold
Angular), and a group with fewer than 2 or more than 8 members or no list lines is ambiguous and clears nothing. Fit can
rise at most one level. Log: report.json `or_groups_v347b`.
- alml_engineer: "recommendation systems" is one option of "Deep expertise in at least one of"; covered by the LLM-agent
  option; Fit Medium -> High.
- zoro_fullstack: Ruby ("Python, Ruby or Javascript") is not a stack gap.
- ust_software_engineer: C#, SQL Server, Azure, GCP leave the stack-gaps note (each sits in a covered inline group).
- Also: allergan, apple, assetwatch, atoms, audit09, bti, linkedin, lumen, monti, twitch, wgu (Notes / gap lists only).

## B3 SQL in database lines (`sql_parse`)

A literal "SQL" in a database requirement line ("databases such as SQL Server, MySQL, ...") becomes a requirement term
(priority medium, supported). It changes coverage and, where the requirement order moves, Skills order; it is removed
before Fit is computed. Log: report.json `sql_term_v347b`. Fixtures: ust_software_engineer (SQL one place earlier in
Skills), assetwatch, microsoft, swisslog, us_cold.

## B4 bullet relevance (`bullet_relevance`)

Trace: in 7a, `_v345_bank_prefer` preferred GoingOnce's Fleet bullet whenever the posting matched its warehouse regex,
which includes `\bshipping\b`, so alml's "a track record of shipping ML systems into production" fired it. Fix: the
preference fires only on supply-chain / warehouse / logistics / vehicle-fleet wording (logistics-sense "shipping" only;
"device fleet" and "support the fleet" do not count).

Scoring: within each selected project, bullets are scored against the posting's role lines (stem overlap, +3 for
GoingOnce's agents / Negotiate / fallback bullets on AI postings, +3 for RIPPLE / claim-check bullets on LLM-limitation
lines). One non-lead bullet per project is swapped only when a same-size bullet with a new evidence id and a unique verb
beats it by at least 6 (FAIL-CLOSED below that) and the full rebuild reproduces the swap exactly. Fleet is a candidate
only on logistics postings. Projects, order, slot counts, line counts and verb uniqueness never change. Log: report.json
`bullet_relevance_v347b` (when a swap happens); `V347B_DEBUG=<path>` dumps every score.
- Swaps (5 of 120 existing, cap 12): booz_allen, monti, quora, raydar_swe (Fleet -> plain-code fallback), roblox
  (model comparison -> leakage control). Scores in DIFF_REPORT_v347b.md and NOTES.
- alml_engineer still shows Fleet: the fallback bullet's margin is 3 (6 vs 3). Two stronger variants are in the code
  behind test switches, off by default: `V347B_AI_PREFER=1` (14 existing fixtures change) and `V347B_STRICT_FLEET=1`
  (22). Both exceed the cap, so they are reported in NOTES, not shipped.
