# Resume pipeline v3.4.8b: changes (2026-10-19)

Built from Resume_Pipeline_3_4_8a.zip. ONE FACT CHANGE, confirmed by Jay and the university: Jay graduates in December 2026
(was February 2027); he can start work in February 2027 (unchanged). Graduation and start date are two separate facts
everywhere. One master.json `v347_flags` entry, `graduation_dec2026_v348` (default true). With it off (test-only
`--regression-v347-flags-off=graduation_dec2026_v348`, or `V347_FLAGS_OFF=graduation_dec2026_v348` for run_all.py) every
fixture equals `3_validation/baseline_v348a/` (the unmodified 8a outputs), apart from the version label on the two stop reports.

Hash lock: pipeline 31820fef | master 577bdd6d | bank d56f0743 (unchanged) | template dc281778 | context md c7d271da.
plan_template.json (4358f1e0) and bank_check.py (81b28185) are unchanged.

Code changes edit only the final definitions of `grad_window_warning`, `_grad_window_ok`, `_v342_grad_window`,
`eligibility_blockers`, `gating_assessment`, `blockers_summary`, `parse_jd_requirements`, `compose_bank_cover_letter`,
`validate_cover_letter_v32`, `_v346_post_run`, `assemble_latex`, `skills_text_hash`, `_prepare_runtime_cache` and
`main_v3_1`, plus `V347_FLAG_NAMES` / `PIPELINE_VERSION` ("v3.4.8b"), and add new helpers in a "v3.4.8b layer" block
before `if __name__`; names defined more than once stay 61. No file is renamed (CHANGES_v3_4_8a.md is a new copy of the
old CHANGES.md); bullet_bank.json is not edited.

## D1 facts

- master.json `education.masters`: dates "August 2025 -- Expected December 2026", `graduation` "December 2026",
  `available_to_start_work` "February 2027, subject to approved OPT/EAD", `graduation_confirmed` (the 2026-10-19 note);
  `degree_conferral` (February 1, 2027) and the computed OPT date `earliest_post_completion_opt` (February 2, 2027) are
  removed. `coursework_completion` (December 16, 2026) is unchanged.
- `candidate_eligibility`: `graduation` and `available_to_start_work` added (blocker reporting only).
- `qualification_facts`: "graduation in 2027" / "graduating in 2027" / "2027 graduate" became "graduation in December
  2026" / "graduating in December 2026" / "December 2026 graduate".
- `cover_letter_rules.p2`, `cover_letter_bank._rules[1]`: "graduation December 2026, start work February 2027".
- Context md: new section 0-v348b first; the section-4 Education block, the old logistics rules (0-v346, 0b, 0c, P2 and
  checklist lines) and the degree-years note now say December 2026 / February 2027; the OPT-date line is gone.
- Flag off: `_prepare_runtime_cache` puts the v3.4.8a values back into the loaded master (`V348B_OLD_MASTER`), so a
  flag-off build reads exactly what v3.4.8a read; `skills_text_hash` keys the cache with the 8a template hash.

## D2 resume

Resume_Template_CURRENT.tex Education line: `August 2025 -- Expected December 2026` (same length; every page still one
page). Flag off: `assemble_latex` writes the 8a line. Post-run check `_v348b_post_run` fails a build whose resume lacks the
new line or whose letter / Notes state a February 2027 graduation.

## D3 letters

`compose_bank_cover_letter` writes the letter as before and then swaps the logistics sentence:
"I graduate in December 2026 and can start work in February 2027." / internships "My Master's in Computer Science at the
University at Buffalo is expected in December 2026, and I can start work in February 2027." A letter the one-word-longer
full-time sentence would push past 200 words is rebuilt with the new sentence in place, so the existing 200-word budget
refits it (harvey and monti: the closing's responsibility phrase is shortened). The start-clause validator passes both
sentences; `validate_cover_letter_v32` fails a letter that calls February 2027 a graduation date.

## D4 eligibility and timing

- Graduation windows (`v348b_window_ok`, `v348b_grad_window`): Jay's December 2026 must fall inside the stated window with
  one month of tolerance (the v3.4.2 single-date rule): ranges ("December 2026 - June 2027", "between ... and ...",
  "Winter 2026 - Spring 2027"), lists ("December 2026 or May/June 2027"), "by" / "after" dates, seasons and bare years
  ("graduating in 2026"; a bare "2027" is within one month). A "<year> Start" is a start date, not a graduation.
  The met-graduation ATS term is "graduation in December 2026" (was "graduation in 2027").
- Graduating-class notes: a 2026-class posting keeps a Timing note (a 2026 cycle may start before February 2027); an
  earlier class gets the "confirm the hiring cycle" note. Start-date checks keep the February 2027 threshold.
- Enrollment (`v348b_enrollment`): an internship that requires enrollment during or after the internship (unless it
  clearly ends by December 2026), or that starts after December 2026, gets `enrollment_required` (a note that caps Fit at
  Low as before; never a skip).
- Reasons, Notes and tracker labels say December 2026 ("graduation window excludes December 2026", "enrollment required
  past December 2026"); Timing notes read "Graduates December 2026; available to start February 2027 (subject to OPT/EAD
  approval)." The degree-years note says "Jay's Master's (expected December 2026)". No computed OPT date anywhere.
- The new-grad layout trigger (a 2026 or 2027 class, new grad, early career ...) already fits a December 2026 graduate and
  is unchanged; no layout changed on any fixture.

## D5 instructions

`2_PROJECT_INSTRUCTIONS_paste.txt`: version, step 4d "(Jay graduates December 2026 and starts work February 2027)", hash
lock. 7,581 characters. Outreach notes never name dates (the O2 validator forbids digits; selftest_v348b checks the
templates); nothing in the outreach changed on any fixture.

## D6 selftests (expected text only)

- selftest_v346: the start-clause test letters use the December 2026 sentences (3 lines).
- selftest_v347a: the A1 relocation test paragraph and the zoro e2e letter check use "I graduate in December 2026 and can
  start work in February 2027." (3 lines); the A6 version check accepts v3.4.8b.
- selftest_v347b / v347c / v348a: the new flag goes off where a build is compared with baseline_v347a / v347b / v347c;
  v348a's version / flag-count / template checks accept v3.4.8b (the template now changes).
- selftest_v342 to v347c: version lists accept v3.4.8b. No fixture expectation in manifest.json asserted February 2027.
- New: selftest_v348b.py, predict_v348b.py, predicted_changes_v348b.json, predicted_changes_v348b_amendments.json,
  diff_gate_v348b.py, baseline_v348a/, GREP_PROOF_v348b.txt.
