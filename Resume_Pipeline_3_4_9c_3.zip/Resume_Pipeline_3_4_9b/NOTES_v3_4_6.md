# Resume pipeline v3.4.6: notes

Built 2026-10-16 from Resume_Pipeline_3_4_5.zip: the five confirmed fixes only (details and before/after snippets in
CHANGES.md).

## What Jay needs to do

1. **Sources: re-upload 4 of the 7 files.** Changed: `resume_pipeline_v3_2.py`, `master.json`, `bullet_bank.json`,
   `Master_Resume_Context_LEAN_CURRENT_v3_2.md` (new section 0-v346 and the internship logistics line).
   Unchanged: `Resume_Template_CURRENT.tex`, `plan_template.json`, `bank_check.py`. Uploading all 7 again is fine.
2. **Project instructions: paste the new `2_PROJECT_INSTRUCTIONS_paste.txt`** (7,592 characters; limit 7,600). It has
   the new hash lock, "pipeline v3.4.6", "variants A-J", and a tagline line saying an unsupported scope phrase fails the run.
3. **Tracker sheet: nothing new.**
4. Optional: send `Judge_Batch_v3_4_6.md` (the same 11 postings as the v3.4.5 batch) to the judge.

## Hash lock

| File | sha256 |
|---|---|
| resume_pipeline_v3_2.py | 7117ff07… (full value in the instructions) |
| master.json | d1733399… |
| bullet_bank.json | d56f0743… |
| Resume_Template_CURRENT.tex | 1309898b… (unchanged) |
| Master_Resume_Context_LEAN_CURRENT_v3_2.md | 8c6de951… |
| plan_template.json | 4358f1e0… (unchanged) |
| bank_check.py | 81b28185… (unchanged) |

## Results

| Check | v3.4.5 | v3.4.6 |
|---|---|---|
| Fixtures | 120: 118 pass + 2 expected stops | 120: 118 pass + 2 expected stops (fonzi, cisco_no_title) |
| v340_original (53), v341_tune (36), v342_new (6), v343_new (2), v344_new (2), v345_new (1) | 10.00 | 10.00 / 10.00 on every group, no ranking or Fit change |
| audit_v344 | PASS, 11 of 118 = 9.3% fallback closings | PASS, 11 of 118 = 9.3%, longest closing 30 words, longest letter 200 words |
| bank_check | 113/113, 9/9 Experience variants | 113/113, 10/10 Experience variants (J added) |
| selftests | v341-v345 pass | v341-v346 pass (v346: 54 checks, 4 end-to-end builds incl. the bad-tagline FAIL) |
| Pages with two "Developed" Experience openings | 92 of 118 | 0 of 118 |
| Letters without a start clause in paragraph 2 | 2 (figure, nvidia: internships) | 0 |
| Names defined more than once | 61 | 61 |

**Holdouts (20, never tuned, reported separately):** resume 9.85, letter 9.97, the same as v3.4.5. Still below 9.5:
acme_cloud, twitch, linkedin_ai (unchanged). No holdout's ranking, Fit, closing or letter changed; the only change on
holdout pages is the item-5 verb swap (items 1 to 4 touch no holdout).

## Acceptance: the 11 previously judged packages (re-run, in `packages/`)

| Package | Status | "Developed" Experience openings (v3.4.5 -> v3.4.6) | RIPPLE tools bullet | Daphne/ASGI | Letter start clause (v3.4.5 -> v3.4.6) | Tagline check |
|---|---|---|---|---|---|---|
| allergan | PASS | 1 -> 1 | not on page | absent (posting does not ask) | yes -> yes | pass, no scope phrase |
| audible | PASS | 2 -> 1 | not on page | absent | yes -> yes | pass, no scope phrase |
| audible_md | PASS | 2 -> 1 | not on page | absent | yes -> yes | pass, no scope phrase |
| doordash_mdx | PASS | 2 -> 1 | code-analysis (wording changed here) | absent | yes -> yes | pass, no scope phrase |
| elevenlabs | PASS | 2 -> 1 | code-analysis | absent | yes -> yes | pass (new stand-in tagline) |
| figure | PASS | 1 -> 1 | code-analysis | absent | **no -> yes** | pass, no scope phrase |
| laminar | PASS | 2 -> 1 | code-analysis | absent | yes -> yes | pass, no scope phrase |
| macys | PASS | 2 -> 1 | not on page | absent | yes -> yes | pass, no scope phrase |
| quora | PASS | 1 -> 1 | code-analysis | absent | yes -> yes | pass, no scope phrase |
| twitch_se1 | PASS | 2 -> 1 | not on page | absent | yes -> yes | pass: "live services" backed by the LaunchOps live-quiz service bullet |
| us_cold | PASS | 2 -> 1 | not on page | **shown in Skills** ("Working experience with one or more web application servers") | yes -> yes | pass, no scope phrase |

"Developed ... Developed" was on 8 of the 11 pages in v3.4.5 (the 8 the judge flagged) and is on none now; allergan,
figure and quora never had it, because Go Digital is off on those new-grad pages.

**Tagline validator fired as intended:** ElevenLabs re-run with the old tagline `Master's CS student building
permissions and platform services for full-stack products.` exits 2 with status FAIL:
`tagline_unsupported_scope: "permissions" (trust / policy domain: no selected bullet or Experience line names
permissions); "platform services" (platform / product scope: no selected bullet or Experience line names platform +
services)`. selftest_v346 repeats this end to end.

**New-grad layout confirmed byte-identical:** on all 32 new-grad fixture pages the layout record (section order,
omitted Experience, slots by rank, slot fallback) and the PERSONAL PROJECTS block equal v3.4.5, apart from the item-1
word on the four pages with that RIPPLE bullet. Go Digital is dropped on the same 26 new-grad pages and kept on the same 6.

## Assumptions

- **Item 5 verb and bullet:** I varied the Go Digital bullet ("Developed" -> "Authored"), not the Thesis one. The
  Thesis bullet's variant F also opens with "Developed", so changing Go Digital is the only single-bullet change that
  removes the repeat on every page. "Built", the suggested verb, already opens the Thesis heartbeat bullet (a new
  repeat), and the other plain verbs (Created, Wrote, Coded, Designed) open project bullets in the bank. "Authored"
  is in master's own verb taxonomy ("writing a substantial implementation or system component") and no bank bullet
  uses it. It is now in banned_project_verbs, which also rules out the unused project verb "Co-authored".
- **Item 4 scope:** the validator checks the model-written `tagline_text` (tagline_id "custom"). The 12 master
  taglines are Jay-approved text chosen by id and are not checked. "Backed" means one bullet or Experience line on the
  page names every word of the phrase. Skills and project headings do not count, as the request says "selected
  bullet or Experience line".
- **Item 4 strictness:** all words of a flagged phrase must be on one line. This is why audit09's stand-in
  "payment backends" now fails (its page says "payment API") and was changed to "payment APIs". Generic qualifiers
  (reliable, tested, maintainable, ...) are ignored inside a phrase.
- **Item 2 shown as "Daphne/ASGI"**, the supported-pool name in master (the "or equivalent" form), in Skills > Tools.
  It is offered first among JD-named skills; a post-run check fails the build if it ever does not show.
- **Item 3 wording:** internships now say "..., and I can start any time from that month." This is true to master
  (graduation February 2027; earliest post-completion OPT February 2, 2027) and does not promise a start "soon after"
  or before graduation. No visa or OPT wording was added.
- **Failing the build** means report status FAIL plus exit code 2. Post-run validator failures used to leave the
  exit code at 0; they now return 2 as well.
- Fixture stand-ins changed: the elevenlabs tagline (the leak itself) and the audit09 tagline (see above).
- The judge's "possible fabrications" that are in master are not defects; nothing new was claimed. Fraud stays solo,
  GoingOnce stays "with a four-person team".
- Older selftests updated for v3.4.6: version checks (v342-v345), the variant list (A-J) in v343, and the Experience
  bullet count (7) in v342.
