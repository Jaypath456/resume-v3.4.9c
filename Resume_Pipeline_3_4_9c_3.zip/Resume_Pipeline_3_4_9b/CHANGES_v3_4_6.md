# Resume pipeline v3.4.6: changes (2026-10-16)

Built from Resume_Pipeline_3_4_5.zip. Five small, independent fixes, nothing else. No ranking, cover letter structure
(beyond item 3), new-grad layout or Go Digital drop logic was touched.

Hash lock: pipeline 7117ff07 | master d1733399 | bank d56f0743 | template 1309898b (unchanged) | context md 8c6de951.
plan_template.json and bank_check.py are unchanged. Code changes edit the final definition of each function in place,
plus new helper names in a "v3.4.6 layer" block before `if __name__`; the count of names defined more than once stays 61.

Changed files: `resume_pipeline_v3_2.py`, `master.json`, `bullet_bank.json`, `Master_Resume_Context_LEAN_CURRENT_v3_2.md`,
`2_PROJECT_INSTRUCTIONS_paste.txt`, `0_SETUP_STEPS.txt`, `3_validation/manifest.json` (two stand-in taglines),
`3_validation/selftest_v342.py` to `selftest_v345.py` (version and count checks), new `3_validation/selftest_v346.py`,
`EXPERIENCE_VARIANTS_REVIEW.md`, `RULES_CATALOGUE.md`.

---

## 1. RIPPLE bullet wording ("static-analysis" to "code-analysis")

**Bank (`bullet_bank.json`, ripple.tools.b), before:**
```
Integrated seven static-analysis tools into the agent's tool-calling loop under a cap of 25 calls per task, with Python code checking each claim against evidence before it enters the report.
```
**After:**
```
Integrated seven code-analysis tools into the agent's tool-calling loop under a cap of 25 calls per task, with Python code checking each claim against evidence before it enters the report.
```
Master's evidence line (unchanged): `"ripple.analysis_tools": "It uses seven code-analysis tools with a cap of 25 tool calls per task."`
The other two tools variants (ripple.tools.a, ripple.tools.s1) already said "code-analysis". The bullet still renders
2 lines (tail fill 0.53). `bank_check`: 113/113 ok, 10/10 Experience variants ok.

**Output, DoorDash MDX page, before / after:** the same text as above. The fixture pages that carried the old wording
(doordash_mdx, nvidia_infra, raydar_swe, umich) changed in this one line only.

## 2. Daphne/ASGI for web application server postings

**Code (final `v345_jd_named_skills`), added:**
```python
# v3.4.6 (item 2): a web application server / ASGI / async server line with LaunchOps on the page names Daphne/ASGI
if _V346_DAPHNE in cat_of and _v346_asgi_line(plan, raw):
    named.insert(0, _V346_DAPHNE)
    ...  # also registered as JD-named for the v3.3 Skills gate (as OAuth/Auth0 is)
```
Trigger: `(web )?application server(s)`, `app server(s)`, `ASGI`, `async(hronous) (web|python|http )?server(s)`, and only
when LaunchOps is one of the three projects on the page. "Async workflows / processing / patterns" do not count, so
audit12, LinkedIn and Klaviyo stay without it (selftest_v346 checks this). A post-run check fails the build
(`asgi_server_not_shown`) if the posting asks and LaunchOps is on the page but Daphne is not shown.

**Output, US Cold Storage (posting line "Working experience with one or more web application servers"), before:**
```
Tools: Maven, Git, Redis, Apache Kafka, GitHub Actions, nginx, WebSockets, AWS (EC2/RDS)
```
**After:**
```
Tools: Maven, Git, Redis, Apache Kafka, GitHub Actions, nginx, Daphne/ASGI, WebSockets, AWS (EC2/RDS)
```
It is the only one of the 118 built fixtures whose posting asks for one, so it is the only page that changed.

## 3. Letter start availability (cover_letter_rules.p2)

Audit of the letter templates: the full-time logistics sentence already says "I graduate in February 2027 and can start
work that month." The internship sentence ("My Master's ... is expected in February 2027.") had no start clause. It is
the only template without one.

**Code (final `compose_bank_cover_letter`), added:**
```python
# v3.4.6 (item 3): the internship logistics sentence states start availability too (cover_letter_rules.p2)
paras = [p.replace(_V346_INTERN_LOGISTICS, _V346_INTERN_LOGISTICS_START) for p in paras]
```
**Validator (post-run):** paragraph 2 of every cover letter must match a start clause ("can start", "available to
start", "start work", ...). If not, the build fails with `cover_letter_start_availability_missing`. All 118 built
letters pass.

**Output, Figure (internship), before:**
```
My Master's in Computer Science at the University at Buffalo is expected in February 2027. I am open to relocating.
```
**After:**
```
My Master's in Computer Science at the University at Buffalo is expected in February 2027, and I can start any time from that month. I am open to relocating.
```
Two fixture letters changed (figure and nvidia, the two internship postings); both stay under 200 words (Figure 181).

## 4. Script-side tagline validator

**Code (new, `v346_tagline_unsupported` + `_v346_post_run`):** a checked term list `V346_TAGLINE_SCOPE_TERMS` with five
categories of domain / scope words, matched as word patterns, not as past phrases:
business domain (commerce, retail, payments, fintech, healthcare, logistics, media, robotics, ...), platform / product
scope (platform, infrastructure, integrations, enterprise, cloud, AWS, devices, connected, ...), trust / policy
(safety, content, moderation, fraud, security, permissions, identity, ...), product area (search, recommendations,
ranking, speech, video, ...), scale / live (live, streaming, real-time, large-scale, millions, ...).
The tagline is split into phrases at commas and joining words ("and", "for", "with", ...). Any phrase holding a term
needs ONE selected bullet or Experience line on the rendered page that names every word of that phrase (plurals and
"integrations" / "integrated" match). Otherwise the build fails with `tagline_unsupported_scope`, naming the phrase.
The check runs on the final page in the script, so no plan.json field can turn it off. Pre-approved master taglines
(`tagline_id`) are not checked.

**Before (v3.4.5, ElevenLabs):** the page rendered `Master's CS student building permissions and platform services for
full-stack products.` and the run PASSED.

**After, same tagline (intentional bad-tagline test), the build FAILS (exit code 2, status FAIL):**
```
tagline_unsupported_scope: "permissions" (trust / policy domain: no selected bullet or Experience line names permissions);
"platform services" (platform / product scope: no selected bullet or Experience line names platform + services)
```
The instruction examples fail too ("AWS integrations", "connected commerce", "content quality", "AWS applications"),
and so do phrases never seen before ("healthcare platforms", "search"). Supported ones pass ("payment APIs", "live
services" on a page with the live-quiz service bullet, "backend services on AWS").

## 5. Experience verb variant J (verb-only)

**Master (`experience_variants`), added and approved 2026-10-16:**
```
exp.godigital.1.J  (verb_only: true, avoids_repeat_verb: "Developed")
Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data and generate automated anomaly reports for the compliance and audit team.
```
"Authored" is added to `banned_project_verbs` (the Experience-verb list), so no project bullet can use it.

**Code (final `select_experience_variants`), added:** `_v346_verb_only_picks` picks J whenever another Experience bullet
on the page, as rendered (the Thesis original or its variant F), opens with "Developed". When Go Digital is left off
(new-grad drop), J is not used. A post-run check fails any build where two Experience bullets open with the same verb
(`experience_repeat_opening_verb`).

**Output, US Cold Storage, before:**
```
Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket ...
Developed a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data ...
```
**After:**
```
Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket ...
Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data ...
```
In the full run, 92 pages had two "Developed" openings in v3.4.5 and 0 have them in v3.4.6. For 87 fixtures this
swap is the only change on the page.

---

## Not changed (confirmed)

- Go Digital new-grad drop rule: identical. On all 32 new-grad pages, `layout_v343` in report.json (section order,
  omitted Experience, slots by rank, slot fallback) is identical to v3.4.5, and Go Digital is on or off exactly as in
  v3.4.5 (dropped on 26, kept on 6: appian_sec, applied_mat, l3harris, macys, raydar_backend, serco_sw). Every
  standard page still shows Go Digital.
- New-grad project layout (3/3/3, 3/3/2, 3/2/3, 3/2/2 slots): the PERSONAL PROJECTS block of all 32 new-grad pages is
  byte-identical to v3.4.5, with the same bullet count per project. The only text difference there is the item-1 word
  ("static-analysis" to "code-analysis") on the four new-grad pages that carry that RIPPLE bullet (doordash_mdx,
  nvidia_infra, raydar_swe, umich); the comparison swaps that word back and then finds no other difference.
- Project ranking, Fit, closings, the cover letter structure and every other rule: unchanged. 24 fixture pages are
  byte-identical to v3.4.5, 87 differ only by the item-5 verb, and the other 7 differ in a single line (items 1, 2 or
  the two stand-in taglines below).

## Fixture stand-ins changed (they stand in for model output)

- elevenlabs: `building permissions and platform services for full-stack products` (the leak this release blocks)
  became `building backend services and full-stack features end to end`.
- audit09: `building payment backends and reliable APIs ...` became `building payment APIs and reliable services ...`,
  because no line on its page names "payment" and "backend" together (the page says "Designed a payment API ...").
