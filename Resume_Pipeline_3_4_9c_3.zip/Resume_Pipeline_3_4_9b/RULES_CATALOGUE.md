# JD Rules Catalogue — pipeline v3.4.3 (auto JD reader; v3.3/v3.4/v3.4.1/v3.4.2/v3.4.3 rules: see CHANGES.txt and context .md sections 0 and 0a)

Every rule below is enforced by `resume_pipeline_v3_2.py` itself, so the same JD always gives the same result, whatever ChatGPT does that day.
Tested on 52 JDs: your 20 JDs, Harvey, BTI, the 13 role-family fixtures, 10 postings built from live-board patterns (Greenhouse, Lever, Workday, Amazon/Google-style, jobright/LinkedIn scrapes, clearance/defense, no-heading prose) and 6 odd formats (ALL-CAPS numbered, one-paragraph inline, emoji bullets, iOS, PhD research, Workday).
Plus L3Harris (systems engineering, recent-bachelor's only), Raydar (agency posting, no tool names), Amplitude (AI-agent analytics backend) and the 10-JD High-thinking diagnostic. Result: 66/66 PASS, about 1 s per run locally (3–5 s in ChatGPT).


## v3.4.3 additions (JD reader)
- Job-board widget lines ("Let's Strengthen Your Resume", "X out of 5 keywords matched", "Low Match", "Improve My Match") are removed before parsing.
- No title: the plan's role must appear in the posting text; a placeholder role or a role the paste never states stops the run ("stop: paste the job title line"; force cannot override).
- "As a <role>, you will..." counts as a responsibilities heading.
- "Data classification" with storage / policy / handling / governance context is masked: never ML, never the Classification skill, never ranks Fraud. "Spark" counts only capitalized; "metrics examination" and "log analysis" are not ML themes.
- Method phrases become supported requirements: log analysis -> Debugging; metrics examination -> Application Monitoring; testability -> Unit Testing; data storage / management -> PostgreSQL; "AWS" -> AWS (EC2/RDS). Added only while the list holds fewer than 25 requirements, then re-sorted by priority.
- "Bachelor's + N years or Master's + M years" -> one note that evaluates both options.
- New-grad detection: new grad / new college grad / university graduate / early career / recent graduate in the title or posting, or a 2026 / 2027 graduating class; plain "entry level" never.
- 1-2 letter skills (Go, C, R) match case-sensitively when reporting omitted terms ("wherever you may go" is not Go).

## 1. Sections (found by heading)
A line counts as a heading if all of these hold:
- It is not a bullet.
- It is 8 words or fewer.
- It doesn't end with a period, and either ends with ":", is Title Case or ALL CAPS, or starts with a known heading phrase.

| Section | Heading phrases recognised | Effect |
|---|---|---|
| Required | Requirements, Qualifications, Minimum/Basic Qualifications, What you'll bring / need, What you have, You have, Who you are, About you, What we're looking for, What it takes, Must-have, Required Skills, To be successful | items → **must** |
| Strict required | the above **and** the heading says Required / Minimum / Basic / Must / Essential / "need to see" | also sets `required_section` (an unsupported item caps Fit at Low) |
| Preferred | Preferred, Nice-to-have(s), Bonus (Points), A plus, Ways to stand out, Desired, Good to have, Extra credit | items → **medium** |
| Responsibilities | What you'll do, Responsibilities, Key job responsibilities, In this role, The role, Role overview, About the role/team, Day to day | items → **high** |
| Skills list | Skills, Skills & Technologies, Tech stack, Key skills (jobright/LinkedIn scrapes) | items → **high** |
| Intro (skipped) | Description, Job Description, Why <Company>, About <Company>/us, Overview, Who we are, Our mission | company blurb, never requirements |
| Other (skipped) | Benefits, Perks, Compensation, Salary/Pay range, EEO, Accommodation, Privacy, Culture, Values, How to apply | ignored |
| No headings at all | — | sentences are split and read as **high** |
| Inline labels | "Requirements: …" / "Nice to have: …" inside a paragraph | **must** / **medium** for that sentence |
| Markdown | **bold** / # headings | read as headings |
| Emoji / symbol bullets | ✅ 🔹 ∙ ▪ etc. | treated as bullets, never headings |

Inline overrides on any line:
- "preferred", "a plus", "nice to have", "bonus", "ideally", "desired" → **medium**
- "required", "must have", "must be", "mandatory" → **must** + `required_section`

## 2. AND vs OR lists
- **AND list** → one requirement per item. Example: "Experience with CI/CD, secrets management, IaC, and observability" becomes 4 items.
- **Bare "or" inside one list item** → only that item is an OR: "Python, Django or Flask, REST APIs" = Python + (Django|Flask) + REST APIs. "A, B, or C" (or on the last item) = one OR group.
- **"including"** lists parts that all count, so it is an AND list: "fundamentals, including data structures, algorithms, version control, testing, and debugging" = 5 requirements (v3.2.12).
- **Example cues (such as, e.g., like, one of)** group only the run of terms right after the cue (joined by commas/and/or); a following clause is read separately; items before it stay separate: "Kubernetes, using frameworks such as vLLM and Triton" = Kubernetes + (vLLM|Triton). "etc.", "or similar" group the whole line.
- **OR / example list** → ONE requirement, led by your strongest supported option, with every supported option as an alias.
  - Cues: or, one of, one or more, at least one, any of, such as, e.g., like, etc., similar, equivalent.
  - The requirement keeps every supported option in "alternatives". It carries one weight (a project or bullet that proves any option earns it once) and needs one visible option; ATS coverage still lists each option as shown or not shown (ats_summary.or_alternatives_not_shown), so nothing hides behind a bundle.
  - An option that is already its own requirement from another line never leads the group, so two JD lines never merge into one requirement.
  - Example: "Proficiency in one of Go, Ruby, Java, or C++" becomes a single requirement led by Java/Go.
  - Unsupported options in an OR list never become gaps.
- **Team stack lines** ("You'll work with technologies such as A, B and C", "our stack includes") are an AND list at **medium**: every item counts, unsupported ones are gaps.
- **Category + examples** ("CRM software (e.g., Salesforce)", "RPA tools (e.g., UiPath, Brity Works)") = ONE requirement led by the category.
- **Slash pairs** ("C++/Golang", "TypeScript/JavaScript", "Spring/Spring Boot") also form one OR group, even on an AND line.
- The **title** always counts: a technology named in the job title becomes a must (for example "C++ Software Engineer" → C++).

## 3. Qualifications (never pasted into skills or the cover letter)
| JD wording | Becomes | Supported? |
|---|---|---|
| Bachelor's / Master's / BS / MS / "four-year degree" / "degree or equivalent practical experience", in CS, software, information, technical, STEM, engineering, math, statistics, quantitative, or related | Master's degree in Computer Science | yes |
| Degree only in a non-CS field (Chemical, Physics, Mechanical, Electrical, Biology, Finance, …) with no CS/software mention | degree in a non-CS field | no |
| PhD required (no Master's/Bachelor's option) | PhD degree | no |
| "graduating Dec 2026 – June 2027", "Winter 2026 – Spring 2027", "graduate by June 2027", "within the last 12 months" | graduation in 2027 | yes, if the window includes 2027 |
| Previous / required internship | internship experience | yes |
| "N years of experience", "0–2 years (internships count)" | industry experience if N ≤ your professional years; otherwise "N+ years of experience" | yes / no |
| U.S. citizenship | U.S. citizenship (must, required) | no; also an eligibility blocker |
| "pursuing a Bachelor's" / "completed Bachelor's within the last 12 months" (no master's option) | current or recent bachelor's student | no; also a degree_recency blocker |
| Secret / DoD / obtain-and-maintain clearance | security clearance (must, required) | no; also an eligibility blocker |
| "will not sponsor" / H-1B wording | eligibility blocker (raw-text scan) | — |
| "New College Grad 2026", "class of 2026" | graduation_year timing warning | warning only |
| "starting in January 2027" (any start before Feb 2027) | start_date timing warning | warning only |

Field names inside degree lines (Statistics, Machine Learning, NLP, Mathematics, AI, Robotics, …) are **not** turned into skill requirements.
Real tech on the same line still counts, e.g. "a CS degree, strong Python skills, REST APIs and SQL".

## 4. Term recognition
- **Lexicon**:
  - your supported pool and its normalisation aliases
  - your never-supported list
  - about 260 general technologies (clouds, data, ML, front-end, DevOps, testing, protocols, enterprise tools)
- **Canonical names**: LLM/LLMs/large language models → LLMs; NLP ↔ natural language processing; RAG ↔ retrieval-augmented generation; Golang → Go; Spark → Apache Spark; Airflow → Apache Airflow; Copilot → GitHub Copilot; ClaudeCode → Claude Code; AWS/EC2/RDS/Amazon Web Services → AWS (EC2/RDS); CI/CD → Continuous Integration (CD is never claimed); "Continuous Deployment" / "continuous delivery" → its own gap; A/B tests → A/B testing; feature engineering; relational databases → Relational Databases; schema/database design → Database Design; containerization → Docker; HTML/CSS shown together; RPA/UiPath, UI/UX, Windows Server recognised (gaps); Data Structures and Algorithms → Data Structures + Algorithms; .Net Framework → .NET; Azure Dev Ops → Azure DevOps; k8s → Kubernetes.
- **Guards against false hits**:
  - Matched case-sensitively: Go, R, C, Make, Spring (not "Spring 2027"), Swift, Ruby, Rust, Lambda, Triton, Flask, CAD, SAP, ARM.
  - "statistics" only when it sits near modelling or analysis words, not "frequently cited statistics".
  - "experimentation" only near A/B testing or platform words.
  - "Go to market" and "go beyond" are ignored.
- **Support**:
  - The negation-aware Master evidence decides.
  - Your never-supported terms are always gaps: RAG, Flask, Jira, Terraform, Spark, Airflow, TypeScript, Jenkins, Selenium, .NET, C#, ServiceNow, ITSM, HIPAA, FHIR, …
  - A supported term that cannot appear in Skills (for example Lua) is kept as **medium**, so it never causes an ATS failure.

## 4b. Concept terms (JDs that name no tools)
backend software → Backend Development; APIs / service interfaces / web services → REST APIs; data modeling → Database Design; monitoring → Application Monitoring; full-stack / across the stack → Full-Stack Development; data or processing pipelines → Data Pipelines; asynchronous jobs / background processing / message queues → Event-Driven Architecture; troubleshooting → Debugging; automated testing → Unit Testing; code reviews → Code Review; in production / deployment → Production Deployment. Glued scraped skill lists ("Backend software developmentApisData modeling") are split first. Concept words never come from the title and never count as technologies in the team_focus check.

## 5. Role family (title first, then body)
- **Title rules, in order**:
  1. ML / data scientist / applied scientist → data_science_ml
  2. AI / LLM / agent / forward deployed / GenAI → ai_llm. Exception: "AI Engineer" whose body is mostly ML/statistics goes to data_science_ml.
  3. data engineer / analytics engineer / ETL → data_engineering
  4. SDET / test / QA → sdet_quality
  5. DevOps / SRE / infrastructure / cloud / platform → devops_cloud
  6. embedded / firmware / kernel / C++ → systems
  7. full stack / front end / growth → fullstack
  8. sustaining / support / ServiceNow → support_sustaining
  9. backend / API / payments / distributed → backend
- **Generic titles** ("Software Engineer", "Associate Software Developer"): the body decides only when one family clearly dominates (≥ 4 hits and 1.5× the runner-up; support needs ≥ 8). Otherwise general_swe.
- **Generic title on an AI product** (≥ 6 AI signal words): stays general_swe, so the domain rule leads with RIPPLE/GoingOnce and keeps LedgerFlow.
- **No title** (role "Not stated"): the body decides with a lower bar (≥ 3 hits and 1.3× the runner-up).
- The tagline and themes follow the family; a general_swe posting about an AI product uses the ai_apps tagline.

## 6. Fit (tracker only; never blocks documents)
- Start from the share of must + high requirements that are supported: ≥ 85% High, ≥ 60% Medium, otherwise Low.
- Then cap it:
  - An unsupported `required_section` must → Low.
  - Any other unsupported must/high, or partial years → at most Medium.

## 7. Skills (ATS)
1. Core baseline.
2. Supported must terms, keeping the JD's own spelling.
3. Supported high and medium requirements.
4. Every supported skill the JD names literally.
5. JD-named project technologies.
6. Other project technologies (still visible in headers and bullets).
7. Family fillers.

Tools stays exactly 1 line, with at most 7 skill lines (6 is fine); the least JD-relevant items are dropped first.
Target in report.json `ats_summary`: 100% of supported requirements visible and 100% of JD-named skills visible.

## 7b. Projects
- Specific role family → its anchor project is #1 (3 bullets, leads cover-letter P2): full-stack LaunchOps, backend/DevOps/support/SDET/data-eng LedgerFlow, data science/ML Fraud, AI/LLM GoingOnce, systems Pintos. general_swe → pure JD scoring.
- A must-have only one project proves forces that project into the top 3 — only for concrete technologies, never for concept skills (Debugging, Code Review) or skills the Experience section proves.
- **Product domain**: a posting about AI agents / LLMs / retrieval (≥ 6 signal words) boosts RIPPLE and GoingOnce; an ML posting boosts Fraud. For general_swe the boosted project becomes #1; other families keep their anchor and the boost decides #2/#3.
- Every project includes one identity bullet (what it is), shown first, then the headline metric.
- Display order stays newest-first.

## 8. Cover letter (script-written from reviewed sentences)
- Backend / full-stack / general JDs that ask for pipelines, extraction, LLMs or AI agents: paragraph 2 leads with the HeinOnline pipeline instead of the Thesis modules.
- AI/ML-product general_swe and backend postings also lead paragraph 2 with HeinOnline; full-stack keeps Thesis unless the posting is AI-led.
- General SWE on an AI or ML product uses an AI or ML hook ("…built AI agent tools in Python alongside backend services in Java").
- LedgerFlow sentence by family: DevOps = crash tests + local Kubernetes demo; SDET/support = 94 tests + crash runs; others = overspend test.
- Missing title → "the open engineering role"; file name Company_Application.
- **Paragraph 1**: the exact role, the company, "Your team <team_focus>", and the family hook.
- **Paragraph 2**: one Experience item with a metric, and the #1 project with its metric.
- **Paragraph 3**: the #2 project, collaboration, and a closing that names the company.
- team_focus must be a sentence about what the team builds and for whom, not a technology list.
- **Checks**:
  - 130–300 words; every sentence ≤ 40 words.
  - Every number comes from the Master.
  - No gap terms and no visa wording; graduation is always February 2027.
  - At most 2 projects named.
  - No banned phrases.
  - At least 2 supported must/high terms.

## 8b. Special postings
- Recruiting agency for an unnamed client ("on behalf of our client"): "the X role that <agency> is recruiting for", "The team …", closing "for your client".
- Company names ending in s get a correct possessive (Technologies').

## 9. What ChatGPT still decides (and the levers it has)
- `application` facts and `team_focus`. These are the only free-text inputs.
- `jd_requirements_extra` priority: must for required lines, high for responsibilities, medium for preferred. The script re-sorts and trims auto medium items to stay inside 25 / 12 medium.
- `jd_requirements_extra` / `jd_requirements_remove`: the extra's term or an alias must appear in its JD verbatim, otherwise the script rejects it (listed in plan_resolved_fields.json). corrections for a clear parser miss. Each one is logged in plan_resolved_fields.json so we can review it.
- `cover_letter.extra`: only when the script reports cover_letter_jd_coverage.

## 10. Known limits (by design)
- Fit is a rough tracker label, not a hiring prediction.
- Soft-skill lines (communication, ownership, curiosity) are not ATS requirements and are not listed.
- A JD pasted with all line breaks removed still parses (sentence split), but section-based priorities fall back to "high".

## v3.2.9 - v3.2.10 additions
- "workflow automation" / "automated workflows" map to Agentic Workflows (v3.2.9).
- VERIFY extras already present as a term or alias are skipped (v3.2.9).
- Bare "testing" / "well-tested" map to Unit Testing (aliases testing, automated testing); non-software testing phrases (A/B, load, usability, genetic, drug, security, performance) are ignored (v3.2.10).
- Bullet wording: no filler such as "real-world", "on purpose", "across every one of those runs"; team projects state team work as team work (v3.2.10).
- v3.2.11: GoingOnce personal contribution (Buy/Sell/Fleet parts, mainly negotiation and transport) and RIPPLE Claude Code use are Master evidence; Claude Code bullets surface only for JDs naming AI-assisted development.

## v3.2.12 additions
- Scoring: each JD requirement counts once per bullet and once per project, whichever spelling (term, alias, OR option) matches. report resolved_plan.bank_selection_auto.breakdown shows the points behind every selected bullet. Ties go to the project's headline bullet.
- Requirements cap 32 (12 medium); anything trimmed is listed in plan_resolved_fields.json jd_requirements_trimmed, never dropped silently.
- "evaluate AI features" / "evaluating AI-generated responses" / "evals" read as Model Evaluation. Degree lines read as "degree in Computer Science" (not "Master's").
- Extras: accepted when the verbatim is really in jd.txt and the term is about it (term, alias, known spelling, or a shared word stem). Rejections carry a reason.
- Short AI postings: AI-led when there are 6+ AI mentions, or 3+ at 10+ per 1,000 words.
- Company not stated: letter says "the role you posted" / "your team"; outreach says "on your team"; file key is Company_Not_Stated_<Role>_<JD id>. Placeholder text (Not stated, N/A, TBD, {company}) in the resume, letter or outreach fails the run; the tracker's visa line is not scanned.
- Same company and title for a second posting: application.key_suffix (city) gives it its own files and tracker row. The tracker is deduped by Resume File Name.
- Experience: compared byte for byte with the template (headers, dates, bullets); any difference fails the run.
- ATS summary: visible, exact JD wording, alias-only list, OR options not shown, missing; warning ats_thin_parse under 8 parsed requirements.
- Cover letter: when the JD asks for AI-assisted development and RIPPLE is on the page, paragraph 2 adds "While building RIPPLE with Claude Code, I corrected its generated code multiple times and used it to probe how AI agents handle edge cases."
- Evidence: GoingOnce = worked across all four agents, mainly Negotiate and Fleet, smaller parts of Buy and Sell, and built the streaming and front-end parts; tests and award stay team-scoped. RIPPLE = corrected Claude Code's generated code multiple times (no example, count or test result). Verbs Studied/Explored removed.


## v3.2.13 additions
- **Sponsorship denial** (sponsorship_denied): negated offer/provide/sponsor/support/consider + sponsorship/visa/immigration, "requests will not be considered", unrestricted or permanent work authorization. Positive offers are not blockers.
- **Non-software roles**: non_software_role(title, JD) sets role_mismatch.
- **Optional wording**: "not required/mandatory", "helpful", "useful", "optional", "welcome" make a line medium. "Additional qualifications" = preferred; "Project examples, not requirements" = skipped.
- **Lists**: "N or more of the following" and "<noun> (A, B, C)" are alternative groups.
- **Ambiguous words** (Express, Make, Shell, Ray, ...) count as technologies only when capitalised and not followed by a lowercase verb.
- **Agency letters** say "the role that <agency> is recruiting for".
- **Evidence**: GoingOnce front end only; code review = reviewed and merged teammates' pull requests (Thesis Mumbai Tech); Go appears in the letter only through the LaunchOps live-quiz bullet.

## v3.2.14 additions
- **SKIP gate** (early_skip_check / gating_assessment): sponsorship, citizenship, clearance; 3+ years of experience stated anywhere (jd_min_years; preferred wording and degree substitutes do not count); senior/staff/principal/lead/director/architect/engineering-manager titles ("member of technical staff" is not senior); main stack outside the evidence (an unsupported TypeScript, Node, C#, C++, .NET, PHP, Ruby, Rust, Swift, Kotlin, Scala, Angular, Vue, GraphQL or Perl requirement that is in the title, among the first three musts, or mentioned 3+ times, with no supported OR alternative); non-software role. A skipped posting keeps only report.json and SKIP.txt. `application.force=true` builds it anyway.
- **Founding** titles cap Fit at Medium.
- **JD clean-up** (clean_jd_text): entities, markdown, job-board widget lines.
- **Tracker Status** = Applied for every new row (v3.4.4; earlier versions used Prepared).

## v3.2.14 stage 2
Skip: all-foreign location. Warn: 1-2 years; graduation window excluding Feb 2027. Raw primary-stack skip. Parser OR-run, education-list, lexicon fixes. ml_models tagline. Pintos ranking limited to systems/low-level JDs.

## v3.2.15 (stage 3)
Letter: 2 paragraphs, hook sentence (planner, script-validated), logistics line, plain-English bank. Skills: on-page evidence rule, Go detection. Project heading swap. Bullet scoring: headline + metric bonus, OR alternatives. Experience frozen.

## v3.2.16
Project selection by role (RIPPLE/resume-pipeline gating, data-eng order), tagline_text + cover_letter.closing validated fields, letter filler removed, 6 bullets reworded.


## v3.3.0 additions (see CHANGES.txt for detail)
- Ranking: theme-first (job title weighted most), complementary picks, rank-order display.
- Hedged lists ("could include", "depending on the role", "Potential internships include") are optional (medium, never required).
- Skills gate: JD-named, heading technology (always), universal basics, or visibly shown on the page; never_filler and synonym_groups in master.skills; >=3 entries per line, <=11, 6-7 lines, 10pt buffer.
- Letters use only bullets on the page; hook must come from the role text, not the mission blurb.
- enrollment_required SKIP for internships that need enrollment for their full duration.
- quality_v33.json on every run.

## v3.4.1 additions (see CHANGES.txt for detail)
- **Skip verdicts**: a firm U.S. citizenship, security-clearance or no-visa-sponsorship line ends the run with `SKIP.txt` = `skip: <reason> ("<JD line>")` and no package. Firm = the line is not worded as a preference ("preferred", "a plus", "ideally", "helpful") and does not sit in a bonus / "ways to stand out" list unless it also says must / required / will not / cannot / unable. Sponsorship offered ("will sponsor", "sponsorship available") is never a skip. `application.force = true` builds the package anyway.
- **Stop**: text from which no requirement can be read (a recruiting ad) ends with `stop: no job requirements were found ...` and a `jd_no_requirements` warning instead of a crash.
- **Bullet slots**: 3/2/2 slots; a slot is one 2-line bank bullet or two 1-line bank bullets (different evidence, verbs and wording) from the same project. All project verbs on the page differ.
- **False C**: "Washington, D.C." -> DC, "Objective-C" -> ObjectiveC, "C/C++" -> C++ before parsing, so none counts as the C language or the systems theme.
- **Titles**: "Intelligent Systems" reads as AI applications; information / business / enterprise / management / integration / internal / corporate systems titles get no OS-systems boost. "Distributed training" is not the distributed-systems theme. Internal tools, business users / workflows, Microsoft 365, SharePoint, Entra ID and Microsoft Graph count toward the corporate-systems (it_ops) theme.
- **Concept terms**: authentication -> JWT; terminal / command line -> Linux; logs, reading logs -> Debugging; logging -> Application Monitoring. Documentation stays a soft skill.
- **Skills**: both synonym members show when the JD names both (SQL + Relational Databases); a JD's literal wording replaces a derived synonym (or joins it when the derived one is required); AI-coding-tool postings show Claude Code, Cursor and GitHub Copilot; "not a research ML role" postings get no ML fillers; when the smallest skills state cannot leave the 10pt page buffer (or the required tools exceed one line), fillers and a filler-only AI/ML line leave first, then the bullets are re-picked to avoid naming technologies the JD does not ask for.
- **Ranking**: "GitHub" never forces the one project whose heading says "GitHub Actions" (every project is on GitHub).
- **Letter lead**: LLM / document-extraction roles -> HeinOnline (+ Thesis healthcare sentence for healthcare postings); data and ML roles -> Go Digital ETL (data engineering) or HeinOnline.
- **Model fields**: list bullets (∙ • ▪ ...), smart quotes, zero-width characters and emoji are removed from company, role, location, visa, hook, closing, team_focus and tagline_text.

## v3.4.2 additions (see CHANGES.txt for detail)
- **No skips** (gating_assessment): every earlier skip reason (sponsorship, citizenship, clearance, 3+ years, senior title, stack outside the evidence, non-software role, enrollment) becomes a `note_<type>` warning and the package is built. Hard blockers (no sponsorship, citizenship, clearance, graduation window, student audience, enrollment required) cap Fit at Low. New blockers: `graduation_window` (one stated graduation date Jay does not meet, e.g. "graduating May 2027") and `student_audience` (rising seniors / juniors, returning to school). `tracker_row.Blockers` and `report.notes` list them. Only `no_requirements` still stops (`stop: <reason>`).
- **AI/ML skills line** only when `_v342_ai_gate` passes: the title or a role line names AI/ML/LLM/agents/models, or the theme vector's AI share is >= 0.08. AI/ML terms the gate leaves off are not reported as omitted.
- **Language lead** (`lead_language`): a title naming exactly one language, or a role line (not hedged) that names exactly one language plus a skill cue (experience, proficiency, knowledge, skills, familiarity, strong, programming, coding, develop, required, preferred, must); required / preferred / must lines outvote the rest. Lists of 2+ languages never count; AI / ML / data / frontend / mobile titles are never overridden. Map: Java -> ledgerflow, C -> pintos.
- **Testing JDs** (testing, TDD, test design, test automation, CI/CD, continuous integration / delivery, GitHub Actions): bonus for `ledger.ci` (+4, +3 more when CI is named), RIPPLE Claude Code (+1.5) and tests (+1). GitHub Actions joins the LedgerFlow heading when `ledger.ci` is on the page and the JD names it.
- **Letter picks**: requirement-weighted letter sentences; `launchops.access_control` for permissions / authorization JDs; `thesis_iot` experience for embedded / systems JDs (not data/ML); `ledger.ci` sentence for testing-heavy JDs. The second letter project is swapped for the third when it answers the top requirements clearly better (+2 margin).
- **Closing** (`_v342_closing`): "I want to help <company> <top responsibility in the JD's words>, building on <proof>." The responsibility is the first one without unsupported terms that the letter has not already quoted; the proof comes from the letter's two projects (or the systems experience) and avoids one the letter already states. Rejected: closings starting "I would welcome the chance", over 36 words, without 4 consecutive JD words, or without a project/job name.
- **Skills filler**: Kubernetes shows as "Kubernetes (local k3d)"; OAuth/Auth0 for OAuth / SSO / authentication JDs; Claude API only with GoingOnce on the page (its bullets naming Claude) or an LLM-API JD; at most 2 terms per synonym group; GitHub dropped when GitHub Actions shows; unrequired matched tools are dropped before the Tools line wraps.
- **1-line pairs**: a pair partner cannot restate the project's first bullet (shared identity phrase).
- **Relocation**: onsite internship letters add "I am open to relocating."
- **Judge packet**: every run writes `out/judge_packet.md`; `3_validation/combine_judge_packets.py` merges several.
- **Experience variants** (off): `select_experience_variants` + `experience_variants_stage`; approved only in live runs, proposed too with `--experience-variants-test`; the Experience integrity check accepts exactly the checked swaps.

- **LLM-system reliability** (`_v342_llm_reliability`): an agent / LLM posting whose role lines name 4+ of evaluation, observability, guardrails, cost, fallbacks, reliability puts tailor_pipeline in the #3 slot when it is not already selected (ranking_override_reason records the signals).
- **"Operating" as a verb**: "experience operating systems in production" (and "building and operating systems at scale") is not the Operating Systems topic; the requirement, the skill and the omission warning are dropped unless Pintos is selected.
- **OAuth/Auth0** added by the auth rule is protected from Tools-line pruning; "GitHub" is always dropped when "GitHub Actions" shows.

## v3.4.4
- **Closing**: build / improve responsibility from the posting, Jay as actor, <= 30 words, proof the letter has not given (no shared number, 3-word phrase or most content words) and matching the claim (testing -> CI / test suites; integrations -> LedgerFlow exactly-once; permissions -> LaunchOps server checks or Data Maven access control; interactive -> LaunchOps live service; embedded -> Pintos / Thesis IoT; operations -> Thesis heartbeat monitor). Scale claims, growth lines, list fragments, mid-phrase endings and hook repeats are rejected; role-family fallback <= 10%. A model-written closing (<= 36 words) is kept only when it passes.
- **Letter**: <= 200 words as a reader counts them; Thesis code-review / mentoring / failure-response sentence for code review, debugging, operations and mentorship postings; RIPPLE: Claude Code helped write it and Jay checked its output with the 241-test suite.
- **Bank**: GoingOnce tests team-scoped; Pintos bullets open with "Implemented"; LLM-engine runtime bullet off agent / ML-infrastructure postings; design patterns -> LedgerFlow outbox bullet; ReactJS kept in headings; preflight for required terms shown only in Skills / headings.
- **Experience variant I** (Agile/Scrum + reviewed and merged team pull requests), the only variant allowed to add facts.
- **JD cleaning**: job-board widget sections and markdown widget lines; informational H1B text never blocks.
- **Tracker**: 11 columns (Career Status Portal, Visa / Sponsorship and Lane removed), Status Applied, "status:" updates.
- **Reports**: report.json verify_changes_v344 (each change with its JD line), preflight_v344, jd_widgets_removed_v344.


## v3.4.6 (see CHANGES_v3_4_6.md)
- RIPPLE ripple.tools.b says "seven code-analysis tools" (master ripple.analysis_tools).
- A role line asking for a web application server, application server, ASGI server or async server, with LaunchOps on the page, adds Daphne/ASGI to Skills (as a JD-named skill). Async workflows, async processing or async patterns do not count.
- Letter paragraph 2 must state start availability (full-time "can start work that month"; internships "and I can start any time from that month"); a letter without it fails the build (cover_letter_start_availability_missing).
- tagline_text (model-written) is checked against a term list of domain / scope words (business domains, platform / product scope, trust / policy, product areas, scale / live). Each phrase holding such a word needs one selected bullet or Experience line that names every word of the phrase, else the build fails (tagline_unsupported_scope, naming the phrase). Pre-approved master taglines (tagline_id) are not checked.
- Experience variant J (verb-only) applies whenever another Experience bullet opens with "Developed"; a page with two Experience bullets opening with the same verb fails the build (experience_repeat_opening_verb).

## v3.4.7a (see CHANGES.md; each rule has a master.json v347_flags switch)
- Relocation: only Buffalo, NY is local; any other place containing "Buffalo" (Buffalo Grove, IL) gets "I am open to relocating." on onsite / hybrid postings; remote postings never mention relocation.
- Headings: a posting-named technology the script added to headings stays only on the selected project whose bullets best show it (a framework bullet shows its language); it leaves a heading whose bullets do not show it when another selected project does. Core stack and a technology only one project shows stay; Skills are unchanged.
- Hiring identity: "<Org> ... has openings", "<Org> is hiring", "send resume to <...@domain>" and "company:" labels are read; a mismatch adds "Posted under <label>; the posting names <employer> as the employer." to Notes (never renamed). A letter sentence naming another organization from the posting fails (cover_letter_two_organizations).
- report.json: unquoted verify entries move to internal_changes with a reason; hook_specific false carries hook_specific_reason; a "Not stated" company is left out of the outreach people searches.
