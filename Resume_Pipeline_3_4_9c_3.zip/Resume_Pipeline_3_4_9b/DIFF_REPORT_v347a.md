# DIFF_REPORT_v347a

Baseline: `baseline_v346` (v3.4.6 code). New: a snapshot of `run_all.py` on the v3.4.7a code, all v347_flags on (same 124 fixtures, same stand-in plans).

Result: **PASS**. 1719 changed lines in 115 fixtures; 0 unpredicted on v340_original / holdout; 0 unpredicted and unjustified elsewhere.


## Summary

| Check | Result |
|---|---|
| S2 determinism (two runs of v3.4.6) | identical after normalizing report.json `timestamps.*` and `pdflatex_calls[*].duration_ms` only |
| S3 all flags off vs baseline_v346 | identical on all 124 fixtures; only the `pipeline_version` label differs, in the two stop reports (fonzi, cisco_no_title) |
| S5 gate, flags on | PASS: 1,719 changed lines in 115 fixtures, 0 unpredicted, 0 invariant violations, every predicted change happened |
| Unpredicted changes on v340_original (53) / holdouts (20) | 0 / 0 |
| Justified changes elsewhere | 1 rule: the `pipeline_version` label on fonzi and cisco_no_title (version, not a fix) |

Fixtures changed per fix (all predicted by `predict_v347a.py` before the code changed):

| Fix | Flag | Fixtures | By group |
|---|---|---|---|
| A1 relocation | relocation_fix | 1 (zoro_fullstack) | v347_new 1 |
| A2 heading placement | heading_tech_fix | 23 (JavaScript leaves 1 or 2 headings) | v340_original 9, v341_tune 7, holdout 4, v342_new 2, v347_new 1 |
| A3 hiring identity | identity_fix | 4 (report only; 1 Notes line: meritore_capgemini) | v340_original 1, v341_tune 1, v347_new 2 |
| A4 report clarity | report_fix | 99 (report only) | v340_original 40, v341_tune 30, holdout 17, v342_new 5, v347_new 4, v344_new 2, v343_new 1 |
| A5 outreach, company not stated | outreach_fix | 8 (outreach + report copy) | v340_original 4, v341_tune 3, v347_new 1 |
| A6 hook reason | hook_reason_fix | 40 (report only) | v340_original 19, v341_tune 13, holdout 7, v347_new 1 |

Resume changes are A2 heading lines only; letter changes are the A1 sentence only (zoro_fullstack); tracker rows are unchanged
on every fixture.

Normalized before comparing (the only fields that differ between two runs of the same code): report.json: timestamps.* (start, end, duration_ms of every stage); report.json: pdflatex_calls[*].duration_ms.

JSON files are compared as flattened `path: value` lines. `before` (none) means an added line; `after` (none) means a removed line.

## Invariants

No changed line touches a resume bullet, a Skills line, a project heading's name (selection / order), the tracker row, report Fit / blockers / gaps / status, or the letter outside A1: **held** (0 violations).

## Changes by fix

| Fix | Fixtures | Lines |
|---|---|---|
| A1 | zoro_fullstack | 3 |
| A2 | acme_cloud, bti, cdi, engen, fidelity, frontend, harvey, inspire11, ixl, linkedin, loopwell, macys, mastercard, meridian_sw, monti, ng_fullstack, rocketmoney, serco_snow, serco_sw, sparkline, us_cold, wgu, zoro_fullstack | 92 |
| A3 | cobalt, meritore_capgemini, nvidia_devtech, zoro_fullstack | 21 |
| A4 | acme_cloud, alml_engineer, amazon, amplify, amplitude, anthropic_it, appian_sec, apple, applied_mat, assetwatch, audible, audible_md, audit02, audit03, audit04, audit05, audit06, audit07, audit08, audit09, audit10, audit11, audit12, bae, black_canyon, booz_allen, brex, brightpath_fs, brightpath_ml, brillio, bti, chewy, cobalt, corvex, dassault, dominos, doordash, doordash_mdx, elevenlabs, engen, fanatics, fidelity, flowgen, frontend, fulfillment, ga_asi, garmin, google_sre, halcyon, helix, impact, inspire11, instalily, ios_randstad, ironvale, jobgether, l3harris, laminar, linkedin, linkedin_ai, loopwell, lumen, macys, mastercard, meridian_bank, meritore_capgemini, microsoft, monti, nimble, northwind, nvidia, otter, paypal, perplexity, pinecrest, pocketly, raydar_backend, raydar_swe, research_phd, roblox, robot_sdet, rocketmoney, rockstar, serco_snow, serco_sw, spacexsi, sparkline, stratus, swisslog, tailscale, twitch, twitch_se1, umich, us_cold, ust_software_engineer, vindexa, wgu, wpp, zoro_fullstack | 772 |
| A5 | alml_engineer, audit01, frontend, fulfillment, ng_fullstack, qa_sdet, research_phd, robot_sdet | 96 |
| A6 | acme_cloud, amplify, anthropic_it, arclight, atoms, audit01, audit03, audit07, audit10, audit12, bae, birthmodel, brightpath_fs, brightpath_ml, chewy, cobalt, dassault, engen, fidelity, flowgen, frontend, ga_asi, google_sre, harvey, impact, ironvale, ixl, klaviyo, linkedin, microsoft, northwind, novita, nvidia_devtech, pinecrest, pinterest, research_phd, rockstar, sparkline, swisslog, zoro_fullstack | 733 |
| cisco_no_title). Added after the first full gate run. | cisco_no_title, fonzi | 2 |
| justified: version label v3.4.6 -> v3.4.7a (not a fix): report.json carries pipeline_version only on the two expected stops (fonzi | cisco_no_title, fonzi | 2 |

## Every changed line

| Fixture | Group | File | Fix | Before | After |
|---|---|---|---|---|---|
| acme_cloud | holdout | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| acme_cloud | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| acme_cloud | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| acme_cloud | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "fast"` |
| acme_cloud | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "infrastructure"` |
| acme_cloud | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "keep"` |
| acme_cloud | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "large-scale"` |
| acme_cloud | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "reliable"` |
| acme_cloud | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "services"` |
| acme_cloud | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "storage"` |
| acme_cloud | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "stated"` |
| acme_cloud | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Write product or system development code."` |
| acme_cloud | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "code"` |
| acme_cloud | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "product"` |
| acme_cloud | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "write"` |
| acme_cloud | holdout | report | A4 | `verify_changes_v344[4].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| acme_cloud | holdout | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| acme_cloud | holdout | report | A4 | `verify_changes_v344[4].internal: true` | (none) |
| acme_cloud | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| acme_cloud | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| acme_cloud | holdout | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| acme_cloud | holdout | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| alml_engineer | v347_new | report | A5 | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20machine%20learning%20manager"` | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=machine%20learning%20manager"` |
| alml_engineer | v347_new | report | A5 | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20machine%20learning%20engineer"` | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=machine%20learning%20engineer"` |
| alml_engineer | v347_new | report | A5 | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| alml_engineer | v347_new | report | A5 | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| alml_engineer | v347_new | report | A5 | `outreach.linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=AL/ML%20Engineer\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20machine%20learning%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20machine%20learning%20engineer \| R` | `outreach.linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=AL/ML%20Engineer\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=machine%20learning%20manager \| Team engineers https://www.linkedin.com/search/results` |
| alml_engineer | v347_new | report | A5 | (none) | `outreach.linkedin.company_status: "not stated in the posting"` |
| alml_engineer | v347_new | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| alml_engineer | v347_new | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| alml_engineer | v347_new | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| alml_engineer | v347_new | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| alml_engineer | v347_new | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| alml_engineer | v347_new | outreach | A5 | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20machine%20learning%20manager"` | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=machine%20learning%20manager"` |
| alml_engineer | v347_new | outreach | A5 | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20machine%20learning%20engineer"` | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=machine%20learning%20engineer"` |
| alml_engineer | v347_new | outreach | A5 | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| alml_engineer | v347_new | outreach | A5 | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| alml_engineer | v347_new | outreach | A5 | `linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=AL/ML%20Engineer\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20machine%20learning%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20machine%20learning%20engineer \| Recruiters` | `linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=AL/ML%20Engineer\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=machine%20learning%20manager \| Team engineers https://www.linkedin.com/search/results/people/?` |
| alml_engineer | v347_new | outreach | A5 | (none) | `linkedin.company_status: "not stated in the posting"` |
| amazon | v340_original | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| amazon | v340_original | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| amazon | v340_original | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| amazon | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| amazon | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "ability"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "assess"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "child"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "effectively"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "reading"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "students"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "teachers"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "tools"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "assessments"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[1]: "literacy"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Build high-quality, robust, scalable software solutions that help Amplify build and maintain a best-in-class learning platform"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "amplify"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "best-in-class"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "high-quality"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "learning"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "maintain"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "platform"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[6]: "robust"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[7]: "scalable"` |
| amplify | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[8]: "solutions"` |
| amplify | v340_original | report | A4 | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b) (no posting line names it; script rule)"` | `verify_changes_v344[0].change: "Letter experience sentence: Thesis Mumbai Tech code review, mentoring and failure response (code review)"` |
| amplify | v340_original | report | A4 | `verify_changes_v344[0].jd_line: ""` | `verify_changes_v344[0].jd_line: "- Write automated tests and participate in code reviews"` |
| amplify | v340_original | report | A4 | `verify_changes_v344[1].change: "Letter experience sentence: Thesis Mumbai Tech code review, mentoring and failure response (code review)"` | `verify_changes_v344[1].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` |
| amplify | v340_original | report | A4 | `verify_changes_v344[1].jd_line: "- Write automated tests and participate in code reviews"` | `verify_changes_v344[1].jd_line: "Strong understanding of modern frontend and backend web technologies (React, REST APIs, SQL)"` |
| amplify | v340_original | report | A4 | `verify_changes_v344[2].change: "Closing responsibility \"create reporting on student assessments with tools and recommendations for improving outcomes\" with proof ledger.exactly_once_effect (architecture) (no posting line names it; script rule)"` | `verify_changes_v344[2].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` |
| amplify | v340_original | report | A4 | `verify_changes_v344[2].jd_line: ""` | `verify_changes_v344[2].jd_line: "- Write automated tests and participate in code reviews"` |
| amplify | v340_original | report | A4 | `verify_changes_v344[3].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` | (none) |
| amplify | v340_original | report | A4 | `verify_changes_v344[3].jd_line: "Strong understanding of modern frontend and backend web technologies (React, REST APIs, SQL)"` | (none) |
| amplify | v340_original | report | A4 | `verify_changes_v344[4].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` | (none) |
| amplify | v340_original | report | A4 | `verify_changes_v344[4].jd_line: "- Write automated tests and participate in code reviews"` | (none) |
| amplify | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| amplify | v340_original | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| amplify | v340_original | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| amplify | v340_original | report | A4 | (none) | `internal_changes[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` |
| amplify | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| amplify | v340_original | report | A4 | (none) | `internal_changes[1].change: "Closing responsibility \"create reporting on student assessments with tools and recommendations for improving outcomes\" with proof ledger.exactly_once_effect (architecture)"` |
| amplify | v340_original | report | A4 | (none) | `internal_changes[1].reason: "script rule: no posting line names it"` |
| amplify | v340_original | report | A4 | (none) | `internal_changes[2].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| amplify | v340_original | report | A4 | (none) | `internal_changes[2].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| amplitude | holdout | report | A4 | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b) (no posting line names it; script rule)"` | `verify_changes_v344[0].change: "Closing responsibility \"write maintainable code and automated tests\" with proof ledger.chaos_runs (testing)"` |
| amplitude | holdout | report | A4 | `verify_changes_v344[0].jd_line: ""` | `verify_changes_v344[0].jd_line: "- Write maintainable code and automated tests, participate in code reviews, and use logs and metrics to debug services and make background jobs more reliable"` |
| amplitude | holdout | report | A4 | `verify_changes_v344[1].change: "Closing responsibility \"write maintainable code and automated tests\" with proof ledger.chaos_runs (testing)"` | `verify_changes_v344[1].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` |
| amplitude | holdout | report | A4 | `verify_changes_v344[1].jd_line: "- Write maintainable code and automated tests, participate in code reviews, and use logs and metrics to debug services and make background jobs more reliable"` | `verify_changes_v344[1].jd_line: "As a Software Engineer I on the Agent Analytics team, you'll help build the foundation of a growing AI analytics product. You'll start with well-scoped backend and data pipeline features, pair with experienced engineers, and take on more ow"` |
| amplitude | holdout | report | A4 | `verify_changes_v344[2].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` | `verify_changes_v344[2].change: "Experience variant C (exp.hein.3.C, suits AI roles)"` |
| amplitude | holdout | report | A4 | `verify_changes_v344[2].jd_line: "As a Software Engineer I on the Agent Analytics team, you'll help build the foundation of a growing AI analytics product. You'll start with well-scoped backend and data pipeline features, pair with experienced engineers, and take on more ow"` | `verify_changes_v344[2].jd_line: "Exposure to SQL, backend APIs, cloud infrastructure, or data pipelines is a plus. Projects involving AI agents, LLM applications, tracing, or evaluations are also welcome"` |
| amplitude | holdout | report | A4 | `verify_changes_v344[3].change: "Experience variant C (exp.hein.3.C, suits AI roles)"` | `verify_changes_v344[3].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` |
| amplitude | holdout | report | A4 | `verify_changes_v344[3].jd_line: "Exposure to SQL, backend APIs, cloud infrastructure, or data pipelines is a plus. Projects involving AI agents, LLM applications, tracing, or evaluations are also welcome"` | `verify_changes_v344[3].jd_line: "- Write maintainable code and automated tests, participate in code reviews, and use logs and metrics to debug services and make background jobs more reliable"` |
| amplitude | holdout | report | A4 | `verify_changes_v344[4].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` | `verify_changes_v344[4].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| amplitude | holdout | report | A4 | `verify_changes_v344[5].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | `verify_changes_v344[5].change: "Coursework line dropped: it did not fit one page with the buffer"` |
| amplitude | holdout | report | A4 | `verify_changes_v344[5].jd_line: "- Write maintainable code and automated tests, participate in code reviews, and use logs and metrics to debug services and make background jobs more reliable"` | `verify_changes_v344[5].jd_line: "- Comfortable programming in at least one language such as TypeScript, Python, Java, or a similar language, through coursework, projects, internships, or professional experience"` |
| amplitude | holdout | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| amplitude | holdout | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| amplitude | holdout | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| amplitude | holdout | report | A4 | `verify_changes_v344[7].change: "Coursework line dropped: it did not fit one page with the buffer"` | (none) |
| amplitude | holdout | report | A4 | `verify_changes_v344[7].jd_line: "- Comfortable programming in at least one language such as TypeScript, Python, Java, or a similar language, through coursework, projects, internships, or professional experience"` | (none) |
| amplitude | holdout | report | A4 | (none) | `internal_changes[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` |
| amplitude | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| amplitude | holdout | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| amplitude | holdout | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "automate"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "claude"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "much"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "playbook"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "possible"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "repeatable"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words: []` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Lead technical IT due diligence: assess a company's identity, applications, endpoints, and infrastructure, and brief the deal team on risk and effort before close"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "applications"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "assess"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "before"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "brief"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "close"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "deal"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[6]: "diligence"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[7]: "effort"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[8]: "endpoints"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[9]: "identity"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[10]: "infrastructure"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[11]: "lead"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[12]: "risk"` |
| anthropic_it | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[13]: "technical"` |
| anthropic_it | v340_original | report | A4 | `verify_changes_v344[3].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| anthropic_it | v340_original | report | A4 | `verify_changes_v344[3].jd_line: ""` | (none) |
| anthropic_it | v340_original | report | A4 | `verify_changes_v344[3].internal: true` | (none) |
| anthropic_it | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| anthropic_it | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| appian_sec | v340_original | report | A4 | `verify_changes_v344[3].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| appian_sec | v340_original | report | A4 | `verify_changes_v344[3].jd_line: ""` | (none) |
| appian_sec | v340_original | report | A4 | `verify_changes_v344[3].internal: true` | (none) |
| appian_sec | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| appian_sec | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| apple | v340_original | report | A4 | `verify_changes_v344[4].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests) (no posting line names it; script rule)"` | `verify_changes_v344[4].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| apple | v340_original | report | A4 | `verify_changes_v344[4].jd_line: ""` | `verify_changes_v344[4].jd_line: "Ability to comprehend and debug complex systems integrations spanning toolchains and teams."` |
| apple | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | (none) |
| apple | v340_original | report | A4 | `verify_changes_v344[5].jd_line: "Ability to comprehend and debug complex systems integrations spanning toolchains and teams."` | (none) |
| apple | v340_original | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| apple | v340_original | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| apple | v340_original | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| apple | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` |
| apple | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| apple | v340_original | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| apple | v340_original | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| applied_mat | v341_tune | report | A4 | `verify_changes_v344[3].change: "Experience variant F (exp.thesis.2.F, suits real-time / IoT / embedded roles) (no posting line names it; script rule)"` | `verify_changes_v344[3].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| applied_mat | v341_tune | report | A4 | `verify_changes_v344[3].jd_line: ""` | `verify_changes_v344[3].jd_line: "Identify and troubleshoot moderately difficult problems communicated from lab testing or field."` |
| applied_mat | v341_tune | report | A4 | `verify_changes_v344[4].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | (none) |
| applied_mat | v341_tune | report | A4 | `verify_changes_v344[4].jd_line: "Identify and troubleshoot moderately difficult problems communicated from lab testing or field."` | (none) |
| applied_mat | v341_tune | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| applied_mat | v341_tune | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| applied_mat | v341_tune | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| applied_mat | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant F (exp.thesis.2.F, suits real-time / IoT / embedded roles)"` |
| applied_mat | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| applied_mat | v341_tune | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| applied_mat | v341_tune | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "concurrency"` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "embedded"` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "environment"` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "file"` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "linux"` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "management"` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "process"` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words: []` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Develop low-level software in C for our device platform."` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "develop"` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "device"` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "low-level"` |
| arclight | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "platform"` |
| assetwatch | v340_original | report | A4 | `verify_changes_v344[8].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| assetwatch | v340_original | report | A4 | `verify_changes_v344[8].jd_line: ""` | (none) |
| assetwatch | v340_original | report | A4 | `verify_changes_v344[8].internal: true` | (none) |
| assetwatch | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| assetwatch | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "atoms"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "everyday"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "join"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "kind"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "life"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "physical"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "shape"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "transform"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "working"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words: []` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Architect and implement scalable backend systems and APIs."` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "apis"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "architect"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "backend"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "implement"` |
| atoms | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "scalable"` |
| audible | v343_new | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| audible | v343_new | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| audible | v343_new | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| audible | v343_new | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| audible | v343_new | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| audible_md | v344_new | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| audible_md | v344_new | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| audible_md | v344_new | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| audible_md | v344_new | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| audible_md | v344_new | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| audit01 | v340_original | report | A5 | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager"` | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager"` |
| audit01 | v340_original | report | A5 | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer"` | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=software%20engineer"` |
| audit01 | v340_original | report | A5 | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| audit01 | v340_original | report | A5 | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| audit01 | v340_original | report | A5 | `outreach.linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Junior%20Software%20Engineer\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20enginee` | `outreach.linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Junior%20Software%20Engineer\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager \| Team engineers https://www.linkedin.co` |
| audit01 | v340_original | report | A5 | (none) | `outreach.linkedin.company_status: "not stated in the posting"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "aside"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "group"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "improvements"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "improving"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "like"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "process"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "sets"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "ships"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "small"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[9]: "time"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[10]: "weekly"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words: []` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Implement API endpoints and review pull requests with teammates."` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "endpoints"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "implement"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "pull"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "requests"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "review"` |
| audit01 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "teammates"` |
| audit01 | v340_original | outreach | A5 | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager"` | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager"` |
| audit01 | v340_original | outreach | A5 | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer"` | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=software%20engineer"` |
| audit01 | v340_original | outreach | A5 | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| audit01 | v340_original | outreach | A5 | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| audit01 | v340_original | outreach | A5 | `linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Junior%20Software%20Engineer\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer \| Recr` | `linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Junior%20Software%20Engineer\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager \| Team engineers https://www.linkedin.com/search/` |
| audit01 | v340_original | outreach | A5 | (none) | `linkedin.company_status: "not stated in the posting"` |
| audit02 | v340_original | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| audit02 | v340_original | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| audit02 | v340_original | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| audit02 | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| audit02 | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "apis"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "behind"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "debug"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "easy"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "implement"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "keep"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "python"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "rest"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "services"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words: []` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Write and test new API endpoints used by the checkout product."` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "checkout"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "endpoints"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "product"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "test"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "used"` |
| audit03 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "write"` |
| audit03 | v340_original | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| audit03 | v340_original | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| audit03 | v340_original | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| audit03 | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| audit03 | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| audit04 | v340_original | report | A4 | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b) (no posting line names it; script rule)"` | `verify_changes_v344[1].change: "Closing responsibility \"debug failures and describe data assumptions clearly\" with proof ledger.exactly_once_effect (data)"` |
| audit04 | v340_original | report | A4 | `verify_changes_v344[1].jd_line: ""` | `verify_changes_v344[1].jd_line: "- Ability to debug failures and describe data assumptions clearly."` |
| audit04 | v340_original | report | A4 | `verify_changes_v344[2].change: "Closing responsibility \"debug failures and describe data assumptions clearly\" with proof ledger.exactly_once_effect (data)"` | `verify_changes_v344[2].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` |
| audit04 | v340_original | report | A4 | `verify_changes_v344[2].jd_line: "- Ability to debug failures and describe data assumptions clearly."` | `verify_changes_v344[2].jd_line: "Hands-on experience with ETL, data quality checks, and relational database design."` |
| audit04 | v340_original | report | A4 | `verify_changes_v344[3].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` | `verify_changes_v344[3].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| audit04 | v340_original | report | A4 | `verify_changes_v344[3].jd_line: "Hands-on experience with ETL, data quality checks, and relational database design."` | `verify_changes_v344[3].jd_line: "- Ability to debug failures and describe data assumptions clearly."` |
| audit04 | v340_original | report | A4 | `verify_changes_v344[4].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | (none) |
| audit04 | v340_original | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| audit04 | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | (none) |
| audit04 | v340_original | report | A4 | `verify_changes_v344[5].jd_line: "- Ability to debug failures and describe data assumptions clearly."` | (none) |
| audit04 | v340_original | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| audit04 | v340_original | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| audit04 | v340_original | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| audit04 | v340_original | report | A4 | (none) | `internal_changes[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` |
| audit04 | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| audit04 | v340_original | report | A4 | (none) | `internal_changes[1].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| audit04 | v340_original | report | A4 | (none) | `internal_changes[1].reason: "script rule: no posting line names it"` |
| audit04 | v340_original | report | A4 | (none) | `internal_changes[2].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| audit04 | v340_original | report | A4 | (none) | `internal_changes[2].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| audit05 | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| audit05 | v340_original | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| audit05 | v340_original | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| audit05 | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| audit05 | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| audit06 | v340_original | report | A4 | `verify_changes_v344[6].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | (none) |
| audit06 | v340_original | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| audit06 | v340_original | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| audit06 | v340_original | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| audit06 | v340_original | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| audit06 | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| audit06 | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| audit06 | v340_original | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| audit06 | v340_original | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| audit07 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| audit07 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| audit07 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "automation"` |
| audit07 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "cloud"` |
| audit07 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "collaboration"` |
| audit07 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "developers"` |
| audit07 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "internal"` |
| audit07 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "platforms"` |
| audit07 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "scripting"` |
| audit07 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "troubleshooting"` |
| audit07 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "platform"` |
| audit07 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| audit07 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| audit07 | v340_original | report | A4 | `verify_changes_v344[1].change: "Letter experience sentence: Thesis Mumbai Tech code review, mentoring and failure response (debugging) (no posting line names it; script rule)"` | `verify_changes_v344[1].change: "Closing responsibility \"write maintainable automation\" with proof ledger.chaos_runs (testing)"` |
| audit07 | v340_original | report | A4 | `verify_changes_v344[1].jd_line: ""` | `verify_changes_v344[1].jd_line: "\| python \| write maintainable automation \| repeatable tests \|"` |
| audit07 | v340_original | report | A4 | `verify_changes_v344[2].change: "Closing responsibility \"write maintainable automation\" with proof ledger.chaos_runs (testing)"` | `verify_changes_v344[2].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` |
| audit07 | v340_original | report | A4 | `verify_changes_v344[2].jd_line: "\| python \| write maintainable automation \| repeatable tests \|"` | `verify_changes_v344[2].jd_line: "\| SQL \| EXPLAIN APPLICATION DATA FLOWS \| CORRECT QUERIES \|"` |
| audit07 | v340_original | report | A4 | `verify_changes_v344[3].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` | `verify_changes_v344[3].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| audit07 | v340_original | report | A4 | `verify_changes_v344[3].jd_line: "\| SQL \| EXPLAIN APPLICATION DATA FLOWS \| CORRECT QUERIES \|"` | `verify_changes_v344[3].jd_line: "EXPOSURE TO KUBERNETES, TERRAFORM, PROMETHEUS, OR GRAFANA IS USEFUL BUT NOT REQUIRED. THIS TEAM WILL PROVIDE TRAINING ON INTERNAL DEPLOYMENT SYSTEMS."` |
| audit07 | v340_original | report | A4 | `verify_changes_v344[4].change: "Experience variant D (exp.thesis.1.D, for every role)"` | `verify_changes_v344[4].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| audit07 | v340_original | report | A4 | `verify_changes_v344[4].jd_line: "EXPOSURE TO KUBERNETES, TERRAFORM, PROMETHEUS, OR GRAFANA IS USEFUL BUT NOT REQUIRED. THIS TEAM WILL PROVIDE TRAINING ON INTERNAL DEPLOYMENT SYSTEMS."` | `verify_changes_v344[4].jd_line: "AWS \| SUPPORT CLOUD HOSTING \| OPERATIONAL LOGS \|"` |
| audit07 | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | `verify_changes_v344[5].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` |
| audit07 | v340_original | report | A4 | `verify_changes_v344[6].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` | (none) |
| audit07 | v340_original | report | A4 | `verify_changes_v344[6].jd_line: "AWS \| SUPPORT CLOUD HOSTING \| OPERATIONAL LOGS \|"` | (none) |
| audit07 | v340_original | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| audit07 | v340_original | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| audit07 | v340_original | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| audit07 | v340_original | report | A4 | (none) | `internal_changes[0].change: "Letter experience sentence: Thesis Mumbai Tech code review, mentoring and failure response (debugging)"` |
| audit07 | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| audit07 | v340_original | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| audit07 | v340_original | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| audit08 | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| audit08 | v340_original | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| audit08 | v340_original | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| audit08 | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| audit08 | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| audit09 | v340_original | report | A4 | `verify_changes_v344[3].change: "Letter experience sentence: Thesis Mumbai Tech code review, mentoring and failure response (code review) (no posting line names it; script rule)"` | `verify_changes_v344[3].change: "Closing responsibility \"implement service endpoints, validate input, and reason about concurrency\" with proof ledger.exactly_once_effect (integrations)"` |
| audit09 | v340_original | report | A4 | `verify_changes_v344[3].jd_line: ""` | `verify_changes_v344[3].jd_line: "implement service endpoints, validate input, and reason about concurrency"` |
| audit09 | v340_original | report | A4 | `verify_changes_v344[4].change: "Closing responsibility \"implement service endpoints, validate input, and reason about concurrency\" with proof ledger.exactly_once_effect (integrations)"` | `verify_changes_v344[4].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` |
| audit09 | v340_original | report | A4 | `verify_changes_v344[4].jd_line: "implement service endpoints, validate input, and reason about concurrency"` | `verify_changes_v344[4].jd_line: "- Improve data access paths and instrument error handling."` |
| audit09 | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` | (none) |
| audit09 | v340_original | report | A4 | `verify_changes_v344[5].jd_line: "- Improve data access paths and instrument error handling."` | (none) |
| audit09 | v340_original | report | A4 | `verify_changes_v344[6].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests) (no posting line names it; script rule)"` | (none) |
| audit09 | v340_original | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| audit09 | v340_original | report | A4 | (none) | `internal_changes[0].change: "Letter experience sentence: Thesis Mumbai Tech code review, mentoring and failure response (code review)"` |
| audit09 | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| audit09 | v340_original | report | A4 | (none) | `internal_changes[1].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` |
| audit09 | v340_original | report | A4 | (none) | `internal_changes[1].reason: "script rule: no posting line names it"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "applications"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "before"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "building"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "changes"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "clients"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "engineers"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "enterprise"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "internal"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "making"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[9]: "process"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[10]: "understand"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[11]: "where"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[12]: "workflow"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "application"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[1]: "business"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Design integration endpoints and data transformations for business users."` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "business"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "data"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "design"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "endpoints"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "integration"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "transformations"` |
| audit10 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[6]: "users"` |
| audit10 | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| audit10 | v340_original | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| audit10 | v340_original | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| audit10 | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| audit10 | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| audit11 | v340_original | report | A4 | `verify_changes_v344[1].change: "Experience variant F (exp.thesis.2.F, suits real-time / IoT / embedded roles) (no posting line names it; script rule)"` | (none) |
| audit11 | v340_original | report | A4 | `verify_changes_v344[1].jd_line: ""` | (none) |
| audit11 | v340_original | report | A4 | `verify_changes_v344[2].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| audit11 | v340_original | report | A4 | `verify_changes_v344[2].jd_line: ""` | (none) |
| audit11 | v340_original | report | A4 | `verify_changes_v344[2].internal: true` | (none) |
| audit11 | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant F (exp.thesis.2.F, suits real-time / IoT / embedded roles)"` |
| audit11 | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| audit11 | v340_original | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| audit11 | v340_original | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "apis"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "applications"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "configure"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "design"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "evaluation"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "internal"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "jobs"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "launch"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "rest"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "applied"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Implement Python services for LLM integration, request validation, and tool calling."` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "calling"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "implement"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "integration"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "python"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "request"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "services"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[6]: "tool"` |
| audit12 | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[7]: "validation"` |
| audit12 | v340_original | report | A4 | `verify_changes_v344[9].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| audit12 | v340_original | report | A4 | `verify_changes_v344[9].jd_line: ""` | (none) |
| audit12 | v340_original | report | A4 | `verify_changes_v344[9].internal: true` | (none) |
| audit12 | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| audit12 | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| bae | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| bae | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| bae | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "coding"` |
| bae | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "debugging"` |
| bae | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "integrating"` |
| bae | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "regression"` |
| bae | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "requirement"` |
| bae | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "testing"` |
| bae | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "well"` |
| bae | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "entry"` |
| bae | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| bae | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| bae | v341_tune | report | A4 | `verify_changes_v344[1].change: "Closing responsibility \"develop breakthrough technologies\" with proof pintos.processes (embedded) (no posting line names it; script rule)"` | `verify_changes_v344[1].change: "Experience variant E (exp.thesis.1.E, suits client-facing / internal-tools roles)"` |
| bae | v341_tune | report | A4 | `verify_changes_v344[1].jd_line: ""` | `verify_changes_v344[1].jd_line: "Operating Systems (e.g. Windows and/or UNIX/Linux)"` |
| bae | v341_tune | report | A4 | `verify_changes_v344[2].change: "Experience variant E (exp.thesis.1.E, suits client-facing / internal-tools roles)"` | `verify_changes_v344[2].change: "Experience variant F (exp.thesis.2.F, suits real-time / IoT / embedded roles)"` |
| bae | v341_tune | report | A4 | `verify_changes_v344[2].jd_line: "Operating Systems (e.g. Windows and/or UNIX/Linux)"` | `verify_changes_v344[2].jd_line: "Proficiency in multiple high level programming languages (e.g. C, C++, Java, Python)"` |
| bae | v341_tune | report | A4 | `verify_changes_v344[3].change: "Experience variant F (exp.thesis.2.F, suits real-time / IoT / embedded roles)"` | `verify_changes_v344[3].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| bae | v341_tune | report | A4 | `verify_changes_v344[3].jd_line: "Proficiency in multiple high level programming languages (e.g. C, C++, Java, Python)"` | `verify_changes_v344[3].jd_line: "Operating Systems (e.g. Windows and/or UNIX/Linux)"` |
| bae | v341_tune | report | A4 | `verify_changes_v344[4].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | (none) |
| bae | v341_tune | report | A4 | `verify_changes_v344[4].jd_line: "Operating Systems (e.g. Windows and/or UNIX/Linux)"` | (none) |
| bae | v341_tune | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| bae | v341_tune | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| bae | v341_tune | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| bae | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Closing responsibility \"develop breakthrough technologies\" with proof pintos.processes (embedded)"` |
| bae | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| bae | v341_tune | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| bae | v341_tune | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "apis"` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "backend"` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "clinical"` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "delivery"` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "features"` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "frontend"` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "labor"` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "teams"` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "units"` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[9]: "used"` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "healthcare"` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| birthmodel | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| black_canyon | v341_tune | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| black_canyon | v341_tune | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| black_canyon | v341_tune | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| black_canyon | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| black_canyon | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| booz_allen | v341_tune | report | A4 | `verify_changes_v344[8].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| booz_allen | v341_tune | report | A4 | `verify_changes_v344[8].jd_line: ""` | (none) |
| booz_allen | v341_tune | report | A4 | `verify_changes_v344[8].internal: true` | (none) |
| booz_allen | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| booz_allen | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| brex | v340_original | report | A4 | `verify_changes_v344[3].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| brex | v340_original | report | A4 | `verify_changes_v344[3].jd_line: ""` | (none) |
| brex | v340_original | report | A4 | `verify_changes_v344[3].internal: true` | (none) |
| brex | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| brex | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "across"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "back"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "django"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "features"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "front"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "including"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "python"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "react"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "real-time"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[9]: "rest"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[10]: "websockets"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "entry"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[1]: "full"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[2]: "stack"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Brightpath builds onboarding and training software for growing companies."` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "brightpath"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "builds"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "companies"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "growing"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "onboarding"` |
| brightpath_fs | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "training"` |
| brightpath_fs | v341_tune | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| brightpath_fs | v341_tune | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| brightpath_fs | v341_tune | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| brightpath_fs | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| brightpath_fs | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "content"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "deploy"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "evaluate"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "learning"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "models"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "personalize"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "ranking"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "retrieval"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "train"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "stated"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Brightpath AI is building personalized education for every learner."` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "brightpath"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "building"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "education"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "every"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "learner"` |
| brightpath_ml | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "personalized"` |
| brightpath_ml | v341_tune | report | A4 | `verify_changes_v344[4].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | (none) |
| brightpath_ml | v341_tune | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| brightpath_ml | v341_tune | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| brightpath_ml | v341_tune | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| brightpath_ml | v341_tune | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| brightpath_ml | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| brightpath_ml | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| brightpath_ml | v341_tune | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| brightpath_ml | v341_tune | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| brillio | v340_original | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| brillio | v340_original | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| brillio | v340_original | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| brillio | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| brillio | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| bti | v341_tune | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| bti | v341_tune | resume_tex | A2 | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS, JavaScript $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` |
| bti | v341_tune | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| bti | v341_tune | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| bti | v341_tune | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| bti | v341_tune | report | A4 | `verify_changes_v344[7].change: "Preflight preference dropped (Java): the preferred bullet did not fit one page with the buffer (no posting line names it; script rule)"` | (none) |
| bti | v341_tune | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| bti | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| bti | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| bti | v341_tune | report | A4 | (none) | `internal_changes[1].change: "Preflight preference dropped (Java): the preferred bullet did not fit one page with the buffer"` |
| bti | v341_tune | report | A4 | (none) | `internal_changes[1].reason: "script rule: no posting line names it"` |
| bti | v341_tune | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| bti | v341_tune | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| bti | v341_tune | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[1]: "goingonce"` |
| bti | v341_tune | report | A2 | (none) | `heading_tech_v347.goingonce[0].left: "JavaScript"` |
| bti | v341_tune | report | A2 | (none) | `heading_tech_v347.goingonce[0].shown_by[0]: "launchops"` |
| cdi | v340_original | resume_tex | A2 | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS, JavaScript $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` |
| cdi | v340_original | report | A2 | (none) | `heading_tech_v347.goingonce[0].left: "JavaScript"` |
| cdi | v340_original | report | A2 | (none) | `heading_tech_v347.goingonce[0].shown_by[0]: "launchops"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "apis"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "enterprise"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "error"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "established"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "handling"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "human"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "integrate"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "patterns"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "reliable"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[9]: "review"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[10]: "security"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[11]: "services"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words: []` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Help build AI-powered experiences for knowledge discovery, analytics, and workflow automation."` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "ai-powered"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "analytics"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "automation"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "discovery"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "experiences"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "knowledge"` |
| chewy | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[6]: "workflow"` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[1].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b) (no posting line names it; script rule)"` | `verify_changes_v344[1].change: "LaunchOps: the MongoDB quiz-service bullet is preferred, so NoSQL is backed by a bullet"` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[1].jd_line: ""` | `verify_changes_v344[1].jd_line: "- Proficiency in at least one programming language, such as Python, Java, or TypeScript, and familiarity with APIs and SQL or NoSQL databases."` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[2].change: "LaunchOps: the MongoDB quiz-service bullet is preferred, so NoSQL is backed by a bullet"` | `verify_changes_v344[2].change: "Letter experience sentence: Thesis Mumbai Tech code review, mentoring and failure response (debugging, code review, operations)"` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[2].jd_line: "- Proficiency in at least one programming language, such as Python, Java, or TypeScript, and familiarity with APIs and SQL or NoSQL databases."` | `verify_changes_v344[2].jd_line: "Help monitor and troubleshoot applications, building familiarity with production systems and reliable software delivery."` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[3].change: "Letter experience sentence: Thesis Mumbai Tech code review, mentoring and failure response (debugging, code review, operations)"` | `verify_changes_v344[3].change: "Closing responsibility \"develop, test, and maintain scoped features across user interfaces\" with proof exp.thesis_iot (interactive)"` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[3].jd_line: "Help monitor and troubleshoot applications, building familiarity with production systems and reliable software delivery."` | `verify_changes_v344[3].jd_line: "develop, test, and maintain scoped features across user interfaces, backend services"` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[4].change: "Closing responsibility \"develop, test, and maintain scoped features across user interfaces\" with proof exp.thesis_iot (interactive)"` | `verify_changes_v344[4].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[4].jd_line: "develop, test, and maintain scoped features across user interfaces, backend services"` | `verify_changes_v344[4].jd_line: "Develop, test, and maintain scoped features across user interfaces, backend services, and APIs with guidance from experienced engineers."` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[5].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` | `verify_changes_v344[5].change: "Experience variant C (exp.hein.3.C, suits AI roles)"` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[5].jd_line: "Develop, test, and maintain scoped features across user interfaces, backend services, and APIs with guidance from experienced engineers."` | `verify_changes_v344[5].jd_line: "Coursework or projects involving language model APIs, AI-powered applications, or workflow automation."` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[6].change: "Experience variant C (exp.hein.3.C, suits AI roles)"` | `verify_changes_v344[6].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[6].jd_line: "Coursework or projects involving language model APIs, AI-powered applications, or workflow automation."` | `verify_changes_v344[6].jd_line: "- Collaborate with engineers and product partners to understand requirements, communicate progress, and apply feedback from code reviews."` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[7].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` | `verify_changes_v344[7].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[7].jd_line: "- Collaborate with engineers and product partners to understand requirements, communicate progress, and apply feedback from code reviews."` | `verify_changes_v344[7].jd_line: "- Use AI-assisted development tools for coding, testing, debugging, and documentation while reviewing, understanding, and testing generated outputs."` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[8].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | `verify_changes_v344[8].change: "Coursework line dropped: it did not fit one page with the buffer"` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[8].jd_line: "- Use AI-assisted development tools for coding, testing, debugging, and documentation while reviewing, understanding, and testing generated outputs."` | `verify_changes_v344[8].jd_line: "- Hands-on use of AI-assisted development tools through work, coursework, or personal projects, with examples of how you reviewed, tested, and improved generated code."` |
| chewy | v341_tune | report | A4 | `verify_changes_v344[9].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| chewy | v341_tune | report | A4 | `verify_changes_v344[9].jd_line: ""` | (none) |
| chewy | v341_tune | report | A4 | `verify_changes_v344[9].internal: true` | (none) |
| chewy | v341_tune | report | A4 | `verify_changes_v344[10].change: "Coursework line dropped: it did not fit one page with the buffer"` | (none) |
| chewy | v341_tune | report | A4 | `verify_changes_v344[10].jd_line: "- Hands-on use of AI-assisted development tools through work, coursework, or personal projects, with examples of how you reviewed, tested, and improved generated code."` | (none) |
| chewy | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` |
| chewy | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| chewy | v341_tune | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| chewy | v341_tune | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| cisco_no_title | v343_new | report | justified: version label v3.4.6 -> v3.4.7a (not a fix): report.json carries pipeline_version only on the two expected stops (fonzi, cisco_no_title). Added after the first full gate run. | `pipeline_version: "v3.4.6"` | `pipeline_version: "v3.4.7a"` |
| cobalt | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| cobalt | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| cobalt | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "analytics"` |
| cobalt | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "apis"` |
| cobalt | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "behind"` |
| cobalt | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "dashboards"` |
| cobalt | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "data"` |
| cobalt | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "design"` |
| cobalt | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "postgresql"` |
| cobalt | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "schemas"` |
| cobalt | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "services"` |
| cobalt | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "backend"` |
| cobalt | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| cobalt | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| cobalt | v341_tune | report | A4 | `verify_changes_v344[2].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | (none) |
| cobalt | v341_tune | report | A4 | `verify_changes_v344[2].jd_line: ""` | (none) |
| cobalt | v341_tune | report | A4 | `verify_changes_v344[3].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| cobalt | v341_tune | report | A4 | `verify_changes_v344[3].jd_line: ""` | (none) |
| cobalt | v341_tune | report | A4 | `verify_changes_v344[3].internal: true` | (none) |
| cobalt | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| cobalt | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| cobalt | v341_tune | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| cobalt | v341_tune | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| cobalt | v341_tune | report | A3 | (none) | `hiring_identity_v347.employer: "Cobalt Analytics"` |
| cobalt | v341_tune | report | A3 | (none) | `hiring_identity_v347.employer_statements[0]: "Cobalt Analytics"` |
| cobalt | v341_tune | report | A3 | (none) | `hiring_identity_v347.send_resume_to: []` |
| cobalt | v341_tune | report | A3 | (none) | `hiring_identity_v347.header_labels: []` |
| cobalt | v341_tune | report | A3 | (none) | `hiring_identity_v347.matches_company: true` |
| corvex | holdout | report | A4 | `verify_changes_v344[6].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | `verify_changes_v344[6].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| corvex | holdout | report | A4 | `verify_changes_v344[6].jd_line: ""` | `verify_changes_v344[6].jd_line: "- Reproduce, triage, and document defects; work with developers on root cause."` |
| corvex | holdout | report | A4 | `verify_changes_v344[7].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | (none) |
| corvex | holdout | report | A4 | `verify_changes_v344[7].jd_line: "- Reproduce, triage, and document defects; work with developers on root cause."` | (none) |
| corvex | holdout | report | A4 | `verify_changes_v344[8].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| corvex | holdout | report | A4 | `verify_changes_v344[8].jd_line: ""` | (none) |
| corvex | holdout | report | A4 | `verify_changes_v344[8].internal: true` | (none) |
| corvex | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| corvex | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| corvex | holdout | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| corvex | holdout | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| dassault | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| dassault | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| dassault | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "applications"` |
| dassault | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "architecture"` |
| dassault | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "design"` |
| dassault | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "designing"` |
| dassault | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "developing"` |
| dassault | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "support"` |
| dassault | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "workflows"` |
| dassault | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words: []` |
| dassault | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| dassault | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| dassault | holdout | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| dassault | holdout | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| dassault | holdout | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| dassault | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| dassault | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| dominos | v341_tune | report | A4 | `verify_changes_v344[0].change: "Fraud: the edge-type ablation and leakage-control bullets are preferred (ML posting) (no posting line names it; script rule)"` | `verify_changes_v344[0].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` |
| dominos | v341_tune | report | A4 | `verify_changes_v344[0].jd_line: ""` | `verify_changes_v344[0].jd_line: "Python for data analysis and modeling."` |
| dominos | v341_tune | report | A4 | `verify_changes_v344[1].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` | (none) |
| dominos | v341_tune | report | A4 | `verify_changes_v344[1].jd_line: "Python for data analysis and modeling."` | (none) |
| dominos | v341_tune | report | A4 | `verify_changes_v344[2].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | (none) |
| dominos | v341_tune | report | A4 | `verify_changes_v344[2].jd_line: ""` | (none) |
| dominos | v341_tune | report | A4 | `verify_changes_v344[3].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| dominos | v341_tune | report | A4 | `verify_changes_v344[3].jd_line: ""` | (none) |
| dominos | v341_tune | report | A4 | `verify_changes_v344[3].internal: true` | (none) |
| dominos | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Fraud: the edge-type ablation and leakage-control bullets are preferred (ML posting)"` |
| dominos | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| dominos | v341_tune | report | A4 | (none) | `internal_changes[1].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| dominos | v341_tune | report | A4 | (none) | `internal_changes[1].reason: "script rule: no posting line names it"` |
| dominos | v341_tune | report | A4 | (none) | `internal_changes[2].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| dominos | v341_tune | report | A4 | (none) | `internal_changes[2].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| doordash | v340_original | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| doordash | v340_original | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| doordash | v340_original | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| doordash | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| doordash | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| doordash_mdx | v342_new | report | A4 | `verify_changes_v344[8].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| doordash_mdx | v342_new | report | A4 | `verify_changes_v344[8].jd_line: ""` | (none) |
| doordash_mdx | v342_new | report | A4 | `verify_changes_v344[8].internal: true` | (none) |
| doordash_mdx | v342_new | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| doordash_mdx | v342_new | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| elevenlabs | v342_new | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| elevenlabs | v342_new | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| elevenlabs | v342_new | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| elevenlabs | v342_new | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| elevenlabs | v342_new | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| engen | v341_tune | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "applications"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "claims"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "critical"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "enhance"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "financial"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "modernize"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "operations"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "processing"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "support"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "stated"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Monitor work against production schedule and provide progress updates and report any issues or technical difficulties to senior developers/principals on a regular basis."` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "against"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "basis"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "developers"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "difficulties"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "issues"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "monitor"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[6]: "principals"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[7]: "production"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[8]: "progress"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[9]: "provide"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[10]: "regular"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[11]: "report"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[12]: "schedule"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[13]: "technical"` |
| engen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[14]: "updates"` |
| engen | v341_tune | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| engen | v341_tune | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| engen | v341_tune | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| engen | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| engen | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| engen | v341_tune | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| engen | v341_tune | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| fanatics | v340_original | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| fanatics | v340_original | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| fanatics | v340_original | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| fanatics | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| fanatics | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| fidelity | v340_original | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "autonomous"` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "building"` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "cross-functional"` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "desktop"` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "end-to-end"` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "experience"` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "features"` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "part"` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "teams"` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[9]: "user"` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "digital"` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[1]: "xaml"` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| fidelity | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| fidelity | v340_original | report | A4 | `verify_changes_v344[8].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| fidelity | v340_original | report | A4 | `verify_changes_v344[8].jd_line: ""` | (none) |
| fidelity | v340_original | report | A4 | `verify_changes_v344[8].internal: true` | (none) |
| fidelity | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| fidelity | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| fidelity | v340_original | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| fidelity | v340_original | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "agents"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "compliantly"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "configure"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "enterprise"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "guardrails"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "operate"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "predictably"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "real-world"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "safely"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[9]: "scenarios"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[10]: "validate"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "deployed"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[1]: "forward"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Write and maintain key agent-building artifacts, including AOPs, integration specs, evaluation plans, and customer-facing technical documentation."` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "agent-building"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "aops"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "artifacts"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "customer-facing"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "documentation"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "evaluation"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[6]: "including"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[7]: "integration"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[8]: "maintain"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[9]: "plans"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[10]: "specs"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[11]: "technical"` |
| flowgen | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[12]: "write"` |
| flowgen | v341_tune | report | A4 | `verify_changes_v344[9].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| flowgen | v341_tune | report | A4 | `verify_changes_v344[9].jd_line: ""` | (none) |
| flowgen | v341_tune | report | A4 | `verify_changes_v344[9].internal: true` | (none) |
| flowgen | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| flowgen | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| fonzi | v341_tune | report | justified: version label v3.4.6 -> v3.4.7a (not a fix): report.json carries pipeline_version only on the two expected stops (fonzi, cisco_no_title). Added after the first full gate run. | `pipeline_version: "v3.4.6"` | `pipeline_version: "v3.4.7a"` |
| frontend | v340_original | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| frontend | v340_original | resume_tex | A2 | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS, JavaScript $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` |
| frontend | v340_original | report | A5 | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20frontend%20engineering%20manager"` | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=frontend%20engineering%20manager"` |
| frontend | v340_original | report | A5 | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20frontend%20engineer"` | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=frontend%20engineer"` |
| frontend | v340_original | report | A5 | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| frontend | v340_original | report | A5 | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| frontend | v340_original | report | A5 | `outreach.linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Frontend%20Engineer%20I\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20frontend%20engineering%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20frontend%20engineer \| ` | `outreach.linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Frontend%20Engineer%20I\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=frontend%20engineering%20manager \| Team engineers https://www.linkedin.com/sea` |
| frontend | v340_original | report | A5 | (none) | `outreach.linkedin.company_status: "not stated in the posting"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "apis"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "backend"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "design"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "engineers"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "features"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "interfaces"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "responsive"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "rest"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "user"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "frontend"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "We build the web dashboard that thousands of small businesses use to run payroll."` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "businesses"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "dashboard"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "payroll"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "small"` |
| frontend | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "thousands"` |
| frontend | v340_original | report | A4 | `verify_changes_v344[4].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| frontend | v340_original | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| frontend | v340_original | report | A4 | `verify_changes_v344[4].internal: true` | (none) |
| frontend | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| frontend | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| frontend | v340_original | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| frontend | v340_original | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| frontend | v340_original | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[1]: "goingonce"` |
| frontend | v340_original | report | A2 | (none) | `heading_tech_v347.goingonce[0].left: "JavaScript"` |
| frontend | v340_original | report | A2 | (none) | `heading_tech_v347.goingonce[0].shown_by[0]: "launchops"` |
| frontend | v340_original | outreach | A5 | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20frontend%20engineering%20manager"` | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=frontend%20engineering%20manager"` |
| frontend | v340_original | outreach | A5 | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20frontend%20engineer"` | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=frontend%20engineer"` |
| frontend | v340_original | outreach | A5 | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| frontend | v340_original | outreach | A5 | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| frontend | v340_original | outreach | A5 | `linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Frontend%20Engineer%20I\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20frontend%20engineering%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20frontend%20engineer \| Recruiter` | `linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Frontend%20Engineer%20I\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=frontend%20engineering%20manager \| Team engineers https://www.linkedin.com/search/resul` |
| frontend | v340_original | outreach | A5 | (none) | `linkedin.company_status: "not stated in the posting"` |
| fulfillment | v341_tune | report | A5 | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager"` | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager"` |
| fulfillment | v341_tune | report | A5 | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer"` | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=software%20engineer"` |
| fulfillment | v341_tune | report | A5 | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| fulfillment | v341_tune | report | A5 | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| fulfillment | v341_tune | report | A5 | `outreach.linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=the%20open%20engineering%20role\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engi` | `outreach.linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=the%20open%20engineering%20role\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager \| Team engineers https://www.linkedin` |
| fulfillment | v341_tune | report | A5 | (none) | `outreach.linkedin.company_status: "not stated in the posting"` |
| fulfillment | v341_tune | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| fulfillment | v341_tune | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| fulfillment | v341_tune | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| fulfillment | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| fulfillment | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| fulfillment | v341_tune | outreach | A5 | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager"` | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager"` |
| fulfillment | v341_tune | outreach | A5 | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer"` | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=software%20engineer"` |
| fulfillment | v341_tune | outreach | A5 | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| fulfillment | v341_tune | outreach | A5 | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| fulfillment | v341_tune | outreach | A5 | `linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=the%20open%20engineering%20role\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer \| R` | `linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=the%20open%20engineering%20role\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager \| Team engineers https://www.linkedin.com/sear` |
| fulfillment | v341_tune | outreach | A5 | (none) | `linkedin.company_status: "not stated in the posting"` |
| ga_asi | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| ga_asi | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| ga_asi | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "applications"` |
| ga_asi | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "coding"` |
| ga_asi | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "data"` |
| ga_asi | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "design"` |
| ga_asi | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "documentation"` |
| ga_asi | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "implementation"` |
| ga_asi | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "including"` |
| ga_asi | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "management"` |
| ga_asi | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "testing"` |
| ga_asi | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "associate"` |
| ga_asi | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| ga_asi | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| ga_asi | holdout | report | A4 | `verify_changes_v344[4].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| ga_asi | holdout | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| ga_asi | holdout | report | A4 | `verify_changes_v344[4].internal: true` | (none) |
| ga_asi | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| ga_asi | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| garmin | holdout | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| garmin | holdout | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| garmin | holdout | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| garmin | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| garmin | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "automation"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "building"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "eliminating"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "fault-tolerant"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "infrastructure"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "large-scale"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "through"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "cloud"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[1]: "google"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[2]: "reliability"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[3]: "site"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Write product or system development code."` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "code"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "product"` |
| google_sre | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "write"` |
| google_sre | v340_original | report | A4 | `verify_changes_v344[3].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | `verify_changes_v344[3].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| google_sre | v340_original | report | A4 | `verify_changes_v344[3].jd_line: ""` | `verify_changes_v344[3].jd_line: "- Experience with monitoring, alerting, and automation of operational work."` |
| google_sre | v340_original | report | A4 | `verify_changes_v344[4].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | `verify_changes_v344[4].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` |
| google_sre | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` | (none) |
| google_sre | v340_original | report | A4 | `verify_changes_v344[5].jd_line: "- Experience with monitoring, alerting, and automation of operational work."` | (none) |
| google_sre | v340_original | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| google_sre | v340_original | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| google_sre | v340_original | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| google_sre | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| google_sre | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| google_sre | v340_original | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| google_sre | v340_original | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| halcyon | holdout | report | A4 | `verify_changes_v344[2].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | `verify_changes_v344[2].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| halcyon | holdout | report | A4 | `verify_changes_v344[2].jd_line: ""` | `verify_changes_v344[2].jd_line: "- Monitor pipelines and resolve data quality issues."` |
| halcyon | holdout | report | A4 | `verify_changes_v344[3].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | (none) |
| halcyon | holdout | report | A4 | `verify_changes_v344[3].jd_line: "- Monitor pipelines and resolve data quality issues."` | (none) |
| halcyon | holdout | report | A4 | `verify_changes_v344[4].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| halcyon | holdout | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| halcyon | holdout | report | A4 | `verify_changes_v344[4].internal: true` | (none) |
| halcyon | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| halcyon | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| halcyon | holdout | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| halcyon | holdout | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| harvey | v341_tune | resume_tex | A2 | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS, JavaScript $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "automation"` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "code"` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "contribute"` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "document"` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "features"` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "intelligence"` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "production"` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "retrieval"` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "spanning"` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[9]: "workflow"` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words: []` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| harvey | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| harvey | v341_tune | report | A2 | (none) | `heading_tech_v347.goingonce[0].left: "JavaScript"` |
| harvey | v341_tune | report | A2 | (none) | `heading_tech_v347.goingonce[0].shown_by[0]: "launchops"` |
| helix | v341_tune | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| helix | v341_tune | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| helix | v341_tune | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| helix | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| helix | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "apis"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "design"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "features"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "first"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "mindset"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "modules"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "public"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "securely"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "services"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "full"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[1]: "stack"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Troubleshoot issues before they spoil your weekend"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "before"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "issues"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "spoil"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "they"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "troubleshoot"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "weekend"` |
| impact | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[6]: "your"` |
| impact | v341_tune | report | A4 | `verify_changes_v344[9].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| impact | v341_tune | report | A4 | `verify_changes_v344[9].jd_line: ""` | (none) |
| impact | v341_tune | report | A4 | `verify_changes_v344[9].internal: true` | (none) |
| impact | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| impact | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| inspire11 | v340_original | resume_tex | A2 | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS, JavaScript $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` |
| inspire11 | v340_original | report | A4 | `verify_changes_v344[10].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| inspire11 | v340_original | report | A4 | `verify_changes_v344[10].jd_line: ""` | (none) |
| inspire11 | v340_original | report | A4 | `verify_changes_v344[10].internal: true` | (none) |
| inspire11 | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| inspire11 | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| inspire11 | v340_original | report | A2 | (none) | `heading_tech_v347.goingonce[0].left: "JavaScript"` |
| inspire11 | v340_original | report | A2 | (none) | `heading_tech_v347.goingonce[0].shown_by[0]: "ledgerflow"` |
| instalily | v340_original | report | A4 | `verify_changes_v344[8].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| instalily | v340_original | report | A4 | `verify_changes_v344[8].jd_line: ""` | (none) |
| instalily | v340_original | report | A4 | `verify_changes_v344[8].internal: true` | (none) |
| instalily | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| instalily | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| ios_randstad | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| ios_randstad | v340_original | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| ios_randstad | v340_original | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| ios_randstad | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| ios_randstad | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "because"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "depend"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "every"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "ground"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "mission"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "running"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "satellite"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "teams"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "test"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[9]: "time"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[10]: "tools"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[11]: "working"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "associate"` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| ironvale | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| ironvale | v341_tune | report | A4 | `verify_changes_v344[1].change: "Closing responsibility \"develop mission software and test tools\" with proof ledger.chaos_runs (testing) (no posting line names it; script rule)"` | `verify_changes_v344[1].change: "Experience variant F (exp.thesis.2.F, suits real-time / IoT / embedded roles)"` |
| ironvale | v341_tune | report | A4 | `verify_changes_v344[1].jd_line: ""` | `verify_changes_v344[1].jd_line: "- Programming experience in C++ or Java"` |
| ironvale | v341_tune | report | A4 | `verify_changes_v344[2].change: "Experience variant F (exp.thesis.2.F, suits real-time / IoT / embedded roles)"` | `verify_changes_v344[2].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` |
| ironvale | v341_tune | report | A4 | `verify_changes_v344[2].jd_line: "- Programming experience in C++ or Java"` | `verify_changes_v344[2].jd_line: "- Must be able to obtain and maintain a Secret security clearance"` |
| ironvale | v341_tune | report | A4 | `verify_changes_v344[3].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles) (no posting line names it; script rule)"` | `verify_changes_v344[3].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` |
| ironvale | v341_tune | report | A4 | `verify_changes_v344[3].jd_line: ""` | `verify_changes_v344[3].jd_line: "- Familiarity with Agile/Scrum"` |
| ironvale | v341_tune | report | A4 | `verify_changes_v344[4].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` | (none) |
| ironvale | v341_tune | report | A4 | `verify_changes_v344[4].jd_line: "- Must be able to obtain and maintain a Secret security clearance"` | (none) |
| ironvale | v341_tune | report | A4 | `verify_changes_v344[5].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` | (none) |
| ironvale | v341_tune | report | A4 | `verify_changes_v344[5].jd_line: "- Familiarity with Agile/Scrum"` | (none) |
| ironvale | v341_tune | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| ironvale | v341_tune | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| ironvale | v341_tune | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| ironvale | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Closing responsibility \"develop mission software and test tools\" with proof ledger.chaos_runs (testing)"` |
| ironvale | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| ironvale | v341_tune | report | A4 | (none) | `internal_changes[1].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| ironvale | v341_tune | report | A4 | (none) | `internal_changes[1].reason: "script rule: no posting line names it"` |
| ironvale | v341_tune | report | A4 | (none) | `internal_changes[2].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| ironvale | v341_tune | report | A4 | (none) | `internal_changes[2].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| ixl | v340_original | resume_tex | A2 | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS, JavaScript $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` |
| ixl | v340_original | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "application"` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "back-end"` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "educational"` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "logic"` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "products"` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "students"` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "teachers"` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "used"` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "wiring"` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words: []` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Own projects from conception through the development cycle"` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "conception"` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "cycle"` |
| ixl | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "through"` |
| ixl | v340_original | report | A2 | (none) | `heading_tech_v347.goingonce[0].left: "JavaScript"` |
| ixl | v340_original | report | A2 | (none) | `heading_tech_v347.goingonce[0].shown_by[0]: "launchops"` |
| ixl | v340_original | report | A2 | (none) | `heading_tech_v347.goingonce[0].shown_by[1]: "ledgerflow"` |
| ixl | v340_original | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| ixl | v340_original | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| jobgether | v340_original | report | A4 | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b) (no posting line names it; script rule)"` | `verify_changes_v344[0].change: "LaunchOps heading keeps ReactJS (a selected bullet shows React)"` |
| jobgether | v340_original | report | A4 | `verify_changes_v344[0].jd_line: ""` | `verify_changes_v344[0].jd_line: "Strong proficiency in TypeScript and JavaScript, with hands-on experience using React or Node.js."` |
| jobgether | v340_original | report | A4 | `verify_changes_v344[1].change: "Closing responsibility \"write clear, maintainable code and meaningful automated tests\" with proof launchops.ownership (permissions) (no posting line names it; script rule)"` | `verify_changes_v344[1].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` |
| jobgether | v340_original | report | A4 | `verify_changes_v344[1].jd_line: ""` | `verify_changes_v344[1].jd_line: "Experience working with REST or RPC-style APIs."` |
| jobgether | v340_original | report | A4 | `verify_changes_v344[2].change: "LaunchOps heading keeps ReactJS (a selected bullet shows React)"` | `verify_changes_v344[2].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| jobgether | v340_original | report | A4 | `verify_changes_v344[2].jd_line: "Strong proficiency in TypeScript and JavaScript, with hands-on experience using React or Node.js."` | `verify_changes_v344[2].jd_line: "Exposure to serverless or event-driven architectures, including AWS Lambda, SQS, or equivalent technologies, is a plus."` |
| jobgether | v340_original | report | A4 | `verify_changes_v344[3].change: "Experience variant B (exp.hein.1.B, suits data / backend roles)"` | (none) |
| jobgether | v340_original | report | A4 | `verify_changes_v344[3].jd_line: "Experience working with REST or RPC-style APIs."` | (none) |
| jobgether | v340_original | report | A4 | `verify_changes_v344[4].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests) (no posting line names it; script rule)"` | (none) |
| jobgether | v340_original | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| jobgether | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | (none) |
| jobgether | v340_original | report | A4 | `verify_changes_v344[5].jd_line: "Exposure to serverless or event-driven architectures, including AWS Lambda, SQS, or equivalent technologies, is a plus."` | (none) |
| jobgether | v340_original | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| jobgether | v340_original | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| jobgether | v340_original | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| jobgether | v340_original | report | A4 | (none) | `internal_changes[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` |
| jobgether | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| jobgether | v340_original | report | A4 | (none) | `internal_changes[1].change: "Closing responsibility \"write clear, maintainable code and meaningful automated tests\" with proof launchops.ownership (permissions)"` |
| jobgether | v340_original | report | A4 | (none) | `internal_changes[1].reason: "script rule: no posting line names it"` |
| jobgether | v340_original | report | A4 | (none) | `internal_changes[2].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` |
| jobgether | v340_original | report | A4 | (none) | `internal_changes[2].reason: "script rule: no posting line names it"` |
| jobgether | v340_original | report | A4 | (none) | `internal_changes[3].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| jobgether | v340_original | report | A4 | (none) | `internal_changes[3].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "backend"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "brands"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "builds"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "foundational"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "grow"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "klaviyo"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "power"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "technologies"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words: []` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Develop robust, reliable and scalable services to serve AI models in production environments."` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "develop"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "environments"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "models"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "production"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "reliable"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "robust"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[6]: "scalable"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[7]: "serve"` |
| klaviyo | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[8]: "services"` |
| l3harris | v341_tune | report | A4 | `verify_changes_v344[3].change: "Experience variant F (exp.thesis.2.F, suits real-time / IoT / embedded roles) (no posting line names it; script rule)"` | `verify_changes_v344[3].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| l3harris | v341_tune | report | A4 | `verify_changes_v344[3].jd_line: ""` | `verify_changes_v344[3].jd_line: "Description(highlighting: forward, deploy)"` |
| l3harris | v341_tune | report | A4 | `verify_changes_v344[4].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | `verify_changes_v344[4].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` |
| l3harris | v341_tune | report | A4 | `verify_changes_v344[5].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` | (none) |
| l3harris | v341_tune | report | A4 | `verify_changes_v344[5].jd_line: "Description(highlighting: forward, deploy)"` | (none) |
| l3harris | v341_tune | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| l3harris | v341_tune | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| l3harris | v341_tune | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| l3harris | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant F (exp.thesis.2.F, suits real-time / IoT / embedded roles)"` |
| l3harris | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| l3harris | v341_tune | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| l3harris | v341_tune | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| laminar | v344_new | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| laminar | v344_new | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| laminar | v344_new | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| laminar | v344_new | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| laminar | v344_new | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| linkedin | v340_original | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "apis"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "asynchronous"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "backend"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "design"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "extensible"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "handle"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "scale"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "services"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "synchronous"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[9]: "workflows"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "applications"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "You will own end-to-end feature delivery, translating ambiguous product requirements into clean, testable, and maintainable production code."` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "ambiguous"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "clean"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "code"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "delivery"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "end-to-end"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "feature"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[6]: "maintainable"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[7]: "product"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[8]: "production"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[9]: "requirements"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[10]: "testable"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[11]: "translating"` |
| linkedin | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[12]: "will"` |
| linkedin | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| linkedin | v340_original | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| linkedin | v340_original | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| linkedin | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| linkedin | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| linkedin | v340_original | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| linkedin | v340_original | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| linkedin_ai | holdout | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| linkedin_ai | holdout | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| linkedin_ai | holdout | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| linkedin_ai | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| linkedin_ai | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| loopwell | holdout | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, JavaScript, GitHub Actions, PostgreSQL $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, GitHub Actions, PostgreSQL $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| loopwell | holdout | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| loopwell | holdout | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| loopwell | holdout | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| loopwell | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| loopwell | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| loopwell | holdout | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| loopwell | holdout | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| loopwell | holdout | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[1]: "goingonce"` |
| lumen | holdout | report | A4 | `verify_changes_v344[4].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | (none) |
| lumen | holdout | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| lumen | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| lumen | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| macys | v342_new | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| macys | v342_new | report | A4 | `verify_changes_v344[4].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| macys | v342_new | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| macys | v342_new | report | A4 | `verify_changes_v344[4].internal: true` | (none) |
| macys | v342_new | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| macys | v342_new | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| macys | v342_new | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| macys | v342_new | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| mastercard | v340_original | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| mastercard | v340_original | report | A4 | `verify_changes_v344[10].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| mastercard | v340_original | report | A4 | `verify_changes_v344[10].jd_line: ""` | (none) |
| mastercard | v340_original | report | A4 | `verify_changes_v344[10].internal: true` | (none) |
| mastercard | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| mastercard | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| mastercard | v340_original | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| mastercard | v340_original | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| meridian_bank | v341_tune | report | A4 | `verify_changes_v344[3].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| meridian_bank | v341_tune | report | A4 | `verify_changes_v344[3].jd_line: ""` | (none) |
| meridian_bank | v341_tune | report | A4 | `verify_changes_v344[3].internal: true` | (none) |
| meridian_bank | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| meridian_bank | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| meridian_sw | holdout | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| meridian_sw | holdout | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| meridian_sw | holdout | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| meritore_capgemini | v347_new | report | A3 | `notes: []` | `notes[0]: "Posted under Capgemini; the posting names Meritore Technologies LLC as the employer."` |
| meritore_capgemini | v347_new | report | A4 | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b) (no posting line names it; script rule)"` | `verify_changes_v344[0].change: "Letter experience sentence: Thesis Mumbai Tech code review, mentoring and failure response (code review, debugging)"` |
| meritore_capgemini | v347_new | report | A4 | `verify_changes_v344[0].jd_line: ""` | `verify_changes_v344[0].jd_line: "- Participate in code reviews to improve code quality."` |
| meritore_capgemini | v347_new | report | A4 | `verify_changes_v344[1].change: "Letter experience sentence: Thesis Mumbai Tech code review, mentoring and failure response (code review, debugging)"` | `verify_changes_v344[1].change: "Closing responsibility \"improve code quality\" with proof ledger.ci (testing)"` |
| meritore_capgemini | v347_new | report | A4 | `verify_changes_v344[2].change: "Closing responsibility \"improve code quality\" with proof ledger.ci (testing)"` | `verify_changes_v344[2].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` |
| meritore_capgemini | v347_new | report | A4 | `verify_changes_v344[3].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` | (none) |
| meritore_capgemini | v347_new | report | A4 | `verify_changes_v344[3].jd_line: "- Participate in code reviews to improve code quality."` | (none) |
| meritore_capgemini | v347_new | report | A4 | `verify_changes_v344[4].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| meritore_capgemini | v347_new | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| meritore_capgemini | v347_new | report | A4 | `verify_changes_v344[4].internal: true` | (none) |
| meritore_capgemini | v347_new | report | A4 | (none) | `internal_changes[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` |
| meritore_capgemini | v347_new | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| meritore_capgemini | v347_new | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| meritore_capgemini | v347_new | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| meritore_capgemini | v347_new | report | A3 | (none) | `hiring_identity_v347.employer: "Meritore Technologies LLC"` |
| meritore_capgemini | v347_new | report | A3 | (none) | `hiring_identity_v347.employer_statements[0]: "Meritore Technologies LLC"` |
| meritore_capgemini | v347_new | report | A3 | (none) | `hiring_identity_v347.send_resume_to[0]: "hr@meritore.com"` |
| meritore_capgemini | v347_new | report | A3 | (none) | `hiring_identity_v347.header_labels[0]: "Capgemini"` |
| meritore_capgemini | v347_new | report | A3 | (none) | `hiring_identity_v347.matches_company: true` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "builds"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "improve"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "patterns"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "quality"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "repeatable"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "shares"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "velocity"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words: []` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Build and enhance APIs, tools, and subsystems for telemetry collection, routing, storage, and efficient data access."` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "access"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "apis"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "collection"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "data"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "efficient"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "enhance"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[6]: "routing"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[7]: "storage"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[8]: "subsystems"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[9]: "telemetry"` |
| microsoft | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[10]: "tools"` |
| microsoft | v340_original | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| microsoft | v340_original | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| microsoft | v340_original | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| microsoft | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| microsoft | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| monti | v341_tune | resume_tex | A2 | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS, JavaScript $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` |
| monti | v341_tune | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| monti | v341_tune | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| monti | v341_tune | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| monti | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| monti | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| monti | v341_tune | report | A2 | (none) | `heading_tech_v347.goingonce[0].left: "JavaScript"` |
| monti | v341_tune | report | A2 | (none) | `heading_tech_v347.goingonce[0].shown_by[0]: "launchops"` |
| ng_fullstack | v340_original | resume_tex | A2 | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS, JavaScript $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` |
| ng_fullstack | v340_original | report | A5 | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager"` | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager"` |
| ng_fullstack | v340_original | report | A5 | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer"` | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=software%20engineer"` |
| ng_fullstack | v340_original | report | A5 | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| ng_fullstack | v340_original | report | A5 | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| ng_fullstack | v340_original | report | A5 | `outreach.linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Software%20Engineer%2C%20New%20Grad\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20` | `outreach.linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Software%20Engineer%2C%20New%20Grad\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager \| Team engineers https://www.link` |
| ng_fullstack | v340_original | report | A5 | (none) | `outreach.linkedin.company_status: "not stated in the posting"` |
| ng_fullstack | v340_original | report | A2 | (none) | `heading_tech_v347.goingonce[0].left: "JavaScript"` |
| ng_fullstack | v340_original | report | A2 | (none) | `heading_tech_v347.goingonce[0].shown_by[0]: "launchops"` |
| ng_fullstack | v340_original | outreach | A5 | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager"` | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager"` |
| ng_fullstack | v340_original | outreach | A5 | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer"` | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=software%20engineer"` |
| ng_fullstack | v340_original | outreach | A5 | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| ng_fullstack | v340_original | outreach | A5 | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| ng_fullstack | v340_original | outreach | A5 | `linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Software%20Engineer%2C%20New%20Grad\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer ` | `linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Software%20Engineer%2C%20New%20Grad\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager \| Team engineers https://www.linkedin.com/` |
| ng_fullstack | v340_original | outreach | A5 | (none) | `linkedin.company_status: "not stated in the posting"` |
| nimble | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| nimble | v340_original | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| nimble | v340_original | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| nimble | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| nimble | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| northwind | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| northwind | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| northwind | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "features"` |
| northwind | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "internal"` |
| northwind | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "ship"` |
| northwind | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "small"` |
| northwind | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "support"` |
| northwind | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "tools"` |
| northwind | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "weekly"` |
| northwind | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "stated"` |
| northwind | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| northwind | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| northwind | v341_tune | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| northwind | v341_tune | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| northwind | v341_tune | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| northwind | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| northwind | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "automation"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "customer-specific"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "customers"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "integrations"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "production"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "prototypes"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "reach"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "tools"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "deployed"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[1]: "forward"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "You'll operate at the intersection of software engineering, infrastructure, product, and customer success."` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "customer"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "infrastructure"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "intersection"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "operate"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "product"` |
| novita | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "success"` |
| nvidia | v340_original | report | A4 | `verify_changes_v344[0].change: "Fraud: the edge-type ablation and leakage-control bullets are preferred (ML posting) (no posting line names it; script rule)"` | `verify_changes_v344[0].change: "Closing responsibility \"optimize core deep learning algorithms and libraries (e.g., CuDNN, CuBLAS), maintaining build, test, and distribution infrastructure\" with proof ripple.tests (testing)"` |
| nvidia | v340_original | report | A4 | `verify_changes_v344[0].jd_line: ""` | `verify_changes_v344[0].jd_line: "Depending on the internship role, prior experience or knowledge requirements could include the following programming skills and technologies: C, C++, CUDA, Python, x86, ARM CPU, GPU, Linux, Direct3D, Vulkan, OpenGL, OpenCL, Spark, Perl, Bas"` |
| nvidia | v340_original | report | A4 | `verify_changes_v344[1].change: "Closing responsibility \"optimize core deep learning algorithms and libraries (e.g., CuDNN, CuBLAS), maintaining build, test, and distribution infrastructure\" with proof ripple.tests (testing)"` | `verify_changes_v344[1].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| nvidia | v340_original | report | A4 | `verify_changes_v344[2].change: "Experience variant A (exp.hein.1.A, suits AI / LLM / document roles) (no posting line names it; script rule)"` | `verify_changes_v344[2].change: "Experience variant F (exp.thesis.2.F, suits real-time / IoT / embedded roles)"` |
| nvidia | v340_original | report | A4 | `verify_changes_v344[2].jd_line: ""` | `verify_changes_v344[2].jd_line: "Depending on the internship role, prior experience or knowledge requirements could include the following programming skills and technologies: C, C++, CUDA, Python, x86, ARM CPU, GPU, Linux, Direct3D, Vulkan, OpenGL, OpenCL, Spark, Perl, Bas"` |
| nvidia | v340_original | report | A4 | `verify_changes_v344[3].change: "Experience variant C (exp.hein.3.C, suits AI roles) (no posting line names it; script rule)"` | (none) |
| nvidia | v340_original | report | A4 | `verify_changes_v344[3].jd_line: ""` | (none) |
| nvidia | v340_original | report | A4 | `verify_changes_v344[4].change: "Experience variant D (exp.thesis.1.D, for every role)"` | (none) |
| nvidia | v340_original | report | A4 | `verify_changes_v344[4].jd_line: "Depending on the internship role, prior experience or knowledge requirements could include the following programming skills and technologies: C, C++, CUDA, Python, x86, ARM CPU, GPU, Linux, Direct3D, Vulkan, OpenGL, OpenCL, Spark, Perl, Bas"` | (none) |
| nvidia | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant F (exp.thesis.2.F, suits real-time / IoT / embedded roles)"` | (none) |
| nvidia | v340_original | report | A4 | `verify_changes_v344[5].jd_line: "Depending on the internship role, prior experience or knowledge requirements could include the following programming skills and technologies: C, C++, CUDA, Python, x86, ARM CPU, GPU, Linux, Direct3D, Vulkan, OpenGL, OpenCL, Spark, Perl, Bas"` | (none) |
| nvidia | v340_original | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| nvidia | v340_original | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| nvidia | v340_original | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| nvidia | v340_original | report | A4 | (none) | `internal_changes[0].change: "Fraud: the edge-type ablation and leakage-control bullets are preferred (ML posting)"` |
| nvidia | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| nvidia | v340_original | report | A4 | (none) | `internal_changes[1].change: "Experience variant A (exp.hein.1.A, suits AI / LLM / document roles)"` |
| nvidia | v340_original | report | A4 | (none) | `internal_changes[1].reason: "script rule: no posting line names it"` |
| nvidia | v340_original | report | A4 | (none) | `internal_changes[2].change: "Experience variant C (exp.hein.3.C, suits AI roles)"` |
| nvidia | v340_original | report | A4 | (none) | `internal_changes[2].reason: "script rule: no posting line names it"` |
| nvidia | v340_original | report | A4 | (none) | `internal_changes[3].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| nvidia | v340_original | report | A4 | (none) | `internal_changes[3].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "algorithms"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "application"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "core"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "crafting"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "data"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "developers"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "optimizing"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "parallel"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "structures"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "college"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[1]: "public"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[2]: "sector"` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| nvidia_devtech | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| nvidia_devtech | v340_original | report | A3 | (none) | `hiring_identity_v347.employer: "NVIDIA"` |
| nvidia_devtech | v340_original | report | A3 | (none) | `hiring_identity_v347.employer_statements[0]: "NVIDIA"` |
| nvidia_devtech | v340_original | report | A3 | (none) | `hiring_identity_v347.send_resume_to: []` |
| nvidia_devtech | v340_original | report | A3 | (none) | `hiring_identity_v347.header_labels: []` |
| nvidia_devtech | v340_original | report | A3 | (none) | `hiring_identity_v347.matches_company: true` |
| otter | v340_original | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| otter | v340_original | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| otter | v340_original | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| otter | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| otter | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| paypal | v340_original | report | A4 | `verify_changes_v344[1].change: "Closing responsibility \"create innovative experiences\" with proof exp.datamaven_access (permissions) (no posting line names it; script rule)"` | `verify_changes_v344[1].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` |
| paypal | v340_original | report | A4 | `verify_changes_v344[1].jd_line: ""` | `verify_changes_v344[1].jd_line: "putput: 'Verification: Verified 6 JD requirement lines; changes: added 'Software Development Lifecycle' from “Software Development Lifecycle (SDLC)” (high priority) and 'Code Review' from “May contribute to code & design reviews” (high prio"` |
| paypal | v340_original | report | A4 | `verify_changes_v344[2].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` | (none) |
| paypal | v340_original | report | A4 | `verify_changes_v344[2].jd_line: "putput: 'Verification: Verified 6 JD requirement lines; changes: added 'Software Development Lifecycle' from “Software Development Lifecycle (SDLC)” (high priority) and 'Code Review' from “May contribute to code & design reviews” (high prio"` | (none) |
| paypal | v340_original | report | A4 | `verify_changes_v344[3].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| paypal | v340_original | report | A4 | `verify_changes_v344[3].jd_line: ""` | (none) |
| paypal | v340_original | report | A4 | `verify_changes_v344[3].internal: true` | (none) |
| paypal | v340_original | report | A4 | (none) | `internal_changes[0].change: "Closing responsibility \"create innovative experiences\" with proof exp.datamaven_access (permissions)"` |
| paypal | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| paypal | v340_original | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| paypal | v340_original | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| perplexity | holdout | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| perplexity | holdout | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| perplexity | holdout | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| perplexity | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| perplexity | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| pinecrest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| pinecrest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| pinecrest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "boot"` |
| pinecrest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "java"` |
| pinecrest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "messaging"` |
| pinecrest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "microservices"` |
| pinecrest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "patient-facing"` |
| pinecrest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "scheduling"` |
| pinecrest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "services"` |
| pinecrest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "spring"` |
| pinecrest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words: []` |
| pinecrest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| pinecrest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| pinecrest | holdout | report | A4 | `verify_changes_v344[3].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | `verify_changes_v344[3].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| pinecrest | holdout | report | A4 | `verify_changes_v344[3].jd_line: ""` | `verify_changes_v344[3].jd_line: "- Exposure to cloud platforms (AWS, Azure, or GCP)"` |
| pinecrest | holdout | report | A4 | `verify_changes_v344[4].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | `verify_changes_v344[4].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` |
| pinecrest | holdout | report | A4 | `verify_changes_v344[5].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` | (none) |
| pinecrest | holdout | report | A4 | `verify_changes_v344[5].jd_line: "- Exposure to cloud platforms (AWS, Azure, or GCP)"` | (none) |
| pinecrest | holdout | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| pinecrest | holdout | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| pinecrest | holdout | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| pinecrest | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| pinecrest | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| pinecrest | holdout | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| pinecrest | holdout | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "across"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "analysis"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "apply"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "discovery"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "graph"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "modeling"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "notifications"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "problems"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "ranking"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[9]: "recommendations"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[10]: "search"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "learning"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[1]: "machine"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[2]: "master"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[3]: "university"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Write clean, efficient, and sustainable code"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "clean"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "code"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "efficient"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "sustainable"` |
| pinterest | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "write"` |
| pocketly | v341_tune | report | A4 | `verify_changes_v344[3].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | (none) |
| pocketly | v341_tune | report | A4 | `verify_changes_v344[3].jd_line: ""` | (none) |
| pocketly | v341_tune | report | A4 | `verify_changes_v344[4].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| pocketly | v341_tune | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| pocketly | v341_tune | report | A4 | `verify_changes_v344[4].internal: true` | (none) |
| pocketly | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| pocketly | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| pocketly | v341_tune | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| pocketly | v341_tune | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| qa_sdet | v340_original | report | A5 | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20quality%20engineering%20manager"` | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=quality%20engineering%20manager"` |
| qa_sdet | v340_original | report | A5 | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20quality%20engineer"` | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=quality%20engineer"` |
| qa_sdet | v340_original | report | A5 | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| qa_sdet | v340_original | report | A5 | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| qa_sdet | v340_original | report | A5 | `outreach.linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Software%20Development%20Engineer%20in%20Test%2C%20New%20Grad\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20quality%20engineering%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=N` | `outreach.linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Software%20Development%20Engineer%20in%20Test%2C%20New%20Grad\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=quality%20engineering%20manager \| Team e` |
| qa_sdet | v340_original | report | A5 | (none) | `outreach.linkedin.company_status: "not stated in the posting"` |
| qa_sdet | v340_original | outreach | A5 | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20quality%20engineering%20manager"` | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=quality%20engineering%20manager"` |
| qa_sdet | v340_original | outreach | A5 | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20quality%20engineer"` | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=quality%20engineer"` |
| qa_sdet | v340_original | outreach | A5 | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| qa_sdet | v340_original | outreach | A5 | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| qa_sdet | v340_original | outreach | A5 | `linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Software%20Development%20Engineer%20in%20Test%2C%20New%20Grad\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20quality%20engineering%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stat` | `linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=Software%20Development%20Engineer%20in%20Test%2C%20New%20Grad\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=quality%20engineering%20manager \| Team engineers ` |
| qa_sdet | v340_original | outreach | A5 | (none) | `linkedin.company_status: "not stated in the posting"` |
| raydar_backend | holdout | report | A4 | `verify_changes_v344[3].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| raydar_backend | holdout | report | A4 | `verify_changes_v344[3].jd_line: ""` | (none) |
| raydar_backend | holdout | report | A4 | `verify_changes_v344[3].internal: true` | (none) |
| raydar_backend | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| raydar_backend | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| raydar_swe | v341_tune | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| raydar_swe | v341_tune | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| raydar_swe | v341_tune | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| raydar_swe | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| raydar_swe | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| research_phd | v341_tune | report | A5 | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager"` | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager"` |
| research_phd | v341_tune | report | A5 | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer"` | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=software%20engineer"` |
| research_phd | v341_tune | report | A5 | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| research_phd | v341_tune | report | A5 | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| research_phd | v341_tune | report | A5 | `outreach.linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=the%20open%20engineering%20role\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engi` | `outreach.linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=the%20open%20engineering%20role\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager \| Team engineers https://www.linkedin` |
| research_phd | v341_tune | report | A5 | (none) | `outreach.linkedin.company_status: "not stated in the posting"` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "because"` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "discovery"` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "large"` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "models"` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "path"` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "question"` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "result"` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "scientific"` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "shorten"` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[9]: "they"` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "stated"` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| research_phd | v341_tune | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| research_phd | v341_tune | report | A4 | `verify_changes_v344[3].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | (none) |
| research_phd | v341_tune | report | A4 | `verify_changes_v344[3].jd_line: ""` | (none) |
| research_phd | v341_tune | report | A4 | `verify_changes_v344[4].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| research_phd | v341_tune | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| research_phd | v341_tune | report | A4 | `verify_changes_v344[4].internal: true` | (none) |
| research_phd | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| research_phd | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| research_phd | v341_tune | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| research_phd | v341_tune | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| research_phd | v341_tune | outreach | A5 | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager"` | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager"` |
| research_phd | v341_tune | outreach | A5 | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer"` | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=software%20engineer"` |
| research_phd | v341_tune | outreach | A5 | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| research_phd | v341_tune | outreach | A5 | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| research_phd | v341_tune | outreach | A5 | `linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=the%20open%20engineering%20role\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer \| R` | `linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=the%20open%20engineering%20role\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager \| Team engineers https://www.linkedin.com/sear` |
| research_phd | v341_tune | outreach | A5 | (none) | `linkedin.company_status: "not stated in the posting"` |
| roblox | v341_tune | report | A4 | `verify_changes_v344[3].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| roblox | v341_tune | report | A4 | `verify_changes_v344[3].jd_line: ""` | (none) |
| roblox | v341_tune | report | A4 | `verify_changes_v344[3].internal: true` | (none) |
| roblox | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| roblox | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| robot_sdet | v341_tune | report | A5 | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager"` | `outreach.linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager"` |
| robot_sdet | v341_tune | report | A5 | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer"` | `outreach.linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=software%20engineer"` |
| robot_sdet | v341_tune | report | A5 | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `outreach.linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| robot_sdet | v341_tune | report | A5 | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `outreach.linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| robot_sdet | v341_tune | report | A5 | `outreach.linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=the%20open%20engineering%20role\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engi` | `outreach.linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=the%20open%20engineering%20role\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager \| Team engineers https://www.linkedin` |
| robot_sdet | v341_tune | report | A5 | (none) | `outreach.linkedin.company_status: "not stated in the posting"` |
| robot_sdet | v341_tune | report | A4 | `verify_changes_v344[4].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | `verify_changes_v344[4].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| robot_sdet | v341_tune | report | A4 | `verify_changes_v344[4].jd_line: ""` | `verify_changes_v344[4].jd_line: "Strong debugging skills"` |
| robot_sdet | v341_tune | report | A4 | `verify_changes_v344[5].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | (none) |
| robot_sdet | v341_tune | report | A4 | `verify_changes_v344[5].jd_line: "Strong debugging skills"` | (none) |
| robot_sdet | v341_tune | report | A4 | `verify_changes_v344[6].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles) (no posting line names it; script rule)"` | (none) |
| robot_sdet | v341_tune | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| robot_sdet | v341_tune | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| robot_sdet | v341_tune | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| robot_sdet | v341_tune | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| robot_sdet | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| robot_sdet | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| robot_sdet | v341_tune | report | A4 | (none) | `internal_changes[1].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` |
| robot_sdet | v341_tune | report | A4 | (none) | `internal_changes[1].reason: "script rule: no posting line names it"` |
| robot_sdet | v341_tune | report | A4 | (none) | `internal_changes[2].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| robot_sdet | v341_tune | report | A4 | (none) | `internal_changes[2].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| robot_sdet | v341_tune | outreach | A5 | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager"` | `linkedin.people.manager: "https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager"` |
| robot_sdet | v341_tune | outreach | A5 | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer"` | `linkedin.people.team_engineers: "https://www.linkedin.com/search/results/people/?keywords=software%20engineer"` |
| robot_sdet | v341_tune | outreach | A5 | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20technical%20recruiter"` | `linkedin.people.recruiters: "https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter"` |
| robot_sdet | v341_tune | outreach | A5 | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20University%20at%20Buffalo"` | `linkedin.people.ub_alumni: "https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo"` |
| robot_sdet | v341_tune | outreach | A5 | `linkedin.block: "Company LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=the%20open%20engineering%20role\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineering%20manager \| Team engineers https://www.linkedin.com/search/results/people/?keywords=Not%20stated%20software%20engineer \| R` | `linkedin.block: "Company: not stated in the posting, so the people searches leave the company out\nCompany LinkedIn: not found\nLinkedIn job: not found \| Job search: https://www.linkedin.com/jobs/search/?keywords=the%20open%20engineering%20role\nPeople: Manager https://www.linkedin.com/search/results/people/?keywords=software%20engineering%20manager \| Team engineers https://www.linkedin.com/sear` |
| robot_sdet | v341_tune | outreach | A5 | (none) | `linkedin.company_status: "not stated in the posting"` |
| rocketmoney | v340_original | resume_tex | A2 | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS, JavaScript $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` |
| rocketmoney | v340_original | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| rocketmoney | v340_original | report | A4 | `verify_changes_v344[3].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| rocketmoney | v340_original | report | A4 | `verify_changes_v344[3].jd_line: ""` | (none) |
| rocketmoney | v340_original | report | A4 | `verify_changes_v344[3].internal: true` | (none) |
| rocketmoney | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| rocketmoney | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| rocketmoney | v340_original | report | A2 | (none) | `heading_tech_v347.goingonce[0].left: "JavaScript"` |
| rocketmoney | v340_original | report | A2 | (none) | `heading_tech_v347.goingonce[0].shown_by[0]: "launchops"` |
| rocketmoney | v340_original | report | A2 | (none) | `heading_tech_v347.goingonce[0].shown_by[1]: "ledgerflow"` |
| rocketmoney | v340_original | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| rocketmoney | v340_original | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| rocketmoney | v340_original | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[1]: "goingonce"` |
| rockstar | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| rockstar | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| rockstar | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "administration"` |
| rockstar | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "architecture"` |
| rockstar | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "benefit"` |
| rockstar | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "carrier"` |
| rockstar | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "integrations"` |
| rockstar | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "problems"` |
| rockstar | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "shipping"` |
| rockstar | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "workflows"` |
| rockstar | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "product"` |
| rockstar | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| rockstar | v340_original | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| rockstar | v340_original | report | A4 | `verify_changes_v344[4].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles) (no posting line names it; script rule)"` | (none) |
| rockstar | v340_original | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| rockstar | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| rockstar | v340_original | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| rockstar | v340_original | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| rockstar | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| rockstar | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| rockstar | v340_original | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| rockstar | v340_original | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| serco_snow | v341_tune | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| serco_snow | v341_tune | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| serco_snow | v341_tune | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| serco_snow | v341_tune | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| serco_snow | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| serco_snow | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| serco_snow | v341_tune | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| serco_snow | v341_tune | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| serco_sw | v341_tune | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| serco_sw | v341_tune | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| serco_sw | v341_tune | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| serco_sw | v341_tune | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| serco_sw | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| serco_sw | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| serco_sw | v341_tune | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| serco_sw | v341_tune | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| spacexsi | v340_original | report | A4 | `verify_changes_v344[4].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | (none) |
| spacexsi | v340_original | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| spacexsi | v340_original | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| spacexsi | v340_original | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| spacexsi | v340_original | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| spacexsi | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| spacexsi | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| spacexsi | v340_original | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| spacexsi | v340_original | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| sparkline | holdout | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| sparkline | holdout | resume_tex | A2 | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS, JavaScript $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` |
| sparkline | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| sparkline | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| sparkline | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "accessible"` |
| sparkline | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "dashboards"` |
| sparkline | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "designers"` |
| sparkline | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "react"` |
| sparkline | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "responsive"` |
| sparkline | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "stated"` |
| sparkline | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| sparkline | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| sparkline | holdout | report | A4 | `verify_changes_v344[1].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | (none) |
| sparkline | holdout | report | A4 | `verify_changes_v344[1].jd_line: ""` | (none) |
| sparkline | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| sparkline | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| sparkline | holdout | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| sparkline | holdout | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| sparkline | holdout | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[1]: "goingonce"` |
| sparkline | holdout | report | A2 | (none) | `heading_tech_v347.goingonce[0].left: "JavaScript"` |
| sparkline | holdout | report | A2 | (none) | `heading_tech_v347.goingonce[0].shown_by[0]: "launchops"` |
| stratus | v341_tune | report | A4 | `verify_changes_v344[4].change: "Experience variant D (exp.thesis.1.D, for every role) (no posting line names it; script rule)"` | `verify_changes_v344[4].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| stratus | v341_tune | report | A4 | `verify_changes_v344[4].jd_line: ""` | `verify_changes_v344[4].jd_line: "Deploy and operate services on Kubernetes and AWS."` |
| stratus | v341_tune | report | A4 | `verify_changes_v344[5].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | `verify_changes_v344[5].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` |
| stratus | v341_tune | report | A4 | `verify_changes_v344[6].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` | (none) |
| stratus | v341_tune | report | A4 | `verify_changes_v344[6].jd_line: "Deploy and operate services on Kubernetes and AWS."` | (none) |
| stratus | v341_tune | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| stratus | v341_tune | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| stratus | v341_tune | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| stratus | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| stratus | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| stratus | v341_tune | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| stratus | v341_tune | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "the hook shares no content word with the job title or the first responsibility line"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "analyzing"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "causes"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "identifying"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "investigate"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "issues"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "logs"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "reproducing"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "root"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "software-related"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "stated"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: "Code Reviews: Participate in code reviews, both as a reviewer and a reviewee, to ensure adherence to coding best practices and high-quality deliverables."` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[0]: "adherence"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[1]: "best"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[2]: "code"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[3]: "coding"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[4]: "deliverables"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[5]: "ensure"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[6]: "high-quality"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[7]: "participate"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[8]: "practices"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[9]: "reviewee"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[10]: "reviewer"` |
| swisslog | holdout | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words[11]: "reviews"` |
| swisslog | holdout | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| swisslog | holdout | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| swisslog | holdout | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| swisslog | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| swisslog | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| tailscale | holdout | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| tailscale | holdout | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| tailscale | holdout | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| tailscale | holdout | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| tailscale | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| twitch | holdout | report | A4 | `verify_changes_v344[0].change: "Preflight: a bullet that names Go is preferred (ledgerflow.eo.b, ledgerflow.eo.c, ledgerflow.ci.b) (no posting line names it; script rule)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Java is preferred (ledgerflow.eo.b, ledgerflow.eo.c, ledgerflow.ci.b)"` |
| twitch | holdout | report | A4 | `verify_changes_v344[0].jd_line: ""` | `verify_changes_v344[0].jd_line: "Java"` |
| twitch | holdout | report | A4 | `verify_changes_v344[1].change: "Preflight: a bullet that names Java is preferred (ledgerflow.eo.b, ledgerflow.eo.c, ledgerflow.ci.b)"` | `verify_changes_v344[1].change: "Closing responsibility \"write technical documentation\" with proof ledger.ci (testing)"` |
| twitch | holdout | report | A4 | `verify_changes_v344[1].jd_line: "Java"` | `verify_changes_v344[1].jd_line: "- Experience writing technical documentation"` |
| twitch | holdout | report | A4 | `verify_changes_v344[2].change: "Closing responsibility \"write technical documentation\" with proof ledger.ci (testing)"` | `verify_changes_v344[2].change: "Experience variant F (exp.thesis.2.F, suits real-time / IoT / embedded roles)"` |
| twitch | holdout | report | A4 | `verify_changes_v344[2].jd_line: "- Experience writing technical documentation"` | `verify_changes_v344[2].jd_line: "- Proficiency in at least one of Go, Ruby, Java, or C++"` |
| twitch | holdout | report | A4 | `verify_changes_v344[3].change: "Experience variant F (exp.thesis.2.F, suits real-time / IoT / embedded roles)"` | `verify_changes_v344[3].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| twitch | holdout | report | A4 | `verify_changes_v344[3].jd_line: "- Proficiency in at least one of Go, Ruby, Java, or C++"` | `verify_changes_v344[3].jd_line: "- Design, build, and operate scalable payment services in Go and Java on AWS"` |
| twitch | holdout | report | A4 | `verify_changes_v344[4].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | `verify_changes_v344[4].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` |
| twitch | holdout | report | A4 | `verify_changes_v344[5].change: "Experience variant H (exp.datamaven.1.H, suits cloud / security roles)"` | `verify_changes_v344[5].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` |
| twitch | holdout | report | A4 | `verify_changes_v344[5].jd_line: "- Design, build, and operate scalable payment services in Go and Java on AWS"` | `verify_changes_v344[5].jd_line: "- Participate in design and code reviews"` |
| twitch | holdout | report | A4 | `verify_changes_v344[6].change: "Experience variant I (exp.thesis.1.I, suits postings naming Agile, Scrum, code review or pull requests)"` | (none) |
| twitch | holdout | report | A4 | `verify_changes_v344[6].jd_line: "- Participate in design and code reviews"` | (none) |
| twitch | holdout | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| twitch | holdout | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| twitch | holdout | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| twitch | holdout | report | A4 | (none) | `internal_changes[0].change: "Preflight: a bullet that names Go is preferred (ledgerflow.eo.b, ledgerflow.eo.c, ledgerflow.ci.b)"` |
| twitch | holdout | report | A4 | (none) | `internal_changes[0].reason: "script rule: no posting line names it"` |
| twitch | holdout | report | A4 | (none) | `internal_changes[1].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| twitch | holdout | report | A4 | (none) | `internal_changes[1].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| twitch_se1 | v342_new | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| twitch_se1 | v342_new | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| twitch_se1 | v342_new | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| twitch_se1 | v342_new | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| twitch_se1 | v342_new | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| umich | v341_tune | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| umich | v341_tune | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| umich | v341_tune | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| umich | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| umich | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| us_cold | v342_new | resume_tex | A2 | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS, JavaScript $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{GoingOnce: Multi-Agent Car Marketplace} $\|$ Python, LangGraph, ReactJS $\|$ \href{https://github.com/raunakpandey1/goingonce}{\underline{GitHub}} \hfill \textit{October 2026}` |
| us_cold | v342_new | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| us_cold | v342_new | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| us_cold | v342_new | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| us_cold | v342_new | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| us_cold | v342_new | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| us_cold | v342_new | report | A2 | (none) | `heading_tech_v347.goingonce[0].left: "JavaScript"` |
| us_cold | v342_new | report | A2 | (none) | `heading_tech_v347.goingonce[0].shown_by[0]: "launchops"` |
| ust_software_engineer | v347_new | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| ust_software_engineer | v347_new | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| ust_software_engineer | v347_new | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| ust_software_engineer | v347_new | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| ust_software_engineer | v347_new | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| vindexa | v340_original | report | A4 | `verify_changes_v344[7].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| vindexa | v340_original | report | A4 | `verify_changes_v344[7].jd_line: ""` | (none) |
| vindexa | v340_original | report | A4 | `verify_changes_v344[7].internal: true` | (none) |
| vindexa | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| vindexa | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| wgu | v341_tune | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| wgu | v341_tune | report | A4 | `verify_changes_v344[5].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| wgu | v341_tune | report | A4 | `verify_changes_v344[5].jd_line: ""` | (none) |
| wgu | v341_tune | report | A4 | `verify_changes_v344[5].internal: true` | (none) |
| wgu | v341_tune | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| wgu | v341_tune | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| wgu | v341_tune | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| wgu | v341_tune | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| wpp | v340_original | report | A4 | `verify_changes_v344[6].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| wpp | v340_original | report | A4 | `verify_changes_v344[6].jd_line: ""` | (none) |
| wpp | v340_original | report | A4 | `verify_changes_v344[6].internal: true` | (none) |
| wpp | v340_original | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| wpp | v340_original | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| zoro_fullstack | v347_new | resume_tex | A2 | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka, JavaScript $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` | `\noindent\textbf{LedgerFlow: Event-Driven Payment Ledger} $\|$ Java, Spring Boot, Kafka $\|$ \href{https://github.com/Jaypath456/ledgerFlow}{\underline{GitHub}} \hfill \textit{October 2026}` |
| zoro_fullstack | v347_new | letter_txt | A1 | `LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side rules reject forged evidence, skipped prerequisites, and duplicate submissions. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit a` | `LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side rules reject forged evidence, skipped prerequisites, and duplicate submissions. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit a` |
| zoro_fullstack | v347_new | report | A1 | `cover_letter.words: 165` | `cover_letter.words: 170` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.test: "hook shares a content word (4+ letters, not generic) with the job title or the first responsibility line"` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.failed: "no first responsibility line was found, and the hook shares no content word with the job title"` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[0]: "customer"` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[1]: "data"` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[2]: "demand"` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[3]: "deployment"` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[4]: "management"` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[5]: "monitoring"` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[6]: "processes"` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[7]: "scale"` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.hook_words[8]: "zoro"` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[0]: "developer-"` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[1]: "full"` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.title_words[2]: "stack"` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_line: ""` |
| zoro_fullstack | v347_new | report | A6 | (none) | `cover_letter.hook_specific_reason.first_responsibility_words: []` |
| zoro_fullstack | v347_new | report | A1 | `cover_letter.words_total: 172` | `cover_letter.words_total: 177` |
| zoro_fullstack | v347_new | report | A4 | `verify_changes_v344[4].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` | (none) |
| zoro_fullstack | v347_new | report | A4 | `verify_changes_v344[4].jd_line: ""` | (none) |
| zoro_fullstack | v347_new | report | A4 | `verify_changes_v344[4].internal: true` | (none) |
| zoro_fullstack | v347_new | report | A4 | (none) | `internal_changes[0].change: "Experience variant J (exp.godigital.1.J, verb-only: another Experience bullet on the page opens with Developed)"` |
| zoro_fullstack | v347_new | report | A4 | (none) | `internal_changes[0].reason: "script rule: verb-only variant, so two Experience bullets never open with the same verb (not posting-driven)"` |
| zoro_fullstack | v347_new | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].left: "JavaScript"` |
| zoro_fullstack | v347_new | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[0]: "launchops"` |
| zoro_fullstack | v347_new | report | A2 | (none) | `heading_tech_v347.ledgerflow[0].shown_by[1]: "goingonce"` |
| zoro_fullstack | v347_new | report | A3 | (none) | `hiring_identity_v347.employer: "Zoro"` |
| zoro_fullstack | v347_new | report | A3 | (none) | `hiring_identity_v347.employer_statements[0]: "Zoro"` |
| zoro_fullstack | v347_new | report | A3 | (none) | `hiring_identity_v347.send_resume_to: []` |
| zoro_fullstack | v347_new | report | A3 | (none) | `hiring_identity_v347.header_labels: []` |
| zoro_fullstack | v347_new | report | A3 | (none) | `hiring_identity_v347.matches_company: true` |
