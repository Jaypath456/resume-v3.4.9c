# Resume pipeline v3.4.7c: changes (2026-10-18)

Built from Resume_Pipeline_3_4_7b.zip. One rule, C1, behind the new master.json `v347_flags` entry `strict_fleet`
(default true). With it off (test-only `--regression-v347-flags-off=strict_fleet`, or `V347_FLAGS_OFF=strict_fleet` in
run_all.py), every fixture equals `3_validation/baseline_v347b/` (the unmodified 7b outputs), apart from the version
label on the two stop reports.

Hash lock: pipeline b96bab1d | master 6efa8598 | bank d56f0743 (unchanged) | template 1309898b (unchanged) |
context md 9003110a. plan_template.json and bank_check.py are unchanged. Code changes edit only the final definitions of
`_v347b_bullet_relevance`, `auto_bank_selection`, `build_skill_states`, `compose_bank_cover_letter` and `main_v3_1`, plus
`V347_FLAG_NAMES` / `PIPELINE_VERSION` and new helpers in a "v3.4.7c layer" block before `if __name__`; names defined more
than once stay 61. The 7b test switch `V347B_STRICT_FLEET` is removed (it is the rule now); `V347B_AI_PREFER` stays a
test-only switch.

Changed Sources: `resume_pipeline_v3_2.py`, `master.json` (`strict_fleet` flag, md pointer),
`Master_Resume_Context_LEAN_CURRENT_v3_2.md` (new section 0-v347c). Other changed files: `2_PROJECT_INSTRUCTIONS_paste.txt`
(version and hash lock only), `0_SETUP_STEPS.txt`, selftest_v342 to v347b (version checks; selftest_v347b also turns
strict_fleet off in its 7a-equivalence builds), new `selftest_v347c.py`, `predict_v347c.py`, `predicted_changes_v347c.json`,
`diff_gate_v347c.py`, `baseline_v347b/`, refreshed `4_sample_outputs/` and `5_judged_packages/` (Judge_Batch_v3_4_7c.md).
The old CHANGES.md is now CHANGES_v3_4_7b.md.

## Safety steps (same method as 7a / 7b)

1. `baseline_v347b/`: all 124 fixtures on the unmodified 7b Sources; two 7b runs identical.
2. `predict_v347c.py` restates the rule (no 7c code) and wrote `predicted_changes_v347c.json` before the code changed.
3. `diff_gate_v347c.py gate`: every changed line predicted (or justified with a reason), plus the allowlist guard and the
   resume / letter / tracker / report guards (see its docstring). Result PASS (DIFF_REPORT_v347c.md).
4. Two 7c runs identical; strict_fleet-off run identical to baseline_v347b.

## C1 strict_fleet

- Trigger: the 7b B4 logistics test (`v347b_logistics_line`): a supply-chain / warehouse / logistics / vehicle-fleet
  posting line, title or company. Only those pages keep `goingonce.fleet.a`.
- Swap: in `_v347b_bullet_relevance`, a non-lead Fleet bullet on any other page is the bullet to replace (no score
  margin needed). Candidates: other GoingOnce bullets with the same line count, an evidence id not already on the page
  and a verb no other page bullet uses; the best B4 score wins, and the swap is kept only if the selector reproduces the
  exact page (FAIL-CLOSED). A swap that also clears the B4 margin is logged as B4, as in 7b.
- Skills: `build_skill_states` builds from the page as it was before the swap, so Skills never change.
- Letter: `compose_bank_cover_letter` writes the letter as before the swap, then replaces the Fleet sentence (if any)
  with the new bullet's letter sentence.
- Retry (`_v347c_retry`, called from `main_v3_1`): a build that does not PASS with the swap (e.g. the new bullet names a
  technology Skills do not show) is rebuilt with the next candidate, at most four times, then with the Fleet bullet
  (the 7b page, byte-identical).
- Log: report.json `strict_fleet_v347c` when a swap ships; `V347C_DEBUG=<path>` dumps the attempts of one run.
- Result: 13 swaps, all on Jay's allowlist; 7 allowlisted fixtures keep Fleet (FAIL-CLOSED, reasons in NOTES).
