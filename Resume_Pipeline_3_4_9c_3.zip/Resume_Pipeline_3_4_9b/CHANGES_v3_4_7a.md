# Resume pipeline v3.4.7a: changes (2026-10-18)

Built from Resume_Pipeline_3_4_6.zip. Low-risk build: safety tooling first (S1 to S5), then six narrow fixes (A1 to A6),
each behind its own switch in master.json `v347_flags` (default true). Nothing else changed: no project selection,
ranking, bullet, Fit, blocker, Skills, tracker or layout change on any fixture (the diff gate checks this on every line).

Hash lock: pipeline 879ef747 | master 0227a736 | bank d56f0743 (unchanged) | template 1309898b (unchanged) |
context md 7a052c4e. plan_template.json and bank_check.py are unchanged. Code changes edit the final definition of each
function in place (compose_bank_cover_letter, build_project_block, hook_specific, build_cover_letter, build_outreach,
main_v3_1), plus new helper names in a "v3.4.7a layer" block before `if __name__`; names defined more than once stay 61.
bullet_bank.json and Resume_Template_CURRENT.tex are not edited.

Changed Sources: `resume_pipeline_v3_2.py`, `master.json` (adds `v347_flags`; md pointer), `Master_Resume_Context_LEAN_CURRENT_v3_2.md`
(new section 0-v347a). Other changed files: `2_PROJECT_INSTRUCTIONS_paste.txt`, `0_SETUP_STEPS.txt`, `3_validation/run_all.py`
(V347_FLAGS_OFF, SRC), `score_all.py` (v347_new group), `manifest.json` (+4 fixtures), `jds/` (+4 postings), selftest_v342 to
v346 (version checks only), new `selftest_v347a.py`, `diff_gate_v347.py`, `predict_v347a.py`, `predicted_changes_v347a.json`,
`baseline_v346/`. The old CHANGES.md is now CHANGES_v3_4_6.md.

---

## Safety tooling

- **S1 fixtures and baseline.** New suite "v347" (group v347_new): zoro_fullstack, alml_engineer, ust_software_engineer,
  meritore_capgemini, with stand-in plan fields that pass the v3.4.6 rules. `3_validation/baseline_v346/<fixture>/` holds
  resume.tex, letter.txt, report.json, tracker_row.json and outreach.json (the outreach block) for all 124 fixtures, run on the
  unmodified v3.4.6 Sources.
- **S2 determinism.** Two full runs of the v3.4.6 code are identical after normalizing only `report.json timestamps.*`
  (start, end, duration_ms of every stage) and `report.json pdflatex_calls[*].duration_ms`. Nothing else differed.
- **S3 flags.** `--regression-v347-flags-off=all|name,...` (test-only, like `--regression-allow-missing-title`;
  `V347_FLAGS_OFF=all python3 run_all.py`) switches fixes off without editing the hash-locked master. With every flag off,
  all 124 fixtures are identical to baseline_v346; the only listed difference is the `pipeline_version` label
  ("v3.4.6" -> "v3.4.7a") in the reports of the two expected stops, which are the only reports that carry it.
- **S4 predictions.** `predict_v347a.py` was written and run, and `predicted_changes_v347a.json` saved, before any code
  change. It restates each rule independently of the code.
- **S5 diff gate.** `diff_gate_v347.py gate baseline_v346 <new snapshot>`: every changed line must match a prediction; an
  unpredicted change on v340_original or a holdout fails; elsewhere it needs a written justification. It also fails on
  any change to a resume bullet, a Skills line, a project heading name, the tracker row, report Fit / blockers / gaps /
  status, or the letter outside A1. Result: PASS, 1,719 changed lines in 115 fixtures, 0 unpredicted, 0 invariant
  violations, every prediction happened. The one justification is the version label above.

## A1 relocation (`relocation_fix`)

Only Buffalo, NY (the city Buffalo with NY / N.Y. / New York) counts as local. Any other place containing "Buffalo" gets
"I am open to relocating." on onsite / hybrid postings; remote postings never get it (a remote letter that had it would
lose it; no fixture did). Scan: one fixture, zoro_fullstack (Buffalo Grove, IL). Letter, before:
```
... it never overdrew the account. I graduate in February 2027 and can start work that month. I want to build scalable ...
```
After:
```
... it never overdrew the account. I graduate in February 2027 and can start work that month. I am open to relocating. I want to build scalable ...
```

## A2 heading technology placement (`heading_tech_fix`)

A technology the posting names that the script added to a heading (not in master header_priority_tech) stays only on
the selected project whose bullets best show it, at most one heading. It leaves a heading whose bullets do not show it
when another selected project's heading or bullets do. A framework bullet shows its language (React -> JavaScript;
Django, pytest, Streamlit ... -> Python; Spring -> Java). Core stack and a technology only one project shows (Maven on
LedgerFlow) stay. The slot is not refilled, and the change is applied only to the rendered heading, so Skills and their
order are unchanged. 23 fixtures, all JavaScript (9 v340_original, 7 v341_tune, 4 holdouts, 2 v342_new, zoro). zoro:
```
LedgerFlow: Event-Driven Payment Ledger $|$ Java, Spring Boot, Kafka, JavaScript   ->   ... $|$ Java, Spring Boot, Kafka
GoingOnce: Multi-Agent Car Marketplace $|$ Python, LangGraph, ReactJS, JavaScript   (unchanged: its React bullet shows it)
```
report.json `heading_tech_v347` records each move and which project shows the technology instead.

## A3 hiring identity (`identity_fix`)

The script reads employer statements in the posting body ("<Org> ... has (multiple) openings", "<Org> is hiring", "send
resume to <...@domain>") and any "company:" header label. When the employer differs from application.company, or a
header label differs while the employer matches, report.json notes gets "Posted under <label>; the posting names
<employer> as the employer." Nothing is renamed. A letter sentence that names another organization from the posting
fails the build with `cover_letter_two_organizations` (fix the hook). report.json `hiring_identity_v347` shows what was
found. Fixtures: meritore_capgemini (Notes: "Posted under Capgemini; the posting names Meritore Technologies LLC as the
employer."), zoro, cobalt, nvidia_devtech (employer = company, no note). Instructions: application.company = the
organization the posting says has the opening or receives applications; a different board/header label goes in Notes;
the recruiter / agency rule is kept.

## A4 report clarity (`report_fix`)

verify_changes_v344 entries with no quoted posting line move to `internal_changes` with a reason; every remaining entry
quotes a JD line. Before (zoro): `{"change": "Experience variant J (... verb-only ...)", "jd_line": "", "internal": true}`
in verify_changes_v344. After: in internal_changes with `"reason": "script rule: verb-only variant, so two Experience
bullets never open with the same verb (not posting-driven)"`. The " (no posting line names it; script rule)" suffix
becomes the reason "script rule: no posting line names it". 99 fixtures. Report only.

## A5 outreach with no company (`outreach_fix`)

When application.company is "Not stated", the people searches leave the company keyword out and the block starts with
"Company: not stated in the posting, so the people searches leave the company out"; `linkedin.company_status` says the
same. No URL contains "Not%20stated". 8 fixtures. Before: `keywords=Not%20stated%20machine%20learning%20manager`;
after: `keywords=machine%20learning%20manager`. Outreach only.

## A6 hook-specificity reason (`hook_reason_fix`)

hook_specific's test is unchanged (moved into v347_hook_detail; selftest_v347a checks the verdict equals v3.4.6 on every
fixture hook). When it returns false, report.json cover_letter.hook_specific_reason names the test, why it failed, and
the words it compared. 40 fixtures. Report only.
