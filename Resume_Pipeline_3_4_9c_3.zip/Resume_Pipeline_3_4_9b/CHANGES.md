# Resume pipeline v3.4.9b: changes (2026-10-20)

Built from Resume_Pipeline_3_4_9a.zip. A format build: US Letter page in Times (mathptmx), the reference header, bold
results, Skills in at most 5 lines, and the reference's two trims, following General_CV_reference.tex. Every change sits
behind its own master.json `v347_flags` entry (default true): `bank_format_v349b`, `format_letter_v349b`,
`bold_results_v349b`, `skills_cap5_v349b`, `letter_trims_v349b` (38 flags). With all five off (test-only
`--regression-v347-flags-off=...`, or `V347_FLAGS_OFF=...` for run_all.py) every fixture equals
`3_validation/baseline_v349a/` (the unmodified 9a outputs) on 128 fixtures; the A4 template is rebuilt byte for byte
(dc281778). Facts are unchanged: Jay graduates in December 2026 and can start work in February 2027. No new evidence.

Hash lock: pipeline 76c1c6ea | master d4e92491 | bank 914805e9 | template 137af61b (Letter) | context md d883cfa0.
bank_check.py 205567fe (Letter measurement); plan_template.json 4358f1e0 (unchanged).

## Phase 0 (measure only)
Letter + mathptmx copy measured before any edit: 75/118 bank variants failed (limit 50), so the build stopped. Jay chose
a tail floor of 0.30 on Letter (0.3in margins kept). Details: format_report.md section 0.

## Phase 1: bank_format_v349b
Two new variant ids for the two variants that still failed: `ripple.tests.s2` (replaces ripple.tests.s1) and
`pintos.tests.c` (replaces pintos.tests.a). Same numbers, no new names, no more words, unique opening verb, passes
bank_check on Letter (3_validation/reword_v349b.py). The old ids stay in the bank for flags off.

## Phase 2
- format_letter_v349b: Resume_Template_CURRENT.tex is the Letter template (letterpaper, mathptmx, header
  "email | phone | NY, US | linkedin.com/in/jaypathare3 | github.com/Jaypath456" with the visible address as link text and
  no portfolio, section rules 0.2em / 0.25em, 3pt between projects). With the flag off the pipeline restores the A4
  template text. Fit steps: the v3.4.9a page is built first as the reference; the Letter page keeps its bullets and order;
  if it misses one Letter page with 10pt spare, the optional coursework line leaves, then one bullet slot leaves the
  lowest-ranked project with two or more, keeping the letter unchanged (report.json format_v349b.letter_fit).
- bold_results_v349b: at render time, a numeric result plus up to 3 following words, at most 2 spans per bullet, only in
  Experience and Personal Projects bullets. Stripping \textbf gives the plain page exactly.
- skills_cap5_v349b: skills_rendered_lines_max 5, one line per category; items leave in order filler, posting-named
  skills the page shows, other posting-named non-priority skills ("Skills full" note), must / high terms a bullet already
  shows. Required ATS terms and page technologies stay; when they alone need it, one category takes a second line
  (6 lines on 5 of 126 pages).
- letter_trims_v349b (decision card 2, "Reference trims"): the HeinOnline "Interviewed" line uses its short form and the
  AWS certification line is not shown.

Code: final definitions only (`assemble_latex`, `experience_byte_check`, `experience_variants_stage`,
`apply_auto_plan_fields`, `skills_text_hash`, `_v341_est_lines`, `build_skill_states`, `tex_skill_measurement_and_selection`,
`validate_pdf`, `v348c_w_map`, `v348c_selection_bank`, `_v348c_post_run`, `build_cover_letter`, `_v341_project_combos`,
`_v343_slots`, `_v345_set_coursework`, `auto_bank_selection`, `main_v3_1`), plus `V347_FLAG_NAMES` and `PIPELINE_VERSION`
("v3.4.9b"); new helpers in a "v3.4.9b layer" before `if __name__`. Names defined more than once stay 61. No file renamed
(CHANGES_v3_4_9a.md is a copy of the old CHANGES.md).

## Validation
- diff_gate_v349b.py gate baseline_v349a vs flags on (and bold off): PASS, 128 fixtures, 0 failing.
- Determinism: flags on twice identical. Flags off: identical to baseline_v349a.
- golden_check: 11/12 (ebsco_sde1 rank1 LedgerFlow, as in 9a; no new failure).
- score_all: tuned 9.97, holdouts 9.80 / 9.97 (as in 9a). audit_v344: 13/126 fallback closings = 10.3% (as in 9a).
- bank_check on Letter: 120/120, Experience 10/10. Selftests v341-v349b: see NOTES_v3_4_9b.md.
- Validation tools updated: score_all.py reads Experience lines without bold and accepts the short Interviewed line;
  bank_check.py measures Letter with and without bold; older selftests accept v3.4.9b and pin the flags off.
