#!/usr/bin/env python3
"""
bank_check.py - verify every bullet in bullet_bank.json against the live template + master.json + validator.

For each bank variant it checks:
  1. SEMANTIC: runs resume_pipeline.validate_semantic_plan on the variant alone (same rules the resume pipeline uses).
  2. GEOMETRY: compiles all variants in the template's own preamble (one itemize, same margins/font) and measures
     physical lines + second-line fill from PDF coordinates (pdftotext -bbox-layout; no PyMuPDF needed).
  3. CONFLICTS: which variants in the same project share a salient phrase (cannot be picked together).

Usage:
  python bank_check.py --template Resume_Template_CURRENT.tex --master master.json \
      --pipeline resume_pipeline.py --bank bullet_bank.json --out-dir bank_out [--write-back]

Pass criteria (geometry): a variant's rendered line count equals its "lines" field (default 2).
  2-line variants: second-line fill in [0.50, 0.92]. 1-line variants (v3.4.1, used in pairs that fill one 2-line slot):
  exactly 1 line with fill >= 0.50 of the text width.
Lints (v3.4.1): no filler tail phrase (master writing_rules.filler_tail_phrases), no Experience verb anywhere in a
  project bullet (master banned_project_verbs, which lists every Experience opening verb), and each 1-line variant
  must have at least one partner in its project (different main evidence, verb, no conflict) so it can fill a slot.
Exit code 0 only when every variant passes. Output: bank_out/bank_report.json (+ updated bank with --write-back).
v3.4.9b: on the Letter template (letterpaper in the preamble, master v347_flags format_letter_v349b true) the 2-line
  tail floor is master layout_v349b.format_letter_v349b.bank_tail_fill_min (0.30, Jay 2026-10-20); with
  bold_results_v349b true each variant is measured as the page renders it (bold results) AND plain, and must pass both.
  An old id replaced by a bank_format_v349b wording is used only with the flag off (the A4 page) and is reported, not
  failed, on Letter. Every template Experience bullet must keep its line count when its results are bold.
"""
import argparse, importlib.util, json, re, subprocess, sys, types
from pathlib import Path

MIN_TAIL, MAX_TAIL = 0.50, 0.92
MIN_ONE_LINE = 0.50
IGNORED_SEMANTIC = {"rank1_missing_hero_evidence", "rank1_missing_headline_evidence"}


def load_pipeline(path: Path):
    try:
        import fitz  # noqa: F401
    except ImportError:               # validator functions used here never touch fitz
        sys.modules["fitz"] = types.ModuleType("fitz")
    spec = importlib.util.spec_from_file_location("resume_pipeline_mod", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def resolve_claims(master, pid, v):
    """claims are stored as exact atoms; verify they exist in the referenced evidence."""
    return list(v["claims"])


def semantic_check(pipe, master, pid, v):
    items = master["projects"][pid]["evidence_items"]
    themes = sorted({t for it in items.values() for t in it.get("optional_themes", [])})
    bullet = {
        "text": v["text"], "verb": v["verb"], "main_evidence_id": v["main_evidence_id"],
        "supporting_evidence_ids": v.get("supporting_evidence_ids", []),
        "claims": resolve_claims(master, pid, v), "jd_terms": v.get("jd_terms", []),
    }
    plan = {"ranking": [pid], "jd_themes": themes, "bullets": {pid: [bullet]}}
    fails = pipe.validate_semantic_plan(plan, master)
    return [f for f in fails if f["type"] not in IGNORED_SEMANTIC]


def build_tex(template: str, texts, latex_escape, raw=False):
    pre = template.split(r"\begin{document}")[0]
    items = "\n".join(r"\item " + (t if raw else latex_escape(t)) for t in texts)
    return (pre + "\\begin{document}\n\\begin{itemize}\n\\setlength{\\itemsep}{0pt}\n"
            + items + "\n\\end{itemize}\n\\end{document}\n")


def measure(tex: str, workdir: Path, right_margin_pt: float):
    workdir.mkdir(parents=True, exist_ok=True)
    (workdir / "bank.tex").write_text(tex, encoding="utf-8")
    p = subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "bank.tex"],
                       cwd=workdir, capture_output=True, text=True)
    if p.returncode != 0:
        raise SystemExit("pdflatex failed:\n" + "\n".join(p.stdout.splitlines()[-25:]))
    subprocess.run(["pdftotext", "-bbox-layout", "bank.pdf", "bank.html"], cwd=workdir, check=True)
    html = (workdir / "bank.html").read_text(encoding="utf-8")
    page_w = float(re.search(r'<page width="([\d.]+)"', html).group(1))
    lines = []
    for x0, _y0, x1, _y1, body in re.findall(
            r'<line xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(.*?)</line>', html, re.S):
        lines.append((float(x0), float(x1)))
    first_x = min(x for x, _ in lines)
    bullets = []
    for x0, x1 in lines:
        if x0 <= first_x + 5:
            bullets.append([(x0, x1)])
        elif bullets:
            bullets[-1].append((x0, x1))
    out = []
    cont = [b[1][0] for b in bullets if len(b) >= 2]
    cx_default = min(cont) if cont else first_x + 10
    for b in bullets:
        if len(b) < 2:
            avail = page_w - right_margin_pt - cx_default
            out.append({"lines": len(b), "tail_fill": round((b[0][1] - cx_default) / avail, 3)})
            continue
        cx0, cx1 = b[1]
        avail = page_w - right_margin_pt - cx0
        out.append({"lines": len(b), "tail_fill": round((b[-1][1] - b[-1][0]) / avail, 3)})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--template", required=True, type=Path)
    ap.add_argument("--master", required=True, type=Path)
    ap.add_argument("--pipeline", required=True, type=Path)
    ap.add_argument("--bank", required=True, type=Path)
    ap.add_argument("--out-dir", required=True, type=Path)
    ap.add_argument("--write-back", action="store_true")
    a = ap.parse_args()

    pipe = load_pipeline(a.pipeline)
    master = json.loads(a.master.read_text(encoding="utf-8"))
    bank = json.loads(a.bank.read_text(encoding="utf-8"))
    variants = [(pid, v) for pid, vs in bank["projects"].items() for v in vs]

    right_margin = master["layout_rules"]["margins_in"]["right"] * 72.0
    ttext = a.template.read_text(encoding="utf-8")
    flags = master.get("v347_flags") or {}
    letter = "letterpaper" in ttext.split(r"\begin{document}")[0] and flags.get("format_letter_v349b", True) and bool(master.get("layout_v349b"))
    bold = letter and flags.get("bold_results_v349b", True) and hasattr(pipe, "v349b_bold_text")
    global MIN_TAIL, MAX_TAIL, MIN_ONE_LINE
    if letter:
        fl = master["layout_v349b"]["format_letter_v349b"]
        MIN_TAIL, MAX_TAIL, MIN_ONE_LINE = fl["bank_tail_fill_min"], fl["bank_tail_fill_max"], fl["bank_one_line_fill_min"]
    replaced = {(v.get("v348c") or {}).get("replaces") for _, v in variants if (v.get("v348c") or {}).get("flag") == "bank_format_v349b"} if letter else set()
    esc = (lambda t: pipe.v349b_bold_text(pipe.latex_escape(t))) if bold else pipe.latex_escape
    tex = build_tex(ttext, [esc(v["text"]) for _, v in variants], pipe.latex_escape, raw=True)
    geo = measure(tex, a.out_dir, right_margin)
    if len(geo) != len(variants):
        raise SystemExit(f"parsed {len(geo)} bullets but bank has {len(variants)}; check template preamble/parsing")
    geo_plain = measure(build_tex(ttext, [v["text"] for _, v in variants], pipe.latex_escape), a.out_dir / "plain", right_margin) if bold else geo

    exempt_global = set(master.get("semantic_phrase_overlap_exemptions", []))
    report = {"summary": {}, "variants": {}}
    bad = 0
    report["format"] = {"letter": bool(letter), "bold": bool(bold), "tail_fill_min": MIN_TAIL, "tail_fill_max": MAX_TAIL, "one_line_fill_min": MIN_ONE_LINE,
                        "replaced_old_ids": sorted(x for x in replaced if x)}
    for (pid, v), g, gp in zip(variants, geo, geo_plain):
        sem = semantic_check(pipe, master, pid, v)
        reasons = []
        want = int(v.get("lines", 2))
        for tag, gg in (("", g), (" (plain)", gp)) if bold else (("", g),):
            if gg["lines"] != want:
                reasons.append(f"lines={gg['lines']} (want {want}){tag}")
            elif want == 1:
                if gg["tail_fill"] < MIN_ONE_LINE:
                    reasons.append(f"one-line fill {gg['tail_fill']} < {MIN_ONE_LINE}{tag}")
            elif gg["tail_fill"] < MIN_TAIL:
                reasons.append(f"tail {gg['tail_fill']} < {MIN_TAIL}{tag}")
            elif gg["tail_fill"] > MAX_TAIL:
                reasons.append(f"tail {gg['tail_fill']} > {MAX_TAIL}{tag}")
        if v["id"] in replaced:   # v3.4.9b: used only with bank_format_v349b off (the A4 page)
            report.setdefault("replaced_v349b", {})[v["id"]] = reasons
            reasons = [r for r in reasons if not (r.startswith("lines=") or r.startswith("tail ") or r.startswith("one-line fill"))]
        for f in sem:
            reasons.append(f"{f['type']}: {f['measured']}")
        low = v["text"].lower()
        filler = [x for x in master.get("writing_rules", {}).get("filler_tail_phrases", []) if x.lower() in low]
        if filler:
            reasons.append(f"filler_phrase: {filler}")
        exp_verbs = sorted({b.split()[0] for r in master.get("experience", []) for b in r.get("bullets", [])} | set(master.get("banned_project_verbs", [])))
        hit = [x for x in exp_verbs if re.search(r"\b" + re.escape(x) + r"\b", v["text"], re.I)]
        if hit:
            reasons.append(f"experience_verb: {hit}")
        v["measured"] = {"lines": g["lines"], "tail_fill": g["tail_fill"]}
        v["status"] = "ok" if not reasons else "FAIL"
        if reasons:
            bad += 1
            report["variants"][v["id"]] = reasons

    # pairwise conflicts inside each project (different main evidence only)
    for pid, vs in bank["projects"].items():
        tech_bi = {x.lower() for x in master["projects"][pid].get("tech", []) if len(x.split()) == 2}
        for v in vs:
            v["conflicts_with"] = []
        for i, vi in enumerate(vs):
            for vj in vs[i + 1:]:
                if vi["main_evidence_id"] == vj["main_evidence_id"]:
                    continue
                shared = (pipe.salient_bigrams(vi["text"]) & pipe.salient_bigrams(vj["text"])) - exempt_global - tech_bi
                # v3.4.2: two variants that state the same number restate one result (e.g. "241 tests" in a Claude Code
                # bullet and in the test-suite bullet), so they never share a page
                nums = set(re.findall(r"\d[\d,.]*\d|\d", vi["text"])) & set(re.findall(r"\d[\d,.]*\d|\d", vj["text"]))
                if shared or nums:
                    vi["conflicts_with"].append(vj["id"])
                    vj["conflicts_with"].append(vi["id"])

    # every 1-line variant needs a partner that can share a slot with it
    for pid, vs in bank["projects"].items():
        for v in vs:
            if int(v.get("lines", 2)) != 1 or v["status"] != "ok":
                continue
            ok = [w["id"] for w in vs if w is not v and int(w.get("lines", 2)) == 1 and w["status"] == "ok"
                  and w["main_evidence_id"] != v["main_evidence_id"] and w["verb"].lower() != v["verb"].lower()
                  and w["id"] not in v["conflicts_with"] and not (w.get("optional") and v.get("optional"))]
            if not ok:
                v["status"] = "FAIL"; bad += 1
                report["variants"].setdefault(v["id"], []).append("one-line variant has no pairable partner")

    # v3.4.2: Experience variants keep the original's facts (numbers, tools, opening verb) and its line count
    ev_rows = [(b, x) for b in (master.get("experience_variants") or {}).get("bullets", []) for x in b.get("variants", [])]
    ev_bad = 0
    report["experience_variants"] = {}
    if ev_rows:
        texts = []
        for b, x in ev_rows:
            texts += [b["original"], x["text"]]
        egeo = measure(build_tex(ttext, [esc(t) for t in texts], pipe.latex_escape, raw=True), a.out_dir / "experience", right_margin)
        for i, (b, x) in enumerate(ev_rows):
            reasons = list(pipe.experience_variant_problems(b["original"], x["text"], master))
            go, gv = egeo[2 * i], egeo[2 * i + 1]
            if go["lines"] != gv["lines"]:
                reasons.append(f"lines={gv['lines']} (original has {go['lines']})")
            report["experience_variants"][x["id"]] = {"lines": gv["lines"], "original_lines": go["lines"], "problems": reasons}
            if reasons:
                ev_bad += 1
        bad += ev_bad
    if bold:   # v3.4.9b: the template's Experience bullets keep their line counts with bold results
        items = [l.split("\\item ", 1)[1] for l in ttext.split("PERSONAL PROJECTS")[0].split("\n") if l.strip().startswith("\\item ")]
        gb = measure(build_tex(ttext, [pipe.v349b_bold_text(t) for t in items], pipe.latex_escape, raw=True), a.out_dir / "exp_bold", right_margin)
        gq = measure(build_tex(ttext, items, pipe.latex_escape, raw=True), a.out_dir / "exp_plain", right_margin)
        report["experience_bold"] = {"bullets": len(items), "line_changes": [i for i, (x, y) in enumerate(zip(gb, gq)) if x["lines"] != y["lines"]]}
        if report["experience_bold"]["line_changes"] or len(gb) != len(items):
            bad += 1

    report["summary"] = {"variants": len(variants), "failing": bad, "experience_variants": len(ev_rows), "experience_failing": ev_bad,
                         "one_line": sum(1 for _, v in variants if int(v.get("lines", 2)) == 1),
                         "tail_range": [min(g["tail_fill"] for g in geo if g["tail_fill"] and g["lines"] == 2),
                                        max(g["tail_fill"] for g in geo if g["tail_fill"] and g["lines"] == 2)],
                         "one_line_fill_range": [min([g["tail_fill"] for g in geo if g["lines"] == 1] or [0]),
                                                 max([g["tail_fill"] for g in geo if g["lines"] == 1] or [0])]}
    (a.out_dir / "bank_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    if a.write_back:
        a.bank.write_text(json.dumps(bank, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(report["summary"]))
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
