# Resume Pipeline v3.4.3 — notes (2026-10-15)

## What to do
1. Sources: delete the 7 old files and upload the 7 in `1_upload_to_ChatGPT_Sources/` (pipeline, master, bank and context .md changed).
2. Project instructions: paste `2_PROJECT_INSTRUCTIONS_paste.txt` (7,077 characters, under the 7,500 limit). It carries the new hash lock.
3. Tracker: the "Blockers" column from v3.4.2 is still needed if you have not added it. Rows now update only on an exact Company + Role match.
4. Optional: send `5_judged_packages/Judge_Batch_v3_4_3.md` (8 packages, Audible included) to the judge with `3_validation/JUDGE_PROMPT.md` and `RUBRIC.md`. The rubric now scores Experience.

## Results
- Regression: all 117 fixtures behave as expected. 115 build and pass; Fonzi stops (no requirements) and the Cisco paste stops with "stop: paste the job title line".
- Scores (score_all.py, Experience now scored):
  - Original 53: resume 10.00, letter 10.00 (no regression).
  - v3.4.1 tuning 36 and v3.4.2 judge-batch 6: 10.00 / 10.00.
  - New v3.4.3 fixtures (Audible, Cisco): 10.00 / 10.00.
  - Holdouts (20, never tuned): resume 9.85 mean, 9.00 min; letter 9.97 mean, 9.50 min (v3.4.2: 9.84 / 9.97). acme_cloud, twitch and linkedin_ai stay below 9.5 for the same reasons as before.
- selftest_v341, selftest_v342 and selftest_v343 all pass. selftest_v342 shows six SKIP lines for draft-variant checks that your approval of A–H replaced.
- bank_check: 112/112 bank variants and 8/8 Experience variants ok.

## Per package: Judge_Output_v3_4_2_GPT6.md deductions

### 1. Allergan Aesthetics, Integration Engineer
- Fixed: "Pydantic" in Skills. The line is now Django REST Framework, Django, Spring Boot, ReactJS; RIPPLE's heading still shows Pydantic.
- Also changed: the posting says "early-career Integration Engineer", so the new-grad layout applies (Education first, Go Digital left off, a third LaunchOps bullet). Cursor and GitHub Copilot left Tools because the posting does not name them. The closing now reads "I want to build, test, and deploy integrations and APIs at Allergan Aesthetics, building on LedgerFlow, my event-driven Java payment ledger."

### 2. DoorDash, Software Engineer, ML Infrastructure (MDX)
- Fixed: "Distributed Systems" only in Skills. LedgerFlow is now on the page (fix 6) with four bullets: two Spring Boot services over Kafka, 200 simultaneous payments, 27 crash runs, 250 payments through a restart.
- Fixed: "Pydantic" and "GitHub Copilot". Frameworks is now pytest, Spring Boot, Pandas, NumPy. Tools keeps Claude Code and Cursor because the posting names both ("Claude Code, Codex, Cursor").
- Fixed: the Fraud letter sentence. Fraud left the page and the letter; the letter's second project is now LedgerFlow.
- Fixed: the closing. It no longer implies production ML-platform experience: "I want to build agentic developer support for the ML lifecycle at DoorDash, building on RIPPLE, whose AI-generated code I checked against its full test suite."
- Partly fixed: the LLM engine. It stays as project #3 because it is Jay's evidence for evaluation and claim checks, which the posting asks for. Its "three AI workers / 73%" bullet was replaced by the claim-check bullet. Fix 6 replaces a project with no distributed evidence (Fraud here), not the LLM engine.
- Hook rewritten to name the domain: "...evaluate modeling experiments for DoorDash's ML platform."

### 3. Macy's, 2027 Tech Early Careers - Software Engineer
- Fixed: "all 80 of 80 tests" now reads "all 80 tests".
- Fixed: the generic hook. It now reads "I want to contribute to clearly defined projects for Macy's connected commerce technology, which serves millions of customers."
- Fixed: the closing. Growth lines ("work alongside mentors") no longer qualify and Jay is the actor: "I want to build dependable, well-tested software with the team at Macy's, building on LedgerFlow, which never overdrew an account under simultaneous payments." (No build/improve responsibility in the posting, so the role-family closing applies.)
- Remains: "Agile" only in Skills. No master evidence describes agile or iterative delivery inside a project bullet, and an approved variant cannot add it.
- Also changed: new-grad layout (2027 class); LedgerFlow's heading adds JavaScript (master lists HTML/CSS/JavaScript for LedgerFlow); LaunchOps gains its Go live-quiz bullet.

### 4. Figure, Embedded Software Engineering Intern, Platform
- Fixed: "all 80 of 80" in the resume and the letter ("All 80 tests pass.").
- Fixed: the closing now uses Pintos: "I want to design, implement, and test features for the robot software platform at Figure, building on the system calls I wrote in C for Pintos."
- Also fixed: Pydantic left Skills (Frameworks: Testcontainers, Spring Boot). New-grad layout applies (the posting names a graduating window).
- Remains: "Linux" only in Tools. Master has no Linux-specific bullet, and Pintos must not be presented as embedded Linux.
- Remains: RIPPLE as project #3 and the LedgerFlow letter sentence. Master has no embedded, firmware, OTA or networking project beyond Pintos and the Thesis IoT pipeline, so these carry the testing and reliability requirements honestly.

### 5. United States Cold Storage, Java Developer I
- Fixed: "Maven" only in Tools. LedgerFlow's heading now shows Maven (fix 4).
- Partly fixed: "JavaScript" only in Skills. LaunchOps and GoingOnce headings now show JavaScript; no bullet names it.
- Fixed: the mixed Frameworks line. It is now ReactJS, Django, Django REST Framework, Spring Boot.
- Fixed: the generic closing: "I want to work on design, coding, and testing at United States Cold Storage, building on LedgerFlow, where a GitHub Actions CI workflow runs every automated test."
- Partly fixed: the GoingOnce bullets. The agent-architecture bullet is now one line (team scope kept); the interface-tests bullet and the Fleet agent bullet follow.
- Remains: "Scrum" only in Skills (no project-bullet evidence).
- Not a defect: the 94-test CI sentence. The letter does not claim TDD or continuous delivery.
- Hook now names Java and the warehouse management systems.

### 6. Twitch, Software Engineer I
- Fixed: the broad Frameworks line (LangGraph, Streamlit, Pandas, NumPy removed).
- Fixed: the closing. It now uses the scalability responsibility: "I want to architect and build robust, scalable applications that can handle millions of concurrent users at Twitch, building on LedgerFlow, which never overdrew an account under simultaneous payments." The hook already carries the interactive-experiences line.
- Partly fixed: GoingOnce now shows the one-line team bullet, the interface tests and the Fleet agent.
- Remains: "Algorithms" and "Data Structures" only in Skills. Both are in master, but no bullet demonstrates them by name.
- Remains: the 200-simultaneous-payments sentence. It is Jay's real concurrency evidence; nothing in master proves millions of users, and the letter does not claim it.

### 7. ElevenLabs, Full-Stack Engineer (Backend Leaning) - Platform Engineering
- Fixed: Pydantic, Pandas and NumPy left the Frameworks line.
- Fixed: the closing now cites the permission checks: "I want to build and improve the building blocks customers touch directly at ElevenLabs, building on LaunchOps, where server-side checks block edits to other users' tasks."
- Remains: "test design" and "security fundamentals" are shown through examples (CI, server-side rules), not the exact phrases. Adding those phrases would claim more than master states.

### 8. Audible (new)
- Fit High; standard layout (not new grad); projects LedgerFlow, RIPPLE, LaunchOps; Fraud stays off (the governance "data classification" line no longer counts as ML).
- Widget lines from the job board were removed before parsing; "We spark listeners' imaginations" is not read as Spark.
- Skills show "AWS (EC2/RDS)" for the posting's AWS and Claude Code because the posting asks for AI tools for development productivity; no Classification skill.
- Hook: "I want to develop, test, and maintain software components and applications for the world's largest audiobook creator and provider."
- Closing: "I want to write maintainable and scalable code for software components at Audible, Inc., building on LedgerFlow, which never overdrew an account under simultaneous payments." No "Inc.." anywhere.

## Assumptions
- Bank bullets say "Created a Git-diff check" because "Added" is an Experience verb; the meaning is unchanged.
- F1–F3 were reworded only so they fit the one-line and tail checks (for example fraud.leak.a ends "...reporting final results only on a held-out 15% test set."). No number or fact changed.
- The short GoingOnce bullet now says "with a four-person team" (it said "with a team"), to keep the confirmed team scope on the project-level bullet.
- Variant G ("restored the services it caught failing") and variant A (LLM document-extraction emphasis) are used as you approved them; the opening-verb rule keeps them from repeating another bullet's first verb.
- The 3/3/3 layout is used only when Go Digital is omitted and the page keeps its buffer; otherwise 3/3/2, 3/2/3, then 3/2/2.
- "Early career" in the body (Allergan) counts as new grad, as your rule lists it.
- The 14 older fixtures saved without a title line run with a test-only flag; a live paste without a title always stops.
- Jay's experience is taken as about 2 years for the degree-plus-years note.
- Proof map: interactive → LaunchOps live quiz, GoingOnce interface tests or the Thesis IoT pipeline; scale / concurrency → LedgerFlow's concurrency and crash tests; integrations → LedgerFlow exactly-once; embedded → Pintos or the Thesis IoT pipeline; testing → CI and test suites; permissions → LaunchOps server checks.
- When a Frameworks line has nothing on-role to swap in, it gets shorter rather than keep an off-role entry (for example "Frameworks & Libraries: Spring Boot").
- Judge items listed as "possible fabrications" in earlier rounds are all in master and were left alone.
