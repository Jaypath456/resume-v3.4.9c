# DIFF_REPORT_v347b

Baseline: `baseline_v347a` (unmodified v3.4.7a code). New: a snapshot of the final run (v3.4.7b code, all v347_flags on).

Result: **PASS**. 582 changed lines in 39 fixtures; 0 unpredicted on v340_original / holdout; 0 unpredicted and unjustified elsewhere; 0 guard failures.

Normalized before comparing (the only fields that differ between two runs of the same code): report.json: timestamps.* (start, end, duration_ms of every stage); report.json: pdflatex_calls[*].duration_ms.

JSON files are compared as flattened `path: value` lines. `before` (none) means an added line; `after` (none) means a removed line.

## Guards

- G0 project selection / order: held (no project heading name changed).
- B1 negative-polarity blockers: 8 before, 8 after (held).
- B1 / B2 Fit: 2 fixtures changed Fit; none dropped; none rose more than one level except by a removed non-negative sponsorship blocker.
- B4 blast radius: bullets changed on 5 of 120 existing fixtures (cap 12, 10%).


### Fit changes

| Fixture | Before | After | Cause |
|---|---|---|---|
| alml_engineer | Medium | High | B2 / other |
| zoro_fullstack | Low | High | B1 blocker removed |

### B4 bullet changes

| Fixture | Group | Removed bullet | Added bullet | Scores (before -> after, margin) |
|---|---|---|---|---|
| booz_allen | v341_tune | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and photos with a saved fallback for every call, so results repeat.` | goingonce.fleet.a 3 -> goingonce.determ.a 11 (margin 8) |
| monti | v341_tune | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and photos with a saved fallback for every call, so results repeat.` | goingonce.fleet.a 3 -> goingonce.determ.a 11 (margin 8) |
| quora | v345_new | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and photos with a saved fallback for every call, so results repeat.` | goingonce.fleet.a 3 -> goingonce.determ.a 10 (margin 7) |
| raydar_swe | v341_tune | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and photos with a saved fallback for every call, so results repeat.` | goingonce.fleet.a 3 -> goingonce.determ.a 10 (margin 7) |
| roblox | v341_tune | `Compared MLP, GraphSAGE, and GAT models trained with class weights and F1-tuned thresholds; GraphSAGE raised fraud F1 to 0.564 from 0.394 for the MLP, and GAT scored lowest.` | `Prevented data leakage by fitting the feature scaler on the training split only and tuning decision thresholds on validation data, then reporting final results only on a held-out 15\% test set.` | fraud.compare.a 1 -> fraud.leak.a 9 (margin 8) |

## Changes by fix

| Fix | Fixtures | Lines |
|---|---|---|
| B1 | anthropic_it, audit03, audit04, audit05, audit06, audit07, cardinal, fidelity, flowgen, inspire11, meridian_bank, paypal, pinterest, roblox, zoro_fullstack | 74 |
| B2 | allergan, alml_engineer, apple, applied_mat, assetwatch, atoms, audit09, booz_allen, bti, linkedin, lumen, monti, roblox, twitch, ust_software_engineer, wgu, zoro_fullstack | 213 |
| B3 | assetwatch, microsoft, swisslog, us_cold, ust_software_engineer | 148 |
| B4 | alml_engineer, booz_allen, monti, quora, raydar_swe, roblox, rockstar, vindexa | 166 |
| justified: version label v3.4.7a -> v3.4.7b (not a fix): report.json carries pipeline_version only on the two expected stops | cisco_no_title, fonzi | 2 |

## Predicted but not changed

- alml_engineer / resume_tex / B4
- appian_sec / report / B2
- audit05 / resume_tex / B4
- audit10 / report / B2
- audit12 / report / B4
- audit12 / resume_tex / B4
- commure / report / B2
- doordash_mdx / report / B2
- engen / report / B2
- rockstar / resume_tex / B4
- vindexa / resume_tex / B4
- wpp / report / B2

## Every changed line

| Fixture | Group | File | Fix | Before | After |
|---|---|---|---|---|---|
| allergan | v340_original | report | B2 | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): TypeScript."` | `notes[0]: "OR-group alternatives Jay does not have (the posting accepts any one, and another option is covered, so they are not gaps): TypeScript."` |
| allergan | v340_original | report | B2 | `jd_gap_terms_detected[0]: "TypeScript"` | `jd_gap_terms_detected[0]: "Lambda"` |
| allergan | v340_original | report | B2 | `jd_gap_terms_detected[1]: "Lambda"` | `jd_gap_terms_detected[1]: "S3"` |
| allergan | v340_original | report | B2 | `jd_gap_terms_detected[2]: "S3"` | `jd_gap_terms_detected[2]: "Terraform"` |
| allergan | v340_original | report | B2 | `jd_gap_terms_detected[3]: "Terraform"` | (none) |
| allergan | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].term: "TypeScript"` |
| allergan | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].line: "Proficiency in at least one language such as Python, TypeScript/JavaScript, or Java."` |
| allergan | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].covered_by: "Python (supported term Python)"` |
| allergan | v340_original | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| allergan | v340_original | report | B2 | (none) | `or_groups_v347b.ambiguous: []` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[5].term: "recommender systems"` | `ats_coverage[5].term: "Model Evaluation"` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[5].verbatim: "recommendation systems"` | `ats_coverage[5].verbatim: "evals"` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[5].supported: false` | `ats_coverage[5].supported: true` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[5].status: "gap (unsupported)"` | `ats_coverage[5].status: "alias only"` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[5].surface: null` | `ats_coverage[5].surface: "skills"` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[6].term: "Model Evaluation"` | `ats_coverage[5].also_in[0]: "tagline"` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[6].verbatim: "evals"` | `ats_coverage[6].term: "Production Deployment"` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[6].priority: "must"` | `ats_coverage[6].verbatim: "deployment"` |
| alml_engineer | v347_new | report | B2, B4 | (none) | `ats_coverage[6].priority: "high"` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[6].status: "alias only"` | `ats_coverage[6].status: "covered"` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[6].also_in[0]: "tagline"` | `ats_coverage[6].also_in[0]: "experience"` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[7].term: "Production Deployment"` | `ats_coverage[7].term: "recommender systems"` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[7].verbatim: "deployment"` | `ats_coverage[7].verbatim: "recommendation systems"` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[7].priority: "high"` | `ats_coverage[7].priority: "medium"` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[7].supported: true` | `ats_coverage[7].supported: false` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[7].status: "covered"` | `ats_coverage[7].status: "gap (unsupported)"` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[7].surface: "skills"` | `ats_coverage[7].surface: null` |
| alml_engineer | v347_new | report | B2, B4 | `ats_coverage[7].also_in[0]: "experience"` | (none) |
| alml_engineer | v347_new | report | B2 | `hard_gaps[0].term: "recommender systems"` | `hard_gaps: []` |
| alml_engineer | v347_new | report | B2 | `hard_gaps[0].verbatim: "recommendation systems"` | `effective_fit: "High"` |
| alml_engineer | v347_new | report | B2 | `hard_gaps[0].priority: "must"` | `notes[0]: "OR-group: recommender systems is one option of \"Deep expertise in at least one of: the following:\" (covered by LLM agent products), so it is not a hard gap."` |
| alml_engineer | v347_new | report | B2 | `hard_gaps[0].status: "unsupported"` | (none) |
| alml_engineer | v347_new | report | B2 | `hard_gaps[0].reason: "Requirement is marked unsupported by the canonical evidence."` | (none) |
| alml_engineer | v347_new | report | B2 | `effective_fit: "Medium"` | (none) |
| alml_engineer | v347_new | report | B2 | `notes: []` | (none) |
| alml_engineer | v347_new | report | B2 | `tracker_row.Fit (High/Medium/Low): "Medium"` | `tracker_row.Fit (High/Medium/Low): "High"` |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[5].term: "recommender systems"` | `plan_resolved_fields.jd_requirements[5].term: "Model Evaluation"` |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[5].supported: false` | `plan_resolved_fields.jd_requirements[5].supported: true` |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[5].verbatim: "recommendation systems"` | `plan_resolved_fields.jd_requirements[5].verbatim: "evals"` |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[5].aliases[0]: "recommender systems"` | `plan_resolved_fields.jd_requirements[5].aliases[0]: "Model Evaluation"` |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[6].term: "Model Evaluation"` | `plan_resolved_fields.jd_requirements[5].aliases[1]: "evaluation"` |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[6].priority: "must"` | `plan_resolved_fields.jd_requirements[5].aliases[2]: "AI evaluation"` |
| alml_engineer | v347_new | report | B2 | (none) | `plan_resolved_fields.jd_requirements[6].term: "Production Deployment"` |
| alml_engineer | v347_new | report | B2 | (none) | `plan_resolved_fields.jd_requirements[6].priority: "high"` |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[6].verbatim: "evals"` | `plan_resolved_fields.jd_requirements[6].verbatim: "deployment"` |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[6].aliases[0]: "Model Evaluation"` | `plan_resolved_fields.jd_requirements[6].aliases[0]: "Production Deployment"` |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[6].aliases[1]: "evaluation"` | `plan_resolved_fields.jd_requirements[7].term: "recommender systems"` |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[6].aliases[2]: "AI evaluation"` | `plan_resolved_fields.jd_requirements[7].priority: "medium"` |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[7].term: "Production Deployment"` | `plan_resolved_fields.jd_requirements[7].supported: false` |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[7].priority: "high"` | `plan_resolved_fields.jd_requirements[7].verbatim: "recommendation systems"` |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[7].supported: true` | `plan_resolved_fields.jd_requirements[7].aliases[0]: "recommender systems"` |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[7].verbatim: "deployment"` | (none) |
| alml_engineer | v347_new | report | B2 | `plan_resolved_fields.jd_requirements[7].aliases[0]: "Production Deployment"` | (none) |
| alml_engineer | v347_new | report | B4 | `verify_changes_v344[1].change: "GoingOnce: the Fleet agent bullet is preferred (warehouse / logistics posting)"` | `verify_changes_v344[1].change: "Closing responsibility \"optimize models for latency, accuracy, and scalability in real-world applications\" with proof ripple.git_verification (ai)"` |
| alml_engineer | v347_new | report | B4 | `verify_changes_v344[1].jd_line: "- 2+ years of experience in Machine Learning and/or Data Science, with a track record of shipping ML systems into production."` | `verify_changes_v344[1].jd_line: "optimize models for latency, accuracy, and scalability in real-world applications"` |
| alml_engineer | v347_new | report | B4 | `verify_changes_v344[2].change: "Closing responsibility \"optimize models for latency, accuracy, and scalability in real-world applications\" with proof ripple.git_verification (ai)"` | `verify_changes_v344[2].change: "Experience variant A (exp.hein.1.A, suits AI / LLM / document roles)"` |
| alml_engineer | v347_new | report | B4 | `verify_changes_v344[2].jd_line: "optimize models for latency, accuracy, and scalability in real-world applications"` | `verify_changes_v344[2].jd_line: "Design, train, and deploy machine learning models for production use at scale."` |
| alml_engineer | v347_new | report | B4 | `verify_changes_v344[3].change: "Experience variant A (exp.hein.1.A, suits AI / LLM / document roles)"` | `verify_changes_v344[3].change: "Experience variant C (exp.hein.3.C, suits AI roles)"` |
| alml_engineer | v347_new | report | B4 | `verify_changes_v344[4].change: "Experience variant C (exp.hein.3.C, suits AI roles)"` | `verify_changes_v344[4].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| alml_engineer | v347_new | report | B4 | `verify_changes_v344[4].jd_line: "Design, train, and deploy machine learning models for production use at scale."` | `verify_changes_v344[4].jd_line: "Collaborate with engineers and product teams to scope problems, define success metrics, and build robust evaluation frameworks."` |
| alml_engineer | v347_new | report | B4 | `verify_changes_v344[5].change: "Experience variant D (exp.thesis.1.D, for every role)"` | (none) |
| alml_engineer | v347_new | report | B4 | `verify_changes_v344[5].jd_line: "Collaborate with engineers and product teams to scope problems, define success metrics, and build robust evaluation frameworks."` | (none) |
| alml_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared: []` |
| alml_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared[0].term: "recommender systems"` |
| alml_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared[0].member: "Search / retrieval / ranking or recommendation systems"` |
| alml_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared[0].line: "Deep expertise in at least one of: the following:"` |
| alml_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared[0].covered_by: "LLM agent products (agent evidence (RIPPLE AI agent; GoingOnce multi-agent prototype))"` |
| alml_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.ambiguous: []` |
| alml_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.fit.before: "High"` |
| alml_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.fit.after: "High"` |
| alml_engineer | v347_new | tracker | B2 | `Fit (High/Medium/Low): "Medium"` | `Fit (High/Medium/Low): "High"` |
| anthropic_it | v340_original | report | B1 | (none) | `notes[1]: "Sponsorship information (not a blocker): \"Visa sponsorship: We do sponsor visas!\" (employer says it sponsors)."` |
| apple | v340_original | report | B2 | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): Spark, Hadoop, Scala."` | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): Spark, Hadoop."` |
| apple | v340_original | report | B2 | (none) | `notes[1]: "OR-group alternatives Jay does not have (the posting accepts any one, and another option is covered, so they are not gaps): Scala."` |
| apple | v340_original | report | B2 | `jd_gap_terms_detected[2]: "Scala"` | (none) |
| apple | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].term: "Scala"` |
| apple | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].line: "Ability to implement data science pipelines and applications in a general programming language such as Python, Scala, or Java."` |
| apple | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].covered_by: "Python (supported term Python)"` |
| apple | v340_original | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| apple | v340_original | report | B2 | (none) | `or_groups_v347b.ambiguous: []` |
| applied_mat | v341_tune | report | B2 | `notes: []` | `notes[0]: "OR-group list unclear (kept the v3.4.7a reading): \"In addition, Applied endeavors to make our careers site accessible to all users. If you would like t\"."` |
| applied_mat | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared: []` |
| applied_mat | v341_tune | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| applied_mat | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].line: "In addition, Applied endeavors to make our careers site accessible to all users. If you would like to contact us regarding accessibility of our website or need assistance completing the application pr"` |
| applied_mat | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].members[0]: "to contact us regarding accessibility of our website"` |
| applied_mat | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].members[1]: "need assistance completing the application process"` |
| applied_mat | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].members[2]: "please contact us via e-mail at Accommodations_Program@amat"` |
| applied_mat | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].why: "an item longer than 4 words"` |
| assetwatch | v340_original | report | B3 | `warnings[0].type: "jd_supported_skill_term_omitted"` | `warnings[0].type: "ats_required_verbatim_alias_only"` |
| assetwatch | v340_original | report | B3 | `warnings[0].target: "SQL"` | `warnings[0].target: "Claude Code"` |
| assetwatch | v340_original | report | B3 | `warnings[0].measured: "Present in raw JD but absent from jd_requirements"` | `warnings[0].measured.verbatim: "AI-assisted development"` |
| assetwatch | v340_original | report | B3 | `warnings[0].expected: "Include important supported JD terms within the capped jd_requirements set"` | `warnings[0].measured.surface: "skills"` |
| assetwatch | v340_original | report | B3 | `warnings[0].suggested_repair: "Planning warning only; do not auto-add or invent requirements."` | `warnings[0].expected: "Exact JD form is not safe to claim; supported canonical/alias coverage is present"` |
| assetwatch | v340_original | report | B3 | (none) | `warnings[0].suggested_repair: "Warning only: keep truthful canonical wording."` |
| assetwatch | v340_original | report | B3 | `warnings[1].target: "Claude Code"` | `warnings[1].target: "Production Deployment"` |
| assetwatch | v340_original | report | B3 | `warnings[1].measured.verbatim: "AI-assisted development"` | `warnings[1].measured.verbatim: "production systems"` |
| assetwatch | v340_original | report | B3 | `warnings[2].target: "Production Deployment"` | `warnings[2].target: "Unit Testing"` |
| assetwatch | v340_original | report | B3 | `warnings[2].measured.verbatim: "production systems"` | `warnings[2].measured.verbatim: "automated testing"` |
| assetwatch | v340_original | report | B3 | `warnings[3].type: "ats_required_verbatim_alias_only"` | `warnings[3].type: "note_seniority_gap"` |
| assetwatch | v340_original | report | B3 | `warnings[3].target: "Unit Testing"` | `warnings[3].target: "gating"` |
| assetwatch | v340_original | report | B3 | `warnings[3].measured.verbatim: "automated testing"` | `warnings[3].measured: "requires 3+ years of professional experience; likely screened out"` |
| assetwatch | v340_original | report | B3 | `warnings[3].measured.surface: "skills"` | `warnings[3].expected: ""` |
| assetwatch | v340_original | report | B3 | `warnings[3].expected: "Exact JD form is not safe to claim; supported canonical/alias coverage is present"` | `warnings[3].suggested_repair: "Check the posting before applying."` |
| assetwatch | v340_original | report | B3 | `warnings[3].suggested_repair: "Warning only: keep truthful canonical wording."` | `warnings[4].type: "note_experience_years"` |
| assetwatch | v340_original | report | B3 | `warnings[4].type: "note_seniority_gap"` | (none) |
| assetwatch | v340_original | report | B3 | `warnings[4].measured: "requires 3+ years of professional experience; likely screened out"` | `warnings[4].measured: "Posting asks for 3+ years; Jay has about 2 years of professional experience."` |
| assetwatch | v340_original | report | B3 | `warnings[5].type: "note_experience_years"` | (none) |
| assetwatch | v340_original | report | B3 | `warnings[5].target: "gating"` | (none) |
| assetwatch | v340_original | report | B3 | `warnings[5].measured: "Posting asks for 3+ years; Jay has about 2 years of professional experience."` | (none) |
| assetwatch | v340_original | report | B3 | `warnings[5].expected: ""` | (none) |
| assetwatch | v340_original | report | B3 | `warnings[5].suggested_repair: "Check the posting before applying."` | (none) |
| assetwatch | v340_original | report | B3 | (none) | `ats_coverage[26].term: "SQL"` |
| assetwatch | v340_original | report | B3 | (none) | `ats_coverage[26].verbatim: "SQL"` |
| assetwatch | v340_original | report | B3 | (none) | `ats_coverage[26].priority: "medium"` |
| assetwatch | v340_original | report | B3 | (none) | `ats_coverage[26].supported: true` |
| assetwatch | v340_original | report | B3 | (none) | `ats_coverage[26].status: "covered"` |
| assetwatch | v340_original | report | B3 | (none) | `ats_coverage[26].surface: "skills"` |
| assetwatch | v340_original | report | B2 | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): Jira, SQL Server, Terraform."` | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): Jira, Terraform."` |
| assetwatch | v340_original | report | B2 | (none) | `notes[1]: "OR-group alternatives Jay does not have (the posting accepts any one, and another option is covered, so they are not gaps): SQL Server."` |
| assetwatch | v340_original | report | B3 | `ats_summary.supported_requirements_visible: "18/18"` | `ats_summary.supported_requirements_visible: "19/19"` |
| assetwatch | v340_original | report | B3 | `ats_summary.exact_jd_wording_visible: "15/18"` | `ats_summary.exact_jd_wording_visible: "16/19"` |
| assetwatch | v340_original | report | B3 | `ats_summary.requirements_parsed: 26` | `ats_summary.requirements_parsed: 27` |
| assetwatch | v340_original | report | B2 | `jd_gap_terms_detected[2]: "SQL Server"` | `jd_gap_terms_detected[2]: "Lambda"` |
| assetwatch | v340_original | report | B2 | `jd_gap_terms_detected[3]: "Lambda"` | `jd_gap_terms_detected[3]: "Terraform"` |
| assetwatch | v340_original | report | B2 | `jd_gap_terms_detected[4]: "Terraform"` | (none) |
| assetwatch | v340_original | report | B3 | (none) | `plan_resolved_fields.jd_requirements[26].term: "SQL"` |
| assetwatch | v340_original | report | B3 | (none) | `plan_resolved_fields.jd_requirements[26].priority: "medium"` |
| assetwatch | v340_original | report | B3 | (none) | `plan_resolved_fields.jd_requirements[26].supported: true` |
| assetwatch | v340_original | report | B3 | (none) | `plan_resolved_fields.jd_requirements[26].verbatim: "SQL"` |
| assetwatch | v340_original | report | B3 | (none) | `plan_resolved_fields.jd_requirements[26].aliases[0]: "SQL"` |
| assetwatch | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].term: "SQL Server"` |
| assetwatch | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].line: "3+ years of professional experience building production React web applications with TypeScript and relational databases such as MySQL or SQL Server."` |
| assetwatch | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].covered_by: "MySQL (supported term MySQL)"` |
| assetwatch | v340_original | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| assetwatch | v340_original | report | B2 | (none) | `or_groups_v347b.ambiguous: []` |
| assetwatch | v340_original | report | B3 | (none) | `sql_term_v347b.line: "- 3+ years of professional experience building production React web applications with TypeScript and relational databases such as MySQL or SQL Server."` |
| assetwatch | v340_original | report | B3 | (none) | `sql_term_v347b.status: "covered"` |
| assetwatch | v340_original | report | B3 | (none) | `sql_term_v347b.surface: "skills"` |
| atoms | v340_original | report | B2 | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): Azure."` | `notes[0]: "OR-group alternatives Jay does not have (the posting accepts any one, and another option is covered, so they are not gaps): Azure."` |
| atoms | v340_original | report | B2 | `jd_gap_terms_detected[0]: "Azure"` | `jd_gap_terms_detected: []` |
| atoms | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].term: "Azure"` |
| atoms | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].line: "Experience with cloud platforms like AWS, Google Cloud, or Azure."` |
| atoms | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].covered_by: "AWS (supported term AWS)"` |
| atoms | v340_original | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| atoms | v340_original | report | B2 | (none) | `or_groups_v347b.ambiguous: []` |
| audit03 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_before.requirement: "We do not offer visa sponsorship."` |
| audit03 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_before.polarity: "negative"` |
| audit03 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_after.requirement: "We do not offer visa sponsorship."` |
| audit03 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_after.polarity: "negative"` |
| audit03 | v340_original | report | B1 | (none) | `sponsorship_v347b.action: "kept (negative wording)"` |
| audit04 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_before.requirement: "Immigration note: We will not sponsor H-1B petitions now or in the future."` |
| audit04 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_before.polarity: "negative"` |
| audit04 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_after.requirement: "Immigration note: We will not sponsor H-1B petitions now or in the future."` |
| audit04 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_after.polarity: "negative"` |
| audit04 | v340_original | report | B1 | (none) | `sponsorship_v347b.action: "kept (negative wording)"` |
| audit05 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_before.requirement: "Applicants must possess unrestricted permanent US work authorization."` |
| audit05 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_before.polarity: "none"` |
| audit05 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_after.requirement: "Applicants must possess unrestricted permanent US work authorization."` |
| audit05 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_after.polarity: "none"` |
| audit05 | v340_original | report | B1 | (none) | `sponsorship_v347b.action: "kept (authorization wording: v3.4.7a behaviour)"` |
| audit06 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_before.requirement: "We cannot support employment-based visa applications."` |
| audit06 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_before.polarity: "negative"` |
| audit06 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_after.requirement: "We cannot support employment-based visa applications."` |
| audit06 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_after.polarity: "negative"` |
| audit06 | v340_original | report | B1 | (none) | `sponsorship_v347b.action: "kept (negative wording)"` |
| audit07 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_before.requirement: "SPONSORSHIP REQUESTS WILL NOT BE CONSIDERED."` |
| audit07 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_before.polarity: "negative"` |
| audit07 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_after.requirement: "SPONSORSHIP REQUESTS WILL NOT BE CONSIDERED."` |
| audit07 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_after.polarity: "negative"` |
| audit07 | v340_original | report | B1 | (none) | `sponsorship_v347b.action: "kept (negative wording)"` |
| audit09 | v340_original | report | B2 | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): GraphQL."` | `notes[0]: "OR-group alternatives Jay does not have (the posting accepts any one, and another option is covered, so they are not gaps): GraphQL."` |
| audit09 | v340_original | report | B2 | `jd_gap_terms_detected[0]: "GraphQL"` | `jd_gap_terms_detected: []` |
| audit09 | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].term: "GraphQL"` |
| audit09 | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].line: "Familiarity with any of REST APIs, GraphQL, or gRPC."` |
| audit09 | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].covered_by: "REST APIs (supported term REST APIs)"` |
| audit09 | v340_original | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| audit09 | v340_original | report | B2 | (none) | `or_groups_v347b.ambiguous: []` |
| booz_allen | v341_tune | resume_tex | B4 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and photos with a saved fallback for every call, so results repeat.` |
| booz_allen | v341_tune | resume_tex | B4 | `  \item \textbf{Tools:} Git, Gemini API, Claude Code, Novita API, AWS (EC2/RDS), Docker` | `  \item \textbf{Tools:} Git, Gemini API, Claude API, Claude Code, Novita API, AWS (EC2/RDS), Docker` |
| booz_allen | v341_tune | report | B4 | `warnings[0].type: "ats_required_verbatim_alias_only"` | `warnings[0].type: "project_bullet_tail_quality"` |
| booz_allen | v341_tune | report | B4 | `warnings[0].target: "Git"` | `warnings[0].target: "goingonce.bullet_2"` |
| booz_allen | v341_tune | report | B4 | `warnings[0].measured.verbatim: "version control"` | `warnings[0].measured.fill_ratio: 0.4993` |
| booz_allen | v341_tune | report | B4 | `warnings[0].measured.surface: "skills"` | `warnings[0].measured.used_width_pt: 263.19` |
| booz_allen | v341_tune | report | B4 | `warnings[0].expected: "Exact JD form is not safe to claim; supported canonical/alias coverage is present"` | `warnings[0].measured.available_width_pt: 527.17` |
| booz_allen | v341_tune | report | B4 | `warnings[0].suggested_repair: "Warning only: keep truthful canonical wording."` | `warnings[0].expected.quality_min_fill_ratio: 0.5` |
| booz_allen | v341_tune | report | B4 | `warnings[1].type: "note_clearance"` | `warnings[0].expected.structural_min_fill_ratio: 0.4` |
| booz_allen | v341_tune | report | B4 | `warnings[1].target: "gating"` | `warnings[0].suggested_repair: "Advisory only. In bank mode, improve/re-measure the bank offline; never pad the selected bullet."` |
| booz_allen | v341_tune | report | B4 | `warnings[1].measured: "Secret clearance"` | `warnings[1].type: "ats_required_verbatim_alias_only"` |
| booz_allen | v341_tune | report | B4 | `warnings[1].expected: ""` | `warnings[1].target: "Git"` |
| booz_allen | v341_tune | report | B4 | `warnings[1].suggested_repair: "Check the posting before applying."` | `warnings[1].measured.verbatim: "version control"` |
| booz_allen | v341_tune | report | B4 | (none) | `warnings[1].measured.surface: "skills"` |
| booz_allen | v341_tune | report | B4 | (none) | `warnings[1].expected: "Exact JD form is not safe to claim; supported canonical/alias coverage is present"` |
| booz_allen | v341_tune | report | B4 | (none) | `warnings[1].suggested_repair: "Warning only: keep truthful canonical wording."` |
| booz_allen | v341_tune | report | B4 | (none) | `warnings[2].type: "note_clearance"` |
| booz_allen | v341_tune | report | B4 | (none) | `warnings[2].target: "gating"` |
| booz_allen | v341_tune | report | B4 | (none) | `warnings[2].measured: "Secret clearance"` |
| booz_allen | v341_tune | report | B4 | (none) | `warnings[2].expected: ""` |
| booz_allen | v341_tune | report | B4 | (none) | `warnings[2].suggested_repair: "Check the posting before applying."` |
| booz_allen | v341_tune | report | B4 | `skill_fit_cache.skills_text_hash: "507a39ab3a780f669d2cbb51588d31b90145fd502b97ac72b4c30d7ef6c56223"` | `skill_fit_cache.skills_text_hash: "d4eb19ff60347333d10157b9973dd1a1f9b44e2cb4eca2a9d1a0596128671a46"` |
| booz_allen | v341_tune | report | B2 | (none) | `notes[2]: "OR-group list unclear (kept the v3.4.7a reading): \"Experience with AI/ML or LLM-enabled patterns such as RAG, embeddings, vector search, prompt or tool\"."` |
| booz_allen | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared: []` |
| booz_allen | v341_tune | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| booz_allen | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].line: "Experience with AI/ML or LLM-enabled patterns such as RAG, embeddings, vector search, prompt or tool orchestration, or frameworks such as OpenAI Agents SDK, Google ADK, LangChain, or comparable"` |
| booz_allen | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].members[0]: "RAG"` |
| booz_allen | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].members[1]: "embeddings"` |
| booz_allen | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].members[2]: "vector search"` |
| booz_allen | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].members[3]: "prompt"` |
| booz_allen | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].members[4]: "tool orchestration"` |
| booz_allen | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].members[5]: "frameworks such as OpenAI Agents SDK"` |
| booz_allen | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].members[6]: "Google ADK"` |
| booz_allen | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].members[7]: "LangChain"` |
| booz_allen | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].members[8]: "comparable"` |
| booz_allen | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous[0].why: "an item longer than 4 words"` |
| booz_allen | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.margin: 6` |
| booz_allen | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].project: "goingonce"` |
| booz_allen | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].before: "goingonce.fleet.a"` |
| booz_allen | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].after: "goingonce.determ.a"` |
| booz_allen | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].score_before: 3` |
| booz_allen | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].score_after: 11` |
| booz_allen | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].margin: 8` |
| booz_allen | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.logistics_line: ""` |
| booz_allen | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.ai_posting: true` |
| booz_allen | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.llm_limitation_line: false` |
| bti | v341_tune | report | B2 | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): Vue, Angular."` | `notes[0]: "OR-group alternatives Jay does not have (the posting accepts any one, and another option is covered, so they are not gaps): Vue, Angular."` |
| bti | v341_tune | report | B2 | `jd_gap_terms_detected[0]: "Vue"` | `jd_gap_terms_detected: []` |
| bti | v341_tune | report | B2 | `jd_gap_terms_detected[1]: "Angular"` | (none) |
| bti | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].term: "Vue"` |
| bti | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].line: "∙ Basic front-end development experience (HTML, CSS, JavaScript, and a modern framework such as React, Angular, or Vue is a plus)."` |
| bti | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].covered_by: "React (supported term ReactJS)"` |
| bti | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].term: "Angular"` |
| bti | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].line: "∙ Basic front-end development experience (HTML, CSS, JavaScript, and a modern framework such as React, Angular, or Vue is a plus)."` |
| bti | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].covered_by: "React (supported term ReactJS)"` |
| bti | v341_tune | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| bti | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous: []` |
| cardinal | holdout | report | B1 | (none) | `sponsorship_v347b.blocker_before.requirement: "Candidates must be authorized to work in the United States without sponsorship now or in the future."` |
| cardinal | holdout | report | B1 | (none) | `sponsorship_v347b.blocker_before.polarity: "negative"` |
| cardinal | holdout | report | B1 | (none) | `sponsorship_v347b.blocker_after.requirement: "Candidates must be authorized to work in the United States without sponsorship now or in the future."` |
| cardinal | holdout | report | B1 | (none) | `sponsorship_v347b.blocker_after.polarity: "negative"` |
| cardinal | holdout | report | B1 | (none) | `sponsorship_v347b.action: "kept (negative wording)"` |
| cisco_no_title | v343_new | report | justified: version label v3.4.7a -> v3.4.7b (not a fix): report.json carries pipeline_version only on the two expected stops | `pipeline_version: "v3.4.7a"` | `pipeline_version: "v3.4.7b"` |
| fidelity | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_before.requirement: "Fidelity will not provide immigration sponsorship for this position."` |
| fidelity | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_before.polarity: "negative"` |
| fidelity | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_after.requirement: "Fidelity will not provide immigration sponsorship for this position."` |
| fidelity | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_after.polarity: "negative"` |
| fidelity | v340_original | report | B1 | (none) | `sponsorship_v347b.action: "kept (negative wording)"` |
| flowgen | v341_tune | report | B1 | `notes: []` | `notes[0]: "Sponsorship information (not a blocker): \"Visa Support/Sponsorship available\" (employer says it sponsors)."` |
| fonzi | v341_tune | report | justified: version label v3.4.7a -> v3.4.7b (not a fix): report.json carries pipeline_version only on the two expected stops | `pipeline_version: "v3.4.7a"` | `pipeline_version: "v3.4.7b"` |
| inspire11 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_before.requirement: "Inspire11 is unable to sponsor employment visas at this time."` |
| inspire11 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_before.polarity: "negative"` |
| inspire11 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_after.requirement: "Inspire11 is unable to sponsor employment visas at this time."` |
| inspire11 | v340_original | report | B1 | (none) | `sponsorship_v347b.blocker_after.polarity: "negative"` |
| inspire11 | v340_original | report | B1 | (none) | `sponsorship_v347b.action: "kept (negative wording)"` |
| linkedin | v340_original | report | B2 | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): TypeScript, C#, Ruby, C++."` | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): C#, Ruby, C++."` |
| linkedin | v340_original | report | B2 | (none) | `notes[1]: "OR-group alternatives Jay does not have (the posting accepts any one, and another option is covered, so they are not gaps): TypeScript."` |
| linkedin | v340_original | report | B2 | `jd_gap_terms_detected[0]: "TypeScript"` | `jd_gap_terms_detected[0]: "C#"` |
| linkedin | v340_original | report | B2 | `jd_gap_terms_detected[1]: "C#"` | `jd_gap_terms_detected[1]: "Ruby"` |
| linkedin | v340_original | report | B2 | `jd_gap_terms_detected[2]: "Ruby"` | `jd_gap_terms_detected[2]: "C++"` |
| linkedin | v340_original | report | B2 | `jd_gap_terms_detected[3]: "C++"` | (none) |
| linkedin | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].term: "TypeScript"` |
| linkedin | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].line: "Proficiency in at least one mainstream language (e.g., Java, C++, Python, or JavaScript/TypeScript)."` |
| linkedin | v340_original | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].covered_by: "Java (supported term Java)"` |
| linkedin | v340_original | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| linkedin | v340_original | report | B2 | (none) | `or_groups_v347b.ambiguous: []` |
| lumen | holdout | report | B2 | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): RAG, vector database, vector databases, LangChain, OpenAI, GCP."` | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): RAG, vector database, vector databases, OpenAI, GCP."` |
| lumen | holdout | report | B2 | (none) | `notes[1]: "OR-group alternatives Jay does not have (the posting accepts any one, and another option is covered, so they are not gaps): LangChain."` |
| lumen | holdout | report | B2 | `jd_gap_terms_detected[3]: "LangChain"` | `jd_gap_terms_detected[3]: "OpenAI"` |
| lumen | holdout | report | B2 | `jd_gap_terms_detected[4]: "OpenAI"` | `jd_gap_terms_detected[4]: "GCP"` |
| lumen | holdout | report | B2 | `jd_gap_terms_detected[5]: "GCP"` | (none) |
| lumen | holdout | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].term: "LangChain"` |
| lumen | holdout | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].line: "Experience with agent frameworks such as LangGraph or LangChain."` |
| lumen | holdout | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].covered_by: "LangGraph (supported term LangGraph)"` |
| lumen | holdout | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| lumen | holdout | report | B2 | (none) | `or_groups_v347b.ambiguous: []` |
| meridian_bank | v341_tune | report | B1 | (none) | `sponsorship_v347b.blocker_before.requirement: "Meridian Bank will not sponsor applicants for work visas for this position."` |
| meridian_bank | v341_tune | report | B1 | (none) | `sponsorship_v347b.blocker_before.polarity: "negative"` |
| meridian_bank | v341_tune | report | B1 | (none) | `sponsorship_v347b.blocker_after.requirement: "Meridian Bank will not sponsor applicants for work visas for this position."` |
| meridian_bank | v341_tune | report | B1 | (none) | `sponsorship_v347b.blocker_after.polarity: "negative"` |
| meridian_bank | v341_tune | report | B1 | (none) | `sponsorship_v347b.action: "kept (negative wording)"` |
| microsoft | v340_original | resume_tex | B3 | `  \item \textbf{Languages \& Databases:} Python, Java, SQL, PostgreSQL, JavaScript, MySQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, PostgreSQL, JavaScript, MySQL` |
| microsoft | v340_original | report | B3 | `warnings[0].target: "SQL"` | `warnings[0].target: "PostgreSQL"` |
| microsoft | v340_original | report | B3 | `warnings[1].target: "PostgreSQL"` | `warnings[1].target: "Power BI"` |
| microsoft | v340_original | report | B3 | `warnings[2].type: "jd_supported_skill_term_omitted"` | `warnings[2].type: "experience_years"` |
| microsoft | v340_original | report | B3 | `warnings[2].target: "Power BI"` | `warnings[2].target: "gating"` |
| microsoft | v340_original | report | B3 | `warnings[2].measured: "Present in raw JD but absent from jd_requirements"` | `warnings[2].measured: "asks 2+ years of experience; Jay has about one year of professional experience"` |
| microsoft | v340_original | report | B3 | `warnings[2].expected: "Include important supported JD terms within the capped jd_requirements set"` | `warnings[2].expected: ""` |
| microsoft | v340_original | report | B3 | `warnings[2].suggested_repair: "Planning warning only; do not auto-add or invent requirements."` | `warnings[2].suggested_repair: "Check the posting before applying."` |
| microsoft | v340_original | report | B3 | `warnings[3].type: "experience_years"` | (none) |
| microsoft | v340_original | report | B3 | `warnings[3].target: "gating"` | (none) |
| microsoft | v340_original | report | B3 | `warnings[3].measured: "asks 2+ years of experience; Jay has about one year of professional experience"` | (none) |
| microsoft | v340_original | report | B3 | `warnings[3].expected: ""` | (none) |
| microsoft | v340_original | report | B3 | `warnings[3].suggested_repair: "Check the posting before applying."` | (none) |
| microsoft | v340_original | report | B3 | (none) | `ats_coverage[12].term: "SQL"` |
| microsoft | v340_original | report | B3 | (none) | `ats_coverage[12].verbatim: "SQL"` |
| microsoft | v340_original | report | B3 | (none) | `ats_coverage[12].priority: "medium"` |
| microsoft | v340_original | report | B3 | (none) | `ats_coverage[12].supported: true` |
| microsoft | v340_original | report | B3 | (none) | `ats_coverage[12].status: "covered"` |
| microsoft | v340_original | report | B3 | (none) | `ats_coverage[12].surface: "skills"` |
| microsoft | v340_original | report | B3 | `skill_fit_cache.skills_text_hash: "a2f6febf615e004f356425ce5f54b2b3e852707681f2229b82149bfbce3e70cd"` | `skill_fit_cache.skills_text_hash: "c7e0c7d2f81216841981031f6512dfb415af71784979950087d31c9b2fe3ef4b"` |
| microsoft | v340_original | report | B3 | `ats_summary.supported_requirements_visible: "10/10"` | `ats_summary.supported_requirements_visible: "11/11"` |
| microsoft | v340_original | report | B3 | `ats_summary.exact_jd_wording_visible: "10/10"` | `ats_summary.exact_jd_wording_visible: "11/11"` |
| microsoft | v340_original | report | B3 | `ats_summary.requirements_parsed: 12` | `ats_summary.requirements_parsed: 13` |
| microsoft | v340_original | report | B3 | (none) | `plan_resolved_fields.jd_requirements[12].term: "SQL"` |
| microsoft | v340_original | report | B3 | (none) | `plan_resolved_fields.jd_requirements[12].priority: "medium"` |
| microsoft | v340_original | report | B3 | (none) | `plan_resolved_fields.jd_requirements[12].supported: true` |
| microsoft | v340_original | report | B3 | (none) | `plan_resolved_fields.jd_requirements[12].verbatim: "SQL"` |
| microsoft | v340_original | report | B3 | (none) | `plan_resolved_fields.jd_requirements[12].aliases[0]: "SQL"` |
| microsoft | v340_original | report | B3 | (none) | `sql_term_v347b.line: "Microsoft's Azure Data engineering team is leading the transformation of analytics in the world of data with products like databases, data integration, big data analytics, messaging and real-time anal"` |
| microsoft | v340_original | report | B3 | (none) | `sql_term_v347b.status: "covered"` |
| microsoft | v340_original | report | B3 | (none) | `sql_term_v347b.surface: "skills"` |
| monti | v341_tune | resume_tex | B4 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and photos with a saved fallback for every call, so results repeat.` |
| monti | v341_tune | report | B4 | `warnings[0].type: "ats_required_verbatim_alias_only"` | `warnings[0].type: "project_bullet_tail_quality"` |
| monti | v341_tune | report | B4 | `warnings[0].target: "Claude Code"` | `warnings[0].target: "goingonce.bullet_2"` |
| monti | v341_tune | report | B4 | `warnings[0].measured.verbatim: "AI coding tools"` | `warnings[0].measured.fill_ratio: 0.4993` |
| monti | v341_tune | report | B4 | `warnings[0].measured.surface: "skills"` | `warnings[0].measured.used_width_pt: 263.19` |
| monti | v341_tune | report | B4 | `warnings[0].expected: "Exact JD form is not safe to claim; supported canonical/alias coverage is present"` | `warnings[0].measured.available_width_pt: 527.17` |
| monti | v341_tune | report | B4 | `warnings[0].suggested_repair: "Warning only: keep truthful canonical wording."` | `warnings[0].expected.quality_min_fill_ratio: 0.5` |
| monti | v341_tune | report | B4 | (none) | `warnings[0].expected.structural_min_fill_ratio: 0.4` |
| monti | v341_tune | report | B4 | (none) | `warnings[0].suggested_repair: "Advisory only. In bank mode, improve/re-measure the bank offline; never pad the selected bullet."` |
| monti | v341_tune | report | B4 | `warnings[1].target: "JWT"` | `warnings[1].target: "Claude Code"` |
| monti | v341_tune | report | B4 | `warnings[1].measured.verbatim: "authentication"` | `warnings[1].measured.verbatim: "AI coding tools"` |
| monti | v341_tune | report | B4 | `warnings[2].target: "Linux"` | `warnings[2].target: "JWT"` |
| monti | v341_tune | report | B4 | `warnings[2].measured.verbatim: "in a terminal"` | `warnings[2].measured.verbatim: "authentication"` |
| monti | v341_tune | report | B4 | (none) | `warnings[3].type: "ats_required_verbatim_alias_only"` |
| monti | v341_tune | report | B4 | (none) | `warnings[3].target: "Linux"` |
| monti | v341_tune | report | B4 | (none) | `warnings[3].measured.verbatim: "in a terminal"` |
| monti | v341_tune | report | B4 | (none) | `warnings[3].measured.surface: "skills"` |
| monti | v341_tune | report | B4 | (none) | `warnings[3].expected: "Exact JD form is not safe to claim; supported canonical/alias coverage is present"` |
| monti | v341_tune | report | B4 | (none) | `warnings[3].suggested_repair: "Warning only: keep truthful canonical wording."` |
| monti | v341_tune | report | B2 | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): RAG, TypeScript, C#, Terraform."` | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): RAG, Terraform."` |
| monti | v341_tune | report | B2 | (none) | `notes[1]: "OR-group alternatives Jay does not have (the posting accepts any one, and another option is covered, so they are not gaps): TypeScript, C#."` |
| monti | v341_tune | report | B2 | `jd_gap_terms_detected[1]: "TypeScript"` | `jd_gap_terms_detected[1]: "Terraform"` |
| monti | v341_tune | report | B2 | `jd_gap_terms_detected[2]: "C#"` | `jd_gap_terms_detected[2]: "Azure"` |
| monti | v341_tune | report | B2 | `jd_gap_terms_detected[3]: "Terraform"` | (none) |
| monti | v341_tune | report | B2 | `jd_gap_terms_detected[4]: "Azure"` | (none) |
| monti | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].term: "TypeScript"` |
| monti | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].line: "Basic software development experience in one or more languages such as TypeScript, JavaScript, Python, C#, or similar."` |
| monti | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].covered_by: "JavaScript (supported term JavaScript)"` |
| monti | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].term: "C#"` |
| monti | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].line: "Basic software development experience in one or more languages such as TypeScript, JavaScript, Python, C#, or similar."` |
| monti | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].covered_by: "JavaScript (supported term JavaScript)"` |
| monti | v341_tune | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| monti | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous: []` |
| monti | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.margin: 6` |
| monti | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].project: "goingonce"` |
| monti | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].before: "goingonce.fleet.a"` |
| monti | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].after: "goingonce.determ.a"` |
| monti | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].score_before: 3` |
| monti | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].score_after: 11` |
| monti | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].margin: 8` |
| monti | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.logistics_line: ""` |
| monti | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.ai_posting: true` |
| monti | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.llm_limitation_line: false` |
| paypal | v340_original | report | B1 | `notes: []` | `notes[0]: "Sponsorship information (not a blocker): \"Visa / sponsorship: Not stated in the posting.\" (neutral)."` |
| pinterest | holdout | report | B1 | `notes: []` | `notes[0]: "Sponsorship wording unclear: check manually (\"Visa Sponsorship: Case by case\")."` |
| quora | v345_new | resume_tex | B4 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and photos with a saved fallback for every call, so results repeat.` |
| quora | v345_new | resume_tex | B4 | `  \item \textbf{Tools:} Kubernetes (local k3d), Git, Claude Code, AWS (EC2/RDS), Docker` | `  \item \textbf{Tools:} Kubernetes (local k3d), Git, Claude API, Claude Code, AWS (EC2/RDS), Docker` |
| quora | v345_new | report | B4 | `warnings: []` | `warnings[0].type: "project_bullet_tail_quality"` |
| quora | v345_new | report | B4 | (none) | `warnings[0].target: "goingonce.bullet_2"` |
| quora | v345_new | report | B4 | (none) | `warnings[0].measured.fill_ratio: 0.4993` |
| quora | v345_new | report | B4 | (none) | `warnings[0].measured.used_width_pt: 263.19` |
| quora | v345_new | report | B4 | (none) | `warnings[0].measured.available_width_pt: 527.17` |
| quora | v345_new | report | B4 | (none) | `warnings[0].expected.quality_min_fill_ratio: 0.5` |
| quora | v345_new | report | B4 | (none) | `warnings[0].expected.structural_min_fill_ratio: 0.4` |
| quora | v345_new | report | B4 | (none) | `warnings[0].suggested_repair: "Advisory only. In bank mode, improve/re-measure the bank offline; never pad the selected bullet."` |
| quora | v345_new | report | B4 | `skill_fit_cache.skills_text_hash: "5cdf9007e482b3a32e4f00abde449a74a721df7ea63c2d6f650ca5023c7e0dd5"` | `skill_fit_cache.skills_text_hash: "0f47d86bee3e6449f4643df7340b9d4cdf63283ee0a914b526b8bf495d059dfa"` |
| quora | v345_new | report | B4 | (none) | `bullet_relevance_v347b.margin: 6` |
| quora | v345_new | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].project: "goingonce"` |
| quora | v345_new | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].before: "goingonce.fleet.a"` |
| quora | v345_new | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].after: "goingonce.determ.a"` |
| quora | v345_new | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].score_before: 3` |
| quora | v345_new | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].score_after: 10` |
| quora | v345_new | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].margin: 7` |
| quora | v345_new | report | B4 | (none) | `bullet_relevance_v347b.logistics_line: ""` |
| quora | v345_new | report | B4 | (none) | `bullet_relevance_v347b.ai_posting: true` |
| quora | v345_new | report | B4 | (none) | `bullet_relevance_v347b.llm_limitation_line: false` |
| raydar_swe | v341_tune | resume_tex | B4 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and photos with a saved fallback for every call, so results repeat.` |
| raydar_swe | v341_tune | resume_tex | B4 | `  \item \textbf{Tools:} Apache Kafka, GitHub Actions, Git, Claude Code, Redis, AWS (EC2/RDS), Docker` | `  \item \textbf{Tools:} Apache Kafka, GitHub Actions, Git, Claude API, Claude Code, Redis, AWS (EC2/RDS), Docker` |
| raydar_swe | v341_tune | report | B4 | `warnings[0].type: "ats_required_verbatim_alias_only"` | `warnings[0].type: "project_bullet_tail_quality"` |
| raydar_swe | v341_tune | report | B4 | `warnings[0].target: "Agentic Workflows"` | `warnings[0].target: "goingonce.bullet_2"` |
| raydar_swe | v341_tune | report | B4 | `warnings[0].measured.verbatim: "AI workflows"` | `warnings[0].measured.fill_ratio: 0.4993` |
| raydar_swe | v341_tune | report | B4 | `warnings[0].measured.surface: "skills"` | `warnings[0].measured.used_width_pt: 263.19` |
| raydar_swe | v341_tune | report | B4 | `warnings[0].expected: "Exact JD form is not safe to claim; supported canonical/alias coverage is present"` | `warnings[0].measured.available_width_pt: 527.17` |
| raydar_swe | v341_tune | report | B4 | `warnings[0].suggested_repair: "Warning only: keep truthful canonical wording."` | `warnings[0].expected.quality_min_fill_ratio: 0.5` |
| raydar_swe | v341_tune | report | B4 | (none) | `warnings[0].expected.structural_min_fill_ratio: 0.4` |
| raydar_swe | v341_tune | report | B4 | (none) | `warnings[0].suggested_repair: "Advisory only. In bank mode, improve/re-measure the bank offline; never pad the selected bullet."` |
| raydar_swe | v341_tune | report | B4 | (none) | `warnings[1].type: "ats_required_verbatim_alias_only"` |
| raydar_swe | v341_tune | report | B4 | (none) | `warnings[1].target: "Agentic Workflows"` |
| raydar_swe | v341_tune | report | B4 | (none) | `warnings[1].measured.verbatim: "AI workflows"` |
| raydar_swe | v341_tune | report | B4 | (none) | `warnings[1].measured.surface: "skills"` |
| raydar_swe | v341_tune | report | B4 | (none) | `warnings[1].expected: "Exact JD form is not safe to claim; supported canonical/alias coverage is present"` |
| raydar_swe | v341_tune | report | B4 | (none) | `warnings[1].suggested_repair: "Warning only: keep truthful canonical wording."` |
| raydar_swe | v341_tune | report | B4 | `skill_fit_cache.skills_text_hash: "2cdbaac802c65fbe648ef583e894fd52bfc394b243be1f5bea2ec32362f464fe"` | `skill_fit_cache.skills_text_hash: "9f16d2c4d7553d9d11abac8109341fc46de614a11b078aeff2397b223b136df2"` |
| raydar_swe | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.margin: 6` |
| raydar_swe | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].project: "goingonce"` |
| raydar_swe | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].before: "goingonce.fleet.a"` |
| raydar_swe | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].after: "goingonce.determ.a"` |
| raydar_swe | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].score_before: 3` |
| raydar_swe | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].score_after: 10` |
| raydar_swe | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].margin: 7` |
| raydar_swe | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.logistics_line: ""` |
| raydar_swe | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.ai_posting: true` |
| raydar_swe | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.llm_limitation_line: false` |
| roblox | v341_tune | resume_tex | B4 | `  \item Compared MLP, GraphSAGE, and GAT models trained with class weights and F1-tuned thresholds; GraphSAGE raised fraud F1 to 0.564 from 0.394 for the MLP, and GAT scored lowest.` | `  \item Prevented data leakage by fitting the feature scaler on the training split only and tuning decision thresholds on validation data, then reporting final results only on a held-out 15\% test set.` |
| roblox | v341_tune | report | B1, B2 | (none) | `notes[2]: "Sponsorship wording unclear: check manually (\"For US based roles only, please note the Company may not be able to employ candidates for this role who have United Stat\")."` |
| roblox | v341_tune | report | B1 | (none) | `sponsorship_v347b.blocker_before.requirement: "For US based roles only, please note the Company may not be able to employ candidates for this role who have United States work authorization related to certain US visa categories, or support future H"` |
| roblox | v341_tune | report | B1 | (none) | `sponsorship_v347b.blocker_before.polarity: "unclear"` |
| roblox | v341_tune | report | B1 | (none) | `sponsorship_v347b.blocker_after.requirement: "For US based roles only, please note the Company may not be able to employ candidates for this role who have United States work authorization related to certain US visa categories, or support future H"` |
| roblox | v341_tune | report | B1 | (none) | `sponsorship_v347b.blocker_after.polarity: "unclear"` |
| roblox | v341_tune | report | B1 | (none) | `sponsorship_v347b.action: "kept (wording unclear: v3.4.7a behaviour)"` |
| roblox | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.margin: 6` |
| roblox | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].project: "fraud"` |
| roblox | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].before: "fraud.compare.a"` |
| roblox | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].after: "fraud.leak.a"` |
| roblox | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].score_before: 1` |
| roblox | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].score_after: 9` |
| roblox | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.swaps[0].margin: 8` |
| roblox | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.logistics_line: ""` |
| roblox | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.ai_posting: true` |
| roblox | v341_tune | report | B4 | (none) | `bullet_relevance_v347b.llm_limitation_line: false` |
| rockstar | v340_original | report | B4 | `verify_changes_v344[0].change: "GoingOnce: the Fleet agent bullet is preferred (warehouse / logistics posting)"` | `verify_changes_v344[0].change: "Letter experience sentence: Thesis Mumbai Tech requirements gathering (stakeholder / requirements posting)"` |
| rockstar | v340_original | report | B4 | `verify_changes_v344[0].jd_line: "The company is seeking early Product Engineers who want to own problems end to end, from architecture to shipping to the partner conversation that shapes what gets built next."` | `verify_changes_v344[0].jd_line: "- Exhibit strong product sense and translate technical concepts to non-technical stakeholders effortlessly"` |
| rockstar | v340_original | report | B4 | `verify_changes_v344[1].change: "Letter experience sentence: Thesis Mumbai Tech requirements gathering (stakeholder / requirements posting)"` | `verify_changes_v344[1].change: "Closing responsibility \"build complex systems with elegant design and robust architecture\" with proof launchops.ownership (architecture)"` |
| rockstar | v340_original | report | B4 | `verify_changes_v344[1].jd_line: "- Exhibit strong product sense and translate technical concepts to non-technical stakeholders effortlessly"` | `verify_changes_v344[1].jd_line: "- Possess exceptional engineering skills to build complex systems with elegant design and robust architecture"` |
| rockstar | v340_original | report | B4 | `verify_changes_v344[2].change: "Closing responsibility \"build complex systems with elegant design and robust architecture\" with proof launchops.ownership (architecture)"` | `verify_changes_v344[2].change: "Experience variant E (exp.thesis.1.E, suits client-facing / internal-tools roles)"` |
| rockstar | v340_original | report | B4 | `verify_changes_v344[2].jd_line: "- Possess exceptional engineering skills to build complex systems with elegant design and robust architecture"` | `verify_changes_v344[2].jd_line: "- Collaborate effectively with customers and partners to solve complex problems"` |
| rockstar | v340_original | report | B4 | `verify_changes_v344[3].change: "Experience variant E (exp.thesis.1.E, suits client-facing / internal-tools roles)"` | (none) |
| rockstar | v340_original | report | B4 | `verify_changes_v344[3].jd_line: "- Collaborate effectively with customers and partners to solve complex problems"` | (none) |
| swisslog | holdout | report | B3 | `warnings[0].type: "jd_supported_skill_term_omitted"` | `warnings[0].type: "ats_required_verbatim_alias_only"` |
| swisslog | holdout | report | B3 | `warnings[0].target: "SQL"` | `warnings[0].target: "Debugging"` |
| swisslog | holdout | report | B3 | `warnings[0].measured: "Present in raw JD but absent from jd_requirements"` | `warnings[0].measured.verbatim: "logs"` |
| swisslog | holdout | report | B3 | `warnings[0].expected: "Include important supported JD terms within the capped jd_requirements set"` | `warnings[0].measured.surface: "skills"` |
| swisslog | holdout | report | B3 | `warnings[0].suggested_repair: "Planning warning only; do not auto-add or invent requirements."` | `warnings[0].expected: "Exact JD form is not safe to claim; supported canonical/alias coverage is present"` |
| swisslog | holdout | report | B3 | (none) | `warnings[0].suggested_repair: "Warning only: keep truthful canonical wording."` |
| swisslog | holdout | report | B3 | `warnings[1].target: "Debugging"` | `warnings[1].target: "OOP"` |
| swisslog | holdout | report | B3 | `warnings[1].measured.verbatim: "logs"` | `warnings[1].measured.verbatim: "object-oriented programming"` |
| swisslog | holdout | report | B3 | `warnings[2].type: "ats_required_verbatim_alias_only"` | (none) |
| swisslog | holdout | report | B3 | `warnings[2].target: "OOP"` | (none) |
| swisslog | holdout | report | B3 | `warnings[2].measured.verbatim: "object-oriented programming"` | (none) |
| swisslog | holdout | report | B3 | `warnings[2].measured.surface: "skills"` | (none) |
| swisslog | holdout | report | B3 | `warnings[2].expected: "Exact JD form is not safe to claim; supported canonical/alias coverage is present"` | (none) |
| swisslog | holdout | report | B3 | `warnings[2].suggested_repair: "Warning only: keep truthful canonical wording."` | (none) |
| swisslog | holdout | report | B3 | (none) | `ats_coverage[18].term: "SQL"` |
| swisslog | holdout | report | B3 | (none) | `ats_coverage[18].verbatim: "SQL"` |
| swisslog | holdout | report | B3 | (none) | `ats_coverage[18].priority: "medium"` |
| swisslog | holdout | report | B3 | (none) | `ats_coverage[18].supported: true` |
| swisslog | holdout | report | B3 | (none) | `ats_coverage[18].status: "covered"` |
| swisslog | holdout | report | B3 | (none) | `ats_coverage[18].surface: "skills"` |
| swisslog | holdout | report | B3 | `ats_summary.supported_requirements_visible: "8/8"` | `ats_summary.supported_requirements_visible: "9/9"` |
| swisslog | holdout | report | B3 | `ats_summary.exact_jd_wording_visible: "6/8"` | `ats_summary.exact_jd_wording_visible: "7/9"` |
| swisslog | holdout | report | B3 | `ats_summary.requirements_parsed: 18` | `ats_summary.requirements_parsed: 19` |
| swisslog | holdout | report | B3 | (none) | `plan_resolved_fields.jd_requirements[18].term: "SQL"` |
| swisslog | holdout | report | B3 | (none) | `plan_resolved_fields.jd_requirements[18].priority: "medium"` |
| swisslog | holdout | report | B3 | (none) | `plan_resolved_fields.jd_requirements[18].supported: true` |
| swisslog | holdout | report | B3 | (none) | `plan_resolved_fields.jd_requirements[18].verbatim: "SQL"` |
| swisslog | holdout | report | B3 | (none) | `plan_resolved_fields.jd_requirements[18].aliases[0]: "SQL"` |
| swisslog | holdout | report | B3 | (none) | `sql_term_v347b.line: "- Knowledge and experience with at least three and mastery of at least two of the following: Java, C++ or C# as well as databases (SQL Server), object-oriented concepts as related to the field of prog"` |
| swisslog | holdout | report | B3 | (none) | `sql_term_v347b.status: "covered"` |
| swisslog | holdout | report | B3 | (none) | `sql_term_v347b.surface: "skills"` |
| twitch | holdout | report | B2 | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): Ruby, C++."` | `notes[0]: "OR-group alternatives Jay does not have (the posting accepts any one, and another option is covered, so they are not gaps): Ruby, C++."` |
| twitch | holdout | report | B2 | `jd_gap_terms_detected[0]: "Ruby"` | `jd_gap_terms_detected: []` |
| twitch | holdout | report | B2 | `jd_gap_terms_detected[1]: "C++"` | (none) |
| twitch | holdout | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].term: "Ruby"` |
| twitch | holdout | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].line: "Proficiency in at least one of Go, Ruby, Java, or C++"` |
| twitch | holdout | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].covered_by: "Go (supported term Go)"` |
| twitch | holdout | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].term: "C++"` |
| twitch | holdout | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].line: "Proficiency in at least one of Go, Ruby, Java, or C++"` |
| twitch | holdout | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].covered_by: "Go (supported term Go)"` |
| twitch | holdout | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| twitch | holdout | report | B2 | (none) | `or_groups_v347b.ambiguous: []` |
| us_cold | v342_new | report | B3 | `warnings[0].type: "jd_supported_skill_term_omitted"` | `warnings: []` |
| us_cold | v342_new | report | B3 | `warnings[0].target: "SQL"` | (none) |
| us_cold | v342_new | report | B3 | `warnings[0].measured: "Present in raw JD but absent from jd_requirements"` | (none) |
| us_cold | v342_new | report | B3 | `warnings[0].expected: "Include important supported JD terms within the capped jd_requirements set"` | (none) |
| us_cold | v342_new | report | B3 | `warnings[0].suggested_repair: "Planning warning only; do not auto-add or invent requirements."` | (none) |
| us_cold | v342_new | report | B3 | (none) | `ats_coverage[19].term: "SQL"` |
| us_cold | v342_new | report | B3 | (none) | `ats_coverage[19].verbatim: "SQL"` |
| us_cold | v342_new | report | B3 | (none) | `ats_coverage[19].priority: "medium"` |
| us_cold | v342_new | report | B3 | (none) | `ats_coverage[19].supported: true` |
| us_cold | v342_new | report | B3 | (none) | `ats_coverage[19].status: "covered"` |
| us_cold | v342_new | report | B3 | (none) | `ats_coverage[19].surface: "skills"` |
| us_cold | v342_new | report | B3 | `ats_summary.supported_requirements_visible: "13/13"` | `ats_summary.supported_requirements_visible: "14/14"` |
| us_cold | v342_new | report | B3 | `ats_summary.exact_jd_wording_visible: "12/13"` | `ats_summary.exact_jd_wording_visible: "13/14"` |
| us_cold | v342_new | report | B3 | `ats_summary.requirements_parsed: 19` | `ats_summary.requirements_parsed: 20` |
| us_cold | v342_new | report | B3 | (none) | `plan_resolved_fields.jd_requirements[19].term: "SQL"` |
| us_cold | v342_new | report | B3 | (none) | `plan_resolved_fields.jd_requirements[19].priority: "medium"` |
| us_cold | v342_new | report | B3 | (none) | `plan_resolved_fields.jd_requirements[19].supported: true` |
| us_cold | v342_new | report | B3 | (none) | `plan_resolved_fields.jd_requirements[19].verbatim: "SQL"` |
| us_cold | v342_new | report | B3 | (none) | `plan_resolved_fields.jd_requirements[19].aliases[0]: "SQL"` |
| us_cold | v342_new | report | B3 | (none) | `sql_term_v347b.line: "- Knowledge of relational databases such as Oracle and SQL server and ORM technologies (Hibernate)"` |
| us_cold | v342_new | report | B3 | (none) | `sql_term_v347b.status: "covered"` |
| us_cold | v342_new | report | B3 | (none) | `sql_term_v347b.surface: "skills"` |
| ust_software_engineer | v347_new | resume_tex | B3 | `  \item \textbf{Languages \& Databases:} Python, PostgreSQL, Java, Go, SQL, MongoDB, JavaScript, MySQL` | `  \item \textbf{Languages \& Databases:} Python, PostgreSQL, SQL, Java, Go, MongoDB, JavaScript, MySQL` |
| ust_software_engineer | v347_new | report | B3 | `warnings[0].type: "jd_supported_skill_term_omitted"` | `warnings: []` |
| ust_software_engineer | v347_new | report | B3 | `warnings[0].target: "SQL"` | (none) |
| ust_software_engineer | v347_new | report | B3 | `warnings[0].measured: "Present in raw JD but absent from jd_requirements"` | (none) |
| ust_software_engineer | v347_new | report | B3 | `warnings[0].expected: "Include important supported JD terms within the capped jd_requirements set"` | (none) |
| ust_software_engineer | v347_new | report | B3 | `warnings[0].suggested_repair: "Planning warning only; do not auto-add or invent requirements."` | (none) |
| ust_software_engineer | v347_new | report | B3 | (none) | `ats_coverage[10].term: "SQL"` |
| ust_software_engineer | v347_new | report | B3 | (none) | `ats_coverage[10].verbatim: "SQL"` |
| ust_software_engineer | v347_new | report | B3 | (none) | `ats_coverage[10].priority: "medium"` |
| ust_software_engineer | v347_new | report | B3 | (none) | `ats_coverage[10].supported: true` |
| ust_software_engineer | v347_new | report | B3 | (none) | `ats_coverage[10].status: "covered"` |
| ust_software_engineer | v347_new | report | B3 | (none) | `ats_coverage[10].surface: "skills"` |
| ust_software_engineer | v347_new | report | B3 | `skill_fit_cache.skills_text_hash: "efd0b5d454526f328d3d5beab27c612bc9d925232d08065001dd8ed849e90b45"` | `skill_fit_cache.skills_text_hash: "c82c3c95471daed89be1fab280382b62708dc914f0c9e6548a530113658d13be"` |
| ust_software_engineer | v347_new | report | B2 | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): C#, SQL Server, Azure, GCP."` | `notes[0]: "OR-group alternatives Jay does not have (the posting accepts any one, and another option is covered, so they are not gaps): C#, SQL Server, Azure, GCP."` |
| ust_software_engineer | v347_new | report | B3 | `ats_summary.supported_requirements_visible: "10/10"` | `ats_summary.supported_requirements_visible: "11/11"` |
| ust_software_engineer | v347_new | report | B3 | `ats_summary.exact_jd_wording_visible: "7/10"` | `ats_summary.exact_jd_wording_visible: "8/11"` |
| ust_software_engineer | v347_new | report | B3 | `ats_summary.requirements_parsed: 10` | `ats_summary.requirements_parsed: 11` |
| ust_software_engineer | v347_new | report | B2 | `jd_gap_terms_detected[0]: "C#"` | `jd_gap_terms_detected: []` |
| ust_software_engineer | v347_new | report | B2 | `jd_gap_terms_detected[1]: "SQL Server"` | (none) |
| ust_software_engineer | v347_new | report | B2 | `jd_gap_terms_detected[2]: "Azure"` | (none) |
| ust_software_engineer | v347_new | report | B2 | `jd_gap_terms_detected[3]: "GCP"` | (none) |
| ust_software_engineer | v347_new | report | B3 | (none) | `plan_resolved_fields.jd_requirements[10].term: "SQL"` |
| ust_software_engineer | v347_new | report | B3 | (none) | `plan_resolved_fields.jd_requirements[10].priority: "medium"` |
| ust_software_engineer | v347_new | report | B3 | (none) | `plan_resolved_fields.jd_requirements[10].supported: true` |
| ust_software_engineer | v347_new | report | B3 | (none) | `plan_resolved_fields.jd_requirements[10].verbatim: "SQL"` |
| ust_software_engineer | v347_new | report | B3 | (none) | `plan_resolved_fields.jd_requirements[10].aliases[0]: "SQL"` |
| ust_software_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].term: "C#"` |
| ust_software_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].line: "Strong programming experience in one or more languages such as Java, C#, Python, JavaScript, or Go."` |
| ust_software_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].covered_by: "Java (supported term Java)"` |
| ust_software_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].term: "SQL Server"` |
| ust_software_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].line: "Experience with databases such as SQL Server, MySQL, PostgreSQL, or MongoDB."` |
| ust_software_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].covered_by: "MySQL (supported term MySQL)"` |
| ust_software_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[2].term: "Azure"` |
| ust_software_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[2].line: "Understanding of cloud platforms such as Azure, AWS, or GCP."` |
| ust_software_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[2].covered_by: "AWS (supported term AWS)"` |
| ust_software_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[3].term: "GCP"` |
| ust_software_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[3].line: "Understanding of cloud platforms such as Azure, AWS, or GCP."` |
| ust_software_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[3].covered_by: "AWS (supported term AWS)"` |
| ust_software_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| ust_software_engineer | v347_new | report | B2 | (none) | `or_groups_v347b.ambiguous: []` |
| ust_software_engineer | v347_new | report | B3 | (none) | `sql_term_v347b.line: "· Experience with databases such as SQL Server, MySQL, PostgreSQL, or MongoDB."` |
| ust_software_engineer | v347_new | report | B3 | (none) | `sql_term_v347b.status: "covered"` |
| ust_software_engineer | v347_new | report | B3 | (none) | `sql_term_v347b.surface: "skills"` |
| vindexa | v340_original | report | B4 | `verify_changes_v344[1].change: "GoingOnce: the Fleet agent bullet is preferred (warehouse / logistics posting)"` | `verify_changes_v344[1].change: "Closing responsibility \"write production-quality code while moving at startup speed\" with proof ripple.git_verification (testing)"` |
| vindexa | v340_original | report | B4 | `verify_changes_v344[1].jd_line: "- Demonstrated history of shipping meaningful software at startup pace."` | `verify_changes_v344[1].jd_line: "write production-quality code while moving at startup speed"` |
| vindexa | v340_original | report | B4 | `verify_changes_v344[2].change: "Closing responsibility \"write production-quality code while moving at startup speed\" with proof ripple.git_verification (testing)"` | `verify_changes_v344[2].change: "Experience variant A (exp.hein.1.A, suits AI / LLM / document roles)"` |
| vindexa | v340_original | report | B4 | `verify_changes_v344[2].jd_line: "write production-quality code while moving at startup speed"` | `verify_changes_v344[2].jd_line: "You will work directly alongside our CEO, who is technical and actively involved in product and engineering, and operate with significant autonomy. We move fast using AI coding tools and agents as force multipliers, not crutches. The expect"` |
| vindexa | v340_original | report | B4 | `verify_changes_v344[3].change: "Experience variant A (exp.hein.1.A, suits AI / LLM / document roles)"` | `verify_changes_v344[3].change: "Experience variant C (exp.hein.3.C, suits AI roles)"` |
| vindexa | v340_original | report | B4 | `verify_changes_v344[4].change: "Experience variant C (exp.hein.3.C, suits AI roles)"` | `verify_changes_v344[4].change: "Experience variant D (exp.thesis.1.D, for every role)"` |
| vindexa | v340_original | report | B4 | `verify_changes_v344[4].jd_line: "You will work directly alongside our CEO, who is technical and actively involved in product and engineering, and operate with significant autonomy. We move fast using AI coding tools and agents as force multipliers, not crutches. The expect"` | `verify_changes_v344[4].jd_line: "Eventually recruit, mentor, and lead additional engineers as the team grows."` |
| vindexa | v340_original | report | B4 | `verify_changes_v344[5].change: "Experience variant D (exp.thesis.1.D, for every role)"` | `verify_changes_v344[5].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` |
| vindexa | v340_original | report | B4 | `verify_changes_v344[5].jd_line: "Eventually recruit, mentor, and lead additional engineers as the team grows."` | `verify_changes_v344[5].jd_line: "- Instrument the system: logging, monitoring, error tracking, performance."` |
| vindexa | v340_original | report | B4 | `verify_changes_v344[6].change: "Experience variant G (exp.thesis.5.G, suits SRE / DevOps / operations roles)"` | (none) |
| vindexa | v340_original | report | B4 | `verify_changes_v344[6].jd_line: "- Instrument the system: logging, monitoring, error tracking, performance."` | (none) |
| wgu | v341_tune | report | B2 | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): TypeScript, Spark, Hadoop, Databricks, Jira, Scala, Vue, Angular."` | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): TypeScript, Spark, Hadoop, Databricks, Jira, Scala."` |
| wgu | v341_tune | report | B2 | (none) | `notes[1]: "OR-group alternatives Jay does not have (the posting accepts any one, and another option is covered, so they are not gaps): Vue, Angular."` |
| wgu | v341_tune | report | B2 | `jd_gap_terms_detected[6]: "Vue"` | (none) |
| wgu | v341_tune | report | B2 | `jd_gap_terms_detected[7]: "Angular"` | (none) |
| wgu | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].term: "Vue"` |
| wgu | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].line: "Experience with JavaScript/TypeScript and a modern UI framework such as Angular, React, or Vue.js"` |
| wgu | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].covered_by: "React (supported term ReactJS)"` |
| wgu | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].term: "Angular"` |
| wgu | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].line: "Experience with JavaScript/TypeScript and a modern UI framework such as Angular, React, or Vue.js"` |
| wgu | v341_tune | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[1].covered_by: "React (supported term ReactJS)"` |
| wgu | v341_tune | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| wgu | v341_tune | report | B2 | (none) | `or_groups_v347b.ambiguous: []` |
| zoro_fullstack | v347_new | report | B1 | `warnings[1].type: "note_work_authorization_or_sponsorship"` | (none) |
| zoro_fullstack | v347_new | report | B1 | `warnings[1].target: "gating"` | (none) |
| zoro_fullstack | v347_new | report | B1 | `warnings[1].measured: "H1B Sponsor Likely"` | (none) |
| zoro_fullstack | v347_new | report | B1 | `warnings[1].expected: ""` | (none) |
| zoro_fullstack | v347_new | report | B1 | `warnings[1].suggested_repair: "Check the posting before applying."` | (none) |
| zoro_fullstack | v347_new | report | B1 | `eligibility_blockers[0].type: "work_authorization_or_sponsorship"` | `eligibility_blockers: []` |
| zoro_fullstack | v347_new | report | B1 | `eligibility_blockers[0].requirement: "H1B Sponsor Likely"` | (none) |
| zoro_fullstack | v347_new | report | B1 | `eligibility_blockers[0].reason: "Candidate plans to use F-1 OPT and will need future employer sponsorship."` | (none) |
| zoro_fullstack | v347_new | report | B1 | `effective_fit: "Low"` | `effective_fit: "High"` |
| zoro_fullstack | v347_new | report | B1, B2 | `notes[0]: "work_authorization_or_sponsorship: Candidate plans to use F-1 OPT and will need future employer sponsorship."` | `notes[0]: "Sponsorship information (not a blocker): \"H1B Sponsor Likely\" (job-board badge / sponsorship data)."` |
| zoro_fullstack | v347_new | report | B1, B2 | `notes[1]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): Ruby."` | `notes[1]: "OR-group alternatives Jay does not have (the posting accepts any one, and another option is covered, so they are not gaps): Ruby."` |
| zoro_fullstack | v347_new | report | B1 | `tracker_row.Fit (High/Medium/Low): "Low"` | `tracker_row.Fit (High/Medium/Low): "High"` |
| zoro_fullstack | v347_new | report | B1 | `tracker_row.Blockers: "no visa sponsorship"` | `tracker_row.Blockers: ""` |
| zoro_fullstack | v347_new | report | B2 | `jd_gap_terms_detected[0]: "Ruby"` | `jd_gap_terms_detected: []` |
| zoro_fullstack | v347_new | report | B1 | (none) | `sponsorship_v347b.blocker_before.requirement: "H1B Sponsor Likely"` |
| zoro_fullstack | v347_new | report | B1 | (none) | `sponsorship_v347b.blocker_before.polarity: "badge"` |
| zoro_fullstack | v347_new | report | B1 | (none) | `sponsorship_v347b.blocker_after: null` |
| zoro_fullstack | v347_new | report | B1 | (none) | `sponsorship_v347b.action: "removed (badge wording is information, not a blocker)"` |
| zoro_fullstack | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].term: "Ruby"` |
| zoro_fullstack | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].line: "Proficient in high-level languages such as Python, Ruby or Javascript"` |
| zoro_fullstack | v347_new | report | B2 | (none) | `or_groups_v347b.stack_gaps_cleared[0].covered_by: "Python (supported term Python)"` |
| zoro_fullstack | v347_new | report | B2 | (none) | `or_groups_v347b.hard_gaps_cleared: []` |
| zoro_fullstack | v347_new | report | B2 | (none) | `or_groups_v347b.ambiguous: []` |
| zoro_fullstack | v347_new | tracker | B1 | `Fit (High/Medium/Low): "Low"` | `Fit (High/Medium/Low): "High"` |
| zoro_fullstack | v347_new | tracker | B1 | `Blockers: "no visa sponsorship"` | `Blockers: ""` |
