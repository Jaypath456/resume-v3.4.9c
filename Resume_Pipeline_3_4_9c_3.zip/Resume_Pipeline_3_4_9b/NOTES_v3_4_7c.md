# Resume pipeline v3.4.7c: notes

Built 2026-10-18 from Resume_Pipeline_3_4_7b.zip. One change, C1: GoingOnce's Fleet bullet appears only on
supply-chain / warehouse / logistics / vehicle-fleet postings. It is the v3.4.7b test switch `V347B_STRICT_FLEET`
turned into a real rule, behind the new master.json `v347_flags` entry `strict_fleet` (default true). Every changed
output line is in DIFF_REPORT_v347c.md; the code change is in CHANGES.md.

## What Jay needs to do

1. **Sources: re-upload 3 of the 7 files.** Changed: `resume_pipeline_v3_2.py`, `master.json` (new `strict_fleet`
   flag and the new md pointer), `Master_Resume_Context_LEAN_CURRENT_v3_2.md` (new section 0-v347c). Unchanged:
   `bullet_bank.json`, `Resume_Template_CURRENT.tex`, `plan_template.json`, `bank_check.py`. Uploading all 7 is fine.
2. **Project instructions: paste the new `2_PROJECT_INSTRUCTIONS_paste.txt`** (7,581 characters; limit 7,600). Only the
   version ("pipeline v3.4.7c") and the hash lock changed.
3. **Tracker sheet: nothing new.**
4. Optional: send `5_judged_packages/Judge_Batch_v3_4_7c.md` to the judge.

## Hash lock

| File | sha256 |
|---|---|
| resume_pipeline_v3_2.py | b96bab1d… (full value in the instructions) |
| master.json | 6efa8598… |
| bullet_bank.json | d56f0743… (unchanged) |
| Resume_Template_CURRENT.tex | 1309898b… (unchanged) |
| Master_Resume_Context_LEAN_CURRENT_v3_2.md | 9003110a… |
| plan_template.json | 4358f1e0… (unchanged) |
| bank_check.py | 81b28185… (unchanged) |

## Acceptance

| Check | Result |
|---|---|
| Baseline | `3_validation/baseline_v347b/`: all 124 fixtures run on the unmodified 7b Sources, saved before any change |
| Determinism (7b code) | IDENTICAL: two 7b runs |
| Predictions | `predict_v347c.py` (restates the rule without the new code, imports only the 7b posting parser) wrote `predicted_changes_v347c.json` from the baseline before the code changed |
| Diff gate | **PASS** (`diff_gate_v347c.py`): 130 changed lines in 15 fixtures (13 swaps + the version label on the two stop reports), 0 unpredicted, 0 guard failures. Guards: only allowlisted fixtures change; the only changed .tex lines are Fleet -> another GoingOnce bullet; same project headings, bullet counts, .tex line counts and unique verbs; Skills lines untouched; letter = old letter with only the Fleet sentence replaced; tracker and outreach unchanged; report.json identical apart from the swap log and the measurements listed below |
| strict_fleet off | IDENTICAL to baseline_v347b on all 124 fixtures (version label only on the two stops) |
| Determinism (7c code) | IDENTICAL: two full 7c runs |
| Fixtures | 124: 122 pass + 2 expected stops (fonzi, cisco_no_title) |
| score_all | 10.00 / 10.00 on v340_original (53), v341_tune (36), v342_new (6), v343_new (2), v344_new (2), v345_new (1); v347_new (4) resume 10.00, letter 9.88 (zoro hook, as before) |
| Holdouts (20, never tuned) | resume 9.85, letter 9.97, unchanged; below 9.5: acme_cloud, twitch, linkedin_ai (as before). One holdout changed: amplitude (on your allowlist), Fleet -> Negotiate |
| audit_v344 | PASS: 122 built, 11 fallback closings (9.0%), longest closing 30 words, longest letter 200 words |
| bank_check | 113/113 ok, 10/10 Experience variants ok |
| selftests | v341 to v347b pass (v342 to v347b: version checks; v347b turns strict_fleet off in its 7a-equivalence builds); new selftest_v347c passes 39 checks (flag, logistics test, alml / rockstar swaps compared with baseline_v347b, inspire11 FAIL-CLOSED identical, us_cold keeps Fleet, 3 strict_fleet-off builds identical, instructions and hash lock) |
| Names defined more than once | 61 (unchanged) |

## Every swapped bullet (13)

Before, on all 13: *"Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in
full truckloads, and schedules pickups, so simulated prices hold and transport stays low."* (2 lines, verb Programmed)

| Fixture | Group | After (all 2 lines; the verb is unique on the page) |
|---|---|---|
| alml_engineer | v347_new | Negotiate: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport." |
| amplitude | holdout | Negotiate (same text) |
| anthropic_it | v340_original | Plain code: "Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and photos with a saved fallback for every call, so results repeat." (Skills already show Claude API) |
| brillio | v340_original | Negotiate |
| bti | v341_tune | Negotiate |
| cdi | v340_original | Negotiate |
| flowgen | v341_tune | Negotiate |
| meritore_capgemini | v347_new | Negotiate |
| research_phd | v341_tune | Negotiate |
| rockstar | v340_original | Negotiate. **Letter:** "Its Fleet agent spreads 120 similar rental cars across markets in full truckloads after checking demand." -> "I coded its Negotiate agent, where each side keeps a private price limit and a mediator closes the gap in rounds." (181 -> 186 words in the body; nothing else in the letter changed) |
| twitch_se1 | v342_new | Interface: "Created the Streamlit and React interface for the agents' streaming API so users can follow each agent's progress live, step by step, while the four agents of the simulated marketplace prototype run." |
| vindexa | v340_original | Negotiate |
| zoro_fullstack | v347_new | Negotiate |

Projects, order, slot counts, Skills, Fit, blockers, tracker rows and outreach are unchanged on all 13. Only rockstar's
letter used the Fleet fact. report.json gains `strict_fleet_v347c` (before / after id and text, lines, verb, and the
letter sentence when it changed); rockstar's `cover_letter.words` / `words_total` follow its letter; anthropic_it's
coverage now lists the new bullet as evidence for Claude (`ats_coverage[0].also_in`, `preflight_v344.skills_or_heading_only`).

## Allowlisted fixtures that did not change (12), and why

| Fixture | Why |
|---|---|
| booz_allen, monti, quora, raydar_swe | v3.4.7b B4 already replaced their Fleet bullet (the 22-fixture list was measured against 7a) |
| roblox | no Fleet bullet in 7b (its 7b change was a Fraud bullet) |
| cardinal, harvey, inspire11, ng_fullstack, sparkline, tiktok_appsec | **Fleet kept (FAIL-CLOSED).** The only same-size GoingOnce bullet with a new evidence id and an unused verb is the plain-code bullet, which names Claude; Skills do not show Claude API on these pages and Skills may not change, so the build fails the "every bullet technology is in Skills" check and the script keeps Fleet. tiktok_appsec's letter, which carries the Fleet sentence, is therefore unchanged too |
| rocketmoney | **Fleet kept (FAIL-CLOSED).** Plain-code bullet: same Claude / Skills problem; the next one (the "Coded the Negotiate and Fleet agents and the ... front end" bullet) is not reproduced by the selector |

## Postings off the allowlist that still show Fleet (9)

audit05, brightpath_fs, cobalt, frontend, ixl, loopwell, lumen (holdout), northwind, pinecrest are not logistics
postings, so the rule applies, but the selector does not reproduce the replacement (it would reshuffle other GoingOnce
bullets), so the script keeps the 7b page. This is the same FAIL-CLOSED behaviour the 7b switch had, and it keeps every
fixture outside your allowlist byte-identical. us_cold keeps Fleet because it is a logistics posting (cold storage).

## Assumptions

- **Allowlist is a gate rule, not code.** The pipeline cannot know fixture names; `diff_gate_v347c.py` fails if any
  fixture outside the 25 changes. The live rule in ChatGPT applies to every posting.
- **"Report fields that log the swap"** covers the new `strict_fleet_v347c` block, the letter word counts when the
  letter sentence changed, and fields that describe the new bullet itself (a tail-fill warning if it had one, which bullet
  backs a Skills term). Fit, blockers, gaps, status and Skills resolution are compared exactly.
- **Skills are frozen** by building them from the page as it was before the swap; a replacement naming a technology
  Skills do not show fails the build and the script retries the next bullet, then keeps Fleet.
- **Letter:** the letter is written as before the swap, then the Fleet sentence is replaced by the new bullet's letter
  sentence (master `cover_letter_bank.letter_sentences`). A closing resting on the Fleet proof, or a letter over 200
  words, would also trigger the retry (did not happen).
- **Retries:** at most four replacement attempts, then the 7b page. A B4 swap of the Fleet bullet keeps its B4 log.
- bullet_bank.json and the template are not edited; the bank's informational `built_with` pointer still names an older
  master hash (nothing checks it). `tools/` stays out of the zip.
