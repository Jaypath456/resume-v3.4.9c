# Experience variants: approved (v3.4.3)

Jay approved variants A-H on 2026-10-15, and `experience_variants_enabled` is now `true` in master.json. Live runs swap in at most one variant per Experience bullet when its themes fit the posting (theme weight >= 0.12); D has no theme and is used whenever E does not fit.

Rules (script-checked by `experience_variant_problems`, bank_check and on every page): a variant may drop facts but never adds a fact, number or tool (a subset is fine); at most 2 content words beyond the job's bullets and evidence anchors; its opening verb may change only when no other bullet on the page starts with that verb; it renders the same number of lines as the original. bank_check result: 8/8 variants ok.

| Variant | Job | Original | Approved text | Used for |
|---|---|---|---|---|
| A (exp.hein.1.A) | HeinOnline (University at Buffalo) | Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals. | Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals using OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B), CrossRef API, and web scrapers. | llm_agents, ai_apps, model_api, ml_dl |
| B (exp.hein.1.B) | HeinOnline (University at Buffalo) | Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals. | Engineered a fault-tolerant data pipeline that processed 28k+ pages of law journals, combining CrossRef API, web scrapers, and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B). | data_eng, backend, integration |
| C (exp.hein.3.C) | HeinOnline (University at Buffalo) | Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing time by over 80%, and added confidence scoring to flag low-confidence fields for human review. | Added confidence scoring that flags low-confidence fields for human review, and parallelized the pipeline with a CPU-based worker pool, cutting total processing time by over 80%. | llm_agents, ai_apps, model_api, ml_dl |
| D (exp.thesis.1.D) | Thesis Mumbai Tech (Startup) | Led end-to-end delivery of healthcare platform modules with a team of 4: gathered requirements in client meetings, prototyped to validate scope, and broke the finalized work into tasks. | Led a team of 4 through end-to-end delivery of healthcare platform modules: gathered requirements in client meetings, prototyped to validate scope, and broke the finalized work into tasks. | always (when no themed variant fits) |
| E (exp.thesis.1.E) | Thesis Mumbai Tech (Startup) | Led end-to-end delivery of healthcare platform modules with a team of 4: gathered requirements in client meetings, prototyped to validate scope, and broke the finalized work into tasks. | Gathered requirements in client meetings, prototyped to validate scope, and led a team of 4 through end-to-end delivery of healthcare platform modules. | customer, it_ops |
| F (exp.thesis.2.F) | Thesis Mumbai Tech (Startup) | Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ~2s live monitoring. | Developed a real-time WebSocket + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ~2s live monitoring, plus Patient Management and Consent modules on normalized schemas for 10k+ records. | realtime, systems |
| G (exp.thesis.5.G) | Thesis Mumbai Tech (Startup) | Built a heartbeat monitoring dashboard for 4 production projects, pinging each site every 5 minutes to track health. | Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing. | devops_cloud, it_ops |
| H (exp.datamaven.1.H) | Data Maven Pvt Ltd | Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access. | Deployed backend services on AWS EC2 and RDS, restricting access with VPC networking and security groups. | devops_cloud, security |

The seven v3.4.2 proposals were replaced by these eight texts. Assumptions: G ("restored the services it caught failing") rests on the Thesis anchor "heartbeat/service monitoring and responding to failures it surfaced"; A calls the HeinOnline work an "LLM document-extraction pipeline" from the OCR/LLM vision step in the original bullet.

## v3.4.6: variant J (approved by Jay 2026-10-16, verb-only, in rotation)

| Variant | Job | Original | Approved text | Used for |
|---|---|---|---|---|
| J (exp.godigital.1.J) | Go Digital Technology Consulting | Developed a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data and generate automated anomaly reports for the compliance and audit team. | Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data and generate automated anomaly reports for the compliance and audit team. | any page where another Experience bullet (Thesis original or variant F) also opens with "Developed" |

Only the opening verb changes; every other word, number and fact is identical. "Authored" was added to master
banned_project_verbs (the list of Experience verbs), so no project bullet can take it and J can never be skipped for a
verb clash. The page check fails any build where two Experience bullets open with the same verb. bank_check: 10/10
Experience variants ok (J renders 2 lines, as the original).
