# Resume pipeline v3.4.7a: notes

Built 2026-10-18 from Resume_Pipeline_3_4_6.zip. Low-risk build: safety tooling S1 to S5 first, then fixes A1 to A6,
each behind its own master.json `v347_flags` switch (default true). Details and before/after snippets in CHANGES.md;
every changed output line in DIFF_REPORT_v347a.md.

## What Jay needs to do

1. **Sources: re-upload 3 of the 7 files.** Changed: `resume_pipeline_v3_2.py`, `master.json` (adds `v347_flags` and the
   new md pointer), `Master_Resume_Context_LEAN_CURRENT_v3_2.md` (new section 0-v347a). Unchanged: `bullet_bank.json`,
   `Resume_Template_CURRENT.tex`, `plan_template.json`, `bank_check.py`. Uploading all 7 again is fine.
2. **Project instructions: paste the new `2_PROJECT_INSTRUCTIONS_paste.txt`** (7,581 characters; limit 7,600). It has the
   new hash lock, "pipeline v3.4.7a" and the A3 company rule: application.company is the organization the posting says
   has the opening or receives applications; a different board/header label goes in Notes; the recruiter / agency rule is
   kept. To make room, four short phrases were trimmed (one tagline example, the "audiobook" example, "Never invent a
   title", which "copied exactly" already covers, and two pronoun phrases); no rule was removed.
3. **Tracker sheet: nothing new.**

## Hash lock

| File | sha256 |
|---|---|
| resume_pipeline_v3_2.py | 879ef747… (full value in the instructions) |
| master.json | 0227a736… |
| bullet_bank.json | d56f0743… (unchanged) |
| Resume_Template_CURRENT.tex | 1309898b… (unchanged) |
| Master_Resume_Context_LEAN_CURRENT_v3_2.md | 7a052c4e… |
| plan_template.json | 4358f1e0… (unchanged) |
| bank_check.py | 81b28185… (unchanged) |

## Acceptance

| Check | Result |
|---|---|
| S1 baseline | 4 postings added as fixtures (suite v347): 124 fixtures. `3_validation/baseline_v346/` = resume .tex, letter .txt, report.json, tracker_row.json, outreach.json of each, from the unmodified v3.4.6 Sources |
| S2 determinism | PASS: two full v3.4.6 runs identical after normalizing only report.json `timestamps.*` (start, end, duration_ms per stage) and `pdflatex_calls[*].duration_ms` |
| S3 all flags off | PASS: all 124 fixtures identical to baseline_v346 (normalized). The only listed difference is the version label `pipeline_version` "v3.4.6" -> "v3.4.7a" in the two stop reports (fonzi, cisco_no_title), the only reports that carry it |
| S4 predictions | `predicted_changes_v347a.json`, written by `predict_v347a.py` from the baseline before any code change |
| S5 diff gate | PASS: 1,719 changed lines in 115 fixtures, 0 unpredicted on the 53 originals and 20 holdouts, 0 unjustified elsewhere, 0 invariant violations, every prediction happened |
| Invariants (gate) | no change to any resume bullet, Skills line, project heading name (selection / order), tracker row, Fit, blockers, gaps or status; the run summary (family, project order, Fit, blockers) of every fixture equals v3.4.6 |
| Fixtures | 124: 122 pass + 2 expected stops (fonzi, cisco_no_title) |
| score_all | identical to the v3.4.6 baseline: 10.00 / 10.00 on v340_original (53), v341_tune (36), v342_new (6), v343_new (2), v344_new (2), v345_new (1); v347_new (4) resume 10.00, letter 9.88 |
| Holdouts (20, never tuned) | resume 9.85, letter 9.97, unchanged; below 9.5: acme_cloud, twitch, linkedin_ai (as before) |
| audit_v344 | PASS: 122 built, 11 fallback closings (9.0%), longest closing 30 words, longest letter 200 words |
| bank_check | 113/113 ok, 10/10 Experience variants ok |
| selftests | v341 to v346 pass; new selftest_v347a passes (65 checks: each fix, 6 end-to-end builds including the two-organization FAIL, 4 flags-off builds equal to baseline_v346, a one-flag rollback) |
| Names defined more than once | 61 (unchanged) |

## The four new postings (outputs in `packages/`)

| Fixture | Plan stand-ins | Result |
|---|---|---|
| zoro_fullstack | Zoro, "Software Developer- Full Stack", Buffalo Grove, IL (Onsite) | PASS, Fit Low (see finding 1). A1: letter now says "I am open to relocating." A2: JavaScript left the LedgerFlow heading and stays on GoingOnce |
| alml_engineer | company "Not stated" (the posting names none), "AL/ML Engineer", Santa Clara, CA (Onsite) | PASS, Fit Medium. A5: people searches leave the company out |
| ust_software_engineer | UST, "Software Engineer", Frisco, TX (Hybrid) | PASS, Fit High. Unchanged apart from A4 |
| meritore_capgemini | Meritore Technologies LLC, "Software Engineer", Ashburn, VA; hook names only Meritore | PASS, Fit Medium. A3 Notes: "Posted under Capgemini; the posting names Meritore Technologies LLC as the employer." |

## Findings left for a later build (not fixed: outside this low-risk scope)

1. **Zoro gets a sponsorship blocker from a job-board badge.** "H1B Sponsor Likely" (a board widget that says the
   company is likely to sponsor) is read as a work-authorization requirement, so Fit is capped at Low. Same in v3.4.6.
2. **Zoro's posting yields no first responsibility line** (A6 now says so: "no first responsibility line was found"),
   so its stand-in hook is scored not specific (letter 9.5, same as v3.4.6). The title also tokenizes as "Developer-".
3. **UST's "UST is searching for ..."** is not one of the three A3 patterns, so no employer statement is recorded there
   (company and employer agree anyway).
4. **A2 removes, it does not move.** When another project's bullets show the technology but that project's heading does
   not list it (a LaunchOps React bullet for JavaScript), the technology leaves every heading it was added to (frontend,
   inspire11, cdi and others); Skills still list it. Moving it onto the best-showing heading would displace a core item.
5. **ats_coverage still says `also_in: header`** for a technology A2 took off every heading (e.g. frontend JavaScript),
   because A2 changes only the rendered heading so that Skills stay byte-identical. Skills is the term's main surface.

## Assumptions

- **Flags and the hash lock.** master.json is hash-locked, so the regression cannot edit it to test flags off. A
  test-only switch `--regression-v347-flags-off=all|name,...` (like `--regression-allow-missing-title`;
  `V347_FLAGS_OFF=all python3 run_all.py`) turns fixes off at run time. For a real rollback, set the flag false in
  master.json and rehash (EXPECTED_MASTER_JSON_SHA256, the instructions' hash lock).
- **bullet_bank.json not edited**, as asked. Its informational `built_with.master_json_sha256` therefore still holds
  the v3.4.6 master hash; nothing checks that field.
- **A1 Buffalo, NY** means the city Buffalo followed by NY, N.Y. or New York ("Buffalo, NY", "Buffalo, New York"). The
  remote test is v3.4.6's (a "remote" word in the location or the posting's first 400 characters, unless the location says
  hybrid / onsite). No fixture had a remote letter with relocation, so that branch only shows in the selftest.
- **A2 "best shows"** = most selected bullets naming the technology, a framework counting for its language (React, Node,
  TypeScript -> JavaScript; Django, Flask, FastAPI, Pydantic, pytest, PyTorch, LangGraph, Streamlit, asyncio -> Python;
  Spring -> Java); ties go to the earlier project on the page. If no holder's bullets show it and no other selected
  project shows it, the first heading keeps it. A plan's own `project_tech` is never moved. The slot is not refilled
  (refilling with the displaced core item changed Skills order on frontend and inspire11 in a trial run, so it was
  dropped).
- **A3** reads employer statements only in the three forms asked for; the board / header label is a "company:" line. The
  Notes line is written when the detected employer differs from application.company, and also when the employer matches
  but a header label differs (meritore). The letter check counts organizations found this way (employer statements and
  labels) that differ from application.company; Jay's own employers and schools are never counted.
- **A4**: entries flagged internal (variant J) and entries the v3.4.5 quote check marked "(no posting line names it;
  script rule)" move; the suffix becomes the reason. `internal_changes` appears only when something moved.
- **A6**: hook_specific's test is unchanged; its body moved into `v347_hook_detail`. selftest_v347a compares the verdict
  with a copy of the v3.4.6 function on every fixture hook.
- **Fixture stand-ins** for the 4 postings were chosen to pass the v3.4.6 rules (the first Meritore hook failed
  cover_letter_hook_not_from_jd and was reworded to copy the posting's duty line). alml_engineer: company "Not stated"
  (the posting names no company) and Santa Clara, CA, from the body, not the San Francisco header.
- **Version label.** PIPELINE_VERSION is "v3.4.7a". It is the one justified difference in the gate (the two stop
  reports), listed in DIFF_REPORT_v347a.md.
- 4_sample_outputs and 5_judged_packages are unchanged v3.4.6 outputs; the four new postings' v3.4.7a outputs are in
  packages/ beside this file.
- Never invented evidence: no master fact, bank bullet or letter sentence changed. GoingOnce keeps "with a four-person
  team"; fraud stays solo; variant J and the v3.4.6 tagline validator are untouched.
