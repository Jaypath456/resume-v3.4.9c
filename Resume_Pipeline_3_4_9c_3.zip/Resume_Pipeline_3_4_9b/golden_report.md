# Golden set report (v3.4.9a)

Snapshot: `snap_v349a_7b` (label snap_v349a_7b). Rules: `golden_set.json`.

Result: **11 / 12 PASS**.

| Posting | Set | rank1 | Page order | Fit | Hard gaps | Languages line | Closing sentence | Forbidden found | Result | Flipped by |
|---|---|---|---|---|---|---|---|---|---|---|
| akamai_se | launchops, ledgerflow, ripple | ledgerflow | ledgerflow > ripple > launchops | High | none | Python, JavaScript, Go, Java, SQL, PostgreSQL, MySQL | I want to build and maintain customer-facing platform features at Akamai Technologies, drawing on the real-time IoT pipeline I built at Thesis Mumbai Tech. | none | PASS | snap_v349a_8: FAIL -> PASS |
| ebsco_sde1 | launchops, ledgerflow, ripple | ledgerflow | ledgerflow > ripple > launchops | Medium | on-call | JavaScript, SQL, HTML/CSS, Java, Python, JSON, PostgreSQL, MySQL | I want to design, develop, and demonstrate software at EBSCO Information Services, building on LedgerFlow, which kept every balance correct through forced crashes and repeated messages. | none | FAIL: rank1 ledgerflow != launchops | - |
| giga_swe | goingonce, ledgerflow, ripple | ripple | goingonce > ledgerflow > ripple | Medium | none | Java, Python, SQL, PostgreSQL | I want to help build the systems that power the AI agents at Giga, drawing on RIPPLE, which checks every claim against evidence. | none | PASS | snap_v349a_6: FAIL -> PASS |
| meritore_jpc | launchops, ledgerflow, ripple | ledgerflow | ledgerflow > ripple > launchops | Medium | none | Python, Java, Go, SQL, PostgreSQL, MySQL | I want to write clean, efficient, and well-documented code at Meritore Technologies LLC, building on LedgerFlow, where a GitHub Actions CI workflow runs every automated test. | none | PASS | snap_v349a_5: FAIL -> PASS |
| ust_software_engineer | launchops, ledgerflow, ripple | ledgerflow | ledgerflow > ripple > launchops | High | none | Python, SQL, Java, Go, JavaScript, PostgreSQL, MongoDB, MySQL | I want to design, develop, test, deploy, and maintain software applications at UST, building on LedgerFlow, which kept every balance correct through forced crashes and repeated messages. | none | PASS | - |
| zoro_fullstack | goingonce, launchops, ledgerflow | launchops | ledgerflow > goingonce > launchops | High | none | Python, JavaScript, Java, Go, SQL, MySQL, PostgreSQL, MongoDB | I want to build scalable infrastructure and customer-facing solutions at Zoro, drawing on LaunchOps, whose Go live-quiz service stays in sync across two copies. | none | PASS | snap_v349a_6: FAIL -> PASS |
| alml_engineer | fraud, goingonce, ripple | fraud | goingonce > ripple > fraud | High | none | Python, SQL, PostgreSQL | I want to optimize models for latency, accuracy, and scalability in real-world applications on your team, building on my fraud model's edge-type ablation. | none | PASS | snap_v349a_6: FAIL -> PASS |
| doordash_mdx | ledgerflow, ripple, tailor_pipeline | ripple | ledgerflow > ripple > tailor_pipeline | Medium | observability | Python, Java, SQL, PostgreSQL, MySQL | I want to build ML infrastructure in production including feature engineering and feature stores at DoorDash, drawing on my LLM engine's provider failover. | none | PASS | snap_v349a_6: FAIL -> PASS |
| figure | ledgerflow, pintos, ripple | pintos | ledgerflow > ripple > pintos | Low | graduation window | Python, C, Java, SQL, PostgreSQL | I want to integrate, debug, and validate updates on real robot hardware at Figure, building on the locking and memory-access checks I wrote in C for Pintos. | none | PASS | snap_v349a_6: FAIL -> PASS |
| elevenlabs | launchops, ledgerflow, ripple | launchops | ledgerflow > ripple > launchops | High | none | Python, Java, Go, SQL, PostgreSQL, MySQL | I want to design and build generic resource and permissioning services at ElevenLabs, drawing on LaunchOps, where every onboarding task has an owner and prerequisites the server enforces. | none | PASS | snap_v349a_6: FAIL -> PASS |
| macys | launchops, ledgerflow, pintos | ledgerflow | ledgerflow > pintos > launchops | Low | iOS | Java, Python, JavaScript, SQL, C, Go, PostgreSQL, MySQL | I want to build dependable, well-tested software with the team at Macy's, drawing on LedgerFlow, where a GitHub Actions CI workflow runs every automated test. | none | PASS | snap_v349a_6: FAIL -> PASS |
| audible | launchops, ledgerflow, ripple | ledgerflow | ledgerflow > ripple > launchops | High | none | SQL, Python, Java, Go, PostgreSQL, NoSQL, MongoDB, MySQL | I want to write maintainable and scalable code for software components at Audible, Inc., building on LedgerFlow, where a GitHub Actions CI workflow runs every automated test. | none | PASS | - |

## History

| Posting | baseline_v348c | snap_v349a_1 | snap_v349a_2 | snap_v349a_3 | snap_v349a_4 | snap_v349a_5 | snap_v349a_6 | snap_v349a_7 | snap_v349a_8 | snap_v349a_9 | snap_v349a_10 | snap_v349a_7b |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| akamai_se | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | PASS | PASS | PASS | PASS |
| ebsco_sde1 | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL |
| giga_swe | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS | PASS |
| meritore_jpc | FAIL | FAIL | FAIL | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| ust_software_engineer | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
| zoro_fullstack | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS | PASS |
| alml_engineer | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS | PASS |
| doordash_mdx | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS | PASS |
| figure | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS | PASS |
| elevenlabs | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS | PASS |
| macys | FAIL | FAIL | FAIL | FAIL | FAIL | FAIL | PASS | PASS | PASS | PASS | PASS | PASS |
| audible | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS |
