# Resume pipeline v3.4.8a: notes

Built 2026-10-19 from Resume_Pipeline_3_4_7c.zip. LOW-RISK build: on all 124 fixtures the resume .tex, the letter .txt
and tracker_row.json are byte-identical to v3.4.7c. Three report-level changes, each behind its own master.json
`v347_flags` entry (default true): **O** `outreach_v348` (new LinkedIn outreach block and notes), **E**
`employer_phrasings_v348` (more employer-statement phrasings, Notes only) and **H** `hook_fallback_v348` (the hook check
uses the role summary on postings with no responsibility lines). Every changed output line is in DIFF_REPORT_v348a.md;
the code change is in CHANGES.md.

## What Jay needs to do

1. **Sources: re-upload 3 of the 7 files.** Changed: `resume_pipeline_v3_2.py`, `master.json` (three new flags, the
   outreach domain map and note rule, the new md pointer), `Master_Resume_Context_LEAN_CURRENT_v3_2.md` (new section
   0-v348a). Unchanged: `bullet_bank.json`, `Resume_Template_CURRENT.tex`, `plan_template.json`, `bank_check.py`.
   Uploading all 7 is fine.
2. **Project instructions: paste the new `2_PROJECT_INSTRUCTIONS_paste.txt`** (7,551 characters; limit 7,600). Changed:
   version, step h ("Outreach: print report.json outreach.linkedin.block_md exactly (markdown links; each note in its own
   text block). Jay sends the notes."), the hook line ("... copy 4+ consecutive words from the posting's role or team text
   (no responsibilities listed: its role summary)."), the hash lock, and three trims to make room: the example list after "report.json notes", "Never match on the file name
   alone." (the line before it already requires Company AND Role to match exactly), and "Cursor / GitHub Copilot show
   only when the posting names them" from the SCRIPT-ENFORCED list (the script still enforces it; nothing in the plan can
   add them).
3. **Tracker sheet: nothing new.**
4. Optional: send `5_judged_packages/Judge_Batch_v3_4_8a.md` to the judge (resumes and letters are the 7c ones).

## Hash lock

| File | sha256 |
|---|---|
| resume_pipeline_v3_2.py | ebbb295c… (full value in the instructions) |
| master.json | 2f6d01c7… |
| bullet_bank.json | d56f0743… (unchanged) |
| Resume_Template_CURRENT.tex | 1309898b… (unchanged) |
| Master_Resume_Context_LEAN_CURRENT_v3_2.md | 8e63f1e0… |
| plan_template.json | 4358f1e0… (unchanged) |
| bank_check.py | 81b28185… (unchanged) |

## Acceptance

| Check | Result |
|---|---|
| Baseline | `3_validation/baseline_v347c/`: all 124 fixtures on the unmodified 7c Sources, saved before any change |
| Determinism (7c code) | IDENTICAL: two 7c runs |
| Predictions | `predict_v348a.py` (restates the three rules, imports only the unmodified 7c parser) wrote `predicted_changes_v348a.json` from the baseline before the code changed: O on 122 fixtures, E on 10, H flips on 11 |
| Diff gate | **PASS** (`diff_gate_v348a.py`): 4,119 changed lines in 124 fixtures, 0 unpredicted on the 53 originals and 20 holdouts, 0 unjustified elsewhere, 0 predicted-but-unchanged, 0 gate-guard failures. The only line not predicted in advance is the version label on the two stop reports (fonzi, cisco_no_title), listed as "justified" exactly as every earlier gate listed it |
| Gate guard | G1 resume .tex, letter .txt, tracker_row.json raw-byte identical on all 124; G2 report.json changes only in outreach, hiring_identity_v347 and the hook-specificity fields (no employer Notes line was added anywhere); G3 hook verdicts change only False -> True on predicted fixtures; G4 all 488 notes (122 fixtures x 4) pass the O2 validator and every block_md has the O1 format |
| All new flags off | IDENTICAL to baseline_v347c on all 124 fixtures (version label only on the two stops) |
| Determinism (8a code) | IDENTICAL: two full 8a runs |
| Fixtures | 124: 122 pass + 2 expected stops (fonzi, cisco_no_title) |
| score_all | 10.00 / 10.00 on v340_original (53), v341_tune (36), v342_new (6), v343_new (2), v344_new (2), v345_new (1) and now v347_new (4): zoro letter 9.50 -> 10.00. No score fell |
| Holdouts (20, never tuned) | resume 9.85, letter 9.97, unchanged; below 9.5: acme_cloud, twitch, linkedin_ai (as before) |
| audit_v344 | PASS: 122 built, 11 fallback closings (9.0%), longest closing 30 words, longest letter 200 words |
| bank_check | 113/113 ok, 10/10 Experience variants ok |
| selftests | all pass: v341 (28), v342 (26, plus the 6 old SKIP lines), v343 (37), v344 (55), v345 (59), v346 (54), v347a (65), v347b (94), v347c (39) and the new **selftest_v348a (163 checks)**: validator incl. 19 deliberately bad notes that must FAIL, every template x every domain x with / without company, strategy and variety, the domain map against master evidence, block_md format, 15 employer true / false hits, hook fallback, zoro / ust end to end, 3 flags-off builds equal to baseline_v347c, instructions and hash lock. Old selftests: version checks accept v3.4.8a; v347a / v347b / v347c turn the new flags off where they compare with an older baseline |
| Names defined more than once | 61 (unchanged) |

## O. Outreach: what changed

- `report.json outreach.linkedin.block_md` (and outreach.json) is the block the model prints: a Company / Job post line
  of markdown links (`Req: [search](...)` only when a requisition ID exists), then four numbered sections, each with one
  people-search link and its note alone in a ```text block, so each note gets a copy button.
- Four notes: hiring manager, software engineers (new), technical recruiters, UB alumni. Three templates per audience
  (your eight, lightly polished, plus a third each), picked by a hash of company + role, so a rerun is identical and other
  companies get other wording. All 12 templates were used across the 122 fixtures (32 to 52 times each).
- Domain phrase by role family (`master.json outreach.domain_phrases_v348`, each with the master evidence it rests on):
  backend "backend services and APIs", fullstack "full-stack web apps", ai_llm "LLM agents and evaluation",
  data_science_ml "machine learning models", data_engineering "data pipelines", devops_cloud "cloud deployments and
  monitoring", systems "systems programming in C", sdet_quality "testing and CI", support_sustaining "production web
  apps and monitoring" (not in your list; from the heartbeat dashboard and the containerized production projects),
  general_swe "backend systems".
- The plain `outreach.linkedin.block` stays for compatibility, now carrying the four new notes. 9 fixtures say "the open
  role" because their title has a digit or would push a note past 300 characters (applied_mat, ga_asi, garmin,
  google_sre, macys, meridian_sw, nvidia_infra, pinterest, serco_snow). The longest note is exactly 300 characters.

## Outreach before and after (the four real postings)

### zoro_fullstack

**Before (v3.4.7c, `outreach.linkedin.block`):**

```text
Company LinkedIn: not found
LinkedIn job: not found | Job search: https://www.linkedin.com/jobs/search/?keywords=Software%20Developer-%20Full%20Stack%20Zoro
People: Manager https://www.linkedin.com/search/results/people/?keywords=Zoro%20full%20stack%20engineering%20manager | Team engineers https://www.linkedin.com/search/results/people/?keywords=Zoro%20full%20stack%20engineer | Recruiters https://www.linkedin.com/search/results/people/?keywords=Zoro%20technical%20recruiter | UB alumni https://www.linkedin.com/search/results/people/?keywords=Zoro%20University%20at%20Buffalo
Note to hiring manager (239 chars): Hi {Name}, I applied for the Software Developer- Full Stack role at Zoro. I built LaunchOps, a Django and React onboarding app with a 20-task workflow for HR, IT, and managers. I'd value connecting and being considered for your team. – Jay
Note to UB alum (198 chars): Hi {Name}, fellow UB CS grad student here. I applied for the Software Developer- Full Stack role at Zoro. Would you be open to a short chat so I can get your advice on the team? Thanks, Jay
Note to recruiter (230 chars): Hi {Name}, I applied for the Software Developer- Full Stack role at Zoro. I built LaunchOps, a Django and React onboarding app with a 20-task workflow for HR, IT, and managers. Happy to share anything that helps your review. – Jay
```

**After (v3.4.8a, `outreach.linkedin.block_md`, printed as markdown; templates hiring_manager.B, engineer.B, recruiter.B, ub_alum.C; domain "full-stack web apps"):**

````markdown
Company: [Zoro on LinkedIn](https://www.linkedin.com/search/results/companies/?keywords=Zoro) · Job post: [search](https://www.linkedin.com/jobs/search/?keywords=Software%20Developer-%20Full%20Stack%20Zoro)

### 1. Hiring manager
[Find hiring managers at Zoro](https://www.linkedin.com/search/results/people/?keywords=Zoro%20full%20stack%20engineering%20manager)
```text
Hi {Name}, I applied for the Software Developer Full Stack role at Zoro and wanted to say hello. I'm a CS grad student at UB with startup experience, and most of my recent focus has been full-stack web apps. Glad to connect either way. Best, Jay
```

### 2. Software engineers / team members
[Find engineers at Zoro](https://www.linkedin.com/search/results/people/?keywords=Zoro%20full%20stack%20engineer)
```text
Hi {Name}, I came across your profile while looking into engineering at Zoro. I work mostly on full-stack web apps and I'm curious how your team approaches it. Happy to connect if you're open to it. Best, Jay
```

### 3. Technical recruiters
[Find technical recruiters at Zoro](https://www.linkedin.com/search/results/people/?keywords=Zoro%20technical%20recruiter)
```text
Hi {Name}, quick hello. I put in an application for the Software Developer Full Stack role at Zoro. I'm a CS grad student at UB with startup experience, mostly focused on full-stack web apps, and I'd be glad to connect. Best, Jay
```

### 4. University at Buffalo alumni
[Find UB alumni at Zoro](https://www.linkedin.com/search/results/people/?keywords=Zoro%20University%20at%20Buffalo)
```text
Hi {Name}, I'm doing my MS in CS at UB and saw that you went from UB to Zoro. I'd be curious how you found your way there and what a normal week looks like for you. Open to a short chat sometime? Best, Jay
```
````

### alml_engineer

**Before (v3.4.7c, `outreach.linkedin.block`):**

```text
Company: not stated in the posting, so the people searches leave the company out
Company LinkedIn: not found
LinkedIn job: not found | Job search: https://www.linkedin.com/jobs/search/?keywords=AL/ML%20Engineer
People: Manager https://www.linkedin.com/search/results/people/?keywords=machine%20learning%20manager | Team engineers https://www.linkedin.com/search/results/people/?keywords=machine%20learning%20engineer | Recruiters https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter | UB alumni https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo
Note to hiring manager (215 chars): Hi {Name}, I applied for the AL/ML Engineer role on your team. My GraphSAGE fraud model reached 0.9259 AUC-ROC against about 0.858 for a plain baseline. I'd value connecting and being considered for your team. – Jay
Note to UB alum (187 chars): Hi {Name}, fellow UB CS grad student here. I applied for the AL/ML Engineer role on your team. Would you be open to a short chat so I can get your advice on the team? Thanks, Jay
Note to recruiter (206 chars): Hi {Name}, I applied for the AL/ML Engineer role on your team. My GraphSAGE fraud model reached 0.9259 AUC-ROC against about 0.858 for a plain baseline. Happy to share anything that helps your review. – Jay
```

**After (v3.4.8a, `outreach.linkedin.block_md`, printed as markdown; templates hiring_manager.B, engineer.C, recruiter.C, ub_alum.A; domain "machine learning models"):**

````markdown
Company: not stated in the posting · Job post: [search](https://www.linkedin.com/jobs/search/?keywords=AL/ML%20Engineer)

### 1. Hiring manager
[Find hiring managers](https://www.linkedin.com/search/results/people/?keywords=machine%20learning%20manager)
```text
Hi {Name}, I applied for the AL/ML Engineer role on your team and wanted to say hello. I'm a CS grad student at UB with startup experience, and most of my recent focus has been machine learning models. Glad to connect either way. Best, Jay
```

### 2. Software engineers / team members
[Find engineers](https://www.linkedin.com/search/results/people/?keywords=machine%20learning%20engineer)
```text
Hi {Name}, I'm a grad student at UB and have spent a lot of my time on machine learning models. I'd love to connect and hear what you're working on and what you like most about your team. Thanks, Jay
```

### 3. Technical recruiters
[Find technical recruiters](https://www.linkedin.com/search/results/people/?keywords=technical%20recruiter)
```text
Hi {Name}, I wanted to say hello since I recently applied for the AL/ML Engineer role on your team. I'm finishing my master's in CS at UB and have startup and internship experience. Lately I've been focused on machine learning models. Happy to share more anytime. Best, Jay
```

### 4. University at Buffalo alumni
[Find UB alumni](https://www.linkedin.com/search/results/people/?keywords=University%20at%20Buffalo)
```text
Hi {Name}, I'm a CS grad student at UB and came across your profile while reading about your team. I'd love to hear how you made the jump from UB and what your work looks like now. Would you be open to a quick chat sometime? Thanks, Jay
```
````

### ust_software_engineer

**Before (v3.4.7c, `outreach.linkedin.block`):**

```text
Company LinkedIn: not found
LinkedIn job: not found | Job search: https://www.linkedin.com/jobs/search/?keywords=Software%20Engineer%20UST | Req search: https://www.linkedin.com/jobs/search/?keywords=66812%20UST
People: Manager https://www.linkedin.com/search/results/people/?keywords=UST%20software%20engineering%20manager | Team engineers https://www.linkedin.com/search/results/people/?keywords=UST%20software%20engineer | Recruiters https://www.linkedin.com/search/results/people/?keywords=UST%20technical%20recruiter | UB alumni https://www.linkedin.com/search/results/people/?keywords=UST%20University%20at%20Buffalo
Note to hiring manager (224 chars): Hi {Name}, I applied for the Software Engineer role at UST. My LedgerFlow ledger handled 200 simultaneous payments on an account funded for 50 with no overdraft. I'd value connecting and being considered for your team. – Jay
Note to UB alum (184 chars): Hi {Name}, fellow UB CS grad student here. I applied for the Software Engineer role at UST. Would you be open to a short chat so I can get your advice on the team? Thanks, Jay
Note to recruiter (227 chars): Hi {Name}, I applied for the Software Engineer role at UST (req 66812). My LedgerFlow ledger handled 200 simultaneous payments on an account funded for 50 with no overdraft. Happy to share anything that helps your review. – Jay
```

**After (v3.4.8a, `outreach.linkedin.block_md`, printed as markdown; templates hiring_manager.A, engineer.B, recruiter.C, ub_alum.A; domain "backend services and APIs"):**

````markdown
Company: [UST on LinkedIn](https://www.linkedin.com/search/results/companies/?keywords=UST) · Job post: [search](https://www.linkedin.com/jobs/search/?keywords=Software%20Engineer%20UST) · Req: [search](https://www.linkedin.com/jobs/search/?keywords=66812%20UST)

### 1. Hiring manager
[Find hiring managers at UST](https://www.linkedin.com/search/results/people/?keywords=UST%20software%20engineering%20manager)
```text
Hi {Name}, I recently applied for the Software Engineer role on your team. I'm finishing my MS in CS at UB, with startup and internship experience, and lately I've focused on backend services and APIs. Glad to connect and share more if it helps. Thanks, Jay
```

### 2. Software engineers / team members
[Find engineers at UST](https://www.linkedin.com/search/results/people/?keywords=UST%20software%20engineer)
```text
Hi {Name}, I came across your profile while looking into engineering at UST. I work mostly on backend services and APIs and I'm curious how your team approaches it. Happy to connect if you're open to it. Best, Jay
```

### 3. Technical recruiters
[Find technical recruiters at UST](https://www.linkedin.com/search/results/people/?keywords=UST%20technical%20recruiter)
```text
Hi {Name}, I wanted to say hello since I recently applied for the Software Engineer role at UST. I'm finishing my master's in CS at UB and have startup and internship experience. Lately I've been focused on backend services and APIs. Happy to share more anytime. Best, Jay
```

### 4. University at Buffalo alumni
[Find UB alumni at UST](https://www.linkedin.com/search/results/people/?keywords=UST%20University%20at%20Buffalo)
```text
Hi {Name}, I'm a CS grad student at UB and came across your profile while reading about UST. I'd love to hear how you made the jump from UB and what your work there looks like. Would you be open to a quick chat sometime? Thanks, Jay
```
````

### meritore_capgemini

**Before (v3.4.7c, `outreach.linkedin.block`):**

```text
Company LinkedIn: not found
LinkedIn job: not found | Job search: https://www.linkedin.com/jobs/search/?keywords=Software%20Engineer%20Meritore%20Technologies%20LLC | Req search: https://www.linkedin.com/jobs/search/?keywords=12239%20Meritore%20Technologies%20LLC
People: Manager https://www.linkedin.com/search/results/people/?keywords=Meritore%20Technologies%20LLC%20software%20engineering%20manager | Team engineers https://www.linkedin.com/search/results/people/?keywords=Meritore%20Technologies%20LLC%20software%20engineer | Recruiters https://www.linkedin.com/search/results/people/?keywords=Meritore%20Technologies%20LLC%20technical%20recruiter | UB alumni https://www.linkedin.com/search/results/people/?keywords=Meritore%20Technologies%20LLC%20University%20at%20Buffalo
Note to hiring manager (247 chars): Hi {Name}, I applied for the Software Engineer role at Meritore Technologies LLC. Claude Code helped me write my AI agent RIPPLE, and I checked its output with RIPPLE's 241-test suite. I'd value connecting and being considered for your team. – Jay
Note to UB alum (206 chars): Hi {Name}, fellow UB CS grad student here. I applied for the Software Engineer role at Meritore Technologies LLC. Would you be open to a short chat so I can get your advice on the team? Thanks, Jay
Note to recruiter (250 chars): Hi {Name}, I applied for the Software Engineer role at Meritore Technologies LLC (req 12239). Claude Code helped me write my AI agent RIPPLE, and I checked its output with RIPPLE's 241-test suite. Happy to share anything that helps your review. – Jay
```

**After (v3.4.8a, `outreach.linkedin.block_md`, printed as markdown; templates hiring_manager.B, engineer.B, recruiter.B, ub_alum.A; domain "backend systems"):**

````markdown
Company: [Meritore Technologies LLC on LinkedIn](https://www.linkedin.com/search/results/companies/?keywords=Meritore%20Technologies%20LLC) · Job post: [search](https://www.linkedin.com/jobs/search/?keywords=Software%20Engineer%20Meritore%20Technologies%20LLC) · Req: [search](https://www.linkedin.com/jobs/search/?keywords=12239%20Meritore%20Technologies%20LLC)

### 1. Hiring manager
[Find hiring managers at Meritore Technologies LLC](https://www.linkedin.com/search/results/people/?keywords=Meritore%20Technologies%20LLC%20software%20engineering%20manager)
```text
Hi {Name}, I applied for the Software Engineer role at Meritore Technologies LLC and wanted to say hello. I'm a CS grad student at UB with startup experience, and most of my recent focus has been backend systems. Glad to connect either way. Best, Jay
```

### 2. Software engineers / team members
[Find engineers at Meritore Technologies LLC](https://www.linkedin.com/search/results/people/?keywords=Meritore%20Technologies%20LLC%20software%20engineer)
```text
Hi {Name}, I came across your profile while looking into engineering at Meritore Technologies LLC. I work mostly on backend systems and I'm curious how your team approaches it. Happy to connect if you're open to it. Best, Jay
```

### 3. Technical recruiters
[Find technical recruiters at Meritore Technologies LLC](https://www.linkedin.com/search/results/people/?keywords=Meritore%20Technologies%20LLC%20technical%20recruiter)
```text
Hi {Name}, quick hello. I put in an application for the Software Engineer role at Meritore Technologies LLC. I'm a CS grad student at UB with startup experience, mostly focused on backend systems, and I'd be glad to connect. Best, Jay
```

### 4. University at Buffalo alumni
[Find UB alumni at Meritore Technologies LLC](https://www.linkedin.com/search/results/people/?keywords=Meritore%20Technologies%20LLC%20University%20at%20Buffalo)
```text
Hi {Name}, I'm a CS grad student at UB and came across your profile while reading about Meritore Technologies LLC. I'd love to hear how you made the jump from UB and what your work there looks like. Would you be open to a quick chat sometime? Thanks, Jay
```
````


## E. Employer statements recorded (10 fixtures; no Notes line anywhere, since each matches application.company)

| Fixture | Statements before | Statements after | Employer | application.company | Notes line |
|---|---|---|---|---|---|
| black_canyon | (none) | ['Black Canyon Consulting'] | Black Canyon Consulting | Black Canyon Consulting | no |
| brillio | (none) | ['Brillio'] | Brillio | Brillio | no |
| cardinal | (none) | ['Cardinal Insurance'] | Cardinal Insurance | Cardinal Insurance | no |
| ironvale | (none) | ['Ironvale Systems'] | Ironvale Systems | Ironvale Systems | no |
| ixl | (none) | ['IXL Learning'] | IXL Learning | IXL Learning | no |
| raydar_backend | (none) | ['Raydar'] | Raydar | Raydar | no |
| raydar_swe | (none) | ['Raydar'] | Raydar | Raydar | no |
| rockstar | (none) | ['Rockstar'] | Rockstar | Rockstar | no |
| serco_sw | (none) | ['Serco North America'] | Serco North America | Serco | no |
| ust_software_engineer | (none) | ['UST'] | UST | UST | no |

False hits guarded: "We are seeking", "The team is looking for", "Our client is seeking", "Our partner is looking for"
(jobgether), "The company is seeking" (rockstar) and similar are not employer statements; selftest_v348a checks 15 true and
false hits.

## H. Every fixture whose hook verdict changed (11, all False -> True)

| Fixture | Group | Scored (hook_test) | hook_specific | Role text | Shared words | Role summary (first 140 chars) |
|---|---|---|---|---|---|---|
| audit07 | v340 | no | False -> True | role_summary | automation, cloud, collaboration, developers, internal, platforms, scripting, troubleshooting | COPPERPEAK OPERATES INTERNAL PLATFORMS THAT HELP PRODUCT TEAMS RELEASE FEATURES. THE ROLE INVOLVES AUTOMATION, CLOUD TROUBLESHOOTING, SCRIPT |
| bae | v341 | no | False -> True | role_summary | coding, debugging, integrating, regression, requirement, testing, well | We are looking for 2027 entry level candidates interested in joining our ES Defense software engineering team in NH/MA. Qualified candidates |
| birthmodel | v340 | no | False -> True | role_summary | clinical, delivery, features, labor, teams, units, used | We're looking for a recent graduate or early-career software engineer to join our engineering team. You'll work across the stack, contributi |
| cobalt | v341 | no | False -> True | role_summary | analytics, apis, behind, dashboards, data, services | Cobalt Analytics is hiring a Junior Backend Engineer to build the APIs and data services behind our analytics dashboards. |
| fidelity | v340 | no | False -> True | role_summary | autonomous, building, cross-functional, desktop, end-to-end, experience, features, part, teams, user | Our teams build and contribute to Fidelity's digital presence. As a desktop developer, you will help us build the desktop user experience an |
| harvey | v341 | no | False -> True | role_summary | automation, code, document, features, intelligence, production, retrieval, spanning, workflow | The Software Engineer, New Grad joins Harvey's Engineering team, working alongside experienced engineers to build the AI-powered systems tha |
| ironvale | v341 | no | False -> True | role_summary | ground, mission, satellite, test, tools | Ironvale Systems is seeking an Associate Software Engineer to develop mission software and test tools for satellite ground systems. |
| northwind | v341 | no | False -> True | role_summary | features, internal, ship, small, support, tools, weekly | Northwind Labs builds internal tools that help support teams resolve customer issues faster. Requirements: Python, Django or Flask, REST API |
| research_phd | v341 | no | False -> True | role_summary | discovery, large, models, scientific | We build and train large models for scientific discovery. |
| rockstar | v340 | no | False -> True | role_summary | problems | Rockstar is recruiting for a health insurance technology startup that is modernizing and automating the benefits experience. The company is  |
| zoro_fullstack | v347 | yes | False -> True | role_summary | customer, data, zoro | Zoro is hiring a Full Stack Software Developer to build scalable infrastructure and customer-facing solutions that support product data and  |

Only zoro is a scored hook fixture (`hook_test`), so it is the only score change (letter 9.5 -> 10.0). The other ten are
unscored; their report.json now says the hook is specific and adds `hook_specific_basis_v348`. No verdict went the
other way, and every fixture whose verdict did not flip reports exactly what it did in 7c. Rockstar flips on one shared
word ("problems", from "own problems end to end" in its role paragraph); it is listed so you can judge it.

## Assumptions

- **300 characters counts the note as written, with "{Name}" in it** (as filled by the script). A long first name
  adds a few characters when you send it; notes run from 191 to 300 characters (median 237; 90% are 282 or less).
- **"Job post: [view](url) or [search](url)"**: [view] when the plan has a matching LinkedIn job URL, otherwise
  [search]. The company link is the LinkedIn company page when known, else a LinkedIn company search. Blank lines
  separate the sections so the headings render in any markdown viewer.
- **Templates never tie {domain} to one employer** ("I enjoy working on ...", "lately I've focused on ..."), because
  some domains (systems programming in C, testing and CI, LLM agents) come from coursework and projects, not the startup
  or internships. Hiring-manager and recruiter notes say "startup and internship experience" separately.
- **Fallback order** for a note that fails the validator: "the open role", then no company ("your team"), then the next
  template. A company named like a project (e.g. "Ripple") or containing a digit drops out of the note this way.
- **The old `outreach.message` (three-sentence message) and `contact_titles` are unchanged**: the instructions never
  print them and the request listed only the LinkedIn block.
- **E guard**: <Org> must start a sentence and be capitalized; the first word may not be We / The / Our / This / Your /
  Company / Client / Team / Partner and the like. New statements are added after the 7a ones, so a 7a employer keeps
  first place. A "(BCC)" acronym or a ", developer of ...," appositive may sit between the name and the verb.
- **H**: "no responsibility lines" means the 7c responsibility parser finds none (the same test A6 reports). The role
  summary is, in order: a "<Org> is hiring a ... to ..." sentence; the paragraph under "The Role", "About the role",
  "About this role", "Role overview", "Role summary", "Position summary", "Job summary", "The position" or "About the
  position"; the first paragraph of 12+ words that talks about the job ("this role", "you will", "we are looking",
  "is seeking", "join our" ...). Title normalization applies to every posting; it flipped nothing on its own.
- **Report fields**: a flipped hook adds `cover_letter.hook_specific_basis_v348` (source, summary, shared words); a
  hook that fails against the role summary says so in the A6 reason. Both are hook-specificity fields Jay allowed.
- **Old selftests**: version checks accept v3.4.8a; selftest_v347a turns hook_fallback_v348 off for its "hook verdict
  unchanged since v3.4.6" check (and accepts zoro's new specific verdict end to end); selftest_v347b / v347c turn the
  three new flags off where they compare a build with baseline_v347a / v347b (outreach differs by design). bullet_bank.json and the template are not
  edited; `tools/` stays out of the zip.
