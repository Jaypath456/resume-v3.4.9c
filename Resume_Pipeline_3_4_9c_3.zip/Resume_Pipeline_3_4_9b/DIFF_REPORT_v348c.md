# DIFF_REPORT v3.4.8c

Built from v3.4.8b one fix at a time (T, W, F, S, J, C). Each section below compares the snapshot before a fix with the
snapshot after it (all in `3_validation/`), so every changed line is attributed to exactly one fix id. Each table row is
one changed line: fixture, group, file, fix id, before, after. All six gates PASS with 0 unpredicted changes on the 53
originals and the 20 holdouts and 0 guard failures. With all eight new flags off every fixture is identical to
`baseline_v348b` (the version label aside, see section T), and a second full run is identical to `snap_v348c_C`.

## Per-fix count of changed fixtures

| Fix | Flag(s) | Before -> after | Changed lines | Changed fixtures | Of which beyond the version label |
|---|---|---|---|---|---|
| T | start_date_parse_v348 | baseline_v348b -> snap_v348c_T | 15 | 4 | 2 (cdi, tiktok_appsec) |
| W | bank_wording_v348 | snap_v348c_T -> snap_v348c_W | 154 | 63 | 63 |
| F | fleet_language_model_v348, fleet_repick_v348 | snap_v348c_W -> snap_v348c_F | 250 | 17 | 17 |
| S | skills_lines_v348 | snap_v348c_F -> snap_v348c_S | 1612 | 99 | 99 |
| J | heading_move_v348 | snap_v348c_S -> snap_v348c_J | 54 | 11 | 11 |
| C | closing_proof_map_v348, closing_specific_v348 | snap_v348c_J -> snap_v348c_C | 168 | 8 | 8 |

The version label ("v3.4.8b" -> "v3.4.8c") shows only on the two stop fixtures (fonzi, cisco_no_title), counted under T.
Amendments (predictions untouched): S-A1 (flowgen, 1 line), J-A1 (meridian_sw, 4 lines).

## Fix T

Before: `baseline_v348b`. After: `snap_v348c_T` (every fix up to T on). Predictions: `predicted_changes_v348c_T.json`.

Result: **PASS**. 15 changed lines in 4 fixtures (2 with output changes beyond the version label); 0 unpredicted on v340_original / holdout; 0 unpredicted and unjustified elsewhere; 0 gate-guard failures; 0 lines matched only a documented amendment; longest letter 200 words.

Guards:

- T1 resume, letter and outreach identical: **held**
- T2 tracker: only the Blockers column; Fit identical everywhere: **held**
- T3 report: Fit identical; the only added blocker is a start_date Timing note (never a skip): **held**

Changed fixtures (2): cdi, tiktok_appsec

| Fixture | Group | File | Fix | Before | After |
|---|---|---|---|---|---|
| cdi | v340_original | report | T | `eligibility_blockers: []` | `eligibility_blockers[0].type: "start_date"` |
| cdi | v340_original | report | T | (none) | `eligibility_blockers[0].requirement: "- Target start date: 12/01/2026"` |
| cdi | v340_original | report | T | (none) | `eligibility_blockers[0].reason: "Timing check: the posting mentions a start before February 2027. Graduates December 2026; available to start February 2027 (subject to OPT/EAD approval)."` |
| cdi | v340_original | report | T | `notes[0]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): TypeScript, Next.js."` | `notes[0]: "start_date: Timing check: the posting mentions a start before February 2027. Graduates December 2026; available to start February 2027 (subject to OPT/EAD approval)."` |
| cdi | v340_original | report | T | (none) | `notes[1]: "Stack gaps (named in the posting but not hard requirements, so Fit is not capped): TypeScript, Next.js."` |
| cdi | v340_original | report | T | `tracker_row.Blockers: ""` | `tracker_row.Blockers: "start date"` |
| cdi | v340_original | tracker | T | `Blockers: ""` | `Blockers: "start date"` |
| cisco_no_title | v343_new | report | T (justified: PIPELINE_VERSION label on a stop report (v3.4.8b -> v3.4 | `pipeline_version: "v3.4.8b"` | `pipeline_version: "v3.4.8c"` |
| fonzi | v341_tune | report | T (justified: PIPELINE_VERSION label on a stop report (v3.4.8b -> v3.4 | `pipeline_version: "v3.4.8b"` | `pipeline_version: "v3.4.8c"` |
| tiktok_appsec | v340_original | report | T | `eligibility_blockers: []` | `eligibility_blockers[0].type: "start_date"` |
| tiktok_appsec | v340_original | report | T | (none) | `eligibility_blockers[0].requirement: "Application Security Engineer Graduate (TikTok) - 2026 Start (BS/MS)"` |
| tiktok_appsec | v340_original | report | T | (none) | `eligibility_blockers[0].reason: "Timing check: the posting mentions a start before February 2027. Graduates December 2026; available to start February 2027 (subject to OPT/EAD approval)."` |
| tiktok_appsec | v340_original | report | T | `notes: []` | `notes[0]: "start_date: Timing check: the posting mentions a start before February 2027. Graduates December 2026; available to start February 2027 (subject to OPT/EAD approval)."` |
| tiktok_appsec | v340_original | report | T | `tracker_row.Blockers: ""` | `tracker_row.Blockers: "start date"` |
| tiktok_appsec | v340_original | tracker | T | `Blockers: ""` | `Blockers: "start date"` |

## Fix W

Before: `snap_v348c_T`. After: `snap_v348c_W` (every fix up to W on). Predictions: `predicted_changes_v348c_W.json`.

Result: **PASS**. 154 changed lines in 63 fixtures (63 with output changes beyond the version label); 0 unpredicted on v340_original / holdout; 0 unpredicted and unjustified elsewhere; 0 gate-guard failures; 0 lines matched only a documented amendment; longest letter 200 words.

Guards:

- W1 resume: only project bullet lines change (headings, Experience, Skills, Education, order identical): **held**
- W2 every changed bullet is a new bank_wording_v348 variant or a re-pick inside a project that took one: **held**
- W3 letter, tracker and outreach identical: **held**

Changed fixtures (63): allergan, amplify, amplitude, applied_mat, arclight, assetwatch, atoms, audible, audible_md, audit01, audit02, audit03, audit04, audit06, audit07, audit08, audit09, audit10, audit12, birthmodel, booz_allen, brillio, cdi, chewy, corvex, doordash, doordash_mdx, engen, fanatics, fidelity, flowgen, ga_asi, google_sre, helix, impact, inspire11, instalily, jobgether, klaviyo, linkedin, linkedin_ai, lumen, mastercard, meridian_sw, meritore_capgemini, monti, nimble, northbeam, novita, nvidia_ai_cloud, nvidia_devtech, pocketly, qa_sdet, quora, robot_sdet, serco_snow, serco_sw, stratus, swisslog, twitch_se1, ust_software_engineer, vindexa, wpp

| Fixture | Group | File | Fix | Before | After |
|---|---|---|---|---|---|
| allergan | v340_original | resume_tex | W | `  \item Validated every finished code change with a post-change check that reads its Git diff and flags unexpected edits, missing tests, and calling code that was left out of date by the change.` | `  \item Validated every finished code change with RIPPLE's own Git-diff check, which runs after the change is made, reads its Git diff, and flags unexpected edits, missing tests, and stale callers.` |
| allergan | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| allergan | v340_original | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.git.c"` |
| allergan | v340_original | report | W | (none) | `bank_wording_v348c.replaces.ripple.git.c: "ripple.git.b"` |
| amplify | v340_original | report | W | `verify_quotes_v345.unquoted[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc"` | `verify_quotes_v345.unquoted[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc"` |
| amplify | v340_original | report | W | `internal_changes[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `internal_changes[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| amplitude | holdout | report | W | `verify_quotes_v345.unquoted[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc"` | `verify_quotes_v345.unquoted[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc"` |
| amplitude | holdout | report | W | `internal_changes[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `internal_changes[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| applied_mat | v341_tune | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| arclight | v341_tune | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| assetwatch | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| atoms | v340_original | resume_tex | W | `  \item Benchmarked agent cost at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` | `  \item Measured agent usage at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` |
| atoms | v340_original | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| atoms | v340_original | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.eff.b"` |
| atoms | v340_original | report | W | (none) | `bank_wording_v348c.replaces.ripple.eff.b: "ripple.eff.a"` |
| audible | v343_new | resume_tex | W | `  \item Wrote RIPPLE with Claude Code as a coding assistant, checking the code that Claude Code generated by running RIPPLE's 241-test suite and testing edge cases across real repositories.` | `  \item Wrote RIPPLE with Claude Code as a coding assistant, checking its output with RIPPLE's 241-test suite and testing how the agent handles edge cases across the real code repositories it analyzes.` |
| audible | v343_new | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.cc.d"` |
| audible | v343_new | report | W | (none) | `bank_wording_v348c.replaces.ripple.cc.d: "ripple.cc.a"` |
| audible_md | v344_new | resume_tex | W | `  \item Wrote RIPPLE with Claude Code as a coding assistant, checking the code that Claude Code generated by running RIPPLE's 241-test suite and testing edge cases across real repositories.` | `  \item Wrote RIPPLE with Claude Code as a coding assistant, checking its output with RIPPLE's 241-test suite and testing how the agent handles edge cases across the real code repositories it analyzes.` |
| audible_md | v344_new | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.cc.d"` |
| audible_md | v344_new | report | W | (none) | `bank_wording_v348c.replaces.ripple.cc.d: "ripple.cc.a"` |
| audit01 | v340_original | resume_tex | W | `  \item Validated every finished code change with a post-change check that reads its Git diff and flags unexpected edits, missing tests, and calling code that was left out of date by the change.` | `  \item Validated every finished code change with RIPPLE's own Git-diff check, which runs after the change is made, reads its Git diff, and flags unexpected edits, missing tests, and stale callers.` |
| audit01 | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| audit01 | v340_original | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| audit01 | v340_original | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.git.c"` |
| audit01 | v340_original | report | W | (none) | `bank_wording_v348c.replaces.ripple.git.c: "ripple.git.b"` |
| audit02 | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| audit02 | v340_original | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| audit03 | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| audit03 | v340_original | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| audit03 | v340_original | report | W | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc"` | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc"` |
| audit04 | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| audit04 | v340_original | report | W | `verify_quotes_v345.unquoted[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc"` | `verify_quotes_v345.unquoted[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc"` |
| audit04 | v340_original | report | W | `internal_changes[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `internal_changes[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| audit06 | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| audit06 | v340_original | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| audit07 | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| audit08 | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| audit09 | v340_original | resume_tex | W | `  \item Validated every finished code change with a post-change check that reads its Git diff and flags unexpected edits, missing tests, and calling code that was left out of date by the change.` | `  \item Validated every finished code change with RIPPLE's own Git-diff check, which runs after the change is made, reads its Git diff, and flags unexpected edits, missing tests, and stale callers.` |
| audit09 | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| audit09 | v340_original | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| audit09 | v340_original | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.git.c"` |
| audit09 | v340_original | report | W | (none) | `bank_wording_v348c.replaces.ripple.git.c: "ripple.git.b"` |
| audit10 | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| audit12 | v340_original | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| audit12 | v340_original | report | W | `verify_changes_v344[2].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[2].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| birthmodel | v340_original | resume_tex | W | `  \item Validated every finished code change with a post-change check that reads its Git diff and flags unexpected edits, missing tests, and calling code that was left out of date by the change.` | `  \item Validated every finished code change with RIPPLE's own Git-diff check, which runs after the change is made, reads its Git diff, and flags unexpected edits, missing tests, and stale callers.` |
| birthmodel | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| birthmodel | v340_original | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.git.c"` |
| birthmodel | v340_original | report | W | (none) | `bank_wording_v348c.replaces.ripple.git.c: "ripple.git.b"` |
| booz_allen | v341_tune | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| booz_allen | v341_tune | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| booz_allen | v341_tune | report | W | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| brillio | v340_original | report | W | `preflight_v344.skills_or_heading_only[5].bullet_evidence: "preferred: ripple.cc.a, ripple.cc.c, ripple.cc.b"` | `preflight_v344.skills_or_heading_only[5].bullet_evidence: "preferred: ripple.cc.d, ripple.cc.c, ripple.cc.b"` |
| brillio | v340_original | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| cdi | v340_original | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| cdi | v340_original | report | W | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc"` | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc"` |
| chewy | v341_tune | resume_tex | W | `  \item Validated every finished code change with a post-change check that reads its Git diff and flags unexpected edits, missing tests, and calling code that was left out of date by the change.` | `  \item Validated every finished code change with RIPPLE's own Git-diff check, which runs after the change is made, reads its Git diff, and flags unexpected edits, missing tests, and stale callers.` |
| chewy | v341_tune | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| chewy | v341_tune | report | W | `verify_quotes_v345.unquoted[0]: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b) (no"` | `verify_quotes_v345.unquoted[0]: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c) (no"` |
| chewy | v341_tune | report | W | `internal_changes[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `internal_changes[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| chewy | v341_tune | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.git.c"` |
| chewy | v341_tune | report | W | (none) | `bank_wording_v348c.replaces.ripple.git.c: "ripple.git.b"` |
| corvex | holdout | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| corvex | holdout | report | W | `verify_changes_v344[2].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[2].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| corvex | holdout | report | W | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc"` | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc"` |
| doordash | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| doordash_mdx | v342_new | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| engen | v341_tune | report | W | `preflight_v344.skills_or_heading_only[8].bullet_evidence: "preferred: ripple.cc.a, ripple.cc.c, ripple.cc.b"` | `preflight_v344.skills_or_heading_only[8].bullet_evidence: "preferred: ripple.cc.d, ripple.cc.c, ripple.cc.b"` |
| engen | v341_tune | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| fanatics | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| fidelity | v340_original | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| flowgen | v341_tune | resume_tex | W | `  \item Benchmarked agent cost at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` | `  \item Measured agent usage at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` |
| flowgen | v341_tune | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| flowgen | v341_tune | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.eff.b"` |
| flowgen | v341_tune | report | W | (none) | `bank_wording_v348c.replaces.ripple.eff.b: "ripple.eff.a"` |
| ga_asi | holdout | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| google_sre | v340_original | resume_tex | W | `  \item Benchmarked agent cost at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` | `  \item Measured agent usage at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` |
| google_sre | v340_original | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.eff.b"` |
| google_sre | v340_original | report | W | (none) | `bank_wording_v348c.replaces.ripple.eff.b: "ripple.eff.a"` |
| helix | v341_tune | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| impact | v341_tune | report | W | `verify_changes_v344[2].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[2].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| impact | v341_tune | report | W | `verify_changes_v344[3].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[3].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| impact | v341_tune | report | W | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc"` | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc"` |
| inspire11 | v340_original | report | W | `preflight_v344.skills_or_heading_only[2].bullet_evidence: "preferred: ripple.cc.a, ripple.cc.c, ripple.cc.b"` | `preflight_v344.skills_or_heading_only[2].bullet_evidence: "preferred: ripple.cc.d, ripple.cc.c, ripple.cc.b"` |
| inspire11 | v340_original | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| inspire11 | v340_original | report | W | `verify_changes_v344[3].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[3].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| inspire11 | v340_original | report | W | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| instalily | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| jobgether | v340_original | report | W | `verify_quotes_v345.unquoted[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc"` | `verify_quotes_v345.unquoted[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc"` |
| jobgether | v340_original | report | W | `internal_changes[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `internal_changes[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| klaviyo | v340_original | resume_tex | W | `  \item Benchmarked agent cost at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` | `  \item Measured agent usage at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` |
| klaviyo | v340_original | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.eff.b"` |
| klaviyo | v340_original | report | W | (none) | `bank_wording_v348c.replaces.ripple.eff.b: "ripple.eff.a"` |
| linkedin | v340_original | report | W | `preflight_v344.skills_or_heading_only[5].bullet_evidence: "preferred: ripple.cc.a, ripple.cc.c, ripple.cc.b"` | `preflight_v344.skills_or_heading_only[5].bullet_evidence: "preferred: ripple.cc.d, ripple.cc.c, ripple.cc.b"` |
| linkedin | v340_original | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| linkedin_ai | holdout | resume_tex | W | `  \item Wrote RIPPLE with Claude Code as a coding assistant, checking the code that Claude Code generated by running RIPPLE's 241-test suite and testing edge cases across real repositories.` | `  \item Wrote RIPPLE with Claude Code as a coding assistant, checking its output with RIPPLE's 241-test suite and testing how the agent handles edge cases across the real code repositories it analyzes.` |
| linkedin_ai | holdout | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.cc.d"` |
| linkedin_ai | holdout | report | W | (none) | `bank_wording_v348c.replaces.ripple.cc.d: "ripple.cc.a"` |
| lumen | holdout | resume_tex | W | `  \item Benchmarked agent cost at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` | `  \item Measured agent usage at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` |
| lumen | holdout | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.eff.b"` |
| lumen | holdout | report | W | (none) | `bank_wording_v348c.replaces.ripple.eff.b: "ripple.eff.a"` |
| mastercard | v340_original | report | W | `verify_changes_v344[2].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[2].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| mastercard | v340_original | report | W | `verify_changes_v344[3].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[3].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| meridian_sw | holdout | resume_tex | W | `  \item Validated every finished code change with a post-change check that reads its Git diff and flags unexpected edits, missing tests, and calling code that was left out of date by the change.` | `  \item Validated every finished code change with RIPPLE's own Git-diff check, which runs after the change is made, reads its Git diff, and flags unexpected edits, missing tests, and stale callers.` |
| meridian_sw | holdout | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| meridian_sw | holdout | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.git.c"` |
| meridian_sw | holdout | report | W | (none) | `bank_wording_v348c.replaces.ripple.git.c: "ripple.git.b"` |
| meritore_capgemini | v347_new | resume_tex | W | `  \item Benchmarked agent cost at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` | `  \item Measured agent usage at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` |
| meritore_capgemini | v347_new | report | W | `verify_quotes_v345.unquoted[0]: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b) (no"` | `verify_quotes_v345.unquoted[0]: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c) (no"` |
| meritore_capgemini | v347_new | report | W | `internal_changes[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `internal_changes[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| meritore_capgemini | v347_new | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.eff.b"` |
| meritore_capgemini | v347_new | report | W | (none) | `bank_wording_v348c.replaces.ripple.eff.b: "ripple.eff.a"` |
| monti | v341_tune | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| nimble | v340_original | resume_tex | W | `  \item Benchmarked agent cost at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` | `  \item Measured agent usage at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` |
| nimble | v340_original | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.eff.b"` |
| nimble | v340_original | report | W | (none) | `bank_wording_v348c.replaces.ripple.eff.b: "ripple.eff.a"` |
| northbeam | v341_tune | report | W | `verify_changes_v344[4].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[4].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| novita | v340_original | resume_tex | W | `  \item Benchmarked agent cost at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` | `  \item Measured agent usage at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` |
| novita | v340_original | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.eff.b"` |
| novita | v340_original | report | W | (none) | `bank_wording_v348c.replaces.ripple.eff.b: "ripple.eff.a"` |
| nvidia_ai_cloud | v341_tune | resume_tex | W | `  \item Wrote RIPPLE with Claude Code as a coding assistant, checking the code that Claude Code generated by running RIPPLE's 241-test suite and testing edge cases across real repositories.` | `  \item Wrote RIPPLE with Claude Code as a coding assistant, checking its output with RIPPLE's 241-test suite and testing how the agent handles edge cases across the real code repositories it analyzes.` |
| nvidia_ai_cloud | v341_tune | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.cc.d"` |
| nvidia_ai_cloud | v341_tune | report | W | (none) | `bank_wording_v348c.replaces.ripple.cc.d: "ripple.cc.a"` |
| nvidia_devtech | v340_original | resume_tex | W | `  \item Benchmarked agent cost at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` | `  \item Measured agent usage at about 10 tool calls and about 17 model calls per run, with under one duplicate call.` |
| nvidia_devtech | v340_original | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.eff.b"` |
| nvidia_devtech | v340_original | report | W | (none) | `bank_wording_v348c.replaces.ripple.eff.b: "ripple.eff.a"` |
| pocketly | v341_tune | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| qa_sdet | v340_original | resume_tex | W | `  \item Validated every finished code change with a post-change check that reads its Git diff and flags unexpected edits, missing tests, and calling code that was left out of date by the change.` | `  \item Validated every finished code change with RIPPLE's own Git-diff check, which runs after the change is made, reads its Git diff, and flags unexpected edits, missing tests, and stale callers.` |
| qa_sdet | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| qa_sdet | v340_original | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| qa_sdet | v340_original | report | W | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc"` | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc"` |
| qa_sdet | v340_original | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.git.c"` |
| qa_sdet | v340_original | report | W | (none) | `bank_wording_v348c.replaces.ripple.git.c: "ripple.git.b"` |
| quora | v345_new | resume_tex | W | `  \item Wrote RIPPLE with Claude Code as a coding assistant, checking the code that Claude Code generated by running RIPPLE's 241-test suite and testing edge cases across real repositories.` | `  \item Wrote RIPPLE with Claude Code as a coding assistant, checking its output with RIPPLE's 241-test suite and testing how the agent handles edge cases across the real code repositories it analyzes.` |
| quora | v345_new | report | W | (none) | `bank_wording_v348c.selected[0]: "ripple.cc.d"` |
| quora | v345_new | report | W | (none) | `bank_wording_v348c.replaces.ripple.cc.d: "ripple.cc.a"` |
| robot_sdet | v341_tune | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| robot_sdet | v341_tune | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| robot_sdet | v341_tune | report | W | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc"` | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc"` |
| serco_snow | v341_tune | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| serco_sw | v341_tune | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| stratus | v341_tune | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| swisslog | holdout | report | W | `preflight_v344.skills_or_heading_only[2].bullet_evidence: "preferred: ripple.cc.a, ripple.cc.c, ripple.cc.b"` | `preflight_v344.skills_or_heading_only[2].bullet_evidence: "preferred: ripple.cc.d, ripple.cc.c, ripple.cc.b"` |
| swisslog | holdout | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| twitch_se1 | v342_new | resume_tex | W | `  \item Created the Streamlit and React interface for the agents' streaming API so users can follow each agent's progress live, step by step, while the four agents of the simulated marketplace prototype run.` | `  \item Created the Streamlit and React interface for the agents' streaming API, so users can follow all four agents live as each step streams in from the API, including every human approval step.` |
| twitch_se1 | v342_new | report | W | `strict_fleet_v347c.swaps[0].after: "goingonce.ui.a"` | `strict_fleet_v347c.swaps[0].after: "goingonce.ui.c"` |
| twitch_se1 | v342_new | report | W | `strict_fleet_v347c.swaps[0].after_text: "Created the Streamlit and React interface for the agents' streaming API so users can follow each agent's progress live, step by step, while the four agents of the simulated marketplace prototype run."` | `strict_fleet_v347c.swaps[0].after_text: "Created the Streamlit and React interface for the agents' streaming API, so users can follow all four agents live as each step streams in from the API, including every human approval step."` |
| twitch_se1 | v342_new | report | W | (none) | `bank_wording_v348c.selected[0]: "goingonce.ui.c"` |
| twitch_se1 | v342_new | report | W | (none) | `bank_wording_v348c.replaces.goingonce.ui.c: "goingonce.ui.a"` |
| ust_software_engineer | v347_new | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| vindexa | v340_original | report | W | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.a, ripple.cc.c, ripple.cc.b)"` | `verify_changes_v344[0].change: "Preflight: a bullet that names Unit Testing is preferred (ripple.cc.d, ripple.cc.c, ripple.cc.b)"` |
| wpp | v340_original | report | W | `verify_changes_v344[1].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_changes_v344[1].change: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |
| wpp | v340_original | report | W | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.b)"` | `verify_quotes_v345.replaced[0]: "Preflight: a bullet that names Git is preferred (ripple.git.a, ripple.git.c)"` |

## Fix F

Before: `snap_v348c_W`. After: `snap_v348c_F` (every fix up to F on). Predictions: `predicted_changes_v348c_F.json`.

Result: **PASS**. 250 changed lines in 17 fixtures (17 with output changes beyond the version label); 0 unpredicted on v340_original / holdout; 0 unpredicted and unjustified elsewhere; 0 gate-guard failures; 0 lines matched only a documented amendment; longest letter 200 words.

Guards:

- F1 resume: only GoingOnce bullet lines change (projects, order, headings, slot counts, Experience and Skills identical): **held**
- F2 letter: only the GoingOnce sentence that cited Fleet changes: **held**
- F3 tracker and outreach identical; Fit identical: **held**
- F4 Fleet stays only on pages the logistics test accepts (every remaining Fleet page is listed with its reason): **held**

Changed fixtures (17): audit05, brightpath_fs, cardinal, cobalt, frontend, harvey, inspire11, ixl, loopwell, lumen, ng_fullstack, northwind, pinecrest, rocketmoney, sparkline, tiktok_appsec, us_cold

Fixtures that still show the Fleet bullet:

- us_cold: logistics posting ("We are looking for a Full Stack Java Developer with experience building performant, scalable, reliable, and testable sof")

Predicted but not changed:

- harvey / letter_txt
- lumen / letter_txt

| Fixture | Group | File | Fix | Before | After |
|---|---|---|---|---|---|
| audit05 | v340_original | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| audit05 | v340_original | letter_txt | F | `LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side permission checks block users from editing other users' tasks and reject forged evidence and skipped prerequisites. GoingOnce is a multi-agent car marketplace prototype my team of four built, where I mainly built the Negotiate and Fleet agents. A human a` | `LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side permission checks block users from editing other users' tasks and reject forged evidence and skipped prerequisites. GoingOnce is a multi-agent car marketplace prototype my team of four built, where I mainly built the Negotiate and Fleet agents. A human a` |
| audit05 | v340_original | report | F | `cover_letter.words: 185` | `cover_letter.words: 190` |
| audit05 | v340_original | report | F | `cover_letter.words_total: 192` | `cover_letter.words_total: 197` |
| audit05 | v340_original | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| audit05 | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| audit05 | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| audit05 | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| audit05 | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| audit05 | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| audit05 | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| audit05 | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| audit05 | v340_original | report | F | (none) | `strict_fleet_v347c.letter_sentence.project: "goingonce"` |
| audit05 | v340_original | report | F | (none) | `strict_fleet_v347c.letter_sentence.before: "Its Fleet agent spreads 120 similar rental cars across markets in full truckloads after checking demand."` |
| audit05 | v340_original | report | F | (none) | `strict_fleet_v347c.letter_sentence.after: "I coded its Negotiate agent, where each side keeps a private price limit and a mediator closes the gap in rounds."` |
| audit05 | v340_original | report | F | (none) | `fleet_v348c.repick.before[0]: "goingonce.agents.s1"` |
| audit05 | v340_original | report | F | (none) | `fleet_v348c.repick.before[1]: "goingonce.ui.s1"` |
| audit05 | v340_original | report | F | (none) | `fleet_v348c.repick.before[2]: "goingonce.fleet.a"` |
| audit05 | v340_original | report | F | (none) | `fleet_v348c.repick.after[0]: "goingonce.agents.s1"` |
| audit05 | v340_original | report | F | (none) | `fleet_v348c.repick.after[1]: "goingonce.ui.s1"` |
| audit05 | v340_original | report | F | (none) | `fleet_v348c.repick.after[2]: "goingonce.negotiate.a"` |
| audit05 | v340_original | report | F | (none) | `fleet_v348c.repick.pairs[0][0]: "goingonce.fleet.a"` |
| audit05 | v340_original | report | F | (none) | `fleet_v348c.repick.pairs[0][1]: "goingonce.negotiate.a"` |
| brightpath_fs | v341_tune | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| brightpath_fs | v341_tune | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| brightpath_fs | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| brightpath_fs | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| brightpath_fs | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| brightpath_fs | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| brightpath_fs | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| brightpath_fs | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| brightpath_fs | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| brightpath_fs | v341_tune | report | F | (none) | `fleet_v348c.repick.before[0]: "goingonce.agents.s1"` |
| brightpath_fs | v341_tune | report | F | (none) | `fleet_v348c.repick.before[1]: "goingonce.ui.s1"` |
| brightpath_fs | v341_tune | report | F | (none) | `fleet_v348c.repick.before[2]: "goingonce.fleet.a"` |
| brightpath_fs | v341_tune | report | F | (none) | `fleet_v348c.repick.after[0]: "goingonce.agents.s1"` |
| brightpath_fs | v341_tune | report | F | (none) | `fleet_v348c.repick.after[1]: "goingonce.ui.s1"` |
| brightpath_fs | v341_tune | report | F | (none) | `fleet_v348c.repick.after[2]: "goingonce.negotiate.a"` |
| brightpath_fs | v341_tune | report | F | (none) | `fleet_v348c.repick.pairs[0][0]: "goingonce.fleet.a"` |
| brightpath_fs | v341_tune | report | F | (none) | `fleet_v348c.repick.pairs[0][1]: "goingonce.negotiate.a"` |
| cardinal | holdout | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat.` |
| cardinal | holdout | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| cardinal | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| cardinal | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| cardinal | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.determ.b"` |
| cardinal | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| cardinal | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat."` |
| cardinal | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| cardinal | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Kept"` |
| cobalt | v341_tune | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| cobalt | v341_tune | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| cobalt | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| cobalt | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| cobalt | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| cobalt | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| cobalt | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| cobalt | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| cobalt | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| cobalt | v341_tune | report | F | (none) | `fleet_v348c.repick.before[0]: "goingonce.agents.s1"` |
| cobalt | v341_tune | report | F | (none) | `fleet_v348c.repick.before[1]: "goingonce.ui.s1"` |
| cobalt | v341_tune | report | F | (none) | `fleet_v348c.repick.before[2]: "goingonce.fleet.a"` |
| cobalt | v341_tune | report | F | (none) | `fleet_v348c.repick.after[0]: "goingonce.agents.s1"` |
| cobalt | v341_tune | report | F | (none) | `fleet_v348c.repick.after[1]: "goingonce.ui.s1"` |
| cobalt | v341_tune | report | F | (none) | `fleet_v348c.repick.after[2]: "goingonce.negotiate.a"` |
| cobalt | v341_tune | report | F | (none) | `fleet_v348c.repick.pairs[0][0]: "goingonce.fleet.a"` |
| cobalt | v341_tune | report | F | (none) | `fleet_v348c.repick.pairs[0][1]: "goingonce.negotiate.a"` |
| frontend | v340_original | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| frontend | v340_original | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| frontend | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| frontend | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| frontend | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| frontend | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| frontend | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| frontend | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| frontend | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| frontend | v340_original | report | F | (none) | `fleet_v348c.repick.before[0]: "goingonce.agents.s1"` |
| frontend | v340_original | report | F | (none) | `fleet_v348c.repick.before[1]: "goingonce.ui.s1"` |
| frontend | v340_original | report | F | (none) | `fleet_v348c.repick.before[2]: "goingonce.fleet.a"` |
| frontend | v340_original | report | F | (none) | `fleet_v348c.repick.after[0]: "goingonce.agents.s1"` |
| frontend | v340_original | report | F | (none) | `fleet_v348c.repick.after[1]: "goingonce.ui.s1"` |
| frontend | v340_original | report | F | (none) | `fleet_v348c.repick.after[2]: "goingonce.negotiate.a"` |
| frontend | v340_original | report | F | (none) | `fleet_v348c.repick.pairs[0][0]: "goingonce.fleet.a"` |
| frontend | v340_original | report | F | (none) | `fleet_v348c.repick.pairs[0][1]: "goingonce.negotiate.a"` |
| harvey | v341_tune | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat.` |
| harvey | v341_tune | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| harvey | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| harvey | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| harvey | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.determ.b"` |
| harvey | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| harvey | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat."` |
| harvey | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| harvey | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Kept"` |
| inspire11 | v340_original | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat.` |
| inspire11 | v340_original | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| inspire11 | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| inspire11 | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| inspire11 | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.determ.b"` |
| inspire11 | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| inspire11 | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat."` |
| inspire11 | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| inspire11 | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Kept"` |
| ixl | v340_original | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | (none) |
| ixl | v340_original | resume_tex | F | (none) | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| ixl | v340_original | letter_txt | F | `LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side rules reject forged evidence, skipped prerequisites, and duplicate submissions. GoingOnce is a multi-agent car marketplace prototype my team of four built, where I mainly built the Negotiate and Fleet agents. A human approves every simulated bid or listi` | `LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side rules reject forged evidence, skipped prerequisites, and duplicate submissions. GoingOnce is a multi-agent car marketplace prototype my team of four built, where I mainly built the Negotiate and Fleet agents. A human approves every simulated bid or listi` |
| ixl | v340_original | report | F | `cover_letter.words: 187` | `cover_letter.words: 192` |
| ixl | v340_original | report | F | `cover_letter.words_total: 194` | `cover_letter.words_total: 199` |
| ixl | v340_original | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| ixl | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| ixl | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| ixl | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| ixl | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| ixl | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| ixl | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| ixl | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| ixl | v340_original | report | F | (none) | `fleet_v348c.repick.before[0]: "goingonce.agents.a"` |
| ixl | v340_original | report | F | (none) | `fleet_v348c.repick.before[1]: "goingonce.fleet.a"` |
| ixl | v340_original | report | F | (none) | `fleet_v348c.repick.before[2]: "goingonce.history.a"` |
| ixl | v340_original | report | F | (none) | `fleet_v348c.repick.after[0]: "goingonce.agents.a"` |
| ixl | v340_original | report | F | (none) | `fleet_v348c.repick.after[1]: "goingonce.history.a"` |
| ixl | v340_original | report | F | (none) | `fleet_v348c.repick.after[2]: "goingonce.negotiate.a"` |
| ixl | v340_original | report | F | (none) | `fleet_v348c.repick.pairs[0][0]: "goingonce.fleet.a"` |
| ixl | v340_original | report | F | (none) | `fleet_v348c.repick.pairs[0][1]: "goingonce.negotiate.a"` |
| loopwell | holdout | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| loopwell | holdout | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| loopwell | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| loopwell | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| loopwell | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| loopwell | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| loopwell | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| loopwell | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| loopwell | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| loopwell | holdout | report | F | (none) | `fleet_v348c.repick.before[0]: "goingonce.agents.s1"` |
| loopwell | holdout | report | F | (none) | `fleet_v348c.repick.before[1]: "goingonce.ui.s1"` |
| loopwell | holdout | report | F | (none) | `fleet_v348c.repick.before[2]: "goingonce.fleet.a"` |
| loopwell | holdout | report | F | (none) | `fleet_v348c.repick.after[0]: "goingonce.agents.s1"` |
| loopwell | holdout | report | F | (none) | `fleet_v348c.repick.after[1]: "goingonce.ui.s1"` |
| loopwell | holdout | report | F | (none) | `fleet_v348c.repick.after[2]: "goingonce.negotiate.a"` |
| loopwell | holdout | report | F | (none) | `fleet_v348c.repick.pairs[0][0]: "goingonce.fleet.a"` |
| loopwell | holdout | report | F | (none) | `fleet_v348c.repick.pairs[0][1]: "goingonce.negotiate.a"` |
| lumen | holdout | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat.` |
| lumen | holdout | resume_tex | F | `  \item Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and photos with a saved fallback for every call, so results repeat.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.determ.b"` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat."` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Kept"` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.swaps[1].project: "goingonce"` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.swaps[1].before: "goingonce.determ.a"` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.swaps[1].after: "goingonce.negotiate.a"` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.swaps[1].before_text: "Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and photos with a saved fallback for every call, so results repeat."` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.swaps[1].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.swaps[1].lines: 2` |
| lumen | holdout | report | F | (none) | `strict_fleet_v347c.swaps[1].verb: "Coded"` |
| lumen | holdout | report | F | (none) | `fleet_v348c.repick.before[0]: "goingonce.agents.a"` |
| lumen | holdout | report | F | (none) | `fleet_v348c.repick.before[1]: "goingonce.fleet.a"` |
| lumen | holdout | report | F | (none) | `fleet_v348c.repick.before[2]: "goingonce.determ.a"` |
| lumen | holdout | report | F | (none) | `fleet_v348c.repick.after[0]: "goingonce.agents.a"` |
| lumen | holdout | report | F | (none) | `fleet_v348c.repick.after[1]: "goingonce.determ.b"` |
| lumen | holdout | report | F | (none) | `fleet_v348c.repick.after[2]: "goingonce.negotiate.a"` |
| lumen | holdout | report | F | (none) | `fleet_v348c.repick.pairs[0][0]: "goingonce.fleet.a"` |
| lumen | holdout | report | F | (none) | `fleet_v348c.repick.pairs[0][1]: "goingonce.determ.b"` |
| lumen | holdout | report | F | (none) | `fleet_v348c.repick.pairs[1][0]: "goingonce.determ.a"` |
| lumen | holdout | report | F | (none) | `fleet_v348c.repick.pairs[1][1]: "goingonce.negotiate.a"` |
| ng_fullstack | v340_original | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat.` |
| ng_fullstack | v340_original | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| ng_fullstack | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| ng_fullstack | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| ng_fullstack | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.determ.b"` |
| ng_fullstack | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| ng_fullstack | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat."` |
| ng_fullstack | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| ng_fullstack | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Kept"` |
| northwind | v341_tune | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| northwind | v341_tune | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| northwind | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| northwind | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| northwind | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| northwind | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| northwind | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| northwind | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| northwind | v341_tune | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| northwind | v341_tune | report | F | (none) | `fleet_v348c.repick.before[0]: "goingonce.agents.s1"` |
| northwind | v341_tune | report | F | (none) | `fleet_v348c.repick.before[1]: "goingonce.ui.s1"` |
| northwind | v341_tune | report | F | (none) | `fleet_v348c.repick.before[2]: "goingonce.fleet.a"` |
| northwind | v341_tune | report | F | (none) | `fleet_v348c.repick.after[0]: "goingonce.agents.s1"` |
| northwind | v341_tune | report | F | (none) | `fleet_v348c.repick.after[1]: "goingonce.ui.s1"` |
| northwind | v341_tune | report | F | (none) | `fleet_v348c.repick.after[2]: "goingonce.negotiate.a"` |
| northwind | v341_tune | report | F | (none) | `fleet_v348c.repick.pairs[0][0]: "goingonce.fleet.a"` |
| northwind | v341_tune | report | F | (none) | `fleet_v348c.repick.pairs[0][1]: "goingonce.negotiate.a"` |
| pinecrest | holdout | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| pinecrest | holdout | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| pinecrest | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| pinecrest | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| pinecrest | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| pinecrest | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| pinecrest | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| pinecrest | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| pinecrest | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| pinecrest | holdout | report | F | (none) | `fleet_v348c.repick.before[0]: "goingonce.agents.s1"` |
| pinecrest | holdout | report | F | (none) | `fleet_v348c.repick.before[1]: "goingonce.ui.s1"` |
| pinecrest | holdout | report | F | (none) | `fleet_v348c.repick.before[2]: "goingonce.fleet.a"` |
| pinecrest | holdout | report | F | (none) | `fleet_v348c.repick.after[0]: "goingonce.agents.s1"` |
| pinecrest | holdout | report | F | (none) | `fleet_v348c.repick.after[1]: "goingonce.ui.s1"` |
| pinecrest | holdout | report | F | (none) | `fleet_v348c.repick.after[2]: "goingonce.negotiate.a"` |
| pinecrest | holdout | report | F | (none) | `fleet_v348c.repick.pairs[0][0]: "goingonce.fleet.a"` |
| pinecrest | holdout | report | F | (none) | `fleet_v348c.repick.pairs[0][1]: "goingonce.negotiate.a"` |
| rocketmoney | v340_original | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat.` |
| rocketmoney | v340_original | letter_txt | F | `LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side permission checks block users from editing other users' tasks and reject forged evidence and skipped prerequisites. GoingOnce is a multi-agent car marketplace prototype my team of four built, where I mainly built the Negotiate and Fleet agents. A human a` | `LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side permission checks block users from editing other users' tasks and reject forged evidence and skipped prerequisites. GoingOnce is a multi-agent car marketplace prototype my team of four built, where I mainly built the Negotiate and Fleet agents. A human a` |
| rocketmoney | v340_original | report | F | `cover_letter.words: 184` | `cover_letter.words: 188` |
| rocketmoney | v340_original | report | F | `cover_letter.words_total: 191` | `cover_letter.words_total: 195` |
| rocketmoney | v340_original | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| rocketmoney | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| rocketmoney | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| rocketmoney | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.determ.b"` |
| rocketmoney | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| rocketmoney | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat."` |
| rocketmoney | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| rocketmoney | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Kept"` |
| rocketmoney | v340_original | report | F | (none) | `strict_fleet_v347c.letter_sentence.project: "goingonce"` |
| rocketmoney | v340_original | report | F | (none) | `strict_fleet_v347c.letter_sentence.before: "Its Fleet agent spreads 120 similar rental cars across markets in full truckloads after checking demand."` |
| rocketmoney | v340_original | report | F | (none) | `strict_fleet_v347c.letter_sentence.after: "Search, pricing and negotiation math stay in plain code, and every language-model call keeps a saved fallback, so results repeat."` |
| sparkline | holdout | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat.` |
| sparkline | holdout | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| sparkline | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| sparkline | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| sparkline | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.determ.b"` |
| sparkline | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| sparkline | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat."` |
| sparkline | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| sparkline | holdout | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Kept"` |
| tiktok_appsec | v340_original | resume_tex | F | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat.` |
| tiktok_appsec | v340_original | letter_txt | F | `LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Its live-quiz service in Go runs as two copies behind nginx, with Redis keeping them in sync. GoingOnce is a multi-agent car marketplace prototype my team of four built, where I mainly built the Negotiate and Fleet agents. A human approves every simulated bid or lis` | `LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Its live-quiz service in Go runs as two copies behind nginx, with Redis keeping them in sync. GoingOnce is a multi-agent car marketplace prototype my team of four built, where I mainly built the Negotiate and Fleet agents. A human approves every simulated bid or lis` |
| tiktok_appsec | v340_original | report | F | `cover_letter.words: 181` | `cover_letter.words: 185` |
| tiktok_appsec | v340_original | report | F | `cover_letter.words_total: 189` | `cover_letter.words_total: 193` |
| tiktok_appsec | v340_original | report | F | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| tiktok_appsec | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| tiktok_appsec | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| tiktok_appsec | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.determ.b"` |
| tiktok_appsec | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| tiktok_appsec | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].after_text: "Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for language and photos, with a saved fallback for every call, so results repeat."` |
| tiktok_appsec | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| tiktok_appsec | v340_original | report | F | (none) | `strict_fleet_v347c.swaps[0].verb: "Kept"` |
| tiktok_appsec | v340_original | report | F | (none) | `strict_fleet_v347c.letter_sentence.project: "goingonce"` |
| tiktok_appsec | v340_original | report | F | (none) | `strict_fleet_v347c.letter_sentence.before: "Its Fleet agent spreads 120 similar rental cars across markets in full truckloads after checking demand."` |
| tiktok_appsec | v340_original | report | F | (none) | `strict_fleet_v347c.letter_sentence.after: "Search, pricing and negotiation math stay in plain code, and every language-model call keeps a saved fallback, so results repeat."` |
| us_cold | v342_new | report | F | (none) | `fleet_v348c.fleet_on_page: true` |
| us_cold | v342_new | report | F | (none) | `fleet_v348c.logistics_line: "We are looking for a Full Stack Java Developer with experience building performant, scalable, reliable, and testable software for our warehouse management syste"` |

## Fix S

Before: `snap_v348c_F`. After: `snap_v348c_S` (every fix up to S on). Predictions: `predicted_changes_v348c_S.json`; amendments: `predicted_changes_v348c_S_amendments.json`.

Result: **PASS**. 1612 changed lines in 99 fixtures (99 with output changes beyond the version label); 0 unpredicted on v340_original / holdout; 0 unpredicted and unjustified elsewhere; 0 gate-guard failures; 1 lines matched only a documented amendment; longest letter 200 words.

Guards:

- S1 resume: only the Skills "Languages & Databases" line changes: **held**
- S2 that line keeps every old item, lists languages before databases, and adds only terms the page shows (up to 3 items): **held**
- S3 letter, tracker and outreach identical: **held**

Changed fixtures (99): allergan, alml_engineer, amazon, amplify, amplitude, apple, applied_mat, arclight, assetwatch, atoms, audible, audible_md, audit01, audit02, audit03, audit04, audit05, audit06, audit08, audit09, audit11, audit12, bae, birthmodel, black_canyon, brex, brightpath_fs, brightpath_ml, brillio, bti, cardinal, chewy, cobalt, commure, dominos, doordash, doordash_mdx, elevenlabs, engen, fanatics, figure, flowgen, frontend, fulfillment, ga_asi, garmin, google_sre, halcyon, helix, impact, inspire11, instalily, ios_randstad, ironvale, ixl, jobgether, klaviyo, l3harris, laminar, linkedin, loopwell, mastercard, meridian_bank, meridian_sw, meritore_capgemini, microsoft, ng_fullstack, nimble, northbeam, novita, nvidia_devtech, otter, paypal, perplexity, pinecrest, pinterest, pocketly, quora, raydar_backend, raydar_swe, research_phd, robot_sdet, rocketmoney, rockstar, serco_snow, serco_sw, spacexsi, sparkline, tailscale, tiktok_appsec, twitch, twitch_se1, umich, us_cold, ust_software_engineer, vindexa, wgu, wpp, zoro_fullstack

| Fixture | Group | File | Fix | Before | After |
|---|---|---|---|---|---|
| allergan | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Java, SQL, Go, PostgreSQL, MongoDB, JavaScript` | `  \item \textbf{Languages \& Databases:} Python, Java, SQL, Go, JavaScript, PostgreSQL, MongoDB` |
| allergan | v340_original | report | S | `skill_fit_cache.skills_text_hash: "2d999880598b86ede07b16190ecb22ca0b4d8e7020e75d155ca490be8e320950"` | `skill_fit_cache.skills_text_hash: "6eb63705b50001ec3d92a5d0281bfc196dbe1577ffe8857090aa54cf94ebdc09"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "SQL"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Go"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "PostgreSQL"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MongoDB"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "JavaScript"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "JavaScript"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "PostgreSQL"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "MongoDB"` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| allergan | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| alml_engineer | v347_new | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, PostgreSQL` |
| alml_engineer | v347_new | report | S | `skill_fit_cache.skills_text_hash: "901cd5a726b81420260d026c6720100b0db801b88feae51f3b80cebea78665d2"` | `skill_fit_cache.skills_text_hash: "a5e8f2d20ac7ce039d63085e6c991d273a220a5116934f4289466f75cd349e4c"` |
| alml_engineer | v347_new | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| alml_engineer | v347_new | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| alml_engineer | v347_new | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| alml_engineer | v347_new | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| alml_engineer | v347_new | report | S | (none) | `skills_lines_v348c.after[2]: "PostgreSQL"` |
| alml_engineer | v347_new | report | S | (none) | `skills_lines_v348c.s2_added[0]: "PostgreSQL"` |
| alml_engineer | v347_new | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| amazon | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, C, Python, PostgreSQL, SQL` | `  \item \textbf{Languages \& Databases:} Java, C, Python, SQL, PostgreSQL` |
| amazon | v340_original | report | S | `skill_fit_cache.skills_text_hash: "31bb41d2caa6a008148a0cc2cf2774c163525dbed075e0bdc92a7b7c88f1bc7c"` | `skill_fit_cache.skills_text_hash: "dd38b51911530fceb1f016bce285f6cab7c8d3b3e458dffdd4aef4922eef1a10"` |
| amazon | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| amazon | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "C"` |
| amazon | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Python"` |
| amazon | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| amazon | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| amazon | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| amazon | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "C"` |
| amazon | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Python"` |
| amazon | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| amazon | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| amazon | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| amazon | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| amplify | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} SQL, Java, Go, PostgreSQL, Python, MongoDB, MySQL` | `  \item \textbf{Languages \& Databases:} SQL, Java, Go, Python, PostgreSQL, MongoDB, MySQL` |
| amplify | v340_original | report | S | `skill_fit_cache.skills_text_hash: "9edca408a7d6c330485a9157bcdcbc9705609d682e79da46810b666c49096ba6"` | `skill_fit_cache.skills_text_hash: "6e8bca5fe005ddb2ad50d8f5b7f9871afc3b04c31efe273b980d04d7a4bd8f3b"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "SQL"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Go"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "Python"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MongoDB"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "MySQL"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "SQL"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Go"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Python"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MongoDB"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "MySQL"` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| amplify | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| amplitude | holdout | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, Python, PostgreSQL, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Java, Python, SQL, PostgreSQL, MySQL` |
| amplitude | holdout | report | S | `skill_fit_cache.skills_text_hash: "e99d4d465dfb78cd0ba0197ac57927e85297537b5d2ea95d472940ef75f51f04"` | `skill_fit_cache.skills_text_hash: "1af95e68e76522b54465ec8552fe50e1b254f63b6d6d6e3fd8ad266bdfd5dbf1"` |
| amplitude | holdout | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| amplitude | holdout | report | S | (none) | `skills_lines_v348c.before[1]: "Python"` |
| amplitude | holdout | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| amplitude | holdout | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| amplitude | holdout | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| amplitude | holdout | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| amplitude | holdout | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| amplitude | holdout | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| amplitude | holdout | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| amplitude | holdout | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| amplitude | holdout | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| amplitude | holdout | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| apple | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Relational Databases, SQL, Python, Java, PostgreSQL, MySQL` | `  \item \textbf{Languages \& Databases:} SQL, Python, Java, Relational Databases, PostgreSQL, MySQL` |
| apple | v340_original | report | S | `skill_fit_cache.skills_text_hash: "50d9e2a9ebb2ae7be9ea3a9dc2b7d1a0afab02e6e5480b6bc86e3fa6485affe8"` | `skill_fit_cache.skills_text_hash: "eabe612602a93db901c7550f40bac4104ee094fa04b2752978c4d8ef27d93af4"` |
| apple | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Relational Databases"` |
| apple | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| apple | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Python"` |
| apple | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| apple | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "PostgreSQL"` |
| apple | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| apple | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "SQL"` |
| apple | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| apple | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| apple | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Relational Databases"` |
| apple | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| apple | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| apple | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| apple | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| applied_mat | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} C, Python, Java, PostgreSQL, SQL` | `  \item \textbf{Languages \& Databases:} C, Python, Java, SQL, PostgreSQL` |
| applied_mat | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "0d2db77c8eda614266da177d07f96db251578879bee944daf8c20f204cf331ac"` | `skill_fit_cache.skills_text_hash: "dcbeacaefaf0b3043a9c9b2f95251c71af96a4f29d1d19e7c06003384e951406"` |
| applied_mat | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "C"` |
| applied_mat | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "Python"` |
| applied_mat | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| applied_mat | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| applied_mat | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| applied_mat | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "C"` |
| applied_mat | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| applied_mat | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| applied_mat | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| applied_mat | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| applied_mat | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| applied_mat | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| arclight | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} C, Python, Java, PostgreSQL, SQL` | `  \item \textbf{Languages \& Databases:} C, Python, Java, SQL, PostgreSQL` |
| arclight | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "4c11f96e63e4ffda0cdd84507f1ba82acfc804d0c8679b2214353fc6465b7f34"` | `skill_fit_cache.skills_text_hash: "f340d6886f45ff2a850f096144c95d00d85abf3bd2488f6bae5e8d7024c027a7"` |
| arclight | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "C"` |
| arclight | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "Python"` |
| arclight | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| arclight | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| arclight | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| arclight | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "C"` |
| arclight | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| arclight | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| arclight | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| arclight | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| arclight | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| arclight | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| assetwatch | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Relational Databases, MySQL, Python, SQL, Java, Go, PostgreSQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, Go, Relational Databases, MySQL, PostgreSQL` |
| assetwatch | v340_original | report | S | `skill_fit_cache.skills_text_hash: "4672e9a19d7cf9e6399a7d46d73537c5ebb4ec4a333ab42e60ee8539f09c3ef3"` | `skill_fit_cache.skills_text_hash: "bebb98d1d12c1052d03b9df26bac541a6ec03266cb39b58b6df855574590cb72"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Relational Databases"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "MySQL"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Python"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "Java"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "Go"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "PostgreSQL"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "Relational Databases"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "PostgreSQL"` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| assetwatch | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| atoms | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, PostgreSQL, Go, MongoDB, NoSQL, Python, SQL` | `  \item \textbf{Languages \& Databases:} Java, Go, Python, SQL, PostgreSQL, MongoDB, NoSQL` |
| atoms | v340_original | report | S | `skill_fit_cache.skills_text_hash: "b09ba448ce5392750e3455dc639c85a3e34bd6354a1f9f71411bc946bdf8c4a8"` | `skill_fit_cache.skills_text_hash: "febf37d3898601db3758f031b569826309268055dd4bfa21f46ca2dbd5a60609"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Go"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "MongoDB"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "NoSQL"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "Python"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "SQL"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Go"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Python"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MongoDB"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "NoSQL"` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| atoms | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| audible | v343_new | resume_tex | S | `  \item \textbf{Languages \& Databases:} PostgreSQL, NoSQL, SQL, Python, Java, Go, MongoDB, MySQL` | `  \item \textbf{Languages \& Databases:} SQL, Python, Java, Go, PostgreSQL, NoSQL, MongoDB, MySQL` |
| audible | v343_new | report | S | `skill_fit_cache.skills_text_hash: "0329bc2b83ede8fc8a999184b2ae756858181351fa4505739533b38912d0ca1a"` | `skill_fit_cache.skills_text_hash: "792b0049a11efb723260eed4b3d68f5d7afabce4709a425630c9f0f571f95e39"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.before[0]: "PostgreSQL"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.before[1]: "NoSQL"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.before[2]: "SQL"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.before[3]: "Python"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.before[4]: "Java"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.before[5]: "Go"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.before[6]: "MongoDB"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.before[7]: "MySQL"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.after[0]: "SQL"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.after[5]: "NoSQL"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.after[6]: "MongoDB"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.after[7]: "MySQL"` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| audible | v343_new | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| audible_md | v344_new | resume_tex | S | `  \item \textbf{Languages \& Databases:} PostgreSQL, NoSQL, SQL, Python, Java, Go, MongoDB, MySQL` | `  \item \textbf{Languages \& Databases:} SQL, Python, Java, Go, PostgreSQL, NoSQL, MongoDB, MySQL` |
| audible_md | v344_new | report | S | `skill_fit_cache.skills_text_hash: "0329bc2b83ede8fc8a999184b2ae756858181351fa4505739533b38912d0ca1a"` | `skill_fit_cache.skills_text_hash: "792b0049a11efb723260eed4b3d68f5d7afabce4709a425630c9f0f571f95e39"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.before[0]: "PostgreSQL"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.before[1]: "NoSQL"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.before[2]: "SQL"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.before[3]: "Python"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.before[4]: "Java"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.before[5]: "Go"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.before[6]: "MongoDB"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.before[7]: "MySQL"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.after[0]: "SQL"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.after[5]: "NoSQL"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.after[6]: "MongoDB"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.after[7]: "MySQL"` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| audible_md | v344_new | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| audit01 | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL, PostgreSQL, Java, Go, MongoDB` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, Go, PostgreSQL, MongoDB` |
| audit01 | v340_original | report | S | `skill_fit_cache.skills_text_hash: "c7c9fec35011c41b0683860fc7a96328fa304aac3ea74fbf898aae0e7915ad7d"` | `skill_fit_cache.skills_text_hash: "d7f01dde1b2800b5547f245133abe623a8e972a21ad2b1c5d48f1779f793d7ec"` |
| audit01 | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| audit01 | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| audit01 | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| audit01 | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| audit01 | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "Go"` |
| audit01 | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MongoDB"` |
| audit01 | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| audit01 | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| audit01 | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| audit01 | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| audit01 | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| audit01 | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MongoDB"` |
| audit01 | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| audit01 | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| audit02 | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} SQL, Python, PostgreSQL, Java, MySQL` | `  \item \textbf{Languages \& Databases:} SQL, Python, Java, PostgreSQL, MySQL` |
| audit02 | v340_original | report | S | `skill_fit_cache.skills_text_hash: "ebd17bbee7d05ec15dc44080631f9cac0e559682942c68721e708ae7be5564c6"` | `skill_fit_cache.skills_text_hash: "dc502d1dff9543997e6aa6e139ef842ee80b91e3fc0619c861511486de322fa4"` |
| audit02 | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "SQL"` |
| audit02 | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Python"` |
| audit02 | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| audit02 | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| audit02 | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| audit02 | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "SQL"` |
| audit02 | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| audit02 | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| audit02 | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| audit02 | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| audit02 | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| audit02 | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| audit03 | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL, Relational Databases, PostgreSQL, Java, MySQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, Relational Databases, PostgreSQL, MySQL` |
| audit03 | v340_original | report | S | `skill_fit_cache.skills_text_hash: "3861a465befcae96a02d2065d0ef59077ea62375a23c5bb9f4b621ac42c2f50d"` | `skill_fit_cache.skills_text_hash: "dc50bc1c4aa344c85703320261b493181a2ad7eb6d689b5440b2ebcdda091f16"` |
| audit03 | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| audit03 | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| audit03 | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Relational Databases"` |
| audit03 | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| audit03 | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "Java"` |
| audit03 | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| audit03 | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| audit03 | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| audit03 | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| audit03 | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Relational Databases"` |
| audit03 | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| audit03 | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| audit03 | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| audit03 | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| audit04 | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL, PostgreSQL, Java, Relational Databases, MySQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, PostgreSQL, Relational Databases, MySQL` |
| audit04 | v340_original | report | S | `skill_fit_cache.skills_text_hash: "55eb4339c98a2975949a9ef8dcd56e22aa0381db3ed0ef1c69ae7cb7ddf06ba2"` | `skill_fit_cache.skills_text_hash: "b96e0069a27f992a6560a662a9766dd3fe8279d75bd0c5766970479171f6aa7e"` |
| audit04 | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| audit04 | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| audit04 | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| audit04 | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| audit04 | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "Relational Databases"` |
| audit04 | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| audit04 | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| audit04 | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| audit04 | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| audit04 | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| audit04 | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "Relational Databases"` |
| audit04 | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| audit04 | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| audit04 | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| audit05 | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, JavaScript, Relational Databases, SQL, PostgreSQL, Java, Go, MongoDB, MySQL` | `  \item \textbf{Languages \& Databases:} Python, JavaScript, SQL, Java, Go, Relational Databases, PostgreSQL, MongoDB, MySQL` |
| audit05 | v340_original | report | S | `skill_fit_cache.skills_text_hash: "14d43eb59d73bf9c7d17d49aa722596cdf7c9f8d16f96081b127bf335e48df41"` | `skill_fit_cache.skills_text_hash: "fb2affca5c1453caeda5b6b0cc13572c7f48837788ebca38676937104c781637"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "JavaScript"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Relational Databases"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "PostgreSQL"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "Java"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "Go"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.before[7]: "MongoDB"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.before[8]: "MySQL"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "JavaScript"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Java"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "Go"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "Relational Databases"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "PostgreSQL"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.after[7]: "MongoDB"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.after[8]: "MySQL"` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| audit05 | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| audit06 | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL, PostgreSQL, Java, MySQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, PostgreSQL, MySQL` |
| audit06 | v340_original | report | S | `skill_fit_cache.skills_text_hash: "601e48c2531f76553545e6283b6a9bb6533a9c029f0cc5148831ddd4898cd500"` | `skill_fit_cache.skills_text_hash: "aa519baa06108dd93d0787fbf9dd466d5beab63a767313aaf47d236f8ebd6269"` |
| audit06 | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| audit06 | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| audit06 | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| audit06 | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| audit06 | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| audit06 | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| audit06 | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| audit06 | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| audit06 | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| audit06 | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| audit06 | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| audit06 | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| audit08 | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, C, Java, PostgreSQL, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, C, Java, SQL, PostgreSQL, MySQL` |
| audit08 | v340_original | report | S | `skill_fit_cache.skills_text_hash: "0372d073a973efce3defefa4fcf50c643e685949488c69e18662e91a4e45ee2a"` | `skill_fit_cache.skills_text_hash: "0d4b1ca4cd3897a2b675c96af213071d5a7b7c3a1dbb33bbb4b3368634be724f"` |
| audit08 | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| audit08 | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "C"` |
| audit08 | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| audit08 | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| audit08 | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| audit08 | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| audit08 | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| audit08 | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "C"` |
| audit08 | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| audit08 | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| audit08 | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| audit08 | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| audit08 | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| audit08 | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| audit09 | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, PostgreSQL, Java, Go, MongoDB, MySQL, SQL` | `  \item \textbf{Languages \& Databases:} Python, Java, Go, SQL, PostgreSQL, MongoDB, MySQL` |
| audit09 | v340_original | report | S | `skill_fit_cache.skills_text_hash: "a81aaa837ff023a99db837093a02cc1b3d16c1670c8521fb0ee382ff011ddb39"` | `skill_fit_cache.skills_text_hash: "3dde91790858f41ed62275f58ee6dbeda17d002c4c0f431e02fb888ecf461591"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Go"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "MongoDB"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "SQL"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Go"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MongoDB"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "MySQL"` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| audit09 | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| audit11 | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} C, Python, Java, PostgreSQL, SQL` | `  \item \textbf{Languages \& Databases:} C, Python, Java, SQL, PostgreSQL` |
| audit11 | v340_original | report | S | `skill_fit_cache.skills_text_hash: "c2b1aaa12322f8b7c4b65da9f38deafe14649fc084337fd10c49da9d277961c6"` | `skill_fit_cache.skills_text_hash: "fdec491ef052d7e58f8f3499205c83c27d464209cf789590c09f7c9243260d11"` |
| audit11 | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "C"` |
| audit11 | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Python"` |
| audit11 | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| audit11 | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| audit11 | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| audit11 | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "C"` |
| audit11 | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| audit11 | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| audit11 | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| audit11 | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| audit11 | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| audit11 | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| audit12 | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL, Relational Databases, PostgreSQL, Java` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, Relational Databases, PostgreSQL` |
| audit12 | v340_original | report | S | `skill_fit_cache.skills_text_hash: "ac8e30a835e4407bc9626af916c2d335fb7075ac44bd644b8d2d6836378843ba"` | `skill_fit_cache.skills_text_hash: "8230ee5fbc25d47ba4137ec429de70e8a7bcc11df753ffcded62602a8a3fcbe5"` |
| audit12 | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| audit12 | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| audit12 | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Relational Databases"` |
| audit12 | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| audit12 | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "Java"` |
| audit12 | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| audit12 | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| audit12 | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| audit12 | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Relational Databases"` |
| audit12 | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| audit12 | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| audit12 | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| bae | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} C, Java, Python, PostgreSQL, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} C, Java, Python, SQL, PostgreSQL, MySQL` |
| bae | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "34ef9cdbcd84e0b4aaebaf019df6e88d1c11bb8e34a166bb0da9359f2c40a620"` | `skill_fit_cache.skills_text_hash: "5e2ac9a75afcf0fb4ad5e82217a106dc2f0003583f0228bc60f971f1d96edcc6"` |
| bae | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "C"` |
| bae | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| bae | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "Python"` |
| bae | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| bae | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| bae | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| bae | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "C"` |
| bae | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| bae | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Python"` |
| bae | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| bae | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| bae | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| bae | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| bae | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| birthmodel | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Relational Databases, Python, PostgreSQL, JavaScript, Java, Go, MongoDB, SQL` | `  \item \textbf{Languages \& Databases:} Python, JavaScript, Java, Go, SQL, Relational Databases, PostgreSQL, MongoDB` |
| birthmodel | v340_original | report | S | `skill_fit_cache.skills_text_hash: "2452801798fca3606782e3600a3be220d849220eb4a6369a06c8c5ee14e0268b"` | `skill_fit_cache.skills_text_hash: "8ea7fd631dfe57f04d00ebffc6826e38b74bcc85c22cf9603b3d31dcd66153c1"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Relational Databases"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Python"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "JavaScript"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "Java"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "Go"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "MongoDB"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.before[7]: "SQL"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "JavaScript"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "SQL"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "Relational Databases"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "PostgreSQL"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.after[7]: "MongoDB"` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| birthmodel | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| black_canyon | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL, Relational Databases, PostgreSQL, Java, MySQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, Relational Databases, PostgreSQL, MySQL` |
| black_canyon | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "9104417713a231c5c59f64c9a748e13e05ac491167bcd21d7575e1d7118245f3"` | `skill_fit_cache.skills_text_hash: "d28d11d00b92b5fa507f40a9b65265f6d217e33f96f720906aa4dc74213f3b36"` |
| black_canyon | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| black_canyon | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| black_canyon | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "Relational Databases"` |
| black_canyon | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| black_canyon | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "Java"` |
| black_canyon | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| black_canyon | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| black_canyon | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| black_canyon | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| black_canyon | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "Relational Databases"` |
| black_canyon | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| black_canyon | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| black_canyon | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| black_canyon | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| brex | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} SQL, Python, PostgreSQL, Java, MySQL` | `  \item \textbf{Languages \& Databases:} SQL, Python, Java, PostgreSQL, MySQL` |
| brex | v340_original | report | S | `skill_fit_cache.skills_text_hash: "7e81397549114fdfc93dc3ea393627a64b006df1c783a5eb360610084cd4e1c1"` | `skill_fit_cache.skills_text_hash: "f783b15d2f8bf19fb6772bd459749f456dab29ba6ea80652f692ab178673ad6b"` |
| brex | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "SQL"` |
| brex | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Python"` |
| brex | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| brex | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| brex | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| brex | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "SQL"` |
| brex | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| brex | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| brex | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| brex | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| brex | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| brex | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| brightpath_fs | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, PostgreSQL, JavaScript, Relational Databases, SQL, Java, Go, MongoDB, MySQL` | `  \item \textbf{Languages \& Databases:} Python, JavaScript, SQL, Java, Go, PostgreSQL, Relational Databases, MongoDB, MySQL` |
| brightpath_fs | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "f75814cbc9b2582823e7e3c5617c789973a181743fb0b7310582194d1d75769d"` | `skill_fit_cache.skills_text_hash: "4997278bd7044b4030cce08837f6688873d0e48299ec7991a8cd558801d290f6"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "JavaScript"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "Relational Databases"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "Java"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.before[6]: "Go"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.before[7]: "MongoDB"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.before[8]: "MySQL"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "JavaScript"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "Java"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "Go"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "PostgreSQL"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.after[6]: "Relational Databases"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.after[7]: "MongoDB"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.after[8]: "MySQL"` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| brightpath_fs | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| brightpath_ml | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL, PostgreSQL, Java, MySQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, PostgreSQL, MySQL` |
| brightpath_ml | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "3575c2bb3f7a9650cf9e1d332328bfe2d316fb9d024ade2c35eeac291722d5bf"` | `skill_fit_cache.skills_text_hash: "e37ee58a223cf8f146313243e4264fd9a5d0c681c3c092ef2d53d40552599579"` |
| brightpath_ml | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| brightpath_ml | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| brightpath_ml | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| brightpath_ml | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| brightpath_ml | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| brightpath_ml | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| brightpath_ml | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| brightpath_ml | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| brightpath_ml | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| brightpath_ml | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| brightpath_ml | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| brightpath_ml | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| brillio | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, Python, PostgreSQL, SQL` | `  \item \textbf{Languages \& Databases:} Java, Python, SQL, PostgreSQL` |
| brillio | v340_original | report | S | `skill_fit_cache.skills_text_hash: "d7a555afc6a57dc19dff1422b1a2a9822f75ba3f32266f1d26442d97c0dab3ce"` | `skill_fit_cache.skills_text_hash: "18002ad64851598b808f5861204aaaac40f6a740b0560b52d7d81007d5fb36b9"` |
| brillio | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| brillio | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Python"` |
| brillio | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| brillio | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| brillio | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| brillio | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| brillio | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| brillio | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| brillio | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| brillio | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| bti | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, Python, Relational Databases, SQL, HTML/CSS, JavaScript, Go, PostgreSQL, MySQL` | `  \item \textbf{Languages \& Databases:} Java, Python, SQL, HTML/CSS, JavaScript, Go, Relational Databases, PostgreSQL, MySQL` |
| bti | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "36ba5d90413776ca94784c4d4c9e5c931925fd3fa26bbfcce1053445977ef0cb"` | `skill_fit_cache.skills_text_hash: "e11115047f0b3a8f89bebfd7fb968940d894cdd84c57aa857bce9c3ad2e7ee5d"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "Python"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "Relational Databases"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "HTML/CSS"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "JavaScript"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.before[6]: "Go"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.before[7]: "PostgreSQL"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.before[8]: "MySQL"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "HTML/CSS"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "JavaScript"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "Go"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.after[6]: "Relational Databases"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.after[7]: "PostgreSQL"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.after[8]: "MySQL"` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| bti | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| cardinal | holdout | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, SQL, PostgreSQL, Go, Python, MongoDB` | `  \item \textbf{Languages \& Databases:} Java, SQL, Go, Python, PostgreSQL, MongoDB` |
| cardinal | holdout | report | S | `skill_fit_cache.skills_text_hash: "7f4964ba4de79b823a3edc24f8cd23f7a2a08c3c06e4d8a9896ff522a8f31cc4"` | `skill_fit_cache.skills_text_hash: "0a277f88827aef5376e9f882f9fe37843d9e823e84efe005df2e59c214053974"` |
| cardinal | holdout | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| cardinal | holdout | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| cardinal | holdout | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| cardinal | holdout | report | S | (none) | `skills_lines_v348c.before[3]: "Go"` |
| cardinal | holdout | report | S | (none) | `skills_lines_v348c.before[4]: "Python"` |
| cardinal | holdout | report | S | (none) | `skills_lines_v348c.before[5]: "MongoDB"` |
| cardinal | holdout | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| cardinal | holdout | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| cardinal | holdout | report | S | (none) | `skills_lines_v348c.after[2]: "Go"` |
| cardinal | holdout | report | S | (none) | `skills_lines_v348c.after[3]: "Python"` |
| cardinal | holdout | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| cardinal | holdout | report | S | (none) | `skills_lines_v348c.after[5]: "MongoDB"` |
| cardinal | holdout | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| cardinal | holdout | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| chewy | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL, NoSQL, Java, PostgreSQL, Go, MongoDB, MySQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, Go, NoSQL, PostgreSQL, MongoDB, MySQL` |
| chewy | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "3cea1d5e454b28c4a5a2db3eb8417a35907c4324a5874c070c300138a3bdfbec"` | `skill_fit_cache.skills_text_hash: "739726651da034df1626f9d0dd91666928b96ef73697f04fb6b5ba36ab3aeaac"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "NoSQL"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "PostgreSQL"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "Go"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.before[6]: "MongoDB"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.before[7]: "MySQL"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "NoSQL"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "PostgreSQL"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.after[6]: "MongoDB"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.after[7]: "MySQL"` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| chewy | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| cobalt | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, PostgreSQL, SQL, Java, Go, MySQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, Go, PostgreSQL, MySQL` |
| cobalt | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "53511d090cd8d6b26afcaf899ff143e8c38458f4298babb1bf7c0456590a8cdd"` | `skill_fit_cache.skills_text_hash: "82cd66353b5e7bdadf3efe678a8eae5930e3588c039585bbe1dd66fcb4963c21"` |
| cobalt | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| cobalt | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| cobalt | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "SQL"` |
| cobalt | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| cobalt | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "Go"` |
| cobalt | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| cobalt | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| cobalt | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| cobalt | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| cobalt | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| cobalt | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| cobalt | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| cobalt | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| cobalt | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| commure | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, Go, PostgreSQL, MongoDB, SQL, Python` | `  \item \textbf{Languages \& Databases:} Java, Go, SQL, Python, PostgreSQL, MongoDB` |
| commure | v340_original | report | S | `skill_fit_cache.skills_text_hash: "defb995f282985753225917f16f5d3a412d696ca667f3bb49aeb672d92599f0f"` | `skill_fit_cache.skills_text_hash: "c54e803cd5dc9495fff44c3eea3496ef358a7c238cb25f79b266112c1b366a75"` |
| commure | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| commure | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Go"` |
| commure | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| commure | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "MongoDB"` |
| commure | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| commure | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "Python"` |
| commure | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| commure | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Go"` |
| commure | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| commure | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Python"` |
| commure | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| commure | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MongoDB"` |
| commure | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| commure | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| dominos | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL, PostgreSQL, Java, Go, MySQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, Go, PostgreSQL, MySQL` |
| dominos | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "3f1d9bab3a89820c1ccf4305a96e96f43c6a2107622a6fce9c5216f403f3f35f"` | `skill_fit_cache.skills_text_hash: "c9e5211a9f7f4ed9bc2ce0211e7708bfa7d84667a588f2928a17828890004bcc"` |
| dominos | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| dominos | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| dominos | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| dominos | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| dominos | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "Go"` |
| dominos | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| dominos | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| dominos | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| dominos | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| dominos | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| dominos | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| dominos | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| dominos | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| dominos | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| doordash | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} SQL, NoSQL, Java, Go, PostgreSQL, Python, MongoDB, MySQL` | `  \item \textbf{Languages \& Databases:} SQL, Java, Go, Python, NoSQL, PostgreSQL, MongoDB, MySQL` |
| doordash | v340_original | report | S | `skill_fit_cache.skills_text_hash: "759e05ebb778fd295a82dbb451cb9d8e6e8258173d8860e114044ea2e1439a4f"` | `skill_fit_cache.skills_text_hash: "908c6e715e67621de3e2ee7a1c0e071cf2cf489371b422c724471228b9b87fcd"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "SQL"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "NoSQL"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Go"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "PostgreSQL"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "Python"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "MongoDB"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.before[7]: "MySQL"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "SQL"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Go"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Python"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "NoSQL"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "PostgreSQL"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "MongoDB"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.after[7]: "MySQL"` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| doordash | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| doordash_mdx | v342_new | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, PostgreSQL, Java, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, Java, SQL, PostgreSQL, MySQL` |
| doordash_mdx | v342_new | report | S | `skill_fit_cache.skills_text_hash: "10dabaa81cd4ceb434f8bd498a006bff428ded71daf9e33391a9aff06956d739"` | `skill_fit_cache.skills_text_hash: "648b6dc2683677eb0d310fbc0a955422d482180104d0ee5ac2853008891bee24"` |
| doordash_mdx | v342_new | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| doordash_mdx | v342_new | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| doordash_mdx | v342_new | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| doordash_mdx | v342_new | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| doordash_mdx | v342_new | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| doordash_mdx | v342_new | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| doordash_mdx | v342_new | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| doordash_mdx | v342_new | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| doordash_mdx | v342_new | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| doordash_mdx | v342_new | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| doordash_mdx | v342_new | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| doordash_mdx | v342_new | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| elevenlabs | v342_new | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, PostgreSQL, Java, Go, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, Java, Go, SQL, PostgreSQL, MySQL` |
| elevenlabs | v342_new | report | S | `skill_fit_cache.skills_text_hash: "466c81134f4456ad00b1d98e76d9e4c69aa9c8b8a3b33dcc9a1aa9cd04468171"` | `skill_fit_cache.skills_text_hash: "91f0fd40dec5e7061b2880633e3ee022d068d1ce20bb29e887b39bbfed71f6f3"` |
| elevenlabs | v342_new | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| elevenlabs | v342_new | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| elevenlabs | v342_new | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| elevenlabs | v342_new | report | S | (none) | `skills_lines_v348c.before[3]: "Go"` |
| elevenlabs | v342_new | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| elevenlabs | v342_new | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| elevenlabs | v342_new | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| elevenlabs | v342_new | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| elevenlabs | v342_new | report | S | (none) | `skills_lines_v348c.after[2]: "Go"` |
| elevenlabs | v342_new | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| elevenlabs | v342_new | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| elevenlabs | v342_new | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| elevenlabs | v342_new | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| elevenlabs | v342_new | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| engen | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, NoSQL, HTML/CSS, Java, JavaScript, Go, MongoDB, SQL, PostgreSQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, HTML/CSS, Java, JavaScript, Go, SQL, NoSQL, MongoDB, PostgreSQL, MySQL` |
| engen | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "bfb891693f3befc2cb4a7d68b022a9ccd183df6cbd8cab56a79e71b8df1a7573"` | `skill_fit_cache.skills_text_hash: "eafd43db9ba453ba5e7c02f9e8a08d23afbc4643b35749e42043426b959a699e"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "NoSQL"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "HTML/CSS"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "JavaScript"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "Go"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.before[6]: "MongoDB"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.before[7]: "SQL"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.before[8]: "PostgreSQL"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.before[9]: "MySQL"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "HTML/CSS"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "JavaScript"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "Go"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "SQL"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.after[6]: "NoSQL"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.after[7]: "MongoDB"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.after[8]: "PostgreSQL"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.after[9]: "MySQL"` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| engen | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| fanatics | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, NoSQL, Go, PostgreSQL, Python, MongoDB, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Java, Go, Python, SQL, NoSQL, PostgreSQL, MongoDB, MySQL` |
| fanatics | v340_original | report | S | `skill_fit_cache.skills_text_hash: "70cd5fa76e974522f3e8937bb01f4927b29662a266413c1680164ccab931ee96"` | `skill_fit_cache.skills_text_hash: "d7f32b1ccdd6f3299d30c80470518df668a6ed3d13483a88e7d64b5a5ef7e924"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "NoSQL"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Go"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "Python"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MongoDB"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "SQL"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.before[7]: "MySQL"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Go"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Python"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "NoSQL"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "PostgreSQL"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "MongoDB"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.after[7]: "MySQL"` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| fanatics | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| figure | v342_new | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, C, Java, PostgreSQL, SQL` | `  \item \textbf{Languages \& Databases:} Python, C, Java, SQL, PostgreSQL` |
| figure | v342_new | report | S | `skill_fit_cache.skills_text_hash: "692aebd00fb7761ce03204469de1c51ccab8b0b9f57eea2038dbc0eb1be13972"` | `skill_fit_cache.skills_text_hash: "e274116059549a60502005228fb8e1b5452cb9a7ce0d7deab06b32499fe20d43"` |
| figure | v342_new | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| figure | v342_new | report | S | (none) | `skills_lines_v348c.before[1]: "C"` |
| figure | v342_new | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| figure | v342_new | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| figure | v342_new | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| figure | v342_new | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| figure | v342_new | report | S | (none) | `skills_lines_v348c.after[1]: "C"` |
| figure | v342_new | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| figure | v342_new | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| figure | v342_new | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| figure | v342_new | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| figure | v342_new | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| flowgen | v341_tune | report | S (amendment S-A1) | `skill_fit_cache.skills_text_hash: "615f9f95162bbf3555bb7915422cabec4a8a142902b40246d8eff248d2b1bcaa"` | `skill_fit_cache.skills_text_hash: "e47e9761b3dab3301607b6996bda20d568604aa87d9e680e0f3c7df57cc8ac78"` |
| frontend | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} JavaScript, HTML/CSS, Java, Go, Python, MongoDB, SQL, PostgreSQL, MySQL` | `  \item \textbf{Languages \& Databases:} JavaScript, HTML/CSS, Java, Go, Python, SQL, MongoDB, PostgreSQL, MySQL` |
| frontend | v340_original | report | S | `skill_fit_cache.skills_text_hash: "b657146edb0b325daa172f15e58ba0167950d91297907b0206d30f886fb3e947"` | `skill_fit_cache.skills_text_hash: "ce22051671ad5142ca6eb5f1fe9d6d4145f72b663411e2bcbb56156cb4ad6db3"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "JavaScript"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "HTML/CSS"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Go"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "Python"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MongoDB"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "SQL"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.before[7]: "PostgreSQL"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.before[8]: "MySQL"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "JavaScript"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "HTML/CSS"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "Python"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "SQL"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "MongoDB"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.after[7]: "PostgreSQL"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.after[8]: "MySQL"` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| frontend | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| fulfillment | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, PostgreSQL, Python, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Java, Python, SQL, PostgreSQL, MySQL` |
| fulfillment | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "eb0981243d48b613443fccc93bf10629ec6c0a7f42d3820691aba368e639fdf7"` | `skill_fit_cache.skills_text_hash: "36804136b7707a5510c884db3ecc546cb7ee7f0a669b4666b14d4568c65ca313"` |
| fulfillment | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| fulfillment | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| fulfillment | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "Python"` |
| fulfillment | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| fulfillment | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| fulfillment | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| fulfillment | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| fulfillment | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| fulfillment | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| fulfillment | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| fulfillment | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| fulfillment | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| ga_asi | holdout | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, PostgreSQL, Java, C, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, Java, C, SQL, PostgreSQL, MySQL` |
| ga_asi | holdout | report | S | `skill_fit_cache.skills_text_hash: "aa8138cdbca774f45bbb6ef529de47b42a7be88b7be4d800db3a6fc671d9439f"` | `skill_fit_cache.skills_text_hash: "b906cf9b7310740d468fdabfe079ddf4c24d0e76561f30ec0410d9578c89b5bc"` |
| ga_asi | holdout | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| ga_asi | holdout | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| ga_asi | holdout | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| ga_asi | holdout | report | S | (none) | `skills_lines_v348c.before[3]: "C"` |
| ga_asi | holdout | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| ga_asi | holdout | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| ga_asi | holdout | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| ga_asi | holdout | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| ga_asi | holdout | report | S | (none) | `skills_lines_v348c.after[2]: "C"` |
| ga_asi | holdout | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| ga_asi | holdout | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| ga_asi | holdout | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| ga_asi | holdout | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| ga_asi | holdout | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| garmin | holdout | resume_tex | S | `  \item \textbf{Languages \& Databases:} C, Java, PostgreSQL, Python, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} C, Java, Python, SQL, PostgreSQL, MySQL` |
| garmin | holdout | report | S | `skill_fit_cache.skills_text_hash: "49932f3d265b351dc208650e0ed5e9261e8b524b49e826129a8143c5206d0782"` | `skill_fit_cache.skills_text_hash: "b20a70abf51c0255ee72d9be358fd39d8574e7e6555c9f6cb631886b3bea9ea2"` |
| garmin | holdout | report | S | (none) | `skills_lines_v348c.before[0]: "C"` |
| garmin | holdout | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| garmin | holdout | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| garmin | holdout | report | S | (none) | `skills_lines_v348c.before[3]: "Python"` |
| garmin | holdout | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| garmin | holdout | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| garmin | holdout | report | S | (none) | `skills_lines_v348c.after[0]: "C"` |
| garmin | holdout | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| garmin | holdout | report | S | (none) | `skills_lines_v348c.after[2]: "Python"` |
| garmin | holdout | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| garmin | holdout | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| garmin | holdout | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| garmin | holdout | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| garmin | holdout | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| google_sre | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Java, Go, PostgreSQL, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, Java, Go, SQL, PostgreSQL, MySQL` |
| google_sre | v340_original | report | S | `skill_fit_cache.skills_text_hash: "6136c572e84d20ab16721b571fb167ff9415314711874724e9132d2f44df0ba4"` | `skill_fit_cache.skills_text_hash: "fe3fc22d10cb6a2eb5712aef0a013f393c8f7e23ee62a04a009abcf18d8af205"` |
| google_sre | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| google_sre | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| google_sre | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Go"` |
| google_sre | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| google_sre | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| google_sre | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| google_sre | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| google_sre | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| google_sre | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Go"` |
| google_sre | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| google_sre | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| google_sre | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| google_sre | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| google_sre | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| halcyon | holdout | resume_tex | S | `  \item \textbf{Languages \& Databases:} SQL, Python, Relational Databases, PostgreSQL, MySQL, Java` | `  \item \textbf{Languages \& Databases:} SQL, Python, Java, Relational Databases, PostgreSQL, MySQL` |
| halcyon | holdout | report | S | `skill_fit_cache.skills_text_hash: "f68411d9f0f4cd8f7abfb7ca0c27694bdfdfb278f3e5a8bff9cd1ceb311d26a1"` | `skill_fit_cache.skills_text_hash: "2b02059f12dbf37151e98c6fb105b5508702e29cd5b95db0a3005eebcc74942d"` |
| halcyon | holdout | report | S | (none) | `skills_lines_v348c.before[0]: "SQL"` |
| halcyon | holdout | report | S | (none) | `skills_lines_v348c.before[1]: "Python"` |
| halcyon | holdout | report | S | (none) | `skills_lines_v348c.before[2]: "Relational Databases"` |
| halcyon | holdout | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| halcyon | holdout | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| halcyon | holdout | report | S | (none) | `skills_lines_v348c.before[5]: "Java"` |
| halcyon | holdout | report | S | (none) | `skills_lines_v348c.after[0]: "SQL"` |
| halcyon | holdout | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| halcyon | holdout | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| halcyon | holdout | report | S | (none) | `skills_lines_v348c.after[3]: "Relational Databases"` |
| halcyon | holdout | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| halcyon | holdout | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| halcyon | holdout | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| halcyon | holdout | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| helix | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, SQL, PostgreSQL, Python, MySQL` | `  \item \textbf{Languages \& Databases:} Java, SQL, Python, PostgreSQL, MySQL` |
| helix | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "bc099a5bb82707b4f57469a5a13696607df4ab8ede8798134bd0e35362c6e991"` | `skill_fit_cache.skills_text_hash: "b23bc35179fbf67d8ae1360d26e6280d727fe7c89865c3daccb32fe10c80a3db"` |
| helix | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| helix | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| helix | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| helix | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "Python"` |
| helix | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| helix | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| helix | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| helix | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Python"` |
| helix | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| helix | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| helix | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| helix | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| impact | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, Relational Databases, MySQL, PostgreSQL, Python, SQL` | `  \item \textbf{Languages \& Databases:} Java, Python, SQL, Relational Databases, MySQL, PostgreSQL` |
| impact | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "72a053b10dc43784c6da5af5ea3fc05040d18a0c18ef0236fb496b0ef27c2a58"` | `skill_fit_cache.skills_text_hash: "a60673c605699ba7607532b9c5b155b373d1beba22510469c13877a95838daef"` |
| impact | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| impact | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "Relational Databases"` |
| impact | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "MySQL"` |
| impact | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| impact | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "Python"` |
| impact | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "SQL"` |
| impact | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| impact | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| impact | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| impact | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "Relational Databases"` |
| impact | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| impact | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "PostgreSQL"` |
| impact | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| impact | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| inspire11 | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} JavaScript, Java, Python, PostgreSQL, Relational Databases, MongoDB, MySQL, SQL` | `  \item \textbf{Languages \& Databases:} JavaScript, Java, Python, SQL, PostgreSQL, Relational Databases, MongoDB, MySQL` |
| inspire11 | v340_original | report | S | `skill_fit_cache.skills_text_hash: "e09a04540b1cb1e14bcc909f6fcd00768b483b1db7263a5599fa87641c92ea8f"` | `skill_fit_cache.skills_text_hash: "a7a15ae91fb8559e3a69bae3aa5a0287780050fe9c11d3fe0a689026ee301043"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "JavaScript"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Python"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "Relational Databases"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MongoDB"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "MySQL"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.before[7]: "SQL"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "JavaScript"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Python"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "Relational Databases"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "MongoDB"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.after[7]: "MySQL"` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| inspire11 | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| instalily | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Java, PostgreSQL, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, Java, SQL, PostgreSQL, MySQL` |
| instalily | v340_original | report | S | `skill_fit_cache.skills_text_hash: "3e1a611de6692818a205038f3a6af194ecfbdd04dbcf17bd0ef450a28183adce"` | `skill_fit_cache.skills_text_hash: "45d69b3842518d155a2552a36386242a361c7ae8f72aa954f227a1b62dbf7199"` |
| instalily | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| instalily | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| instalily | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| instalily | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| instalily | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| instalily | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| instalily | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| instalily | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| instalily | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| instalily | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| instalily | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| instalily | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| ios_randstad | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, PostgreSQL, Python, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Java, Python, SQL, PostgreSQL, MySQL` |
| ios_randstad | v340_original | report | S | `skill_fit_cache.skills_text_hash: "fba6d1e20ab7d986fba31d633e905d0cf7deeed5d433dea87e6106cbfb02611c"` | `skill_fit_cache.skills_text_hash: "227a29b7b17a32fbdb22a93d042e5e512b36b29b682f7b40b78accffff0d3dde"` |
| ios_randstad | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| ios_randstad | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| ios_randstad | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Python"` |
| ios_randstad | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| ios_randstad | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| ios_randstad | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| ios_randstad | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| ios_randstad | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| ios_randstad | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| ios_randstad | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| ios_randstad | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| ios_randstad | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| ironvale | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, Python, C, PostgreSQL, SQL` | `  \item \textbf{Languages \& Databases:} Java, Python, C, SQL, PostgreSQL` |
| ironvale | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "38aad833f2db6f8e894bfc5ddcb36a25454dc15bcf4e56816ac896898d61844d"` | `skill_fit_cache.skills_text_hash: "3cf7023f9e04823e70c296bdb9f7fa9bf9187b9638b7f064a4ab4e70b6a8b582"` |
| ironvale | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| ironvale | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "Python"` |
| ironvale | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "C"` |
| ironvale | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| ironvale | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| ironvale | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| ironvale | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| ironvale | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "C"` |
| ironvale | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| ironvale | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| ironvale | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| ironvale | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| ixl | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Java, JavaScript, Go, PostgreSQL, SQL` | `  \item \textbf{Languages \& Databases:} Python, Java, JavaScript, Go, SQL, PostgreSQL` |
| ixl | v340_original | report | S | `skill_fit_cache.skills_text_hash: "13ba867a0a99afb7d5cf0c6be38f6ac9e6994b6068e0c423d2ad9d54470d4867"` | `skill_fit_cache.skills_text_hash: "6d504af3797e4a0c63db7644934ef2325f74801a7c94fc1222279d6116ecb108"` |
| ixl | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| ixl | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| ixl | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "JavaScript"` |
| ixl | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Go"` |
| ixl | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "PostgreSQL"` |
| ixl | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "SQL"` |
| ixl | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| ixl | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| ixl | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "JavaScript"` |
| ixl | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| ixl | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "SQL"` |
| ixl | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "PostgreSQL"` |
| ixl | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| ixl | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| jobgether | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} JavaScript, Relational Databases, PostgreSQL, MySQL, Java, Python, SQL` | `  \item \textbf{Languages \& Databases:} JavaScript, Java, Python, SQL, Relational Databases, PostgreSQL, MySQL` |
| jobgether | v340_original | report | S | `skill_fit_cache.skills_text_hash: "f2d862305b207959eb20e7510e7647269416d5ef81fb25bfbda3f6233008e214"` | `skill_fit_cache.skills_text_hash: "727cfeb80c02abca6d799a8c6d87809774810f3fd3cfb50ec49ad3ad00ab1bbf"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "JavaScript"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Relational Databases"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "MySQL"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "Java"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "Python"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "SQL"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "JavaScript"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Python"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "Relational Databases"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "PostgreSQL"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "MySQL"` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| jobgether | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| klaviyo | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, PostgreSQL, Java, SQL` | `  \item \textbf{Languages \& Databases:} Python, Java, SQL, PostgreSQL` |
| klaviyo | v340_original | report | S | `skill_fit_cache.skills_text_hash: "81cbc73b7466add156074f8858266f0d0ddce29842ba4b95c7ab28112c8170f3"` | `skill_fit_cache.skills_text_hash: "f44c5e111029df016873c93d64f7f00294dbebbbbd70f0ea7cef53111befbd6b"` |
| klaviyo | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| klaviyo | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| klaviyo | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| klaviyo | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| klaviyo | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| klaviyo | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| klaviyo | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| klaviyo | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| klaviyo | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| klaviyo | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| l3harris | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} C, Java, PostgreSQL, Python, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} C, Java, Python, SQL, PostgreSQL, MySQL` |
| l3harris | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "2cf4f86e4cf877ec18b134b4cca7dc8796b7b6fe539b7ba08ddc222d165c0444"` | `skill_fit_cache.skills_text_hash: "df2c35a7865adf56f5b47d02f7d794bf7d67cd927ef3236ca389c5f3d206c182"` |
| l3harris | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "C"` |
| l3harris | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| l3harris | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| l3harris | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "Python"` |
| l3harris | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| l3harris | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| l3harris | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "C"` |
| l3harris | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| l3harris | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Python"` |
| l3harris | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| l3harris | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| l3harris | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| l3harris | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| l3harris | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| laminar | v344_new | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Java, PostgreSQL, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, Java, SQL, PostgreSQL, MySQL` |
| laminar | v344_new | report | S | `skill_fit_cache.skills_text_hash: "2fc7acc30d39407c4bcf5397fbaa70e584120b1ef7f8d1b8909ba5f1f73d6d9b"` | `skill_fit_cache.skills_text_hash: "4241964ed15d251852ca2294d2e55a0beab794002ae29cf26cc6904ba8dfc423"` |
| laminar | v344_new | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| laminar | v344_new | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| laminar | v344_new | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| laminar | v344_new | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| laminar | v344_new | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| laminar | v344_new | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| laminar | v344_new | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| laminar | v344_new | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| laminar | v344_new | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| laminar | v344_new | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| laminar | v344_new | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| laminar | v344_new | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| linkedin | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Relational Databases, Java, PostgreSQL, JavaScript, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, Java, JavaScript, SQL, Relational Databases, PostgreSQL, MySQL` |
| linkedin | v340_original | report | S | `skill_fit_cache.skills_text_hash: "9e6c86bd67156c0690b18b61c4d98fee1dc8719b43cbf8a13b249ef8c17a72fc"` | `skill_fit_cache.skills_text_hash: "5210ca32fe3294ccec6f3bf85999a1bf70950f419c64da3e6c9593d88d10ad90"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Relational Databases"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "JavaScript"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "SQL"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "MySQL"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "JavaScript"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "Relational Databases"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "PostgreSQL"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "MySQL"` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| linkedin | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| loopwell | holdout | resume_tex | S | `  \item \textbf{Languages \& Databases:} JavaScript, PostgreSQL, SQL, Python, Java, Go, MongoDB, MySQL` | `  \item \textbf{Languages \& Databases:} JavaScript, SQL, Python, Java, Go, PostgreSQL, MongoDB, MySQL` |
| loopwell | holdout | report | S | `skill_fit_cache.skills_text_hash: "09b8c607d95eb0ca4e32082c645760a39693cfa631e7c0ec2e61b77b53e3160d"` | `skill_fit_cache.skills_text_hash: "585261dafc0630eba48e74b2db512fc83a9645e928216ad48e2baec45a4d0b62"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.before[0]: "JavaScript"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.before[2]: "SQL"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.before[3]: "Python"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.before[4]: "Java"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.before[5]: "Go"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.before[6]: "MongoDB"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.before[7]: "MySQL"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.after[0]: "JavaScript"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.after[2]: "Python"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.after[3]: "Java"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.after[4]: "Go"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.after[5]: "PostgreSQL"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.after[6]: "MongoDB"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.after[7]: "MySQL"` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| loopwell | holdout | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| mastercard | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, Relational Databases, SQL, JavaScript, PostgreSQL, Python, Go` | `  \item \textbf{Languages \& Databases:} Java, SQL, JavaScript, Python, Go, Relational Databases, PostgreSQL` |
| mastercard | v340_original | report | S | `skill_fit_cache.skills_text_hash: "1fe0ef05d1d33adafd4772ecc7d770adee53e2f6938d5d8787000696d8f3520e"` | `skill_fit_cache.skills_text_hash: "77bb376e36c5d05beb4c560905cfc30295b093f7931c2bda55182b68d4039906"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Relational Databases"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "SQL"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "JavaScript"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "PostgreSQL"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "Python"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "Go"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "JavaScript"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Python"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "Go"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "Relational Databases"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "PostgreSQL"` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| mastercard | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| meridian_bank | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL, PostgreSQL, Java, MySQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, PostgreSQL, MySQL` |
| meridian_bank | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "c04d25e2102735dbd63bf84c02bcfaafe1b45684ce67ab198e41659a04635059"` | `skill_fit_cache.skills_text_hash: "8e2274fb2d11f1ba252b50b4bfa847f317116eb95cf9645d5822acc2716f6373"` |
| meridian_bank | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| meridian_bank | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| meridian_bank | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| meridian_bank | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| meridian_bank | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| meridian_bank | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| meridian_bank | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| meridian_bank | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| meridian_bank | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| meridian_bank | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| meridian_bank | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| meridian_bank | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| meridian_sw | holdout | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Relational Databases, Java, JavaScript, Go, SQL, PostgreSQL, MongoDB` | `  \item \textbf{Languages \& Databases:} Python, Java, JavaScript, Go, SQL, Relational Databases, PostgreSQL, MongoDB` |
| meridian_sw | holdout | report | S | `skill_fit_cache.skills_text_hash: "efad0cc7a799271bec1fa49a76b134c6a682532dbefd8f10e52b40c976085deb"` | `skill_fit_cache.skills_text_hash: "a0f05e08a811ad72fb83220612232499f554c637dd5901cd338ae39cb03ed4e6"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.before[1]: "Relational Databases"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.before[3]: "JavaScript"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.before[4]: "Go"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.before[5]: "SQL"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.before[6]: "PostgreSQL"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.before[7]: "MongoDB"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.after[2]: "JavaScript"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.after[4]: "SQL"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.after[5]: "Relational Databases"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.after[6]: "PostgreSQL"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.after[7]: "MongoDB"` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| meridian_sw | holdout | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| meritore_capgemini | v347_new | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Java, PostgreSQL, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, Java, SQL, PostgreSQL, MySQL` |
| meritore_capgemini | v347_new | report | S | `skill_fit_cache.skills_text_hash: "5fd9de1d32b4259572da11cfe967a8e52ca90747f05dbbf14dcc9c5125787056"` | `skill_fit_cache.skills_text_hash: "dd29781e33c2c266d0b03543a57099384820d8ec6386980294a5c959835a2e6d"` |
| meritore_capgemini | v347_new | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| meritore_capgemini | v347_new | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| meritore_capgemini | v347_new | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| meritore_capgemini | v347_new | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| meritore_capgemini | v347_new | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| meritore_capgemini | v347_new | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| meritore_capgemini | v347_new | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| meritore_capgemini | v347_new | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| meritore_capgemini | v347_new | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| meritore_capgemini | v347_new | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| meritore_capgemini | v347_new | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| meritore_capgemini | v347_new | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| microsoft | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, PostgreSQL, JavaScript, MySQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, JavaScript, PostgreSQL, MySQL` |
| microsoft | v340_original | report | S | `skill_fit_cache.skills_text_hash: "d6f03c9d1b82c342a05d43bde8992aec5aefeef0f3c35daf6eae5c9cbc569873"` | `skill_fit_cache.skills_text_hash: "5636b5d2163416a29639fb0b2ba15e41ec157e17ab15d7fdb91a4284bca99f2f"` |
| microsoft | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| microsoft | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| microsoft | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| microsoft | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| microsoft | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "JavaScript"` |
| microsoft | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| microsoft | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| microsoft | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| microsoft | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| microsoft | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "JavaScript"` |
| microsoft | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| microsoft | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| microsoft | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| microsoft | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| ng_fullstack | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} JavaScript, Relational Databases, PostgreSQL, Java, Go, Python, MongoDB, SQL` | `  \item \textbf{Languages \& Databases:} JavaScript, Java, Go, Python, SQL, Relational Databases, PostgreSQL, MongoDB` |
| ng_fullstack | v340_original | report | S | `skill_fit_cache.skills_text_hash: "cb10f2c1c284c21c09476d44733770c1341c5d865989486e4ffbfcb4feb3ef43"` | `skill_fit_cache.skills_text_hash: "e7a2c0d1384c0a79cf929b36d726eb4a41783a9624d125c7d73044c98ce29436"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "JavaScript"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Relational Databases"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "Go"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "Python"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "MongoDB"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.before[7]: "SQL"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "JavaScript"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Go"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Python"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "SQL"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "Relational Databases"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "PostgreSQL"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.after[7]: "MongoDB"` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| ng_fullstack | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| nimble | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} SQL, Java, PostgreSQL, Python, MySQL` | `  \item \textbf{Languages \& Databases:} SQL, Java, Python, PostgreSQL, MySQL` |
| nimble | v340_original | report | S | `skill_fit_cache.skills_text_hash: "4ea7d2c6456ef051932210129121f15f48ea8ed73fc8cd7bbcda40977ae66e2d"` | `skill_fit_cache.skills_text_hash: "1a6bd5997dff7711c1a1e6b325566da01f2b4a9633d2908c5f6d0545bff76c79"` |
| nimble | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "SQL"` |
| nimble | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| nimble | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| nimble | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Python"` |
| nimble | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| nimble | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "SQL"` |
| nimble | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| nimble | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Python"` |
| nimble | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| nimble | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| nimble | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| nimble | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| northbeam | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, PostgreSQL, Relational Databases, SQL, Go, Python, MongoDB` | `  \item \textbf{Languages \& Databases:} Java, SQL, Go, Python, PostgreSQL, Relational Databases, MongoDB` |
| northbeam | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "4e90a05dbdf25c602b940661b62736b785e428d84772d532b51ba1e3ce89a692"` | `skill_fit_cache.skills_text_hash: "b73c55902965e2e4f34c7a4a460f228b673f55c1203e9de0f2530dbb5db756dd"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "Relational Databases"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "Go"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "Python"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.before[6]: "MongoDB"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Go"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "Python"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "Relational Databases"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.after[6]: "MongoDB"` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| northbeam | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| novita | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Java, PostgreSQL, SQL` | `  \item \textbf{Languages \& Databases:} Python, Java, SQL, PostgreSQL` |
| novita | v340_original | report | S | `skill_fit_cache.skills_text_hash: "008c3f2b1e49f1bd2337e5bdf5e38300fb6d3ef795ab25b09948ab450baf5bc8"` | `skill_fit_cache.skills_text_hash: "cd2a4a4acadf7688351f17eb1f738079597a254661ef0aea3208c7c010e80cdf"` |
| novita | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| novita | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| novita | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| novita | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| novita | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| novita | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| novita | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| novita | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| novita | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| novita | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| nvidia_devtech | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, C, PostgreSQL, Java, SQL` | `  \item \textbf{Languages \& Databases:} Python, C, Java, SQL, PostgreSQL` |
| nvidia_devtech | v340_original | report | S | `skill_fit_cache.skills_text_hash: "9ed2fbc511b48f6a3ad2b1e0eefade9a268419d8d4285d4ac78ad8ff86fdea8e"` | `skill_fit_cache.skills_text_hash: "39ef781937c45bf7acd6cc8803b472180e49e77ce3f91de7a483876af5d0e5bb"` |
| nvidia_devtech | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| nvidia_devtech | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "C"` |
| nvidia_devtech | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| nvidia_devtech | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| nvidia_devtech | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| nvidia_devtech | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| nvidia_devtech | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "C"` |
| nvidia_devtech | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| nvidia_devtech | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| nvidia_devtech | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| nvidia_devtech | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| nvidia_devtech | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| otter | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, PostgreSQL, Java, Go, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, Java, Go, SQL, PostgreSQL, MySQL` |
| otter | v340_original | report | S | `skill_fit_cache.skills_text_hash: "f8a5c77ea7eebff786e90ebe798beeba5937b065dd582823f41e472441f472ff"` | `skill_fit_cache.skills_text_hash: "d49725775f62865847d595df62dbb035e695cad75522ac4bdfdd13e58d08166e"` |
| otter | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| otter | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| otter | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| otter | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Go"` |
| otter | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| otter | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| otter | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| otter | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| otter | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Go"` |
| otter | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| otter | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| otter | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| otter | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| otter | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| paypal | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, PostgreSQL, Python, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Java, Python, SQL, PostgreSQL, MySQL` |
| paypal | v340_original | report | S | `skill_fit_cache.skills_text_hash: "2994d7e8a6eeb94abe160487ff9e4809333d5f1a3c3df98915bf17dde49c254d"` | `skill_fit_cache.skills_text_hash: "53428b0fc29523dfdf10e24696280de4c53860ae1f0775bb10c29f9a5a651428"` |
| paypal | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| paypal | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| paypal | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Python"` |
| paypal | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| paypal | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| paypal | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| paypal | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| paypal | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| paypal | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| paypal | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| paypal | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| paypal | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| perplexity | holdout | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL, PostgreSQL, Java, Go, MySQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, Go, PostgreSQL, MySQL` |
| perplexity | holdout | report | S | `skill_fit_cache.skills_text_hash: "37f42c51d37ae43d64dc9479d0c00da52dd3cfe04394b18d23da41085f0cd175"` | `skill_fit_cache.skills_text_hash: "c2768858c4ae93074aef5f9b5db384c49781e1120507834f046407eb92a0af7a"` |
| perplexity | holdout | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| perplexity | holdout | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| perplexity | holdout | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| perplexity | holdout | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| perplexity | holdout | report | S | (none) | `skills_lines_v348c.before[4]: "Go"` |
| perplexity | holdout | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| perplexity | holdout | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| perplexity | holdout | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| perplexity | holdout | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| perplexity | holdout | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| perplexity | holdout | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| perplexity | holdout | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| perplexity | holdout | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| perplexity | holdout | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| pinecrest | holdout | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, SQL, Go, PostgreSQL, Python, MySQL` | `  \item \textbf{Languages \& Databases:} Java, SQL, Go, Python, PostgreSQL, MySQL` |
| pinecrest | holdout | report | S | `skill_fit_cache.skills_text_hash: "195fc83e24f9ab0955aa5803a39c12b4bbbde1b90b8b7a6697e342c849cab93f"` | `skill_fit_cache.skills_text_hash: "05df65c2c31e01e77dc771834b89d1fc0852e5ba68aa06ba6c9afba10ce2ab70"` |
| pinecrest | holdout | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| pinecrest | holdout | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| pinecrest | holdout | report | S | (none) | `skills_lines_v348c.before[2]: "Go"` |
| pinecrest | holdout | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| pinecrest | holdout | report | S | (none) | `skills_lines_v348c.before[4]: "Python"` |
| pinecrest | holdout | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| pinecrest | holdout | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| pinecrest | holdout | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| pinecrest | holdout | report | S | (none) | `skills_lines_v348c.after[2]: "Go"` |
| pinecrest | holdout | report | S | (none) | `skills_lines_v348c.after[3]: "Python"` |
| pinecrest | holdout | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| pinecrest | holdout | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| pinecrest | holdout | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| pinecrest | holdout | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| pinterest | holdout | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Java, PostgreSQL, SQL` | `  \item \textbf{Languages \& Databases:} Python, Java, SQL, PostgreSQL` |
| pinterest | holdout | report | S | `skill_fit_cache.skills_text_hash: "dcc3b522d8d50f49f867eddb890be70436a427f83e6a5fe391cebf872cb3b659"` | `skill_fit_cache.skills_text_hash: "8456b2a74b129393fd563580c03c6aa806bff92841852e51f33e46a549d0169d"` |
| pinterest | holdout | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| pinterest | holdout | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| pinterest | holdout | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| pinterest | holdout | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| pinterest | holdout | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| pinterest | holdout | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| pinterest | holdout | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| pinterest | holdout | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| pinterest | holdout | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| pinterest | holdout | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| pocketly | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, PostgreSQL, Python, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Java, Python, SQL, PostgreSQL, MySQL` |
| pocketly | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "ee8a014b38e4983cf4dbcf5291c667eadab28641ec0b1bdbc84dc630e882e3fd"` | `skill_fit_cache.skills_text_hash: "a0d88cf242f4e47dba95b9124ccc46b259bcedb279ce9065732ce53a08d6e4dd"` |
| pocketly | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| pocketly | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| pocketly | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "Python"` |
| pocketly | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| pocketly | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| pocketly | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| pocketly | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| pocketly | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| pocketly | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| pocketly | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| pocketly | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| pocketly | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| quora | v345_new | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, PostgreSQL` |
| quora | v345_new | report | S | `skill_fit_cache.skills_text_hash: "96287f8e4e1fa35b07d7da1deda56f18e7fde6f571455c955a2fea4d44995f84"` | `skill_fit_cache.skills_text_hash: "85632ecb6966ff27f7f7d53660044b2dd8f3cad45cf43bf6752f4bb5b0172d40"` |
| quora | v345_new | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| quora | v345_new | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| quora | v345_new | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| quora | v345_new | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| quora | v345_new | report | S | (none) | `skills_lines_v348c.after[2]: "PostgreSQL"` |
| quora | v345_new | report | S | (none) | `skills_lines_v348c.s2_added[0]: "PostgreSQL"` |
| quora | v345_new | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| raydar_backend | holdout | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, PostgreSQL, Python, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Java, Python, SQL, PostgreSQL, MySQL` |
| raydar_backend | holdout | report | S | `skill_fit_cache.skills_text_hash: "09c1c71e8b8e885f0e10ac0a442dd48192bc68764600c847957ddf173b75bbf1"` | `skill_fit_cache.skills_text_hash: "95b47b79dc647481c19db830c09110fdd02f83a5127cda3c637865dd75b103de"` |
| raydar_backend | holdout | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| raydar_backend | holdout | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| raydar_backend | holdout | report | S | (none) | `skills_lines_v348c.before[2]: "Python"` |
| raydar_backend | holdout | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| raydar_backend | holdout | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| raydar_backend | holdout | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| raydar_backend | holdout | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| raydar_backend | holdout | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| raydar_backend | holdout | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| raydar_backend | holdout | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| raydar_backend | holdout | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| raydar_backend | holdout | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| raydar_swe | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Java, PostgreSQL, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, Java, SQL, PostgreSQL, MySQL` |
| raydar_swe | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "4043f20df660e0acfb7e5d5356c22a2d7da91696f9e7c72327b5a432616bdb9a"` | `skill_fit_cache.skills_text_hash: "511d8f18c762a91de74a1ded714bf2f2f3479a97bd13948ac9fcc5ad62a7b10e"` |
| raydar_swe | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| raydar_swe | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| raydar_swe | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| raydar_swe | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| raydar_swe | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| raydar_swe | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| raydar_swe | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| raydar_swe | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| raydar_swe | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| raydar_swe | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| raydar_swe | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| raydar_swe | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| research_phd | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, SQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, PostgreSQL` |
| research_phd | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "e2d6e0340362899a32789f1c177a6a98213c1dc3b4e5664fc88f0c40b4d929b8"` | `skill_fit_cache.skills_text_hash: "b960d27b8750f11b4408d7dee629cc5d45de154965dd848298581318f8581c07"` |
| research_phd | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| research_phd | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| research_phd | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| research_phd | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| research_phd | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "PostgreSQL"` |
| research_phd | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added[0]: "PostgreSQL"` |
| research_phd | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| robot_sdet | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Java, PostgreSQL, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, Java, SQL, PostgreSQL, MySQL` |
| robot_sdet | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "29e2a44592c619454610b4817c4dfb5fe6b54122a682c332d8de1c71d4f1fc9a"` | `skill_fit_cache.skills_text_hash: "8dae25a65d0da883684707f1a84ca495c5bd5cc490f3107072295a353e63b242"` |
| robot_sdet | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| robot_sdet | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| robot_sdet | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| robot_sdet | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| robot_sdet | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| robot_sdet | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| robot_sdet | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| robot_sdet | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| robot_sdet | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| robot_sdet | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| robot_sdet | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| robot_sdet | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| rocketmoney | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} JavaScript, Relational Databases, Python, Java, Go, MongoDB, SQL` | `  \item \textbf{Languages \& Databases:} JavaScript, Python, Java, Go, SQL, Relational Databases, MongoDB` |
| rocketmoney | v340_original | report | S | `skill_fit_cache.skills_text_hash: "3e991ae20581325b66314ad02083927d49b5adec4c4d98fb5274cfc0fa62605a"` | `skill_fit_cache.skills_text_hash: "7ad4f2bfefea7a8d8a80843c429d366e425e968895bb9f0751fddbd24070bed6"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "JavaScript"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Relational Databases"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Python"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "Go"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MongoDB"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "SQL"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "JavaScript"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "SQL"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "Relational Databases"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "MongoDB"` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| rocketmoney | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| rockstar | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Java, Go, PostgreSQL, MongoDB, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, Java, Go, SQL, PostgreSQL, MongoDB, MySQL` |
| rockstar | v340_original | report | S | `skill_fit_cache.skills_text_hash: "7b1465dd9bfea4c31b6b47ff9419020bcfc7e76c1bf7bb24176ed617c8441059"` | `skill_fit_cache.skills_text_hash: "e260f998be367b8b2b91d9f1d1a0558395e843eae2ebb77b0376ea4445390d92"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Go"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "MongoDB"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "SQL"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.before[6]: "MySQL"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Go"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MongoDB"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.after[6]: "MySQL"` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| rockstar | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| serco_snow | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} JavaScript, HTML/CSS, Relational Databases, Java, Go, Python, MongoDB, SQL, PostgreSQL, MySQL` | `  \item \textbf{Languages \& Databases:} JavaScript, HTML/CSS, Java, Go, Python, SQL, Relational Databases, MongoDB, PostgreSQL, MySQL` |
| serco_snow | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "d15e89e373f04613c12b464bf6f2ac6102adeaea31c754f01af3e7592dbb346e"` | `skill_fit_cache.skills_text_hash: "87fce8493991e64154a9e2b8fdf1f4a2e3c3614ec2a2eea694ac6d4ac5b62acd"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "JavaScript"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "HTML/CSS"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "Relational Databases"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "Go"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "Python"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.before[6]: "MongoDB"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.before[7]: "SQL"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.before[8]: "PostgreSQL"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.before[9]: "MySQL"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "JavaScript"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "HTML/CSS"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "Python"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "SQL"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.after[6]: "Relational Databases"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.after[7]: "MongoDB"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.after[8]: "PostgreSQL"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.after[9]: "MySQL"` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| serco_snow | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| serco_sw | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} JavaScript, HTML/CSS, Relational Databases, Java, Go, Python, MongoDB, SQL` | `  \item \textbf{Languages \& Databases:} JavaScript, HTML/CSS, Java, Go, Python, SQL, Relational Databases, MongoDB` |
| serco_sw | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "99990d7648c3e0af631d31692819a481930414baf8d9e4bce6ddaa42ae8fa104"` | `skill_fit_cache.skills_text_hash: "93c01f5d7b93f4001ae30701bf70c5d6199bd05516379ab4fc05539fe0c26ffa"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "JavaScript"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "HTML/CSS"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "Relational Databases"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "Go"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "Python"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.before[6]: "MongoDB"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.before[7]: "SQL"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "JavaScript"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "HTML/CSS"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "Python"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "SQL"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.after[6]: "Relational Databases"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.after[7]: "MongoDB"` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| serco_sw | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| spacexsi | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} PostgreSQL, Python, Java, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, Java, SQL, PostgreSQL, MySQL` |
| spacexsi | v340_original | report | S | `skill_fit_cache.skills_text_hash: "41b583f70143db98d5055f4ebccec4a00c0732914dc61578901001f36ca2adb2"` | `skill_fit_cache.skills_text_hash: "9cc205064bd26a52e1f5fc0238b61a85b2e99ba64230cacc11e297138db3ee89"` |
| spacexsi | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "PostgreSQL"` |
| spacexsi | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Python"` |
| spacexsi | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| spacexsi | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| spacexsi | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| spacexsi | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| spacexsi | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| spacexsi | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| spacexsi | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "PostgreSQL"` |
| spacexsi | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "MySQL"` |
| spacexsi | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| spacexsi | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| sparkline | holdout | resume_tex | S | `  \item \textbf{Languages \& Databases:} JavaScript, HTML/CSS, Java, Go, Python, MongoDB, SQL, PostgreSQL` | `  \item \textbf{Languages \& Databases:} JavaScript, HTML/CSS, Java, Go, Python, SQL, MongoDB, PostgreSQL` |
| sparkline | holdout | report | S | `skill_fit_cache.skills_text_hash: "61865684dad049892d0b10df67a33be2e50888fc16492716977b74d477e704d1"` | `skill_fit_cache.skills_text_hash: "65b4f56d7a54e16e3d1913576f262a10e3391a3aace42846ffccd9e1acfccc47"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.before[0]: "JavaScript"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.before[1]: "HTML/CSS"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.before[3]: "Go"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.before[4]: "Python"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.before[5]: "MongoDB"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.before[6]: "SQL"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.before[7]: "PostgreSQL"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.after[0]: "JavaScript"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.after[1]: "HTML/CSS"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.after[4]: "Python"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.after[5]: "SQL"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.after[6]: "MongoDB"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.after[7]: "PostgreSQL"` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| sparkline | holdout | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| tailscale | holdout | resume_tex | S | `  \item \textbf{Languages \& Databases:} Go, Python, Java, PostgreSQL, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Go, Python, Java, SQL, PostgreSQL, MySQL` |
| tailscale | holdout | report | S | `skill_fit_cache.skills_text_hash: "c5b6b3bdfb588d633e5ff60532411c017b0fd6dc497f6f3da00db5fc6d46dc91"` | `skill_fit_cache.skills_text_hash: "5979c332fa6d130075d5777c165a656513a9cd27905a9d92f543aa192b9376fa"` |
| tailscale | holdout | report | S | (none) | `skills_lines_v348c.before[0]: "Go"` |
| tailscale | holdout | report | S | (none) | `skills_lines_v348c.before[1]: "Python"` |
| tailscale | holdout | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| tailscale | holdout | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| tailscale | holdout | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| tailscale | holdout | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| tailscale | holdout | report | S | (none) | `skills_lines_v348c.after[0]: "Go"` |
| tailscale | holdout | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| tailscale | holdout | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| tailscale | holdout | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| tailscale | holdout | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| tailscale | holdout | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| tailscale | holdout | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| tailscale | holdout | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| tiktok_appsec | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Go, Python, Java, PostgreSQL, MongoDB, SQL` | `  \item \textbf{Languages \& Databases:} Go, Python, Java, SQL, PostgreSQL, MongoDB` |
| tiktok_appsec | v340_original | report | S | `skill_fit_cache.skills_text_hash: "613e46718ec7a0b6380e9b32a0e95709ecd3cfa81315d7f045f1dbc47a3f0c01"` | `skill_fit_cache.skills_text_hash: "8e305a5e1138b43119017c8f44c32e9852b2ec3916cffa4cf848c29b2f8204ab"` |
| tiktok_appsec | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Go"` |
| tiktok_appsec | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Python"` |
| tiktok_appsec | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Java"` |
| tiktok_appsec | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| tiktok_appsec | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "MongoDB"` |
| tiktok_appsec | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "SQL"` |
| tiktok_appsec | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Go"` |
| tiktok_appsec | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| tiktok_appsec | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| tiktok_appsec | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| tiktok_appsec | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| tiktok_appsec | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MongoDB"` |
| tiktok_appsec | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| tiktok_appsec | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| twitch | holdout | resume_tex | S | `  \item \textbf{Languages \& Databases:} Go, Java, Python, PostgreSQL, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Go, Java, Python, SQL, PostgreSQL, MySQL` |
| twitch | holdout | report | S | `skill_fit_cache.skills_text_hash: "4f49b5f1d9cde1aceeae216c1c406a71ceba70ab2f50db39abca9d9ed7258573"` | `skill_fit_cache.skills_text_hash: "d736903d9b88b5eaf117d8aaa9d32ca4aec8751b78be2bf39136d4cfcba47531"` |
| twitch | holdout | report | S | (none) | `skills_lines_v348c.before[0]: "Go"` |
| twitch | holdout | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| twitch | holdout | report | S | (none) | `skills_lines_v348c.before[2]: "Python"` |
| twitch | holdout | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| twitch | holdout | report | S | (none) | `skills_lines_v348c.before[4]: "SQL"` |
| twitch | holdout | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| twitch | holdout | report | S | (none) | `skills_lines_v348c.after[0]: "Go"` |
| twitch | holdout | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| twitch | holdout | report | S | (none) | `skills_lines_v348c.after[2]: "Python"` |
| twitch | holdout | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| twitch | holdout | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| twitch | holdout | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| twitch | holdout | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| twitch | holdout | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| twitch_se1 | v342_new | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Java, Go, PostgreSQL, MongoDB, SQL, MySQL` | `  \item \textbf{Languages \& Databases:} Python, Java, Go, SQL, PostgreSQL, MongoDB, MySQL` |
| twitch_se1 | v342_new | report | S | `skill_fit_cache.skills_text_hash: "63dadbb03e3aee81f068681598e8d0caa98a09322f148dbcf4b97b28ac65bcc3"` | `skill_fit_cache.skills_text_hash: "fb9c1d33a5d3e9627323850571c90fc490dd9aa4a42e42cc72a17bcca208903a"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.before[1]: "Java"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.before[2]: "Go"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.before[4]: "MongoDB"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.before[5]: "SQL"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.before[6]: "MySQL"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.after[1]: "Java"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.after[2]: "Go"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.after[3]: "SQL"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.after[5]: "MongoDB"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.after[6]: "MySQL"` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| twitch_se1 | v342_new | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| umich | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, HTML/CSS, Relational Databases, PostgreSQL, MySQL, JavaScript, Java, Go, MongoDB, SQL` | `  \item \textbf{Languages \& Databases:} Python, HTML/CSS, JavaScript, Java, Go, SQL, Relational Databases, PostgreSQL, MySQL, MongoDB` |
| umich | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "0ae0417c250a8f5e6707a37b6e379504aef1a5a26e207e662d3d8cf97766a502"` | `skill_fit_cache.skills_text_hash: "114aa6ebd01346b619248b8c2bf86da5b402fa40816cc7233695cdf51996b307"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "HTML/CSS"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "Relational Databases"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "PostgreSQL"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "MySQL"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "JavaScript"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.before[6]: "Java"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.before[7]: "Go"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.before[8]: "MongoDB"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.before[9]: "SQL"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "HTML/CSS"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "JavaScript"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "Java"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "Go"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "SQL"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.after[6]: "Relational Databases"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.after[7]: "PostgreSQL"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.after[8]: "MySQL"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.after[9]: "MongoDB"` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| umich | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| us_cold | v342_new | resume_tex | S | `  \item \textbf{Languages \& Databases:} Java, JavaScript, Relational Databases, SQL, Go, PostgreSQL, Python, MySQL` | `  \item \textbf{Languages \& Databases:} Java, JavaScript, SQL, Go, Python, Relational Databases, PostgreSQL, MySQL` |
| us_cold | v342_new | report | S | `skill_fit_cache.skills_text_hash: "21269d72d36b1ae5e0a5b6e625808777106dbd49ba25d467b51edc56ca205827"` | `skill_fit_cache.skills_text_hash: "e8e2df12b63b4fa616e963ec5a84e9524e51acabfb33aa5112a7a484f150c7f1"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.before[0]: "Java"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.before[1]: "JavaScript"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.before[2]: "Relational Databases"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.before[4]: "Go"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.before[5]: "PostgreSQL"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.before[6]: "Python"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.before[7]: "MySQL"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.after[0]: "Java"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.after[1]: "JavaScript"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.after[2]: "SQL"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.after[4]: "Python"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.after[5]: "Relational Databases"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.after[6]: "PostgreSQL"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.after[7]: "MySQL"` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| us_cold | v342_new | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| ust_software_engineer | v347_new | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, PostgreSQL, SQL, Java, Go, MongoDB, JavaScript, MySQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, Go, JavaScript, PostgreSQL, MongoDB, MySQL` |
| ust_software_engineer | v347_new | report | S | `skill_fit_cache.skills_text_hash: "a131229c2944def7274716a7bb190472a9e7f3d0dddac998dbd8b5c8b9dd544d"` | `skill_fit_cache.skills_text_hash: "c69e1c6632eea7a9f708fd070fbba5aa588df23301ae3b09afd8de94d14e0239"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.before[2]: "SQL"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.before[3]: "Java"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.before[4]: "Go"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.before[5]: "MongoDB"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.before[6]: "JavaScript"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.before[7]: "MySQL"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.after[4]: "JavaScript"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.after[5]: "PostgreSQL"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.after[6]: "MongoDB"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.after[7]: "MySQL"` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| ust_software_engineer | v347_new | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| vindexa | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} SQL, PostgreSQL, Python, MySQL` | `  \item \textbf{Languages \& Databases:} SQL, Python, PostgreSQL, MySQL` |
| vindexa | v340_original | report | S | `skill_fit_cache.skills_text_hash: "f4762dc181a992d5313c3096a17f70ec0f2848ce1c7024c43772efb8a91dbaaf"` | `skill_fit_cache.skills_text_hash: "ea17fbbbabb1ab224c050c2be8b15e62f0d71f5b4c42061ebaf8bbee7abef073"` |
| vindexa | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "SQL"` |
| vindexa | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "PostgreSQL"` |
| vindexa | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "Python"` |
| vindexa | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "MySQL"` |
| vindexa | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "SQL"` |
| vindexa | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| vindexa | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "PostgreSQL"` |
| vindexa | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "MySQL"` |
| vindexa | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| vindexa | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| wgu | v341_tune | resume_tex | S | `  \item \textbf{Languages \& Databases:} NoSQL, SQL, Python, Relational Databases, Java, JavaScript, Go, MongoDB, MySQL, HTML/CSS` | `  \item \textbf{Languages \& Databases:} SQL, Python, Java, JavaScript, Go, HTML/CSS, NoSQL, Relational Databases, MongoDB, MySQL` |
| wgu | v341_tune | report | S | `skill_fit_cache.skills_text_hash: "c8df87684c9600305fa0bdfed81dd4bd041fc5ee364d20fb8b5a3a90e0030f4d"` | `skill_fit_cache.skills_text_hash: "d38423b586dc5649eb989159e0384717f75c31654beabdb2659a2ec1efd3afec"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.before[0]: "NoSQL"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.before[1]: "SQL"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.before[2]: "Python"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.before[3]: "Relational Databases"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.before[4]: "Java"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.before[5]: "JavaScript"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.before[6]: "Go"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.before[7]: "MongoDB"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.before[8]: "MySQL"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.before[9]: "HTML/CSS"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.after[0]: "SQL"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.after[1]: "Python"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.after[3]: "JavaScript"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.after[4]: "Go"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.after[5]: "HTML/CSS"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.after[6]: "NoSQL"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.after[7]: "Relational Databases"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.after[8]: "MongoDB"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.after[9]: "MySQL"` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| wgu | v341_tune | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| wpp | v340_original | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, Relational Databases, PostgreSQL, SQL, Java, MySQL` | `  \item \textbf{Languages \& Databases:} Python, SQL, Java, Relational Databases, PostgreSQL, MySQL` |
| wpp | v340_original | report | S | `skill_fit_cache.skills_text_hash: "fcb97ccc93d92ef6b4dc0ef3542b718eb66d797947ae30a9275dbfa492fb7da9"` | `skill_fit_cache.skills_text_hash: "0b9afe4a6663543c62a285bfbb660f89d80257311cee57d1c6ecaeb62dbe0732"` |
| wpp | v340_original | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| wpp | v340_original | report | S | (none) | `skills_lines_v348c.before[1]: "Relational Databases"` |
| wpp | v340_original | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| wpp | v340_original | report | S | (none) | `skills_lines_v348c.before[3]: "SQL"` |
| wpp | v340_original | report | S | (none) | `skills_lines_v348c.before[4]: "Java"` |
| wpp | v340_original | report | S | (none) | `skills_lines_v348c.before[5]: "MySQL"` |
| wpp | v340_original | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| wpp | v340_original | report | S | (none) | `skills_lines_v348c.after[1]: "SQL"` |
| wpp | v340_original | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| wpp | v340_original | report | S | (none) | `skills_lines_v348c.after[3]: "Relational Databases"` |
| wpp | v340_original | report | S | (none) | `skills_lines_v348c.after[4]: "PostgreSQL"` |
| wpp | v340_original | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| wpp | v340_original | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| wpp | v340_original | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |
| zoro_fullstack | v347_new | resume_tex | S | `  \item \textbf{Languages \& Databases:} Python, MySQL, PostgreSQL, JavaScript, Java, Go, MongoDB, SQL` | `  \item \textbf{Languages \& Databases:} Python, JavaScript, Java, Go, SQL, MySQL, PostgreSQL, MongoDB` |
| zoro_fullstack | v347_new | report | S | `skill_fit_cache.skills_text_hash: "ce88aa08f59eab00ec1a38b71e3c302a928f61ed46fa168a55013ea0522aa0f4"` | `skill_fit_cache.skills_text_hash: "d0c928c54fdb630a620a9c7383b92d3062805f9c1abcea39231355aaa91248bb"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.before[0]: "Python"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.before[1]: "MySQL"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.before[2]: "PostgreSQL"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.before[3]: "JavaScript"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.before[4]: "Java"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.before[5]: "Go"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.before[6]: "MongoDB"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.before[7]: "SQL"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.after[0]: "Python"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.after[1]: "JavaScript"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.after[2]: "Java"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.after[3]: "Go"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.after[4]: "SQL"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.after[5]: "MySQL"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.after[6]: "PostgreSQL"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.after[7]: "MongoDB"` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.s2_added: []` |
| zoro_fullstack | v347_new | report | S | (none) | `skills_lines_v348c.s2_not_on_page: []` |

## Fix J

Before: `snap_v348c_S`. After: `snap_v348c_J` (every fix up to J on). Predictions: `predicted_changes_v348c_J.json`; amendments: `predicted_changes_v348c_J_amendments.json`.

Result: **PASS**. 54 changed lines in 11 fixtures (11 with output changes beyond the version label); 0 unpredicted on v340_original / holdout; 0 unpredicted and unjustified elsewhere; 0 gate-guard failures; 4 lines matched only a documented amendment; longest letter 200 words.

Guards:

- J1 resume: only project heading technology lists change (bullets, Skills, Experience identical): **held**
- J2 a heading only gains one technology, has at most 4 afterwards, and keeps every core-stack item: **held**
- J3 letter, tracker and outreach identical: **held**

Changed fixtures (11): acme_cloud, bti, cdi, engen, harvey, ixl, linkedin, macys, meridian_sw, monti, wgu

Predicted but not changed:

- anthropic_it / report
- arclight / report
- atoms / report
- audit06 / report
- audit08 / report
- audit12 / report
- bae / report
- booz_allen / report
- doordash_mdx / report
- garmin / report
- linkedin_ai / report
- lumen / report
- novita / report
- nvidia / report
- nvidia_ai_cloud / report
- us_cold / report

| Fixture | Group | File | Fix | Before | After |
|---|---|---|---|---|---|
| acme_cloud | holdout | resume_tex | J | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, Python, Go $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, Python, Go, JavaScript $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` |
| acme_cloud | holdout | report | J | (none) | `heading_move_v348c.moved[0].tech: "JavaScript"` |
| acme_cloud | holdout | report | J | (none) | `heading_move_v348c.moved[0].from: "ledgerflow"` |
| acme_cloud | holdout | report | J | (none) | `heading_move_v348c.moved[0].to: "launchops"` |
| acme_cloud | holdout | report | J | (none) | `heading_move_v348c.moved[0].bullets_showing: 1` |
| bti | v341_tune | resume_tex | J | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python, JavaScript $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` |
| bti | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].tech: "JavaScript"` |
| bti | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].from: "ledgerflow"` |
| bti | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].to: "launchops"` |
| bti | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].bullets_showing: 1` |
| cdi | v340_original | resume_tex | J | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python, JavaScript $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` |
| cdi | v340_original | report | J | (none) | `heading_move_v348c.moved[0].tech: "JavaScript"` |
| cdi | v340_original | report | J | (none) | `heading_move_v348c.moved[0].from: "goingonce"` |
| cdi | v340_original | report | J | (none) | `heading_move_v348c.moved[0].to: "launchops"` |
| cdi | v340_original | report | J | (none) | `heading_move_v348c.moved[0].bullets_showing: 1` |
| engen | v341_tune | resume_tex | J | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python, JavaScript $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` |
| engen | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].tech: "JavaScript"` |
| engen | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].from: "ledgerflow"` |
| engen | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].to: "launchops"` |
| engen | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].bullets_showing: 1` |
| harvey | v341_tune | resume_tex | J | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, Python, Go $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, Python, Go, JavaScript $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` |
| harvey | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].tech: "JavaScript"` |
| harvey | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].from: "goingonce"` |
| harvey | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].to: "launchops"` |
| harvey | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].bullets_showing: 1` |
| ixl | v340_original | resume_tex | J | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python, JavaScript $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` |
| ixl | v340_original | report | J | (none) | `heading_move_v348c.moved[0].tech: "JavaScript"` |
| ixl | v340_original | report | J | (none) | `heading_move_v348c.moved[0].from: "goingonce"` |
| ixl | v340_original | report | J | (none) | `heading_move_v348c.moved[0].to: "launchops"` |
| ixl | v340_original | report | J | (none) | `heading_move_v348c.moved[0].bullets_showing: 1` |
| linkedin | v340_original | resume_tex | J | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python, JavaScript $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` |
| linkedin | v340_original | report | J | (none) | `heading_move_v348c.moved[0].tech: "JavaScript"` |
| linkedin | v340_original | report | J | (none) | `heading_move_v348c.moved[0].from: "ledgerflow"` |
| linkedin | v340_original | report | J | (none) | `heading_move_v348c.moved[0].to: "launchops"` |
| linkedin | v340_original | report | J | (none) | `heading_move_v348c.moved[0].bullets_showing: 1` |
| macys | v342_new | resume_tex | J | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python, JavaScript $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` |
| macys | v342_new | report | J | (none) | `heading_move_v348c.moved[0].tech: "JavaScript"` |
| macys | v342_new | report | J | (none) | `heading_move_v348c.moved[0].from: "ledgerflow"` |
| macys | v342_new | report | J | (none) | `heading_move_v348c.moved[0].to: "launchops"` |
| macys | v342_new | report | J | (none) | `heading_move_v348c.moved[0].bullets_showing: 1` |
| meridian_sw | holdout | report | J (amendment J-A1) | (none) | `heading_move_v348c.kept_off[0].tech: "JavaScript"` |
| meridian_sw | holdout | report | J (amendment J-A1) | (none) | `heading_move_v348c.kept_off[0].from: "ledgerflow"` |
| meridian_sw | holdout | report | J (amendment J-A1) | (none) | `heading_move_v348c.kept_off[0].to: "launchops"` |
| meridian_sw | holdout | report | J (amendment J-A1) | (none) | `heading_move_v348c.kept_off[0].reason: "that heading already has 4 technologies"` |
| monti | v341_tune | resume_tex | J | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python, JavaScript $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` |
| monti | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].tech: "JavaScript"` |
| monti | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].from: "goingonce"` |
| monti | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].to: "launchops"` |
| monti | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].bullets_showing: 1` |
| wgu | v341_tune | resume_tex | J | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` | `\noindent\textbf{LaunchOps: Employee Onboarding Platform} $\|$ Django, ReactJS, Python, JavaScript $\|$ \href{https://github.com/Jaypath456/LaunchOps}{\underline{GitHub}} \hfill \textit{March 2026}` |
| wgu | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].tech: "JavaScript"` |
| wgu | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].from: "ledgerflow"` |
| wgu | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].to: "launchops"` |
| wgu | v341_tune | report | J | (none) | `heading_move_v348c.moved[0].bullets_showing: 1` |

## Fix C

Before: `snap_v348c_J`. After: `snap_v348c_C` (every fix up to C on). Predictions: `predicted_changes_v348c_C.json`.

Result: **PASS**. 168 changed lines in 8 fixtures (8 with output changes beyond the version label); 0 unpredicted on v340_original / holdout; 0 unpredicted and unjustified elsewhere; 0 gate-guard failures; 0 lines matched only a documented amendment; longest letter 200 words.

Guards:

- C1 resume, tracker and outreach identical: **held**
- C2 letter: only the closing sentence changes: **held**
- C3 every changed closing <= 30 words, names the company, and repeats no proof already in the letter: **held**

Changed fixtures (8): alml_engineer, audit12, doordash_mdx, elevenlabs, figure, flowgen, klaviyo, lumen

Changed closings:

- alml_engineer: `I want to optimize models for latency, accuracy, and scalability in real-world applications on your team, building on RIPPLE, whose Git-diff check flags missing tests and stale callers.` -> `I want to optimize models for latency, accuracy, and scalability in real-world applications on your team, building on my fraud model's edge-type ablation, which showed the graph adds 0.016 AUC.`
- audit12: `I want to implement Python services for LLM integration, request validation, and tool calling at VectorForge AI, building on my LLM engine's provider failover.` -> `I want to build evaluation datasets that represent routine use, unusual inputs, and adversarial cases at VectorForge AI, drawing on my LLM engine's provider failover.`
- doordash_mdx: `I want to build and run ML-powered products at DoorDash, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers.` -> `I want to build agentic systems that increase the velocity of ML development at DoorDash, drawing on my LLM engine's provider failover.`
- elevenlabs: `I want to build and improve the building blocks customers touch directly at ElevenLabs, drawing on LaunchOps, where every onboarding task has an owner and prerequisites the server enforces.` -> `I want to design and build generic resource and permissioning services at ElevenLabs, drawing on LaunchOps, where every onboarding task has an owner and prerequisites the server enforces.`
- figure: `I want to design, implement, and test features for the robot software platform at Figure, building on the process management I wrote in C for Pintos.` -> `I want to integrate, debug, and validate updates on real robot hardware at Figure, building on the process management I wrote in C for Pintos.`
- flowgen: `I want to write and maintain key agent-building artifacts at FlowGen Labs, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers.` -> `I want to write and maintain key agent-building artifacts at FlowGen Labs, drawing on RIPPLE, which checks every claim against evidence.`
- klaviyo: `I want to develop robust, reliable and scalable services to serve AI models at Klaviyo, drawing on LedgerFlow, where a GitHub Actions CI workflow runs every automated test.` -> `I want to create human and automated evals to ensure high AI model quality at Klaviyo, drawing on RIPPLE, which checks every claim against evidence.`
- lumen: `I want to build AI agents that automate back-office workflows at Lumen Agents, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers.` -> `I want to build AI agents that automate back-office workflows at Lumen Agents, drawing on RIPPLE, which checks every claim against evidence.`

Predicted but not changed:

- acme_cloud / letter_txt
- acme_cloud / report
- amplitude / letter_txt
- amplitude / report
- appian_sec / letter_txt
- appian_sec / report
- arclight / letter_txt
- arclight / report
- assetwatch / letter_txt
- assetwatch / report
- atoms / letter_txt
- atoms / report
- audible / letter_txt
- audible / report
- audible_md / letter_txt
- audible_md / report
- audit02 / letter_txt
- audit02 / report
- audit08 / letter_txt
- audit08 / report
- bae / letter_txt
- bae / report
- birthmodel / letter_txt
- birthmodel / report
- brightpath_fs / letter_txt
- brightpath_fs / report
- brightpath_ml / letter_txt
- brightpath_ml / report
- brillio / letter_txt
- brillio / report
- cdi / letter_txt
- cdi / report
- cobalt / letter_txt
- cobalt / report
- commure / letter_txt
- commure / report
- corvex / letter_txt
- corvex / report
- fanatics / letter_txt
- fanatics / report
- fulfillment / letter_txt
- fulfillment / report
- google_sre / letter_txt
- google_sre / report
- halcyon / letter_txt
- halcyon / report
- harvey / letter_txt
- harvey / report
- helix / letter_txt
- helix / report
- instalily / letter_txt
- instalily / report
- ironvale / letter_txt
- ironvale / report
- ixl / letter_txt
- ixl / report
- jobgether / letter_txt
- jobgether / report
- l3harris / letter_txt
- l3harris / report
- linkedin / letter_txt
- linkedin / report
- linkedin_ai / letter_txt
- linkedin_ai / report
- loopwell / letter_txt
- loopwell / report
- mastercard / letter_txt
- mastercard / report
- meridian_bank / letter_txt
- meridian_bank / report
- meridian_sw / letter_txt
- meridian_sw / report
- meritore_capgemini / letter_txt
- meritore_capgemini / report
- microsoft / letter_txt
- microsoft / report
- monti / letter_txt
- monti / report
- ng_fullstack / letter_txt
- ng_fullstack / report
- novita / letter_txt
- novita / report
- nvidia_ai_cloud / letter_txt
- nvidia_ai_cloud / report
- paypal / letter_txt
- paypal / report
- pinterest / letter_txt
- pinterest / report
- quora / letter_txt
- quora / report
- raydar_swe / letter_txt
- raydar_swe / report
- robot_sdet / letter_txt
- robot_sdet / report
- rocketmoney / letter_txt
- rocketmoney / report
- rockstar / letter_txt
- rockstar / report
- stratus / letter_txt
- stratus / report
- twitch_se1 / letter_txt
- twitch_se1 / report
- us_cold / letter_txt
- us_cold / report
- ust_software_engineer / letter_txt
- ust_software_engineer / report
- vindexa / letter_txt
- vindexa / report
- wpp / letter_txt
- wpp / report

| Fixture | Group | File | Fix | Before | After |
|---|---|---|---|---|---|
| alml_engineer | v347_new | letter_txt | C | `In my fraud-detection project, I trained graph neural networks in PyTorch on highly imbalanced transaction data. GraphSAGE reached 0.9259 AUC-ROC, against about 0.858 for a plain neural-network baseline. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. On 30 unseen tasks from 16 repositories, it accepted zero unsupport` | `In my fraud-detection project, I trained graph neural networks in PyTorch on highly imbalanced transaction data. GraphSAGE reached 0.9259 AUC-ROC, against about 0.858 for a plain neural-network baseline. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. On 30 unseen tasks from 16 repositories, it accepted zero unsupport` |
| alml_engineer | v347_new | report | C | `cover_letter.words: 169` | `cover_letter.words: 171` |
| alml_engineer | v347_new | report | C | `cover_letter.closing.proof: "ripple.git_verification"` | `cover_letter.closing.proof: "fraud.edge_ablation_result"` |
| alml_engineer | v347_new | report | C | `cover_letter.closing.proof_kind: "ai"` | `cover_letter.closing.proof_kind: "ml_results"` |
| alml_engineer | v347_new | report | C | `cover_letter.closing._proof: "RIPPLE, whose Git-diff check flags missing tests and stale callers"` | `cover_letter.closing._proof: "my fraud model's edge-type ablation, which showed the graph adds 0.016 AUC"` |
| alml_engineer | v347_new | report | C | (none) | `cover_letter.closing.v348c.before: "I want to optimize models for latency, accuracy, and scalability in real-world applications on your team, building on RIPPLE, whose Git-diff check flags missing tests and stale callers."` |
| alml_engineer | v347_new | report | C | (none) | `cover_letter.closing.v348c.before_proof: "ripple.git_verification"` |
| alml_engineer | v347_new | report | C | (none) | `cover_letter.closing.v348c.specificity_before: 0` |
| alml_engineer | v347_new | report | C | (none) | `cover_letter.closing.v348c.rule: "C1"` |
| alml_engineer | v347_new | report | C | `cover_letter.closing.text: "I want to optimize models for latency, accuracy, and scalability in real-world applications on your team, building on RIPPLE, whose Git-diff check flags missing tests and stale callers."` | `cover_letter.closing.text: "I want to optimize models for latency, accuracy, and scalability in real-world applications on your team, building on my fraud model's edge-type ablation, which showed the graph adds 0.016 AUC."` |
| alml_engineer | v347_new | report | C | `cover_letter.words_total: 176` | `cover_letter.words_total: 178` |
| alml_engineer | v347_new | report | C | `verify_changes_v344[1].change: "Closing responsibility \"optimize models for latency, accuracy, and scalability in real-world applications\" with proof ripple.git_verification (ai)"` | `verify_changes_v344[1].change: "Closing responsibility \"optimize models for latency, accuracy, and scalability in real-world applications\" with proof fraud.edge_ablation_result (ml_results)"` |
| alml_engineer | v347_new | report | C | (none) | `closing_v348c.before: "I want to optimize models for latency, accuracy, and scalability in real-world applications on your team, building on RIPPLE, whose Git-diff check flags missing tests and stale callers."` |
| alml_engineer | v347_new | report | C | (none) | `closing_v348c.before_proof: "ripple.git_verification"` |
| alml_engineer | v347_new | report | C | (none) | `closing_v348c.specificity_before: 0` |
| alml_engineer | v347_new | report | C | (none) | `closing_v348c.rule: "C1"` |
| alml_engineer | v347_new | report | C | (none) | `closing_v348c.after: "I want to optimize models for latency, accuracy, and scalability in real-world applications on your team, building on my fraud model's edge-type ablation, which showed the graph adds 0.016 AUC."` |
| alml_engineer | v347_new | report | C | (none) | `closing_v348c.after_proof: "fraud.edge_ablation_result"` |
| audit12 | v340_original | letter_txt | C | `I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Its Git-diff check flags unexpected edits, missing tests, and stale callers. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. I also built an LLM Application Optimization Engine in Python that falls back from Gemini to Novita's mo` | `I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Its Git-diff check flags unexpected edits, missing tests, and stale callers. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. I also built an LLM Application Optimization Engine in Python that falls back from Gemini to Novita's mo` |
| audit12 | v340_original | report | C | `cover_letter.words: 183` | `cover_letter.words: 184` |
| audit12 | v340_original | report | C | `cover_letter.closing.responsibility: "implement Python services for LLM integration, request validation, and tool calling"` | `cover_letter.closing.responsibility: "build evaluation datasets that represent routine use, unusual inputs, and adversarial cases"` |
| audit12 | v340_original | report | C | `cover_letter.closing.jd_line: "implement Python services for LLM integration, request validation, and tool calling"` | `cover_letter.closing.jd_line: "- Build evaluation datasets that represent routine use, unusual inputs, and adversarial cases."` |
| audit12 | v340_original | report | C | `cover_letter.closing.connector: "building on"` | `cover_letter.closing.connector: "drawing on"` |
| audit12 | v340_original | report | C | (none) | `cover_letter.closing.v348c.before: "I want to implement Python services for LLM integration, request validation, and tool calling at VectorForge AI, building on my LLM engine's provider failover."` |
| audit12 | v340_original | report | C | (none) | `cover_letter.closing.v348c.before_proof: "tailor.provider_failover"` |
| audit12 | v340_original | report | C | (none) | `cover_letter.closing.v348c.specificity_before: 0` |
| audit12 | v340_original | report | C | (none) | `cover_letter.closing.v348c.rule: "C2+C1"` |
| audit12 | v340_original | report | C | (none) | `cover_letter.closing.v348c.specificity_after: 3` |
| audit12 | v340_original | report | C | (none) | `cover_letter.closing.v348c.domain_words: 3` |
| audit12 | v340_original | report | C | `cover_letter.closing.text: "I want to implement Python services for LLM integration, request validation, and tool calling at VectorForge AI, building on my LLM engine's provider failover."` | `cover_letter.closing.text: "I want to build evaluation datasets that represent routine use, unusual inputs, and adversarial cases at VectorForge AI, drawing on my LLM engine's provider failover."` |
| audit12 | v340_original | report | C | `cover_letter.words_total: 190` | `cover_letter.words_total: 191` |
| audit12 | v340_original | report | C | `verify_changes_v344[4].change: "Closing responsibility \"implement Python services for LLM integration, request validation, and tool calling\" with proof tailor.provider_failover (ai)"` | `verify_changes_v344[4].change: "Closing responsibility \"build evaluation datasets that represent routine use, unusual inputs, and adversarial cases\" with proof tailor.provider_failover (ai)"` |
| audit12 | v340_original | report | C | `verify_changes_v344[4].jd_line: "implement Python services for LLM integration, request validation, and tool calling"` | `verify_changes_v344[4].jd_line: "- Build evaluation datasets that represent routine use, unusual inputs, and adversarial cases."` |
| audit12 | v340_original | report | C | (none) | `closing_v348c.before: "I want to implement Python services for LLM integration, request validation, and tool calling at VectorForge AI, building on my LLM engine's provider failover."` |
| audit12 | v340_original | report | C | (none) | `closing_v348c.before_proof: "tailor.provider_failover"` |
| audit12 | v340_original | report | C | (none) | `closing_v348c.specificity_before: 0` |
| audit12 | v340_original | report | C | (none) | `closing_v348c.rule: "C2+C1"` |
| audit12 | v340_original | report | C | (none) | `closing_v348c.specificity_after: 3` |
| audit12 | v340_original | report | C | (none) | `closing_v348c.domain_words: 3` |
| audit12 | v340_original | report | C | (none) | `closing_v348c.after: "I want to build evaluation datasets that represent routine use, unusual inputs, and adversarial cases at VectorForge AI, drawing on my LLM engine's provider failover."` |
| audit12 | v340_original | report | C | (none) | `closing_v348c.after_proof: "tailor.provider_failover"` |
| doordash_mdx | v342_new | letter_txt | C | `I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry l` | `I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry l` |
| doordash_mdx | v342_new | report | C | `cover_letter.closing.responsibility: "build and run ML-powered products"` | `cover_letter.closing.responsibility: "build agentic systems that increase the velocity of ML development"` |
| doordash_mdx | v342_new | report | C | `cover_letter.closing.jd_line: "DoorDash's MDX team sits within Machine Learning Platform and builds the shared foundation that ML engineers across DoorDash, Wolt, and Deliveroo rely on to build and run ML-powered products. We work across the full ML lifecycle: feature engineering, training, evaluation, deployment, serving, and monitoring. Our mission is to increase the velocity and reliability of ` | `cover_letter.closing.jd_line: "- Build agentic systems that increase the velocity of ML development across DoorDash, Wolt, and Deliveroo, helping ML engineers get from idea to production model faster."` |
| doordash_mdx | v342_new | report | C | `cover_letter.closing.proof: "ripple.git_verification"` | `cover_letter.closing.proof: "tailor.provider_failover"` |
| doordash_mdx | v342_new | report | C | `cover_letter.closing._proof: "RIPPLE, whose Git-diff check flags missing tests and stale callers"` | `cover_letter.closing._proof: "my LLM engine's provider failover"` |
| doordash_mdx | v342_new | report | C | (none) | `cover_letter.closing.v348c.before: "I want to build and run ML-powered products at DoorDash, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers."` |
| doordash_mdx | v342_new | report | C | (none) | `cover_letter.closing.v348c.before_proof: "ripple.git_verification"` |
| doordash_mdx | v342_new | report | C | (none) | `cover_letter.closing.v348c.specificity_before: 0` |
| doordash_mdx | v342_new | report | C | (none) | `cover_letter.closing.v348c.rule: "C2+C1"` |
| doordash_mdx | v342_new | report | C | (none) | `cover_letter.closing.v348c.specificity_after: 3` |
| doordash_mdx | v342_new | report | C | (none) | `cover_letter.closing.v348c.domain_words: 4` |
| doordash_mdx | v342_new | report | C | `cover_letter.closing.text: "I want to build and run ML-powered products at DoorDash, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers."` | `cover_letter.closing.text: "I want to build agentic systems that increase the velocity of ML development at DoorDash, drawing on my LLM engine's provider failover."` |
| doordash_mdx | v342_new | report | C | `verify_changes_v344[2].change: "Closing responsibility \"build and run ML-powered products\" with proof ripple.git_verification (ai)"` | `verify_changes_v344[2].change: "Closing responsibility \"build agentic systems that increase the velocity of ML development\" with proof tailor.provider_failover (ai)"` |
| doordash_mdx | v342_new | report | C | `verify_changes_v344[2].jd_line: "DoorDash's MDX team sits within Machine Learning Platform and builds the shared foundation that ML engineers across DoorDash, Wolt, and Deliveroo rely on to build and run ML-powered products. We work across the full ML lifecycle: feature en"` | `verify_changes_v344[2].jd_line: "- Build agentic systems that increase the velocity of ML development across DoorDash, Wolt, and Deliveroo, helping ML engineers get from idea to production model faster."` |
| doordash_mdx | v342_new | report | C | (none) | `closing_v348c.before: "I want to build and run ML-powered products at DoorDash, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers."` |
| doordash_mdx | v342_new | report | C | (none) | `closing_v348c.before_proof: "ripple.git_verification"` |
| doordash_mdx | v342_new | report | C | (none) | `closing_v348c.specificity_before: 0` |
| doordash_mdx | v342_new | report | C | (none) | `closing_v348c.rule: "C2+C1"` |
| doordash_mdx | v342_new | report | C | (none) | `closing_v348c.specificity_after: 3` |
| doordash_mdx | v342_new | report | C | (none) | `closing_v348c.domain_words: 4` |
| doordash_mdx | v342_new | report | C | (none) | `closing_v348c.after: "I want to build agentic systems that increase the velocity of ML development at DoorDash, drawing on my LLM engine's provider failover."` |
| doordash_mdx | v342_new | report | C | (none) | `closing_v348c.after_proof: "tailor.provider_failover"` |
| elevenlabs | v342_new | letter_txt | C | `LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side permission checks block users from editing other users' tasks and reject forged evidence and skipped prerequisites. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. A GitHub` | `LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side permission checks block users from editing other users' tasks and reject forged evidence and skipped prerequisites. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. A GitHub` |
| elevenlabs | v342_new | report | C | `cover_letter.words: 177` | `cover_letter.words: 176` |
| elevenlabs | v342_new | report | C | `cover_letter.closing.responsibility: "build and improve the building blocks customers touch directly"` | `cover_letter.closing.responsibility: "design and build generic resource and permissioning services"` |
| elevenlabs | v342_new | report | C | `cover_letter.closing.jd_line: "build and improve the building blocks customers touch directly"` | `cover_letter.closing.jd_line: "- Designing and building generic resource and permissioning services that product teams use to build features safely and quickly."` |
| elevenlabs | v342_new | report | C | (none) | `cover_letter.closing.v348c.before: "I want to build and improve the building blocks customers touch directly at ElevenLabs, drawing on LaunchOps, where every onboarding task has an owner and prerequisites the server enforces."` |
| elevenlabs | v342_new | report | C | (none) | `cover_letter.closing.v348c.before_proof: "launchops.ownership"` |
| elevenlabs | v342_new | report | C | (none) | `cover_letter.closing.v348c.specificity_before: -1` |
| elevenlabs | v342_new | report | C | (none) | `cover_letter.closing.v348c.rule: "C2"` |
| elevenlabs | v342_new | report | C | (none) | `cover_letter.closing.v348c.specificity_after: 1` |
| elevenlabs | v342_new | report | C | (none) | `cover_letter.closing.v348c.domain_words: 2` |
| elevenlabs | v342_new | report | C | `cover_letter.closing.text: "I want to build and improve the building blocks customers touch directly at ElevenLabs, drawing on LaunchOps, where every onboarding task has an owner and prerequisites the server enforces."` | `cover_letter.closing.text: "I want to design and build generic resource and permissioning services at ElevenLabs, drawing on LaunchOps, where every onboarding task has an owner and prerequisites the server enforces."` |
| elevenlabs | v342_new | report | C | `cover_letter.words_total: 185` | `cover_letter.words_total: 184` |
| elevenlabs | v342_new | report | C | `verify_changes_v344[3].change: "Closing responsibility \"build and improve the building blocks customers touch directly\" with proof launchops.ownership (permissions)"` | `verify_changes_v344[3].change: "Closing responsibility \"design and build generic resource and permissioning services\" with proof launchops.ownership (permissions)"` |
| elevenlabs | v342_new | report | C | `verify_changes_v344[3].jd_line: "Building and improving the building blocks customers touch directly: API keys, login experience, analytics, admin tooling, workspace security and more"` | `verify_changes_v344[3].jd_line: "- Designing and building generic resource and permissioning services that product teams use to build features safely and quickly."` |
| elevenlabs | v342_new | report | C | `verify_quotes_v345.replaced[0]: "Closing responsibility \"build and improve the building blocks customers touch di"` | `verify_quotes_v345.replaced[0]: "Experience variant E (exp.thesis.1.E, suits client-facing / internal-tools roles"` |
| elevenlabs | v342_new | report | C | `verify_quotes_v345.replaced[1]: "Experience variant E (exp.thesis.1.E, suits client-facing / internal-tools roles"` | (none) |
| elevenlabs | v342_new | report | C | (none) | `closing_v348c.before: "I want to build and improve the building blocks customers touch directly at ElevenLabs, drawing on LaunchOps, where every onboarding task has an owner and prerequisites the server enforces."` |
| elevenlabs | v342_new | report | C | (none) | `closing_v348c.before_proof: "launchops.ownership"` |
| elevenlabs | v342_new | report | C | (none) | `closing_v348c.specificity_before: -1` |
| elevenlabs | v342_new | report | C | (none) | `closing_v348c.rule: "C2"` |
| elevenlabs | v342_new | report | C | (none) | `closing_v348c.specificity_after: 1` |
| elevenlabs | v342_new | report | C | (none) | `closing_v348c.domain_words: 2` |
| elevenlabs | v342_new | report | C | (none) | `closing_v348c.after: "I want to design and build generic resource and permissioning services at ElevenLabs, drawing on LaunchOps, where every onboarding task has an owner and prerequisites the server enforces."` |
| elevenlabs | v342_new | report | C | (none) | `closing_v348c.after_proof: "launchops.ownership"` |
| figure | v342_new | letter_txt | C | `For an operating systems course, I wrote the user-programs layer of the Pintos teaching operating system in C. All 80 tests pass. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, it never overdrew the account. My Master's in Computer Science at ` | `For an operating systems course, I wrote the user-programs layer of the Pintos teaching operating system in C. All 80 tests pass. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, it never overdrew the account. My Master's in Computer Science at ` |
| figure | v342_new | report | C | `cover_letter.words: 173` | `cover_letter.words: 172` |
| figure | v342_new | report | C | `cover_letter.closing.responsibility: "design, implement, and test features for the robot software platform"` | `cover_letter.closing.responsibility: "integrate, debug, and validate updates on real robot hardware"` |
| figure | v342_new | report | C | `cover_letter.closing.jd_line: "design, implement, and test features for the robot software platform"` | `cover_letter.closing.jd_line: "- Work across software and hardware layers to integrate, debug, and validate updates on real robot hardware."` |
| figure | v342_new | report | C | (none) | `cover_letter.closing.v348c.before: "I want to design, implement, and test features for the robot software platform at Figure, building on the process management I wrote in C for Pintos."` |
| figure | v342_new | report | C | (none) | `cover_letter.closing.v348c.before_proof: "pintos.processes"` |
| figure | v342_new | report | C | (none) | `cover_letter.closing.v348c.specificity_before: 0` |
| figure | v342_new | report | C | (none) | `cover_letter.closing.v348c.rule: "C2"` |
| figure | v342_new | report | C | (none) | `cover_letter.closing.v348c.specificity_after: 2` |
| figure | v342_new | report | C | (none) | `cover_letter.closing.v348c.domain_words: 2` |
| figure | v342_new | report | C | `cover_letter.closing.text: "I want to design, implement, and test features for the robot software platform at Figure, building on the process management I wrote in C for Pintos."` | `cover_letter.closing.text: "I want to integrate, debug, and validate updates on real robot hardware at Figure, building on the process management I wrote in C for Pintos."` |
| figure | v342_new | report | C | `cover_letter.words_total: 180` | `cover_letter.words_total: 179` |
| figure | v342_new | report | C | `verify_changes_v344[0].change: "Closing responsibility \"design, implement, and test features for the robot software platform\" with proof pintos.processes (embedded)"` | `verify_changes_v344[0].change: "Closing responsibility \"integrate, debug, and validate updates on real robot hardware\" with proof pintos.processes (embedded)"` |
| figure | v342_new | report | C | `verify_changes_v344[0].jd_line: "design, implement, and test features for the robot software platform"` | `verify_changes_v344[0].jd_line: "- Work across software and hardware layers to integrate, debug, and validate updates on real robot hardware."` |
| figure | v342_new | report | C | (none) | `closing_v348c.before: "I want to design, implement, and test features for the robot software platform at Figure, building on the process management I wrote in C for Pintos."` |
| figure | v342_new | report | C | (none) | `closing_v348c.before_proof: "pintos.processes"` |
| figure | v342_new | report | C | (none) | `closing_v348c.specificity_before: 0` |
| figure | v342_new | report | C | (none) | `closing_v348c.rule: "C2"` |
| figure | v342_new | report | C | (none) | `closing_v348c.specificity_after: 2` |
| figure | v342_new | report | C | (none) | `closing_v348c.domain_words: 2` |
| figure | v342_new | report | C | (none) | `closing_v348c.after: "I want to integrate, debug, and validate updates on real robot hardware at Figure, building on the process management I wrote in C for Pintos."` |
| figure | v342_new | report | C | (none) | `closing_v348c.after_proof: "pintos.processes"` |
| flowgen | v341_tune | letter_txt | C | `I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. I also built an LLM Application Optimization Engine in Python that falls back from Gemini to Novita's model API after 3 failed attempts. Three AI workers write in parallel, which re` | `I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. I also built an LLM Application Optimization Engine in Python that falls back from Gemini to Novita's model API after 3 failed attempts. Three AI workers write in parallel, which re` |
| flowgen | v341_tune | report | C | `cover_letter.words: 171` | `cover_letter.words: 168` |
| flowgen | v341_tune | report | C | `cover_letter.closing.proof: "ripple.git_verification"` | `cover_letter.closing.proof: "ripple.analysis_tools"` |
| flowgen | v341_tune | report | C | `cover_letter.closing._proof: "RIPPLE, whose Git-diff check flags missing tests and stale callers"` | `cover_letter.closing._proof: "RIPPLE, which checks every claim against evidence"` |
| flowgen | v341_tune | report | C | (none) | `cover_letter.closing.v348c.before: "I want to write and maintain key agent-building artifacts at FlowGen Labs, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers."` |
| flowgen | v341_tune | report | C | (none) | `cover_letter.closing.v348c.before_proof: "ripple.git_verification"` |
| flowgen | v341_tune | report | C | (none) | `cover_letter.closing.v348c.specificity_before: 0` |
| flowgen | v341_tune | report | C | (none) | `cover_letter.closing.v348c.rule: "C1"` |
| flowgen | v341_tune | report | C | `cover_letter.closing.text: "I want to write and maintain key agent-building artifacts at FlowGen Labs, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers."` | `cover_letter.closing.text: "I want to write and maintain key agent-building artifacts at FlowGen Labs, drawing on RIPPLE, which checks every claim against evidence."` |
| flowgen | v341_tune | report | C | `cover_letter.words_total: 178` | `cover_letter.words_total: 175` |
| flowgen | v341_tune | report | C | `verify_changes_v344[3].change: "Closing responsibility \"write and maintain key agent-building artifacts\" with proof ripple.git_verification (ai)"` | `verify_changes_v344[3].change: "Closing responsibility \"write and maintain key agent-building artifacts\" with proof ripple.analysis_tools (ai)"` |
| flowgen | v341_tune | report | C | (none) | `closing_v348c.before: "I want to write and maintain key agent-building artifacts at FlowGen Labs, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers."` |
| flowgen | v341_tune | report | C | (none) | `closing_v348c.before_proof: "ripple.git_verification"` |
| flowgen | v341_tune | report | C | (none) | `closing_v348c.specificity_before: 0` |
| flowgen | v341_tune | report | C | (none) | `closing_v348c.rule: "C1"` |
| flowgen | v341_tune | report | C | (none) | `closing_v348c.after: "I want to write and maintain key agent-building artifacts at FlowGen Labs, drawing on RIPPLE, which checks every claim against evidence."` |
| flowgen | v341_tune | report | C | (none) | `closing_v348c.after_proof: "ripple.analysis_tools"` |
| klaviyo | v340_original | letter_txt | C | `I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an accou` | `I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an accou` |
| klaviyo | v340_original | report | C | `cover_letter.words: 181` | `cover_letter.words: 178` |
| klaviyo | v340_original | report | C | `cover_letter.closing.responsibility: "develop robust, reliable and scalable services to serve AI models"` | `cover_letter.closing.responsibility: "create human and automated evals to ensure high AI model quality"` |
| klaviyo | v340_original | report | C | `cover_letter.closing.jd_line: "develop robust, reliable and scalable services to serve AI models in production environments"` | `cover_letter.closing.jd_line: "- Experience creating human and automated evals to ensure high AI model quality."` |
| klaviyo | v340_original | report | C | `cover_letter.closing.proof: "ledger.ci"` | `cover_letter.closing.proof: "ripple.analysis_tools"` |
| klaviyo | v340_original | report | C | `cover_letter.closing.proof_kind: "testing"` | `cover_letter.closing.proof_kind: "ai"` |
| klaviyo | v340_original | report | C | `cover_letter.closing._proof: "LedgerFlow, where a GitHub Actions CI workflow runs every automated test"` | `cover_letter.closing._proof: "RIPPLE, which checks every claim against evidence"` |
| klaviyo | v340_original | report | C | (none) | `cover_letter.closing.v348c.before: "I want to develop robust, reliable and scalable services to serve AI models at Klaviyo, drawing on LedgerFlow, where a GitHub Actions CI workflow runs every automated test."` |
| klaviyo | v340_original | report | C | (none) | `cover_letter.closing.v348c.before_proof: "ledger.ci"` |
| klaviyo | v340_original | report | C | (none) | `cover_letter.closing.v348c.specificity_before: 0` |
| klaviyo | v340_original | report | C | (none) | `cover_letter.closing.v348c.rule: "C2+C1"` |
| klaviyo | v340_original | report | C | (none) | `cover_letter.closing.v348c.specificity_after: 2` |
| klaviyo | v340_original | report | C | (none) | `cover_letter.closing.v348c.domain_words: 2` |
| klaviyo | v340_original | report | C | `cover_letter.closing.text: "I want to develop robust, reliable and scalable services to serve AI models at Klaviyo, drawing on LedgerFlow, where a GitHub Actions CI workflow runs every automated test."` | `cover_letter.closing.text: "I want to create human and automated evals to ensure high AI model quality at Klaviyo, drawing on RIPPLE, which checks every claim against evidence."` |
| klaviyo | v340_original | report | C | `cover_letter.words_total: 188` | `cover_letter.words_total: 185` |
| klaviyo | v340_original | report | C | `verify_changes_v344[2].change: "Closing responsibility \"develop robust, reliable and scalable services to serve AI models\" with proof ledger.ci (testing)"` | `verify_changes_v344[2].change: "Closing responsibility \"create human and automated evals to ensure high AI model quality\" with proof ripple.analysis_tools (ai)"` |
| klaviyo | v340_original | report | C | `verify_changes_v344[2].jd_line: "develop robust, reliable and scalable services to serve AI models in production environments"` | `verify_changes_v344[2].jd_line: "- Experience creating human and automated evals to ensure high AI model quality."` |
| klaviyo | v340_original | report | C | (none) | `closing_v348c.before: "I want to develop robust, reliable and scalable services to serve AI models at Klaviyo, drawing on LedgerFlow, where a GitHub Actions CI workflow runs every automated test."` |
| klaviyo | v340_original | report | C | (none) | `closing_v348c.before_proof: "ledger.ci"` |
| klaviyo | v340_original | report | C | (none) | `closing_v348c.specificity_before: 0` |
| klaviyo | v340_original | report | C | (none) | `closing_v348c.rule: "C2+C1"` |
| klaviyo | v340_original | report | C | (none) | `closing_v348c.specificity_after: 2` |
| klaviyo | v340_original | report | C | (none) | `closing_v348c.domain_words: 2` |
| klaviyo | v340_original | report | C | (none) | `closing_v348c.after: "I want to create human and automated evals to ensure high AI model quality at Klaviyo, drawing on RIPPLE, which checks every claim against evidence."` |
| klaviyo | v340_original | report | C | (none) | `closing_v348c.after_proof: "ripple.analysis_tools"` |
| lumen | holdout | letter_txt | C | `I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. GoingOnce is a multi-agent car marketplace prototype my team of four built, where I mainly built the Negotiate and Fleet agents. A human approves every simulated bid or listing befo` | `I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. GoingOnce is a multi-agent car marketplace prototype my team of four built, where I mainly built the Negotiate and Fleet agents. A human approves every simulated bid or listing befo` |
| lumen | holdout | report | C | `cover_letter.words: 175` | `cover_letter.words: 172` |
| lumen | holdout | report | C | `cover_letter.closing.proof: "ripple.git_verification"` | `cover_letter.closing.proof: "ripple.analysis_tools"` |
| lumen | holdout | report | C | `cover_letter.closing._proof: "RIPPLE, whose Git-diff check flags missing tests and stale callers"` | `cover_letter.closing._proof: "RIPPLE, which checks every claim against evidence"` |
| lumen | holdout | report | C | (none) | `cover_letter.closing.v348c.before: "I want to build AI agents that automate back-office workflows at Lumen Agents, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers."` |
| lumen | holdout | report | C | (none) | `cover_letter.closing.v348c.before_proof: "ripple.git_verification"` |
| lumen | holdout | report | C | (none) | `cover_letter.closing.v348c.specificity_before: 3` |
| lumen | holdout | report | C | (none) | `cover_letter.closing.v348c.rule: "C1"` |
| lumen | holdout | report | C | `cover_letter.closing.text: "I want to build AI agents that automate back-office workflows at Lumen Agents, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers."` | `cover_letter.closing.text: "I want to build AI agents that automate back-office workflows at Lumen Agents, drawing on RIPPLE, which checks every claim against evidence."` |
| lumen | holdout | report | C | `cover_letter.words_total: 182` | `cover_letter.words_total: 179` |
| lumen | holdout | report | C | `verify_changes_v344[1].change: "Closing responsibility \"build AI agents that automate back-office workflows\" with proof ripple.git_verification (ai)"` | `verify_changes_v344[1].change: "Closing responsibility \"build AI agents that automate back-office workflows\" with proof ripple.analysis_tools (ai)"` |
| lumen | holdout | report | C | (none) | `closing_v348c.before: "I want to build AI agents that automate back-office workflows at Lumen Agents, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers."` |
| lumen | holdout | report | C | (none) | `closing_v348c.before_proof: "ripple.git_verification"` |
| lumen | holdout | report | C | (none) | `closing_v348c.specificity_before: 3` |
| lumen | holdout | report | C | (none) | `closing_v348c.rule: "C1"` |
| lumen | holdout | report | C | (none) | `closing_v348c.after: "I want to build AI agents that automate back-office workflows at Lumen Agents, drawing on RIPPLE, which checks every claim against evidence."` |
| lumen | holdout | report | C | (none) | `closing_v348c.after_proof: "ripple.analysis_tools"` |

