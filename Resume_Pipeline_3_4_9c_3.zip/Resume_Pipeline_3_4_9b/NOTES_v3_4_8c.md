# v3.4.8c notes (2026-10-19)

## What you need to do

1. Project instructions: delete everything and paste the full text of `2_PROJECT_INSTRUCTIONS_paste.txt` (7,581
   characters; only the version and the hash lock changed).
2. Sources: re-upload the 7 files in `1_upload_to_ChatGPT_Sources/`. Changed: resume_pipeline_v3_2.py, master.json,
   bullet_bank.json, Master_Resume_Context_LEAN_CURRENT_v3_2.md. Unchanged: Resume_Template_CURRENT.tex,
   plan_template.json, bank_check.py.
3. Optional: send `Judge_Batch_v3_4_8c.md` to the judge.

Hash lock: pipeline fb67023f | master a5641f0c | bank 6ce82778 | template dc281778 | context md cf22e3fc.

## Acceptance

- Determinism: a second full run is identical to `snap_v348c_C` (timestamps normalized).
- Flags off: with the eight new flags off, all 124 fixtures equal `baseline_v348b`; only the version label differs, on the
  two stop fixtures fonzi and cisco_no_title.
- Gates: T, W, F, S, J and C each PASS against the previous snapshot with 0 unpredicted changes on the 53 originals and the
  20 holdouts and 0 guard failures (counts in the table below; every changed line in DIFF_REPORT_v348c.md).
- One page: all 122 built resumes compile to 1 PDF page (report.json `pdf_pages`); the 2 stops build no resume.
- bank_check: 118 variants, 0 failing; Experience variants 10/10. Selftests v341 to v348b and the new selftest_v348c pass.
  audit_v344 PASS (fallback closings 11 of 122, 9.0%; longest closing 30 words; longest letter 200 words).
- Scores: every tuned group 10.00 (resume and letter). Holdouts 9.85 / 9.97, the same as v3.4.8b (the three holdouts
  below 9.5, acme_cloud, twitch and linkedin_ai, were already there in 8b).
- Real postings:
  - zoro_fullstack, alml_engineer and meritore_capgemini show no Fleet bullet and no Fleet sentence in the letter. The
    word "Fleet" stays on alml and meritore only inside the GoingOnce overview bullet, which names the team's four agents
    (Buy, Sell, Negotiate and Fleet); that bullet is the project's description, not Fleet work, and removing the name
    would need a bank change outside W and F1.
  - alml's Languages & Databases line is "Python, SQL, PostgreSQL" (3 items, languages first; PostgreSQL is shown by its
    LedgerFlow bullet).
  - alml's closing now uses Fraud evidence (the edge-type ablation).
  - ust_software_engineer: resume differs from 8b only in the Languages & Databases order; letter, tracker and outreach are
    identical.
  - tiktok_appsec and cdi show the Timing note.
  - elevenlabs's closing names the permissioning services, with LaunchOps's server-enforced owners and prerequisites.

## Per-fix result (changed fixtures; details and every changed line in DIFF_REPORT_v348c.md)

| Fix | Flag(s) | Gate vs | Changed fixtures | Page-visible changes |
|---|---|---|---|---|
| T start dates | start_date_parse_v348 | baseline_v348b | 2 (+2 stop labels) | Notes / Timing and tracker Blockers "start date" on cdi, tiktok_appsec |
| W bank wording | bank_wording_v348 | snap_v348c_T | 63 | 22 resume pages (one bullet each) |
| F Fleet | fleet_language_model_v348, fleet_repick_v348 | snap_v348c_W | 17 | 16 pages lose Fleet; us_cold only gains the log line |
| S Skills lines | skills_lines_v348 | snap_v348c_F | 99 | the Languages & Databases line |
| J heading move | heading_move_v348 | snap_v348c_S | 11 | 10 LaunchOps headings gain JavaScript |
| C closings | closing_proof_map_v348, closing_specific_v348 | snap_v348c_J | 8 | the closing sentence |

Every gate: 0 unpredicted changes on the 53 originals and the 20 holdouts, 0 guard failures, longest letter 200 words.

### W: pages whose resume changed

- ripple.git.b -> ripple.git.c: allergan, audit01, audit09, birthmodel, chewy, meridian_sw, qa_sdet
- ripple.eff.a -> ripple.eff.b: atoms, flowgen, google_sre, klaviyo, lumen, meritore_capgemini, nimble, novita, nvidia_devtech
- ripple.cc.a -> ripple.cc.d: audible, audible_md, linkedin_ai, nvidia_ai_cloud, quora
- goingonce.ui.a -> goingonce.ui.c: twitch_se1

### F: Fleet

- F1 (in-place swap to the plain-code bullet without Claude): cardinal, harvey, inspire11, ng_fullstack, rocketmoney,
  sparkline, tiktok_appsec.
- F2 (GoingOnce re-pick without Fleet): audit05, brightpath_fs, cobalt, frontend, ixl, loopwell, lumen, northwind,
  pinecrest.
- Fixtures that still show the Fleet bullet: us_cold only (a warehouse / cold-storage posting: the logistics test keeps
  it, and report.json fleet_v348c logs the logistics line). zoro, alml_engineer and meritore_capgemini show no Fleet.

### C: closings (before -> after)

- **alml_engineer** (C1)
  - Before: I want to optimize models for latency, accuracy, and scalability in real-world applications on your team, building on RIPPLE, whose Git-diff check flags missing tests and stale callers.
  - After: I want to optimize models for latency, accuracy, and scalability in real-world applications on your team, building on my fraud model's edge-type ablation, which showed the graph adds 0.016 AUC.
- **audit12** (C2+C1)
  - Before: I want to implement Python services for LLM integration, request validation, and tool calling at VectorForge AI, building on my LLM engine's provider failover.
  - After: I want to build evaluation datasets that represent routine use, unusual inputs, and adversarial cases at VectorForge AI, drawing on my LLM engine's provider failover.
- **doordash_mdx** (C2+C1)
  - Before: I want to build and run ML-powered products at DoorDash, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers.
  - After: I want to build agentic systems that increase the velocity of ML development at DoorDash, drawing on my LLM engine's provider failover.
- **elevenlabs** (C2)
  - Before: I want to build and improve the building blocks customers touch directly at ElevenLabs, drawing on LaunchOps, where every onboarding task has an owner and prerequisites the server enforces.
  - After: I want to design and build generic resource and permissioning services at ElevenLabs, drawing on LaunchOps, where every onboarding task has an owner and prerequisites the server enforces.
- **figure** (C2)
  - Before: I want to design, implement, and test features for the robot software platform at Figure, building on the process management I wrote in C for Pintos.
  - After: I want to integrate, debug, and validate updates on real robot hardware at Figure, building on the process management I wrote in C for Pintos.
- **flowgen** (C1)
  - Before: I want to write and maintain key agent-building artifacts at FlowGen Labs, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers.
  - After: I want to write and maintain key agent-building artifacts at FlowGen Labs, drawing on RIPPLE, which checks every claim against evidence.
- **klaviyo** (C2+C1)
  - Before: I want to develop robust, reliable and scalable services to serve AI models at Klaviyo, drawing on LedgerFlow, where a GitHub Actions CI workflow runs every automated test.
  - After: I want to create human and automated evals to ensure high AI model quality at Klaviyo, drawing on RIPPLE, which checks every claim against evidence.
- **lumen** (C1)
  - Before: I want to build AI agents that automate back-office workflows at Lumen Agents, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers.
  - After: I want to build AI agents that automate back-office workflows at Lumen Agents, drawing on RIPPLE, which checks every claim against evidence.

C2 scoring rule and margin: specificity = +1 for each word naming the product, team or users (a users word such as
customers / merchants / patients, or a content word whose 6-letter stem the posting's own description uses: its title,
headers and paragraphs), -1 for each generic word (software, components, building, blocks, applications, solutions,
features, products, systems, tools, code, services, platforms, technology); quality adjectives and verbs count 0. The
closing switches only when the 8b responsibility scores <= 0 and a candidate scores at least 2 higher (margin 2) with at
least 2 domain words, comes from a responsibility line (a list item or a "you will" sentence, never the company's
mission or a boast), does not name the company, and has a proof of its own kind that the line itself names.

## Self-scores for the 4 real postings (out of 10)

| Category | zoro_fullstack | alml_engineer | ust_software_engineer | meritore_capgemini |
|---|---|---|---|---|
| Experience selection | 9.5 | 9.5 | 9.5 | 9.5 |
| Experience bullet quality | 9.5 | 9.5 | 9.5 | 9.5 |
| Project selection | 9.5 | 10 | 9.5 | 9.5 |
| Project bullet quality | 9.5 | 9.5 | 9.5 | 9.5 |
| Skills selection | 9.5 | 9.5 | 9.5 | 9.5 |
| ATS coverage | 9.5 | 9.5 | 9.0 | 9.5 |
| Senior technical HR read | 9.5 | 9.5 | 9.5 | 9.0 |

Why the scores below 9.5 cannot go higher from master:
- ust ATS 9.0: three high-priority posting terms are matched only by alias in Skills: "object-oriented design" (OOP),
  "CI/CD" (Continuous Integration) and "cloud platforms" (AWS). Master supports CI (LedgerFlow's GitHub Actions workflow)
  but has no continuous-deployment evidence, so "CI/CD" cannot be written as Jay's skill; the other two have no
  stronger wording in master.
- meritore HR 9.0: Fit is Medium because the posting gives only 4 parseable requirements, too few for the script to call
  it High, and the posting asks for 12 or 24 months of experience, which a senior reviewer will weigh against the
  internship and research experience master records. The page itself has 4/4 requirements visible.

Why the 9.5s are not 10: the remaining gaps are terms matched only by alias (zoro: Full-Stack Development; alml: Model
Evaluation; meritore: Git from "version control") and the student-level experience that master records. None can be
closed without adding evidence that master does not have.

## Assumptions and judgement calls

- T: the Timing note also sets the tracker Blockers label "start date" (the 8b label harvey already used). It is a
  label, not a blocker: Fit and eligibility are unchanged.
- W/F1 verbs: "Measured" (W3) and "Kept" (F1) are in the verb taxonomy, unique on every page and not Experience verbs;
  "Handled" and "Tracked" were not in the taxonomy. ripple.cc.d drops "Python" from the text because master has no
  evidence that it was the language of the tests. W4 replaces only ripple.cc.a (the variant with "checking the code that
  Claude Code generated"); ripple.cc.b, ripple.cc.c and the 1-line ripple.cc.s1 keep their 8b wording, which already
  names the 241-test suite (ust_software_engineer shows ripple.cc.c, and ust must stay unchanged apart from Skills order).
- F1: goingonce.determ.b is a last resort, so the 7c in-place swaps that already worked (zoro, alml, meritore, amplitude,
  cdi, ...) keep their 7c replacement bullet. F2 re-picks leave no selector log behind (the preflight messages are those
  of the 8b page).
- F predictor (honest record): predict_v348c_F.py was written after the F code was first tried on a development copy;
  it restates only your request, imports no v3.4.8c code and was frozen before the full F run.
- C predictor (honest record): the first C2 rule ("+1 for any word repeated in the role text") chose lines full of
  repeated adjectives ("scalable, reliable, and innovative solutions") on a development smoke, so predict_v348c_C.py was
  revised to the rule above before it was run on its baseline and before the full C run. The C code was then tightened
  further (responsibility lines only, no boasts, a proof the line names itself); the predictions stayed a superset (8
  fixtures changed out of 59 predicted to change, 0 unpredicted).
- C1 new master proofs fraud.graphsage_result and fraud.edge_ablation_result only restate master facts already on the
  page (0.9259 against about 0.858 AUC-ROC; the graph adds 0.016 AUC). alml's letter already gives the GraphSAGE AUC, so
  its closing uses the edge-type ablation (a different Fraud fact, as you asked).
- elevenlabs: its posting's permissioning line is "Designing and building generic resource and permissioning services";
  the 8b check read "and permissioning" as a second verb. C2 treats an "-ing" word the posting also uses as a plural noun
  ("permissions") as a noun. The proof is LaunchOps's server-enforced ownership and prerequisites (the server-checks fact
  itself is already in the letter, so a different LaunchOps fact is used).
- Amendments (documented, predictions untouched): S-A1 flowgen's Skills cache key changed while its rendered line did
  not (an unrendered Skills ladder state was reordered); J-A1 meridian_sw logs a JavaScript move it could not make (the
  LaunchOps heading already has 4 technologies).
- Audit fix after the C run: audit_v344 flagged rocketmoney because its closing reused a fact that the F1 letter sentence
  already gave (the two shared more than half their words). The goingonce.determ.b letter sentence in master was
  reworded ("... every language-model call keeps a saved fallback, so results repeat"; same facts). rocketmoney and
  tiktok_appsec, the only fixtures that use that sentence, were re-run in each configuration from F on and replaced in
  snap_v348c_F, _S, _J and _C; every gate was then re-run on the final snapshots and passes.
- Judge batch: the last batch (v3.4.8a, 15 packages) without the duplicate audible_md, so 14 packages.
- bullet_bank.json changed only for the W and F1 variants (plus the bank_check write-back fields conflicts_with, measured
  and status, which the old variants gained only for the new ids).
