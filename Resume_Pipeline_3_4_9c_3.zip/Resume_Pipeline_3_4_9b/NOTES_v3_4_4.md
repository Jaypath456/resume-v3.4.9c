# Resume pipeline v3.4.4 (2026-10-16)

## Results

| Group | Fixtures | Resume | Letter |
|---|---|---|---|
| v340_original | 53 | 10.00 | 10.00 |
| v341_tune | 36 | 10.00 | 10.00 |
| v342_new | 6 | 10.00 | 10.00 |
| v343_new | 2 | 10.00 | 10.00 |
| v344_new (laminar, audible_md) | 2 | 10.00 | 10.00 |
| **holdout (never tuned)** | 20 | 9.85 | 9.97 |

- 119 fixtures: 117 build and pass, plus the 2 expected stops (fonzi: no requirements; cisco_no_title: no title line). No regression on the original 53.
- Holdouts are reported separately and were not touched. The three below 9.5 (acme_cloud, twitch, linkedin_ai) are the same three as in v3.4.3.

## Acceptance checks (audit_v344.py over all 117 built fixtures: PASS)

| Check | Target | Result |
|---|---|---|
| Closings that repeat a letter proof | 0 | 0 |
| Role-family fallback closings | 10% or less | 11 of 117 (9.4%): audit11, dominos, ga_asi, macys, nvidia_devtech, pinecrest, raydar_backend, roblox, serco_snow, sparkline, swisslog |
| Longest closing | 30 words or fewer | 30 |
| Longest letter (greeting and sign-off included) | 200 words or fewer | 200 |
| ".." in letter, outreach, tracker or resume | none | none |
| tracker_row.json | exactly 11 columns, Status "Applied" | all 117 |

- selftest_v341, v342, v343 and v344: all pass.
- bank_check: 112/112 variants ok; 9/9 Experience variants ok (variant I renders 2 lines like the original).

## Hash lock

| File | sha256 |
|---|---|
| resume_pipeline_v3_2.py | 612d4d002e221cca7b19ee7436d9f94b69c14041c062e932c3cd4523a9500bf6 |
| master.json | 4755a8f4420a265c568a4f6ca5562e9bb803bcb1225dd5291695ee1bed1fc057 |
| bullet_bank.json | 0de9bb9d7e46b29e9235a1d0c30a370d2ea17ae1a847e65e129a3fead39b5c0c |
| Resume_Template_CURRENT.tex | a8fbff8eeef8f1b2a2aee90b7ddb32a8d7cffa299784a252e9f384c93145accb (unchanged) |
| Master_Resume_Context_LEAN_CURRENT_v3_2.md | e5b1360c23dd5e4d57f26d559d88775877a3b0289d8e4614b7c55aa8a5553e2d |

The Project instructions (2_PROJECT_INSTRUCTIONS_paste.txt) are 7,470 characters and carry this hash lock.

## What jay needs to do

1. Paste 2_PROJECT_INSTRUCTIONS_paste.txt as the Project instructions (ChatGPT and Claude).
2. Delete the 7 old Sources and upload the 7 files in 1_upload_to_ChatGPT_Sources/. plan_template.json changed too this time.
3. In the tracker sheet, delete the columns "Career Status Portal", "Visa / Sponsorship" and "Lane". The 11 columns that remain end with Blockers. If the Summary tab counted by Lane, switch it to Source and Fit. 0_SETUP_STEPS.txt step 2b has the exact column order.
4. Optional: send Judge_Batch_v3_4_4.md to the judge.
5. To record an outcome later, send `status: <Company> | <Role> | <Rejected / Interview / Offer / Withdrawn>`.

## Judge_Output_v3_4_3_GPT6.md: every deduction, per package

All 58 deductions are listed. Each quoted line was checked with a grep against the regenerated page (pdftotext of resume.pdf), the letter .txt or the judge packet inventory, and the table generator stops if any quote is missing.
Totals: 30 Fixed, 8 Partly fixed, 16 Remains, 1 Remains by rule, 3 Not a defect.

"Remains" almost always means master has no evidence to add: a Git workflow, a Linux, Maven, Algorithms or JavaScript bullet, OTA or production ML work, or retail analysis. Adding any of these would invent evidence. Some others are fixed Experience lines that come verbatim from the template.

### Allergan Aesthetics | Integration Engineer  (`packages/allergan`)

| Judge deduction | Status | Page / letter line (grep-verified) |
|---|---|---|
| 0.5 ATS: Git only in Tools | **Remains** - Git now shows in the RIPPLE heading and a bullet, but no Git workflow bullet exists in master to add (no new evidence invented). | page: "RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic"<br>page: "reads its Git diff and flags unexpected edits" |
| 1.0 heartbeat 'restored' unsupported | **Not a defect** - master records it; the judge inventory now lists the line, so the next judge sees it. | page: "Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing."<br>inventory: "Responded to heartbeat-detected production failures and restored affected services." |
| 0.5 generic tagline | **Fixed** | page: "Master's CS student building AWS integrations, event-driven APIs, and AI-assisted software." |
| 0.25 Thesis modules + pipeline combined | **Remains** - fixed Experience text (verbatim from the template); no approved variant splits it. | page: "Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket" |
| 0.25 telemedicine bullet combines features | **Remains** - fixed Experience text (verbatim from the template). | page: "Delivered a WebRTC telemedicine feature that let remote doctors review test results" |
| 0.25 'build ... building on' closing | **Fixed** | letter: "I want to build, test, and deploy integrations and APIs at Allergan Aesthetics, drawing on LedgerFlow, where each payment takes effect exactly once." |

### DoorDash | Software Engineer, ML Infrastructure (MDX)  (`packages/doordash_mdx`)

| Judge deduction | Status | Page / letter line (grep-verified) |
|---|---|---|
| 0.5 ATS: Model Evaluation only in Skills | **Partly fixed** - RIPPLE's evaluation bullet backs Model Evaluation; Machine Learning still has no bullet on this page (Fraud is not selected, see next line). | page: "Evaluated the agent on 30 unseen tasks from 16 real code repositories with zero unsupported claims accepted."<br>page: "AI/ML: AI Agents, Agentic Workflows, Model Evaluation, Machine Learning, LLMs, Tool Calling" |
| 1.0 heartbeat 'restored' unsupported | **Not a defect** - master records it; the inventory now lists it. | page: "Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing."<br>inventory: "Responded to heartbeat-detected production failures and restored affected services." |
| 1.0 LedgerFlow instead of Fraud | **Remains (by rule)** - v3.4.3 rule 6 keeps LedgerFlow on agentic / ML-infrastructure postings that ask for distributed systems; the judge's swap would drop the only distributed-systems evidence. | page: "LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL" |
| 0.5 top third leads with document extraction | **Remains** - HeinOnline is the fixed first Experience role; RIPPLE now leads the projects. | page: "Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals"<br>page: "PERSONAL PROJECTS RIPPLE: Agentic Change-Impact Analysis" |
| 0.25 Thesis modules + pipeline combined | **Remains** - fixed Experience text. | page: "Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket" |
| 1.0 hook vs production ML infrastructure | **Remains** - master has no production ML-infrastructure evidence; the letter makes no such claim. | letter: "I want to design and implement infrastructure that lets agents propose, run, and evaluate modeling experiments for DoorDash's ML platform." |
| 0.5 letter over 200 words | **Fixed** - 199 words counted as a reader counts them. | letter: "I want to build and run ML-powered products at DoorDash, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers." |
| 0.25 'RIPPLE, whose AI-generated code' | **Fixed** | letter: "Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite." |

### Figure | Embedded Software Engineering Intern, Platform  (`packages/figure`)

| Judge deduction | Status | Page / letter line (grep-verified) |
|---|---|---|
| 0.5 ATS: Linux only in Skills | **Remains** - master has no Linux bullet to add (preflight found no bank bullet naming it). | page: "Tools: Linux, Apache Kafka, GitHub Actions, Git, Claude Code, AWS (EC2/RDS), Docker" |
| 0.5 networking fundamentals indirect | **Remains** - the VPC bullet is the only networking evidence in master. | page: "Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access." |
| 0.5 top third / move Pintos up | **Partly fixed** - Pintos now leads the projects; HeinOnline stays the first Experience role (fixed section order). | page: "PERSONAL PROJECTS Pintos Operating System: User Programs Layer | C, x86, Operating Systems, Concurrency" |
| 0.5 broad tagline | **Fixed** | page: "Master's CS student building tested C systems code with process management and synchronization." |
| 0.25 'Verified' undersells Pintos | **Fixed** | page: "Implemented a teaching operating system's user-programs layer in C, passing all 80 tests" |
| 0.25 second Pintos bullet repeats | **Fixed** | page: "Enforced thread synchronization with locks around shared kernel resources and safety checks on memory access" |
| 1.0 hook misses OTA / update reliability | **Partly fixed** - the hook now names updates; master has no OTA or firmware evidence, so no transfer claim is made. | letter: "keeps Figure's robot fleet running safely through every update." |
| 0.5 broad closing | **Remains** - the posting's responsibility line is broad; the proof changed to process management (not repeated in the letter). | letter: "I want to design, implement, and test features for the robot software platform at Figure, building on the process management I wrote in C for Pintos." |

### Macy's | 2027 Tech Early Careers - Software Engineer  (`packages/macys`)

| Judge deduction | Status | Page / letter line (grep-verified) |
|---|---|---|
| 0.5 ATS: Agile only in Skills | **Fixed** - Experience variant I. | page: "Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum" |
| 0.5 analysis / trends not visible | **Remains** - no retail or business-analysis evidence in master. | page: "Merged all three sources into one validated structure with fuzzy matching" |
| 1.0 heartbeat 'restored' unsupported | **Not a defect** - master records it; the inventory now lists it. | page: "Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing."<br>inventory: "Responded to heartbeat-detected production failures and restored affected services." |
| 0.5 tagline | **Fixed** | page: "Master's CS student building Java software for connected commerce with collaborative teams." |
| 0.25 'Verified' Pintos | **Fixed** | page: "Implemented a teaching operating system's user-programs layer in C, passing all 80 tests" |
| 0.25 second Pintos bullet repeats | **Fixed** | page: "Enforced thread synchronization with locks around shared kernel resources and safety checks on memory access" |
| 0.5 broad closing | **Partly fixed** - proof no longer repeats the overdraft result; the closing is still the role-family fallback (no responsibility line in this posting passes the filters). | letter: "I want to build dependable, well-tested software with the team at Macy's, drawing on LedgerFlow, where a GitHub Actions CI workflow runs every automated test." |
| 0.25 company repeated in opening | **Fixed** | letter: "I am applying for the Macy's 2027 Tech Early Careers - Software Engineer role." |

### Twitch | Software Engineer I  (`packages/twitch_se1`)

| Judge deduction | Status | Page / letter line (grep-verified) |
|---|---|---|
| 0.5 ATS: Algorithms / Data Structures only in Skills | **Remains** - master has no algorithm bullet for the projects this posting ranks. | page: "Software Engineering: Algorithms, Data Structures, System Design, Distributed Systems" |
| 0.5 GoingOnce 24 tests attributed to Jay | **Fixed** | page: "backed by the team's 24 tests for the simulated marketplace prototype." |
| 0.5 LaunchOps heading omits ReactJS | **Fixed** | page: "LaunchOps: Employee Onboarding Platform | Django, Python, Go, ReactJS" |
| 0.25 Fleet agent bullet less relevant | **Fixed** - the interface bullet replaces it. | page: "Created the Streamlit and React interface for the agents' streaming API so users can follow each agent's progress live" |
| 0.25 double 'with' in team bullet | **Fixed** | page: "Prototyped a multi-agent car marketplace with a four-person team: Buy, Sell, Negotiate, and Fleet agents" |
| 1.0 'millions of concurrent users' closing | **Fixed** - scale claims are rejected as closings. | letter: "I want to maintain and support the live services at Twitch, drawing on the heartbeat monitor I built at Thesis Mumbai Tech, where I restored services after detected failures." |
| 0.25 closing repeats the overdraft result | **Fixed** | letter: "drawing on the heartbeat monitor I built at Thesis Mumbai Tech" |

### United States Cold Storage | Java Developer I  (`packages/us_cold`)

| Judge deduction | Status | Page / letter line (grep-verified) |
|---|---|---|
| 0.5 ATS: JavaScript bullet | **Partly fixed** - JavaScript shows in the LaunchOps and GoingOnce headings and React bullets; master has no bullet naming JavaScript itself. | page: "LaunchOps: Employee Onboarding Platform | Django, ReactJS, JavaScript"<br>page: "Designed a Django REST and React onboarding platform" |
| 0.5 ATS: Scrum only in Skills | **Fixed** - Experience variant I. | page: "Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum" |
| 0.5 ATS: Maven has no bullet | **Remains** - master has no Maven build or test bullet. | page: "LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, Maven" |
| 0.5 ATS: Git only in Tools | **Partly fixed** - variant I adds pull-request review; no Git workflow bullet exists in master. | page: "reviewed and merged team pull requests." |
| 0.5 design patterns not stated | **Fixed** | page: "Wrote a transactional outbox, idempotent Kafka consumers, and a reconciliation check in Java" |
| 0.5 GoingOnce 24 tests attributed to Jay | **Fixed** | page: "backed by the team's 24 tests for the simulated marketplace prototype." |
| 0.5 top third emphasizes Python | **Remains** - HeinOnline is the fixed first Experience role; LedgerFlow leads the projects. | page: "PERSONAL PROJECTS LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, Maven" |
| 0.25 Fleet bullet too long | **Fixed** - the Fleet bullet is no longer selected. | page: "backed by the team's 24 tests for the simulated marketplace prototype." |
| 0.5 generic closing | **Remains** - the proof changed (no repeat of the CI line), but the responsibility is still generic. | letter: "I want to work on design, coding, and testing at United States Cold Storage, building on LedgerFlow, where each payment takes effect exactly once." |

### ElevenLabs | Full-Stack Engineer (Backend Leaning) - Platform Engineering  (`packages/elevenlabs`)

| Judge deduction | Status | Page / letter line (grep-verified) |
|---|---|---|
| 0.5 ATS: Data Structures only in Skills | **Remains** - no data-structure bullet in master for these projects. | page: "System Design, Data Structures, Debugging" |
| 0.5 test design indirect | **Remains** - the short CI variant was chosen to keep the one-page buffer. | page: "Configured a GitHub Actions CI workflow that runs all 94 of the ledger's tests." |
| 0.5 tagline misses permissions | **Fixed** | page: "Master's CS student building permissions and platform services for full-stack products." |
| 0.5 hook is a general responsibility | **Fixed** | letter: "I want to build the core platform foundations that every ElevenLabs product builds on, so users, workspaces and permissions stay correct and secure." |
| 1.0 no production / safe-change evidence in letter | **Fixed** | letter: "At Thesis Mumbai Tech, I reviewed and merged team pull requests, mentored new hires through weekly coding rounds, and responded to heartbeat-detected production failures by restoring the affected services." |
| 0.5 vague closing | **Partly fixed** - the permission checks now sit in the letter body, so the closing may not repeat them; the closing uses another LaunchOps proof. | letter: "Server-side permission checks block users from editing other users' tasks"<br>letter: "I want to ship customer-facing features end to end at ElevenLabs, drawing on LaunchOps, whose Go live-quiz service stays in sync across two copies." |

### Audible, Inc. | Software Development Engineer  (`packages/audible`)

| Judge deduction | Status | Page / letter line (grep-verified) |
|---|---|---|
| 0.5 ATS: Code Review only in Skills | **Fixed** - Experience variant I. | page: "Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum"<br>page: "reviewed and merged team pull requests." |
| 0.5 generic tagline | **Fixed** | page: "Master's CS student building maintainable, well-tested software with code review and monitoring." |
| 0.5 top third emphasizes extraction | **Partly fixed** - code review now sits in the first Thesis bullet; HeinOnline stays first (fixed order). | page: "Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum" |
| 0.5 hook restates the responsibility | **Fixed** | letter: "I want to develop, test, and maintain software components and applications that bring audio storytelling to Audible's listeners." |
| 1.0 letter misses operations / review / mentoring | **Fixed** | letter: "At Thesis Mumbai Tech, I reviewed and merged team pull requests, mentored new hires through weekly coding rounds, and responded to heartbeat-detected production failures by restoring the affected services." |
| 0.5 closing repeats the payment example | **Fixed** | letter: "building on LedgerFlow, where a GitHub Actions CI workflow runs every automated test." |

## The two new postings

- **Laminar (Jr. Machine Learning Developer)**:
  - The job-board widgets are removed: "Represents the skills you have", "Find out how your skills align", the H1B "Data Powered by" block and the company-profile lines.
  - Fraud ranks #1 with fraud.sage.s1, elliptic.s1, compare.a and edgeabl.a.
  - Blockers: none. The informational H1B text no longer creates a sponsorship blocker.
  - Fit is Low: JAX is unsupported, Databricks and GCP are gaps, and spectral data / chemometrics are not in master.
  - Closing: "I want to design and run experiments to evaluate and select machine learning models at Laminar, building on my fraud-model ablation study."
- **audible_md (the Audible posting pasted as markdown with widget lines)**:
  - The page and letter are identical to the plain Audible package (diff checked).
  - "Improve My Match", "Low Match" and "&#x20;" are removed.
  - The judge batch carries the full posting. "## Description" no longer splits it.

## Assumptions

- The hooks and taglines in the regression fixtures stand in for what the model writes in a live chat. I rewrote 5 fixture hooks: elevenlabs, tiktok_appsec, ironvale, research_phd and ios_randstad. The script's hook rules (first person, why the work appeals, 4+ words copied from the posting) are unchanged.
- The heartbeat line "restored the services it caught failing" stays on the page. master records "Responded to heartbeat-detected production failures and restored affected services" and the judge inventory now lists it, so the judge's flag is not a defect.
- "Implemented" is now an allowed opening verb for testing evidence, because Pintos test bullets open with it. jay wrote the layer the tests cover.
- New closing proofs restate master evidence only, with no new numbers:
  - Thesis heartbeat failure response, Thesis IoT pipeline, Thesis pull-request review;
  - Data Maven VPC access control;
  - the GoingOnce interface;
  - RIPPLE's tests and Git-diff check;
  - the fraud ablation, leakage, model comparison, Elliptic and GraphSAGE work.
  A proof whose number is not on the page is not used.
- The letter experience sentence uses the Thesis code-review / mentoring / failure-response sentence on code review, debugging, operations and mentorship postings. Healthcare postings keep the healthcare sentence, and data/ML roles keep HeinOnline or Go Digital.
- When a page fails the page or buffer checks because of a preflight preference, it is rebuilt without the preference. report.json logs "Preflight preference dropped".
- On agent and ML-infrastructure postings the LLM engine's runtime bullet is excluded. If no headline variant is left, the selector steps back through a logged ladder: failover / claim-check variants, then the original preference, then the full bank.
- score_all.py skips LaTeX `\item` lines in the healthcare check, because the paypal fixture contains a pasted resume.
- Weak closings that still pass all checks:
  - Macy's (role-family fallback);
  - US Cold ("work on design, coding, and testing");
  - Figure ("the robot software platform");
  - ElevenLabs ("ship customer-facing features end to end").
  The permission proof fits ElevenLabs better, but the letter body already uses it, and repeating it is now a failure.
- NOTES_v3_4_3.md stays in the zip as history.
