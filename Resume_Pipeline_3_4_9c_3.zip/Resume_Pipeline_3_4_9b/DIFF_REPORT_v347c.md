# DIFF_REPORT_v347c

Baseline: `3_validation/baseline_v347b` (unmodified v3.4.7b code). New: snapshot of a full run (v3.4.7c code, all v347_flags on).

Result: **PASS**. 130 changed lines in 15 fixtures; 0 unpredicted; 0 guard failures.

Normalized before comparing (the only fields that differ between two runs of the same code): report.json: timestamps.* (start, end, duration_ms of every stage); report.json: pdflatex_calls[*].duration_ms.

JSON files are compared as flattened `path: value` lines. `before` (none) means an added line; `after` (none) means a removed line.

## Guards

- A allowlist (25 fixtures): held; changed fixtures: alml_engineer, amplitude, anthropic_it, brillio, bti, cdi, cisco_no_title, flowgen, fonzi, meritore_capgemini, research_phd, rockstar, twitch_se1, vindexa, zoro_fullstack.
- R resume (GoingOnce Fleet bullet lines only; same headings, bullet counts, line counts, unique verbs; Skills untouched): held.
- L letter (only the Fleet sentence, replaced by the new bullet's sentence; <= 200 words): held.
- T tracker row and outreach: unchanged.
- J report (equal apart from the swap log and the swapped bullet's own measurements; Fit, blockers, gaps, Skills unchanged): held.


## C1 swaps

| Fixture | Group | Before (Fleet) | After | Lines | Letter |
|---|---|---|---|---|---|
| alml_engineer | v347_new | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `goingonce.negotiate.a` `Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` | 2 | unchanged |
| amplitude | holdout | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `goingonce.negotiate.a` `Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` | 2 | unchanged |
| anthropic_it | v340_original | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `goingonce.determ.a` `Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and photos with a saved fallback for every call, so results repeat.` | 2 | unchanged |
| brillio | v340_original | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `goingonce.negotiate.a` `Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` | 2 | unchanged |
| bti | v341_tune | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `goingonce.negotiate.a` `Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` | 2 | unchanged |
| cdi | v340_original | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `goingonce.negotiate.a` `Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` | 2 | unchanged |
| flowgen | v341_tune | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `goingonce.negotiate.a` `Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` | 2 | unchanged |
| meritore_capgemini | v347_new | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `goingonce.negotiate.a` `Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` | 2 | unchanged |
| research_phd | v341_tune | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `goingonce.negotiate.a` `Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` | 2 | unchanged |
| rockstar | v340_original | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `goingonce.negotiate.a` `Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` | 2 | Fleet sentence -> `I coded its Negotiate agent, where each side keeps a private price limit and a mediator closes the gap in rounds.` |
| twitch_se1 | v342_new | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `goingonce.ui.a` `Created the Streamlit and React interface for the agents' streaming API so users can follow each agent's progress live, step by step, while the four agents of the simulated marketplace prototype run.` | 2 | unchanged |
| vindexa | v340_original | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `goingonce.negotiate.a` `Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` | 2 | unchanged |
| zoro_fullstack | v347_new | `Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `goingonce.negotiate.a` `Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` | 2 | unchanged |

## Predicted swap vs result

Predicted by predict_v347c.py (rule restated, no Skills / letter / selector checks) but not shipped, or shipped differently. Each is a FAIL-CLOSED keep or a retry with the next bullet (NOTES_v3_4_7c.md gives the reason per fixture).

| Fixture | Predicted | Result |
|---|---|---|
| alml_engineer | goingonce.determ.a | goingonce.negotiate.a |
| amplitude | goingonce.determ.a | goingonce.negotiate.a |
| audit05 | goingonce.personal.a | Fleet kept |
| brightpath_fs | goingonce.personal.a | Fleet kept |
| bti | goingonce.determ.a | goingonce.negotiate.a |
| cardinal | goingonce.determ.a | Fleet kept |
| cdi | goingonce.determ.a | goingonce.negotiate.a |
| cobalt | goingonce.personal.a | Fleet kept |
| frontend | goingonce.personal.a | Fleet kept |
| harvey | goingonce.determ.a | Fleet kept |
| inspire11 | goingonce.determ.a | Fleet kept |
| ixl | goingonce.personal.a | Fleet kept |
| loopwell | goingonce.personal.a | Fleet kept |
| lumen | goingonce.negotiate.a | Fleet kept |
| meritore_capgemini | goingonce.determ.a | goingonce.negotiate.a |
| ng_fullstack | goingonce.determ.a | Fleet kept |
| northwind | goingonce.personal.a | Fleet kept |
| pinecrest | goingonce.personal.a | Fleet kept |
| rocketmoney | goingonce.determ.a | Fleet kept |
| sparkline | goingonce.determ.a | Fleet kept |
| tiktok_appsec | goingonce.determ.a | Fleet kept |
| zoro_fullstack | goingonce.determ.a | goingonce.negotiate.a |

## Every changed line

| Fixture | Group | File | Fix | Before | After |
|---|---|---|---|---|---|
| alml_engineer | v347_new | resume_tex | C1 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| alml_engineer | v347_new | report | C1 | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| alml_engineer | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| alml_engineer | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| alml_engineer | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| alml_engineer | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| alml_engineer | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| alml_engineer | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| alml_engineer | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| amplitude | holdout | resume_tex | C1 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| amplitude | holdout | report | C1 | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| amplitude | holdout | report | C1 | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| amplitude | holdout | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| amplitude | holdout | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| amplitude | holdout | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| amplitude | holdout | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| amplitude | holdout | report | C1 | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| amplitude | holdout | report | C1 | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| anthropic_it | v340_original | resume_tex | C1 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and photos with a saved fallback for every call, so results repeat.` |
| anthropic_it | v340_original | report | justified: added after the first gate run: the replacement bullet names a technology Skills already show (anthropic_it: Claude in the plain-code bullet), so the report now lists a bullet as evidence for that Skills term; Skills unchanged | (none) | `ats_coverage[0].also_in[0]: "bullet"` |
| anthropic_it | v340_original | report | justified: added after the first gate run: the replacement bullet names a technology Skills already show (anthropic_it: Claude in the plain-code bullet), so the report now lists a bullet as evidence for that Skills term; Skills unchanged | `preflight_v344.skills_or_heading_only[0].term: "Claude API"` | `preflight_v344.skills_or_heading_only: []` |
| anthropic_it | v340_original | report | justified: added after the first gate run: the replacement bullet names a technology Skills already show (anthropic_it: Claude in the plain-code bullet), so the report now lists a bullet as evidence for that Skills term; Skills unchanged | `preflight_v344.skills_or_heading_only[0].jd: "Claude"` | (none) |
| anthropic_it | v340_original | report | justified: added after the first gate run: the replacement bullet names a technology Skills already show (anthropic_it: Claude in the plain-code bullet), so the report now lists a bullet as evidence for that Skills term; Skills unchanged | `preflight_v344.skills_or_heading_only[0].shown_in[0]: "skills"` | (none) |
| anthropic_it | v340_original | report | justified: added after the first gate run: the replacement bullet names a technology Skills already show (anthropic_it: Claude in the plain-code bullet), so the report now lists a bullet as evidence for that Skills term; Skills unchanged | `preflight_v344.skills_or_heading_only[0].bullet_evidence: "no bank bullet or approved variant names it"` | (none) |
| anthropic_it | v340_original | report | C1 | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| anthropic_it | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| anthropic_it | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| anthropic_it | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.determ.a"` |
| anthropic_it | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| anthropic_it | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after_text: "Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and photos with a saved fallback for every call, so results repeat."` |
| anthropic_it | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| anthropic_it | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].verb: "Kept"` |
| brillio | v340_original | resume_tex | C1 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| brillio | v340_original | report | C1 | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| brillio | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| brillio | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| brillio | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| brillio | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| brillio | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| brillio | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| brillio | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| bti | v341_tune | resume_tex | C1 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| bti | v341_tune | report | C1 | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| bti | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| bti | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| bti | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| bti | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| bti | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| bti | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| bti | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| cdi | v340_original | resume_tex | C1 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| cdi | v340_original | report | C1 | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| cdi | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| cdi | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| cdi | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| cdi | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| cdi | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| cdi | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| cdi | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| cisco_no_title | v343_new | report | justified: version label v3.4.7b -> v3.4.7c (not a fix): report.json carries pipeline_version only on the two expected stops | `pipeline_version: "v3.4.7b"` | `pipeline_version: "v3.4.7c"` |
| flowgen | v341_tune | resume_tex | C1 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| flowgen | v341_tune | report | C1 | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| flowgen | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| flowgen | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| flowgen | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| flowgen | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| flowgen | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| flowgen | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| flowgen | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| fonzi | v341_tune | report | justified: version label v3.4.7b -> v3.4.7c (not a fix): report.json carries pipeline_version only on the two expected stops | `pipeline_version: "v3.4.7b"` | `pipeline_version: "v3.4.7c"` |
| meritore_capgemini | v347_new | resume_tex | C1 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| meritore_capgemini | v347_new | report | C1 | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| meritore_capgemini | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| meritore_capgemini | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| meritore_capgemini | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| meritore_capgemini | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| meritore_capgemini | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| meritore_capgemini | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| meritore_capgemini | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| research_phd | v341_tune | resume_tex | C1 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| research_phd | v341_tune | report | C1 | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| research_phd | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| research_phd | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| research_phd | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| research_phd | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| research_phd | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| research_phd | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| research_phd | v341_tune | report | C1 | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| rockstar | v340_original | resume_tex | C1 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| rockstar | v340_original | letter_txt | C1 | `LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side rules reject forged evidence, skipped prerequisites, and duplicate submissions. GoingOnce is a multi-agent car marketplace prototype my team of four built, where I mainly built the Negotiate and Fleet agents. A human approves every simulated bid or listi` | `LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side rules reject forged evidence, skipped prerequisites, and duplicate submissions. GoingOnce is a multi-agent car marketplace prototype my team of four built, where I mainly built the Negotiate and Fleet agents. A human approves every simulated bid or listi` |
| rockstar | v340_original | report | C1 | `cover_letter.words: 181` | `cover_letter.words: 186` |
| rockstar | v340_original | report | C1 | `cover_letter.words_total: 188` | `cover_letter.words_total: 193` |
| rockstar | v340_original | report | C1 | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| rockstar | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| rockstar | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| rockstar | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| rockstar | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| rockstar | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| rockstar | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| rockstar | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| rockstar | v340_original | report | C1 | (none) | `strict_fleet_v347c.letter_sentence.project: "goingonce"` |
| rockstar | v340_original | report | C1 | (none) | `strict_fleet_v347c.letter_sentence.before: "Its Fleet agent spreads 120 similar rental cars across markets in full truckloads after checking demand."` |
| rockstar | v340_original | report | C1 | (none) | `strict_fleet_v347c.letter_sentence.after: "I coded its Negotiate agent, where each side keeps a private price limit and a mediator closes the gap in rounds."` |
| twitch_se1 | v342_new | resume_tex | C1 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Created the Streamlit and React interface for the agents' streaming API so users can follow each agent's progress live, step by step, while the four agents of the simulated marketplace prototype run.` |
| twitch_se1 | v342_new | report | C1 | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| twitch_se1 | v342_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| twitch_se1 | v342_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| twitch_se1 | v342_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.ui.a"` |
| twitch_se1 | v342_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| twitch_se1 | v342_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after_text: "Created the Streamlit and React interface for the agents' streaming API so users can follow each agent's progress live, step by step, while the four agents of the simulated marketplace prototype run."` |
| twitch_se1 | v342_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| twitch_se1 | v342_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].verb: "Created"` |
| vindexa | v340_original | resume_tex | C1 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| vindexa | v340_original | report | C1 | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| vindexa | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| vindexa | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| vindexa | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| vindexa | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| vindexa | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| vindexa | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| vindexa | v340_original | report | C1 | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
| zoro_fullstack | v347_new | resume_tex | C1 | `  \item Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.` | `  \item Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.` |
| zoro_fullstack | v347_new | report | C1 | (none) | `strict_fleet_v347c.rule: "GoingOnce's Fleet bullet only on supply-chain / warehouse / logistics / vehicle-fleet postings; none found"` |
| zoro_fullstack | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].project: "goingonce"` |
| zoro_fullstack | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before: "goingonce.fleet.a"` |
| zoro_fullstack | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after: "goingonce.negotiate.a"` |
| zoro_fullstack | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].before_text: "Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low."` |
| zoro_fullstack | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].after_text: "Coded the Negotiate agent, where each side's agent keeps a private price limit and a mediator closes the gap in rounds, then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport."` |
| zoro_fullstack | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].lines: 2` |
| zoro_fullstack | v347_new | report | C1 | (none) | `strict_fleet_v347c.swaps[0].verb: "Coded"` |
