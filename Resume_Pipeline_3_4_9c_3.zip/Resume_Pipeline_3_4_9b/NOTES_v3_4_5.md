# Resume pipeline v3.4.5: notes

Built 2026-10-16 from Resume_Pipeline_3_4_4.zip, quora_jd_regression_fixture.txt and SUGGESTIONS_v344_review.txt
(section D margin/spacing proposals and C2 not taken, as asked).

## What Jay needs to do

1. **Sources: re-upload 5 of the 7 files.** Changed: `resume_pipeline_v3_2.py`, `master.json`, `bullet_bank.json`,
   `Resume_Template_CURRENT.tex` (Education layout) and `Master_Resume_Context_LEAN_CURRENT_v3_2.md` (new section 0).
   Unchanged: `plan_template.json`, `bank_check.py`. Uploading all 7 again is fine (0_SETUP_STEPS.txt says so).
2. **Project instructions: paste the new `2_PROJECT_INSTRUCTIONS_paste.txt`** (7,593 characters; limit 7,600).
3. **Tracker sheet: nothing new.** If the v3.4.4 column deletion (Career Status Portal, Visa / Sponsorship, Lane) was not
   done yet, do it now; the sheet stays at 11 columns with Blockers last.
4. Optional: send `Judge_Batch_v3_4_5.md` (11 packages, now including Quora) to the judge.

## Hash lock

| File | sha256 |
|---|---|
| resume_pipeline_v3_2.py | 87e36151… (full value in the instructions) |
| master.json | ca4b5e39… |
| bullet_bank.json | 2419a4b7… |
| Resume_Template_CURRENT.tex | 1309898b… |
| Master_Resume_Context_LEAN_CURRENT_v3_2.md | 3a7e23aa… |
| plan_template.json | 4358f1e0… (unchanged) |
| bank_check.py | 81b28185… (unchanged) |

## Results

| Check | v3.4.4 | v3.4.5 |
|---|---|---|
| Fixtures | 119: 117 pass + 2 expected stops | 120: 118 pass + 2 expected stops (fonzi, cisco_no_title) |
| v340_original (53) | 10.00 / 10.00 | 10.00 / 10.00, every fixture PASS, no ranking or Fit change |
| v341_tune, v342_new, v343_new, v344_new | 10.00 | 10.00 |
| v345_new (quora) | not present | 10.00 / 10.00 |
| audit_v344 | PASS, fallback closings 9.4% | PASS, 11 of 118 = 9.3%, longest closing 30 words, longest letter 200 words, no ".." |
| bank_check | 112/112, 9/9 | 113/113, 9/9 Experience variants |
| selftests | v341-v344 pass | v341-v345 pass (v345: G1-G7 plus two end-to-end Quora builds) |
| Names defined more than once | 61 | 61 (only final definitions edited; new helpers have new names) |

**Holdouts (20, never tuned, reported separately):** resume 9.85, letter 9.97, the same as v3.4.4. Still below 9.5:
acme_cloud, twitch, linkedin_ai (unchanged). One holdout output changed: amplitude now ranks
RIPPLE / LedgerFlow / GoingOnce instead of RIPPLE / LedgerFlow / LLM engine, because the item 4 rule blocks the
v3.4.2 LLM-reliability override (no posting line asks for LLM evaluation or provider failover); its score is unchanged.

**Quora, v3.4.4 vs v3.4.5:** RIPPLE / Fraud / LLM engine became RIPPLE / Fraud / GoingOnce; the closing
"...ML systems that adapt at Quora..." became "...ML systems at Quora..."; Spark is a reported stack gap; PyTorch,
TensorFlow and Kubernetes (local k3d) show in Skills; the coursework line shows; Go Digital is off (new-grad page).

## Each fix, quoted from the output

Every quote below was checked by script against the package file (page = PyMuPDF text of `resume.pdf` in
`packages/<name>/`; letter = the cover letter .txt; report = report.json). 25 of 25 found.

| Item | Package | Source | Quote |
|---|---|---|---|
| 1 (A1) stack gap reported, Fit not capped | quora | report | Stack gaps (named in the posting but not hard requirements, so Fit is not capped): Spark (stack line). |
| 1 (A1) Fit stays High | quora | report | "Fit (High/Medium/Low)": "High" |
| 2 (A2) stack line parsed: PyTorch, TensorFlow | quora | page | Frameworks & Libraries: PyTorch, TensorFlow, LangGraph, ReactJS, Streamlit |
| 3 (A3) Kubernetes (local k3d) in Skills | quora | page | Tools: Kubernetes (local k3d), Git, Claude Code, AWS (EC2/RDS), Docker |
| 4 (B1) override blocked; RIPPLE/Fraud/GoingOnce | quora | report | RIPPLE: Agentic Change-Impact Analysis; Fraud Detection using Graph Neural Networks; GoingOnce: Multi-Agent Car Marketplace |
| 4 (B1) report header shows the blocked override | quora | report | no posting line explicitly asks for LLM evaluation or provider failover |
| 4 (B1) explicit eval line keeps the override, with the displaced project | doordash_mdx | report | "displaced": "goingonce" |
| 6 IEEE-CIS named | quora | page | neural network on the highly imbalanced IEEE-CIS fraud dataset. |
| 6 edge-ablation bullet on an ML posting | quora | page | Ran an edge-type ablation across five identifier types |
| 6 leakage bullet on an ML posting | quora | page | Prevented data leakage by fitting the feature scaler on the training split only |
| 8 Fleet bullet on a warehouse posting | us_cold | page | Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads, |
| 9 (A4) closing ends at a clause boundary | quora | letter | I want to design and improve ML systems at Quora, building on RIPPLE, an AI agent that accepted no unsupported claims on unseen tasks. |
| 10 relevance beats novelty (LaunchOps ownership) | elevenlabs | letter | drawing on LaunchOps, where every onboarding task has an owner and prerequisites the server enforces. |
| 11 sensor posting: Thesis IoT lead | laminar | letter | At Thesis Mumbai Tech, I built a real-time WebSocket and Redis pipeline that streamed IoT baby-warmer device data |
| 11 device posting: Thesis IoT lead | figure | letter | At Thesis Mumbai Tech, I built a real-time WebSocket and Redis pipeline that streamed IoT baby-warmer device data |
| 12 (B5) ops lines -> variant G | audible | page | Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing. |
| 13 Data Preprocessing on Laminar | laminar | page | AI/ML: Machine Learning, Data Preprocessing, GNNs, Model Evaluation, Deep Learning, Agentic AI, LLM Integration |
| 14 NoSQL -> LaunchOps MongoDB quiz bullet | audible | page | a unique MongoDB index rejecting duplicate answers in live sessions. |
| 15 coursework line (new-grad AI/ML) | quora | page | Relevant coursework: Agentic AI, Machine Learning, Deep Learning |
| 16 GPA inline, one date per degree line | quora | page | Master’s in Computer Science \| GPA: 3.85 / 4.0 |
| 16 Bachelor's date on its degree line | quora | page | Bachelor of Engineering, Information Technology                                       August 2019 – May 2023 |
| 17 RIPPLE wording | quora | page | RIPPLE’s 241-test suite and testing edge cases across real repositories. |
| 17 second Pintos bullet | figure | page | Programmed the system-call interface that lets user programs open and manage files and processes through the kernel, |
| 18 (A5) verify quote from a role line | quora | report | design and improve ML systems that adapt to evolving abuse patterns and new challenges |
| 19 (C1) advice, not a referral | quora | report | Would you be open to a short chat so I can get your advice on the team? |

Items without a single page line:

- **5 (LLM engine letter sentence):** no letter in the 11 packages contains "tailored resume and cover letter". In the
  full run the only letter that still does is anthropic_it ("IT Systems Engineer, M&A", a general_swe posting, so the rule
  does not apply). Novita (an AI posting) now reads: "I built an LLM Application Optimization Engine in Python whose
  checks reject any generated claim that its source evidence does not support."
- **7 (Go Digital):** the Quora page has no Go Digital entry; Macy's keeps "Data Engineer Intern | Go Digital Technology
  Consulting, Mumbai, India" (the posting asks to analyze data).
- **13 (ML pages drop Spring Boot and Full-Stack Development):** neither appears on the Quora page (0 matches).
- **17 (GoingOnce interface bullet):** none of the 11 pages selects it; in the bank, `goingonce.ui.a/b/s1` no longer
  mention the 24 tests (selftest_v344 and selftest_v345 check this).
- **20 (instructions):** "tagline_text: ... describes only work Jay has done, in the posting's words; never a domain or
  scope he lacks (not "AWS integrations", "for connected commerce", "content quality and safety", "AWS applications")"
  and "5. If a tracker write fails, the reply's first line is "TRACKER NOT UPDATED: <reason>"."
- **A3 limit:** when a category is full of required terms, a JD-named skill can still be left out. The run then says so in
  Notes ("Skills full (named by the posting and supported, but no room after the required terms): ..."). In the full run
  this happens on audit12 (Concurrency, AWS), mastercard (System Design) and brillio (Claude API); none of the 11 packages.

## Assumptions

- "Patch only the final definition": edited the last definition of each function in place and put new helpers in a
  "v3.4.5 layer" block before `if __name__`. `auto_bank_selection`'s final body was renamed `_v345_auto_bank_core` with
  a new final wrapper; no earlier copy was touched.
- Item 4 applies to the v3.4.2 LLM-reliability override only. The v3.4.3 distributed-systems rule is kept, since Jay
  accepted DoorDash's "Remains (by rule)". DoorDash MDX keeps the LLM engine because the posting says "agent evaluation,
  LLM observability, tracing, or building eval harnesses"; the report now names the displaced project (GoingOnce).
- A1 overrides G2 and G6 from the review: a stack-line technology Jay lacks is a reported stack gap and never caps Fit,
  so Spark is not a hard gap and Quora stays High.
- A3 is enforced by priority, not by failing the run: named skills go ahead of every unnamed optional skill, and one that
  still cannot fit is reported in Notes. Failing would have stopped three fixtures that passed in v3.4.4.
- Item 7 is applied where Go Digital is optional, on the new-grad layout (rule 0a). On standard pages all Experience
  stays, as master section 5 requires.
- A v3.4.3 off-role framework (LangGraph, Streamlit) may stay in a project heading without a Skills entry; a heading
  technology the page check requires is added to Skills (US Cold, Streamlit).
- Clause boundary: a table cell ("|") or a trailing "preferred" / "required" counts as the end of the clause, which kept
  audit07 and Dassault off the fallback closing.
- Fixture stand-ins changed (they stand in for model output): the allergan and macys taglines (item 20) and the
  instalily hook, which echoed the company intro once "About InstaLILY" was read as intro text.
- The new quora fixture's hook copies "detect harmful content, automate complex decisions" from the posting; its
  tagline claims only Jay's own work ("building AI agents, ML models, and evidence-driven evaluation pipelines").
- The judge's "possible fabrications" that are in master are not defects; nothing new was claimed. Fraud stays solo,
  GoingOnce stays "with a four-person team".
- Three older selftest checks were updated for v3.4.5: the version check (v342-v344), the instructions limit (7,500 to 7,600, as Jay
  allowed) and the GoingOnce test-scope check (item 17 removes the tests from the interface bullets).
