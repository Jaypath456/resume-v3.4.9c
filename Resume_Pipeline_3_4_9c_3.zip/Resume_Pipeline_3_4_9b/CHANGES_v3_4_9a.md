# Resume pipeline v3.4.9a: changes (2026-10-20)

Built from Resume_Pipeline_3_4_8c.zip. A core-fixes build, done one fix at a time in the order 1 to 10, with a golden
set of 12 postings as the main acceptance test. For each fix: predictions written and frozen before its code
(`3_validation/predict_v349a_<N>.py` -> `predicted_changes_v349a_<N>.json`, never edited afterwards; gaps found later
are in `predicted_changes_v349a_<N>_amendments.json`), the fix behind its own master.json `v347_flags` entry (default
true), all 128 fixtures run, the gate `diff_gate_v349a.py gate <N> <previous snapshot> <new snapshot>` passed, the new
snapshot saved (`3_validation/snap_v349a_1` ... `_10`) and `golden_check.py` run. Every changed line is attributed to
exactly one fix in DIFF_REPORT_v349a.md.

With the ten new flags off (test-only `--regression-v347-flags-off=...`, or `V347_FLAGS_OFF=...` for run_all.py) every
fixture equals `3_validation/baseline_v348c/` (the unmodified 8c outputs). The facts are unchanged: Jay graduates in
December 2026 and can start work in February 2027.

Hash lock: pipeline 2714d282 | master 9dd92973 | bank 6ce82778 (unchanged) | template dc281778 (unchanged) | context md
f89d59eb. plan_template.json (4358f1e0) and bank_check.py (81b28185) are unchanged.

Code changes edit only final definitions (`parse_jd_requirements`, `gating_assessment`, `lowered_fit`,
`apply_auto_plan_fields`, `_v33_role_lines`, `_variant_score`, `_project_combos`, `_v341_project_combos`,
`auto_project_scores`, `apply_auto_ranking`, `auto_bank_selection`, `build_display_order`, `_v347_heading_placement`,
`_v347b_rerun_factory`, `v348c_fleet_repick`, `_v344_pick_proof`, `v348c_c1_proofs`, `_v344_resp_ok`,
`_v344_actor_phrase`, `compose_bank_cover_letter`, `build_skill_states`, `validate_selected_technology_skill_coverage`,
`_v346_post_run`, `_v348c_post_run`, `main_v3_1`), plus `V347_FLAG_NAMES` (33 flags) and `PIPELINE_VERSION`
("v3.4.9a"); new helpers live in a "v3.4.9a layer" before `if __name__`. Names defined more than once stay 61. No file
is renamed (CHANGES_v3_4_8c.md is a copy of the old CHANGES.md). Resume_Template_CURRENT.tex is not edited.

## G. Golden set (suite v349)

Four real postings are new fixtures with plan stand-ins that pass the rules: giga_swe ("Giga"), ebsco_sde1 ("EBSCO
Information Services"), akamai_se ("Akamai Technologies"), meritore_jpc ("Meritore Technologies LLC"); titles copied
exactly; hooks copy no "our / we / us" and no posting typo. `3_validation/golden_set.json` holds 12 entries (the 4 new
postings plus 8 locked ones whose set, rank1 and Fit must equal baseline_v348c). `golden_check.py` writes
`golden_report.md` (one row per posting: set, rank1, page order, Fit, hard gaps, Languages line, closing, forbidden
phrases, PASS/FAIL) and `golden_history.json` (which fix flipped each row).

## 1. JD reader (flag `jd_sections_v349`)

"What sets you apart", "Nice to have", "Bonus", "Ways to stand out" and "Preferred" headings are preferred. "About You"
alone is not a requirements heading; the sub-heading under it decides. Example lists ("Some examples:", "for example",
"for instance", "projects like") and company-voice parentheticals ("(we use PostgreSQL and SQL Server)") are context,
never requirements or hard gaps. "A and/or B", "A or B" and "at least one of" are alternatives. Instructions: the
model's jd_requirements_extra never adds example-list or context lines. 12 fixtures change.

## 2. Years (flag `years_range_v349`)

"0-3 years" / "1-3 years" are a minimum of 0 / 1; a years note only when the minimum is 3 or more. A company-history
phrase ("for more than 25 years") is not a years ask (amendment 2-A1, nvidia_ai_cloud). 29 fixtures change (notes and
Fit only; resumes and letters identical).

## 3. Fit (flag `fit_guard_v349`)

Preferred, example or context items never make Fit Low; Low only from a must-have gap or a blocker. 1 fixture changes
(flowgen Low -> Medium).

## 4. Bullets (flag `bullet_score_v349`)

No flat +1 number bonus; a number only breaks ties between equally relevant bullets. The LLM engine's resume-wording
bullets appear only on postings about documents or resumes; its failover and claim-check bullets are preferred.
60 fixtures change bullets (projects, order and slot counts identical); 3 heading follow-ons are amendments 4-A1 to 4-A3.

## 5. Ranking (flag `ranker_v349`)

One scoring path: the theme-first score orders the projects and the legacy score breaks ties (never list order). The
role family's anchor (preferred_projects[0]) leads unless another project beats it by 2 points on standalone + legacy/2.
report.json `ranking_v349` lists every score and the reason. Project set changed on 4 of 122 existing fixtures (3.3%,
limit 25%); 20 fixtures changed set, rank1 or page order (listed with scores in DIFF_REPORT_v349a.md). A rejected bullet
rerun now restores its state, and a last-resort reselection keeps the Fleet bullet off non-logistics pages (only us_cold
keeps it).

## 6. Page order (flag `date_order_v349`)

The 3 projects render newest to oldest by master date, ties by rank. Slot counts, headings and Skills stay by rank.
score_all.py already checks "top1" against the ranking (rank1), not the first block; run_all.py now prints rank= and
page= separately. No existing manifest entry was edited (only the 4 golden postings were added). 99 fixtures reorder;
every page stays one page.

## 7. Closing proof (flag `proof_on_page_v349`)

The closing's proof must be an evidence id whose bullet is on the page (checked by id; Fraud's result proofs and
LaunchOps ownership map to their bullets), or an Experience line; otherwise another on-page proof, else the role-family
closing. A proof off the page fails the build (closing_proof_not_on_page). Amendments 7-A1 / 7-A2: on lumen the new
closing lets the v3.4.8c F2 GoingOnce re-pick succeed, so one bullet and the letter's GoingOnce sentence change.

## 7b. Closing proof follow-up (same flag `proof_on_page_v349`)

Found by audit_v344 after fix 10: fix 7 raised role-family closings from 11 to 22 of 126 built (17.5%; cap 10%). Fix 7b
(predictions `predict_v349a_7b.py`, written before its code; gate `gate 7b snap_v349a_10 snap_v349a_7b`): when the
closing would be the role-family closing, the closing search runs once more and an off-page proof may be replaced by
another proof of the same project whose bullet is on the page (closing_proofs order; never one the letter already
says). 9 closings change (alml_engineer, audit12, black_canyon, brightpath_ml, linkedin_ai, loopwell, novita, nvidia,
pinterest); role-family closings 22 -> 13 (10.3%). Only role-family closings can change; resume, tracker and outreach
are identical.

## 8. Copy rule (flag `copy_rule_v349`)

The hook and a model closing need 3 or more content words from one responsibility line (not 4 consecutive words). A
closing phrase stops before a trailing bare singular phrase ("develop and maintain services", not "services for
control plane"). "design develop" pairs get "and". "our" in the hook becomes the company possessive; "we / us" fails
the build (cover_letter_hook_voice). Instructions: the hook may paraphrase and never copies typos or "our".
2 fixtures change (akamai_se closing, amendment 8-A1; doordash hook "DoorDash's backend systems").

## 9. Skills hygiene (flag `skills_dedupe_v349`)

One name per alias group (React + ReactJS -> ReactJS; a posting that names exactly one spelling keeps it). Formats
(JSON, HTML/CSS, ...) move from Tools to the Languages line. A vendor API in a rendered heading that the posting does not
name leaves Tools. Posting-named terms are never dropped. 24 fixtures change Skills lines only (amendment 9-A1: the
skills_text_hash report line).

## 10. Tracker (flag `company_key_v349`)

tracker_row.json gains `company_key` (lowercase, no punctuation, without Inc / LLC / Ltd / Corp / Corporation /
Technologies / Information Services and similar). Instructions: update an existing row when company_key AND Role match,
keeping the longer official name; otherwise append. selftest_v349a proves "Akamai" = "Akamai Technologies" and that
different companies differ.

## Tooling

`3_validation/diff_gate_v349a.py` (snapshot / identical / per-fix gate with guards, `guard_exception` and `"*"`
amendments), `predict_v349a_1.py` ... `_10.py`, the amendment files, `golden_set.json`, `golden_check.py`,
`rank_dump_v349a.py`, `selftest_v349a.py`. Selftests v347a to v348c turn the ten new flags off wherever a build is
compared with an older baseline; selftest_v345's Quora check reads rank1 from ranking_v349 instead of the first block.
