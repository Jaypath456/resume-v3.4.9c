# JUDGE BATCH (12 packages)

Judge each package below separately with the prompt and rubric. Score every package, in order, using the output format once per package with a `## <n>. <package>` heading.

# Judge prompt (paste into the OTHER model: ChatGPT judges Claude's package, Claude judges ChatGPT's)

You are two reviewers at once for this one posting:
1. A technical recruiter at a large company who screens 200 resumes a day and has 30 seconds per page.
2. The company's ATS (Workday/Greenhouse-style): keyword match on the posting's required and preferred terms, with more weight for terms that appear in Experience/Project bullets than in the Skills line.

Inputs: the pipeline writes judge_packet.md for every run (v3.4.2). One packet holds the EVIDENCE INVENTORY, the ELIGIBILITY NOTES, the JOB POSTING, the RESUME (PDF text) and the COVER LETTER. To judge several packages at once, run `python3 combine_judge_packets.py <out_dir>... -o Judge_Batch.md`: the batch carries this prompt and the rubric once, the inventory once, then each package.

Evidence inventory: it is generated from master.json and is the complete record of what Jay can claim. A claim that matches the inventory (including its anchors and boundaries) is verified evidence, never a "possible fabrication". Flag a claim only when the inventory does not support it or a boundary forbids it, and quote the inventory line you checked.

Eligibility notes (sponsorship, citizenship, clearance, graduation window, rising-senior programs) are shown to Jay so he can decide; the package is always built. They are never a defect in the resume or the letter.

Experience: the packet header says experience_variants_enabled. When it is false, the Experience section is frozen by the candidate: do not score its wording, but DO count it as evidence. When it is true, also score Experience with the rubric's Experience section. (v3.4.3 ships it true: Jay approved the variants A-H, so score Experience.)

Score strictly with the rubric in RUBRIC.md (start each document at 10, subtract). Then add these checks:

ATS (score out of 10)
- Every REQUIRED posting line that the candidate can truthfully meet is visible on the page, in the posting's own words where possible (-0.5 each if only an alias is shown, -1 each if missing).
- A required qualification proven only by a Skills-line keyword and no bullet (-0.5 each).
- Skills that are filler for this role (named by neither the posting nor any bullet) (-0.25 each).

Technical recruiter (score out of 10)
- Would the top third of the page make you keep reading for THIS role? If not, say which project or bullet should lead.
- Any claim you would doubt in a phone screen (-0.5 each, quote it).
- Any repeated verb or phrase across the page (-0.25 each).
- Cover letter: does it answer the posting's hardest required line with evidence? (-1 if not)

Output exactly (once per package; in a batch, start each block with `## <package name>`):
ATS: <score>/10
Recruiter (resume): <score>/10
Recruiter (letter): <score>/10
Deductions:
- <points> | "<exact quote>" | <one-line fix>
Pipeline-level fix (one line, only if the same defect would repeat on other postings): <fix or "none">

Do not invent facts about the candidate. Do not reward keywords the candidate cannot back up. Check every "doubtful claim" against the inventory before deducting.

---

# Quality rubric (score each document out of 10; be strict, quote the text for every deduction)

A claim that matches the EVIDENCE INVENTORY is verified evidence, not a fabrication; "a claim not backed by the resume" means not backed by the inventory or the page.

## Resume (start at 10, subtract)
- Technical Skills (max -2.5): a skill the page does not show and the posting does not name (-0.5 each); a posting-named skill that Jay can back up but is missing from Skills (-0.75 each); a line that is long or mixes unrelated things (-0.25); order not matching what the posting stresses (-0.25).
- Project selection (max -2.5): a project that does not prove what the posting asks for (-1); a better-fitting project left out (-1); the strongest proof (a number) missing from a project (-0.5).
- Project bullets (max -2.5): awkward or unnatural phrasing (-0.25 each); run-on or two ideas in one bullet (-0.25 each); no result or number where one exists (-0.25 each); a claim the posting cannot connect to (-0.25).
- Project headings/tagline (max -1.5): heading technology line missing a posting-named technology the bullets show (-0.5); tagline generic or off-target (-0.5).
- Layout/ATS (max -1): one page, readable, standard headings, no clutter.
Do not score the Experience section while experience_variants_enabled=false (the packet header says which; v3.4.3 ships it true).
A new-grad page (the packet's LAYOUT NOTE) puts Education first and may leave the Go Digital internship off by rule: not a defect.

## Experience (scored when the packet says experience_variants_enabled=true, as in v3.4.3; max -1.5, taken from the resume score)
- A variant that adds a fact, number or tool not in the inventory's Experience line or its anchors (-1 each; this is a pipeline defect). Dropping a fact is allowed.
- A variant whose emphasis does not fit the posting better than the original would (-0.25 each).
- Awkward word order introduced by a variant (-0.25 each).

## Cover letter (start at 10, subtract)
- Opening (max -2): generic or could be sent to any company (-1); does not use the posting's own words (-1).
- Evidence (max -3): the two projects and one experience do not prove what the posting asks for (-1 each); a filler sentence that only lists keywords (-1); a claim not backed by the resume (-2).
- Simple English and length (max -2): sentences over 30 words (-0.25 each); jargon where plain words work (-0.25 each); more than 200 words (-0.5).
- Consistency with the resume (max -1.5): a number or fact worded differently or contradicting (-0.75 each).
- Close and logistics (max -1.5): no graduation/start line (-0.75); relocation mentioned for a remote job or missing for an onsite one (-0.5); weak or generic close, e.g. "I would welcome the chance..." instead of one sentence naming the posting's top build / improve responsibility in its own words plus Jay's matching proof (-0.5); a close over 30 words, or one that makes the company (not Jay) the actor (-0.5).
- Hook (part of Opening): describes the team instead of what draws Jay to the work, or does not name the company's product / domain in the posting's words (-0.5).

Output per posting: resume score, letter score, then every deduction as: points | exact quote | one-line fix.

---

# EVIDENCE INVENTORY (generated from master.json; complete record of what Jay can claim; shared by every package)

Anything in this inventory is verified evidence. A claim on the page that matches it is NOT a fabrication.

### Experience (frozen wording; evidence anchors give the measured facts behind each number)
- **Software Engineer Practicum | HeinOnline (University at Buffalo)** (January 2026 -- April 2026)
  - Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  - Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ~90% and pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
  - Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
  - Standardized author names by matching them to HeinOnline's 500+ authors in PostgreSQL, even when spelled differently.
  - Anchors: 47 journals / 28,167+ pages; measured extraction accuracy 90.81% (resume wording: "about 91%"); manual author-entry work cut by about 90% (estimated); worker pool sized to CPU cores minus one; on 47 journals the run took about 50 minutes sequentially and 9 minutes 15 seconds in parallel on 10 cores (about 81% reduction); confidence source values API = 100, LLM = 85, scraper = 50; Docker supported; author names standardized by matching against HeinOnline's 500+ authors stored in PostgreSQL (handles different spellings). Team of 5 for the project. In cover letters say "about 91%".
- **Software Engineer | Thesis Mumbai Tech (Startup)** (August 2024 -- August 2025)
  - Led end-to-end delivery of healthcare platform modules with a team of 4: gathered requirements in client meetings, prototyped to validate scope, and broke the finalized work into tasks.
  - Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ~2s live monitoring.
  - Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses, plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
  - Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
  - Built a heartbeat monitoring dashboard for 4 production projects, pinging each site every 5 minutes to track health.
  - Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds over their first 3 weeks and introducing them to the production projects and tech stack.
  - Anchors: client/stakeholder meetings; prototyping; "led" means technical coordination of a four-person team, not people management or hiring authority; team size is 4 (team of 4); interviewed about 20 student candidates and onboarded the new hires; SQL/relational schemas; PostgreSQL/Redis/WebSockets; WebRTC; real production deployment; heartbeat/service monitoring and responding to failures it surfaced; reviewed and merged team pull requests (cover letters, and the resume only through Experience variant I); Agile/Scrum. The earlier "~90% setup-time reduction" for Docker was an estimate, not a measurement, so it is not used on the resume. Do not infer HIPAA/FHIR/EHR, observability vendors, formal SRE/on-call, SLA ownership, or HA.
- **Cloud Engineer Intern | Data Maven Pvt Ltd** (November 2023 -- May 2024)
  - Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
  - Automated cloud resource provisioning, cutting setup time by ~40% and reducing deployment issues.
  - Anchors: AWS EC2/RDS, VPC, security groups. The 40% setup reduction is estimated, not instrumented; keep "~" and be ready to explain it in an interview.
- **Data Engineer Intern | Go Digital Technology Consulting** (June 2023 -- August 2023)
  - Developed a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data and generate automated anomaly reports for the compliance and audit team.
  - Anchors: Python, Pandas, NumPy, MySQL, SQL, ETL, cleaning/transformation/reporting.

### Projects
#### LedgerFlow — Event-Driven Payment Ledger (Individual, October 2026)
Tech: Java 25, Spring Boot, Spring MVC, Spring JDBC/JdbcClient, Kafka, PostgreSQL 17, Flyway, Maven, Docker Compose, Kubernetes, k3d/k3s/kubectl, Testcontainers, JUnit 5, AssertJ, Awaitility, Actuator/Micrometer, k6, GitHub Actions, HTML/CSS/JavaScript, YAML
- Two Spring Boot services that talk through Kafka: a payment API and a ledger that records every payment as matching debit and credit entries (double-entry accounting).
- Safeguards (transactional outbox, idempotent consumers, reconciliation check) so a payment is never recorded twice or lost when messages are repeated or retried. Supported phrase: each payment takes effect exactly once even though Kafka may deliver a message more than once.
- Overspending test: 200 simultaneous $10 requests against an account funded for exactly 50 payments. 50 went through, 150 were safely rejected, the balance ended at $0, and there was no overdraft or double posting.
- Testing: 94 automated tests, plus 27 of 27 crash-and-repeat test runs with 0 data errors (18,000 repeated messages and 14 forced service crashes in total).
- (optional) Speed: in a controlled local test at 200 payments per second, response time for the slowest 5% of requests dropped from 121 ms to 51 ms after the outbox polling interval went from 50 ms to 10 ms.
- (optional) Local Kubernetes demo (k3d, plain YAML manifests): restarting a service mid-run still completed 250 of 250 payments with 0 duplicates; a fresh cluster came up in 142 s and a replacement service was ready in about 8.9 s.
- Integration tests run against real PostgreSQL and Kafka with Testcontainers and JUnit 5 (Testcontainers is in the LedgerFlow stack).
- CI: LedgerFlow's GitHub Actions CI workflow runs all 94 tests (confirmed by Jay 2026-10-15); the integration tests run against real PostgreSQL and Kafka in containers with Testcontainers and JUnit 5.
- Boundaries (do not claim): personal/local project; not production/HA/PCI; no real bank/card network; no exactly-once Kafka delivery; no EKS/GKE/AKS/Helm/HPA/multi-node HA; CI only, not Continuous Deployment.

#### GoingOnce — Multi-Agent Car Marketplace (Team of 4, October 2026)
Tech: Python, LangGraph, Claude API, Streamlit, ReactJS/Vite, Server-Sent Events, pytest, JavaScript
- Four agents built by the team (Buy, Sell, Negotiate, Fleet) for a car-marketplace prototype; a human approves every simulated bid or listing before it goes through.
- Claude handles language and photo tasks; ordinary code handles search, pricing, and negotiation rules.
- Streamlit and React interface on top of a streaming API; 24 automated tests.
- Simulated marketplace data only.
- 1st Place in ACV Auctions + Copart challenge at UB AI for Good Hackathon Design Challenge.
- Mentor feedback shaped the Negotiate and Fleet flows.
- Jay worked on all four agents (mainly the Negotiate and Fleet agents) and built the Streamlit and React front end himself (confirmed 2026-10-15).
- Negotiate agent (repo README): each side's agent keeps a private price limit, a mediator closes the gap in rounds, then the deal closes itself: simulated escrow payment, insurance, loan payoff, title, and truck transport.
- Fleet agent (repo README): checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.
- Buy agent (repo README): checks each car's history and throws out cars with hidden salvage or odometer rollback across 310 simulated ACV and Copart listings, and pauses for dealer approval before any bid.
- Determinism (repo README): search, history checks, pricing, negotiation math and logistics are plain code; Claude is called only for language and photos, and every Claude call has a saved fallback, so results repeat.
- The HTTP API streams agent steps to the React UI as Server-Sent Events (repo README).
- Boundaries (do not claim): Four-person team project (confirmed by Jay 2026-10-15): Jay worked on all four agents (mainly Negotiate and Fleet) and built the Streamlit/React front end. Feature bullets may describe any agent (Buy, Sell, Negotiate, Fleet); the project-level bullet keeps "with a four-person team"; never imply he built the whole system alone. The 24 tests and the award stay team-scoped; not production; bids, payments, prices and transport are simulated; no real ACV/Copart integration; no FastAPI/Docker/RAG/vector DB; award stays out of project bullets.

#### RIPPLE — Agentic Change-Impact Analysis (Individual, August 2026)
Tech: Python, Python AST, Git CLI, Pydantic, pytest, LLM API, JSON/JSONL
- Command-line AI agent for Python repositories: given a plain-English description of a change, it predicts which files, tests, and regression risks the change will touch before any code is written.
- Uses 7 code-analysis tools with a cap of 25 tool calls per task; Python code checks every claim against evidence before it can enter the report.
- After the change is made, RIPPLE's own Git-diff check flags unexpected edits, missing tests, and stale callers (Jay 2026-10-15: "Added a Git-diff check that flags unexpected edits, missing tests, and stale callers"; it is RIPPLE's automated check, not manual review).
- 241 automated tests.
- Evaluation: 90 runs on 30 unseen tasks from 16 repositories. Precision 0.306, recall 0.152, F1 0.198, MRR 0.311, and 0 unsupported claims accepted into any report. On the page prefer the zero-unsupported-claims result plus at most one score, and only use the score for AI/ML JDs.
- (optional) Efficiency: about 10 tool calls and 17 model calls per run, with under 1 duplicate call per run (exact: 10.37, 16.60, 0.73).
- (optional) Separate post-change check: found all 3 kinds of planted problems on 15 tasks (100% detection) when given the correct pre-change predictions. Never present this as end-to-end performance.
- Hybrid code search over code chunks (BM25 + dense retrieval) is designed only; dense retrieval/RAG implementation and benchmark are not complete.
- Used Claude Code as a coding assistant while building RIPPLE: Claude Code helped write RIPPLE, and Jay checked its output by running RIPPLE's 241-test suite (confirmed by Jay 2026-10-15); he also used it to study how AI agents work and to probe their edge cases.
- Boundaries (do not claim): Python only; no production/adoption/bugs-prevented/productivity claims; no LangGraph/NetworkX/SQLite/MCP/Redis/Docker; do not attribute current metrics to RAG; do not claim it beat historical B3; Claude Code: say Claude Code helped write RIPPLE and Jay checked its output with RIPPLE's 241-test suite (confirmed 2026-10-15); never "RIPPLE, whose AI-generated code" (RIPPLE generates no code); give no count of corrections, no specific bug example and no productivity claim. The Git-diff check is RIPPLE's automated check (Jay 2026-10-15); never describe it as Jay reading diffs by hand.

#### LLM Application Optimization Engine (Individual, July 2026)
Tech: Python, Gemini API, Novita API, Groq API, pytest, LaTeX, pdflatex, pdftotext
- Turns a job description into a tailored one-page resume and cover letter grounded in verified evidence.
- Chooses which 3 projects to show and how many bullets each gets by checking every valid combination (dynamic programming); with 7 active projects the expected count is 105 once runtime integration is verified. Describe it as "picks the best projects"; do not hard-code the count.
- Three AI workers write bullets at the same time; typical runtime fell by about 73% (from about 11 minutes to about 3). On the page use the percentage only.
- Python checks reject unsupported technologies, ownership claims, borrowed evidence, and changed numbers before anything is shipped.
- Compiles the LaTeX and re-reads the PDF to check the layout.
- 2,500+ automated pytest tests.
- Uses Gemini as the main model provider and falls back to Novita's model API after 3 failed attempts; retries and repairs only the parts that failed.
- Uses the Groq API for assessment (confirmed by Jay, 2026-10-13); Gemini is the main generation provider and Novita's model API is the fallback.
- Boundaries (do not claim): individual project; do not claim unsupported production/org adoption; assignment count must remain catalogue-dependent. Groq API role: assessment only; do not describe it as a generation provider or claim specifics of the assessment beyond this.

#### LaunchOps — Office Onboarding & Real-Time Learning Platform (Individual, March 2026)
Tech: Python, Django REST Framework, ReactJS, Go, PostgreSQL, MongoDB (live answers only), Redis, Django Channels, Daphne, Docker Compose, WebSockets, JWT, Locust, asyncio, JavaScript
- Django REST and React onboarding platform with a 20-task workflow shared across HR, IT, manager, and employee roles; tasks have owners, prerequisites, and required evidence.
- Five lessons, each with a 3-question quiz, and an exact 70% pass rule.
- Server-side checks stop users from completing someone else's task, submitting forged evidence, skipping prerequisites, or submitting twice; unresolved support issues also block completion.
- PostgreSQL is the main durable store.
- Live-quiz service written in Go using WebSockets, running as two copies behind nginx; Redis Pub/Sub with Lua scripts coordinates the copies, and a unique MongoDB index rejects duplicate answers.
- A repeatable Django-vs-Go benchmark exists; no speed result after the Go move is verified.
- Boundaries (do not claim): no production deployment, throughput/failover claims, or Go speedup; MongoDB stores live answers only; never reuse retired-LMS metrics.

#### Pintos Operating System — User Programs Layer (Individual academic, May 2026)
Tech: C, x86, Operating Systems, Kernel Development, Concurrency, Thread Synchronization, File Systems, Process Lifecycle
- wrote the part of a teaching operating system that runs user programs, in C: starting programs with arguments, parent/child waiting and exit, 13 system calls, up to 128 open files per process, locks, and safety checks on memory access; all 80 tests pass.
- Boundaries (do not claim): C, not C++; teaching OS, not production OS work.

#### Fraud Detection using Graph Neural Networks (Academic, April 2026)
Tech: PyTorch, PyTorch Geometric, GNN, GraphSAGE, GAT, NetworkX, Pandas, scikit-learn, Focal Loss
- trained fraud models on the IEEE-CIS dataset (590,540 transactions, about 3.5% fraud, roughly 27.6 normal transactions for every fraud). The GraphSAGE graph neural network scored 0.9259 AUC-ROC (fraud F1 0.5641) against about 0.858 for a plain neural-network baseline (MLP); the GAT model did worse. On the Elliptic dataset, GraphSAGE reached about 0.988 AUC and 0.906 F1. Ablation analysis available. On the page always show AUC next to the baseline it beat.
- Graph construction (notebook): a transaction graph of 590,540 nodes and 4,122,298 edges (about 4.1M) built by linking transactions that share card (card1, card2, card1+addr1), address (addr1) and email-domain (P_emaildomain, R_emaildomain) identifiers; any identifier group larger than 50 transactions is skipped so no hub node forms.
- Edge-type ablation (notebook) over five identifier types (card1, card2, addr1, P_emaildomain, R_emaildomain) on the trained GraphSAGE model: all edges 0.9113 test AUC vs 0.8954 with no edges, so the graph adds 0.016 AUC; card1 links alone reach 0.9109 (almost all of the gain), while each other type alone stays at 0.8954-0.8955.
- Model comparison (notebook): MLP, GraphSAGE and GAT trained with focal loss and class weights, with decision thresholds tuned for F1 on validation data; test fraud F1: GraphSAGE 0.564 (0.5641), MLP 0.394 (0.3944), GAT 0.261 (0.2605).
- Leakage controls (notebook): stratified 70/15/15 train/validation/test split; the feature scaler is fit on the training split only; decision thresholds are tuned on the validation split; final results are reported on the held-out 15% test set.
- Jay built the whole notebook himself (confirmed 2026-10-15); describe it as his own work.
- Boundaries (do not claim): Jay's own work: he built 100% of the notebook himself (confirmed 2026-10-15; the course submission lists three names, but the other two worked on a different project). Describe it as Jay's own work, never as team work. Never quote a class-imbalance ratio of 41.4x (that figure includes the 1.5 fraud weight); the true ratio is about 27.6 normal transactions per fraud. The edge ablation tested each identifier type alone and all together; it did not test removing one type from the full graph.

### Additional verified facts (master.json cover_letter_evidence; usable in letters and approved Experience variants)
- collaboration product: Direct client/stakeholder meetings at Thesis Mumbai Tech.
- collaboration product: Clarified requirements and translated them into technical work.
- collaboration product: Prototyped before full implementation.
- collaboration product: Coordinated a four-person engineering team (technical coordination, not people management).
- collaboration product: Reviewed pull requests.
- collaboration product: Worked with clients on UI/UX and product requirements.
- collaboration product: Interviewed about 20 student candidates and onboarded the new hires.
- collaboration product: Agile/Scrum.
- production operations: Deployed team software to a shared production server.
- production operations: Built heartbeat/service-status monitoring.
- production operations: Responded to heartbeat-detected production failures and restored affected services.
- ai-assisted development: GitHub Copilot supported in scoped development evidence.
- ai-assisted development: Cursor and Claude Code used for repository-level development, debugging, test-driven iteration, and code review.
- coursework: Graduate Agentic AI coursework exists separately from RIPPLE; never merge coursework into RIPPLE or Professional Experience.

### Approved Experience variants (verified wording; the page may show one in place of the original line)
- A [HeinOnline (University at Buffalo)]: Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals using OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B), CrossRef API, and web scrapers.
- B [HeinOnline (University at Buffalo)]: Engineered a fault-tolerant data pipeline that processed 28k+ pages of law journals, combining CrossRef API, web scrapers, and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B).
- C [HeinOnline (University at Buffalo)]: Added confidence scoring that flags low-confidence fields for human review, and parallelized the pipeline with a CPU-based worker pool, cutting total processing time by over 80%.
- D [Thesis Mumbai Tech (Startup)]: Led a team of 4 through end-to-end delivery of healthcare platform modules: gathered requirements in client meetings, prototyped to validate scope, and broke the finalized work into tasks.
- E [Thesis Mumbai Tech (Startup)]: Gathered requirements in client meetings, prototyped to validate scope, and led a team of 4 through end-to-end delivery of healthcare platform modules.
- I [Thesis Mumbai Tech (Startup)]: Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements in client meetings, prototyped to validate scope, and reviewed and merged team pull requests. (adds the master-recorded facts: using Agile/Scrum; reviewed and merged team pull requests)
- F [Thesis Mumbai Tech (Startup)]: Developed a real-time WebSocket + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ~2s live monitoring, plus Patient Management and Consent modules on normalized schemas for 10k+ records.
- G [Thesis Mumbai Tech (Startup)]: Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
- H [Data Maven Pvt Ltd]: Deployed backend services on AWS EC2 and RDS, restricting access with VPC networking and security groups.
- J [Go Digital Technology Consulting]: Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data and generate automated anomaly reports for the compliance and audit team.

### Project evidence items (every verified fact behind the project bullets)

### Qualification facts (Jay meets these)
- Master's degree in Computer Science; Master's in Computer Science; degree in Computer Science; Computer Science degree; Bachelor's degree; Bachelor of Engineering; Information Technology degree; STEM degree; technical degree; internship experience; previous internship experience; prior internship; internship; new grad; new graduate; recent graduate; graduation in December 2026; graduating in December 2026; December 2026 graduate; production code; production-level code; production software; code reviews; AI-assisted development tools; AI coding tools; professional software engineering experience; industry experience; startup experience; early-stage startup

### Education
- {"masters": {"degree": "Master's in Computer Science", "institution": "University at Buffalo, The State University of New York, Buffalo, NY", "dates": "August 2025 -- Expected December 2026", "gpa": "3.85 / 4.0", "coursework_completion": "December 16, 2026", "graduation": "December 2026", "available_to_start_work": "February 2027, subject to approved OPT/EAD", "graduation_confirmed": "v3.4.8b (2026-10-19): Jay and the university confirmed graduation in December 2026; the work start date is February 2027. Graduation and start date are two separate facts.", "coursework": ["Agentic AI", "Machine Learning", "Deep Learning"]}, "bachelors": {"degree": "Bachelor of Engineering, Information Technology", "institution": "Vivekanand Education Society's Institute of Technology, Mumbai University, India", "dates": "August 2019 -- May 2023"}}

### Awards
- {"title": "1st Place, ACV Auctions + Copart Challenge", "context": "AI for Good Hackathon Design Challenge, UB", "date": "October 2026", "default_resume": true}
- {"title": "AWS Certified Cloud Practitioner", "date": "July 2024", "default_resume": true}

### Supported skills (Jay can back each one)
- languages_databases: Python, Java, JavaScript, HTML/CSS, C, Go, SQL, PostgreSQL, MongoDB, MySQL, NoSQL, Relational Databases
- frameworks_libraries: Django, Django REST Framework, Django Channels, ReactJS, Spring Boot, Spring MVC, Spring Kafka, Spring JDBC/JdbcClient, JUnit 5, Testcontainers, AssertJ, Awaitility, Pandas, NumPy, scikit-learn, PyTorch, PyTorch Geometric, NetworkX, Librosa, CatBoost, Pydantic, LangGraph, Streamlit, TensorFlow, Matplotlib, pytest, Vite
- ai_ml_data: LLM Integration, Prompt Engineering, Agentic AI, AI Agents, Tool Calling, Multi-Agent Systems, Human-in-the-Loop Workflows, OCR/Tesseract, Machine Learning, Deep Learning, CNNs, RNNs, GNNs, GraphSAGE, GAT, Focal Loss, Model Evaluation, Threshold Optimization, Data Preprocessing, Fuzzy Matching, LLMs, Agentic Workflows, Information Extraction, Classification
- software_engineering: REST APIs, Full-Stack Development, Backend Development, System Design, Event-Driven Architecture, Microservices, Payment Systems, Transactional Outbox, Idempotency, Idempotent Consumers, Double-Entry Ledger, Database Transactions/ACID, Row-Level Locking, Reconciliation, Fault Injection, Chaos Testing, Continuous Integration, Unit Testing, ETL, Parallel Processing, Multiprocessing/Worker Pools, Load Testing, Latency Measurement, Distributed Systems, Backtracking Algorithms, Agile, Scrum, Real-Time Monitoring, Concurrency, Thread Synchronization, Operating Systems, Kernel Development, Process Lifecycle, Static Analysis, Dependency Analysis, Change-Impact Analysis, Regression Analysis, Web Scraping, Production Deployment, Application Monitoring, Heartbeat Monitoring, Incident Response, OOP, Code Review, Data Structures, Algorithms, API Design, Software Design, Database Design, Data Pipelines, Debugging, SDLC, Data Validation, Data Cleaning, Data Transformation, Integration Testing, Data Modeling
- tools_platforms: Redis, Apache Kafka, Kafka KRaft, Maven, Flyway, k6, GitHub Actions, Spring Boot Actuator, Micrometer, AWS (EC2/RDS), Docker, Docker Compose, Kubernetes (local k3d), k3d, k3s, kubectl, Git, GitHub, GitHub Copilot, OAuth/Auth0, JWT, WebRTC, WebSockets, Daphne/ASGI, Locust, asyncio, Arduino Uno, LaTeX, pdflatex, pdftotext, Gemini API, Groq API, Claude API, CrossRef API, JSON, YAML, Cursor, Claude Code, Linux, Tableau, Power BI, nginx, VPC Networking, Novita API
- Scope rules: AWS: AWS (EC2/RDS) only; CI/CD: Use Continuous Integration only; Continuous Deployment is unsupported; Java/Spring/Kafka/Kubernetes: LedgerFlow only; LangGraph/Multi-Agent/Human-in-the-Loop/Claude API: GoingOnce only; Go/MongoDB live quiz: LaunchOps only; Production Deployment/Application Monitoring/Heartbeat Monitoring: Thesis Mumbai Tech only; Code Review: Thesis Mumbai Tech evidence anchors: reviewed and merged team pull requests; Kubernetes: Always shown as "Kubernetes (local k3d)"; never bare Kubernetes (local demo, not production); Claude API: Only when GoingOnce is on the page or the JD names LLM APIs; OAuth/Auth0: Shown when the JD names OAuth, SSO or authentication

### Unsupported skills and claims (never claimed; a page that shows one is a defect)
- RAG, retrieval-augmented generation, vector database, vector databases, vector DB, FastAPI, Fast API, Flask, HIPAA, FHIR, EHR, SRE, on-call, SLA, TypeScript, Selenium, Playwright, Jenkins, LangChain, Snowflake, Redshift, Airflow, Spark, Hadoop, Databricks, Bash, Prometheus, Grafana, ServiceNow, Salesforce, CRM, Jira, Azure DevOps, Azure Dev Ops, .NET, .Net Framework, C#, Eclipse, SQL Server, TCP, UDP, ArcGIS, arcpy, Geospatial, OpenAI, Embedded RTOS, RTOS, ARM, Ruby, Rust, Scala, Kotlin, Swift, PHP, Vue, Next.js, Node.js, Express, GraphQL, MongoDB Atlas, DynamoDB, Lambda, S3, SageMaker, ITSM, U.S. Citizenship, security clearance
- C++; FastAPI; Angular; Ruby; Apache Spark; Apache Airflow; AWS Glue; Terraform; Azure; GCP; EKS; GKE; AKS; production/high-availability Kubernetes; Helm; Kubernetes HPA/autoscaling; HIPAA implementation/compliance; FHIR; EHR integration; Continuous Deployment; cloud ML platforms beyond AWS EC2/RDS; data-warehouse/platform experience unless added; finance-industry Professional Experience

---

# PACKAGES

## 1. Akamai Technologies | Software Engineer

Pipeline v3.4.9a; file key Akamai_Technologies_Software_Engineer; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
[View More Jobs]( "View More Jobs")
Software Engineer

United States (Remote)
Job Description

Do you want to build customer-facing features for a globally distributed AI platform?

Are you eager to learn cloud platform development while working on cutting-edge AI infrastructure?

Join the Akamai Inference Cloud Team!

The Akamai Inference Cloud team is part of Akamai's Cloud Technology Group. We design, implement, and operate AI platforms enabling customers to run inference models and developers to create applications with unmatched performance, compliance, and economics. The Control Plane & Developer Experience team owns the API platform, developer tools, security, authentication, billing integration, and user-facing interfaces empowering developers.

Partner with the best

As a Software Engineer I on the Control Plane & Developer Experience team, you will build and maintain customer-facing platform features across the Akamai Inference Cloud control plane. You'll work alongside experienced engineers and gain hands-on exposure to API platform development, cloud services, and AI infrastructure.

\#AIC

As a Software Engineer, you will be responsible for:

- Developing and maintaining services for control plane including API endpoints, configuration management, and platform workflows
- Building customer-facing features that enable users to configure, manage, and interact with inference platform resources
- Writing well-tested, well-documented code and participating in code reviews to maintain engineering standards
- Collaborating with engineering and product teams to translate requirements into reliable platform capabilities
- Contributing to platform reliability through monitoring, debugging, and operational support of control plane services

Do what you love

To be successful in this role you will:

- Have a Bachelor's/Master's degree in Computer Science or its equivalent
- Demonstrate proficiency in at least one programming language such as Python, Go, or JavaScript
- Have familiarity with RESTful APIs and basic cloud computing concepts
- Show familiarity with Git, GitHub workflows, and modern software development practices
- Demonstrate curiosity and a desire to learn cloud platform and API development patterns
- Possess solid problem-solving skills and the ability to work effectively in a collaborative engineering team

Work in a way that works for you

FlexBase, Akamai's Global Flexible Working Program, is based on the principles that are helping us create the best workplace in the world. When our colleagues said that flexible working was important to them, we listened. We also know flexible working is important to many of the incredible people considering joining Akamai. FlexBase, gives 95% of employees the choice to work from their home, their office, or both (in the country advertised). This permanent workplace flexibility program is consistent and fair globally, to help us find incredible talent, virtually anywhere. We are happy to discuss working options for this role and encourage you to speak with your recruiter in more detail when you apply.

Learn what makes Akamai a great place to work



| Connect with us on social and see what life at Akamai is like! | image (image) image (image) image (image) image (image) image (image) image (image) |
| -------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |



We power and protect life online, by solving the toughest challenges, together.

At Akamai, we're curious, innovative, collaborative and tenacious. We celebrate diversity of thought and we hold an unwavering belief that we can make a meaningful difference. Our teams use their global perspectives to put customers at the forefront of everything they do, so if you are people-centric, you'll thrive here.

Working for you

At Akamai, we will provide you with opportunities to grow, flourish, and achieve great things. Our benefit options are designed to meet your individual needs for today and in the future. We provide benefits surrounding all aspects of your life:

- Your health
- Your finances
- Your family
- Your time at work
- Your time pursuing other endeavors

Our benefit plan options are designed to meet your individual needs and budget, both today and in the future.

About us

Akamai powers and protects life online. Leading companies worldwide choose Akamai to build, deliver, and secure their digital experiences helping billions of people live, work, and play every day. With the world's most distributed compute platform from cloud to edge we make it easy for customers to develop and run applications, while we keep experiences closer to users and threats farther away.

Join us

Are you seeking an opportunity to make a real difference in a company with a global reach and exciting services and clients? Come join us and grow with a team of people who will energize and inspire you!

Akamai Technologies is an Affirmative Action, Equal Opportunity Employer that values the strength that diversity brings to the workplace. All qualified applicants will receive consideration for employment and will not be discriminated against on the basis of gender, gender identity, sexual orientation, race/ethnicity, protected veteran status, disability, or other protected group status.

If no date is displayed, applications are being accepted on an ongoing basis until the job is filled.

Compensation

Akamai is committed to fair and equitable compensation practices. For US based candidates only - the base salary for this position ranges from $75,700 - $136,300/year; a candidate’s salary is determined by various factors including, but not limited to, relevant work experience, skills, certifications and location. Compensation for candidates outside the US will vary. The compensation package may also include incentive compensation opportunities in the form of annual bonus or incentives, equity awards and an Employee Stock Purchase Plan (ESPP). Akamai provides industry-leading benefits including healthcare, 401K savings plan, company holidays, vacation (in the form of PTO), sick time, family friendly benefits including parental leave and an employee assistance program including a focus on mental and financial wellness; Eligibility requirements apply.

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
             Master’s CS student building backend APIs, event-driven services, and reliable distributed systems.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals using OCR/LLM
      vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B), CrossRef API, and web scrapers.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
  ∙Added confidence scoring that flags low-confidence fields for human review, and parallelized the pipeline with a CPU-based
     worker pool, cutting total processing time by over 80%.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, restricting access with VPC networking and security groups.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka | GitHub                        October 2026
  ∙Coded the Java payment flow so that each payment takes effect exactly once even when Kafka delivers a message more
     than once, using a transactional outbox and idempotent consumers.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Configured a GitHub Actions CI workflow that runs all 94 of the ledger’s tests, including integration tests that start real
     database and message-broker containers with Testcontainers.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Created a Git-diff check that flags unexpected edits, missing tests, and stale callers.
   ∙Directed Claude Code while building RIPPLE, checking the code it generated by running RIPPLE’s 241-test suite and
      testing how the agent handles edge cases across real repositories.

LaunchOps: Employee Onboarding Platform | Django, Python, Go, JavaScript | GitHub               March 2026
   ∙Designed a Django REST and React onboarding platform with a 20-task workflow across HR, IT, and managers.
   ∙Implemented a live-quiz service in Go that runs as two copies behind nginx, kept in sync through Redis.
   ∙Enforced server-side rules that reject forged evidence, skipped prerequisites, duplicate submissions, and edits to other
      users’ tasks, and hold completion while support issues stay open.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, JavaScript, Go, Java, SQL, PostgreSQL, MySQL
  ∙Frameworks & Libraries: Django REST Framework, Django, Spring Boot, Testcontainers, ReactJS
   ∙Software Engineering: REST APIs, Unit Testing, Code Review, Application Monitoring, Debugging, Concurrency,
      Parallel Processing, Backend Development, Distributed Systems, Event-Driven Architecture
   ∙Tools: Git, OAuth/Auth0, Redis, Apache Kafka, GitHub Actions, Claude Code, nginx, GitHub, Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Software Engineer role at Akamai Technologies. I want to help build the API endpoints, configuration management, and customer-facing features that developers use on the Akamai Inference Cloud. At Thesis Mumbai Tech, I led delivery of healthcare platform modules with a team of 4, gathering requirements in client meetings and prototyping to validate scope.

LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. A GitHub Actions CI workflow runs its 94 automated tests. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Its Git-diff check flags unexpected edits, missing tests, and stale callers. Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite. I graduate in December 2026 and can start work in February 2027. I want to build and maintain customer-facing platform features at Akamai Technologies, drawing on the real-time IoT pipeline I built at Thesis Mumbai Tech.

Sincerely,
Jay Niketan Pathare
```

---

## 2. EBSCO Information Services | Software Dev Engineer I

Pipeline v3.4.9a; file key EBSCO_Information_Services_Software_Dev_Engineer_I; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Software Dev Engineer I

LocationUS-AL-Birmingham

ID2026-2112

Category 

Information Technology

Position Type 

Full-Time Regular

Remote 

Hybrid
EBSCO Information Services (EBSCO) delivers a fully optimized research experience, seamlessly integrated with a powerful discovery platform to support the information needs and maximize the research experience of our end-users. Headquartered in Ipswich, MA, EBSCO employs more than 2,700 people worldwide, with most embracing hybrid or remote work models. As an AI-enabled service leader, we thrive on innovation, forward-thinking strategies, and the dedication of our exceptional team. At EBSCO, we’re driven to inspire, empower and support research. Our mission is to transform lives by providing reliable and relevant information — when, where and how people need it. We’re seeking dynamic, creative individuals whose diverse perspectives will help us achieve this global, inclusive mission. Join us to help make an impact.
Your Opportunity
About the role

As a Software Engineer, you'll work on an Agile development team building, testing, and deploying great products and services for our customers. You'll help create information products and services that inform the world, advance research in traditional and emerging fields, and transform learning and education.

You'll design, develop, and demonstrate software in 1- or 2-week iterations as part of an Agile Release Train working toward SAFe Program Increments. You'll make commitments to the business and meet them as a team. You will strive for continuous improvement in knowledge and productivity and display a pattern of continual learning and a desire to broaden your software development and design skills.
What You'll Do
What you'll do

- Contribute to the architecture, design, implementation, testing, delivery, and operation of components for EBSCO products and services
- Work with product management and your team to break complex requirements into clear user stories
- Collaborate with your team to estimate features, then design, build, and test them, committing to work within an iteration
- Own quality throughout development, testing, and deployment
- Write well-engineered solutions using test-first and test-driven approaches
- Use AI tools thoughtfully across the development lifecycle, including planning, coding, testing, and code review, while applying your own judgment and verifying the results
- Provide ongoing maintenance, support, and enhancements to existing systems, including operational support for components your team owns (on-call availability as needed)
- Work alongside other engineers to raise the bar on design, coding standards, performance, security, and maintainability
- Contribute to the continuous improvement of your team, in the spirit of the Agile Manifesto and SAFe
What you'll need

- Bachelor's degree in Computer Science, MIS, Computer Engineering, or a related technical field, or equivalent experience
- 0-3 years of professional experience, including internships or co-ops, building software with C#/.NET and/or JavaScript/TypeScript
- 0-3 years of professional experience in React (Next.js a plus) and modern web development fundamentals: HTML, CSS, HTTP, JSON, RESTful web services
- Working knowledge of SQL (ANSI SQL is what matters; we use PostgreSQL and SQL Server)
- Proficiency with source control (git)
- Familiarity with using AI across the software development lifecycle: planning, development, testing, and code review. You can describe how you've used these tools, where they helped, and where you needed to check or correct their output. Coursework, internships, and personal projects all count.
About You
What sets you apart

- Professional experience with one of more JavaScript frameworks (js, React), including state management and component testing
- Experience with AWS services and cloud-based application deployment
- Hands-on experience with PostgreSQL and/or SQL Server, including query tuning and schema design
- Test-driven development and automated testing (unit, integration, contract, and end-to-end)
- DevOps experience: CI/CD pipelines, infrastructure as code, automated deployment
- Experience designing and consuming web services, including API versioning, microservices, and service-oriented patterns
- Familiarity with performance testing strategies and tools
- Prior experience on an Agile team, ideally in a SAFe environment
Competencies we look for

Technical mastery, ownership and accountability, adaptability to new technologies, Lean/Agile practices, customer focus, and putting the team ahead of self. We value drive, positive attitude, trust and respect, open communication, critical thinking, and continuous improvement.
Pay Range

USD $67,875.00 - USD $96,965.00 /Yr.

[Apply]( "Apply")


The actual salary offer will carefully consider a wide range of factors including your skills, qualifications, education, training, and experience, as well as the position’s work location.

Our Work Policy: We value the balance of remote focus and in-person connection. For all our roles not designated as onsite, candidates living within a 30-mile radius of one of our hub office locations (Ipswich, MA; Birmingham, AL; Contoocook, NH) are required to be on-site one day designated by their team for collaboration and syncs. If you reside outside of this 30-mile range, the position is considered fully remote.

EBSCO provides a generous benefits program including:

-Medical, Dental, Vision, Life and Disability Insurance and Flexible spending accounts
-Retirement Savings Plan
-Paid Parental Leave
-Holidays and Paid Time Off (PTO)
-Mentoring program
And much more! Check it out here: 

We are an equal opportunity employer and comply with all applicable federal, state, and local fair employment practices laws. We strictly prohibit and do not tolerate discrimination against employees, applicants, or any other covered persons because of race, color, sex, pregnancy status, age, national origin or ancestry, ethnicity, religion, creed, sexual orientation, gender identity, status as a veteran, and basis of disability or any other federal, state or local protected class. This policy applies to all terms and conditions of employment, including, but not limited to, hiring, training, promotion, discipline, compensation, benefits, and termination of employment. We comply with the Americans with Disabilities Act (ADA), as amended by the ADA Amendments Act, and all applicable state or local law.

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                     Master’s CS student building reliable backend, full-stack, and distributed systems.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision
      (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL | GitHub           October 2026
   ∙Designed a payment API and a double-entry ledger as two Spring Boot services that talk through Kafka.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Verified the Java payment ledger in a GitHub Actions CI workflow that runs all 94 of its tests, including integration tests
     that run against real PostgreSQL and Kafka instances in containers.
   ∙Validated payment correctness by forcing 14 service crashes and repeating 18,000 messages; every one of those runs ended
     with no wrong balances and no payment recorded twice in the ledger.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Created a Git-diff check that flags unexpected edits, missing tests, and stale callers.
   ∙Directed Claude Code while building RIPPLE, checking the code it generated by running RIPPLE’s 241-test suite and
      testing how the agent handles edge cases across real repositories.

LaunchOps: Employee Onboarding Platform | Django, JavaScript, PostgreSQL, ReactJS | GitHub        March 2026
   ∙Implemented a 20-task onboarding workflow in Django REST and React that coordinates HR, IT, managers, and new
     employees, with an owner, prerequisites, and required evidence on each task.
   ∙Enforced server-side rules that reject forged evidence, skipped prerequisites, duplicate submissions, and edits to other
      users’ tasks, and hold completion while support issues stay open.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY
Relevant coursework: Agentic AI, Machine Learning, Deep Learning

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: JavaScript, SQL, HTML/CSS, Java, Python, JSON, PostgreSQL, MySQL
  ∙Frameworks & Libraries: ReactJS, Django REST Framework, Django, Spring Boot
   ∙Software Engineering: Unit Testing, Code Review, SDLC, Agile, Production Deployment, REST APIs, Microservices,
     Continuous Integration, Database Design, Data Validation
   ∙Tools: Git, AWS (EC2/RDS), Apache Kafka, GitHub Actions, Claude Code, WebSockets, Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Software Dev Engineer I role at EBSCO Information Services. I want to help design, build, and test the components behind EBSCO's research products, using test-first development and AI tools with careful review. At Thesis Mumbai Tech, I reviewed and merged team pull requests and restored production services after heartbeat-detected failures.

LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. A GitHub Actions CI workflow runs its 94 automated tests. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Its Git-diff check flags unexpected edits, missing tests, and stale callers. Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to design, develop, and demonstrate software at EBSCO Information Services, building on LedgerFlow, which kept every balance correct through forced crashes and repeated messages.

Sincerely,
Jay Niketan Pathare
```

---

## 3. Giga | Software Engineer I / II

Pipeline v3.4.9a; file key Giga_Software_Engineer_I_II; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Software Engineer I / II
Location

San Francisco
Employment Type

Full time
Location Type

On-site
Department

Engineering
Compensation

- $160K – $250K • Offers Equity

OverviewApplication
About Giga

Giga has recently raised a $61M Series A and has several paying customers, including DoorDash. We’re building the next generation of customer experience — real-time AI agents that can understand emotion, resolve issues instantly, and scale across the world’s largest enterprises.

It’s an exciting inflection point for the company. While we have been successful, we have larger ambitions. Our goal is to become the go-to AI platform for all enterprise automation, powered by our voice superintelligence. To achieve this, we need more great engineers.

The work affects millions of people every day and our engineers have autonomy and make true impact. This opportunity is unique because we have brilliant founders, have found commercial success, and see a clear path to becoming a generational company. Some further info about us:

- Voice AI startup Giga raises $61M Series A
- DoorDash and Giga Partnership

Giga builds AI agents trusted by the largest B2C companies in the world. Industry leaders like DoorDash trust Giga with their most complex support and operations workflows across voice, chat, and email. If being a part of this resonates with you, please apply!
The Role

We're looking for software engineers to help build the systems that power our AI agents. You'll work across the backend, from data pipelines and integrations to agent infrastructure, shipping features alongside experienced engineers who will help you grow.

This is a role where you'll contribute to real problems from day one. We expect you to ramp up quickly, take ownership of your work, and operate with increasing independence as you learn the codebase.
What You'll Work On

You'll contribute to projects across our stack. Some examples:

- Atlas: Building features for our AI assistant: charts and alerts in Slack, natural language queries, and expanding Atlas to manage platform resources
- Activity Stream: Log visualization with filters, timestamps, and frequency charts to give visibility into agent behavior
- Dynamic knowledge: Adding time-based knowledge (like ongoing incidents) that auto-updates from sources like status pages
- Agent memory: Conversation awareness and recent interaction lookups so agents remember context across sessions

As an early-career engineer, you'll be paired with senior engineers on larger initiatives while also owning smaller projects end-to-end as you ramp up.
You Might Be a Fit If You

- Have 1-3 years of professional software engineering experience
- Are curious and ask good questions—you want to understand why things work, not just how
- Can take feedback well and iterate quickly
- Prefer shipping over perfection but still care about quality
- Want to grow at a startup where you'll have real responsibility early
Perks & Benefits

- Competitive base + bonus + equity
- Catered lunch daily
- Dinner stipend
- $500/month wellness & commuter benefit (gym, fitness classes, mental health)
- 401(k) plan
- Medical, dental, and vision coverage

Giga is an equal opportunity employer. We're committed to providing equal employment opportunities regardless of race, color, religion, sex, sexual orientation, gender identity, national origin, age, disability, veteran status, or any other characteristic protected by law.

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
               Master’s CS student building AI agents, ML systems, and evidence-driven evaluation pipelines.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY
Relevant coursework: Agentic AI, Machine Learning, Deep Learning

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals using OCR/LLM
      vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B), CrossRef API, and web scrapers.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
  ∙Added confidence scoring that flags low-confidence fields for human review, and parallelized the pipeline with a CPU-based
     worker pool, cutting total processing time by over 80%.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
   ∙Gathered requirements in client meetings, prototyped to validate scope, and led a team of 4 through end-to-end delivery
      of healthcare platform modules.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

PERSONAL PROJECTS
GoingOnce: Multi-Agent Car Marketplace | Python, LangGraph, ReactJS, Streamlit | GitHub           October 2026
   ∙Prototyped a four-agent car marketplace with a four-person team; a human approves every simulated bid or listing.
  ∙Wrote the Streamlit and React interface that shows each agent’s progress live from the streaming API.
  ∙Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling a language model only for
     language and photos, with a saved fallback for every call, so results repeat.
  ∙Coded the Negotiate agent, where each side’s agent keeps a private price limit and a mediator closes the gap in rounds,
     then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.

LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL | GitHub           October 2026
   ∙Designed a payment API and a double-entry ledger as two Spring Boot services that talk through Kafka.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Configured a GitHub Actions CI workflow that runs all 94 of the ledger’s tests.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
   ∙Created an AI agent for Python repositories that reads a plain-English change request and predicts the affected files, tests,
     and regression risks before any development begins on the change.
   ∙Evaluated the agent on 30 unseen tasks from 16 real code repositories with zero unsupported claims accepted.
   ∙Measured agent usage at about 10 tool calls and about 17 model calls per run, with under one duplicate call.
   ∙Implemented RIPPLE with Claude Code, checking its generated code by running RIPPLE’s 241-test suite.
   ∙Integrated seven code-analysis tools into the agent’s tool-calling loop under a cap of 25 calls per task.

TECHNICAL SKILLS
  ∙Languages & Databases: Java, Python, SQL, PostgreSQL
  ∙Frameworks & Libraries: LangGraph, Spring Boot, ReactJS, Streamlit
  ∙AI/ML: AI Agents, Tool Calling, LLM Integration
   ∙Software Engineering: Data Pipelines, REST APIs, Parallel Processing, Microservices, Data Validation, Data Modeling,
     Backend Development, Event-Driven Architecture, Distributed Systems, Concurrency
   ∙Tools: Apache Kafka, GitHub Actions, Git, Claude API, Claude Code, Redis, AWS (EC2/RDS), Docker, WebSockets

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Software Engineer I / II role at Giga. I want to help build the backend systems, data pipelines, and integrations that let Giga's AI agents resolve customer issues. At HeinOnline, I built a pipeline that combined the CrossRef API, web scrapers, and OCR/LLM vision to extract metadata from 28k+ pages of law journals with about 91% accuracy.

I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. GoingOnce is a multi-agent car marketplace prototype my team of four built, where I mainly built the Negotiate and Fleet agents. A human approves every simulated bid or listing before it goes through. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to help build the systems that power the AI agents at Giga, drawing on RIPPLE, which checks every claim against evidence.

Sincerely,
Jay Niketan Pathare
```

---

## 4. Meritore Technologies LLC | Software Engineer

Pipeline v3.4.9a; file key Meritore_Technologies_LLC_Software_Engineer; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Job Code : JPC - 1372

Job Description

JOB ID 12239: Software Engineer

Meritore Technologies LLC, a Ashburn, VA based IT Solution, Services and Product Development Firm has Multiple Openings for JOB ID 12239: Software Engineer.

Job duties include:

- Design develop software modules and components.
- Write clean, efficient, and well-documented code.
- Participate in code reviews to improve code quality.
- Conduct unit and integration testing to ensure software quality.
- Collaborate with team members to identify and resolve issues.
- Use version control systems to manage code effectively.
- Stay updated with the latest technologies and industry trends.



Requirements:

Bachelor's degree in Science, IT, Business Administration or related with at least 12 months of experience or 3 consecutive years of related Bachelor’s level education in Science, IT, Business Administration or related with 24 months of experience.

Salary ranges between $150,758.00 to $153,000.00/year.

Send resume to: hr@meritore.com including the JOB ID.

Travel and relocation to various unanticipated client locations throughout the United States may be required. Equal Opportunity Employer

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                     Master’s CS student building reliable backend, full-stack, and distributed systems.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision
      (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitoring dashboard for 4 production projects, pinging each site every 5 minutes to track health.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL | GitHub           October 2026
   ∙Designed a payment API and a double-entry ledger as two Spring Boot services that talk through Kafka.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Stress-tested the ledger with 200 simultaneous payment requests against an account funded for only 50; only funded
     payments went through and the balance ended at zero with no overdraft.
   ∙Configured a GitHub Actions CI workflow that runs all 94 of the ledger’s tests, including integration tests that start real
     database and message-broker containers with Testcontainers.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Evaluated the agent on 30 unseen tasks from 16 real code repositories with zero unsupported claims accepted.
   ∙Validated every finished code change with RIPPLE’s own Git-diff check, which runs after the change is made, reads its
     Git diff, and flags unexpected edits, missing tests, and stale callers.

LaunchOps: Employee Onboarding Platform | Django, ReactJS, PostgreSQL | GitHub                 March 2026
   ∙Created a Django REST and React platform that guides new employees through a 20-task onboarding workflow shared
     by HR, IT, and managers, with an owner and prerequisites on every task.
   ∙Enforced server-side checks that block forged evidence, skipped prerequisites, and duplicate submissions.
   ∙Implemented a live-quiz service in Go that runs as two copies behind nginx, kept in sync through Redis.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, Java, Go, SQL, PostgreSQL, MySQL
  ∙Frameworks & Libraries: Testcontainers, Django REST Framework, Django, ReactJS, Spring Boot
   ∙Software Engineering: Code Review, Integration Testing, Unit Testing, Data Validation, REST APIs, Full-Stack
     Development, Microservices, Backend Development, Event-Driven Architecture, ETL
   ∙Tools: Git, Redis, Apache Kafka, GitHub Actions, nginx, AWS (EC2/RDS), Docker, WebSockets

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Software Engineer role at Meritore Technologies LLC. I want to help design and develop software modules and components at Meritore, backed by unit and integration testing and code reviews. At Thesis Mumbai Tech, I reviewed and merged team pull requests and restored production services after heartbeat-detected failures.

LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, only the funded payments went through and the balance ended at zero. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Its Git-diff check flags unexpected edits, missing tests, and stale callers. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to write clean, efficient, and well-documented code at Meritore Technologies LLC, building on LedgerFlow, where a GitHub Actions CI workflow runs every automated test.

Sincerely,
Jay Niketan Pathare
```

---

## 5. UST | Software Engineer

Pipeline v3.4.9a; file key UST_Software_Engineer; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Careers at UST
Software Engineer

- Job ID: 66812
- 2 Openings
- Frisco
Role description



Software Engineer



The Role

UST is searching for a skilled and motivated Software Engineer to design, develop, test, and maintain high-quality software applications. The ideal candidate will collaborate with cross-functional teams to deliver scalable, reliable, and innovative solutions that meet business requirements.





What You’ll Do

· Design, develop, test, deploy, and maintain software applications.

· Analyze business requirements and translate them into technical solutions.

· Write clean, efficient, and reusable code following coding standards and best practices.

· Participate in code reviews and ensure software quality.

· Troubleshoot, debug, and resolve application issues.

· Collaborate with product managers, architects, QA teams, and stakeholders.

· Develop APIs, integrations, and backend services as required.

· Optimize application performance, scalability, and security.

· Create and maintain technical documentation. Stay updated with emerging technologies and industry trends.



This position description identifies the responsibilities and tasks typically associated with the performance of the position. Other relevant essential functions may be required.



What You Need

· Bachelor's degree in Computer Science, Information Technology, Engineering, or related field.

· Strong programming experience in one or more languages such as Java, C#, Python, JavaScript, or Go.

· Experience with object-oriented design principles and software development methodologies.

· Knowledge of REST APIs, microservices, and web technologies.

· Experience with databases such as SQL Server, MySQL, PostgreSQL, or MongoDB.

· Familiarity with Git and CI/CD tools.

· Understanding of cloud platforms such as Azure, AWS, or GCP.

· Strong problem-solving and analytical skills.

· Excellent communication and teamwork abilities.





Location & Compensation



Compensation can differ depending on factors including but not limited to the specific office location, role, skill set, education, and level of experience. UST provides a reasonable range of compensation for roles that may be hired in various U.S. markets as set forth below.

Role Location: Hybrid- Frisco, Texas

Compensation Range: $56,000-$84,000







Who We Are

Since 1999, UST has worked side by side with the world’s best companies to make a powerful impact through transformation. Headquartered in the United States, UST is powered by technology, driven by AI, inspired by people, and led by our purpose, we partner with our clients from design to operation. Our AI-driven digital solutions, proprietary platforms, engineering, R&D, products, and innovation ecosystem turn core challenges into impactful, disruptive business outcomes. With deep industry knowledge and a future-ready mindset, we infuse expertise, innovation, and agility into our clients’ organizations—delivering measurable value and positive lasting change for them, their customers, and communities around the world. Together, with 30,000+ employees in 30+ countries, we build for boundless impact—touching billions of lives in the process. Visit us at .



Benefits

Full-time, regular employees accrue a minimum of 10 days of paid vacation per year, receive 6 days of paid sick leave each year (pro-rated for new hires throughout the year), 10 paid holidays, and are eligible for paid bereavement leave and jury duty. They are eligible to participate in the Company’s 401(k) Retirement Plan with employer matching. They and their dependents residing in the US are eligible for medical, dental, and vision insurance, as well as the following Company-paid Employee Only benefits: basic life insurance, accidental death and disability insurance, and short- and long-term disability benefits. Regular employees may purchase additional voluntary short-term disability benefits, and participate in a Health Savings Account (HSA) as well as a Flexible Spending Account (FSA) for healthcare, dependent child care, and/or commuting expenses as allowable under IRS guidelines. Benefits offerings vary in Puerto Rico.

Part-time employees receive 6 days of paid sick leave each year (pro-rated for new hires throughout the year) and are eligible to participate in the Company’s 401(k) Retirement Plan with employer matching.

Full-time temporary employees receive 6 days of paid sick leave each year (pro-rated for new hires throughout the year) and are eligible to participate in the Company’s 401(k) program with employer matching. They and their dependents residing in the US are eligible for medical, dental, and vision insurance.

Part-time temporary employees receive 6 days of paid sick leave each year (pro-rated for new hires throughout the year).

All US employees who work in a state or locality with more generous paid sick leave benefits than specified here will receive the benefit of those sick leave laws.



Equal Employment Opportunity Statement

UST is an Equal Opportunity Employer.

All qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender identity, national origin, disability, status as a protected veteran, or any other applicable characteristics protected by law. We will consider qualified applicants with arrest or conviction records in accordance with state and local laws and “fair chance” ordinances.

UST reserves the right to periodically redefine your roles and responsibilities based on the requirements of the organization and/or your performance.



\#UST

\#CB

\#LI-AP4
Skills



AI Coding Agents, AI Mentor Studio, AI FinOps
Benefits
Compensation range: $ 56,000.00 to 84,000.00 per year

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
             Master’s CS student building backend APIs, event-driven services, and reliable distributed systems.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant data pipeline that processed 28k+ pages of law journals, combining CrossRef API, web scrapers,
     and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B).
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL | GitHub           October 2026
  ∙Coded the Java payment flow so that each payment takes effect exactly once even when Kafka delivers a message more
     than once, using a transactional outbox and idempotent consumers.
   ∙Prevented overspending under 200 simultaneous payments on an account funded for only 50, letting only the funded
     payments through and leaving the account balance at exactly zero with no overdraft.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Optimized outbox polling to reduce response time for the slowest 5% of payment requests by about 58%.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Created a Git-diff check that flags unexpected edits, missing tests, and stale callers.
   ∙Directed Claude Code while building RIPPLE, checking the code it generated by running RIPPLE’s 241-test suite and
      testing how the agent handles edge cases across real repositories.

LaunchOps: Employee Onboarding Platform | Django, Go, PostgreSQL | GitHub                     March 2026
   ∙Designed a Django REST and React onboarding platform with a 20-task workflow across HR, IT, and managers.
   ∙Enforced server-side checks that block forged evidence, skipped prerequisites, and duplicate submissions.
   ∙Implemented a real-time quiz service in Go that runs as two copies behind nginx, with Redis keeping both copies in sync
     and a unique MongoDB index rejecting duplicate answers in live sessions.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, SQL, Java, Go, JavaScript, PostgreSQL, MongoDB, MySQL
  ∙Frameworks & Libraries: Django REST Framework, Django, Spring Boot, ReactJS
   ∙Software Engineering: REST APIs, Backend Development, Code Review, OOP, Microservices, Continuous Integration,
     Unit Testing, Data Validation, Application Monitoring, Distributed Systems
   ∙Tools: Git, AWS (EC2/RDS), Claude Code, Redis, Apache Kafka, nginx, Docker, WebSockets

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Software Engineer role at UST. I want to help design, develop, test, and maintain the APIs, integrations, and backend services that UST delivers. At Thesis Mumbai Tech, I reviewed and merged team pull requests, mentored new hires through weekly coding rounds, and responded to heartbeat-detected production failures by restoring the affected services.

LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. Under 200 simultaneous payments on an account funded for only 50, only the funded payments went through and the balance ended at exactly zero. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to design, develop, test, deploy, and maintain software applications at UST, building on LedgerFlow, which kept every balance correct through forced crashes and repeated messages.

Sincerely,
Jay Niketan Pathare
```

---

## 6. Zoro | Software Developer- Full Stack

Pipeline v3.4.9a; file key Zoro_Software_Developer_Full_Stack; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Zoro.com
·
1 hour ago
Software Developer- Full Stack
Buffalo Grove, IL
+1 more
Full-time
Onsite
Entry, Mid, Senior Level
78%
Experience Level
100%
Skill
74%
Industry Exp.
39%
Zoro is hiring a Full Stack Software Developer to build scalable infrastructure and customer-facing solutions that support product data and customer experience. The role develops technical solutions to user stories, helps define tools and processes, and works across IT and business teams to support deployment.
Automotive
Construction
E-Commerce
Food and Beverage
Healthcare
Public Safety
Landscaping
Lighting
Medical
Office Supplies
Small and Medium Businesses
H1B Sponsor Likely

Responsibilities
We want to bridge the gap between web developers and traditional tech ops by building processes that support our infrastructure including data management, monitoring, and deployment
This role focuses on solutions that allow for scale to keep up with customer demand, showcase the most current products, and provide the best customer experience
We are looking for someone that can work in the Scrum/Agile environment and bridge the gap between IT development and the business areas
You will be an integral part of defining our tool set, systems and processes
This role will provide the technical solutions to user stories and facilitate the tasks and approach needed to for the solution deployment
Frequent, clear, and concise communication to IT leaders and business leaders is a key aspect of this role
Daily tasks might include development stand ups, communicating with different teams including Pricing, Product, eCommerce, and Marketing, verifying continual integration and deployment are functioning as needed, and winning the ping pong championship!
Qualification
Required
Proficient in high-level languages such as Python, Ruby or Javascript
Experienced in data movement, Linux(Centos, Ubuntu), Systems integration, testing, and deployment
Experience with RDBMS (MySQL, Postgres)
A desire to work in a fast growing, fast paced, company
Familiarity with agile methodology
Bachelor's degree in computer science or computer engineering or a STEM field required
Preferred
SQLAlchemy is a plus
ETL experience is a plus
master's degree preferred

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                     Master’s CS student building reliable backend, full-stack, and distributed systems.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision
      (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, restricting access with VPC networking and security groups.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka | GitHub                        October 2026
   ∙Designed a payment API and a double-entry ledger as two Spring Boot services that talk through Kafka.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Verified the Java payment ledger in a GitHub Actions CI workflow that runs all 94 of its tests, including integration tests
     that run against real PostgreSQL and Kafka instances in containers.

GoingOnce: Multi-Agent Car Marketplace | Python, LangGraph, ReactJS, JavaScript | GitHub          October 2026
   ∙Prototyped a four-agent car marketplace with a four-person team; a human approves every simulated bid or listing.
  ∙Wrote the Streamlit and React interface that shows each agent’s progress live from the streaming API.
  ∙Coded the Negotiate agent, where each side’s agent keeps a private price limit and a mediator closes the gap in rounds,
     then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.

LaunchOps: Employee Onboarding Platform | Django, ReactJS, Python | GitHub                     March 2026
   ∙Created a Django REST and React platform that guides new employees through a 20-task onboarding workflow shared
     by HR, IT, and managers, with an owner and prerequisites on every task.
   ∙Enforced server-side rules that reject forged evidence, skipped prerequisites, duplicate submissions, and edits to other
      users’ tasks, and hold completion while support issues stay open.
   ∙Implemented a real-time quiz service in Go that runs as two copies behind nginx, with Redis keeping both copies in sync
     and a unique MongoDB index rejecting duplicate answers in live sessions.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, JavaScript, Java, Go, SQL, MySQL, PostgreSQL, MongoDB
  ∙Frameworks & Libraries: Django REST Framework, Django, ReactJS, Spring Boot
   ∙Software Engineering: Full-Stack Development, Production Deployment, Agile, Unit Testing, Application Monitoring,
    ETL, Scrum, REST APIs, Parallel Processing, Event-Driven Architecture
   ∙Tools: Linux, Redis, Apache Kafka, GitHub Actions, nginx, Git, WebSockets, AWS (EC2/RDS), Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Software Developer- Full Stack role at Zoro. I want to help build the data management, monitoring, and deployment processes that let Zoro scale with customer demand. At Thesis Mumbai Tech, I developed Patient Management and Consent modules for 10k+ records and a real-time WebSocket and Redis pipeline that streamed IoT baby-warmer data into PostgreSQL.

LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side rules reject forged evidence, skipped prerequisites, and duplicate submissions. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, it never overdrew the account. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to build scalable infrastructure and customer-facing solutions at Zoro, drawing on LaunchOps, whose Go live-quiz service stays in sync across two copies.

Sincerely,
Jay Niketan Pathare
```

---

## 7. Not stated | AL/ML Engineer

Pipeline v3.4.9a; file key Company_Not_Stated_AL_ML_Engineer_a6e1f4; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
AL/ML Engineer#26-01987

svgSan Francisco, CAsvgOnsite

Job Description


AL/ML Engineer
Santa Clara, CA
FT Role

This opportunity is an ideal role for those seeking to build and deploy machine learning models at scale, and thrives in an environment where research translates rapidly into real-world systems.

Key Responsibilities:

- Design, train, and deploy machine learning models for production use at scale.
- Work on LLM-based systems — from fine tuning to building agents and evaluation pipelines.
- Collaborate with engineers and product teams to scope problems, define success metrics, and build robust evaluation frameworks.
- Mitigate LLM challenges: address biases, hallucinations, and knowledge cutoff limitations to improve trust and performance.
- Optimize models for latency, accuracy, and scalability in real-world applications.
- Contribute to end-to-end product development — from research to deployment to iteration.


Qualifications:

- 2+ years of experience in Machine Learning and/or Data Science, with a track record of shipping ML systems into production.
- Strong understanding of Machine Learning and Deep Learning libraries, such as Scikit Learn, Keras, TensorFlow, PyTorch, Theano, or DyLib
- Deep expertise in at least one of: the following:
- Search / retrieval / ranking or recommendation systems
- Generative AI product development (shipping beyond demos, building evals, problem scoping)
- LLM agent products
- LLM fine tuning
- Practical understanding of LLM limitations (bias, hallucinations, knowledge cutoffs).
- Experience working at an early-stage startup or on 0→1 product launches.
- Comfort with both research prototyping and production-grade engineering.


Direct Hire positions: They want local candidates to bay area. Preferred colleges are MIT, California Berkley, Santa Clara, Stanford, California State, Harvey Mudd, SF University. Jr to Mid level experience but looking for top of the class candidates.

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                  Master’s CS student building ML models, evaluation pipelines, and reliable data systems.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals using OCR/LLM
      vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B), CrossRef API, and web scrapers.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
  ∙Added confidence scoring that flags low-confidence fields for human review, and parallelized the pipeline with a CPU-based
     worker pool, cutting total processing time by over 80%.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules: gathered requirements in client meetings,
     prototyped to validate scope, and broke the finalized work into tasks.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitoring dashboard for 4 production projects, pinging each site every 5 minutes to track health.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
GoingOnce: Multi-Agent Car Marketplace | Python, LangGraph, ReactJS, Streamlit | GitHub           October 2026
   ∙Prototyped a multi-agent car marketplace with a four-person team: Buy, Sell, Negotiate, and Fleet agents, plus a human
    who approves every simulated bid or listing before it goes through.
  ∙Wrote the Streamlit and React front end for a streaming API so each agent’s progress appears on screen as it runs, letting
      users watch all four agents work through the simulated marketplace prototype.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
   ∙Designed RIPPLE, a Python command-line AI agent that reads a plain-English change request and predicts which files,
       tests, and regression risks it will touch before any code is written.
   ∙Measured how well the agent ranks the files a code change will touch on unseen tasks, scoring 0.311 MRR and 0.306
      precision against the files that actually changed in each task.

Fraud Detection using Graph Neural Networks | PyTorch, GraphSAGE | GitHub                           April 2026
   ∙Benchmarked a GraphSAGE graph neural network at 0.9259 AUC-ROC against a baseline of about 0.858 from a plain
      neural network on the highly imbalanced IEEE-CIS fraud dataset.
  ∙Ran an edge-type ablation across five identifier types, showing the graph adds 0.016 AUC over a no-edge baseline and
     that card links alone deliver almost all of that gain on the held-out test set.
   ∙Prevented data leakage by fitting the feature scaler on the training split only and tuning decision thresholds on validation
      data, then reporting final results only on a held-out 15% test set.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, SQL, PostgreSQL
  ∙Frameworks & Libraries: PyTorch, LangGraph, ReactJS, Streamlit, TensorFlow, Pandas, NumPy
  ∙AI/ML: Machine Learning, LLMs, Deep Learning, Model Evaluation, GNNs, Agentic AI
   ∙Software Engineering: Production Deployment, Data Modeling, Parallel Processing, Distributed Systems, Concurrency,
     Application Monitoring
   ∙Tools: Git, Redis, AWS (EC2/RDS), Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the AL/ML Engineer role you posted. I want to help design, train, and deploy machine learning models and build evaluation pipelines for LLM-based systems. At HeinOnline, I built a pipeline that combined the CrossRef API, web scrapers, and OCR/LLM vision to extract metadata from 28k+ pages of law journals with about 91% accuracy.

In my fraud-detection project, I trained graph neural networks in PyTorch on highly imbalanced transaction data. GraphSAGE reached 0.9259 AUC-ROC, against about 0.858 for a plain neural-network baseline. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. On unseen tasks, it ranked the affected files at 0.311 MRR and 0.306 precision. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to optimize models for latency, accuracy, and scalability in real-world applications on your team, building on my fraud model's edge-type ablation.

Sincerely,
Jay Niketan Pathare
```

---

## 8. DoorDash | Software Engineer, ML Infrastructure (MDX)

Pipeline v3.4.9a; file key DoorDash_Software_Engineer_ML_Infrastructure_MDX; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Software Engineer, ML Infrastructure (MDX)
DoorDash
San Francisco, CA; Sunnyvale, CA; Seattle, WA | USD 131k - 192k /yr | Entry Level | Onsite | Full Time | 2+ years experience | Software Engineering
Education: Bachelor's (required), PhD (preferred), Master's (preferred)

About the Team
DoorDash's MDX team sits within Machine Learning Platform and builds the shared foundation that ML engineers across DoorDash, Wolt, and Deliveroo rely on to build and run ML-powered products. We work across the full ML lifecycle: feature engineering, training, evaluation, deployment, serving, and monitoring. Our mission is to increase the velocity and reliability of ML-driven business impact across the company. A central pillar of that work is agentic infrastructure. We are building systems that let agents accelerate and operate the ML workflow itself, including auto research, where agents explore and iterate on modeling ideas, and self-healing systems that detect, diagnose, and remediate failures in ML pipelines and production models with minimal human intervention.

About the Role
You will join a small, high-leverage team building the agentic layer of DoorDash's ML infrastructure. You'll design and build the systems that let agents accelerate how ML engineers across DoorDash, Wolt, and Deliveroo develop, ship, and operate models. That includes auto research systems that explore and iterate on modeling ideas, and agentic developer support that helps ML engineers move through training, evaluation, deployment, and debugging faster. You'll own well-scoped components end to end, from design through production, working across agent orchestration, tooling and integrations with our ML platform, evaluation of agent behavior, and observability. This role is ideal for an engineer with a strong backend foundation who is excited to apply AI agents to real engineering workflows, learns quickly, and wants to grow into technical leadership in a fast-moving area where model capabilities, tooling, and best practices change month to month.

You're excited about this opportunity because you will...
- Build agentic systems that increase the velocity of ML development across DoorDash, Wolt, and Deliveroo, helping ML engineers get from idea to production model faster.
- Design and implement infrastructure that lets agents propose, run, and evaluate modeling experiments.
- Build agentic developer support for the ML lifecycle, such as agents that help engineers set up training jobs, debug failing pipelines, review model deployments, and navigate our platform.
- Develop evaluation and observability for agent behavior, so we can measure whether agents are actually helping, catch regressions early, and build the trust needed to give them more autonomy.
- Work with production standards in mind, including reliability, safety guardrails, cost controls, monitoring, and clear playbooks, so that agentic workflows can run against real ML systems.
- Partner closely with ML engineers, data scientists, and platform teams to understand where their time goes and turn those workflows into durable, reusable platform capabilities.
- Grow quickly in a fast-moving area, with the chance to shape how agents are used to build and operate ML systems at a company of this scale.

We're excited about you because...
- B.S., M.S., or PhD in Computer Science or equivalent
- 2+ years of industry experience in software engineering
- Hands-on experience building ML infrastructure in production including feature engineering and feature stores, data pipelines for ML, training and experimentation platforms, model evaluation, deployment, serving and inference, or monitoring
- Strong backend engineering fundamentals, especially in Python and distributed systems
- Experience operating systems in production, including testing, observability, debugging, and reliability
- A good understanding of how ML engineers and data scientists work, and a track record of building platforms, tools, or services that make them more productive
- Ability to take ambiguous, well-scoped problems from idea to production, and to learn quickly in a fast-moving technical area
- Proficiency in using AI coding tools (e.g., Claude Code, Codex, Cursor) across the software development lifecycle, including designing, generating code, testing, monitoring, and releasing software

Nice To Haves
- Experience building LLM-powered applications or AI agents, including tool use, orchestration, or MCP servers, in production or on substantial projects
- Experience with agent evaluation, LLM observability, tracing, or building eval harnesses
- Experience with ML platforms or MLOps tooling (e.g., Kubeflow, MLflow, Ray, Airflow)
- Experience with Kubernetes and cloud infrastructure (AWS/GCP)
- Experience building developer tools, internal platforms, or self-serve infrastructure
- Experience with guardrails, safety, or cost controls for LLM systems

National base pay range: $130,600 - $192,000 USD
[Compensation, benefits, company, diversity, NYC tool notice and scam notice text removed]

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                     Master’s CS student building agentic developer tools and reliable backend systems.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals using OCR/LLM
      vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B), CrossRef API, and web scrapers.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
  ∙Added confidence scoring that flags low-confidence fields for human review, and parallelized the pipeline with a CPU-based
     worker pool, cutting total processing time by over 80%.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules: gathered requirements in client meetings,
     prototyped to validate scope, and broke the finalized work into tasks.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, restricting access with VPC networking and security groups.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Kafka, PostgreSQL | GitHub                        October 2026
   ∙Designed a payment API and a double-entry ledger as two Java services that talk through Kafka.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Verified that all 250 payments completed with no duplicates while a service restarted in local Kubernetes.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Integrated seven code-analysis tools into the agent’s tool-calling loop under a cap of 25 calls per task.
   ∙Benchmarked the agent on 30 unseen change-request tasks drawn from 16 real code repositories, and not one of its final
      reports accepted a claim that lacked supporting evidence from the code.
   ∙Directed Claude Code while building RIPPLE, checking the code it generated by running RIPPLE’s 241-test suite and
      testing how the agent handles edge cases across real repositories.

LLM Application Optimization Engine | Python, Gemini API, Novita API, pytest | GitHub                  July 2026
   ∙Created an LLM pipeline that turns a job description into a tailored one-page resume and cover letter.
   ∙Implemented failover from Gemini to Novita’s model API after 3 failed attempts, repairing only failed parts.
   ∙Enforced Python checks that compare every generated resume claim against real source evidence and reject unsupported
      technologies, borrowed results, or changed numbers before output.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, Java, SQL, PostgreSQL, MySQL
  ∙Frameworks & Libraries: pytest, Pandas, NumPy
  ∙AI/ML: Machine Learning, AI Agents, Agentic Workflows, Model Evaluation, LLMs, Tool Calling
   ∙Software Engineering:  Production Deployment, Application Monitoring, Debugging, Distributed Systems, Unit
      Testing, SDLC, Data Pipelines, Data Modeling, Parallel Processing, Data Validation
   ∙Tools: Claude Code, Kubernetes (local k3d), AWS (EC2/RDS), Cursor, Apache Kafka, Git, Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Software Engineer, ML Infrastructure (MDX) role at DoorDash. I want to design and implement infrastructure that lets agents propose, run, and evaluate modeling experiments for DoorDash's ML platform. At HeinOnline, I built a pipeline that combined the CrossRef API, web scrapers, and OCR/LLM vision to extract metadata from 28k+ pages of law journals with about 91% accuracy.

I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite. It uses seven code-analysis tools with a cap of 25 tool calls per task. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, it never overdrew the account. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to build ML infrastructure in production including feature engineering and feature stores at DoorDash, drawing on my LLM engine's provider failover.

Sincerely,
Jay Niketan Pathare
```

---

## 9. Figure | Embedded Software Engineering Intern, Platform

Pipeline v3.4.9a; file key Figure_Embedded_Software_Engineering_Intern_Platform; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- graduation_window: The posting sets a graduation date that does not include Jay's December 2026 graduation. ("Student eligibility: Graduating May 2027 - May 2027")
- student_audience: The program is aimed at students with school left after the program; Jay graduates in December 2026. ("- Rising senior or recent graduate in Computer Science, Computer Engineering, Electrical Engineering, or a related field; must be graduating within one year.")

### JOB POSTING
Embedded Software Engineering Intern, Platform
Figure
San Jose, CA | USD 40 - 45 /hr | Internship | Onsite | Full Time | Software Engineering
Student eligibility: Graduating May 2027 - May 2027
Education: Bachelor's (required)

Figure is an AI robotics company developing autonomous general-purpose humanoid robots. The goal of the company is to ship humanoid robots with human level intelligence. Its robots are engineered to perform a variety of tasks in the home and commercial markets. Figure is headquartered in San Jose, CA.

We are looking for an Embedded Software Engineering Intern to join our Platform team. In summary, you will help build and improve the core software infrastructure that keeps our robot fleet running, with a focus on over-the-air (OTA) and firmware update systems that deliver software reliably and securely to robots in the field.

Responsibilities:
- Design, implement, and test features for the robot software platform, including OTA update delivery, firmware update flows, and the embedded Linux systems that support them.
- Work across software and hardware layers to integrate, debug, and validate updates on real robot hardware.
- Improve the reliability, security, and scalability of how software is deployed across the fleet.
- Measure the impact of your work and share results and recommendations with the team.

Requirements:
- Rising senior or recent graduate in Computer Science, Computer Engineering, Electrical Engineering, or a related field; must be graduating within one year.
- Minimum 10 weeks.
- Strong programming skills in C, C++, Rust, or Python.
- Experience with Linux and networking fundamentals.

Bonus Qualifications:
- Experience with embedded Linux build and update tools such as Yocto, RAUC, or SWUpdate.
- Experience with firmware development, bootloaders, or hardware bring-up.
- Familiarity with applied cryptography, such as code signing, PKI, or secure boot.

The US base pay range for this position is $40.00 to $45.00 per hour.

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
             Master’s CS student building tested C systems code with process management and synchronization.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision
      (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules: gathered requirements in client meetings,
     prototyped to validate scope, and broke the finalized work into tasks.
   ∙Developed a real-time WebSocket + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live
     monitoring, plus Patient Management and Consent modules on normalized schemas for 10k+ records.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL | GitHub           October 2026
   ∙Designed a payment API and a double-entry ledger as two Spring Boot services that talk through Kafka.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Configured a GitHub Actions CI workflow that runs all 94 of the ledger’s tests, including integration tests that start real
     database and message-broker containers with Testcontainers.
   ∙Validated payment correctness by forcing 14 service crashes and repeating 18,000 messages; every one of those runs ended
     with no wrong balances and no payment recorded twice in the ledger.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
   ∙Created an AI agent for Python repositories that reads a plain-English change request and predicts the affected files, tests,
     and regression risks before any development begins on the change.
   ∙Evaluated the agent on 30 unseen tasks from 16 real code repositories with zero unsupported claims accepted.
   ∙Integrated seven code-analysis tools into the agent’s tool-calling loop under a cap of 25 calls per task.
   ∙Directed Claude Code while building RIPPLE, checking the code it generated by running RIPPLE’s 241-test suite and
      testing how the agent handles edge cases across real repositories.

Pintos Operating System: User Programs Layer | C, x86, Operating Systems, Concurrency             May 2026
   ∙Implemented a teaching operating system’s user-programs layer in C, passing all 80 tests for program startup with
     arguments, parent-child waiting, system calls, and file handling.
   ∙Enforced thread synchronization with locks around shared kernel resources and safety checks on memory access, keeping
     the kernel safe when several user programs run at the same time.
  ∙Programmed the system-call interface that lets user programs open and manage files and processes through the kernel,
     supporting 13 system calls and up to 128 open files per process.

TECHNICAL SKILLS
  ∙Languages & Databases: Python, C, Java, SQL, PostgreSQL
  ∙Frameworks & Libraries: Testcontainers, Spring Boot
   ∙Software Engineering: Concurrency, Parallel Processing, Thread Synchronization, Operating Systems, Microservices,
     Application Monitoring, Event-Driven Architecture
   ∙Tools: Linux, Apache Kafka, GitHub Actions, Git, Claude Code, AWS (EC2/RDS), Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Embedded Software Engineering Intern, Platform role at Figure. I want to help build and improve the core software infrastructure that keeps Figure's robot fleet running safely through every update. At Thesis Mumbai Tech, I built a real-time WebSocket and Redis pipeline that streamed IoT baby-warmer device data into PostgreSQL with about 2-second live monitoring.

For an operating systems course, I wrote the user-programs layer of the Pintos teaching operating system in C. All 80 tests pass. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, it never overdrew the account. My Master's in Computer Science at the University at Buffalo is expected in December 2026, and I can start work in February 2027. I am open to relocating. I want to integrate, debug, and validate updates on real robot hardware at Figure, building on the locking and memory-access checks I wrote in C for Pintos.

Sincerely,
Jay Niketan Pathare
```

---

## 10. ElevenLabs | Full-Stack Engineer (Backend Leaning) - Platform Engineering

Pipeline v3.4.9a; file key ElevenLabs_Full_Stack_Engineer_Backend_Leaning_Platform_Engineering; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Full-Stack Engineer (Backend Leaning) - Platform Engineering
Eleven Labs
Remote | Entry Level | Full Time | Software Engineering

[Company description, "How we work" and "What we offer" sections removed]

About the role
Core Platform builds the foundations every other team at ElevenLabs builds on: how users, workspaces and permissions work across our products. Our systems sit on the path of every request and are relied on by millions of users and by enterprise customers, so correctness, security and safe rollout matter as much as speed.

We are hiring full stack engineers (backend leaning) for two focus areas. Depending on the team you join, your responsibilities might include:

Workspaces & User Management (serving external customers)
- Building and improving the building blocks customers touch directly: API keys, login experience, analytics, admin tooling, workspace security and more
- Working closely with Sales, FDEs and customer teams to turn enterprise and self-serve feedback into the right improvements, and helping large customers with complex organisational structures.
- Shipping customer-facing features end to end, from backend services to the admin and settings UI.

Permissions & Resources (serving ElevenLabs engineering teams)
- Designing and building generic resource and permissioning services that product teams use to build features safely and quickly.
- Solving hard, largely greenfield problems at scale, for example how a customer with a million agents assigns and manages access.
- Working across product teams to understand their needs, and driving adoption with changes that don't require every team to rework their code.

In both teams you will:
- Scope work as part of a large existing system: understand what exists, what could go wrong on rollout, whether a migration is needed, and how downstream teams are affected.
- Roll out changes safely and with minimal disruption to existing users, teams or systems.
- Debug and operate what you build, working from customer reports, logs and code.
- Own features from scoping to completion, with the support of experienced engineers who are happy to mentor.

Requirements
We do not require any formal experience, certifications, or degrees. Instead, we are seeking engineers who can show they have solved impressively hard problems, through past projects or GitHub contributions. We do require:
- Expertise in Python.
- A strong background in backend development, with comfort working across the stack where the work needs it.
- Experience with common software and system design patterns and infrastructure, including APIs, cloud infrastructure tools, storage solutions and data structures.
- Strong test design and security fundamentals.
- Care and attention to detail when changing live, business-critical systems, and the ability to learn a large existing codebase quickly.
- Comfort with ambiguity: working out what should be built, and prioritising among competing signals.

Bonus:
- Experience with authentication, authorization or permissioning (OAuth, SSO/SCIM, RBAC or similar).
- Experience with Kubernetes.
- Experience building internal platforms or services used by other engineering teams.

Location
Our team is based across the UK, EU and US, and this is our main focus. We are flexible for exceptional candidates elsewhere. You can work remotely, or from our offices in Dublin, London, New York, San Francisco and Warsaw.
[Equal-opportunity text removed]

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                      Master’s CS student building backend services and full-stack features end to end.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant data pipeline that processed 28k+ pages of law journals, combining CrossRef API, web scrapers,
     and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B).
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
   ∙Gathered requirements in client meetings, prototyped to validate scope, and led a team of 4 through end-to-end delivery
      of healthcare platform modules.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL | GitHub           October 2026
  ∙Coded the Java payment flow so that each payment takes effect exactly once even when Kafka delivers a message more
     than once, using a transactional outbox and idempotent consumers.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Configured a GitHub Actions CI workflow that runs all 94 of the ledger’s tests.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Integrated seven code-analysis tools into the agent’s tool-calling loop under a cap of 25 calls per task.
   ∙Evaluated the agent on 30 unseen tasks from 16 real code repositories with zero unsupported claims accepted.
   ∙Implemented RIPPLE with Claude Code, checking its generated code by running RIPPLE’s 241-test suite.

LaunchOps: Employee Onboarding Platform | Django, ReactJS, Python | GitHub                     March 2026
   ∙Designed a Django REST and React onboarding platform with a 20-task workflow across HR, IT, manager, and employee
       roles, where each task has an owner, prerequisites, and evidence.
   ∙Enforced server-side rules that reject forged evidence, skipped prerequisites, duplicate submissions, and edits to other
      users’ tasks, and hold completion while support issues stay open.
   ∙Created a live-quiz service in Go that runs as two copies behind nginx, with Redis coordinating both copies and a unique
     database index that rejects duplicate answers in live sessions.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, Java, Go, SQL, PostgreSQL, MySQL
  ∙Frameworks & Libraries: Django REST Framework, Django, Spring Boot, ReactJS
   ∙Software Engineering: REST APIs, Backend Development, System Design, Data Structures, Debugging, Full-Stack
     Development, Parallel Processing, Event-Driven Architecture, Distributed Systems, Concurrency
   ∙Tools: Redis, OAuth/Auth0, Apache Kafka, GitHub Actions, Git, Claude Code, nginx, GitHub, JWT

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Full-Stack Engineer (Backend Leaning) - Platform Engineering role at ElevenLabs. I want to build the core platform foundations that every ElevenLabs product builds on, so users, workspaces and permissions stay correct and secure. At Thesis Mumbai Tech, I reviewed and merged team pull requests, mentored new hires through weekly coding rounds, and responded to heartbeat-detected production failures by restoring the affected services.

LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side permission checks block users from editing other users' tasks and reject forged evidence and skipped prerequisites. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. A GitHub Actions CI workflow runs its 94 automated tests. I graduate in December 2026 and can start work in February 2027. I want to design and build generic resource and permissioning services at ElevenLabs, drawing on LaunchOps, where every onboarding task has an owner and prerequisites the server enforces.

Sincerely,
Jay Niketan Pathare
```

---

## 11. Macy's | Macy's 2027 Tech Early Careers - Software Engineer

Pipeline v3.4.9a; file key Macy_s_Macy_s_2027_Tech_Early_Careers_Software_Engineer; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- student_audience: The program is aimed at students with school left after the program; Jay graduates in December 2026. ("- Rising seniors majoring in Computer Science, Computer Engineering, or a related field with strong academic performance are encouraged to apply. Minimum 3.0 GP")
- enrollment_required: The internship starts after Jay's December 2026 graduation; Jay can start work in February 2027. ("Macy's 2027 Tech Early Careers - Software Engineer")

### JOB POSTING
Macy's 2027 Tech Early Careers - Software Engineer
Macy's
Johns Creek, GA | Entry Level | Onsite | Full Time | Software Engineering
Education: Bachelor's (required)

Job Overview
The Macy's Technology Summer Internship Program provides students with the opportunity to apply classroom knowledge in a real-world setting while exploring a potential engineering career within our organization. Macy's Tech combines the entrepreneurial spirit of a start-up with the stability of an iconic national brand, powered by a strong national footprint, a robust e-commerce business, and a seamless mobile experience that connects it all. Our technology team supports millions of customers in connected commerce across Macy's expansive technology hub.

What You Will Do
- Work alongside mentors and experienced engineers in an agile environment.
- Contribute to clearly defined projects that drive innovation and business impact.
- Collaborate with cross-functional teams and leaders across the organization.
- Gain exposure to a wide range of technologies and development areas, including:
 - Software Development: Java, JavaScript, Node.js, Angular.js, Vue.js, React.js, SRE, etc.
 - Mobile Development: iOS, Swift, Android, SDK, etc.
 - Cloud Development: Azure, AWS, GCP, etc.
 - Compute and Operations: Python, SQL, Unix/Linux, etc.
- Foster an environment of acceptance and respect that strengthens relationships, and ensures authentic connections with colleagues, customers, and communities.
- In addition to the essential duties mentioned above, other duties may be assigned.

Skills You Will Need
- Technical Proficiency & Programming Knowledge: Able to apply knowledge of programming languages (Java preferred), operating systems, and data processing to solve real-world challenges.
- Software Development Lifecycle Understanding: Familiar with Agile or similar methodologies, with the ability to contribute effectively to iterative development projects.
- Analytical & Business Acumen: Able to analyze data to identify trends, inform decisions, and understand the intersection of technology and retail business strategy.
- Collaboration & Communication: Skilled in working with cross-functional teams, with excellent written and verbal communication abilities to articulate ideas clearly and effectively.
- Leadership & Initiative: Demonstrates intellectual curiosity, self-motivation, and the ability to take ownership of tasks while driving results through collaboration and influence.
- Detail Orientation & Execution: Maintains strong organizational skills and attention to detail to ensure accurate, high-quality work and dependable follow-through.

Who You Are
- Rising seniors majoring in Computer Science, Computer Engineering, or a related field with strong academic performance are encouraged to apply. Minimum 3.0 GPA required.
- Regularly required to sit, talk, hear; use hands/fingers to touch, handle, and feel. Occasionally required to move about the workplace and reach with hands and arms. Requires close vision.
- Able to work a flexible schedule based on department and company needs.

[Company story, "About Us" and equal-opportunity text removed]

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
               Master’s CS student building Java software and full-stack applications with collaborative teams.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision
      (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, restricting access with VPC networking and security groups.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka | GitHub                        October 2026
  ∙Wrote a transactional outbox, idempotent Kafka consumers, and a reconciliation check in Java so that a payment is never
     recorded twice or lost when a message is repeated or retried.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Verified the Java payment ledger in a GitHub Actions CI workflow that runs all 94 of its tests, including integration tests
     that run against real PostgreSQL and Kafka instances in containers.

Pintos Operating System: User Programs Layer | C, x86, Operating Systems, Concurrency             May 2026
   ∙Implemented a teaching operating system’s user-programs layer in C, passing all 80 tests for program startup with
     arguments, parent-child waiting, system calls, and file handling.
  ∙Programmed the system-call interface that lets user programs open and manage files and processes through the kernel,
     supporting 13 system calls and up to 128 open files per process.

LaunchOps: Employee Onboarding Platform | Django, ReactJS, Python, JavaScript | GitHub           March 2026
   ∙Designed a Django REST and React onboarding platform with a 20-task workflow across HR, IT, and managers.
   ∙Enforced server-side checks that block forged evidence, skipped prerequisites, and duplicate submissions.
   ∙Created a live-quiz service in Go that runs as two copies behind nginx, with Redis coordinating both copies and a unique
     database index that rejects duplicate answers in live sessions.

TECHNICAL SKILLS
  ∙Languages & Databases: Java, Python, JavaScript, SQL, C, Go, PostgreSQL, MySQL
  ∙Frameworks & Libraries: Django REST Framework, Django, ReactJS, Spring Boot
   ∙Software Engineering:  SDLC,  Agile,  Operating Systems, Data  Pipelines,  Application Monitoring,  Full-Stack
     Development, REST APIs, Parallel Processing, Concurrency, Unit Testing
   ∙Tools: AWS (EC2/RDS), Redis, Apache Kafka, GitHub Actions, nginx, Linux, Git, Docker, WebSockets

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Macy's 2027 Tech Early Careers - Software Engineer role. I want to contribute to clearly defined projects for Macy's connected commerce technology, which serves millions of customers. At Data Maven, I deployed backend services on AWS EC2 and RDS with VPC networking and security groups, and automated provisioning cut setup time by about 40%.

LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, it never overdrew the account. LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side rules reject forged evidence, skipped prerequisites, and duplicate submissions. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to build dependable, well-tested software with the team at Macy's, drawing on LedgerFlow, where a GitHub Actions CI workflow runs every automated test.

Sincerely,
Jay Niketan Pathare
```

---

## 12. Audible, Inc. | Software Development Engineer

Pipeline v3.4.9a; file key Audible_Inc_Software_Development_Engineer; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Software Development Engineer
Job ID: 10539152 | Audible, Inc.
Description
At Audible, we believe stories have the power to transform lives. It's why we work with some of the world's leading creators to produce and share audio storytelling with our millions of global listeners. We are dreamers and inventors who come from a wide range of backgrounds and experiences to empower and inspire each other. Imagine your future with us.

ABOUT YOU
If you're a dedicated problem solver, this is the role for you. Identifying and overcoming challenges is at the heart of everything you do; whether it's looking ahead to our listeners problems, or analyzing every inefficiency, you thrive when you strive for perfection. We look for people who take responsibility, who feel the pride in a job well done and see every failure as an opportunity to learn. With a knowledgeable team around you, and opportunities to challenge yourself, it's a perfect environment to develop and apply your new skills.

As a Software Development Engineer, you will...
- Develop, test, and maintain software components and applications for the world's largest audiobook creator and provider
- Identify and resolve software defects through code review, log analysis, metrics examination, debugging, and other troubleshooting methods
- Write maintainable and scalable code for software components as part of an agile engineering team
- Collaborate with stakeholders to envision, design, develop, test, and launch customer-centric software that inspires and impacts users
- Apply computer science, engineering, and analysis principles to solve moderate-scale problems
- Continuously enhance testability, operational excellence (OE), and documentation for owned software components
- Handle data classification, storage, and management in accordance with company policies
- Participate in the interview process and provide mentorship to fellow engineers

ABOUT AUDIBLE
Audible is the leading producer and provider of audio storytelling. We spark listeners' imaginations, offering immersive, cinematic experiences full of inspiration and insight to enrich our customers' daily lives. We are a global company with an entrepreneurial spirit. We are dreamers and inventors who are passionate about the positive impact Audible can make for our customers and our neighbors. This spirit courses throughout Audible, supporting a culture of creativity and inclusion built on our People Principles and our mission to build more equitable communities in the cities we call home.
Basic Qualifications
- Experience programming with at least one software programming language
- Bachelor's degree or equivalent in Computer Science
Preferred Qualifications
- Experience from previous technical internship(s) or demonstrated project experience
- Experience with Cloud platforms (preferably AWS), database systems (SQL and NoSQL), AI tools for development productivity, contributing to open-source projects, and/or version control systems
- Experience delivering large, cross-functional, customer facing products

Amazon is an equal opportunity employer and does not discriminate on the basis of protected veteran status, disability, or other legally protected status.

Newark, NJ, USA - 141,900.00 USD Annually

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
              Master’s CS student building maintainable, well-tested software with code review and monitoring.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision
      (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL | GitHub           October 2026
  ∙Coded the Java payment flow so that each payment takes effect exactly once even when Kafka delivers a message more
     than once, using a transactional outbox and idempotent consumers.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Configured a GitHub Actions CI workflow that runs all 94 of the ledger’s tests, including integration tests that start real
     database and message-broker containers with Testcontainers.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
   ∙Designed RIPPLE, a Python command-line AI agent that reads a plain-English change request and predicts which files,
       tests, and regression risks it will touch before any code is written.
  ∙Wrote RIPPLE with Claude Code as a coding assistant, checking its output with RIPPLE’s 241-test suite and testing
    how the agent handles edge cases across the real code repositories it analyzes.

LaunchOps: Employee Onboarding Platform | Django, ReactJS, PostgreSQL | GitHub                 March 2026
   ∙Created a Django REST and React platform that guides new employees through a 20-task onboarding workflow shared
     by HR, IT, and managers, with an owner and prerequisites on every task.
   ∙Implemented a real-time quiz service in Go that runs as two copies behind nginx, with Redis keeping both copies in sync
     and a unique MongoDB index rejecting duplicate answers in live sessions.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: SQL, Python, Java, Go, PostgreSQL, NoSQL, MongoDB, MySQL
  ∙Frameworks & Libraries: Django REST Framework, Testcontainers, Django, ReactJS, Spring Boot
   ∙Software Engineering:  Code Review,  Debugging,  Agile,  Application Monitoring,  Unit  Testing, REST APIs,
     Event-Driven Architecture, Parallel Processing, Distributed Systems, Concurrency
   ∙Tools: Claude Code, Redis, Apache Kafka, GitHub Actions, Git, nginx, AWS (EC2/RDS), Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Software Development Engineer role at Audible, Inc. I want to develop, test, and maintain software components and applications that bring audio storytelling to Audible's listeners. At Thesis Mumbai Tech, I reviewed and merged team pull requests, mentored new hires through weekly coding rounds, and responded to heartbeat-detected production failures by restoring the affected services.

LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, it never overdrew the account. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to write maintainable and scalable code for software components at Audible, Inc., building on LedgerFlow, where a GitHub Actions CI workflow runs every automated test.

Sincerely,
Jay Niketan Pathare
```

---
