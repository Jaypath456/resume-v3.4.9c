# JUDGE PACKET: EBSCO Information Services | Software Dev Engineer I

Pipeline v3.4.9a; file key EBSCO_Information_Services_Software_Dev_Engineer_I; experience_variants_enabled=true (score the Experience section too).

## ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

## EVIDENCE INVENTORY (generated from master.json; complete record of what Jay can claim)

Anything in this inventory is verified evidence. A claim on the page that matches it is NOT a fabrication.

### Experience (frozen wording; evidence anchors give the measured facts behind each number)
- **Software Engineer Practicum | HeinOnline (University at Buffalo)** (January 2026 -- April 2026)
  - Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  - Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ~90% and pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
  - Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
  - Standardized author names by matching them to HeinOnline's 500+ authors in PostgreSQL, even when spelled differently.
  - Anchors: 47 journals / 28,167+ pages; measured extraction accuracy 90.81% (resume wording: "about 91%"); manual author-entry work cut by about 90% (estimated); worker pool sized to CPU cores minus one; on 47 journals the run took about 50 minutes sequentially and 9 minutes 15 seconds in parallel on 10 cores (about 81% reduction); confidence source values API = 100, LLM = 85, scraper = 50; Docker supported; author names standardized by matching against HeinOnline's 500+ authors stored in PostgreSQL (handles different spellings). Team of 5 for the project. In cover letters say "about 91%".
- **Software Engineer | Thesis Mumbai Tech (Startup)** (August 2024 -- August 2025)
  - Led end-to-end delivery of healthcare platform modules with a team of 4: gathered requirements in client meetings, prototyped to validate scope, and broke the finalized work into tasks.
  - Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ~2s live monitoring.
  - Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses, plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
  - Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
  - Built a heartbeat monitoring dashboard for 4 production projects, pinging each site every 5 minutes to track health.
  - Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds over their first 3 weeks and introducing them to the production projects and tech stack.
  - Anchors: client/stakeholder meetings; prototyping; "led" means technical coordination of a four-person team, not people management or hiring authority; team size is 4 (team of 4); interviewed about 20 student candidates and onboarded the new hires; SQL/relational schemas; PostgreSQL/Redis/WebSockets; WebRTC; real production deployment; heartbeat/service monitoring and responding to failures it surfaced; reviewed and merged team pull requests (cover letters, and the resume only through Experience variant I); Agile/Scrum. The earlier "~90% setup-time reduction" for Docker was an estimate, not a measurement, so it is not used on the resume. Do not infer HIPAA/FHIR/EHR, observability vendors, formal SRE/on-call, SLA ownership, or HA.
- **Cloud Engineer Intern | Data Maven Pvt Ltd** (November 2023 -- May 2024)
  - Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
  - Automated cloud resource provisioning, cutting setup time by ~40% and reducing deployment issues.
  - Anchors: AWS EC2/RDS, VPC, security groups. The 40% setup reduction is estimated, not instrumented; keep "~" and be ready to explain it in an interview.
- **Data Engineer Intern | Go Digital Technology Consulting** (June 2023 -- August 2023)
  - Developed a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data and generate automated anomaly reports for the compliance and audit team.
  - Anchors: Python, Pandas, NumPy, MySQL, SQL, ETL, cleaning/transformation/reporting.

### Projects
#### LedgerFlow — Event-Driven Payment Ledger (Individual, October 2026)
Tech: Java 25, Spring Boot, Spring MVC, Spring JDBC/JdbcClient, Kafka, PostgreSQL 17, Flyway, Maven, Docker Compose, Kubernetes, k3d/k3s/kubectl, Testcontainers, JUnit 5, AssertJ, Awaitility, Actuator/Micrometer, k6, GitHub Actions, HTML/CSS/JavaScript, YAML
- Two Spring Boot services that talk through Kafka: a payment API and a ledger that records every payment as matching debit and credit entries (double-entry accounting).
- Safeguards (transactional outbox, idempotent consumers, reconciliation check) so a payment is never recorded twice or lost when messages are repeated or retried. Supported phrase: each payment takes effect exactly once even though Kafka may deliver a message more than once.
- Overspending test: 200 simultaneous $10 requests against an account funded for exactly 50 payments. 50 went through, 150 were safely rejected, the balance ended at $0, and there was no overdraft or double posting.
- Testing: 94 automated tests, plus 27 of 27 crash-and-repeat test runs with 0 data errors (18,000 repeated messages and 14 forced service crashes in total).
- (optional) Speed: in a controlled local test at 200 payments per second, response time for the slowest 5% of requests dropped from 121 ms to 51 ms after the outbox polling interval went from 50 ms to 10 ms.
- (optional) Local Kubernetes demo (k3d, plain YAML manifests): restarting a service mid-run still completed 250 of 250 payments with 0 duplicates; a fresh cluster came up in 142 s and a replacement service was ready in about 8.9 s.
- Integration tests run against real PostgreSQL and Kafka with Testcontainers and JUnit 5 (Testcontainers is in the LedgerFlow stack).
- CI: LedgerFlow's GitHub Actions CI workflow runs all 94 tests (confirmed by Jay 2026-10-15); the integration tests run against real PostgreSQL and Kafka in containers with Testcontainers and JUnit 5.
- Boundaries (do not claim): personal/local project; not production/HA/PCI; no real bank/card network; no exactly-once Kafka delivery; no EKS/GKE/AKS/Helm/HPA/multi-node HA; CI only, not Continuous Deployment.

#### GoingOnce — Multi-Agent Car Marketplace (Team of 4, October 2026)
Tech: Python, LangGraph, Claude API, Streamlit, ReactJS/Vite, Server-Sent Events, pytest, JavaScript
- Four agents built by the team (Buy, Sell, Negotiate, Fleet) for a car-marketplace prototype; a human approves every simulated bid or listing before it goes through.
- Claude handles language and photo tasks; ordinary code handles search, pricing, and negotiation rules.
- Streamlit and React interface on top of a streaming API; 24 automated tests.
- Simulated marketplace data only.
- 1st Place in ACV Auctions + Copart challenge at UB AI for Good Hackathon Design Challenge.
- Mentor feedback shaped the Negotiate and Fleet flows.
- Jay worked on all four agents (mainly the Negotiate and Fleet agents) and built the Streamlit and React front end himself (confirmed 2026-10-15).
- Negotiate agent (repo README): each side's agent keeps a private price limit, a mediator closes the gap in rounds, then the deal closes itself: simulated escrow payment, insurance, loan payoff, title, and truck transport.
- Fleet agent (repo README): checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.
- Buy agent (repo README): checks each car's history and throws out cars with hidden salvage or odometer rollback across 310 simulated ACV and Copart listings, and pauses for dealer approval before any bid.
- Determinism (repo README): search, history checks, pricing, negotiation math and logistics are plain code; Claude is called only for language and photos, and every Claude call has a saved fallback, so results repeat.
- The HTTP API streams agent steps to the React UI as Server-Sent Events (repo README).
- Boundaries (do not claim): Four-person team project (confirmed by Jay 2026-10-15): Jay worked on all four agents (mainly Negotiate and Fleet) and built the Streamlit/React front end. Feature bullets may describe any agent (Buy, Sell, Negotiate, Fleet); the project-level bullet keeps "with a four-person team"; never imply he built the whole system alone. The 24 tests and the award stay team-scoped; not production; bids, payments, prices and transport are simulated; no real ACV/Copart integration; no FastAPI/Docker/RAG/vector DB; award stays out of project bullets.

#### RIPPLE — Agentic Change-Impact Analysis (Individual, August 2026)
Tech: Python, Python AST, Git CLI, Pydantic, pytest, LLM API, JSON/JSONL
- Command-line AI agent for Python repositories: given a plain-English description of a change, it predicts which files, tests, and regression risks the change will touch before any code is written.
- Uses 7 code-analysis tools with a cap of 25 tool calls per task; Python code checks every claim against evidence before it can enter the report.
- After the change is made, RIPPLE's own Git-diff check flags unexpected edits, missing tests, and stale callers (Jay 2026-10-15: "Added a Git-diff check that flags unexpected edits, missing tests, and stale callers"; it is RIPPLE's automated check, not manual review).
- 241 automated tests.
- Evaluation: 90 runs on 30 unseen tasks from 16 repositories. Precision 0.306, recall 0.152, F1 0.198, MRR 0.311, and 0 unsupported claims accepted into any report. On the page prefer the zero-unsupported-claims result plus at most one score, and only use the score for AI/ML JDs.
- (optional) Efficiency: about 10 tool calls and 17 model calls per run, with under 1 duplicate call per run (exact: 10.37, 16.60, 0.73).
- (optional) Separate post-change check: found all 3 kinds of planted problems on 15 tasks (100% detection) when given the correct pre-change predictions. Never present this as end-to-end performance.
- Hybrid code search over code chunks (BM25 + dense retrieval) is designed only; dense retrieval/RAG implementation and benchmark are not complete.
- Used Claude Code as a coding assistant while building RIPPLE: Claude Code helped write RIPPLE, and Jay checked its output by running RIPPLE's 241-test suite (confirmed by Jay 2026-10-15); he also used it to study how AI agents work and to probe their edge cases.
- Boundaries (do not claim): Python only; no production/adoption/bugs-prevented/productivity claims; no LangGraph/NetworkX/SQLite/MCP/Redis/Docker; do not attribute current metrics to RAG; do not claim it beat historical B3; Claude Code: say Claude Code helped write RIPPLE and Jay checked its output with RIPPLE's 241-test suite (confirmed 2026-10-15); never "RIPPLE, whose AI-generated code" (RIPPLE generates no code); give no count of corrections, no specific bug example and no productivity claim. The Git-diff check is RIPPLE's automated check (Jay 2026-10-15); never describe it as Jay reading diffs by hand.

#### LLM Application Optimization Engine (Individual, July 2026)
Tech: Python, Gemini API, Novita API, Groq API, pytest, LaTeX, pdflatex, pdftotext
- Turns a job description into a tailored one-page resume and cover letter grounded in verified evidence.
- Chooses which 3 projects to show and how many bullets each gets by checking every valid combination (dynamic programming); with 7 active projects the expected count is 105 once runtime integration is verified. Describe it as "picks the best projects"; do not hard-code the count.
- Three AI workers write bullets at the same time; typical runtime fell by about 73% (from about 11 minutes to about 3). On the page use the percentage only.
- Python checks reject unsupported technologies, ownership claims, borrowed evidence, and changed numbers before anything is shipped.
- Compiles the LaTeX and re-reads the PDF to check the layout.
- 2,500+ automated pytest tests.
- Uses Gemini as the main model provider and falls back to Novita's model API after 3 failed attempts; retries and repairs only the parts that failed.
- Uses the Groq API for assessment (confirmed by Jay, 2026-10-13); Gemini is the main generation provider and Novita's model API is the fallback.
- Boundaries (do not claim): individual project; do not claim unsupported production/org adoption; assignment count must remain catalogue-dependent. Groq API role: assessment only; do not describe it as a generation provider or claim specifics of the assessment beyond this.

#### LaunchOps — Office Onboarding & Real-Time Learning Platform (Individual, March 2026)
Tech: Python, Django REST Framework, ReactJS, Go, PostgreSQL, MongoDB (live answers only), Redis, Django Channels, Daphne, Docker Compose, WebSockets, JWT, Locust, asyncio, JavaScript
- Django REST and React onboarding platform with a 20-task workflow shared across HR, IT, manager, and employee roles; tasks have owners, prerequisites, and required evidence.
- Five lessons, each with a 3-question quiz, and an exact 70% pass rule.
- Server-side checks stop users from completing someone else's task, submitting forged evidence, skipping prerequisites, or submitting twice; unresolved support issues also block completion.
- PostgreSQL is the main durable store.
- Live-quiz service written in Go using WebSockets, running as two copies behind nginx; Redis Pub/Sub with Lua scripts coordinates the copies, and a unique MongoDB index rejects duplicate answers.
- A repeatable Django-vs-Go benchmark exists; no speed result after the Go move is verified.
- Boundaries (do not claim): no production deployment, throughput/failover claims, or Go speedup; MongoDB stores live answers only; never reuse retired-LMS metrics.

#### Pintos Operating System — User Programs Layer (Individual academic, May 2026)
Tech: C, x86, Operating Systems, Kernel Development, Concurrency, Thread Synchronization, File Systems, Process Lifecycle
- wrote the part of a teaching operating system that runs user programs, in C: starting programs with arguments, parent/child waiting and exit, 13 system calls, up to 128 open files per process, locks, and safety checks on memory access; all 80 tests pass.
- Boundaries (do not claim): C, not C++; teaching OS, not production OS work.

#### Fraud Detection using Graph Neural Networks (Academic, April 2026)
Tech: PyTorch, PyTorch Geometric, GNN, GraphSAGE, GAT, NetworkX, Pandas, scikit-learn, Focal Loss
- trained fraud models on the IEEE-CIS dataset (590,540 transactions, about 3.5% fraud, roughly 27.6 normal transactions for every fraud). The GraphSAGE graph neural network scored 0.9259 AUC-ROC (fraud F1 0.5641) against about 0.858 for a plain neural-network baseline (MLP); the GAT model did worse. On the Elliptic dataset, GraphSAGE reached about 0.988 AUC and 0.906 F1. Ablation analysis available. On the page always show AUC next to the baseline it beat.
- Graph construction (notebook): a transaction graph of 590,540 nodes and 4,122,298 edges (about 4.1M) built by linking transactions that share card (card1, card2, card1+addr1), address (addr1) and email-domain (P_emaildomain, R_emaildomain) identifiers; any identifier group larger than 50 transactions is skipped so no hub node forms.
- Edge-type ablation (notebook) over five identifier types (card1, card2, addr1, P_emaildomain, R_emaildomain) on the trained GraphSAGE model: all edges 0.9113 test AUC vs 0.8954 with no edges, so the graph adds 0.016 AUC; card1 links alone reach 0.9109 (almost all of the gain), while each other type alone stays at 0.8954-0.8955.
- Model comparison (notebook): MLP, GraphSAGE and GAT trained with focal loss and class weights, with decision thresholds tuned for F1 on validation data; test fraud F1: GraphSAGE 0.564 (0.5641), MLP 0.394 (0.3944), GAT 0.261 (0.2605).
- Leakage controls (notebook): stratified 70/15/15 train/validation/test split; the feature scaler is fit on the training split only; decision thresholds are tuned on the validation split; final results are reported on the held-out 15% test set.
- Jay built the whole notebook himself (confirmed 2026-10-15); describe it as his own work.
- Boundaries (do not claim): Jay's own work: he built 100% of the notebook himself (confirmed 2026-10-15; the course submission lists three names, but the other two worked on a different project). Describe it as Jay's own work, never as team work. Never quote a class-imbalance ratio of 41.4x (that figure includes the 1.5 fraud weight); the true ratio is about 27.6 normal transactions per fraud. The edge ablation tested each identifier type alone and all together; it did not test removing one type from the full graph.

### Additional verified facts (master.json cover_letter_evidence; usable in letters and approved Experience variants)
- collaboration product: Direct client/stakeholder meetings at Thesis Mumbai Tech.
- collaboration product: Clarified requirements and translated them into technical work.
- collaboration product: Prototyped before full implementation.
- collaboration product: Coordinated a four-person engineering team (technical coordination, not people management).
- collaboration product: Reviewed pull requests.
- collaboration product: Worked with clients on UI/UX and product requirements.
- collaboration product: Interviewed about 20 student candidates and onboarded the new hires.
- collaboration product: Agile/Scrum.
- production operations: Deployed team software to a shared production server.
- production operations: Built heartbeat/service-status monitoring.
- production operations: Responded to heartbeat-detected production failures and restored affected services.
- ai-assisted development: GitHub Copilot supported in scoped development evidence.
- ai-assisted development: Cursor and Claude Code used for repository-level development, debugging, test-driven iteration, and code review.
- coursework: Graduate Agentic AI coursework exists separately from RIPPLE; never merge coursework into RIPPLE or Professional Experience.

### Approved Experience variants (verified wording; the page may show one in place of the original line)
- A [HeinOnline (University at Buffalo)]: Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals using OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B), CrossRef API, and web scrapers.
- B [HeinOnline (University at Buffalo)]: Engineered a fault-tolerant data pipeline that processed 28k+ pages of law journals, combining CrossRef API, web scrapers, and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B).
- C [HeinOnline (University at Buffalo)]: Added confidence scoring that flags low-confidence fields for human review, and parallelized the pipeline with a CPU-based worker pool, cutting total processing time by over 80%.
- D [Thesis Mumbai Tech (Startup)]: Led a team of 4 through end-to-end delivery of healthcare platform modules: gathered requirements in client meetings, prototyped to validate scope, and broke the finalized work into tasks.
- E [Thesis Mumbai Tech (Startup)]: Gathered requirements in client meetings, prototyped to validate scope, and led a team of 4 through end-to-end delivery of healthcare platform modules.
- I [Thesis Mumbai Tech (Startup)]: Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements in client meetings, prototyped to validate scope, and reviewed and merged team pull requests. (adds the master-recorded facts: using Agile/Scrum; reviewed and merged team pull requests)
- F [Thesis Mumbai Tech (Startup)]: Developed a real-time WebSocket + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ~2s live monitoring, plus Patient Management and Consent modules on normalized schemas for 10k+ records.
- G [Thesis Mumbai Tech (Startup)]: Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
- H [Data Maven Pvt Ltd]: Deployed backend services on AWS EC2 and RDS, restricting access with VPC networking and security groups.
- J [Go Digital Technology Consulting]: Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data and generate automated anomaly reports for the compliance and audit team.

### Project evidence items (every verified fact behind the project bullets)

### Qualification facts (Jay meets these)
- Master's degree in Computer Science; Master's in Computer Science; degree in Computer Science; Computer Science degree; Bachelor's degree; Bachelor of Engineering; Information Technology degree; STEM degree; technical degree; internship experience; previous internship experience; prior internship; internship; new grad; new graduate; recent graduate; graduation in December 2026; graduating in December 2026; December 2026 graduate; production code; production-level code; production software; code reviews; AI-assisted development tools; AI coding tools; professional software engineering experience; industry experience; startup experience; early-stage startup

### Education
- {"masters": {"degree": "Master's in Computer Science", "institution": "University at Buffalo, The State University of New York, Buffalo, NY", "dates": "August 2025 -- Expected December 2026", "gpa": "3.85 / 4.0", "coursework_completion": "December 16, 2026", "graduation": "December 2026", "available_to_start_work": "February 2027, subject to approved OPT/EAD", "graduation_confirmed": "v3.4.8b (2026-10-19): Jay and the university confirmed graduation in December 2026; the work start date is February 2027. Graduation and start date are two separate facts.", "coursework": ["Agentic AI", "Machine Learning", "Deep Learning"]}, "bachelors": {"degree": "Bachelor of Engineering, Information Technology", "institution": "Vivekanand Education Society's Institute of Technology, Mumbai University, India", "dates": "August 2019 -- May 2023"}}

### Awards
- {"title": "1st Place, ACV Auctions + Copart Challenge", "context": "AI for Good Hackathon Design Challenge, UB", "date": "October 2026", "default_resume": true}
- {"title": "AWS Certified Cloud Practitioner", "date": "July 2024", "default_resume": true}

### Supported skills (Jay can back each one)
- languages_databases: Python, Java, JavaScript, HTML/CSS, C, Go, SQL, PostgreSQL, MongoDB, MySQL, NoSQL, Relational Databases
- frameworks_libraries: Django, Django REST Framework, Django Channels, ReactJS, Spring Boot, Spring MVC, Spring Kafka, Spring JDBC/JdbcClient, JUnit 5, Testcontainers, AssertJ, Awaitility, Pandas, NumPy, scikit-learn, PyTorch, PyTorch Geometric, NetworkX, Librosa, CatBoost, Pydantic, LangGraph, Streamlit, TensorFlow, Matplotlib, pytest, Vite
- ai_ml_data: LLM Integration, Prompt Engineering, Agentic AI, AI Agents, Tool Calling, Multi-Agent Systems, Human-in-the-Loop Workflows, OCR/Tesseract, Machine Learning, Deep Learning, CNNs, RNNs, GNNs, GraphSAGE, GAT, Focal Loss, Model Evaluation, Threshold Optimization, Data Preprocessing, Fuzzy Matching, LLMs, Agentic Workflows, Information Extraction, Classification
- software_engineering: REST APIs, Full-Stack Development, Backend Development, System Design, Event-Driven Architecture, Microservices, Payment Systems, Transactional Outbox, Idempotency, Idempotent Consumers, Double-Entry Ledger, Database Transactions/ACID, Row-Level Locking, Reconciliation, Fault Injection, Chaos Testing, Continuous Integration, Unit Testing, ETL, Parallel Processing, Multiprocessing/Worker Pools, Load Testing, Latency Measurement, Distributed Systems, Backtracking Algorithms, Agile, Scrum, Real-Time Monitoring, Concurrency, Thread Synchronization, Operating Systems, Kernel Development, Process Lifecycle, Static Analysis, Dependency Analysis, Change-Impact Analysis, Regression Analysis, Web Scraping, Production Deployment, Application Monitoring, Heartbeat Monitoring, Incident Response, OOP, Code Review, Data Structures, Algorithms, API Design, Software Design, Database Design, Data Pipelines, Debugging, SDLC, Data Validation, Data Cleaning, Data Transformation, Integration Testing, Data Modeling
- tools_platforms: Redis, Apache Kafka, Kafka KRaft, Maven, Flyway, k6, GitHub Actions, Spring Boot Actuator, Micrometer, AWS (EC2/RDS), Docker, Docker Compose, Kubernetes (local k3d), k3d, k3s, kubectl, Git, GitHub, GitHub Copilot, OAuth/Auth0, JWT, WebRTC, WebSockets, Daphne/ASGI, Locust, asyncio, Arduino Uno, LaTeX, pdflatex, pdftotext, Gemini API, Groq API, Claude API, CrossRef API, JSON, YAML, Cursor, Claude Code, Linux, Tableau, Power BI, nginx, VPC Networking, Novita API
- Scope rules: AWS: AWS (EC2/RDS) only; CI/CD: Use Continuous Integration only; Continuous Deployment is unsupported; Java/Spring/Kafka/Kubernetes: LedgerFlow only; LangGraph/Multi-Agent/Human-in-the-Loop/Claude API: GoingOnce only; Go/MongoDB live quiz: LaunchOps only; Production Deployment/Application Monitoring/Heartbeat Monitoring: Thesis Mumbai Tech only; Code Review: Thesis Mumbai Tech evidence anchors: reviewed and merged team pull requests; Kubernetes: Always shown as "Kubernetes (local k3d)"; never bare Kubernetes (local demo, not production); Claude API: Only when GoingOnce is on the page or the JD names LLM APIs; OAuth/Auth0: Shown when the JD names OAuth, SSO or authentication

### Unsupported skills and claims (never claimed; a page that shows one is a defect)
- RAG, retrieval-augmented generation, vector database, vector databases, vector DB, FastAPI, Fast API, Flask, HIPAA, FHIR, EHR, SRE, on-call, SLA, TypeScript, Selenium, Playwright, Jenkins, LangChain, Snowflake, Redshift, Airflow, Spark, Hadoop, Databricks, Bash, Prometheus, Grafana, ServiceNow, Salesforce, CRM, Jira, Azure DevOps, Azure Dev Ops, .NET, .Net Framework, C#, Eclipse, SQL Server, TCP, UDP, ArcGIS, arcpy, Geospatial, OpenAI, Embedded RTOS, RTOS, ARM, Ruby, Rust, Scala, Kotlin, Swift, PHP, Vue, Next.js, Node.js, Express, GraphQL, MongoDB Atlas, DynamoDB, Lambda, S3, SageMaker, ITSM, U.S. Citizenship, security clearance
- C++; FastAPI; Angular; Ruby; Apache Spark; Apache Airflow; AWS Glue; Terraform; Azure; GCP; EKS; GKE; AKS; production/high-availability Kubernetes; Helm; Kubernetes HPA/autoscaling; HIPAA implementation/compliance; FHIR; EHR integration; Continuous Deployment; cloud ML platforms beyond AWS EC2/RDS; data-warehouse/platform experience unless added; finance-industry Professional Experience

## JOB POSTING

Software Dev Engineer I

LocationUS-AL-Birmingham

ID2026-2112

Category 

Information Technology

Position Type 

Full-Time Regular

Remote 

Hybrid
EBSCO Information Services (EBSCO) delivers a fully optimized research experience, seamlessly integrated with a powerful discovery platform to support the information needs and maximize the research experience of our end-users. Headquartered in Ipswich, MA, EBSCO employs more than 2,700 people worldwide, with most embracing hybrid or remote work models. As an AI-enabled service leader, we thrive on innovation, forward-thinking strategies, and the dedication of our exceptional team. At EBSCO, we’re driven to inspire, empower and support research. Our mission is to transform lives by providing reliable and relevant information — when, where and how people need it. We’re seeking dynamic, creative individuals whose diverse perspectives will help us achieve this global, inclusive mission. Join us to help make an impact.
Your Opportunity
About the role

As a Software Engineer, you'll work on an Agile development team building, testing, and deploying great products and services for our customers. You'll help create information products and services that inform the world, advance research in traditional and emerging fields, and transform learning and education.

You'll design, develop, and demonstrate software in 1- or 2-week iterations as part of an Agile Release Train working toward SAFe Program Increments. You'll make commitments to the business and meet them as a team. You will strive for continuous improvement in knowledge and productivity and display a pattern of continual learning and a desire to broaden your software development and design skills.
What You'll Do
What you'll do

- Contribute to the architecture, design, implementation, testing, delivery, and operation of components for EBSCO products and services
- Work with product management and your team to break complex requirements into clear user stories
- Collaborate with your team to estimate features, then design, build, and test them, committing to work within an iteration
- Own quality throughout development, testing, and deployment
- Write well-engineered solutions using test-first and test-driven approaches
- Use AI tools thoughtfully across the development lifecycle, including planning, coding, testing, and code review, while applying your own judgment and verifying the results
- Provide ongoing maintenance, support, and enhancements to existing systems, including operational support for components your team owns (on-call availability as needed)
- Work alongside other engineers to raise the bar on design, coding standards, performance, security, and maintainability
- Contribute to the continuous improvement of your team, in the spirit of the Agile Manifesto and SAFe
What you'll need

- Bachelor's degree in Computer Science, MIS, Computer Engineering, or a related technical field, or equivalent experience
- 0-3 years of professional experience, including internships or co-ops, building software with C#/.NET and/or JavaScript/TypeScript
- 0-3 years of professional experience in React (Next.js a plus) and modern web development fundamentals: HTML, CSS, HTTP, JSON, RESTful web services
- Working knowledge of SQL (ANSI SQL is what matters; we use PostgreSQL and SQL Server)
- Proficiency with source control (git)
- Familiarity with using AI across the software development lifecycle: planning, development, testing, and code review. You can describe how you've used these tools, where they helped, and where you needed to check or correct their output. Coursework, internships, and personal projects all count.
About You
What sets you apart

- Professional experience with one of more JavaScript frameworks (js, React), including state management and component testing
- Experience with AWS services and cloud-based application deployment
- Hands-on experience with PostgreSQL and/or SQL Server, including query tuning and schema design
- Test-driven development and automated testing (unit, integration, contract, and end-to-end)
- DevOps experience: CI/CD pipelines, infrastructure as code, automated deployment
- Experience designing and consuming web services, including API versioning, microservices, and service-oriented patterns
- Familiarity with performance testing strategies and tools
- Prior experience on an Agile team, ideally in a SAFe environment
Competencies we look for

Technical mastery, ownership and accountability, adaptability to new technologies, Lean/Agile practices, customer focus, and putting the team ahead of self. We value drive, positive attitude, trust and respect, open communication, critical thinking, and continuous improvement.
Pay Range

USD $67,875.00 - USD $96,965.00 /Yr.

[Apply]( "Apply")


The actual salary offer will carefully consider a wide range of factors including your skills, qualifications, education, training, and experience, as well as the position’s work location.

Our Work Policy: We value the balance of remote focus and in-person connection. For all our roles not designated as onsite, candidates living within a 30-mile radius of one of our hub office locations (Ipswich, MA; Birmingham, AL; Contoocook, NH) are required to be on-site one day designated by their team for collaboration and syncs. If you reside outside of this 30-mile range, the position is considered fully remote.

EBSCO provides a generous benefits program including:

-Medical, Dental, Vision, Life and Disability Insurance and Flexible spending accounts
-Retirement Savings Plan
-Paid Parental Leave
-Holidays and Paid Time Off (PTO)
-Mentoring program
And much more! Check it out here: 

We are an equal opportunity employer and comply with all applicable federal, state, and local fair employment practices laws. We strictly prohibit and do not tolerate discrimination against employees, applicants, or any other covered persons because of race, color, sex, pregnancy status, age, national origin or ancestry, ethnicity, religion, creed, sexual orientation, gender identity, status as a veteran, and basis of disability or any other federal, state or local protected class. This policy applies to all terms and conditions of employment, including, but not limited to, hiring, training, promotion, discipline, compensation, benefits, and termination of employment. We comply with the Americans with Disabilities Act (ADA), as amended by the ADA Amendments Act, and all applicable state or local law.

## RESUME (PDF text, PyMuPDF layout-aware)

```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                     Master’s CS student building reliable backend, full-stack, and distributed systems.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision
      (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL | GitHub           October 2026
   ∙Designed a payment API and a double-entry ledger as two Spring Boot services that talk through Kafka.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Verified the Java payment ledger in a GitHub Actions CI workflow that runs all 94 of its tests, including integration tests
     that run against real PostgreSQL and Kafka instances in containers.
   ∙Validated payment correctness by forcing 14 service crashes and repeating 18,000 messages; every one of those runs ended
     with no wrong balances and no payment recorded twice in the ledger.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Created a Git-diff check that flags unexpected edits, missing tests, and stale callers.
   ∙Directed Claude Code while building RIPPLE, checking the code it generated by running RIPPLE’s 241-test suite and
      testing how the agent handles edge cases across real repositories.

LaunchOps: Employee Onboarding Platform | Django, JavaScript, PostgreSQL, ReactJS | GitHub        March 2026
   ∙Implemented a 20-task onboarding workflow in Django REST and React that coordinates HR, IT, managers, and new
     employees, with an owner, prerequisites, and required evidence on each task.
   ∙Enforced server-side rules that reject forged evidence, skipped prerequisites, duplicate submissions, and edits to other
      users’ tasks, and hold completion while support issues stay open.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY
Relevant coursework: Agentic AI, Machine Learning, Deep Learning

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: JavaScript, SQL, HTML/CSS, Java, Python, JSON, PostgreSQL, MySQL
  ∙Frameworks & Libraries: ReactJS, Django REST Framework, Django, Spring Boot
   ∙Software Engineering: Unit Testing, Code Review, SDLC, Agile, Production Deployment, REST APIs, Microservices,
     Continuous Integration, Database Design, Data Validation
   ∙Tools: Git, AWS (EC2/RDS), Apache Kafka, GitHub Actions, Claude Code, WebSockets, Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

## COVER LETTER

```text
Dear Hiring Manager,

I am applying for the Software Dev Engineer I role at EBSCO Information Services. I want to help design, build, and test the components behind EBSCO's research products, using test-first development and AI tools with careful review. At Thesis Mumbai Tech, I reviewed and merged team pull requests and restored production services after heartbeat-detected failures.

LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. A GitHub Actions CI workflow runs its 94 automated tests. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Its Git-diff check flags unexpected edits, missing tests, and stale callers. Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to design, develop, and demonstrate software at EBSCO Information Services, building on LedgerFlow, which kept every balance correct through forced crashes and repeated messages.

Sincerely,
Jay Niketan Pathare
```
