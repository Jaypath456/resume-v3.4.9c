# JUDGE PACKET: Akamai Technologies | Software Engineer

Pipeline v3.4.9a; file key Akamai_Technologies_Software_Engineer; experience_variants_enabled=true (score the Experience section too).

## ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

## EVIDENCE INVENTORY (generated from master.json; complete record of what Jay can claim)

Anything in this inventory is verified evidence. A claim on the page that matches it is NOT a fabrication.

### Experience (frozen wording; evidence anchors give the measured facts behind each number)
- **Software Engineer Practicum | HeinOnline (University at Buffalo)** (January 2026 -- April 2026)
  - Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  - Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ~90% and pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
  - Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
  - Standardized author names by matching them to HeinOnline's 500+ authors in PostgreSQL, even when spelled differently.
  - Anchors: 47 journals / 28,167+ pages; measured extraction accuracy 90.81% (resume wording: "about 91%"); manual author-entry work cut by about 90% (estimated); worker pool sized to CPU cores minus one; on 47 journals the run took about 50 minutes sequentially and 9 minutes 15 seconds in parallel on 10 cores (about 81% reduction); confidence source values API = 100, LLM = 85, scraper = 50; Docker supported; author names standardized by matching against HeinOnline's 500+ authors stored in PostgreSQL (handles different spellings). Team of 5 for the project. In cover letters say "about 91%".
- **Software Engineer | Thesis Mumbai Tech (Startup)** (August 2024 -- August 2025)
  - Led end-to-end delivery of healthcare platform modules with a team of 4: gathered requirements in client meetings, prototyped to validate scope, and broke the finalized work into tasks.
  - Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ~2s live monitoring.
  - Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses, plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
  - Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
  - Built a heartbeat monitoring dashboard for 4 production projects, pinging each site every 5 minutes to track health.
  - Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds over their first 3 weeks and introducing them to the production projects and tech stack.
  - Anchors: client/stakeholder meetings; prototyping; "led" means technical coordination of a four-person team, not people management or hiring authority; team size is 4 (team of 4); interviewed about 20 student candidates and onboarded the new hires; SQL/relational schemas; PostgreSQL/Redis/WebSockets; WebRTC; real production deployment; heartbeat/service monitoring and responding to failures it surfaced; reviewed and merged team pull requests (cover letters, and the resume only through Experience variant I); Agile/Scrum. The earlier "~90% setup-time reduction" for Docker was an estimate, not a measurement, so it is not used on the resume. Do not infer HIPAA/FHIR/EHR, observability vendors, formal SRE/on-call, SLA ownership, or HA.
- **Cloud Engineer Intern | Data Maven Pvt Ltd** (November 2023 -- May 2024)
  - Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
  - Automated cloud resource provisioning, cutting setup time by ~40% and reducing deployment issues.
  - Anchors: AWS EC2/RDS, VPC, security groups. The 40% setup reduction is estimated, not instrumented; keep "~" and be ready to explain it in an interview.
- **Data Engineer Intern | Go Digital Technology Consulting** (June 2023 -- August 2023)
  - Developed a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data and generate automated anomaly reports for the compliance and audit team.
  - Anchors: Python, Pandas, NumPy, MySQL, SQL, ETL, cleaning/transformation/reporting.

### Projects
#### LedgerFlow — Event-Driven Payment Ledger (Individual, October 2026)
Tech: Java 25, Spring Boot, Spring MVC, Spring JDBC/JdbcClient, Kafka, PostgreSQL 17, Flyway, Maven, Docker Compose, Kubernetes, k3d/k3s/kubectl, Testcontainers, JUnit 5, AssertJ, Awaitility, Actuator/Micrometer, k6, GitHub Actions, HTML/CSS/JavaScript, YAML
- Two Spring Boot services that talk through Kafka: a payment API and a ledger that records every payment as matching debit and credit entries (double-entry accounting).
- Safeguards (transactional outbox, idempotent consumers, reconciliation check) so a payment is never recorded twice or lost when messages are repeated or retried. Supported phrase: each payment takes effect exactly once even though Kafka may deliver a message more than once.
- Overspending test: 200 simultaneous $10 requests against an account funded for exactly 50 payments. 50 went through, 150 were safely rejected, the balance ended at $0, and there was no overdraft or double posting.
- Testing: 94 automated tests, plus 27 of 27 crash-and-repeat test runs with 0 data errors (18,000 repeated messages and 14 forced service crashes in total).
- (optional) Speed: in a controlled local test at 200 payments per second, response time for the slowest 5% of requests dropped from 121 ms to 51 ms after the outbox polling interval went from 50 ms to 10 ms.
- (optional) Local Kubernetes demo (k3d, plain YAML manifests): restarting a service mid-run still completed 250 of 250 payments with 0 duplicates; a fresh cluster came up in 142 s and a replacement service was ready in about 8.9 s.
- Integration tests run against real PostgreSQL and Kafka with Testcontainers and JUnit 5 (Testcontainers is in the LedgerFlow stack).
- CI: LedgerFlow's GitHub Actions CI workflow runs all 94 tests (confirmed by Jay 2026-10-15); the integration tests run against real PostgreSQL and Kafka in containers with Testcontainers and JUnit 5.
- Boundaries (do not claim): personal/local project; not production/HA/PCI; no real bank/card network; no exactly-once Kafka delivery; no EKS/GKE/AKS/Helm/HPA/multi-node HA; CI only, not Continuous Deployment.

#### GoingOnce — Multi-Agent Car Marketplace (Team of 4, October 2026)
Tech: Python, LangGraph, Claude API, Streamlit, ReactJS/Vite, Server-Sent Events, pytest, JavaScript
- Four agents built by the team (Buy, Sell, Negotiate, Fleet) for a car-marketplace prototype; a human approves every simulated bid or listing before it goes through.
- Claude handles language and photo tasks; ordinary code handles search, pricing, and negotiation rules.
- Streamlit and React interface on top of a streaming API; 24 automated tests.
- Simulated marketplace data only.
- 1st Place in ACV Auctions + Copart challenge at UB AI for Good Hackathon Design Challenge.
- Mentor feedback shaped the Negotiate and Fleet flows.
- Jay worked on all four agents (mainly the Negotiate and Fleet agents) and built the Streamlit and React front end himself (confirmed 2026-10-15).
- Negotiate agent (repo README): each side's agent keeps a private price limit, a mediator closes the gap in rounds, then the deal closes itself: simulated escrow payment, insurance, loan payoff, title, and truck transport.
- Fleet agent (repo README): checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.
- Buy agent (repo README): checks each car's history and throws out cars with hidden salvage or odometer rollback across 310 simulated ACV and Copart listings, and pauses for dealer approval before any bid.
- Determinism (repo README): search, history checks, pricing, negotiation math and logistics are plain code; Claude is called only for language and photos, and every Claude call has a saved fallback, so results repeat.
- The HTTP API streams agent steps to the React UI as Server-Sent Events (repo README).
- Boundaries (do not claim): Four-person team project (confirmed by Jay 2026-10-15): Jay worked on all four agents (mainly Negotiate and Fleet) and built the Streamlit/React front end. Feature bullets may describe any agent (Buy, Sell, Negotiate, Fleet); the project-level bullet keeps "with a four-person team"; never imply he built the whole system alone. The 24 tests and the award stay team-scoped; not production; bids, payments, prices and transport are simulated; no real ACV/Copart integration; no FastAPI/Docker/RAG/vector DB; award stays out of project bullets.

#### RIPPLE — Agentic Change-Impact Analysis (Individual, August 2026)
Tech: Python, Python AST, Git CLI, Pydantic, pytest, LLM API, JSON/JSONL
- Command-line AI agent for Python repositories: given a plain-English description of a change, it predicts which files, tests, and regression risks the change will touch before any code is written.
- Uses 7 code-analysis tools with a cap of 25 tool calls per task; Python code checks every claim against evidence before it can enter the report.
- After the change is made, RIPPLE's own Git-diff check flags unexpected edits, missing tests, and stale callers (Jay 2026-10-15: "Added a Git-diff check that flags unexpected edits, missing tests, and stale callers"; it is RIPPLE's automated check, not manual review).
- 241 automated tests.
- Evaluation: 90 runs on 30 unseen tasks from 16 repositories. Precision 0.306, recall 0.152, F1 0.198, MRR 0.311, and 0 unsupported claims accepted into any report. On the page prefer the zero-unsupported-claims result plus at most one score, and only use the score for AI/ML JDs.
- (optional) Efficiency: about 10 tool calls and 17 model calls per run, with under 1 duplicate call per run (exact: 10.37, 16.60, 0.73).
- (optional) Separate post-change check: found all 3 kinds of planted problems on 15 tasks (100% detection) when given the correct pre-change predictions. Never present this as end-to-end performance.
- Hybrid code search over code chunks (BM25 + dense retrieval) is designed only; dense retrieval/RAG implementation and benchmark are not complete.
- Used Claude Code as a coding assistant while building RIPPLE: Claude Code helped write RIPPLE, and Jay checked its output by running RIPPLE's 241-test suite (confirmed by Jay 2026-10-15); he also used it to study how AI agents work and to probe their edge cases.
- Boundaries (do not claim): Python only; no production/adoption/bugs-prevented/productivity claims; no LangGraph/NetworkX/SQLite/MCP/Redis/Docker; do not attribute current metrics to RAG; do not claim it beat historical B3; Claude Code: say Claude Code helped write RIPPLE and Jay checked its output with RIPPLE's 241-test suite (confirmed 2026-10-15); never "RIPPLE, whose AI-generated code" (RIPPLE generates no code); give no count of corrections, no specific bug example and no productivity claim. The Git-diff check is RIPPLE's automated check (Jay 2026-10-15); never describe it as Jay reading diffs by hand.

#### LLM Application Optimization Engine (Individual, July 2026)
Tech: Python, Gemini API, Novita API, Groq API, pytest, LaTeX, pdflatex, pdftotext
- Turns a job description into a tailored one-page resume and cover letter grounded in verified evidence.
- Chooses which 3 projects to show and how many bullets each gets by checking every valid combination (dynamic programming); with 7 active projects the expected count is 105 once runtime integration is verified. Describe it as "picks the best projects"; do not hard-code the count.
- Three AI workers write bullets at the same time; typical runtime fell by about 73% (from about 11 minutes to about 3). On the page use the percentage only.
- Python checks reject unsupported technologies, ownership claims, borrowed evidence, and changed numbers before anything is shipped.
- Compiles the LaTeX and re-reads the PDF to check the layout.
- 2,500+ automated pytest tests.
- Uses Gemini as the main model provider and falls back to Novita's model API after 3 failed attempts; retries and repairs only the parts that failed.
- Uses the Groq API for assessment (confirmed by Jay, 2026-10-13); Gemini is the main generation provider and Novita's model API is the fallback.
- Boundaries (do not claim): individual project; do not claim unsupported production/org adoption; assignment count must remain catalogue-dependent. Groq API role: assessment only; do not describe it as a generation provider or claim specifics of the assessment beyond this.

#### LaunchOps — Office Onboarding & Real-Time Learning Platform (Individual, March 2026)
Tech: Python, Django REST Framework, ReactJS, Go, PostgreSQL, MongoDB (live answers only), Redis, Django Channels, Daphne, Docker Compose, WebSockets, JWT, Locust, asyncio, JavaScript
- Django REST and React onboarding platform with a 20-task workflow shared across HR, IT, manager, and employee roles; tasks have owners, prerequisites, and required evidence.
- Five lessons, each with a 3-question quiz, and an exact 70% pass rule.
- Server-side checks stop users from completing someone else's task, submitting forged evidence, skipping prerequisites, or submitting twice; unresolved support issues also block completion.
- PostgreSQL is the main durable store.
- Live-quiz service written in Go using WebSockets, running as two copies behind nginx; Redis Pub/Sub with Lua scripts coordinates the copies, and a unique MongoDB index rejects duplicate answers.
- A repeatable Django-vs-Go benchmark exists; no speed result after the Go move is verified.
- Boundaries (do not claim): no production deployment, throughput/failover claims, or Go speedup; MongoDB stores live answers only; never reuse retired-LMS metrics.

#### Pintos Operating System — User Programs Layer (Individual academic, May 2026)
Tech: C, x86, Operating Systems, Kernel Development, Concurrency, Thread Synchronization, File Systems, Process Lifecycle
- wrote the part of a teaching operating system that runs user programs, in C: starting programs with arguments, parent/child waiting and exit, 13 system calls, up to 128 open files per process, locks, and safety checks on memory access; all 80 tests pass.
- Boundaries (do not claim): C, not C++; teaching OS, not production OS work.

#### Fraud Detection using Graph Neural Networks (Academic, April 2026)
Tech: PyTorch, PyTorch Geometric, GNN, GraphSAGE, GAT, NetworkX, Pandas, scikit-learn, Focal Loss
- trained fraud models on the IEEE-CIS dataset (590,540 transactions, about 3.5% fraud, roughly 27.6 normal transactions for every fraud). The GraphSAGE graph neural network scored 0.9259 AUC-ROC (fraud F1 0.5641) against about 0.858 for a plain neural-network baseline (MLP); the GAT model did worse. On the Elliptic dataset, GraphSAGE reached about 0.988 AUC and 0.906 F1. Ablation analysis available. On the page always show AUC next to the baseline it beat.
- Graph construction (notebook): a transaction graph of 590,540 nodes and 4,122,298 edges (about 4.1M) built by linking transactions that share card (card1, card2, card1+addr1), address (addr1) and email-domain (P_emaildomain, R_emaildomain) identifiers; any identifier group larger than 50 transactions is skipped so no hub node forms.
- Edge-type ablation (notebook) over five identifier types (card1, card2, addr1, P_emaildomain, R_emaildomain) on the trained GraphSAGE model: all edges 0.9113 test AUC vs 0.8954 with no edges, so the graph adds 0.016 AUC; card1 links alone reach 0.9109 (almost all of the gain), while each other type alone stays at 0.8954-0.8955.
- Model comparison (notebook): MLP, GraphSAGE and GAT trained with focal loss and class weights, with decision thresholds tuned for F1 on validation data; test fraud F1: GraphSAGE 0.564 (0.5641), MLP 0.394 (0.3944), GAT 0.261 (0.2605).
- Leakage controls (notebook): stratified 70/15/15 train/validation/test split; the feature scaler is fit on the training split only; decision thresholds are tuned on the validation split; final results are reported on the held-out 15% test set.
- Jay built the whole notebook himself (confirmed 2026-10-15); describe it as his own work.
- Boundaries (do not claim): Jay's own work: he built 100% of the notebook himself (confirmed 2026-10-15; the course submission lists three names, but the other two worked on a different project). Describe it as Jay's own work, never as team work. Never quote a class-imbalance ratio of 41.4x (that figure includes the 1.5 fraud weight); the true ratio is about 27.6 normal transactions per fraud. The edge ablation tested each identifier type alone and all together; it did not test removing one type from the full graph.

### Additional verified facts (master.json cover_letter_evidence; usable in letters and approved Experience variants)
- collaboration product: Direct client/stakeholder meetings at Thesis Mumbai Tech.
- collaboration product: Clarified requirements and translated them into technical work.
- collaboration product: Prototyped before full implementation.
- collaboration product: Coordinated a four-person engineering team (technical coordination, not people management).
- collaboration product: Reviewed pull requests.
- collaboration product: Worked with clients on UI/UX and product requirements.
- collaboration product: Interviewed about 20 student candidates and onboarded the new hires.
- collaboration product: Agile/Scrum.
- production operations: Deployed team software to a shared production server.
- production operations: Built heartbeat/service-status monitoring.
- production operations: Responded to heartbeat-detected production failures and restored affected services.
- ai-assisted development: GitHub Copilot supported in scoped development evidence.
- ai-assisted development: Cursor and Claude Code used for repository-level development, debugging, test-driven iteration, and code review.
- coursework: Graduate Agentic AI coursework exists separately from RIPPLE; never merge coursework into RIPPLE or Professional Experience.

### Approved Experience variants (verified wording; the page may show one in place of the original line)
- A [HeinOnline (University at Buffalo)]: Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals using OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B), CrossRef API, and web scrapers.
- B [HeinOnline (University at Buffalo)]: Engineered a fault-tolerant data pipeline that processed 28k+ pages of law journals, combining CrossRef API, web scrapers, and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B).
- C [HeinOnline (University at Buffalo)]: Added confidence scoring that flags low-confidence fields for human review, and parallelized the pipeline with a CPU-based worker pool, cutting total processing time by over 80%.
- D [Thesis Mumbai Tech (Startup)]: Led a team of 4 through end-to-end delivery of healthcare platform modules: gathered requirements in client meetings, prototyped to validate scope, and broke the finalized work into tasks.
- E [Thesis Mumbai Tech (Startup)]: Gathered requirements in client meetings, prototyped to validate scope, and led a team of 4 through end-to-end delivery of healthcare platform modules.
- I [Thesis Mumbai Tech (Startup)]: Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements in client meetings, prototyped to validate scope, and reviewed and merged team pull requests. (adds the master-recorded facts: using Agile/Scrum; reviewed and merged team pull requests)
- F [Thesis Mumbai Tech (Startup)]: Developed a real-time WebSocket + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ~2s live monitoring, plus Patient Management and Consent modules on normalized schemas for 10k+ records.
- G [Thesis Mumbai Tech (Startup)]: Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
- H [Data Maven Pvt Ltd]: Deployed backend services on AWS EC2 and RDS, restricting access with VPC networking and security groups.
- J [Go Digital Technology Consulting]: Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data and generate automated anomaly reports for the compliance and audit team.

### Project evidence items (every verified fact behind the project bullets)

### Qualification facts (Jay meets these)
- Master's degree in Computer Science; Master's in Computer Science; degree in Computer Science; Computer Science degree; Bachelor's degree; Bachelor of Engineering; Information Technology degree; STEM degree; technical degree; internship experience; previous internship experience; prior internship; internship; new grad; new graduate; recent graduate; graduation in December 2026; graduating in December 2026; December 2026 graduate; production code; production-level code; production software; code reviews; AI-assisted development tools; AI coding tools; professional software engineering experience; industry experience; startup experience; early-stage startup

### Education
- {"masters": {"degree": "Master's in Computer Science", "institution": "University at Buffalo, The State University of New York, Buffalo, NY", "dates": "August 2025 -- Expected December 2026", "gpa": "3.85 / 4.0", "coursework_completion": "December 16, 2026", "graduation": "December 2026", "available_to_start_work": "February 2027, subject to approved OPT/EAD", "graduation_confirmed": "v3.4.8b (2026-10-19): Jay and the university confirmed graduation in December 2026; the work start date is February 2027. Graduation and start date are two separate facts.", "coursework": ["Agentic AI", "Machine Learning", "Deep Learning"]}, "bachelors": {"degree": "Bachelor of Engineering, Information Technology", "institution": "Vivekanand Education Society's Institute of Technology, Mumbai University, India", "dates": "August 2019 -- May 2023"}}

### Awards
- {"title": "1st Place, ACV Auctions + Copart Challenge", "context": "AI for Good Hackathon Design Challenge, UB", "date": "October 2026", "default_resume": true}
- {"title": "AWS Certified Cloud Practitioner", "date": "July 2024", "default_resume": true}

### Supported skills (Jay can back each one)
- languages_databases: Python, Java, JavaScript, HTML/CSS, C, Go, SQL, PostgreSQL, MongoDB, MySQL, NoSQL, Relational Databases
- frameworks_libraries: Django, Django REST Framework, Django Channels, ReactJS, Spring Boot, Spring MVC, Spring Kafka, Spring JDBC/JdbcClient, JUnit 5, Testcontainers, AssertJ, Awaitility, Pandas, NumPy, scikit-learn, PyTorch, PyTorch Geometric, NetworkX, Librosa, CatBoost, Pydantic, LangGraph, Streamlit, TensorFlow, Matplotlib, pytest, Vite
- ai_ml_data: LLM Integration, Prompt Engineering, Agentic AI, AI Agents, Tool Calling, Multi-Agent Systems, Human-in-the-Loop Workflows, OCR/Tesseract, Machine Learning, Deep Learning, CNNs, RNNs, GNNs, GraphSAGE, GAT, Focal Loss, Model Evaluation, Threshold Optimization, Data Preprocessing, Fuzzy Matching, LLMs, Agentic Workflows, Information Extraction, Classification
- software_engineering: REST APIs, Full-Stack Development, Backend Development, System Design, Event-Driven Architecture, Microservices, Payment Systems, Transactional Outbox, Idempotency, Idempotent Consumers, Double-Entry Ledger, Database Transactions/ACID, Row-Level Locking, Reconciliation, Fault Injection, Chaos Testing, Continuous Integration, Unit Testing, ETL, Parallel Processing, Multiprocessing/Worker Pools, Load Testing, Latency Measurement, Distributed Systems, Backtracking Algorithms, Agile, Scrum, Real-Time Monitoring, Concurrency, Thread Synchronization, Operating Systems, Kernel Development, Process Lifecycle, Static Analysis, Dependency Analysis, Change-Impact Analysis, Regression Analysis, Web Scraping, Production Deployment, Application Monitoring, Heartbeat Monitoring, Incident Response, OOP, Code Review, Data Structures, Algorithms, API Design, Software Design, Database Design, Data Pipelines, Debugging, SDLC, Data Validation, Data Cleaning, Data Transformation, Integration Testing, Data Modeling
- tools_platforms: Redis, Apache Kafka, Kafka KRaft, Maven, Flyway, k6, GitHub Actions, Spring Boot Actuator, Micrometer, AWS (EC2/RDS), Docker, Docker Compose, Kubernetes (local k3d), k3d, k3s, kubectl, Git, GitHub, GitHub Copilot, OAuth/Auth0, JWT, WebRTC, WebSockets, Daphne/ASGI, Locust, asyncio, Arduino Uno, LaTeX, pdflatex, pdftotext, Gemini API, Groq API, Claude API, CrossRef API, JSON, YAML, Cursor, Claude Code, Linux, Tableau, Power BI, nginx, VPC Networking, Novita API
- Scope rules: AWS: AWS (EC2/RDS) only; CI/CD: Use Continuous Integration only; Continuous Deployment is unsupported; Java/Spring/Kafka/Kubernetes: LedgerFlow only; LangGraph/Multi-Agent/Human-in-the-Loop/Claude API: GoingOnce only; Go/MongoDB live quiz: LaunchOps only; Production Deployment/Application Monitoring/Heartbeat Monitoring: Thesis Mumbai Tech only; Code Review: Thesis Mumbai Tech evidence anchors: reviewed and merged team pull requests; Kubernetes: Always shown as "Kubernetes (local k3d)"; never bare Kubernetes (local demo, not production); Claude API: Only when GoingOnce is on the page or the JD names LLM APIs; OAuth/Auth0: Shown when the JD names OAuth, SSO or authentication

### Unsupported skills and claims (never claimed; a page that shows one is a defect)
- RAG, retrieval-augmented generation, vector database, vector databases, vector DB, FastAPI, Fast API, Flask, HIPAA, FHIR, EHR, SRE, on-call, SLA, TypeScript, Selenium, Playwright, Jenkins, LangChain, Snowflake, Redshift, Airflow, Spark, Hadoop, Databricks, Bash, Prometheus, Grafana, ServiceNow, Salesforce, CRM, Jira, Azure DevOps, Azure Dev Ops, .NET, .Net Framework, C#, Eclipse, SQL Server, TCP, UDP, ArcGIS, arcpy, Geospatial, OpenAI, Embedded RTOS, RTOS, ARM, Ruby, Rust, Scala, Kotlin, Swift, PHP, Vue, Next.js, Node.js, Express, GraphQL, MongoDB Atlas, DynamoDB, Lambda, S3, SageMaker, ITSM, U.S. Citizenship, security clearance
- C++; FastAPI; Angular; Ruby; Apache Spark; Apache Airflow; AWS Glue; Terraform; Azure; GCP; EKS; GKE; AKS; production/high-availability Kubernetes; Helm; Kubernetes HPA/autoscaling; HIPAA implementation/compliance; FHIR; EHR integration; Continuous Deployment; cloud ML platforms beyond AWS EC2/RDS; data-warehouse/platform experience unless added; finance-industry Professional Experience

## JOB POSTING

[View More Jobs]( "View More Jobs")
Software Engineer

United States (Remote)
Job Description

Do you want to build customer-facing features for a globally distributed AI platform?

Are you eager to learn cloud platform development while working on cutting-edge AI infrastructure?

Join the Akamai Inference Cloud Team!

The Akamai Inference Cloud team is part of Akamai's Cloud Technology Group. We design, implement, and operate AI platforms enabling customers to run inference models and developers to create applications with unmatched performance, compliance, and economics. The Control Plane & Developer Experience team owns the API platform, developer tools, security, authentication, billing integration, and user-facing interfaces empowering developers.

Partner with the best

As a Software Engineer I on the Control Plane & Developer Experience team, you will build and maintain customer-facing platform features across the Akamai Inference Cloud control plane. You'll work alongside experienced engineers and gain hands-on exposure to API platform development, cloud services, and AI infrastructure.

\#AIC

As a Software Engineer, you will be responsible for:

- Developing and maintaining services for control plane including API endpoints, configuration management, and platform workflows
- Building customer-facing features that enable users to configure, manage, and interact with inference platform resources
- Writing well-tested, well-documented code and participating in code reviews to maintain engineering standards
- Collaborating with engineering and product teams to translate requirements into reliable platform capabilities
- Contributing to platform reliability through monitoring, debugging, and operational support of control plane services

Do what you love

To be successful in this role you will:

- Have a Bachelor's/Master's degree in Computer Science or its equivalent
- Demonstrate proficiency in at least one programming language such as Python, Go, or JavaScript
- Have familiarity with RESTful APIs and basic cloud computing concepts
- Show familiarity with Git, GitHub workflows, and modern software development practices
- Demonstrate curiosity and a desire to learn cloud platform and API development patterns
- Possess solid problem-solving skills and the ability to work effectively in a collaborative engineering team

Work in a way that works for you

FlexBase, Akamai's Global Flexible Working Program, is based on the principles that are helping us create the best workplace in the world. When our colleagues said that flexible working was important to them, we listened. We also know flexible working is important to many of the incredible people considering joining Akamai. FlexBase, gives 95% of employees the choice to work from their home, their office, or both (in the country advertised). This permanent workplace flexibility program is consistent and fair globally, to help us find incredible talent, virtually anywhere. We are happy to discuss working options for this role and encourage you to speak with your recruiter in more detail when you apply.

Learn what makes Akamai a great place to work



| Connect with us on social and see what life at Akamai is like! | image (image) image (image) image (image) image (image) image (image) image (image) |
| -------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |



We power and protect life online, by solving the toughest challenges, together.

At Akamai, we're curious, innovative, collaborative and tenacious. We celebrate diversity of thought and we hold an unwavering belief that we can make a meaningful difference. Our teams use their global perspectives to put customers at the forefront of everything they do, so if you are people-centric, you'll thrive here.

Working for you

At Akamai, we will provide you with opportunities to grow, flourish, and achieve great things. Our benefit options are designed to meet your individual needs for today and in the future. We provide benefits surrounding all aspects of your life:

- Your health
- Your finances
- Your family
- Your time at work
- Your time pursuing other endeavors

Our benefit plan options are designed to meet your individual needs and budget, both today and in the future.

About us

Akamai powers and protects life online. Leading companies worldwide choose Akamai to build, deliver, and secure their digital experiences helping billions of people live, work, and play every day. With the world's most distributed compute platform from cloud to edge we make it easy for customers to develop and run applications, while we keep experiences closer to users and threats farther away.

Join us

Are you seeking an opportunity to make a real difference in a company with a global reach and exciting services and clients? Come join us and grow with a team of people who will energize and inspire you!

Akamai Technologies is an Affirmative Action, Equal Opportunity Employer that values the strength that diversity brings to the workplace. All qualified applicants will receive consideration for employment and will not be discriminated against on the basis of gender, gender identity, sexual orientation, race/ethnicity, protected veteran status, disability, or other protected group status.

If no date is displayed, applications are being accepted on an ongoing basis until the job is filled.

Compensation

Akamai is committed to fair and equitable compensation practices. For US based candidates only - the base salary for this position ranges from $75,700 - $136,300/year; a candidate’s salary is determined by various factors including, but not limited to, relevant work experience, skills, certifications and location. Compensation for candidates outside the US will vary. The compensation package may also include incentive compensation opportunities in the form of annual bonus or incentives, equity awards and an Employee Stock Purchase Plan (ESPP). Akamai provides industry-leading benefits including healthcare, 401K savings plan, company holidays, vacation (in the form of PTO), sick time, family friendly benefits including parental leave and an employee assistance program including a focus on mental and financial wellness; Eligibility requirements apply.

## RESUME (PDF text, PyMuPDF layout-aware)

```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
             Master’s CS student building backend APIs, event-driven services, and reliable distributed systems.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals using OCR/LLM
      vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B), CrossRef API, and web scrapers.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
  ∙Added confidence scoring that flags low-confidence fields for human review, and parallelized the pipeline with a CPU-based
     worker pool, cutting total processing time by over 80%.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, restricting access with VPC networking and security groups.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka | GitHub                        October 2026
  ∙Coded the Java payment flow so that each payment takes effect exactly once even when Kafka delivers a message more
     than once, using a transactional outbox and idempotent consumers.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Configured a GitHub Actions CI workflow that runs all 94 of the ledger’s tests, including integration tests that start real
     database and message-broker containers with Testcontainers.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Created a Git-diff check that flags unexpected edits, missing tests, and stale callers.
   ∙Directed Claude Code while building RIPPLE, checking the code it generated by running RIPPLE’s 241-test suite and
      testing how the agent handles edge cases across real repositories.

LaunchOps: Employee Onboarding Platform | Django, Python, Go, JavaScript | GitHub               March 2026
   ∙Designed a Django REST and React onboarding platform with a 20-task workflow across HR, IT, and managers.
   ∙Implemented a live-quiz service in Go that runs as two copies behind nginx, kept in sync through Redis.
   ∙Enforced server-side rules that reject forged evidence, skipped prerequisites, duplicate submissions, and edits to other
      users’ tasks, and hold completion while support issues stay open.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, JavaScript, Go, Java, SQL, PostgreSQL, MySQL
  ∙Frameworks & Libraries: Django REST Framework, Django, Spring Boot, Testcontainers, ReactJS
   ∙Software Engineering: REST APIs, Unit Testing, Code Review, Application Monitoring, Debugging, Concurrency,
      Parallel Processing, Backend Development, Distributed Systems, Event-Driven Architecture
   ∙Tools: Git, OAuth/Auth0, Redis, Apache Kafka, GitHub Actions, Claude Code, nginx, GitHub, Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

## COVER LETTER

```text
Dear Hiring Manager,

I am applying for the Software Engineer role at Akamai Technologies. I want to help build the API endpoints, configuration management, and customer-facing features that developers use on the Akamai Inference Cloud. At Thesis Mumbai Tech, I led delivery of healthcare platform modules with a team of 4, gathering requirements in client meetings and prototyping to validate scope.

LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. A GitHub Actions CI workflow runs its 94 automated tests. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Its Git-diff check flags unexpected edits, missing tests, and stale callers. Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite. I graduate in December 2026 and can start work in February 2027. I want to build and maintain customer-facing platform features at Akamai Technologies, drawing on the real-time IoT pipeline I built at Thesis Mumbai Tech.

Sincerely,
Jay Niketan Pathare
```
