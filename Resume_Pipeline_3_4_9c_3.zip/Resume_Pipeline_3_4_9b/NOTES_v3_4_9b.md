# NOTES v3.4.9b (2026-10-20)

Format build from Resume_Pipeline_3_4_9a.zip, following General_CV_reference.tex. Deliverables: Resume_Pipeline_3_4_9b.zip,
this file, format_report.md (sections 0-2), golden_report.md.

## Result
- 128 fixtures: 126 built and PASS on one US Letter page in Times with at least 10pt spare (min 10.8pt), plus the 2
  expected stops (fonzi, cisco_no_title).
- diff_gate_v349b.py: PASS, 0 failing. Letters, tracker rows and outreach are byte-identical to v3.4.9a on every fixture;
  ranking, Projects Used and Fit identical; resume text differs only in the header, Skills lines, the two reference
  trims, 2 reworded variants (on 9 pages) and bullets that left 13 pages for fit (listed in format_report.md 2).
- Flags on twice: identical. Five new flags off: identical to baseline_v349a (128 fixtures).
- golden_check 11/12, same single failure as 9a (ebsco_sde1 rank1 LedgerFlow). score_all tuned 9.97, holdouts
  9.80 / 9.97 (as 9a). audit_v344 10.3% (13/126 role-family closings, as 9a: still over the 10% line, no worse).
- bank_check on Letter: 120 variants, 0 failing; Experience 10/10.
- Selftests v341 to v349b: all pass (14 files). Flags on after the final rehash identical to the earlier flags-on run.

## Decisions
- Card 1 (stop-gate): tail floor 0.30 on Letter, margins kept 0.3in.
- Card 2: "Reference trims" (short Interviewed line, AWS certification line not shown), flag letter_trims_v349b.

## Assumptions (no question asked)
1. Fit order when a Letter page runs over: same bullets as the v3.4.9a page, then drop coursework, then drop one bullet
   slot from the lowest-ranked project with two or more, trying each slot until the letter stays byte-identical. This
   keeps gate 1 (letters identical) on every page. The pipeline builds the v3.4.9a page first as the reference, so a run
   takes about twice as long.
2. vindexa is the one page where no rank #2 / #3 trim kept the letter, so rank #1 (GoingOnce) gave up a slot (2/2/2).
3. Skills: 5 pages (amplitude, bti, inspire11, nvidia_ai_cloud, vindexa) show all five categories and need a 6th line
   for required / must / high terms that no bullet shows; dropping them would fail the ATS check. Must / high terms that a
   bullet already shows may leave Skills. umich leaves out "Full-Stack Development" (posting-named, not priority), listed in
   the "Skills full" note (score_all R-0.25).
4. Bold covers numbers with units or nouns ("28k+ pages", "about 91%"), never years, "only N", caps or schedules.
5. Only 2 variants needed rewording after the 0.30 floor, so section 1 shows both instead of 15 samples.
6. Validation tools changed (not Sources): score_all.py ignores bold in Experience lines and accepts the short
   Interviewed line; older selftests pin the five new flags off where they compare A4 outputs.

## Open for Jay
Paste the new instructions (7,593 characters) and re-upload all 7 Sources (6 changed). Expect hash PASS: pipeline
76c1c6ea | master d4e92491 | bank 914805e9 | template 137af61b | context md d883cfa0.
