# Resume pipeline v3.4.8b: notes

Built 2026-10-19 from Resume_Pipeline_3_4_8a.zip. **One fact change**, confirmed by Jay and the university: Jay graduates in
**December 2026** (was February 2027) and can start work in **February 2027** (unchanged). Graduation and start date are now
two separate facts everywhere: master.json, the context .md, the resume, the letters, eligibility / Timing notes and the
instructions. One switch, master.json `v347_flags.graduation_dec2026_v348` (default true); off = byte-identical to v3.4.8a.
The code change is in CHANGES.md; every changed output line is in DIFF_REPORT_v348b.md.

## What Jay needs to do

1. **Sources: re-upload 4 of the 7 files.** Changed: `resume_pipeline_v3_2.py`, `master.json`, `Resume_Template_CURRENT.tex`
   (the Education date line only), `Master_Resume_Context_LEAN_CURRENT_v3_2.md`. Unchanged: `bullet_bank.json`,
   `plan_template.json`, `bank_check.py`. Uploading all 7 is fine.
2. **Project instructions: paste the new `2_PROJECT_INSTRUCTIONS_paste.txt`** (7,581 characters; limit 7,600). Changed: the
   version, step 4d "(Jay graduates December 2026 and starts work February 2027)", and the hash lock.
3. **Tracker sheet: nothing new.** Rows you already logged keep their old Blockers wording; new rows say "graduation window
   excludes December 2026" / "enrollment required past December 2026".
4. **LinkedIn / anything outside the pipeline:** the pipeline cannot change your LinkedIn education date; set it to Expected
   December 2026 yourself if it still says February 2027.

## Hash lock

| File | sha256 |
|---|---|
| resume_pipeline_v3_2.py | 31820fef… (full value in the instructions) |
| master.json | 577bdd6d… |
| bullet_bank.json | d56f0743… (unchanged) |
| Resume_Template_CURRENT.tex | dc281778… |
| Master_Resume_Context_LEAN_CURRENT_v3_2.md | c7d271da… |
| plan_template.json | 4358f1e0… (unchanged) |
| bank_check.py | 81b28185… (unchanged) |

## Acceptance

| Check | Result |
|---|---|
| Baseline | `3_validation/baseline_v348a/`: all 124 fixtures on the unmodified 8a Sources, saved before any change |
| Determinism (8a code) | IDENTICAL: two 8a runs |
| Predictions | `predict_v348b.py` (restates the date rules without any 8b code) wrote `predicted_changes_v348b.json` from the baseline before the code changed: Education line and logistics sentence on 122, refit of harvey and monti at the 200-word cap, eligibility / Notes on 11 fixtures, possible Fit change on 4, the ATS graduation term on 10, no layout change |
| Diff gate | **PASS** (`diff_gate_v348b.py`): 745 changed lines in 124 fixtures, 0 unpredicted, 0 guard failures. 126 lines matched only one of three **documented amendments** written after an 8-fixture smoke run and before the full run (see below); the predictions file itself was not edited |
| Gate guard | G1 resume: only the Education date line; G2 letter: only the logistics sentence (plus harvey / monti refit), longest letter 200 words; G3 report.json: only timing / eligibility / Notes / Fit / ATS-graduation fields, letter word counts and the template-keyed skills hash; G4 tracker: only Fit / Blockers, Fit only where eligibility changed; G5 layout (new-grad, Go Digital drop) and outreach identical on all 124; G6 no February 2027 graduation anywhere: all **held** |
| Flag off | IDENTICAL to baseline_v348a on all 124 fixtures (version label only on the two stops) |
| Determinism (8b code) | IDENTICAL: two full 8b runs |
| Fixtures | 124: 122 pass + 2 expected stops (fonzi, cisco_no_title); every resume one page |
| score_all | 10.00 / 10.00 on every tuned group (v340_original 53, v341_tune 36, v342_new 6, v343_new 2, v344_new 2, v345_new 1, v347_new 4) |
| Holdouts (20, never tuned) | resume 9.85, letter 9.97, unchanged; below 9.5: acme_cloud, twitch, linkedin_ai (as before) |
| audit_v344 | PASS: 122 built, 11 fallback closings (9.0%), longest closing 30 words, longest letter 200 words |
| bank_check | 113/113 ok, 10/10 Experience variants ok |
| selftests | all pass: v341 28, v342 26, v343 37, v344 55, v345 59, v346 54, v347a 65, v347b 94, v347c 39, v348a 163, v348b 80 (new) |
| Grep | `3_validation/GREP_PROOF_v348b.txt`: 0 of 122 resumes contain "February 2027"; every letter sentence with it is one of the two new logistics sentences; every report / tracker phrase with it is a start date |
| Names defined more than once | 61 (unchanged) |

### The three amendments (honest record)

The smoke run on 8 fixtures showed three kinds of lines the frozen predictions did not cover. They are listed in
`predicted_changes_v348b_amendments.json`, tagged "amendment" in DIFF_REPORT_v348b.md, and nothing else was loosened:

- **A1** `skill_fit_cache.skills_text_hash` changes on all 122 built fixtures: the hash includes the template sha256, and the
  Education line lives in the template. With the flag off the hash uses the 8a template hash (that is how flag-off stays identical).
- **A2** tracker "Fit (High/Medium/Low)" on brightpath_ml and klaviyo: both were predicted for a Fit change, but the pattern
  said "Fit:" (a typo in the predictor).
- **A3** `plan_resolved_fields.jd_requirements[*].supported` on appian_sec and figure: both were predicted for a graduation-term
  flip; the predictor's field pattern missed this copy of the requirement.

## Fixtures whose Fit, blockers, Notes or layout changed, and why

No layout changed (new-grad on/off and the Go Digital drop are identical on all 124: the trigger already accepts a 2026 or 2027
class). Fit changed on two fixtures.

| Fixture | Group | Posting line | Before (8a) | After (8b) |
|---|---|---|---|---|
| brightpath_ml | v341_tune | "MS in Computer Science, Machine Learning, or a related field, graduating December 2026 - June 2027" | graduation_window blocker, **Fit Low**, tracker "graduation window excludes February 2027" | no blocker, **Fit Medium**, Blockers blank |
| klaviyo | v340_original | "Pursuing an advanced degree ... Graduating in December 2026 or May/June 2027" | graduation_window blocker, **Fit Low** | no blocker, **Fit Medium**, Blockers blank |
| macys | v342_new | title "Macy's 2027 Tech Early Careers" + "The Macy's Technology Summer Internship Program" | student_audience only | **+ enrollment_required** (a 2027 internship starts after the December 2026 graduation); Fit stays Low; tracker adds "enrollment required past December 2026" |
| figure | v342_new | "Student eligibility: Graduating May 2027 - May 2027" | graduation_window (reason: February 2027); ATS "graduation in 2027" supported | same blockers, reasons say December 2026; the ATS term becomes "graduation window" (unsupported: May 2027 is five months after December 2026); Fit stays Low |
| appian_sec | v340_original | "Information Security Application Engineer (2026 Graduates)"; "graduating in 2026" | Timing note "targets 2026 graduates; the candidate graduates in February 2027"; ATS "graduation window" gap | Timing note "targets 2026 graduates, and a 2026 hiring cycle may start before February 2027. Graduates December 2026; available to start February 2027 (subject to OPT/EAD approval)."; the graduation line is now met (fit_input High), effective Fit stays Medium |
| commure | v340_original | "Software Engineer (Summer 2026 New Grad)" | Timing note (February 2027 graduation) | Timing note as appian_sec; Fit stays Low |
| nvidia_ai_cloud | v341_tune | "New College Grad 2026" | same | same as commure |
| nvidia_devtech | v340_original | "New College Grad 2026" | same | same as commure |
| harvey | v341_tune | "starting in January 2027 and beyond" | start_date Timing note "before the candidate's February 2027 graduation; OPT work can begin only after graduation and EAD approval" | "Timing check: the posting mentions a start before February 2027. Graduates December 2026; available to start February 2027 (subject to OPT/EAD approval)." Fit stays High |
| nvidia | v340_original | "Must be actively enrolled ... for the full duration of the internship" | enrollment_required, "enrollment required past February 2027" | same blocker, reason "requires enrollment during or after it; Jay graduates in December 2026 and can start work in February 2027", label "past December 2026"; Fit stays Low |
| cisco_no_title (stop) | v343_new | "Bachelor's with 3+ years or a Master's with 2+ years" | degree-years note "Jay's Master's (conferred February 2027)" | "Jay's Master's (expected December 2026)" |

ATS term only (no Fit, blocker or Notes change): atoms, fulfillment, harvey, robot_sdet, and the holdouts meridian_sw and
sparkline: "graduation in 2027" became "graduation in December 2026" (still met). brightpath_ml, klaviyo and appian_sec carry
the same rename.

Letters refit at the 200-word cap (both full-time letters were exactly 200 words; the new sentence is one word longer):

- **harvey**: closing "I want to build the AI-powered systems that serve the world's leading law firms and enterprises at Harvey, ..." ->
  "I want to build the AI-powered systems at Harvey, drawing on RIPPLE, whose Git-diff check flags missing tests and stale callers." (200 -> 192 words)
- **monti**: closing "I want to help debug issues across systems at Monti, ..." -> "I want to help debug issues at Monti, drawing on the heartbeat
  monitor I built at Thesis Mumbai Tech, where I restored services after detected failures." (200 -> 199 words)

## Before and after on the four real postings

All four are full-time letters; nothing else on the page or in the letter changed.

| Posting | Education line before | Education line after | Letter sentence before | Letter sentence after |
|---|---|---|---|---|
| zoro_fullstack | August 2025 -- Expected February 2027 | August 2025 -- Expected December 2026 | I graduate in February 2027 and can start work that month. | I graduate in December 2026 and can start work in February 2027. |
| alml_engineer | August 2025 -- Expected February 2027 | August 2025 -- Expected December 2026 | I graduate in February 2027 and can start work that month. | I graduate in December 2026 and can start work in February 2027. |
| ust_software_engineer | August 2025 -- Expected February 2027 | August 2025 -- Expected December 2026 | I graduate in February 2027 and can start work that month. | I graduate in December 2026 and can start work in February 2027. |
| meritore_capgemini | August 2025 -- Expected February 2027 | August 2025 -- Expected December 2026 | I graduate in February 2027 and can start work that month. | I graduate in December 2026 and can start work in February 2027. |

Letter lengths: zoro 177 -> 178, alml 175 -> 176, ust 191 -> 192, meritore 193 -> 194 words. Internship letters (nvidia and
one other) use "My Master's in Computer Science at the University at Buffalo is expected in December 2026, and I can start work in
February 2027." (one word shorter than before).

## Assumptions (Jay asked for none to be asked)

1. **Graduation-window tolerance:** one month either side, the tolerance the v3.4.2 single-date check already used. So "December
   2026 - June 2027", "Winter 2026 - Spring 2027", "December 2026 or May/June 2027", "graduating in 2026" and a bare "2027" include
   Jay; "May 2027 - May 2027" and "graduating in May 2027" do not. Seasons map to their usual graduation month (spring May,
   summer August, fall / winter December).
2. **2026-class postings** (appian_sec, commure, the two NVIDIA 2026 new-grad roles) keep a Timing note even though Jay is now a
   2026 graduate, because a 2026 hiring cycle may start before he can work in February 2027. It is a note only (no Fit cap).
3. **New-grad layout trigger** unchanged: it already accepts a 2026 or 2027 class, and a December 2026 graduate fits both.
4. **Internship start after December 2026** is read from the title, an internship / start line ("Summer 2027", "2027 Internships",
   "2027 ... Internship Program"), never from a graduation line. An internship that clearly ends by December 2026 (e.g. "Fall 2026
   co-op") gets no enrollment blocker even if it requires enrollment.
5. **Tracker labels** for the two date blockers now say December 2026 on new rows ("graduation window excludes December 2026",
   "enrollment required past December 2026"), so no output states a February 2027 graduation.
6. **Refit:** the logistics sentence is swapped after the closing is chosen, so letters change only in that sentence; only a
   letter the longer sentence would push past 200 words is rebuilt with the existing budget (harvey, monti).
7. **master.json** keeps `coursework_completion` (December 16, 2026); `degree_conferral` (February 1, 2027) and the computed OPT
   date are removed because they stated a February 2027 graduation. Flag off restores them in memory only.
8. `report.json skill_fit_cache.skills_text_hash` changes on every fixture because it includes the template hash (amendment A1).

## Known gaps left as they were (no new parsing was added)

- **tiktok_appsec** ("2026 Start", "commit to an onboarding date by end of year 2026") and **cdi** ("Target start date:
  12/01/2026") start before February 2027, but the start-date check reads only "start ... <Month> <year>" forms, so neither gets a
  Timing note (same as v3.4.8a). Worth a small parser fix in a later version if you want them flagged.
- The pipeline code still contains the old February 2027 sentences in the superseded layers and in the flag-off values; with the
  flag on, the final definitions replace or rewrite every one of them (`GREP_PROOF_v348b.txt`, item 6).
