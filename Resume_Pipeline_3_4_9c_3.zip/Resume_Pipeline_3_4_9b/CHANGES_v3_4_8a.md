# Resume pipeline v3.4.8a: changes (2026-10-19)

Built from Resume_Pipeline_3_4_7c.zip. LOW-RISK build: on all 124 fixtures the resume .tex, letter .txt and
tracker_row.json are byte-identical to `3_validation/baseline_v347c/` (the unmodified 7c outputs). Three changes, each
behind its own master.json `v347_flags` entry (default true). With all three off (test-only
`--regression-v347-flags-off=outreach_v348,employer_phrasings_v348,hook_fallback_v348`, or the same list in
`V347_FLAGS_OFF` for run_all.py) every fixture equals baseline_v347c, apart from the version label on the two stop reports.

Hash lock: pipeline ebbb295c | master 2f6d01c7 | bank d56f0743 (unchanged) | template 1309898b (unchanged) |
context md 8e63f1e0. plan_template.json (4358f1e0) and bank_check.py (81b28185) are unchanged.

Code changes edit only the final definitions of `build_outreach`, `v347_hiring_identity`, `v347_hook_detail`,
`v347_hook_reason`, `build_cover_letter` and `main_v3_1`, plus `V347_FLAG_NAMES` / `PIPELINE_VERSION` ("v3.4.8a"), and
add new helpers in a "v3.4.8a layer" block before `if __name__`; names defined more than once stay 61. No file is renamed;
bullet_bank.json and the template are not edited.

Changed Sources: `resume_pipeline_v3_2.py`, `master.json` (three flags, `outreach.notes_rule_v348`,
`outreach.domain_phrases_v348`, md pointer), `Master_Resume_Context_LEAN_CURRENT_v3_2.md` (new section 0-v348a).
Other changed files: `2_PROJECT_INSTRUCTIONS_paste.txt` (version, hook line, step h, hash lock; the
example list after "report.json notes", "Never match on the file name alone." and the script-enforced Cursor / Copilot item
were cut to stay under 7,600: 7,551 characters), `0_SETUP_STEPS.txt`, version checks in
selftest_v342 to v347c (selftest_v347b / v347c also turn the v3.4.8a flags off where they compare a build with
baseline_v347a / v347b), new `selftest_v348a.py`, `predict_v348a.py`, `predicted_changes_v348a.json`, `diff_gate_v348a.py`,
`baseline_v347c/`, refreshed `4_sample_outputs/` and `5_judged_packages/` (Judge_Batch_v3_4_8a.md). The old CHANGES.md
is now CHANGES_v3_4_7c.md.

## Safety steps (same method as 7a to 7c)

1. `baseline_v347c/`: all 124 fixtures on the unmodified 7c Sources; two 7c runs identical.
2. `predict_v348a.py` restates the three rules without any 8a code and wrote `predicted_changes_v348a.json` from the
   baseline before the code changed (O: 122 fixtures; E: 10; H: 11 verdict flips).
3. `diff_gate_v348a.py gate`: every changed line predicted, plus the gate guard (G1 resume / letter / tracker raw bytes
   identical; G2 report.json changes only in outreach, hiring_identity_v347, the employer Notes line and the
   hook-specificity fields; G3 hook verdicts change only False -> True on predicted fixtures; G4 every note passes the O2
   validator and block_md has the O1 format).
4. Two 8a runs identical; all-three-flags-off run identical to baseline_v347c.

## O outreach_v348

- report.json `outreach.linkedin.block_md` (also in outreach.json): `Company: [<Company> on LinkedIn](url) · Job post:
  [view](url)` (or `[search](url)` when no LinkedIn job URL) `· Req: [search](url)` (only with a req ID), then
  `### 1. Hiring manager`, `### 2. Software engineers / team members`, `### 3. Technical recruiters`,
  `### 4. University at Buffalo alumni`, each with one markdown people-search link and its note alone in a ```text block.
  The company link is the LinkedIn company page when the plan has one, else a LinkedIn company search. Company
  "Not stated": "Company: not stated in the posting", link labels and searches leave the company out, notes say "your team".
- Notes (`outreach.linkedin.notes`: hiring_manager, engineer, recruiter, ub_alum) come from 3 templates per audience
  (Jay's 8 starting templates, polished, plus one more each), picked by sha256 of company + role + audience, so reruns are
  identical and different postings get different wording. Fallbacks, in order: the role becomes "the open role", then the
  company is left out ("your team"), then the next template. `{domain}` comes from `master.outreach.domain_phrases_v348`
  (one phrase per role family, each with the master evidence it rests on); the templates never tie it to one employer.
- O2 validator `v348_note_problems` (post-run `_v348_post_run`): any failing note fails the build
  (`outreach_note_invalid`).
- `outreach.linkedin.block` stays in the old plain format, with the four new notes; `notes_chars` follows the notes;
  `notes_v348` logs the domain, role family and template ids. The old `message` / `contact_titles` fields are unchanged.

## E employer_phrasings_v348

`v348_employer_statements` adds "<Org> is searching for / is looking for / is seeking / seeks / is recruiting" to the A3
employer statements (after the 7a ones, so a 7a employer keeps first place). <Org> starts a sentence, is capitalized and
is not "We", "The", "Our", "This", "Company", "Client" and similar; an "(ABC)" acronym or ", <appositive>," may sit between
the name and the verb. Notes only, never a rename (the 7a Notes rule).

## H hook_fallback_v348

`v347_hook_detail` recomputes the test with job-title tokens normalized (trailing hyphens / punctuation dropped) and, when
the posting has no responsibility line, with the role summary (`v348_role_summary`: a "<Org> is hiring a ... to ..."
sentence, else the paragraph under "The Role" / "About the role" / "Role overview" / similar, else the first paragraph
about the job) as role text. The new detail is used only when its verdict differs, so non-flipping fixtures report what
they did before. A flipped-to-specific hook logs `cover_letter.hook_specific_basis_v348`; a failing role-summary check
says so in the A6 reason. The letter never changes.
