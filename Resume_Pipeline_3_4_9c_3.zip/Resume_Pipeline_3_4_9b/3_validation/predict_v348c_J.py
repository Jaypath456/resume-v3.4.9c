"""v3.4.8c fix J predictions (flag heading_move_v348), written BEFORE any J code.

  python3 predict_v348c_J.py BEFORE_DIR [OUT_JSON]      (default OUT_JSON: predicted_changes_v348c_J.json)

Restated from Jay's request without importing any v3.4.8c code. When the v3.4.7a A2 rule took a posting-named
technology off a heading (report heading_tech_v347) and no rendered heading shows it any more, it moves to the heading
of the selected project whose bullets show it (most bullets first, then page order; a React / Node / TypeScript / Vite
bullet shows JavaScript, as in A2), only when that heading has fewer than 4 technologies; nothing is displaced and
Skills never change. report.json ats_coverage no longer claims also_in "header" for a term no rendered heading shows.
Predicted changed lines: the receiving heading line; report ats_coverage[*].also_in entries / ats_summary and the new
heading_move_v348c log on those pages; and ats_coverage[*].also_in on every page where a term claims "header" but no
rendered heading names it.
"""
import json, re, sys, pathlib

H = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(H))
from diff_gate_v348c import parse_tex   # noqa: E402

SHOW = {"JavaScript": r"JavaScript|React(?:JS|\.js)?|Node(?:\.js)?|TypeScript|Vite", "Python": r"Python|Django|Flask|FastAPI|Pydantic|pytest|PyTorch|LangGraph|Streamlit|asyncio",
        "Java": r"Java|Spring(?: Boot)?"}
FORMS = {"ReactJS": r"React(?:JS|\.js)?", "PostgreSQL": r"Postgre(?:SQL|s)", "Apache Kafka": r"Kafka"}
PID = {"LedgerFlow": "ledgerflow", "LaunchOps": "launchops", "GoingOnce": "goingonce", "RIPPLE": "ripple", "Fraud": "fraud", "Pintos": "pintos", "LLM": "tailor_pipeline"}


def shows(text: str, x: str) -> int:
    rx = SHOW.get(x) or FORMS.get(x) or re.escape(x)
    return len(re.findall(r"(?<![\w])(?:" + rx + r")(?![\w])", text, re.I))


def in_heads(x: str, heads: list[list[str]]) -> bool:
    rx = FORMS.get(x) or re.escape(x)
    return any(re.fullmatch(rx, t, re.I) or t == x for h in heads for t in h)


def main(before: str, out: str = "") -> None:
    B = pathlib.Path(before)
    pred, expected = [], {}
    for fx in sorted(p.name for p in B.iterdir() if (p / "resume.tex").exists()):
        rep = json.loads((B / fx / "report.json").read_text())
        p = parse_tex((B / fx / "resume.tex").read_text())
        heads = [x["tech"] for x in p["projects"]]
        moved = []
        for pid, items in (rep.get("heading_tech_v347") or {}).items():
            for it in items:
                x = it["left"]
                if in_heads(x, heads) or x in [m[0] for m in moved]:
                    continue
                cands = [(shows(" ".join(pr["bullets"]), x), -k, pr) for k, pr in enumerate(p["projects"])
                         if PID.get(pr["name"].split(":")[0].split()[0], "") != pid and shows(" ".join(pr["bullets"]), x)]
                if not cands:
                    continue
                n, _k, best = max(cands, key=lambda c: (c[0], c[1]))
                if len(best["tech"]) < 4:
                    moved.append((x, best["name"]))
        claims = []
        for c in rep.get("ats_coverage") or []:
            if "header" in (c.get("also_in") or []) and not in_heads(str(c.get("term")), heads) and not in_heads(str(c.get("verbatim")), heads):
                claims.append(c.get("term"))
        if not moved and not claims:
            continue
        expected[fx] = {"moved": moved, "header_claims_without_heading": claims}
        for x, name in moved:
            pred.append({"fixture": fx, "file": "resume_tex", "pattern": r"^\\noindent\\textbf\{" + re.escape(name) + r"\}"})
        pred.append({"fixture": fx, "file": "report", "pattern": r"^(?:ats_coverage\[\d+\]\.(?:also_in|surface)|ats_summary\.|heading_move_v348c\.)"})
    label = [{"fixture": fx, "file": "report", "pattern": r'^pipeline_version: "v3\.4\.8c"$', "label_only": True, "reason": "unchanged version label"} for fx in ("fonzi", "cisco_no_title")]
    doc = {"version": "v3.4.8c", "fix": "J", "baseline": str(B), "fixes": [{"fix": "J", "predicted": pred}], "justified": label, "expected": expected}
    pathlib.Path(out or H / "predicted_changes_v348c_J.json").write_text(json.dumps(doc, indent=1) + "\n")
    mv = {k: v["moved"] for k, v in expected.items() if v["moved"]}
    print(f"J: {len(mv)} heading moves: " + "; ".join(f"{k} {v}" for k, v in mv.items()))
    print(f"J: {sum(1 for v in expected.values() if v['header_claims_without_heading'])} pages with a header claim no heading backs: "
          + "; ".join(f"{k} {v['header_claims_without_heading']}" for k, v in expected.items() if v['header_claims_without_heading']))


if __name__ == "__main__":
    main(*sys.argv[1:3])
