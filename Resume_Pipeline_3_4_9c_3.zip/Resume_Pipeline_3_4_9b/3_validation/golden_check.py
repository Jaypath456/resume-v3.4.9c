"""v3.4.9a golden set check (the main acceptance test of the v3.4.9a build).

  python3 golden_check.py SNAPSHOT [LABEL] [REPORT_MD]

SNAPSHOT is a snapshot folder (diff_gate_v348c.py snapshot: <fixture>/resume.tex, letter.txt, report.json, tracker_row.json)
or a run_all.py OUT folder (<fixture>/out/...). LABEL names the snapshot in golden_history.json (for example
"baseline_v348c" or "snap_v349a_1"); each call records the PASS/FAIL of every row under LABEL, so golden_report.md can say
which fix flipped each row. REPORT_MD defaults to golden_report.md next to this script.

Rules come from golden_set.json (12 entries). "rank1" is the project with the most bullet slots: report.json
"ranking_v349".rank[0] when the page carries it (v3.4.9a fix 6 renders newest first, so the first project on the page is no
longer rank1), otherwise the first project on the page (up to v3.4.8c the page order was the rank order). "order" is the
order on the page. Exit code 1 when any row FAILS.
"""
import json, re, sys, pathlib

H = pathlib.Path(__file__).resolve().parent
PID = {"LedgerFlow": "ledgerflow", "LaunchOps": "launchops", "GoingOnce": "goingonce", "RIPPLE": "ripple", "Fraud": "fraud",
       "Pintos": "pintos", "LLM": "tailor_pipeline"}


def _files(root: pathlib.Path, fx: str) -> dict:
    d = root / fx
    if (d / "resume.tex").exists() or (d / "report.json").exists():
        return {"tex": d / "resume.tex", "letter": d / "letter.txt", "report": d / "report.json"}
    o = d / "out"
    tex = [p for p in o.glob("*.tex") if p.name != "build_resume.tex"]
    let = list(o.glob("*_Cover_Letter.txt"))
    return {"tex": tex[0] if tex else o / "none.tex", "letter": let[0] if let else o / "none.txt", "report": o / "report.json"}


def parse_page(tex: str) -> dict:
    out = {"projects": [], "skills": {}}
    sec = ""
    for ln in tex.splitlines():
        m = re.search(r"\\section\*\{([^}]*)\}", ln)
        if m:
            sec = m.group(1)
        s = ln.strip()
        if sec == "PERSONAL PROJECTS" and s.startswith("\\noindent\\textbf{"):
            name = re.match(r"\\noindent\\textbf\{(.*?)\}", s).group(1)
            out["projects"].append({"id": PID.get(re.split(r"[:\s]", name)[0], name), "name": name, "bullets": []})
        elif sec == "PERSONAL PROJECTS" and s.startswith("\\item ") and out["projects"]:
            out["projects"][-1]["bullets"].append(s[6:])
        elif sec == "TECHNICAL SKILLS" and s.startswith("\\item \\textbf{"):
            m = re.match(r"\\item \\textbf\{(.*?):\}\s*(.*)$", s)
            out["skills"][m.group(1).replace("\\&", "&")] = [x.strip() for x in m.group(2).split(",") if x.strip()]
    return out


def _plain(s: str) -> str:
    s = re.sub(r"\\(?:textbf|textit|underline|href\{[^}]*\})\{([^}]*)\}", r"\1", s)
    return s.replace("\\%", "%").replace("\\&", "&").replace("\\$", "$").replace("~", " ")


def check(entry: dict, f: dict) -> dict:
    row = {"name": entry["name"], "problems": []}
    P = row["problems"]
    if not f["tex"].exists() or not f["report"].exists():
        P.append("no resume or report")
        row["status"] = "FAIL"
        return row
    page = parse_page(f["tex"].read_text(encoding="utf-8"))
    rep = json.loads(f["report"].read_text(encoding="utf-8"))
    letter = f["letter"].read_text(encoding="utf-8") if f["letter"].exists() else ""
    order = [p["id"] for p in page["projects"]]
    nb = {p["id"]: len(p["bullets"]) for p in page["projects"]}
    rk = (rep.get("ranking_v349") or {}).get("rank") or order
    rank1 = rk[0] if rk else ""
    row.update({"set": sorted(order), "order": order, "rank1": rank1, "fit": rep.get("effective_fit"),
                "hard_gaps": [g.get("term") for g in rep.get("hard_gaps") or []],
                "languages": ", ".join(page["skills"].get("Languages & Databases", [])),
                "closing": str(((rep.get("cover_letter") or {}).get("closing") or {}).get("text", "")) if isinstance((rep.get("cover_letter") or {}).get("closing"), dict) else str((rep.get("cover_letter") or {}).get("closing") or ""),
                "bullets": nb})
    if sorted(entry["set"]) != sorted(order):
        P.append(f"set {sorted(order)} != {sorted(entry['set'])}")
    if rank1 != entry["rank1"]:
        P.append(f"rank1 {rank1} != {entry['rank1']}")
    slots = (rep.get("layout_v343") or {}).get("slots_by_rank") or []
    if any(a < b for a, b in zip(slots, slots[1:])):
        P.append(f"slots by rank {slots}: rank1 does not get the most")
    if entry.get("order") and order != entry["order"]:
        P.append(f"order {' > '.join(order)} != {' > '.join(entry['order'])}")
    if rep.get("effective_fit") not in entry["fit"]:
        P.append(f"Fit {rep.get('effective_fit')} not in {entry['fit']}")
    for g in entry.get("hard_gaps_exclude", []):
        if g.casefold() in {str(x).casefold() for x in row["hard_gaps"]}:
            P.append(f"hard gap {g}")
    if entry.get("no_note_experience_years") and any(w.get("type") in ("note_experience_years", "experience_years") for w in rep.get("warnings") or []):
        P.append("note_experience_years present")
    sk = page["skills"]
    allsk = [x for v in sk.values() for x in v]
    if entry.get("no_react_and_reactjs") and "React" in allsk and "ReactJS" in allsk:
        P.append("Skills show both React and ReactJS")
    for t in entry.get("not_in_tools", []):
        if t in sk.get("Tools", []):
            P.append(f"{t} in Tools")
    if entry.get("no_llm_resume_bullet"):
        for p in page["projects"]:
            if p["id"] == "tailor_pipeline" and any(re.search(r"\bwrite (?:\w+ )?resume bullets\b|\bresume-generation\b", b, re.I) for b in p["bullets"]):
                P.append("LLM-engine resume bullet on the page")
    page_text = _plain(f["tex"].read_text(encoding="utf-8"))
    found = []
    for ph in entry.get("forbidden", []):
        if ph.casefold() in page_text.casefold() or ph.casefold() in letter.casefold():
            found.append(ph)
    for ph in entry.get("forbidden_letter", []):
        if ph.casefold() in (" " + letter.replace("\n", " ") + " ").casefold():
            found.append(ph.strip() + " (letter)")
    row["forbidden_found"] = found
    if found:
        P.append("forbidden: " + ", ".join(found))
    if rep.get("status") != "PASS":
        P.append("build " + str(rep.get("status")))
    row["status"] = "PASS" if not P else "FAIL"
    return row


def main(snap: str, label: str = "", report: str = "") -> int:
    gs = json.loads((H / "golden_set.json").read_text(encoding="utf-8"))
    root = pathlib.Path(snap)
    rows = [check(e, _files(root, e["name"])) for e in gs["entries"]]
    hp = H / "golden_history.json"
    hist = json.loads(hp.read_text(encoding="utf-8")) if hp.exists() else {"order": [], "runs": {}}
    if label:
        if label not in hist["order"]:
            hist["order"].append(label)
        hist["runs"][label] = {r["name"]: r["status"] for r in rows}
        hp.write_text(json.dumps(hist, indent=1) + "\n", encoding="utf-8")

    def flipped(name):
        prev, out = None, []
        for lb in hist["order"]:
            st = hist["runs"].get(lb, {}).get(name)
            if prev is not None and st != prev:
                out.append(f"{lb}: {prev} -> {st}")
            prev = st
        return "; ".join(out) or "-"
    esc = lambda s: str(s).replace("|", "\\|")
    L = ["# Golden set report (v3.4.9a)", "", f"Snapshot: `{root.name}`" + (f" (label {label})" if label else "") + ". Rules: `golden_set.json`.", "",
         f"Result: **{sum(r['status'] == 'PASS' for r in rows)} / {len(rows)} PASS**.", "",
         "| Posting | Set | rank1 | Page order | Fit | Hard gaps | Languages line | Closing sentence | Forbidden found | Result | Flipped by |",
         "|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        L.append("| " + " | ".join(esc(x) for x in [r["name"], ", ".join(r.get("set", [])), r.get("rank1", ""), " > ".join(r.get("order", [])), r.get("fit", ""),
                                                      ", ".join(r.get("hard_gaps", [])) or "none", r.get("languages", ""), r.get("closing", ""),
                                                      ", ".join(r.get("forbidden_found", [])) or "none",
                                                      r["status"] + ("" if r["status"] == "PASS" else ": " + "; ".join(r["problems"])), flipped(r["name"])]) + " |")
    if hist["order"]:
        L += ["", "## History", "", "| Posting | " + " | ".join(hist["order"]) + " |", "|---|" + "---|" * len(hist["order"])]
        for r in rows:
            L.append(f"| {r['name']} | " + " | ".join(hist["runs"].get(lb, {}).get(r["name"], "") for lb in hist["order"]) + " |")
    pathlib.Path(report or H / "golden_report.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    for r in rows:
        print(f"{r['name']:22} {r['status']}  rank1={r.get('rank1')} order={'>'.join(r.get('order', []))} fit={r.get('fit')}" + ("" if r["status"] == "PASS" else "  " + "; ".join(r["problems"])))
    print(f"GOLDEN {sum(r['status'] == 'PASS' for r in rows)}/{len(rows)} PASS")
    return 0 if all(r["status"] == "PASS" for r in rows) else 1


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:4]))
