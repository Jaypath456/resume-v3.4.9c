"""v3.4.8c fix C predictions (flags closing_proof_map_v348 = C1, closing_specific_v348 = C2), written BEFORE any C code.

  python3 predict_v348c_C.py BEFORE_DIR [OUT_JSON]      (default OUT_JSON: predicted_changes_v348c_C.json)

Restated from Jay's request without importing any v3.4.8c code. Only responsibility closings are in scope (a role-family
closing has no responsibility line and stays).
  C1 proof map: model training / optimization / accuracy / latency -> Fraud's measured results when Fraud is on the
     page; agent / evaluation / LLM reliability -> RIPPLE's evaluation (a Git-diff or Fraud proof is no longer an "AI"
     proof); integrations / APIs -> LedgerFlow exactly-once; permissions / access -> LaunchOps server checks;
     interactive -> LaunchOps live quiz or the GoingOnce interface; testing -> CI and test suites; operations ->
     the Thesis heartbeat. Never a fact the letter already gives (then another fact of the same project).
  C2 specificity: a closing whose responsibility is generic (specificity <= 0) may move to a posting responsibility that
     is clearly more specific: specificity at least 2 higher, with at least 2 domain words. Specificity = +1 for each
     word naming the product, team or users (a users word such as customers / merchants, or a content word whose
     6-letter stem the posting's description uses: the non-bullet lines of its role text), -1 for each generic word
     (software, components, building, blocks, applications, solutions, features, products, systems, tools, code,
     services, platforms, technology); quality adjectives (scalable, reliable, innovative, ...) and verbs count 0.
     A page is predicted when some role line could yield such a responsibility (its domain words, an upper bound for
     any cut of it, reach both thresholds).
Honest record: the first C2 rule written here (+1 for any content word repeated in the role text) was replaced, before
this predictor was run on its baseline and before the full C run, after a development smoke showed it choosing lines
full of repeated quality adjectives ("scalable, reliable, and innovative solutions"); the C1 rule is unchanged. It
restates only Jay's request and imports no v3.4.8c code.
Predicted changed lines (a superset: a page listed here may keep its closing when no candidate passes the validators):
the letter paragraph that holds the closing, and the report's cover_letter.* / closing logs / verify_* lines.
"""
import json, re, sys, pathlib

H = pathlib.Path(__file__).resolve().parent
GENERIC = {"software", "components", "component", "building", "blocks", "applications", "application", "solutions", "features", "products",
           "systems", "system", "tools", "code", "services", "platforms", "technology", "technologies"}
STOP = set("""a an the and or of to for with in on by into from that this each its their as at plus while using which who so it them both also
my i where whose every all any one your our under over than then when only across new existing high quality help build improve design develop
create implement write test deploy integrate monitor enhance maintain optimize optimise ship deliver automate debug troubleshoot scale architect
engineer prototype extend modernize migrate refactor launch work working make makes using use used directly real world real-world""".split())
QUALITY = set("""scalable scalability reliable reliability innovative intuitive high-performance performance efficient efficiency effectiveness
robust maintainable quality high-quality clean quickly safely modern next generation production-level production business requirements value
experiences experience capabilities real standards end-to-end complex tasks secure world-class best leading cutting-edge large various multiple
stack full-stack technical generic internal skilled motivated ideal great strong skills company generational inflection point opportunity
mission role team teams rapidly""".split())
USERS = set("""customers customer users user merchants clients patients students employees businesses firms enterprises creators viewers
advertisers drivers riders members partners shoppers sellers buyers doctors clinicians teachers learners consumers players""".split())
ML = re.compile(r"\bmodels?\b|\bml\b|\bmachine learning\b|\bneural\b", re.I)
ML_RES = re.compile(r"\btrain\w*|\boptimi[sz]\w*|\baccura\w*|\blatenc\w*|\bfine[- ]tun\w*", re.I)


def role_text(raw: str) -> str:
    return re.split(r"(?im)^\s*(?:benefits|what we offer|perks|equal opportunity|about us)\b", raw)[0]


def domain_stems(raw: str) -> set:
    lines = [l.strip() for l in role_text(raw).splitlines() if l.strip() and not re.match(r"^[-*•·]|^\d+[.)]", l.strip())]
    return {w[:6] for l in lines for w in re.findall(r"[a-z][a-z'-]+", l.lower())}


def spec(resp: str, raw: str) -> tuple:
    st = domain_stems(raw)
    sc = dom = 0
    for w in re.findall(r"[a-z][a-z'-]+", resp.lower()):
        if w in GENERIC:
            sc -= 1
        elif w in USERS or (w not in STOP and w not in QUALITY and len(w) >= 4 and w[:6] in st):
            sc += 1; dom += 1
    return sc, dom


def main(before: str, out: str = "") -> None:
    B = pathlib.Path(before)
    man = {m["name"]: m for m in json.loads((H / "manifest.json").read_text())}
    pred, expected = [], {}
    for fx in sorted(p.name for p in B.iterdir() if (p / "letter.txt").exists()):
        rep = json.loads((B / fx / "report.json").read_text())
        cl = (rep.get("cover_letter") or {}).get("closing") or {}
        if not isinstance(cl, dict) or cl.get("family") or not cl.get("responsibility"):
            continue
        resp, proof, kind = str(cl.get("responsibility")), str(cl.get("proof")), str(cl.get("proof_kind"))
        raw = (H / "jds" / (fx + ".txt")).read_text()
        tex = (B / fx / "resume.tex").read_text()
        fraud_on = "Fraud Detection using Graph Neural Networks" in tex
        why = []
        if ML.search(resp) and ML_RES.search(resp) and fraud_on and not proof.startswith("fraud."):
            why.append("C1 model results -> Fraud")
        if kind == "ai" and proof in ("ripple.git_verification", "fraud.graphsage", "fraud.elliptic"):
            why.append("C1 AI proof is not an evaluation proof")
        s0 = spec(resp, raw)[0]
        if s0 <= 0:
            lines = [l.strip(" -*•\t") for l in role_text(raw).splitlines() if len(l.split()) >= 3]
            better = [l for l in lines if spec(l, raw)[1] >= max(2, s0 + 2)]
            if better:
                why.append(f"C2 generic responsibility (specificity {s0}); {len(better)} posting lines score >= {s0 + 2}")
        if not why:
            continue
        expected[fx] = {"responsibility": resp, "proof": proof, "kind": kind, "why": why, "group": man.get(fx, {}).get("suite", "v340")}
        pred.append({"fixture": fx, "file": "letter_txt", "pattern": r"."})
        pred.append({"fixture": fx, "file": "report", "pattern": r"^(?:cover_letter\.|closing_v348c\.|verify_changes_v344|verify_quotes_v345|internal_changes)"})
    label = [{"fixture": fx, "file": "report", "pattern": r'^pipeline_version: "v3\.4\.8c"$', "label_only": True, "reason": "unchanged version label"} for fx in ("fonzi", "cisco_no_title")]
    doc = {"version": "v3.4.8c", "fix": "C", "baseline": str(B), "fixes": [{"fix": "C", "predicted": pred}], "justified": label, "expected": expected,
           "c2_rule": "switch only when the current responsibility scores <= 0 and a candidate scores at least 2 higher with at least 2 domain words"}
    pathlib.Path(out or H / "predicted_changes_v348c_C.json").write_text(json.dumps(doc, indent=1) + "\n")
    print(f"C: {len(expected)} closings may change: " + "; ".join(f"{k} [{', '.join(w.split(' ')[0] for w in v['why'])}]" for k, v in expected.items()))


if __name__ == "__main__":
    main(*sys.argv[1:3])
