"""v3.4.8a self-test: python3 selftest_v348a.py  -> prints each check and exits 1 on any failure.
O outreach_v348: the O2 validator (good notes pass, deliberately bad ones fail), every template in every fill passes,
template variety and stability, the domain map (each phrase backed by master evidence, no domain Jay lacks), the
block_md format (with and without a company), and end-to-end builds of zoro / ust (block_md, four notes, plain block).
E employer_phrasings_v348: true and false hits. H hook_fallback_v348: title normalization, role-summary extraction and
the zoro flip. Flags: each new flag turns only its change off; all three off = baseline_v347c on three fixtures.
Instructions, hash lock and context md."""
import hashlib, json, pathlib, re, shutil, subprocess, sys, tempfile, importlib.util
H = pathlib.Path(__file__).resolve().parent
SRC = H.parent / "1_upload_to_ChatGPT_Sources"
sys.argv = [sys.argv[0]]
spec = importlib.util.spec_from_file_location("rp", SRC / "resume_pipeline_v3_2.py"); rp = importlib.util.module_from_spec(spec); spec.loader.exec_module(rp)
master = json.loads((SRC / "master.json").read_text())
sys.path.insert(0, str(H)); import diff_gate_v347 as gate   # noqa: E402
import diff_gate_v348a as gate8   # noqa: E402
MAN = {m["name"]: m for m in json.loads((H / "manifest.json").read_text())}
TPL = json.loads((SRC / "plan_template.json").read_text())
BASE = H / "baseline_v347c"
NEW = ("outreach_v348", "employer_phrasings_v348", "hook_fallback_v348")
V349B_OFF = "--regression-v347-flags-off=bank_format_v349b,format_letter_v349b,bold_results_v349b,skills_cap5_v349b,letter_trims_v349b"   # v3.4.9b: these end-to-end checks compare with A4 baselines, so the format flags are off
bad = []


def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else f"  -> {detail}"))
    if not ok:
        bad.append(name)


check("pipeline version", rp.PIPELINE_VERSION in ("v3.4.8a", "v3.4.8b", "v3.4.8c", "v3.4.9a", "v3.4.9b"), rp.PIPELINE_VERSION)   # v3.4.8b build keeps these checks
fl = master.get("v347_flags") or {}
check("flags: master.json v347_flags has the three v3.4.8a flags, true", all(fl.get(k) is True for k in NEW), fl)
check("flags: all flags known and true (14 in v3.4.8a, 15 in v3.4.8b, 23 in v3.4.8c, 33 since v3.4.9a, 38 since v3.4.9b)", all(k in rp.V347_FLAG_NAMES for k in NEW) and len(rp.V347_FLAG_NAMES) in (14, 15, 23, 33, 38) and all(fl.get(k) is True for k in rp.V347_FLAG_NAMES))
for k in NEW:
    off = json.loads(json.dumps(master)); off["v347_flags"][k] = False
    got = rp.v347_load_flags(off)
    check(f"flags: {k} false turns only that change off", got[k] is False and all(v for kk, v in got.items() if kk != k), got)
rp.v347_load_flags(master)

# ---- O2 validator ------------------------------------------------------------------------------------------------
P = rp.v348_note_problems
good = "Hi {Name}, I'm a CS grad student at UB and would love to hear how you like the work. Thanks, Jay"
check("O2: a plain warm note passes", P(good) == [], P(good))
for why, n, rid in [
    ("over 300 characters", "Hi {Name}, " + "really " * 45 + "glad to connect. Thanks, Jay", ""),
    ("a digit", "Hi {Name}, I cut processing time by 80 percent at UB. Thanks, Jay", ""),
    ("a project name (RIPPLE)", "Hi {Name}, I built RIPPLE at UB. Thanks, Jay", ""),
    ("a project name (LedgerFlow)", "Hi {Name}, I built LedgerFlow at UB. Thanks, Jay", ""),
    ("a project name (Optimization Engine)", "Hi {Name}, I worked on the Optimization Engine at UB. Thanks, Jay", ""),
    ("a project name in lower case (fraud)", "Hi {Name}, I worked on fraud models at UB. Thanks, Jay", ""),
    ("the requisition ID", "Hi {Name}, I applied for req ABC-X at UB. Thanks, Jay", "ABC-X"),
    ("referral", "Hi {Name}, would you consider a referral? Thanks, Jay", ""),
    ("considered", "Hi {Name}, I'd like to be considered for the role. Thanks, Jay", ""),
    ("opportunity to", "Hi {Name}, I'd love the opportunity to join. Thanks, Jay", ""),
    ("I am excited", "Hi {Name}, I am excited about your team. Thanks, Jay", ""),
    ("passionate", "Hi {Name}, I'm passionate about backend work. Thanks, Jay", ""),
    ("Not stated", "Hi {Name}, I applied for a role at Not stated. Thanks, Jay", ""),
    ("an exclamation mark", "Hi {Name}, great to see your work! Thanks, Jay", ""),
    ("an em dash", "Hi {Name}, I'm at UB — glad to connect. Thanks, Jay", ""),
    ("an en dash", "Hi {Name}, I'm at UB – glad to connect. Thanks, Jay", ""),
    ("a wrong sign-off", "Hi {Name}, glad to connect. – Jay", ""),
    ("a wrong sign-off (Regards)", "Hi {Name}, glad to connect. Regards, Jay", ""),
    ("a lost {Name}", "Hi there, glad to connect. Thanks, Jay", ""),
]:
    check(f"O2: a note with {why} FAILS", bool(P(n, rid)), n)
old = json.loads((BASE / "zoro_fullstack" / "report.json").read_text())["outreach"]["linkedin"]["notes"]
check("O2: the 7c hiring-manager and recruiter notes (zoro: project name, digits, en dash) FAIL the new validator", P(old["hiring_manager"]) and P(old["recruiter"]), {k: P(v) for k, v in old.items()})

# ---- templates -------------------------------------------------------------------------------------------------------
dom = master["outreach"]["domain_phrases_v348"]
fams = [k for k in master["role_families"] if not k.startswith("_")]
check("domain map: one phrase for every role family", all(f in dom and dom[f].get("phrase") for f in fams), sorted(set(fams) - set(dom)))
mtxt = json.dumps({k: v for k, v in master.items() if k != "outreach"}, ensure_ascii=False) + json.dumps({k: v for k, v in master["outreach"].items() if k != "domain_phrases_v348"}, ensure_ascii=False)
for f in fams:
    ev = dom[f].get("evidence") or []
    check(f"domain map: {f} -> {dom[f]['phrase']!r} backed by master evidence", bool(ev) and all(e in mtxt for e in ev), ev)
nev = " ".join(str(x) for x in master.get("never_supported_terms", []) + master.get("unsupported_claims", []) if isinstance(x, str)).lower()
check("domain map: no phrase uses a never-supported term", not any(dom[f]["phrase"].lower() in nev for f in fams))
for aud, tpls in rp.V348_TEMPLATES.items():
    check(f"templates: {aud} has 2-3 templates", 2 <= len(tpls) <= 3, len(tpls))
    for i, (wc, nc) in enumerate(tpls):
        check(f"templates: {aud}.{'ABC'[i]} keeps {{Name}} and has a no-company form without {{Company}}", "{Name}" in wc and "{Name}" in nc and "{Company}" not in nc)
        for f in fams:
            for tpl, co, role in ((wc, "Acme Robotics", "the Backend Software Engineer role"), (nc, "", "the open role")):
                n = rp.v348_fill(tpl, co, role, dom[f]["phrase"])
                if P(n):
                    check(f"templates: {aud}.{'ABC'[i]} with {f} passes O2", False, (n, P(n)))
check("templates: every template x every domain x both forms passes O2", True)
alum_apply = [t for pair in rp.V348_TEMPLATES["ub_alum"] for t in pair if re.search(r"appl(?:y|ied|ication)", t, re.I)]
check("strategy: alumni notes never mention the application", not alum_apply, alum_apply)
eng_ask = [t for pair in rp.V348_TEMPLATES["engineer"] for t in pair if re.search(r"appl(?:y|ied|ication)|\brole\b|job", t, re.I)]
check("strategy: engineer notes make no job ask", not eng_ask, eng_ask)
for aud in ("hiring_manager", "recruiter"):
    once = all(len(re.findall(r"appl(?:y|ied|ication)", t, re.I)) == 1 for pair in rp.V348_TEMPLATES[aud] for t in pair)
    check(f"strategy: {aud} notes mention the application exactly once", once)
openings = {re.sub(r"^Hi \{Name\}, ", "", t).split()[0:3].__str__() for pairs in rp.V348_TEMPLATES.values() for t, _ in pairs}
check("variety: openings after the greeting differ across templates", len(openings) >= 9, len(openings))
picks = {}
for co, role in [("Zoro", "Software Developer"), ("UST", "Software Engineer"), ("Meritore", "Java Developer"), ("Acme", "Data Engineer"), ("Globex", "ML Engineer"),
                 ("Initech", "Backend Engineer"), ("Umbrella", "SDET"), ("Hooli", "Full Stack Engineer")]:
    for aud in rp.V348_AUDIENCES:
        a = rp.v348_template_index(co, role, aud, len(rp.V348_TEMPLATES[aud]))
        check(f"variety: {co}/{role}/{aud} template choice is stable", a == rp.v348_template_index(co, role, aud, len(rp.V348_TEMPLATES[aud])))
        picks.setdefault(aud, set()).add(a)
check("variety: different companies get different templates (every template used across 8 postings)", all(len(v) == len(rp.V348_TEMPLATES[k]) for k, v in picks.items()), picks)
long_role = "the Senior Staff Principal Distinguished Full Stack Platform Infrastructure Reliability Engineering Lead Architect role"
r = rp.v348_pick_note("recruiter", "Acme Robotics International Holdings Group", "x", long_role[4:-5], "cloud deployments and monitoring")
check("fallback: a long role becomes 'the open role' when the note would pass 300 characters", r["note"] and "the open role" in r["note"] and not P(r["note"]), r)
r = rp.v348_pick_note("recruiter", "Ripple", "Software Engineer", "Software Engineer", "backend systems")
check("fallback: a company named like a project (Ripple) drops the company keyword, note still passes", r["note"] and "Ripple" not in r["note"] and not P(r["note"]), r)
r = rp.v348_pick_note("hiring_manager", "3M", "Software Engineer", "Software Engineer", "backend systems")
check("fallback: a company with a digit drops the company keyword", r["note"] and "3M" not in r["note"] and not P(r["note"]), r)
r = rp.v348_pick_note("recruiter", "Acme", "Software Engineer 2", "Software Engineer 2", "backend systems")
check("fallback: a role with a digit becomes 'the open role'", r["note"] and "the open role" in r["note"] and not P(r["note"]), r)
r = rp.v348_pick_note("engineer", "Not stated", "Software Engineer", "Software Engineer", "data pipelines")
check("Not stated: notes say 'your team' and never 'Not stated'", "your team" in r["note"] and "Not stated" not in r["note"] and not P(r["note"]), r)
check("role text: 'Developer- Full Stack' -> 'the Developer Full Stack role'", rp.v348_the_role("Developer- Full Stack") == "the Developer Full Stack role")

# ---- block_md format --------------------------------------------------------------------------------------------------
notes = {a: rp.v348_fill(rp.V348_TEMPLATES[a][0][0], "Acme", "the Backend Engineer role", "backend systems") for a in rp.V348_AUDIENCES}
ppl = {"manager": "https://www.linkedin.com/search/results/people/?keywords=Acme%20manager", "team_engineers": "https://www.linkedin.com/search/results/people/?keywords=Acme%20engineer",
       "recruiters": "https://www.linkedin.com/search/results/people/?keywords=Acme%20technical%20recruiter", "ub_alumni": "https://www.linkedin.com/search/results/people/?keywords=Acme%20University%20at%20Buffalo"}
li = {"notes": notes, "people": ppl, "company_page": "https://www.linkedin.com/company/acme", "job_post": "not found", "job_search": "https://www.linkedin.com/jobs/search/?keywords=Backend%20Acme",
      "requisition_id": "R-12345", "job_search_requisition": "https://www.linkedin.com/jobs/search/?keywords=R-12345%20Acme"}
md = rp.v348_block_md(li, "Acme")
check("block_md: O1 format (company / job / req links, four headings, link + text block each)", not gate8.block_md_problems(md, notes), gate8.block_md_problems(md, notes))
check("block_md: first line", md.split("\n")[0] == "Company: [Acme on LinkedIn](https://www.linkedin.com/company/acme) · Job post: [search](https://www.linkedin.com/jobs/search/?keywords=Backend%20Acme) · Req: [search](https://www.linkedin.com/jobs/search/?keywords=R-12345%20Acme)", md.split("\n")[0])
check("block_md: each note alone in its own ```text block", md.count("```text\n") == 4 and all(f"```text\n{n}\n```" in md for n in notes.values()))
li2 = dict(li, job_post="https://www.linkedin.com/jobs/view/123", requisition_id="", job_search_requisition="")
md2 = rp.v348_block_md(li2, "Acme")
check("block_md: a found job post shows [view] and no Req link without a req ID", "Job post: [view](https://www.linkedin.com/jobs/view/123)" in md2 and "Req:" not in md2)
md3 = rp.v348_block_md(dict(li2, company_page="not found"), "Not stated")
check("block_md: company Not stated -> no company keyword in link labels, company line says so", md3.startswith("Company: not stated in the posting") and "at Not stated" not in md3 and "[Find engineers](" in md3)
check("block_md: a bad block FAILS the format check", bool(gate8.block_md_problems(md.replace("```text\n" + notes["engineer"], notes["engineer"]), notes)))

# ---- E employer phrasings ----------------------------------------------------------------------------------------
E = rp.v348_employer_statements
for t, want in [("UST is searching for a skilled and motivated Software Engineer.", ["UST"]), ("Brillio is seeking motivated engineers.", ["Brillio"]),
                ("Acme Robotics is looking for a backend engineer.", ["Acme Robotics"]), ("Globex seeks a data engineer.", ["Globex"]),
                ("Raydar is recruiting for this role on behalf of our client.", ["Raydar"]),
                ("Black Canyon Consulting (BCC) is searching for a Junior Data Scientist.", ["Black Canyon Consulting"]),
                ("IXL Learning, developer of learning products used by millions, is seeking new graduates.", ["IXL Learning"]),
                ("We are seeking a backend engineer.", []), ("The team is looking for a new engineer.", []), ("Our client is seeking a developer.", []),
                ("Our partner is looking for a Software Engineer.", []), ("The company is seeking early Product Engineers.", []),
                ("This role is looking for strong Python skills.", []), ("our team is seeking a developer.", []), ("Candidates who are seeking growth should apply.", [])]:
    check(f"E: {t!r} -> {want}", E(t) == want, E(t))
idt = rp.v347_hiring_identity("UST is searching for a skilled and motivated Software Engineer to design software.", "UST")
check("E: ust records an employer statement, no Notes line (matches the company)", idt["employer_statements"] == ["UST"] and idt["matches_company"] and not idt["note"], idt)
idt = rp.v347_hiring_identity("Globex seeks a data engineer to build pipelines.", "Talent Partners")
check("E: a different detected employer gets the 7a Notes line (never a rename)", idt["note"] == "Posted under Talent Partners; the posting names Globex as the employer." and idt["company"] == "Talent Partners", idt)
off = json.loads(json.dumps(master)); off["v347_flags"]["employer_phrasings_v348"] = False; rp.v347_load_flags(off)
check("E: flag off -> no statement from the new phrasings", rp.v347_hiring_identity("UST is searching for a skilled engineer.", "UST")["employer_statements"] == [])
rp.v347_load_flags(master)

# ---- H hook fallback ----------------------------------------------------------------------------------------------
check("H: title normalization 'Software Developer- Full Stack' -> 'Software Developer Full Stack'", rp.v348_normalize_title("Software Developer- Full Stack") == "Software Developer Full Stack")
check("H: title normalization keeps inner hyphens ('Back-End Engineer')", rp.v348_normalize_title("Back-End Engineer,") == "Back-End Engineer")
zjd = rp.clean_jd_text((H / "jds" / "zoro_fullstack.txt").read_text())
check("H: zoro role summary is the 'Zoro is hiring a ... to ...' sentence", rp.v348_role_summary(zjd).startswith("Zoro is hiring a Full Stack Software Developer to build"), rp.v348_role_summary(zjd))
check("H: 'About the role' paragraph", rp.v348_role_summary("Intro\nAbout the role\nYou will build the payment APIs that our merchants rely on every day.\nRequirements") .startswith("You will build the payment APIs"))
check("H: no role summary in a bare requirements list", rp.v348_role_summary("Requirements\n- Python\n- SQL") == "")
plan = {"application": {"role": MAN["zoro_fullstack"]["role"]}}
d = rp.v347_hook_detail(MAN["zoro_fullstack"]["hook"], plan, zjd)
check("H: zoro stand-in hook is now specific (shares words with the role summary)", d["ok"] and d.get("role_text_source") == "role_summary" and "customer" in d.get("shared_words", []), d)
off = json.loads(json.dumps(master)); off["v347_flags"]["hook_fallback_v348"] = False; rp.v347_load_flags(off)
d0 = rp.v347_hook_detail(MAN["zoro_fullstack"]["hook"], plan, zjd)
check("H: flag off -> the 7c verdict (not specific)", d0["ok"] is False and "role_text_source" not in d0, d0)
rp.v347_load_flags(master)
d1 = rp.v347_hook_detail("I want to tune ranking models for search.", {"application": {"role": "Backend Engineer"}}, "Responsibilities:\n- Build backend APIs for payments\n- Own services")
check("H: a posting with responsibilities is not checked against a summary", "role_text_source" not in d1 and not d1["ok"], d1)


# ---- end-to-end ---------------------------------------------------------------------------------------------------
def run(name, extra=()):
    m = MAN[name]
    td = pathlib.Path(tempfile.mkdtemp()); dd = td / name; dd.mkdir()
    plan = json.loads(json.dumps(TPL)); a = plan["application"]
    a.update({"company": m["company"], "role": m["role"], "location": m["location"], "visa_sponsorship": "Not stated in the posting.", "source": "Audit", "application_date": "2026-10-13"})
    plan["cover_letter"]["team_focus"] = m["team_focus"]; plan["cover_letter"]["hook"] = m.get("hook", "")
    if m.get("closing") and not m["closing"].startswith("I would welcome the chance"): plan["cover_letter"]["closing"] = m["closing"]
    a.update(m.get("app_extra", {}))
    if m.get("tagline"): plan["tagline_text"] = m["tagline"]
    for k in ("prefer_variants", "jd_requirements_extra"):
        if m.get(k): plan[k] = m[k]
    (dd / "plan.json").write_text(json.dumps(plan, indent=1))
    subprocess.run([sys.executable, "-I", "resume_pipeline_v3_2.py", V349B_OFF, "--template", "Resume_Template_CURRENT.tex", "--master", "master.json", "--plan", str(dd / "plan.json"),
                    "--jd", str(H / "jds" / (name + ".txt")), "--out-dir", str(dd / "out")] + (["--regression-allow-missing-title"] if m.get("legacy_no_title") else []) + list(extra),
                   cwd=SRC, capture_output=True, text=True)
    snap = td / "snap"; gate.snapshot(str(td), str(snap))
    return td, snap / name


for name in ("zoro_fullstack", "ust_software_engineer"):
    td, sn = run(name, ["--regression-v347-flags-off=graduation_dec2026_v348,start_date_parse_v348,bank_wording_v348,fleet_language_model_v348,fleet_repick_v348,skills_lines_v348,heading_move_v348,closing_proof_map_v348,closing_specific_v348,jd_sections_v349,years_range_v349,fit_guard_v349,bullet_score_v349,ranker_v349,date_order_v349,proof_on_page_v349,copy_rule_v349,skills_dedupe_v349,company_key_v349"])   # v3.4.8b / v3.4.8c: later changes go off where a build is compared with baseline_v347c
    r = json.loads((sn / "report.json").read_text())
    li = r["outreach"]["linkedin"]
    check(f"e2e {name}: PASS", r["status"] == "PASS", r.get("failures"))
    for f in ("resume.tex", "letter.txt", "tracker_row.json"):
        check(f"e2e {name}: {f} byte-identical to baseline_v347c", (sn / f).read_bytes() == (BASE / name / f).read_bytes())
    check(f"e2e {name}: block_md O1 format", not gate8.block_md_problems(li.get("block_md", ""), li["notes"]), gate8.block_md_problems(li.get("block_md", ""), li["notes"]))
    check(f"e2e {name}: four notes, all pass O2", set(li["notes"]) == set(rp.V348_AUDIENCES) and not any(P(v, li.get("requisition_id", "")) for v in li["notes"].values()))
    check(f"e2e {name}: plain block kept, with the new notes", li.get("block", "").startswith("Company LinkedIn:") and all(v in li["block"] for v in li["notes"].values()))
    if name == "zoro_fullstack":
        check("e2e zoro: hook now specific (letter score 9.5 -> 10.0)", r["cover_letter"].get("hook_specific") is True and "hook_specific_reason" not in r["cover_letter"])
    else:
        check("e2e ust: employer statement recorded, no Notes line", r.get("hiring_identity_v347", {}).get("employer_statements") == ["UST"] and not any(str(x).startswith("Posted under") for x in r.get("notes", [])))
    shutil.rmtree(td, ignore_errors=True)

# ---- all three flags off == baseline_v347c ---------------------------------------------------------------------------
for name in ("zoro_fullstack", "ust_software_engineer", "alml_engineer"):
    td, sn = run(name, ["--regression-v347-flags-off=" + ",".join(NEW + ("graduation_dec2026_v348",) + tuple("start_date_parse_v348,bank_wording_v348,fleet_language_model_v348,fleet_repick_v348,skills_lines_v348,heading_move_v348,closing_proof_map_v348,closing_specific_v348,jd_sections_v349,years_range_v349,fit_guard_v349,bullet_score_v349,ranker_v349,date_order_v349,proof_on_page_v349,copy_rule_v349,skills_dedupe_v349,company_key_v349".split(",")))])
    sub = td / "base"; sub.mkdir(); shutil.copytree(BASE / name, sub / name)
    dd = gate.diffs(sub, sn.parent)
    check(f"flags off: {name} with the three v3.4.8a flags off identical to baseline_v347c (timing normalized)", not dd, dd[:3])
    shutil.rmtree(td, ignore_errors=True)

# ---- instructions and hash lock -------------------------------------------------------------------------------------
ins = (H.parent / "2_PROJECT_INSTRUCTIONS_paste.txt").read_text(encoding="utf-8")
check("instructions under 7,600 characters", len(ins) < 7600, len(ins))
check("instructions: version v3.4.8a or later", "v3.4.8a" in ins or "v3.4.8b" in ins or "v3.4.8c" in ins or "v3.4.9a" in ins or "v3.4.9b" in ins)
check("instructions: step h prints block_md", "Outreach: print report.json outreach.linkedin.block_md exactly (markdown links; each note in its own text block). Jay sends the notes." in ins)
check("instructions: hook may copy from the role summary when no responsibilities", "role summary" in ins)
for f in ("resume_pipeline_v3_2.py", "master.json", "bullet_bank.json", "Resume_Template_CURRENT.tex", "Master_Resume_Context_LEAN_CURRENT_v3_2.md"):
    hsh = hashlib.sha256((SRC / f).read_bytes()).hexdigest()
    check(f"hash lock lists {f}", f"{f} sha256={hsh}" in ins)
md = (SRC / "Master_Resume_Context_LEAN_CURRENT_v3_2.md").read_text(encoding="utf-8")
check("context md: section 0-v348a before 0-v347c", md.find("## 0-v348a)") != -1 and md.find("## 0-v348a)") < md.find("## 0-v347c)"))
check("context md pointer in master.json matches", master["source"]["master_markdown_sha256"] == hashlib.sha256(md.encode("utf-8")).hexdigest())
check("bank unchanged until v3.4.8c (the template changes in v3.4.8b: Education date only; v3.4.8c adds the W and F1 variants)", hashlib.sha256((SRC / "bullet_bank.json").read_bytes()).hexdigest()[:8] in ("d56f0743", "6ce82778", "914805e9"))

print(f"\n{len(bad)} failing" if bad else "\nall checks pass")
sys.exit(1 if bad else 0)
