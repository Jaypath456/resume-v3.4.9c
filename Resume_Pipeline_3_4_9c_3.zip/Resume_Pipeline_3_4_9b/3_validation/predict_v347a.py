"""v3.4.7a S4: predict, BEFORE any code change, which fixtures and output lines each fix changes.

  python3 predict_v347a.py [BASELINE_DIR]   -> predicted_changes_v347a.json (default baseline: baseline_v346)

Reads only the v3.4.6 baseline outputs, the fixture postings (jds/), manifest.json and master.json. It imports no
v3.4.7a code: each scan restates its fix's rule independently, so a disagreement between the scan and the code shows up
as an unpredicted (or predicted-but-unchanged) line in the diff gate. Patterns are regexes over the gate's lines: text
lines for resume.tex / letter.txt, flattened "path: value" lines for the JSON files."""
import html, json, re, sys, pathlib

H = pathlib.Path(__file__).resolve().parent
BASE = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else H / "baseline_v346"
MASTER = json.loads((H.parent / "1_upload_to_ChatGPT_Sources" / "master.json").read_text())
MAN = json.loads((H / "manifest.json").read_text())


def jd(n):
    return html.unescape((H / "jds" / f"{n}.txt").read_text(encoding="utf-8"))


def built(n):
    return (BASE / n / "report.json").exists() and (BASE / n / "letter.txt").exists()


def rep(n):
    return json.loads((BASE / n / "report.json").read_text())


fixes = []

# ---------------- A1 relocation_fix --------------------------------------------------------------------------------
BUF_NY = re.compile(r"(?<![A-Za-z])(?<![A-Za-z] )Buffalo\s*,\s*(?:NY|N\.Y\.|New York)\b", re.I)
pred, scan = [], []
for m in MAN:
    n = m["name"]
    if not built(n):
        continue
    loc = str((m.get("app_extra") or {}).get("location", m.get("location", "")))
    raw = jd(n)
    letter = (BASE / n / "letter.txt").read_text()
    remote = bool(re.search(r"\bremote\b", loc + " " + raw[:400], re.I)) and not re.search(r"hybrid|onsite|on-site|in office", loc, re.I)
    placeholder = loc.strip().lower() in ("", "not stated", "n/a", "unknown")
    if remote and "relocat" in letter:
        scan.append({"fixture": n, "location": loc, "why": "remote posting whose letter mentions relocation: the sentence leaves"})
    elif not remote and not placeholder and re.search(r"buffalo", loc, re.I) and not BUF_NY.search(loc) and "relocat" not in letter:
        scan.append({"fixture": n, "location": loc, "why": "a place containing 'Buffalo' that is not Buffalo, NY, onsite/hybrid: the letter gains 'I am open to relocating.'"})
    else:
        continue
    pred += [{"fixture": n, "file": "letter_txt", "pattern": r"February 2027", "expect": "logistics sentence + I am open to relocating."},
             {"fixture": n, "file": "report", "pattern": r"^cover_letter\.(words|words_total|closing\.)", "expect": "letter word counts (and the closing if the 200-word cap shortens it)", "optional": True}]
fixes.append({"fix": "A1", "flag": "relocation_fix", "scan": scan, "predicted": pred})

# ---------------- A2 heading_tech_fix ------------------------------------------------------------------------------
NAME2PID = {p["resume_title"]["name"]: pid for pid, p in MASTER["projects"].items()}
LANG_FROM = {"JavaScript": r"React(?:JS|\.js)?|Node(?:\.js)?|TypeScript|Vite", "Python": r"Django|Flask|FastAPI|Pydantic|pytest|PyTorch|LangGraph|Streamlit|asyncio",
             "Java": r"Spring(?: Boot)?"}
FORMS = {"ReactJS": r"React(?:JS|\.js)?", "PostgreSQL": r"Postgre(?:SQL|s)", "Kubernetes (local k3d)": r"Kubernetes|k3d", "Apache Kafka": r"Kafka", "Daphne/ASGI": r"Daphne|ASGI"}


def forms(x):
    return FORMS.get(x, re.escape(re.sub(r"\s*\(.*?\)$", "", x)))


def shows(texts, x):
    rx = forms(x) + ("|" + LANG_FROM[x] if x in LANG_FROM else "")
    return sum(1 for t in texts if re.search(r"(?<![\w])(?:" + rx + r")(?![\w])", t, re.I))


def jd_named(raw, x):
    rx = forms(x) + ("|Javascript|JS" if x == "JavaScript" else "")
    return bool(re.search(r"(?<![\w])(?:" + rx + r")(?![\w])", raw, re.I if len(x) > 2 else 0))


def page_projects(tex):
    """[(pid, heading line, [tech], [bullets])] in display order."""
    out, cur = [], None
    for l in tex.splitlines():
        m = re.match(r"\\noindent\\textbf\{([^:}]+)(?::[^}]*)?\}\s*\$\|\$\s*(.*?)\s*\$\|\$", l.strip())
        if m and m.group(1) in NAME2PID:
            cur = (NAME2PID[m.group(1)], l.strip(), [x.strip() for x in m.group(2).split(",")], [])
            out.append(cur)
            continue
        if cur and l.strip().startswith("\\item "):
            cur[3].append(l.strip()[6:])
        if cur and "\\end{itemize}" in l:
            cur = None
    return out


def core(pid):
    return ["Kubernetes (local k3d)" if x == "Kubernetes" else x for x in MASTER["projects"][pid].get("header_priority_tech", [])]


def a2_removals(projs, raw):
    """{pid: [tech that leaves its heading]} by the A2 rule."""
    rem = {}
    added = {}
    for pid, _l, tech, _b in projs:
        for x in tech:
            if x not in core(pid) and jd_named(raw, x):
                added.setdefault(x, []).append(pid)
    for x, holders in added.items():
        sc = {pid: shows(b, x) for pid, _l, _t, b in projs}
        showing = [p for p in holders if sc[p] > 0]
        if showing:
            keep = max(showing, key=lambda p: (sc[p], -[q[0] for q in projs].index(p)))
            drop = [p for p in holders if p != keep]
        else:
            others = [p for p, _l, t, b in projs if p not in holders and (x in t or sc[p] > 0)]
            drop = list(holders) if others else holders[1:]
        for p in drop:
            rem.setdefault(p, []).append(x)
    return rem


pred, scan = [], []
for m in MAN:
    n = m["name"]
    if not (BASE / n / "resume.tex").exists():
        continue
    projs = page_projects((BASE / n / "resume.tex").read_text())
    rem = a2_removals(projs, jd(n))
    for pid, xs in rem.items():
        line = next(l for p, l, _t, _b in projs if p == pid)
        scan.append({"fixture": n, "project": pid, "leaves_heading": xs, "heading_before": line[:160]})
        pred.append({"fixture": n, "file": "resume_tex", "pattern": r"\\textbf\{" + re.escape(MASTER["projects"][pid]["resume_title"]["name"]),
                     "expect": f"{', '.join(xs)} leaves the {pid} heading (core stack restored)"})
        pred.append({"fixture": n, "file": "report", "pattern": r"^heading_tech_v347", "expect": "report records the move"})
fixes.append({"fix": "A2", "flag": "heading_tech_fix", "scan": scan, "predicted": pred})

# ---------------- A3 identity_fix ----------------------------------------------------------------------------------
ORG = r"((?:[A-Z][\w&.'’-]*)(?:[ \t]+(?:[A-Z][\w&.'’-]*|of|and|&)){0,5})"
P_OPEN = re.compile(r"(?m)(?:^|(?<=[.!?]\s)|(?<=\*\*))" + ORG + r"(?:,[^.\n]{0,160}?)?\s+(?i:has\s+(?:multiple\s+|several\s+|\d+\s+|many\s+)?(?:job\s+)?openings?)\b")
P_HIRE = re.compile(r"(?m)(?:^|(?<=[.!?]\s)|(?<=\*\*))" + ORG + r"\s+(?i:is\s+(?:currently\s+|now\s+)?hiring)\b")
P_MAIL = re.compile(r"(?i)send\s+(?:your\s+)?(?:resumes?|cvs?|résumés?)\s+(?:\w+\s+){0,3}?to\s*:?\s*\**\s*[A-Za-z0-9._%+-]+@([A-Za-z0-9-]+)(?:\.[A-Za-z0-9-]+)*\.[a-z]{2,}")
P_LABEL = re.compile(r"(?im)^[\s*#_]*company[\s*_]*:[\s*_]*([^\n*]+?)[\s*_]*$")
SUFFIX = re.compile(r"\b(?:llc|inc|corp|corporation|co|ltd|limited|technologies|technology|group|holdings|plc|lp|llp)\b\.?", re.I)


def key(s):
    return re.sub(r"[^a-z0-9 ]", "", SUFFIX.sub("", str(s).lower())).split()


def same(a, b):
    ka, kb = key(a), key(b)
    return bool(ka and kb and (ka[0] == kb[0] or " ".join(ka) in " ".join(kb) or " ".join(kb) in " ".join(ka)))


pred, scan = [], []
for m in MAN:
    n = m["name"]
    if not built(n):
        continue
    raw = re.sub(r"\*\*", "", jd(n))
    company = str((m.get("app_extra") or {}).get("company", m["company"]))
    emp = [x.group(1).strip() for x in P_OPEN.finditer(raw)] + [x.group(1).strip() for x in P_HIRE.finditer(raw)]
    mail = [x.group(1) for x in P_MAIL.finditer(raw)]
    label = [x.group(1).strip() for x in P_LABEL.finditer(raw)]
    if not (emp or mail or label):
        continue
    employer = emp[0] if emp else (mail[0] if mail else "")
    differs = bool(employer) and not same(employer, company)
    lab = next((x for x in label if not same(x, company)), "")
    entry = {"fixture": n, "company": company, "employer_statements": emp, "resume_email_domains": mail, "header_labels": label}
    letter = (BASE / n / "letter.txt").read_text()
    second = [o for o in emp + label if not same(o, company) and re.search(r"(?<!\w)" + re.escape(o) + r"(?!\w)", letter)]
    entry["letter_second_org"] = second
    scan.append(entry)
    pred.append({"fixture": n, "file": "report", "pattern": r"^hiring_identity_v347", "expect": "detected employer recorded"})
    if differs or (lab and employer and same(employer, company)):
        pred.append({"fixture": n, "file": "report", "pattern": r"^notes\[\d+\]: \"Posted under ", "expect": "Notes line: Posted under <label>; the posting names <employer> as the employer"})
    if second:
        pred.append({"fixture": n, "file": "report", "pattern": r"cover_letter_two_organizations|^status|^failures", "expect": "letter names a second organization: FAIL"})
fixes.append({"fix": "A3", "flag": "identity_fix", "scan": scan, "predicted": pred})

# ---------------- A4 report_fix ------------------------------------------------------------------------------------
pred, scan = [], []
for m in MAN:
    n = m["name"]
    if not (BASE / n / "report.json").exists():
        continue
    r = rep(n)
    moved = [c["change"] for c in r.get("verify_changes_v344", []) or [] if not c.get("jd_line")]
    if moved:
        scan.append({"fixture": n, "moved": moved})
        pred.append({"fixture": n, "file": "report", "pattern": r"^(verify_changes_v344|internal_changes)\b", "expect": f"{len(moved)} unquoted entries move to internal_changes"})
fixes.append({"fix": "A4", "flag": "report_fix", "scan": scan, "predicted": pred})

# ---------------- A5 outreach_fix ----------------------------------------------------------------------------------
pred, scan = [], []
for m in MAN:
    n = m["name"]
    if not (BASE / n / "outreach.json").exists():
        continue
    t = (BASE / n / "outreach.json").read_text()
    if "Not%20stated" in t or "Not stated" in t:
        scan.append({"fixture": n, "urls_with_not_stated": t.count("Not%20stated")})
        for f, pre in (("outreach", ""), ("report", r"outreach\.")):
            pred.append({"fixture": n, "file": f, "pattern": r"^" + pre + r"linkedin\.(people\.|block|company_status)", "expect": "people links without the company keyword; block says the company is not stated"})
fixes.append({"fix": "A5", "flag": "outreach_fix", "scan": scan, "predicted": pred})

# ---------------- A6 hook_reason_fix -------------------------------------------------------------------------------
pred, scan = [], []
for m in MAN:
    n = m["name"]
    if not (BASE / n / "report.json").exists():
        continue
    if (rep(n).get("cover_letter") or {}).get("hook_specific") is False:
        scan.append({"fixture": n, "hook": m.get("hook", "")[:120]})
        pred.append({"fixture": n, "file": "report", "pattern": r"^cover_letter\.hook_specific_reason", "expect": "which test failed"})
fixes.append({"fix": "A6", "flag": "hook_reason_fix", "scan": scan, "predicted": pred})

out = {"note": "Written by predict_v347a.py from the v3.4.6 baseline before any v3.4.7a code change. 'justified' lists unpredicted changes on "
               "non-original, non-holdout fixtures with a reason (empty unless DIFF_REPORT_v347a.md explains one).",
       "baseline": str(BASE.name), "fixes": fixes, "justified": []}
(H / "predicted_changes_v347a.json").write_text(json.dumps(out, indent=1, ensure_ascii=False) + "\n")
for f in fixes:
    print(f["fix"], f["flag"], "fixtures:", len({s["fixture"] for s in f["scan"]}), sorted({s["fixture"] for s in f["scan"]})[:30])
