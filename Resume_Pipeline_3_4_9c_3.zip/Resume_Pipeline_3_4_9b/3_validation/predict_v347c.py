"""v3.4.7c: predict, BEFORE any code change, which fixtures and output lines the strict_fleet rule (C1) changes.

  python3 predict_v347c.py [BASELINE_DIR] [BASELINE_RUN_DIR]   -> predicted_changes_v347c.json
      BASELINE_DIR      default baseline_v347b (snapshot of the unmodified v3.4.7b outputs)
      BASELINE_RUN_DIR  the full v3.4.7b run folder (resolved_plan.json gives the selected bullet ids); required

C1 rule restated without the v3.4.7c code: GoingOnce's Fleet bullet (goingonce.fleet.a) stays only on a posting with a
supply-chain / warehouse / logistics / vehicle-fleet line (the v3.4.7b B4 logistics test). Anywhere else it is replaced
by the best-scoring other GoingOnce bullet with the same line count, a new evidence id and a verb no other page bullet
uses (the v3.4.7b B4 score). The letter changes only where it carried the Fleet fact (its sentence becomes the
replacement bullet's sentence); the outreach block likewise. It imports no v3.4.7c code: the one shared piece is the
v3.4.7b posting cleaner / role-line parser, imported from the unmodified v3.4.7b pipeline (SRC7B)."""
import importlib.util, json, os, re, sys, pathlib

H = pathlib.Path(__file__).resolve().parent
BASE = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else H / "baseline_v347b"
RUN = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else None
assert RUN, "predict_v347c needs the v3.4.7b run folder (bank_selection)"
SRC7B = pathlib.Path(os.environ.get("SRC7B", H.parent / "1_upload_to_ChatGPT_Sources"))
MASTER = json.loads((SRC7B / "master.json").read_text())
BANK = json.loads((SRC7B / "bullet_bank.json").read_text())
MAN = json.loads((H / "manifest.json").read_text())
sys.argv = [sys.argv[0]]
_sp = importlib.util.spec_from_file_location("rp7b", SRC7B / "resume_pipeline_v3_2.py")
RP = importlib.util.module_from_spec(_sp)
_sp.loader.exec_module(RP)
assert RP.PIPELINE_VERSION == "v3.4.7b", "predict_v347c must read the unmodified v3.4.7b pipeline (set SRC7B)"

# Jay's allowlist (2026-10-18): the 22 existing fixtures NOTES_v3_4_7b.md lists for the Strict variant, plus 3 postings
ALLOW = sorted("""amplitude anthropic_it booz_allen brillio bti cardinal cdi flowgen harvey inspire11 monti ng_fullstack quora raydar_swe
research_phd roblox rocketmoney rockstar sparkline tiktok_appsec twitch_se1 vindexa alml_engineer meritore_capgemini zoro_fullstack""".split())
FLEET = "goingonce.fleet.a"
LOGI = re.compile(r"\bwarehous\w*|\blogistic\w*|\bsupply[- ]chains?\b|\bfulfil+ment\b|\bcold storage\b|\bfreight\b|\bdistribution cent\w+|\binventory\b|\btransportation\b|"
                  r"\b(?:vehicle|truck|delivery|rental|car|van|bus)\s+fleets?\b|\bfleet (?:management|operations|vehicles?|logistics|maintenance)\b|\btrucking\b|\bshipments?\b|\bshipping\b(?=\s+(?:and receiving|carriers?|costs?|rates?|labels?|logistics|operations|routes?|containers?|lanes?|docks?|centers?|partners?\b(?! conversation)))|\b(?:ground|freight|parcel|package|order|outbound|inbound) shipping\b", re.I)
STOP = set("""a an the and or of to in on for with by from at as is are be been was were this that these those it its into via per using use used
your you our we they their them will can may must should would could also plus such other than more most very well across within over under
work working experience years year strong ability able skills skill knowledge understanding including include team teams role build building built
new real every each any all both one two three who what which while when where so not no""".split())
LIMIT = re.compile(r"\bhallucinat\w*|\bgrounding\b|llm (?:limitations?|challenges?)|knowledge cutoffs?|\bunsupported claims?\b|\bfactual(?:ity)?\b", re.I)
AI_GO = ("goingonce.agents.a", "goingonce.agents.s1", "goingonce.negotiate.a", "goingonce.determ.a")
FLEET_FACT = re.compile(r"truckloads?|rental cars", re.I)   # the Fleet bullet's fact in letter / closing / outreach wording


def stems(t):
    return {w[:6] for w in re.findall(r"[a-z][a-z0-9+#-]{2,}", t.casefold().replace("-", " ")) if w not in STOP}


def score(v, post, ai, lim):
    s = len(stems(" ".join([v.get("text", "")] + list(v.get("jd_terms", []) or []))) & post)
    if ai and v["id"] in AI_GO:
        s += 3
    if lim and v["id"].startswith(("ripple.", "tailor_pipeline.")) and re.search(r"\bclaims?\b", v.get("text", ""), re.I):
        s += 3
    return s


def jd(n):
    return RP.clean_jd_text((H / "jds" / f"{n}.txt").read_text(encoding="utf-8"))


VM = {v["id"]: v for p in BANK["projects"].values() for v in p}
LS = MASTER["cover_letter_bank"]["letter_sentences"]["goingonce"]
CP = MASTER["cover_letter_bank"]["closing_proofs"]
OP = MASTER.get("outreach_proofs", {})
tex_rx = lambda i: re.escape(VM[i]["text"][:40].replace("%", r"\%"))
pred, scan, nofix = [], [], []
for m in MAN:
    n = m["name"]
    rp = RUN / n / "out" / "resolved_plan.json"
    if not (BASE / n / "resume.tex").exists() or not rp.exists():
        continue
    sel = json.loads(rp.read_text()).get("bank_selection") or {}
    ids = sel.get("goingonce") or []
    if FLEET not in ids:
        continue
    raw = jd(n)
    lines = RP._v342_role_text(raw)
    title = str((m.get("app_extra") or {}).get("role", m.get("role", "")))
    logi = next((l for l in lines if LOGI.search(l)), "") or (title if LOGI.search(title) else "") or (m.get("company", "") if LOGI.search(m.get("company", "")) else "")
    if logi:
        scan.append({"fixture": n, "keep": "logistics posting", "line": logi[:160]})
        continue
    if ids.index(FLEET) == 0:
        nofix.append({"fixture": n, "reason": "Fleet is the project's lead bullet (never moved)"}); continue
    post = stems(" ".join(lines))
    ai = bool(re.search(r"\b(?:ai|ml|llm|machine learning|agents?|genai|generative|deep learning|data scien\w+)\b", title + " " + " ".join(lines[:30]), re.I))
    lim = any(LIMIT.search(l) for l in lines)
    pool = [v for v in BANK["projects"]["goingonce"] if v.get("status") == "ok"]
    ev = {VM[i].get("main_evidence_id") for i in ids if i != FLEET}
    verbs = {str(VM[i].get("verb", "")).casefold() for p in sel.values() for i in p if i in VM and i != FLEET}
    cands = [v for v in pool if v["id"] not in ids and v["id"] != FLEET and v.get("lines") == VM[FLEET].get("lines")
             and v.get("main_evidence_id") not in ev and str(v.get("verb", "")).casefold() not in verbs]
    if not cands:
        nofix.append({"fixture": n, "reason": "no GoingOnce bullet with the same line count, a new evidence id and a unique verb"}); continue
    best = max(cands, key=lambda v: (score(v, post, ai, lim), -pool.index(v)))
    letter = (BASE / n / "letter.txt").read_text() if (BASE / n / "letter.txt").exists() else ""
    outreach = (BASE / n / "outreach.json").read_text() if (BASE / n / "outreach.json").exists() else ""
    rec = {"fixture": n, "before": FLEET, "after": best["id"], "after_text": best["text"], "allowlisted": n in ALLOW,
           "letter_has_fleet_fact": bool(FLEET_FACT.search(letter)), "outreach_has_fleet_fact": bool(FLEET_FACT.search(outreach))}
    scan.append(rec)
    ev_new = best.get("main_evidence_id")
    pred += [{"fixture": n, "file": "resume_tex", "pattern": tex_rx(FLEET) + "|" + tex_rx(best["id"]), "expect": f"GoingOnce bullet {FLEET} -> {best['id']}"},
             {"fixture": n, "file": "report", "pattern": r"^strict_fleet_v347c\.", "expect": "C1 swap log"}]
    if rec["letter_has_fleet_fact"]:
        alt = [LS.get(ev_new, ""), CP.get(ev_new, "")]
        pred.append({"fixture": n, "file": "letter_txt", "pattern": FLEET_FACT.pattern + "".join("|" + re.escape(a[:40]) for a in alt if a),
                     "expect": "the letter's Fleet sentence becomes the replacement bullet's sentence"})
        pred.append({"fixture": n, "file": "report", "pattern": r"^cover_letter\.|^closing_v344|^letter_", "expect": "report copy of the letter", "optional": True})
    if rec["outreach_has_fleet_fact"]:
        pred.append({"fixture": n, "file": "outreach", "pattern": FLEET_FACT.pattern + ("|" + re.escape(OP.get(best["id"], OP.get(ev_new, ""))[:40]) if OP.get(best["id"], OP.get(ev_new)) else ""),
                     "expect": "outreach proof follows the replacement bullet"})
fixes = [{"fix": "C1", "flag": "strict_fleet", "scan": scan, "predicted": pred}]
swapped = sorted(s["fixture"] for s in scan if "after" in s)
out = {"note": "Written by predict_v347c.py from the v3.4.7b baseline before any v3.4.7c code change. 'justified' lists unpredicted changes "
               "with the reason (added after a gate run, never silently).",
       "baseline": BASE.name, "allowlist": ALLOW,
       "c1": {"predicted_swaps": swapped, "outside_allowlist": sorted(set(swapped) - set(ALLOW)), "allowlist_not_predicted": sorted(set(ALLOW) - set(swapped)), "no_replacement": nofix},
       "fixes": fixes,
       "justified": [{"fixture": "*", "file": "report", "pattern": r"^pipeline_version: ",
                      "reason": "version label v3.4.7b -> v3.4.7c (not a fix): report.json carries pipeline_version only on the two expected stops"}]}
(H / "predicted_changes_v347c.json").write_text(json.dumps(out, indent=1, ensure_ascii=False) + "\n")
print("C1 predicted swaps:", len(swapped), ", ".join(swapped))
print("outside allowlist:", out["c1"]["outside_allowlist"], "| allowlisted but not predicted:", out["c1"]["allowlist_not_predicted"], "| no replacement:", nofix)
for s in scan:
    if "after" in s:
        print(f"  {s['fixture']:22} -> {s['after']:22} letter_fact={s['letter_has_fleet_fact']} outreach_fact={s['outreach_has_fleet_fact']}")
