"""v3.4.9a: dump the ranker's inputs for every fixture (used by predict_v349a_5.py).

  SRC=<Sources dir> python3 rank_dump_v349a.py DUMP_DIR [fixtures...]

Copies SRC to a temporary folder, adds a test-only instrumentation block to the copy (the Sources are never edited), and
runs each fixture through run_all.py up to the ranking stage. Each fixture gets DUMP_DIR/<fixture>/out/rankdump.json:
the role family and its preferred / avoided projects, the theme-first standalone scores with their parts (theme,
requirement hits, brand bonus, penalties, theme strengths), the theme vector, the requirement groups, the legacy v3.2
scores, the greedy picks, and the ranking after the base ranker and after every override. The run stops right after
ranking, so no PDF is built. Bash calls have a time limit: pass fixture names to run a batch.
"""
import os, shutil, subprocess, sys, tempfile, pathlib

H = pathlib.Path(__file__).resolve().parent
PATCHES = [
    ("from copy import deepcopy\n", "from copy import deepcopy\n_INST = {}\n"),
    ('''        standalone[pid] = round(th + rq + brand_bonus(pid) + penalties(pid), 3)
    selected: list[str] = []''',
     '''        standalone[pid] = round(th + rq + brand_bonus(pid) + penalties(pid), 3)
        _INST.setdefault("parts", {})[pid] = {"th": round(th, 3), "rq": round(rq, 3), "brand": brand_bonus(pid), "pen": penalties(pid),
            "hits": [[h[1], h[2]] for h in req_hits[pid]], "strength": strength.get(pid, {})}
    _INST["groups"] = [(g[0], g[1][:3], g[3]) for g in groups]
    _INST["vec"] = vec
    selected: list[str] = []'''),
]
TAIL = '''

# ---- INSTRUMENTATION (rank_dump_v349a.py test copy only, never shipped in the Sources) ----
import sys as _isys
_inst_base = _apply_auto_ranking_v341
def _apply_auto_ranking_v341(raw_plan, master, raw_jd):
    _inst_base(raw_plan, master, raw_jd)
    _INST["after_base"] = list(raw_plan.get("ranking") or [])
    _INST["v33"] = deepcopy(raw_plan.get("_v33_rank"))
_inst_final = apply_auto_ranking
def apply_auto_ranking(raw_plan, master, raw_jd):
    auto = raw_plan.get("ranking") == "auto"
    _inst_final(raw_plan, master, raw_jd)
    prof = role_family_profile(raw_plan, master) or {}
    d = {"auto": auto, "family": raw_plan.get("role_family"), "preferred": prof.get("preferred_projects"), "avoid": prof.get("avoid_projects"),
         "final": raw_plan.get("ranking"), "lead_language": raw_plan.get("_v342_lead_language"), "llm_rel": raw_plan.get("_v342_llm_reliability"),
         "v345": raw_plan.get("_v345_override"), "dist": raw_plan.get("_v343_distributed"), "domain": raw_plan.get("_jd_domain"), **_INST}
    od = Path(_isys.argv[_isys.argv.index("--out-dir") + 1])
    od.mkdir(parents=True, exist_ok=True)
    (od / "rankdump.json").write_text(json.dumps(d, indent=1, default=str))
    raise SystemExit(0)
'''


def main(dump: str, *names: str) -> None:
    src = pathlib.Path(os.environ.get("SRC", H.parent / "1_upload_to_ChatGPT_Sources"))
    with tempfile.TemporaryDirectory() as tmp:
        cp = pathlib.Path(tmp) / "src"
        shutil.copytree(src, cp, ignore=shutil.ignore_patterns("__pycache__"))
        f = cp / "resume_pipeline_v3_2.py"
        s = f.read_text(encoding="utf-8")
        for a, b in PATCHES:
            assert s.count(a) == 1, "instrumentation anchor not found: " + a[:60]
            s = s.replace(a, b)
        anchor = '\n\n\nif __name__ == "__main__":'
        assert s.count(anchor) == 1
        f.write_text(s.replace(anchor, TAIL + anchor), encoding="utf-8")
        # the hash lock covers master / bank / template only, so the instrumented copy still runs
        env = dict(os.environ, SRC=str(cp), OUT=str(pathlib.Path(dump).resolve()))
        subprocess.run([sys.executable, str(H / "run_all.py"), *names], env=env, stdout=subprocess.DEVNULL)
    n = len(list(pathlib.Path(dump).glob("*/out/rankdump.json")))
    print(f"rank dumps in {dump}: {n}")


if __name__ == "__main__":
    main(*sys.argv[1:])
