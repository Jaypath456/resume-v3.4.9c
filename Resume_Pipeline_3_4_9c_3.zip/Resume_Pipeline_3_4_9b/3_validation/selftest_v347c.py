"""v3.4.7c self-test: python3 selftest_v347c.py  -> prints each check and exits 1 on any failure.
C1 strict_fleet: the flag, the logistics test, end-to-end builds (a swap, a swap whose letter carried the Fleet fact, a
FAIL-CLOSED keep, a logistics posting that keeps Fleet), each compared with baseline_v347b (only the GoingOnce bullet,
the one letter sentence and the swap log may differ), the strict_fleet-off equivalence with baseline_v347b, and the
instructions / hash lock."""
import hashlib, json, pathlib, re, shutil, subprocess, sys, tempfile, importlib.util
H = pathlib.Path(__file__).resolve().parent
SRC = H.parent / "1_upload_to_ChatGPT_Sources"
sys.argv = [sys.argv[0]]
spec = importlib.util.spec_from_file_location("rp", SRC / "resume_pipeline_v3_2.py"); rp = importlib.util.module_from_spec(spec); spec.loader.exec_module(rp)
master = json.loads((SRC / "master.json").read_text())
sys.path.insert(0, str(H)); import diff_gate_v347 as gate   # noqa: E402
MAN = {m["name"]: m for m in json.loads((H / "manifest.json").read_text())}
TPL = json.loads((SRC / "plan_template.json").read_text())
BASE = H / "baseline_v347b"
bank = json.loads((SRC / "bullet_bank.json").read_text()); vm = {v["id"]: v for p in bank["projects"].values() for v in p}
FLEET_TXT = vm["goingonce.fleet.a"]["text"]
LS = master["cover_letter_bank"]["letter_sentences"]["goingonce"]
V349B_OFF = "--regression-v347-flags-off=bank_format_v349b,format_letter_v349b,bold_results_v349b,skills_cap5_v349b,letter_trims_v349b"   # v3.4.9b: these end-to-end checks compare with A4 baselines, so the format flags are off
bad = []
V348 = "outreach_v348,employer_phrasings_v348,hook_fallback_v348,graduation_dec2026_v348,start_date_parse_v348,bank_wording_v348,fleet_language_model_v348,fleet_repick_v348,skills_lines_v348,heading_move_v348,closing_proof_map_v348,closing_specific_v348,jd_sections_v349,years_range_v349,fit_guard_v349,bullet_score_v349,ranker_v349,date_order_v349,proof_on_page_v349,copy_rule_v349,skills_dedupe_v349,company_key_v349"   # v3.4.8a / v3.4.8c: later flags go off where a build is compared with baseline_v347b
V348_OFF = "--regression-v347-flags-off=" + V348
GRAD_OFF = "--regression-v347-flags-off=graduation_dec2026_v348,start_date_parse_v348,bank_wording_v348,fleet_language_model_v348,fleet_repick_v348,skills_lines_v348,heading_move_v348,closing_proof_map_v348,closing_specific_v348,jd_sections_v349,years_range_v349,fit_guard_v349,bullet_score_v349,ranker_v349,date_order_v349,proof_on_page_v349,copy_rule_v349,skills_dedupe_v349,company_key_v349"   # v3.4.8b / v3.4.8c: later changes go off where a build is compared with baseline_v347b


def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else f"  -> {detail}"))
    if not ok:
        bad.append(name)


check("pipeline version", rp.PIPELINE_VERSION in ("v3.4.7c", "v3.4.8a", "v3.4.8b", "v3.4.8c", "v3.4.9a", "v3.4.9b"), rp.PIPELINE_VERSION)   # v3.4.8a build keeps these checks
fl = master.get("v347_flags") or {}
check("flags: master.json v347_flags has strict_fleet, true", fl.get("strict_fleet") is True, fl)
check("flags: strict_fleet is a known flag; the ten earlier flags are still true", "strict_fleet" in rp.V347_FLAG_NAMES and all(fl.get(k) is True for k in rp.V347_FLAG_NAMES))
off = json.loads(json.dumps(master)); off["v347_flags"]["strict_fleet"] = False
got = rp.v347_load_flags(off)
check("flags: strict_fleet false turns only C1 off", got["strict_fleet"] is False and all(v for k, v in got.items() if k != "strict_fleet"), got)
rp.v347_load_flags(master)
check("C1: the 7b test switch V347B_STRICT_FLEET is gone", not hasattr(rp, "V347B_STRICT_FLEET"))

# ---- logistics test (the rule's trigger) -----------------------------------------------------------------------
L = lambda t: bool(rp._V347B_LOGISTICS.search(t))
for t, want in [("Manage warehouse inventory systems", True), ("Build supply-chain visibility tools", True), ("Optimize our vehicle fleet routing", True),
                ("Own fleet management software for trucks", True), ("Work with shipping carriers and rates", True),
                ("A track record of shipping ML systems into production", False), ("Shipping meaningful software every week", False),
                ("Monitor our device fleet telemetry", False), ("Build full-stack e-commerce features", False)]:
    check(f"C1 logistics test: {t!r} -> {want}", L(t) == want)


# ---- end-to-end builds -----------------------------------------------------------------------------------------------
def run(name, extra=()):
    m = MAN[name]
    td = pathlib.Path(tempfile.mkdtemp()); d = td / name; d.mkdir()
    plan = json.loads(json.dumps(TPL)); a = plan["application"]
    a.update({"company": m["company"], "role": m["role"], "location": m["location"], "visa_sponsorship": "Not stated in the posting.", "source": "Audit", "application_date": "2026-10-13"})
    plan["cover_letter"]["team_focus"] = m["team_focus"]; plan["cover_letter"]["hook"] = m.get("hook", "")
    if m.get("closing") and not m["closing"].startswith("I would welcome the chance"): plan["cover_letter"]["closing"] = m["closing"]
    a.update(m.get("app_extra", {}))
    if m.get("tagline"): plan["tagline_text"] = m["tagline"]
    for k in ("prefer_variants", "jd_requirements_extra"):
        if m.get(k): plan[k] = m[k]
    (d / "plan.json").write_text(json.dumps(plan, indent=1))
    subprocess.run([sys.executable, "-I", "resume_pipeline_v3_2.py", V349B_OFF, "--template", "Resume_Template_CURRENT.tex", "--master", "master.json", "--plan", str(d / "plan.json"),
                    "--jd", str(H / "jds" / (name + ".txt")), "--out-dir", str(d / "out")] + (["--regression-allow-missing-title"] if m.get("legacy_no_title") else []) + list(extra),
                   cwd=SRC, capture_output=True, text=True)
    snap = td / "snap"; gate.snapshot(str(td), str(snap))
    return td, snap / name


def skills(tex):
    return [l for l in tex.splitlines() if re.match(r"\s*\\item \\textbf\{", l)]


def compare(name, snap):
    b = BASE / name
    tb, tn = (b / "resume.tex").read_text(), (snap / "resume.tex").read_text()
    lb, ln = tb.splitlines(), tn.splitlines()
    changed = [(x, y) for x, y in zip(lb, ln) if x != y] if len(lb) == len(ln) else None
    return tb, tn, changed, (b / "letter.txt").read_text(), (snap / "letter.txt").read_text(), json.loads((snap / "report.json").read_text())


# alml: a swap (Fleet -> Negotiate), letter untouched
td, sn = run("alml_engineer", [GRAD_OFF]); tb, tn, ch, lb, ln, r = compare("alml_engineer", sn)
check("e2e alml: PASS", r["status"] == "PASS", r.get("failures"))
check("e2e alml: Fleet bullet gone", FLEET_TXT not in tn)
check("e2e alml: exactly one .tex line changed, Fleet -> another GoingOnce bullet", ch is not None and len(ch) == 1 and FLEET_TXT in ch[0][0]
      and any(v["text"] in ch[0][1] for k, v in vm.items() if k.startswith("goingonce.") and k != "goingonce.fleet.a"), ch)
check("e2e alml: Skills lines identical to baseline_v347b", skills(tb) == skills(tn))
check("e2e alml: letter identical (it never used the Fleet fact)", lb == ln)
sw = (r.get("strict_fleet_v347c") or {}).get("swaps") or []
check("e2e alml: report logs the swap", len(sw) == 1 and sw[0]["before"] == "goingonce.fleet.a" and sw[0]["after_text"] in tn, sw)
check("e2e alml: Fit unchanged", r["effective_fit"] == json.loads((BASE / "alml_engineer" / "report.json").read_text())["effective_fit"])
shutil.rmtree(td, ignore_errors=True)

# rockstar: the letter's Fleet sentence becomes the replacement bullet's sentence, nothing else
td, sn = run("rockstar", [GRAD_OFF]); tb, tn, ch, lb, ln, r = compare("rockstar", sn)
sw = (r.get("strict_fleet_v347c") or {}).get("swaps") or []
new = LS.get(sw[0]["after"]) or LS.get(vm[sw[0]["after"]]["main_evidence_id"], "") if sw else ""
check("e2e rockstar: PASS with a swap", r["status"] == "PASS" and len(sw) == 1, r.get("failures"))
check("e2e rockstar: letter = baseline with only the Fleet sentence replaced", bool(new) and LS["goingonce.fleet"] in lb and lb.replace(LS["goingonce.fleet"], new) == ln)
check("e2e rockstar: letter <= 200 words", len(re.findall(r"\S+", ln)) <= 200, len(re.findall(r"\S+", ln)))
check("e2e rockstar: Skills lines identical", skills(tb) == skills(tn))
shutil.rmtree(td, ignore_errors=True)

# inspire11: the only candidate (the plain-code bullet) names Claude, which Skills do not show -> FAIL-CLOSED keep
td, sn = run("inspire11", [V348_OFF]); tb, tn, ch, lb, ln, r = compare("inspire11", sn)
sub = td / "base"; sub.mkdir(); shutil.copytree(BASE / "inspire11", sub / "inspire11")
dd = gate.diffs(sub, sn.parent)
check("e2e inspire11: FAIL-CLOSED, identical to baseline_v347b (Fleet kept: Skills would need Claude API)", not dd and FLEET_TXT in tn, dd[:3])
shutil.rmtree(td, ignore_errors=True)

# us_cold: a logistics posting keeps the Fleet bullet
td, sn = run("us_cold", [GRAD_OFF]); tb, tn, ch, lb, ln, r = compare("us_cold", sn)
check("e2e us_cold: logistics posting keeps the Fleet bullet", FLEET_TXT in tn and not r.get("strict_fleet_v347c"))
shutil.rmtree(td, ignore_errors=True)

# ---- strict_fleet off == baseline_v347b ------------------------------------------------------------------------------
for name in ("alml_engineer", "rockstar", "zoro_fullstack"):
    td, sn = run(name, ["--regression-v347-flags-off=strict_fleet," + V348])
    sub = td / "base"; sub.mkdir(); shutil.copytree(BASE / name, sub / name)
    dd = gate.diffs(sub, sn.parent)
    check(f"flags off: {name} with strict_fleet off identical to baseline_v347b (timing normalized)", not dd, dd[:3])
    shutil.rmtree(td, ignore_errors=True)

# ---- instructions and hash lock -------------------------------------------------------------------------------------
ins = (H.parent / "2_PROJECT_INSTRUCTIONS_paste.txt").read_text(encoding="utf-8")
check("instructions under 7,600 characters", len(ins) < 7600, len(ins))
check("instructions: version v3.4.7c or later", "v3.4.7c" in ins or "v3.4.8a" in ins or "v3.4.8b" in ins or "v3.4.8c" in ins or "v3.4.9a" in ins or "v3.4.9b" in ins)
for f in ("resume_pipeline_v3_2.py", "master.json", "bullet_bank.json", "Resume_Template_CURRENT.tex", "Master_Resume_Context_LEAN_CURRENT_v3_2.md"):
    hsh = hashlib.sha256((SRC / f).read_bytes()).hexdigest()
    check(f"hash lock lists {f}", f"{f} sha256={hsh}" in ins)
md = (SRC / "Master_Resume_Context_LEAN_CURRENT_v3_2.md").read_text(encoding="utf-8")
check("context md: section 0-v347c before 0-v347b", md.find("## 0-v347c)") != -1 and md.find("## 0-v347c)") < md.find("## 0-v347b)"))
check("context md pointer in master.json matches", master["source"]["master_markdown_sha256"] == hashlib.sha256((SRC / "Master_Resume_Context_LEAN_CURRENT_v3_2.md").read_bytes()).hexdigest())

print(f"\n{len(bad)} failing" if bad else "\nall checks pass")
sys.exit(1 if bad else 0)
