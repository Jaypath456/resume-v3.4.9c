"""v3.4.4 acceptance audit: python3 audit_v344.py [OUT_DIR]
Checks every built fixture for: a closing that repeats a proof the letter already gives (same number, a shared
three-word phrase, or most of its content words), role-family fallback closings (<= 10% of built fixtures),
closings over 30 words, letters over 200 words (the whole letter as a reader counts it, greeting and sign-off
included), ".." anywhere in the letter / outreach / tracker / resume, and tracker_row.json columns (exactly the 11
v3.4.4 columns, Status "Applied"). Exit code 1 when any check fails."""
import json, re, sys, pathlib, os

H = pathlib.Path(__file__).resolve().parent
OUT = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path(os.environ.get("OUT", H / "out"))
COLS = ["Company", "Role", "Date Applied", "Location", "Projects Used", "Fit (High/Medium/Low)", "Resume File Name", "Status", "Source", "Outcome Date", "Blockers"]
STOP = set("a an the and or of to for with in on by into from that this each its their as at plus while using which who so it them both also my i "
           "where whose every all any one your our under over than then when only".split())
PROJECT_WORDS = {"ledgerflow", "ripple", "launchops", "goingonce", "pintos", "llm", "engine", "fraud", "thesis", "mumbai", "tech", "heinonline"}
DOTS = re.compile(r"(?<![.])\.\.(?![.])")


def words(s):
    return re.findall(r"[a-z0-9][a-z0-9'+#-]*", s.lower())


def content(s):
    return [w for w in words(s) if w not in STOP and w not in PROJECT_WORDS and len(w) >= 3]


def repeats(proof, body):
    """The closing's proof repeats the letter when it shares a number, a three-word content phrase, or >= 50% of its
    content words with the letter body."""
    why = []
    body = re.sub(r"Dear Hiring Manager,|Sincerely,|Jay Niketan Pathare", " ", body)
    nums = set(re.findall(r"\d[\d,.]*", proof))
    shared = sorted(n for n in nums if re.search(r"(?<![\d])" + re.escape(n) + r"(?![\d])", body))
    if shared:
        why.append(f"number {shared}")
    pc, bc = content(proof), content(body)
    tri = {" ".join(bc[i:i + 3]) for i in range(len(bc) - 2)}
    t = [" ".join(pc[i:i + 3]) for i in range(len(pc) - 2) if " ".join(pc[i:i + 3]) in tri]
    if t:
        why.append(f"phrase '{t[0]}'")
    stem = lambda w: w[:5]
    ps, bs = {stem(w) for w in pc}, {stem(w) for w in bc}
    if ps and len(ps & bs) / len(ps) >= 0.5:
        why.append(f"words {sorted(ps & bs)}")
    return why


def main():
    rows, problems = [], []
    built = fallback = 0
    for d in sorted(p for p in OUT.iterdir() if (p / "out" / "report.json").exists()):
        o = d / "out"
        rep = json.loads((o / "report.json").read_text())
        if rep.get("skip") and not rep.get("forced"):
            continue
        built += 1
        n = d.name
        cl = rep.get("cover_letter") or {}
        info = cl.get("closing") or {}
        txt = "".join(p.read_text(encoding="utf-8") for p in o.glob("*_Cover_Letter.txt"))
        closing = str(info.get("text") or "")
        body = txt.replace(closing, " ") if closing else txt
        proof = str(info.get("_proof") or "")
        if not proof and closing:
            m = re.search(r",\s+(?:building on|drawing on|as|which|where|like|backed by|based on|bringing|with)\b(.+)$", closing)
            proof = m.group(1) if m else closing
        why = repeats(proof, body) if closing else []
        if why:
            problems.append(f"{n}: closing repeats a letter proof ({'; '.join(why)}): {closing}")
        if info.get("family"):
            fallback += 1
        cw = len(closing.split())
        if cw > 30:
            problems.append(f"{n}: closing {cw} words")
        lw = len(txt.split())
        if lw > 200:
            problems.append(f"{n}: letter {lw} words")
        for f in [*o.glob("*_Cover_Letter.txt"), o / "outreach.json", o / "tracker_row.json", *[p for p in o.glob("*.tex") if p.name != "build_resume.tex"]]:
            if f.exists() and DOTS.search(f.read_text(encoding="utf-8")):
                problems.append(f"{n}: '..' in {f.name}")
        tr = json.loads((o / "tracker_row.json").read_text()) if (o / "tracker_row.json").exists() else {}
        if [k for k in tr if k != "company_key"] != COLS:   # v3.4.9a: company_key (tracker matching key) is not a sheet column
            problems.append(f"{n}: tracker columns {list(tr.keys())}")
        if tr.get("Status") != "Applied":
            problems.append(f"{n}: tracker Status {tr.get('Status')!r}")
        rows.append((n, cw, lw, bool(info.get("family"))))
    pct = 100.0 * fallback / built if built else 0.0
    print(f"built {built} | fallback closings {fallback} ({pct:.1f}%) | max closing {max((r[1] for r in rows), default=0)} words | "
          f"max letter {max((r[2] for r in rows), default=0)} words")
    if pct > 10.0:
        problems.append(f"fallback closings {pct:.1f}% > 10%")
    for p in problems:
        print("FAIL", p)
    print("audit_v344:", "PASS" if not problems else f"{len(problems)} problem(s)")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
