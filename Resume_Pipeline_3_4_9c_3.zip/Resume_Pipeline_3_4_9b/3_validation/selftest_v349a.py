"""v3.4.9a self-test: python3 selftest_v349a.py  -> prints each check and exits 1 on any failure.
Core-fixes build: 1 JD reader, 2 years ranges, 3 Fit guard, 4 bullet scoring, 5 ranking, 6 page order by date,
7 closing proof on the page, 8 copy rule, 9 Skills hygiene, 10 tracker company_key. Unit checks for each rule (fast;
the end-to-end evidence is the per-fix gates and golden_report.md)."""
import hashlib, json, pathlib, re, sys, importlib.util
H = pathlib.Path(__file__).resolve().parent
SRC = H.parent / "1_upload_to_ChatGPT_Sources"
sys.argv = [sys.argv[0]]
spec = importlib.util.spec_from_file_location("rp", SRC / "resume_pipeline_v3_2.py"); rp = importlib.util.module_from_spec(spec); spec.loader.exec_module(rp)
master = json.loads((SRC / "master.json").read_text())
bad = []


def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else f"  -> {detail}"))
    if not ok:
        bad.append(name)


check("PIPELINE_VERSION v3.4.9a or later", rp.PIPELINE_VERSION in ("v3.4.9a", "v3.4.9b"), rp.PIPELINE_VERSION)
NEW = ("jd_sections_v349", "years_range_v349", "fit_guard_v349", "bullet_score_v349", "ranker_v349", "date_order_v349", "proof_on_page_v349",
       "copy_rule_v349", "skills_dedupe_v349", "company_key_v349")
check("ten new flags registered, default on", all(n in rp.V347_FLAG_NAMES and rp._v347_on(n) for n in NEW))
check("master v347_flags lists the ten new flags", all(n in (master.get("v347_flags") or {}) for n in NEW), [n for n in NEW if n not in (master.get("v347_flags") or {})])
def _a4_template_sha():   # v3.4.9b: the shipped Letter template with the format flags off
    saved = dict(rp._V347_FLAGS); rp._V347_FLAGS.update({k: False for k in rp.V349B_FLAGS})
    try:
        return hashlib.sha256(rp.v349b_effective_template((SRC / "Resume_Template_CURRENT.tex").read_text(encoding="utf-8")).encode("utf-8")).hexdigest()
    finally:
        rp._V347_FLAGS.clear(); rp._V347_FLAGS.update(saved)


check("template unchanged since v3.4.8b (v3.4.9b: with the format flags off the Letter template rebuilds it exactly)", _a4_template_sha().startswith("dc281778"))
check("facts: graduation December 2026, start February 2027", master["education"]["masters"].get("graduation") == "December 2026"
      and master["education"]["masters"].get("available_to_start_work", "").startswith("February 2027"))

# 1 JD reader
jd = "About You\nWhat sets you apart:\n- Kubernetes experience\nSome examples:\n- billing systems\n(we use PostgreSQL and SQL Server)\n"
check("1 example list line is context", rp.v349_context_only("billing systems", jd))
# 2 years
check("2 '1-3 years' reads as a minimum of 1", "1 years" in rp.v349_years_view("1-3 years of experience").replace("1years", "1 years") or rp.v349_years_view("1-3 years of experience").startswith("1"))
# 6 page order
order = rp.v349_date_order(["launchops", "ripple", "ledgerflow"], master)
check("6 page order newest first (LedgerFlow Oct 2026, RIPPLE Aug 2026, LaunchOps Mar 2026)", order == ["ledgerflow", "ripple", "launchops"], order)
order2 = rp.v349_date_order(["goingonce", "ledgerflow", "ripple"], master)
check("6 a date tie keeps rank order (GoingOnce before LedgerFlow when GoingOnce ranks first)", order2 == ["goingonce", "ledgerflow", "ripple"], order2)
# 8 copy rule
check("8 bare singular tail: 'services for control plane'", rp.v349_bare_singular_tail("develop and maintain services for control plane"))
check("8 plural / mass tails are kept", not rp.v349_bare_singular_tail("write unit tests for production code") and not rp.v349_bare_singular_tail("build REST APIs for business users"))
check("8 verb pair gets 'and'", rp.v349_verb_pair("Design develop software modules") == "Design and develop software modules")
check("8 noun use is left alone ('Build test automation')", rp.v349_verb_pair("Build test automation") == "Build test automation")
plan = {"application": {"company": "DoorDash"}, "cover_letter": {"hook": "I want to improve security for our backend systems."}}
check("8 hook voice: our -> DoorDash's", not rp.v349_hook_voice(plan) and plan["cover_letter"]["hook"] == "I want to improve security for DoorDash's backend systems.", plan["cover_letter"]["hook"])
plan = {"application": {"company": "Giga"}, "cover_letter": {"hook": "I want to help us build agents."}}
check("8 hook voice: 'us' fails the build", [f["type"] for f in rp.v349_hook_voice(plan)] == ["cover_letter_hook_voice"])
check("8 copy rule: 3 content words from one responsibility line", rp.v349_from_one_line("I want to build backend data pipelines.", "Responsibilities:\n- Build backend data pipelines and APIs\n"))
# 9 Skills
st = [{"skills": {"languages_databases": ["Python", "PostgreSQL"], "frameworks_libraries": ["React", "ReactJS"], "tools": ["Docker", "JSON", "Git"]}}]
rp.v349_skills_hygiene(st, {"_raw_jd_text": "modern front ends and JSON"}, master)
sk = st[0]["skills"]
check("9 React + ReactJS -> ReactJS", sk["frameworks_libraries"] == ["ReactJS"], sk)
st2 = [{"skills": {"languages_databases": ["Python"], "frameworks_libraries": ["ReactJS", "React"], "tools": ["Git"]}}]
rp.v349_skills_hygiene(st2, {"_raw_jd_text": "Experience in React"}, master)
check("9 a posting that says React keeps its spelling (one name, never dropped)", st2[0]["skills"]["frameworks_libraries"] == ["React"], st2)
check("9 JSON moves to the Languages line", "JSON" not in sk["tools"] and "JSON" in sk["languages_databases"] and sk["languages_databases"][-1] == "PostgreSQL", sk)
# 10 company_key
k = rp.v349_company_key
check("10 'Akamai' and 'Akamai Technologies' match", k("Akamai") == k("Akamai Technologies") == "akamai")
check("10 'EBSCO Information Services' -> ebsco; 'Meritore Technologies LLC' -> meritore; 'Audible, Inc.' -> audible",
      (k("EBSCO Information Services"), k("Meritore Technologies LLC"), k("Audible, Inc.")) == ("ebsco", "meritore", "audible"))
check("10 different companies do not match", len({k("Akamai"), k("Amazon"), k("Meritore"), k("Macy's"), k("Zoro")}) == 5 and k("Macy's") == "macys")
instr = (H.parent / "2_PROJECT_INSTRUCTIONS_paste.txt")
if instr.exists():
    t = instr.read_text(encoding="utf-8")
    check("instructions under 7,600 characters", len(t) < 7600, len(t))
    check("instructions: tracker rows match on company_key and role", "company_key" in t)

print(f"\n{len(bad)} failing" if bad else "\nall checks pass")
sys.exit(1 if bad else 0)
