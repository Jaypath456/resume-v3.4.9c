"""v3.4.7b self-test: python3 selftest_v347b.py  -> prints each check and exits 1 on any failure.
B1 sponsorship polarity (labelled phrasings: negative, positive, neutral, badge, unclear), B2 OR-groups, B3 SQL
parsing, B4 bullet relevance (logistics trigger, scoring, margin), end-to-end builds of the four real postings, and
the flags-off equivalence: with the four v3.4.7b flags off (test-only --regression-v347-flags-off=...) the outputs
equal baseline_v347a after normalizing only the timing fields (diff_gate_v347.py)."""
import hashlib, json, pathlib, re, shutil, subprocess, sys, tempfile, importlib.util
H = pathlib.Path(__file__).resolve().parent
SRC = H.parent / "1_upload_to_ChatGPT_Sources"
sys.argv = [sys.argv[0]]
spec = importlib.util.spec_from_file_location("rp", SRC / "resume_pipeline_v3_2.py"); rp = importlib.util.module_from_spec(spec); spec.loader.exec_module(rp)
master = json.loads((SRC / "master.json").read_text()); rp._prepare_runtime_cache(master)
sys.path.insert(0, str(H)); import diff_gate_v347 as gate
MAN = {m["name"]: m for m in json.loads((H / "manifest.json").read_text())}
TPL = json.loads((SRC / "plan_template.json").read_text())
NEW = ("sponsorship_polarity", "or_groups", "sql_parse", "bullet_relevance")
LATER = ("strict_fleet", "outreach_v348", "employer_phrasings_v348", "hook_fallback_v348", "graduation_dec2026_v348") + tuple("start_date_parse_v348,bank_wording_v348,fleet_language_model_v348,fleet_repick_v348,skills_lines_v348,heading_move_v348,closing_proof_map_v348,closing_specific_v348,jd_sections_v349,years_range_v349,fit_guard_v349,bullet_score_v349,ranker_v349,date_order_v349,proof_on_page_v349,copy_rule_v349,skills_dedupe_v349,company_key_v349".split(","))   # v3.4.7c / v3.4.8a / v3.4.8c: later flags go off too in the v3.4.7a-equivalence test
V349B_OFF = "--regression-v347-flags-off=bank_format_v349b,format_letter_v349b,bold_results_v349b,skills_cap5_v349b,letter_trims_v349b"   # v3.4.9b: these end-to-end checks compare with A4 baselines, so the format flags are off
bad = []


def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + ("" if ok else f"  -> {detail}"))
    if not ok:
        bad.append(name)


check("pipeline version", rp.PIPELINE_VERSION in ("v3.4.7b", "v3.4.7c", "v3.4.8a", "v3.4.8b", "v3.4.8c", "v3.4.9a", "v3.4.9b"), rp.PIPELINE_VERSION)   # v3.4.7c build keeps these checks
fl = master.get("v347_flags") or {}
check("flags: master.json v347_flags has the four v3.4.7b flags, true", all(fl.get(k) is True for k in NEW), fl)
check("flags: the six v3.4.7a flags are still there", all(fl.get(k) is True for k in rp.V347_FLAG_NAMES if k not in NEW + LATER))
off = json.loads(json.dumps(master)); off["v347_flags"]["or_groups"] = False
got = rp.v347_load_flags(off)
check("flags: a false flag turns only that fix off", got["or_groups"] is False and all(v for k, v in got.items() if k != "or_groups"), got)
rp.v347_load_flags(master)

# ---- B1: labelled phrasings ------------------------------------------------------------------------------------
P = rp.v347b_sponsor_polarity
LAB = [
    ("We will not sponsor H-1B petitions now or in the future.", "negative"),
    ("Fidelity will not provide immigration sponsorship for this position.", "negative"),
    ("Inspire11 is unable to sponsor employment visas at this time.", "negative"),
    ("We cannot support employment-based visa applications.", "negative"),
    ("Candidates must be authorized to work in the United States without sponsorship now or in the future.", "negative"),
    ("Must be authorized to work in the U.S. without the need for employer sponsorship.", "negative"),
    ("No visa sponsorship is available for this role.", "negative"),
    ("The company does not sponsor visas.", "negative"),
    ("U.S. citizenship required.", "negative"),
    ("Green card holders only.", "negative"),
    ("Sponsorship is not available for this position.", "negative"),
    ("H1B Sponsor Likely", "badge"),
    ("This company has a track record of offering H1B sponsorships.", "badge"),
    ("Data powered by the Department of Labor; does not guarantee sponsorship.", "badge"),
    ("Visa sponsorship available.", "positive"),
    ("We will sponsor qualified candidates.", "positive"),
    ("Visa sponsorship: We do sponsor visas!", "positive"),
    ("The company has sponsored H-1B workers for this role.", "positive"),
    ("Visa / sponsorship: Not stated in the posting.", "neutral"),
    ("Sponsorship considered case by case.", "unclear"),
    ("Visa Sponsorship: Case by case", "unclear"),
    ("Visa Sponsorship", "none"),   # a bare heading: the statement under it is classified on its own
    ("The Company may not be able to employ candidates who hold certain US visa categories.", "unclear"),
    ("Applicants must be authorized to work in the United States.", "none"),
    ("We are an equal opportunity employer.", "none"),
]
for text, want in LAB:
    got = P(text)
    check(f"B1 phrasing [{want}]: {text[:70]}", got == want, got)
S = rp._v347b_sentences
check("B1: a short heading + value line reads as one statement", S("Visa Sponsorship\nCase by case") == ["Visa Sponsorship: Case by case"], S("Visa Sponsorship\nCase by case"))
check("B1: a heading never merges with a section header or a full statement", S("H1B Sponsor Likely\n\nResponsibilities") == ["H1B Sponsor Likely", "Responsibilities"]
      and S("Visa policy\nWe cannot support employment-based visa applications.")[1].startswith("We cannot"))
check("B1: at least 15 labelled phrasings", len(LAB) >= 15 and {w for _t, w in LAB} >= {"negative", "positive", "neutral", "badge", "unclear"})


def blk(raw, req):
    plan = {"_raw_jd_text": raw}
    return rp._v347b_sponsor_blockers([{"type": "work_authorization_or_sponsorship", "requirement": req, "reason": "r"}], plan, master), rp._V347B_CTX["sponsor"]


out, log = blk("H1B Sponsor Likely\nBuild things.", "H1B Sponsor Likely")
check("B1: a badge blocker is removed", out == [] and log["action"].startswith("removed"), log)
check("B1: the badge goes to Notes as information", any("Sponsorship information (not a blocker)" in n for n in rp.v347b_sponsor_notes(log)), rp.v347b_sponsor_notes(log))
out, log = blk("We will not sponsor visas.", "We will not sponsor visas.")
check("B1: a negative blocker is kept", len(out) == 1 and out[0]["requirement"] == "We will not sponsor visas.", out)
out, log = blk("H1B Sponsor Likely\nWe will not sponsor visas for this role.", "H1B Sponsor Likely")
check("B1: positive first match + a negative statement elsewhere keeps the blocker on the negative text", len(out) == 1 and "will not sponsor" in out[0]["requirement"], out)
out, log = blk("Sponsorship considered case by case.", "Sponsorship considered case by case.")
check("B1 FAIL-CLOSED: unclear wording keeps the v3.4.7a blocker", len(out) == 1, out)
check("B1 FAIL-CLOSED: Notes say the wording is unclear", any(n.startswith("Sponsorship wording unclear: check manually") for n in rp.v347b_sponsor_notes(log)), rp.v347b_sponsor_notes(log))
other = [{"type": "citizenship", "requirement": "US citizen", "reason": "r"}]
check("B1: other blocker types are never touched", rp._v347b_sponsor_blockers(list(other), {"_raw_jd_text": "US citizen"}, master) == other)

# ---- B2: OR-groups -----------------------------------------------------------------------------------------------
G = rp.v347b_or_groups
alml = rp.clean_jd_text((H / "jds" / "alml_engineer.txt").read_text())
lg = [g for g in G(alml) if g["kind"] == "list"]
check("B2: alml list group found with its 4 members", len(lg) == 1 and len(lg[0]["members"]) == 4 and not lg[0]["ambiguous"], lg)
check("B2: the list group stops at the sentence line (LLM limitations is not a member)", lg and not any("limitations" in m for m in lg[0]["members"]), lg)
inl = G("Proficient in high-level languages such as Python, Ruby or Javascript")
check("B2: inline 'A, B or C' is one group", inl and inl[0]["members"] == ["Python", "Ruby", "Javascript"], inl)
check("B2: 'one or more languages such as Java, C#, Python, JavaScript, or Go'", G("Strong programming experience in one or more languages such as Java, C#, Python, JavaScript, or Go.")[0]["members"] == ["Java", "C#", "Python", "JavaScript", "Go"])
cl, amb = rp.v347b_or_cleared("Proficient in high-level languages such as Python, Ruby or Javascript", master)
check("B2: Ruby is cleared by Python", "ruby" in cl and cl["ruby"]["covered_by"].startswith("Python"), cl)
check("B2: a covered member is never cleared (only the others)", "python" not in cl and "javascript" not in cl, cl)
cl, amb = rp.v347b_or_cleared("Experience with Rust, Scala or Kotlin", master)
check("B2: a group with no covered member clears nothing", not cl, cl)
cl, amb = rp.v347b_or_cleared("Deep expertise in at least one of the following:\n- Recommendation systems\n- LLM agent products\n", master)
check("B2: list group covered by the agent evidence clears recommendation systems", "recommendation systems" in cl and "agent evidence" in cl["recommendation systems"]["covered_by"], cl)
cl, amb = rp.v347b_or_cleared("Expertise in any of the following:\n", master)
check("B2 FAIL-CLOSED: a lead-in with no list lines is ambiguous and clears nothing", not cl and amb and amb[0]["ambiguous"], amb)
check("B2: hallucinations / grounding map to the claim-check evidence", "claim-check" in rp.v347b_member_covered("hallucination mitigation", master)
      and "claim-check" in rp.v347b_member_covered("grounding", master))
check("B2: 'LLM fine tuning' is not covered (no master evidence)", rp.v347b_member_covered("LLM fine tuning", master) == "")
check("B2: never-supported terms are never covered", rp.v347b_member_covered("Ruby", master) == "" and rp.v347b_member_covered("C#", master) == "")
plan = {"_jd_requirements_auto": True, "application": {"fit": "Medium"},
        "jd_requirements": [{"term": "recommender systems", "verbatim": "recommendation systems", "priority": "must", "supported": False, "aliases": []},
                            {"term": "LLMs", "priority": "must", "supported": True}, {"term": "Python", "priority": "must", "supported": True}]}
rp._v347b_reset()
rp._v347b_or_hard_gaps(plan, master, "Deep expertise in at least one of the following:\n- Recommendation systems\n- LLM agent products\n")
r0 = plan["jd_requirements"][[r["term"] for r in plan["jd_requirements"]].index("recommender systems")]
check("B2: the uncovered member requirement is hedged (not a hard gap)", r0.get("hedged") and r0["priority"] == "medium", r0)
check("B2 guard: Fit rises at most one level", plan["application"]["fit"] == "High", plan["application"])
plan = {"_jd_requirements_auto": True, "application": {"fit": "Low"},
        "jd_requirements": [{"term": "recommender systems", "verbatim": "recommendation systems", "priority": "must", "supported": False, "aliases": []},
                            {"term": "LLMs", "priority": "must", "supported": True}]}
rp._v347b_or_hard_gaps(plan, master, "Deep expertise in at least one of the following:\n- Recommendation systems\n- LLM agent products\n")
check("B2 guard: Low goes to Medium, never straight to High", plan["application"]["fit"] == "Medium", plan["application"])

# ---- B3: SQL -------------------------------------------------------------------------------------------------------
rp._v347b_reset()
ust = rp.clean_jd_text((H / "jds" / "ust_software_engineer.txt").read_text())
r3 = rp._v347b_add_sql([{"term": "PostgreSQL", "priority": "high", "supported": True}], ust)
check("B3: UST's database line adds a SQL requirement (medium, supported)", r3[-1]["term"] == "SQL" and r3[-1]["priority"] == "medium" and r3[-1]["supported"], r3[-1])
check("B3: never added twice", rp._v347b_add_sql(r3, ust) == r3)
check("B3: MySQL / PostgreSQL / NoSQL alone are not a literal SQL", rp.v347b_sql_line("- Experience with databases such as MySQL, PostgreSQL or NoSQL stores.") == "")
check("B3: SQL outside a database line is ignored", rp.v347b_sql_line("- Write SQL queries for reports.") == "")

# ---- B4: bullet relevance -------------------------------------------------------------------------------------------
LL = rp.v347b_logistics_line
check("B4 trigger: 'shipping ML systems into production' is not logistics", LL({"application": {}}, "- 2+ years with a track record of shipping ML systems into production.") == "")
check("B4 trigger: 'shipping meaningful software' is not logistics", LL({"application": {}}, "- Demonstrated history of shipping meaningful software at startup pace.") == "")
check("B4 trigger: 'from architecture to shipping to the partner conversation' is not logistics",
      LL({"application": {}}, "- Own problems from architecture to shipping to the partner conversation.") == "")
check("B4 trigger: warehouse / supply chain / freight / fleet postings still are", all(LL({"application": {}}, "- " + t) for t in (
    "Build warehouse management software.", "Optimize our supply chain systems.", "Freight brokerage platform.", "Fleet management for delivery vans.", "Cold storage logistics.")))
check("B4 trigger: a logistics company name counts", bool(LL({"application": {"company": "United States Cold Storage", "role": "Java Developer I"}}, "- Build APIs.")))
check("B4: margin is a stated number", isinstance(rp.V347B_MARGIN, int) and rp.V347B_MARGIN >= 4, rp.V347B_MARGIN)
check("B4: strict Fleet test switch replaced by the v3.4.7c strict_fleet flag", not hasattr(rp, "V347B_STRICT_FLEET") or rp.V347B_STRICT_FLEET is False)
bank = json.loads((SRC / "bullet_bank.json").read_text())
vm = {v["id"]: v for p in bank["projects"].values() for v in p}
post = rp._v347b_stems("Work on LLM-based systems from fine tuning to building agents and evaluation pipelines. Mitigate hallucinations.")
check("B4: AI posting bonus for GoingOnce's agent / Negotiate / fallback bullets",
      rp.v347b_bullet_score(vm["goingonce.determ.a"], post, True, False) - rp.v347b_bullet_score(vm["goingonce.determ.a"], post, False, False) == 3)
check("B4: LLM-limitation lines prefer RIPPLE's claim-check bullets",
      rp.v347b_bullet_score(vm["ripple.tools.a"], post, False, True) > rp.v347b_bullet_score(vm["ripple.tools.a"], post, False, False))


# ---- end-to-end builds ---------------------------------------------------------------------------------------------
def run(name, extra=()):
    m = MAN[name]
    td = pathlib.Path(tempfile.mkdtemp()); d = td / name; d.mkdir()
    plan = json.loads(json.dumps(TPL)); a = plan["application"]
    a.update({"company": m["company"], "role": m["role"], "location": m["location"], "visa_sponsorship": "Not stated in the posting.", "source": "Audit", "application_date": "2026-10-13"})
    plan["cover_letter"]["team_focus"] = m["team_focus"]; plan["cover_letter"]["hook"] = m.get("hook", "")
    a.update(m.get("app_extra", {}))
    if m.get("tagline"): plan["tagline_text"] = m["tagline"]
    for k in ("prefer_variants", "jd_requirements_extra"):
        if m.get(k): plan[k] = m[k]
    (d / "plan.json").write_text(json.dumps(plan, indent=1))
    r = subprocess.run([sys.executable, "-I", "resume_pipeline_v3_2.py", V349B_OFF, "--template", "Resume_Template_CURRENT.tex", "--master", "master.json", "--plan", str(d / "plan.json"),
                        "--jd", str(H / "jds" / (name + ".txt")), "--out-dir", str(d / "out")] + list(extra), cwd=SRC, capture_output=True, text=True)
    return r.returncode, td


def rep(td, name):
    return json.loads((td / name / "out" / "report.json").read_text())


rc, td = run("zoro_fullstack"); r = rep(td, "zoro_fullstack")
letter = next((td / "zoro_fullstack" / "out").glob("*_Cover_Letter.txt")).read_text()
check("e2e zoro: PASS", r["status"] == "PASS", r.get("failures"))
check("e2e zoro: no sponsorship blocker", not [b for b in r["eligibility_blockers"] if b["type"] == "work_authorization_or_sponsorship"], r["eligibility_blockers"])
check("e2e zoro: the badge is a Notes line", any(n.startswith("Sponsorship information (not a blocker)") and "H1B Sponsor Likely" in n for n in r["notes"]), r["notes"])
check("e2e zoro: keeps its relocation line", "I am open to relocating." in letter)
check("e2e zoro: Ruby is not a gap", "Ruby" not in r.get("jd_gap_terms_detected", []) and not any(str(n).startswith("Stack gaps") and "Ruby" in n for n in r["notes"]), r["notes"])
check("e2e zoro: Fit from the real gaps (no hard gaps -> not Low)", r["effective_fit"] in ("Medium", "High") and not r["hard_gaps"], r["effective_fit"])
shutil.rmtree(td, ignore_errors=True)
rc, td = run("alml_engineer"); r = rep(td, "alml_engineer")
tex = next(p for p in (td / "alml_engineer" / "out").glob("*.tex") if p.name != "build_resume.tex").read_text()
check("e2e alml: PASS", r["status"] == "PASS", r.get("failures"))
check("e2e alml: OR-group covered, no hard gaps", not r["hard_gaps"] and (r.get("or_groups_v347b") or {}).get("hard_gaps_cleared"), r["hard_gaps"])
check("e2e alml: the warehouse rule no longer fires", not any("Fleet agent bullet is preferred" in str(c.get("change")) for c in r.get("verify_changes_v344", []) + r.get("internal_changes", [])))
check("e2e alml: outreach has no Not%20stated", "Not%20stated" not in json.dumps(r.get("outreach", {})) and "Not%20stated" not in (td / "alml_engineer" / "out" / "outreach.json").read_text())
check("e2e alml: GoingOnce keeps its multi-agent + human-approval bullet", "a human who approves every simulated bid" in tex)
check("e2e alml: no Fleet bullet (v3.4.7c C1)", "Programmed the Fleet agent" not in tex or rp.PIPELINE_VERSION == "v3.4.7b")
shutil.rmtree(td, ignore_errors=True)
rc, td = run("ust_software_engineer"); r = rep(td, "ust_software_engineer")
check("e2e ust: SQL is a covered requirement", any(c["term"] == "SQL" and c["status"] in ("covered", "alias only") for c in r["ats_coverage"]), [c["term"] for c in r["ats_coverage"]])
check("e2e ust: Fit unchanged (High)", r["effective_fit"] == "High", r["effective_fit"])
shutil.rmtree(td, ignore_errors=True)
rc, td = run("meritore_capgemini"); r = rep(td, "meritore_capgemini")
letter = next((td / "meritore_capgemini" / "out").glob("*_Cover_Letter.txt")).read_text()
check("e2e meritore: letter names one employer (no Capgemini)", "Capgemini" not in letter and "Meritore" in letter)
shutil.rmtree(td, ignore_errors=True)

# ---- flags-off equivalence ------------------------------------------------------------------------------------------
base = H / "baseline_v347a"
for name in ("zoro_fullstack", "alml_engineer", "ust_software_engineer", "frontend"):
    rc, td = run(name, ["--regression-v347-flags-off=" + ",".join(NEW + LATER)])
    snap = td / "snap"; gate.snapshot(str(td), str(snap))
    sub = td / "base"; sub.mkdir(); shutil.copytree(base / name, sub / name)
    d = gate.diffs(sub, snap)
    check(f"flags off: {name} identical to baseline_v347a (timing normalized)", not d, d[:3])
    shutil.rmtree(td, ignore_errors=True)
rc, td = run("zoro_fullstack", ["--regression-v347-flags-off=sponsorship_polarity"]); r = rep(td, "zoro_fullstack")
check("rollback: sponsorship_polarity off brings the v3.4.7a blocker back, B2 still applies",
      any(b["type"] == "work_authorization_or_sponsorship" for b in r["eligibility_blockers"]) and "Ruby" not in r.get("jd_gap_terms_detected", []), r["eligibility_blockers"])
shutil.rmtree(td, ignore_errors=True)

# ---- instructions and hash lock -------------------------------------------------------------------------------------
ins = (H.parent / "2_PROJECT_INSTRUCTIONS_paste.txt").read_text(encoding="utf-8")
check("instructions under 7,600 characters", len(ins) < 7600, len(ins))
check("instructions: version v3.4.7b or later", "v3.4.7b" in ins or "v3.4.7c" in ins or "v3.4.8a" in ins or "v3.4.8b" in ins or "v3.4.8c" in ins or "v3.4.9a" in ins or "v3.4.9b" in ins)
for f in ("resume_pipeline_v3_2.py", "master.json", "bullet_bank.json", "Resume_Template_CURRENT.tex", "Master_Resume_Context_LEAN_CURRENT_v3_2.md"):
    hsh = hashlib.sha256((SRC / f).read_bytes()).hexdigest()
    check(f"hash lock lists {f}", f"{f} sha256={hsh}" in ins)

print(f"\n{len(bad)} failing" if bad else "\nall checks pass")
sys.exit(1 if bad else 0)
