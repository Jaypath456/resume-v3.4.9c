## Fix 3 (fit_guard_v349)

Before: `snap_v349a_2`. After: `snap_v349a_3` (every fix up to 3 on). Predictions: `predicted_changes_v349a_3.json`.

Result: **PASS**. 3 changed lines in 1 fixtures (1 with output changes beyond the version label); 0 unpredicted on v340_original / holdout; 0 unpredicted and unjustified elsewhere; 0 gate-guard failures; 0 lines matched only a documented amendment; longest letter 200 words.

Guards:

- 3a resume, letter and outreach identical: **held**
- 3b only Fit changes, and only Low -> Medium where no must-have gap and no blocker exists: **held**

Changed fixtures (1): flowgen

Predicted but not changed:

- anthropic_it / report
- anthropic_it / tracker
- audit03 / report
- audit03 / tracker
- audit05 / report
- audit05 / tracker
- audit06 / report
- audit06 / tracker
- audit07 / report
- audit07 / tracker
- cardinal / report
- cardinal / tracker
- figure / report
- figure / tracker
- inspire11 / report
- inspire11 / tracker
- macys / report
- macys / tracker
- meridian_bank / report
- meridian_bank / tracker
- nvidia / report
- nvidia / tracker
- nvidia_devtech / report
- nvidia_devtech / tracker
- roblox / report
- roblox / tracker

| Fixture | Group | File | Fix | Before | After |
|---|---|---|---|---|---|
| flowgen | v341_tune | report | 3 | `effective_fit: "Low"` | `effective_fit: "Medium"` |
| flowgen | v341_tune | report | 3 | `tracker_row.Fit (High/Medium/Low): "Low"` | `tracker_row.Fit (High/Medium/Low): "Medium"` |
| flowgen | v341_tune | tracker | 3 | `Fit (High/Medium/Low): "Low"` | `Fit (High/Medium/Low): "Medium"` |
