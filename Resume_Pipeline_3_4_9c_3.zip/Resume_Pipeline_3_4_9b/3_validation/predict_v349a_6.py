"""v3.4.9a fix 6 predictions (flag date_order_v349), written BEFORE any fix-6 code.

  python3 predict_v349a_6.py BEFORE_DIR [OUT_JSON]      (default OUT_JSON: predicted_changes_v349a_6.json)

Restated from Jay's request without importing any v3.4.9a code: the three selected projects are rendered newest to
oldest by their master.json date, ties broken by rank; slot counts stay by rank (rank1 keeps the most bullets), so every
project keeps exactly its bullets and the page stays one page. A page whose current order differs from that date order
is predicted to change its resume (the project blocks move), its report (project lists that follow the page order) and
the tracker row's "Projects Used" column. Its letter and outreach never change, and neither does any page already in
date order. "expected" lists each before and after page order with the rank.
"""
import json, re, sys, pathlib

H = pathlib.Path(__file__).resolve().parent
MONTHS = {m: i for i, m in enumerate("january february march april may june july august september october november december".split(), 1)}
PID = {"LedgerFlow": "ledgerflow", "LaunchOps": "launchops", "GoingOnce": "goingonce", "RIPPLE": "ripple", "Fraud": "fraud",
       "Pintos": "pintos", "LLM": "tailor_pipeline"}


def page_order(tex: str) -> list:
    out, sec = [], ""
    for ln in tex.splitlines():
        m = re.search(r"\\section\*\{([^}]*)\}", ln)
        if m:
            sec = m.group(1)
        s = ln.strip()
        if sec == "PERSONAL PROJECTS" and s.startswith("\\noindent\\textbf{"):
            name = re.match(r"\\noindent\\textbf\{(.*?)\}", s).group(1)
            out.append(PID.get(re.split(r"[:\s]", name)[0], name))
    return out


def main(before: str, out: str = "") -> None:
    B = pathlib.Path(before)
    master = json.loads((H.parent / "1_upload_to_ChatGPT_Sources" / "master.json").read_text())
    date = {}
    for pid, p in master["projects"].items():
        mon, yr = str(p.get("date", "")).split()
        date[pid] = (int(yr), MONTHS[mon.lower()])
    pred, expected = [], {}
    for fx in sorted(p.name for p in B.iterdir() if p.is_dir()):
        tex = B / fx / "resume.tex"
        if not tex.exists():
            continue
        page = page_order(tex.read_text(encoding="utf-8"))
        rep = json.loads((B / fx / "report.json").read_text())
        rank = list((rep.get("ranking_v349") or {}).get("rank") or page)
        new = sorted(rank, key=lambda p: (tuple(-x for x in date.get(p, (0, 0))), rank.index(p)))
        if new != page:
            expected[fx] = {"rank": rank, "page_before": page, "page_after": new}
            pred += [{"fixture": fx, "file": "resume_tex", "pattern": r"."},
                     {"fixture": fx, "file": "report", "pattern": r"."},
                     {"fixture": fx, "file": "tracker", "pattern": r"^Projects Used: "}]
    label = [{"fixture": fx, "file": "report", "pattern": r'^pipeline_version: "v3\.4\.(?:8c|9a)"$', "label_only": True,
              "reason": "PIPELINE_VERSION label on a stop report"} for fx in ("fonzi", "cisco_no_title")]
    doc = {"version": "v3.4.9a", "fix": "6", "baseline": str(B), "fixes": [{"fix": "6", "predicted": pred}], "justified": label, "expected": expected}
    pathlib.Path(out or H / "predicted_changes_v349a_6.json").write_text(json.dumps(doc, indent=1) + "\n")
    print(f"6: {len(expected)} pages change order (letters, outreach and every other page unchanged)")


if __name__ == "__main__":
    main(*sys.argv[1:3])
