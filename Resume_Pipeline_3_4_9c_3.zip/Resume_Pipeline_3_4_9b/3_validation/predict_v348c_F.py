"""v3.4.8c fix F predictions (F1 fleet_language_model_v348 + F2 fleet_repick_v348).

  python3 predict_v348c_F.py BEFORE_DIR [OUT_JSON]      (default OUT_JSON: predicted_changes_v348c_F.json)

Honest record: this predictor was written after the F1 / F2 code was first tried on a development copy (the F code
shares the W selector plumbing), but it restates only Jay's request and imports no v3.4.8c code; it was frozen before
the full F run and is not edited afterwards (gaps go to predicted_changes_v348c_F_amendments.json).

Restated rule: GoingOnce's Fleet bullet leaves every non-logistics page. The targets are the pages of BEFORE_DIR that
still show the Fleet bullet, minus the logistics postings (the v3.4.7b logistics test: us_cold):
  F1 (Jay's list) cardinal, harvey, inspire11, ng_fullstack, rocketmoney, sparkline, tiktok_appsec: Fleet becomes the
     new plain-code bullet without "Claude" (goingonce.determ.b), in place.
  F2 (Jay's list) audit05, brightpath_fs, cobalt, frontend, ixl, loopwell, lumen, northwind, pinecrest: the GoingOnce
     set is re-picked without Fleet (any GoingOnce bullet may change).
Predicted changed lines on a target: GoingOnce bullet lines of the resume; the letter sentence that cited Fleet (when
the letter cites it); report strict_fleet_v347c.* / fleet_v348c.* logs and the B4 log lines that name GoingOnce bullets,
plus the report lines that quote the letter (cover_letter.*). On every page that still shows Fleet afterwards: the
report's fleet_v348c log (why it stays). Projects, order, headings, slot counts, Experience, Skills, tracker and outreach
never change.
"""
import json, re, sys, pathlib

H = pathlib.Path(__file__).resolve().parent
F1 = ["cardinal", "harvey", "inspire11", "ng_fullstack", "rocketmoney", "sparkline", "tiktok_appsec"]
F2 = ["audit05", "brightpath_fs", "cobalt", "frontend", "ixl", "loopwell", "lumen", "northwind", "pinecrest"]
LOGISTICS = ["us_cold"]
FLEET_LINE = "Programmed the Fleet agent, which"
FLEET_SENT = re.compile(r"Fleet agent|rental cars|truckloads?")
GO_STARTS = ["Prototyped a multi-agent car", "Prototyped a four-agent car", "Coded the Negotiate and Fleet", "Implemented a hybrid agent",
             "Integrated Claude for language", "Created the Streamlit and React", "Wrote the Streamlit and React", "Coded the Negotiate agent",
             "Programmed the Fleet agent", "Implemented history checks", "Kept search, history checks"]


def main(before: str, out: str = "") -> None:
    B = pathlib.Path(before)
    fleet_pages = sorted(p.name for p in B.iterdir() if (p / "resume.tex").exists() and FLEET_LINE in (p / "resume.tex").read_text())
    targets = [x for x in fleet_pages if x not in LOGISTICS]
    pred, expected = [], {}
    go_rx = r"^\s*\\item (?:" + "|".join(re.escape(x) for x in GO_STARTS) + ")"
    for fx in targets:
        kind = "F1" if fx in F1 else ("F2" if fx in F2 else "other")
        letter = (B / fx / "letter.txt").read_text() if (B / fx / "letter.txt").exists() else ""
        cites = bool(FLEET_SENT.search(letter))
        expected[fx] = {"kind": kind, "letter_cites_fleet": cites}
        pred.append({"fixture": fx, "file": "resume_tex", "pattern": go_rx})
        pred.append({"fixture": fx, "file": "report", "pattern": r"^(?:strict_fleet_v347c\.|fleet_v348c\.|bullet_relevance_v347b\.)"})
        if cites:
            pred.append({"fixture": fx, "file": "letter_txt", "pattern": r"."})
            pred.append({"fixture": fx, "file": "report", "pattern": r"^cover_letter\.|^verify_changes_v344|^internal_changes|^verify_quotes_v345"})
    for fx in fleet_pages:
        pred.append({"fixture": fx, "file": "report", "pattern": r"^fleet_v348c\."})
    label = [{"fixture": fx, "file": "report", "pattern": r'^pipeline_version: "v3\.4\.8c"$', "label_only": True, "reason": "unchanged version label"} for fx in ("fonzi", "cisco_no_title")]
    doc = {"version": "v3.4.8c", "fix": "F", "baseline": str(B), "fixes": [{"fix": "F", "predicted": pred}], "justified": label,
           "expected": expected, "fleet_pages_before": fleet_pages, "logistics_keep": LOGISTICS,
           "jay_lists": {"F1": F1, "F2": F2}, "not_in_jay_lists": [x for x in targets if x not in F1 + F2]}
    pathlib.Path(out or H / "predicted_changes_v348c_F.json").write_text(json.dumps(doc, indent=1) + "\n")
    print(f"F: {len(fleet_pages)} pages show Fleet; {len(targets)} targets ({', '.join(f'{k}:{v['kind']}' for k, v in expected.items())}); "
          f"letters citing Fleet: {[k for k, v in expected.items() if v['letter_cites_fleet']]}; keep: {LOGISTICS}")


if __name__ == "__main__":
    main(*sys.argv[1:3])
