# JUDGE BATCH (14 packages)

Judge each package below separately with the prompt and rubric. Score every package, in order, using the output format once per package with a `## <n>. <package>` heading.

# Judge prompt (paste into the OTHER model: ChatGPT judges Claude's package, Claude judges ChatGPT's)

You are two reviewers at once for this one posting:
1. A technical recruiter at a large company who screens 200 resumes a day and has 30 seconds per page.
2. The company's ATS (Workday/Greenhouse-style): keyword match on the posting's required and preferred terms, with more weight for terms that appear in Experience/Project bullets than in the Skills line.

Inputs: the pipeline writes judge_packet.md for every run (v3.4.2). One packet holds the EVIDENCE INVENTORY, the ELIGIBILITY NOTES, the JOB POSTING, the RESUME (PDF text) and the COVER LETTER. To judge several packages at once, run `python3 combine_judge_packets.py <out_dir>... -o Judge_Batch.md`: the batch carries this prompt and the rubric once, the inventory once, then each package.

Evidence inventory: it is generated from master.json and is the complete record of what Jay can claim. A claim that matches the inventory (including its anchors and boundaries) is verified evidence, never a "possible fabrication". Flag a claim only when the inventory does not support it or a boundary forbids it, and quote the inventory line you checked.

Eligibility notes (sponsorship, citizenship, clearance, graduation window, rising-senior programs) are shown to Jay so he can decide; the package is always built. They are never a defect in the resume or the letter.

Experience: the packet header says experience_variants_enabled. When it is false, the Experience section is frozen by the candidate: do not score its wording, but DO count it as evidence. When it is true, also score Experience with the rubric's Experience section. (v3.4.3 ships it true: Jay approved the variants A-H, so score Experience.)

Score strictly with the rubric in RUBRIC.md (start each document at 10, subtract). Then add these checks:

ATS (score out of 10)
- Every REQUIRED posting line that the candidate can truthfully meet is visible on the page, in the posting's own words where possible (-0.5 each if only an alias is shown, -1 each if missing).
- A required qualification proven only by a Skills-line keyword and no bullet (-0.5 each).
- Skills that are filler for this role (named by neither the posting nor any bullet) (-0.25 each).

Technical recruiter (score out of 10)
- Would the top third of the page make you keep reading for THIS role? If not, say which project or bullet should lead.
- Any claim you would doubt in a phone screen (-0.5 each, quote it).
- Any repeated verb or phrase across the page (-0.25 each).
- Cover letter: does it answer the posting's hardest required line with evidence? (-1 if not)

Output exactly (once per package; in a batch, start each block with `## <package name>`):
ATS: <score>/10
Recruiter (resume): <score>/10
Recruiter (letter): <score>/10
Deductions:
- <points> | "<exact quote>" | <one-line fix>
Pipeline-level fix (one line, only if the same defect would repeat on other postings): <fix or "none">

Do not invent facts about the candidate. Do not reward keywords the candidate cannot back up. Check every "doubtful claim" against the inventory before deducting.

---

# Quality rubric (score each document out of 10; be strict, quote the text for every deduction)

A claim that matches the EVIDENCE INVENTORY is verified evidence, not a fabrication; "a claim not backed by the resume" means not backed by the inventory or the page.

## Resume (start at 10, subtract)
- Technical Skills (max -2.5): a skill the page does not show and the posting does not name (-0.5 each); a posting-named skill that Jay can back up but is missing from Skills (-0.75 each); a line that is long or mixes unrelated things (-0.25); order not matching what the posting stresses (-0.25).
- Project selection (max -2.5): a project that does not prove what the posting asks for (-1); a better-fitting project left out (-1); the strongest proof (a number) missing from a project (-0.5).
- Project bullets (max -2.5): awkward or unnatural phrasing (-0.25 each); run-on or two ideas in one bullet (-0.25 each); no result or number where one exists (-0.25 each); a claim the posting cannot connect to (-0.25).
- Project headings/tagline (max -1.5): heading technology line missing a posting-named technology the bullets show (-0.5); tagline generic or off-target (-0.5).
- Layout/ATS (max -1): one page, readable, standard headings, no clutter.
Do not score the Experience section while experience_variants_enabled=false (the packet header says which; v3.4.3 ships it true).
A new-grad page (the packet's LAYOUT NOTE) puts Education first and may leave the Go Digital internship off by rule: not a defect.

## Experience (scored when the packet says experience_variants_enabled=true, as in v3.4.3; max -1.5, taken from the resume score)
- A variant that adds a fact, number or tool not in the inventory's Experience line or its anchors (-1 each; this is a pipeline defect). Dropping a fact is allowed.
- A variant whose emphasis does not fit the posting better than the original would (-0.25 each).
- Awkward word order introduced by a variant (-0.25 each).

## Cover letter (start at 10, subtract)
- Opening (max -2): generic or could be sent to any company (-1); does not use the posting's own words (-1).
- Evidence (max -3): the two projects and one experience do not prove what the posting asks for (-1 each); a filler sentence that only lists keywords (-1); a claim not backed by the resume (-2).
- Simple English and length (max -2): sentences over 30 words (-0.25 each); jargon where plain words work (-0.25 each); more than 200 words (-0.5).
- Consistency with the resume (max -1.5): a number or fact worded differently or contradicting (-0.75 each).
- Close and logistics (max -1.5): no graduation/start line (-0.75); relocation mentioned for a remote job or missing for an onsite one (-0.5); weak or generic close, e.g. "I would welcome the chance..." instead of one sentence naming the posting's top build / improve responsibility in its own words plus Jay's matching proof (-0.5); a close over 30 words, or one that makes the company (not Jay) the actor (-0.5).
- Hook (part of Opening): describes the team instead of what draws Jay to the work, or does not name the company's product / domain in the posting's words (-0.5).

Output per posting: resume score, letter score, then every deduction as: points | exact quote | one-line fix.

---

# EVIDENCE INVENTORY (generated from master.json; complete record of what Jay can claim; shared by every package)

Anything in this inventory is verified evidence. A claim on the page that matches it is NOT a fabrication.

### Experience (frozen wording; evidence anchors give the measured facts behind each number)
- **Software Engineer Practicum | HeinOnline (University at Buffalo)** (January 2026 -- April 2026)
  - Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  - Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ~90% and pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
  - Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
  - Standardized author names by matching them to HeinOnline's 500+ authors in PostgreSQL, even when spelled differently.
  - Anchors: 47 journals / 28,167+ pages; measured extraction accuracy 90.81% (resume wording: "about 91%"); manual author-entry work cut by about 90% (estimated); worker pool sized to CPU cores minus one; on 47 journals the run took about 50 minutes sequentially and 9 minutes 15 seconds in parallel on 10 cores (about 81% reduction); confidence source values API = 100, LLM = 85, scraper = 50; Docker supported; author names standardized by matching against HeinOnline's 500+ authors stored in PostgreSQL (handles different spellings). Team of 5 for the project. In cover letters say "about 91%".
- **Software Engineer | Thesis Mumbai Tech (Startup)** (August 2024 -- August 2025)
  - Led end-to-end delivery of healthcare platform modules with a team of 4: gathered requirements in client meetings, prototyped to validate scope, and broke the finalized work into tasks.
  - Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ~2s live monitoring.
  - Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses, plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
  - Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
  - Built a heartbeat monitoring dashboard for 4 production projects, pinging each site every 5 minutes to track health.
  - Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds over their first 3 weeks and introducing them to the production projects and tech stack.
  - Anchors: client/stakeholder meetings; prototyping; "led" means technical coordination of a four-person team, not people management or hiring authority; team size is 4 (team of 4); interviewed about 20 student candidates and onboarded the new hires; SQL/relational schemas; PostgreSQL/Redis/WebSockets; WebRTC; real production deployment; heartbeat/service monitoring and responding to failures it surfaced; reviewed and merged team pull requests (cover letters, and the resume only through Experience variant I); Agile/Scrum. The earlier "~90% setup-time reduction" for Docker was an estimate, not a measurement, so it is not used on the resume. Do not infer HIPAA/FHIR/EHR, observability vendors, formal SRE/on-call, SLA ownership, or HA.
- **Cloud Engineer Intern | Data Maven Pvt Ltd** (November 2023 -- May 2024)
  - Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
  - Automated cloud resource provisioning, cutting setup time by ~40% and reducing deployment issues.
  - Anchors: AWS EC2/RDS, VPC, security groups. The 40% setup reduction is estimated, not instrumented; keep "~" and be ready to explain it in an interview.
- **Data Engineer Intern | Go Digital Technology Consulting** (June 2023 -- August 2023)
  - Developed a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data and generate automated anomaly reports for the compliance and audit team.
  - Anchors: Python, Pandas, NumPy, MySQL, SQL, ETL, cleaning/transformation/reporting.

### Projects
#### LedgerFlow — Event-Driven Payment Ledger (Individual, October 2026)
Tech: Java 25, Spring Boot, Spring MVC, Spring JDBC/JdbcClient, Kafka, PostgreSQL 17, Flyway, Maven, Docker Compose, Kubernetes, k3d/k3s/kubectl, Testcontainers, JUnit 5, AssertJ, Awaitility, Actuator/Micrometer, k6, GitHub Actions, HTML/CSS/JavaScript, YAML
- Two Spring Boot services that talk through Kafka: a payment API and a ledger that records every payment as matching debit and credit entries (double-entry accounting).
- Safeguards (transactional outbox, idempotent consumers, reconciliation check) so a payment is never recorded twice or lost when messages are repeated or retried. Supported phrase: each payment takes effect exactly once even though Kafka may deliver a message more than once.
- Overspending test: 200 simultaneous $10 requests against an account funded for exactly 50 payments. 50 went through, 150 were safely rejected, the balance ended at $0, and there was no overdraft or double posting.
- Testing: 94 automated tests, plus 27 of 27 crash-and-repeat test runs with 0 data errors (18,000 repeated messages and 14 forced service crashes in total).
- (optional) Speed: in a controlled local test at 200 payments per second, response time for the slowest 5% of requests dropped from 121 ms to 51 ms after the outbox polling interval went from 50 ms to 10 ms.
- (optional) Local Kubernetes demo (k3d, plain YAML manifests): restarting a service mid-run still completed 250 of 250 payments with 0 duplicates; a fresh cluster came up in 142 s and a replacement service was ready in about 8.9 s.
- Integration tests run against real PostgreSQL and Kafka with Testcontainers and JUnit 5 (Testcontainers is in the LedgerFlow stack).
- CI: LedgerFlow's GitHub Actions CI workflow runs all 94 tests (confirmed by Jay 2026-10-15); the integration tests run against real PostgreSQL and Kafka in containers with Testcontainers and JUnit 5.
- Boundaries (do not claim): personal/local project; not production/HA/PCI; no real bank/card network; no exactly-once Kafka delivery; no EKS/GKE/AKS/Helm/HPA/multi-node HA; CI only, not Continuous Deployment.

#### GoingOnce — Multi-Agent Car Marketplace (Team of 4, October 2026)
Tech: Python, LangGraph, Claude API, Streamlit, ReactJS/Vite, Server-Sent Events, pytest, JavaScript
- Four agents built by the team (Buy, Sell, Negotiate, Fleet) for a car-marketplace prototype; a human approves every simulated bid or listing before it goes through.
- Claude handles language and photo tasks; ordinary code handles search, pricing, and negotiation rules.
- Streamlit and React interface on top of a streaming API; 24 automated tests.
- Simulated marketplace data only.
- 1st Place in ACV Auctions + Copart challenge at UB AI for Good Hackathon Design Challenge.
- Mentor feedback shaped the Negotiate and Fleet flows.
- Jay worked on all four agents (mainly the Negotiate and Fleet agents) and built the Streamlit and React front end himself (confirmed 2026-10-15).
- Negotiate agent (repo README): each side's agent keeps a private price limit, a mediator closes the gap in rounds, then the deal closes itself: simulated escrow payment, insurance, loan payoff, title, and truck transport.
- Fleet agent (repo README): checks market demand, spreads 120 similar rental cars across markets in full truckloads, and schedules pickups, so simulated prices hold and transport stays low.
- Buy agent (repo README): checks each car's history and throws out cars with hidden salvage or odometer rollback across 310 simulated ACV and Copart listings, and pauses for dealer approval before any bid.
- Determinism (repo README): search, history checks, pricing, negotiation math and logistics are plain code; Claude is called only for language and photos, and every Claude call has a saved fallback, so results repeat.
- The HTTP API streams agent steps to the React UI as Server-Sent Events (repo README).
- Boundaries (do not claim): Four-person team project (confirmed by Jay 2026-10-15): Jay worked on all four agents (mainly Negotiate and Fleet) and built the Streamlit/React front end. Feature bullets may describe any agent (Buy, Sell, Negotiate, Fleet); the project-level bullet keeps "with a four-person team"; never imply he built the whole system alone. The 24 tests and the award stay team-scoped; not production; bids, payments, prices and transport are simulated; no real ACV/Copart integration; no FastAPI/Docker/RAG/vector DB; award stays out of project bullets.

#### RIPPLE — Agentic Change-Impact Analysis (Individual, August 2026)
Tech: Python, Python AST, Git CLI, Pydantic, pytest, LLM API, JSON/JSONL
- Command-line AI agent for Python repositories: given a plain-English description of a change, it predicts which files, tests, and regression risks the change will touch before any code is written.
- Uses 7 code-analysis tools with a cap of 25 tool calls per task; Python code checks every claim against evidence before it can enter the report.
- After the change is made, RIPPLE's own Git-diff check flags unexpected edits, missing tests, and stale callers (Jay 2026-10-15: "Added a Git-diff check that flags unexpected edits, missing tests, and stale callers"; it is RIPPLE's automated check, not manual review).
- 241 automated tests.
- Evaluation: 90 runs on 30 unseen tasks from 16 repositories. Precision 0.306, recall 0.152, F1 0.198, MRR 0.311, and 0 unsupported claims accepted into any report. On the page prefer the zero-unsupported-claims result plus at most one score, and only use the score for AI/ML JDs.
- (optional) Efficiency: about 10 tool calls and 17 model calls per run, with under 1 duplicate call per run (exact: 10.37, 16.60, 0.73).
- (optional) Separate post-change check: found all 3 kinds of planted problems on 15 tasks (100% detection) when given the correct pre-change predictions. Never present this as end-to-end performance.
- Hybrid code search over code chunks (BM25 + dense retrieval) is designed only; dense retrieval/RAG implementation and benchmark are not complete.
- Used Claude Code as a coding assistant while building RIPPLE: Claude Code helped write RIPPLE, and Jay checked its output by running RIPPLE's 241-test suite (confirmed by Jay 2026-10-15); he also used it to study how AI agents work and to probe their edge cases.
- Boundaries (do not claim): Python only; no production/adoption/bugs-prevented/productivity claims; no LangGraph/NetworkX/SQLite/MCP/Redis/Docker; do not attribute current metrics to RAG; do not claim it beat historical B3; Claude Code: say Claude Code helped write RIPPLE and Jay checked its output with RIPPLE's 241-test suite (confirmed 2026-10-15); never "RIPPLE, whose AI-generated code" (RIPPLE generates no code); give no count of corrections, no specific bug example and no productivity claim. The Git-diff check is RIPPLE's automated check (Jay 2026-10-15); never describe it as Jay reading diffs by hand.

#### LLM Application Optimization Engine (Individual, July 2026)
Tech: Python, Gemini API, Novita API, Groq API, pytest, LaTeX, pdflatex, pdftotext
- Turns a job description into a tailored one-page resume and cover letter grounded in verified evidence.
- Chooses which 3 projects to show and how many bullets each gets by checking every valid combination (dynamic programming); with 7 active projects the expected count is 105 once runtime integration is verified. Describe it as "picks the best projects"; do not hard-code the count.
- Three AI workers write bullets at the same time; typical runtime fell by about 73% (from about 11 minutes to about 3). On the page use the percentage only.
- Python checks reject unsupported technologies, ownership claims, borrowed evidence, and changed numbers before anything is shipped.
- Compiles the LaTeX and re-reads the PDF to check the layout.
- 2,500+ automated pytest tests.
- Uses Gemini as the main model provider and falls back to Novita's model API after 3 failed attempts; retries and repairs only the parts that failed.
- Uses the Groq API for assessment (confirmed by Jay, 2026-10-13); Gemini is the main generation provider and Novita's model API is the fallback.
- Boundaries (do not claim): individual project; do not claim unsupported production/org adoption; assignment count must remain catalogue-dependent. Groq API role: assessment only; do not describe it as a generation provider or claim specifics of the assessment beyond this.

#### LaunchOps — Office Onboarding & Real-Time Learning Platform (Individual, March 2026)
Tech: Python, Django REST Framework, ReactJS, Go, PostgreSQL, MongoDB (live answers only), Redis, Django Channels, Daphne, Docker Compose, WebSockets, JWT, Locust, asyncio, JavaScript
- Django REST and React onboarding platform with a 20-task workflow shared across HR, IT, manager, and employee roles; tasks have owners, prerequisites, and required evidence.
- Five lessons, each with a 3-question quiz, and an exact 70% pass rule.
- Server-side checks stop users from completing someone else's task, submitting forged evidence, skipping prerequisites, or submitting twice; unresolved support issues also block completion.
- PostgreSQL is the main durable store.
- Live-quiz service written in Go using WebSockets, running as two copies behind nginx; Redis Pub/Sub with Lua scripts coordinates the copies, and a unique MongoDB index rejects duplicate answers.
- A repeatable Django-vs-Go benchmark exists; no speed result after the Go move is verified.
- Boundaries (do not claim): no production deployment, throughput/failover claims, or Go speedup; MongoDB stores live answers only; never reuse retired-LMS metrics.

#### Pintos Operating System — User Programs Layer (Individual academic, May 2026)
Tech: C, x86, Operating Systems, Kernel Development, Concurrency, Thread Synchronization, File Systems, Process Lifecycle
- wrote the part of a teaching operating system that runs user programs, in C: starting programs with arguments, parent/child waiting and exit, 13 system calls, up to 128 open files per process, locks, and safety checks on memory access; all 80 tests pass.
- Boundaries (do not claim): C, not C++; teaching OS, not production OS work.

#### Fraud Detection using Graph Neural Networks (Academic, April 2026)
Tech: PyTorch, PyTorch Geometric, GNN, GraphSAGE, GAT, NetworkX, Pandas, scikit-learn, Focal Loss
- trained fraud models on the IEEE-CIS dataset (590,540 transactions, about 3.5% fraud, roughly 27.6 normal transactions for every fraud). The GraphSAGE graph neural network scored 0.9259 AUC-ROC (fraud F1 0.5641) against about 0.858 for a plain neural-network baseline (MLP); the GAT model did worse. On the Elliptic dataset, GraphSAGE reached about 0.988 AUC and 0.906 F1. Ablation analysis available. On the page always show AUC next to the baseline it beat.
- Graph construction (notebook): a transaction graph of 590,540 nodes and 4,122,298 edges (about 4.1M) built by linking transactions that share card (card1, card2, card1+addr1), address (addr1) and email-domain (P_emaildomain, R_emaildomain) identifiers; any identifier group larger than 50 transactions is skipped so no hub node forms.
- Edge-type ablation (notebook) over five identifier types (card1, card2, addr1, P_emaildomain, R_emaildomain) on the trained GraphSAGE model: all edges 0.9113 test AUC vs 0.8954 with no edges, so the graph adds 0.016 AUC; card1 links alone reach 0.9109 (almost all of the gain), while each other type alone stays at 0.8954-0.8955.
- Model comparison (notebook): MLP, GraphSAGE and GAT trained with focal loss and class weights, with decision thresholds tuned for F1 on validation data; test fraud F1: GraphSAGE 0.564 (0.5641), MLP 0.394 (0.3944), GAT 0.261 (0.2605).
- Leakage controls (notebook): stratified 70/15/15 train/validation/test split; the feature scaler is fit on the training split only; decision thresholds are tuned on the validation split; final results are reported on the held-out 15% test set.
- Jay built the whole notebook himself (confirmed 2026-10-15); describe it as his own work.
- Boundaries (do not claim): Jay's own work: he built 100% of the notebook himself (confirmed 2026-10-15; the course submission lists three names, but the other two worked on a different project). Describe it as Jay's own work, never as team work. Never quote a class-imbalance ratio of 41.4x (that figure includes the 1.5 fraud weight); the true ratio is about 27.6 normal transactions per fraud. The edge ablation tested each identifier type alone and all together; it did not test removing one type from the full graph.

### Additional verified facts (master.json cover_letter_evidence; usable in letters and approved Experience variants)
- collaboration product: Direct client/stakeholder meetings at Thesis Mumbai Tech.
- collaboration product: Clarified requirements and translated them into technical work.
- collaboration product: Prototyped before full implementation.
- collaboration product: Coordinated a four-person engineering team (technical coordination, not people management).
- collaboration product: Reviewed pull requests.
- collaboration product: Worked with clients on UI/UX and product requirements.
- collaboration product: Interviewed about 20 student candidates and onboarded the new hires.
- collaboration product: Agile/Scrum.
- production operations: Deployed team software to a shared production server.
- production operations: Built heartbeat/service-status monitoring.
- production operations: Responded to heartbeat-detected production failures and restored affected services.
- ai-assisted development: GitHub Copilot supported in scoped development evidence.
- ai-assisted development: Cursor and Claude Code used for repository-level development, debugging, test-driven iteration, and code review.
- coursework: Graduate Agentic AI coursework exists separately from RIPPLE; never merge coursework into RIPPLE or Professional Experience.

### Approved Experience variants (verified wording; the page may show one in place of the original line)
- A [HeinOnline (University at Buffalo)]: Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals using OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B), CrossRef API, and web scrapers.
- B [HeinOnline (University at Buffalo)]: Engineered a fault-tolerant data pipeline that processed 28k+ pages of law journals, combining CrossRef API, web scrapers, and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B).
- C [HeinOnline (University at Buffalo)]: Added confidence scoring that flags low-confidence fields for human review, and parallelized the pipeline with a CPU-based worker pool, cutting total processing time by over 80%.
- D [Thesis Mumbai Tech (Startup)]: Led a team of 4 through end-to-end delivery of healthcare platform modules: gathered requirements in client meetings, prototyped to validate scope, and broke the finalized work into tasks.
- E [Thesis Mumbai Tech (Startup)]: Gathered requirements in client meetings, prototyped to validate scope, and led a team of 4 through end-to-end delivery of healthcare platform modules.
- I [Thesis Mumbai Tech (Startup)]: Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements in client meetings, prototyped to validate scope, and reviewed and merged team pull requests. (adds the master-recorded facts: using Agile/Scrum; reviewed and merged team pull requests)
- F [Thesis Mumbai Tech (Startup)]: Developed a real-time WebSocket + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ~2s live monitoring, plus Patient Management and Consent modules on normalized schemas for 10k+ records.
- G [Thesis Mumbai Tech (Startup)]: Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
- H [Data Maven Pvt Ltd]: Deployed backend services on AWS EC2 and RDS, restricting access with VPC networking and security groups.
- J [Go Digital Technology Consulting]: Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data and generate automated anomaly reports for the compliance and audit team.

### Project evidence items (every verified fact behind the project bullets)

### Qualification facts (Jay meets these)
- Master's degree in Computer Science; Master's in Computer Science; degree in Computer Science; Computer Science degree; Bachelor's degree; Bachelor of Engineering; Information Technology degree; STEM degree; technical degree; internship experience; previous internship experience; prior internship; internship; new grad; new graduate; recent graduate; graduation in December 2026; graduating in December 2026; December 2026 graduate; production code; production-level code; production software; code reviews; AI-assisted development tools; AI coding tools; professional software engineering experience; industry experience; startup experience; early-stage startup

### Education
- {"masters": {"degree": "Master's in Computer Science", "institution": "University at Buffalo, The State University of New York, Buffalo, NY", "dates": "August 2025 -- Expected December 2026", "gpa": "3.85 / 4.0", "coursework_completion": "December 16, 2026", "graduation": "December 2026", "available_to_start_work": "February 2027, subject to approved OPT/EAD", "graduation_confirmed": "v3.4.8b (2026-10-19): Jay and the university confirmed graduation in December 2026; the work start date is February 2027. Graduation and start date are two separate facts.", "coursework": ["Agentic AI", "Machine Learning", "Deep Learning"]}, "bachelors": {"degree": "Bachelor of Engineering, Information Technology", "institution": "Vivekanand Education Society's Institute of Technology, Mumbai University, India", "dates": "August 2019 -- May 2023"}}

### Awards
- {"title": "1st Place, ACV Auctions + Copart Challenge", "context": "AI for Good Hackathon Design Challenge, UB", "date": "October 2026", "default_resume": true}
- {"title": "AWS Certified Cloud Practitioner", "date": "July 2024", "default_resume": true}

### Supported skills (Jay can back each one)
- languages_databases: Python, Java, JavaScript, HTML/CSS, C, Go, SQL, PostgreSQL, MongoDB, MySQL, NoSQL, Relational Databases
- frameworks_libraries: Django, Django REST Framework, Django Channels, ReactJS, Spring Boot, Spring MVC, Spring Kafka, Spring JDBC/JdbcClient, JUnit 5, Testcontainers, AssertJ, Awaitility, Pandas, NumPy, scikit-learn, PyTorch, PyTorch Geometric, NetworkX, Librosa, CatBoost, Pydantic, LangGraph, Streamlit, TensorFlow, Matplotlib, pytest, Vite
- ai_ml_data: LLM Integration, Prompt Engineering, Agentic AI, AI Agents, Tool Calling, Multi-Agent Systems, Human-in-the-Loop Workflows, OCR/Tesseract, Machine Learning, Deep Learning, CNNs, RNNs, GNNs, GraphSAGE, GAT, Focal Loss, Model Evaluation, Threshold Optimization, Data Preprocessing, Fuzzy Matching, LLMs, Agentic Workflows, Information Extraction, Classification
- software_engineering: REST APIs, Full-Stack Development, Backend Development, System Design, Event-Driven Architecture, Microservices, Payment Systems, Transactional Outbox, Idempotency, Idempotent Consumers, Double-Entry Ledger, Database Transactions/ACID, Row-Level Locking, Reconciliation, Fault Injection, Chaos Testing, Continuous Integration, Unit Testing, ETL, Parallel Processing, Multiprocessing/Worker Pools, Load Testing, Latency Measurement, Distributed Systems, Backtracking Algorithms, Agile, Scrum, Real-Time Monitoring, Concurrency, Thread Synchronization, Operating Systems, Kernel Development, Process Lifecycle, Static Analysis, Dependency Analysis, Change-Impact Analysis, Regression Analysis, Web Scraping, Production Deployment, Application Monitoring, Heartbeat Monitoring, Incident Response, OOP, Code Review, Data Structures, Algorithms, API Design, Software Design, Database Design, Data Pipelines, Debugging, SDLC, Data Validation, Data Cleaning, Data Transformation, Integration Testing, Data Modeling
- tools_platforms: Redis, Apache Kafka, Kafka KRaft, Maven, Flyway, k6, GitHub Actions, Spring Boot Actuator, Micrometer, AWS (EC2/RDS), Docker, Docker Compose, Kubernetes (local k3d), k3d, k3s, kubectl, Git, GitHub, GitHub Copilot, OAuth/Auth0, JWT, WebRTC, WebSockets, Daphne/ASGI, Locust, asyncio, Arduino Uno, LaTeX, pdflatex, pdftotext, Gemini API, Groq API, Claude API, CrossRef API, JSON, YAML, Cursor, Claude Code, Linux, Tableau, Power BI, nginx, VPC Networking, Novita API
- Scope rules: AWS: AWS (EC2/RDS) only; CI/CD: Use Continuous Integration only; Continuous Deployment is unsupported; Java/Spring/Kafka/Kubernetes: LedgerFlow only; LangGraph/Multi-Agent/Human-in-the-Loop/Claude API: GoingOnce only; Go/MongoDB live quiz: LaunchOps only; Production Deployment/Application Monitoring/Heartbeat Monitoring: Thesis Mumbai Tech only; Code Review: Thesis Mumbai Tech evidence anchors: reviewed and merged team pull requests; Kubernetes: Always shown as "Kubernetes (local k3d)"; never bare Kubernetes (local demo, not production); Claude API: Only when GoingOnce is on the page or the JD names LLM APIs; OAuth/Auth0: Shown when the JD names OAuth, SSO or authentication

### Unsupported skills and claims (never claimed; a page that shows one is a defect)
- RAG, retrieval-augmented generation, vector database, vector databases, vector DB, FastAPI, Fast API, Flask, HIPAA, FHIR, EHR, SRE, on-call, SLA, TypeScript, Selenium, Playwright, Jenkins, LangChain, Snowflake, Redshift, Airflow, Spark, Hadoop, Databricks, Bash, Prometheus, Grafana, ServiceNow, Salesforce, CRM, Jira, Azure DevOps, Azure Dev Ops, .NET, .Net Framework, C#, Eclipse, SQL Server, TCP, UDP, ArcGIS, arcpy, Geospatial, OpenAI, Embedded RTOS, RTOS, ARM, Ruby, Rust, Scala, Kotlin, Swift, PHP, Vue, Next.js, Node.js, Express, GraphQL, MongoDB Atlas, DynamoDB, Lambda, S3, SageMaker, ITSM, U.S. Citizenship, security clearance
- C++; FastAPI; Angular; Ruby; Apache Spark; Apache Airflow; AWS Glue; Terraform; Azure; GCP; EKS; GKE; AKS; production/high-availability Kubernetes; Helm; Kubernetes HPA/autoscaling; HIPAA implementation/compliance; FHIR; EHR integration; Continuous Deployment; cloud ML platforms beyond AWS EC2/RDS; data-warehouse/platform experience unless added; finance-industry Professional Experience

---

# PACKAGES

## 1. Zoro | Software Developer- Full Stack

Pipeline v3.4.8c; file key Zoro_Software_Developer_Full_Stack; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Zoro.com
·
1 hour ago
Software Developer- Full Stack
Buffalo Grove, IL
+1 more
Full-time
Onsite
Entry, Mid, Senior Level
78%
Experience Level
100%
Skill
74%
Industry Exp.
39%
Zoro is hiring a Full Stack Software Developer to build scalable infrastructure and customer-facing solutions that support product data and customer experience. The role develops technical solutions to user stories, helps define tools and processes, and works across IT and business teams to support deployment.
Automotive
Construction
E-Commerce
Food and Beverage
Healthcare
Public Safety
Landscaping
Lighting
Medical
Office Supplies
Small and Medium Businesses
H1B Sponsor Likely

Responsibilities
We want to bridge the gap between web developers and traditional tech ops by building processes that support our infrastructure including data management, monitoring, and deployment
This role focuses on solutions that allow for scale to keep up with customer demand, showcase the most current products, and provide the best customer experience
We are looking for someone that can work in the Scrum/Agile environment and bridge the gap between IT development and the business areas
You will be an integral part of defining our tool set, systems and processes
This role will provide the technical solutions to user stories and facilitate the tasks and approach needed to for the solution deployment
Frequent, clear, and concise communication to IT leaders and business leaders is a key aspect of this role
Daily tasks might include development stand ups, communicating with different teams including Pricing, Product, eCommerce, and Marketing, verifying continual integration and deployment are functioning as needed, and winning the ping pong championship!
Qualification
Required
Proficient in high-level languages such as Python, Ruby or Javascript
Experienced in data movement, Linux(Centos, Ubuntu), Systems integration, testing, and deployment
Experience with RDBMS (MySQL, Postgres)
A desire to work in a fast growing, fast paced, company
Familiarity with agile methodology
Bachelor's degree in computer science or computer engineering or a STEM field required
Preferred
SQLAlchemy is a plus
ETL experience is a plus
master's degree preferred

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                     Master’s CS student building reliable backend, full-stack, and distributed systems.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision
      (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, restricting access with VPC networking and security groups.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LaunchOps: Employee Onboarding Platform | Django, ReactJS, Python | GitHub                     March 2026
   ∙Created a Django REST and React platform that guides new employees through a 20-task onboarding workflow shared
     by HR, IT, and managers, with an owner and prerequisites on every task.
   ∙Enforced server-side rules that reject forged evidence, skipped prerequisites, duplicate submissions, and edits to other
      users’ tasks, and hold completion while support issues stay open.
   ∙Implemented a real-time quiz service in Go that runs as two copies behind nginx, with Redis keeping both copies in sync
     and a unique MongoDB index rejecting duplicate answers in live sessions.

LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka | GitHub                        October 2026
   ∙Designed a payment API and a double-entry ledger as two Spring Boot services that talk through Kafka.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Configured a GitHub Actions CI workflow that runs all 94 of the ledger’s tests.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.

GoingOnce: Multi-Agent Car Marketplace | Python, LangGraph, ReactJS, JavaScript | GitHub          October 2026
   ∙Prototyped a four-agent car marketplace with a four-person team; a human approves every simulated bid or listing.
  ∙Wrote the Streamlit and React interface that shows each agent’s progress live from the streaming API.
  ∙Coded the Negotiate agent, where each side’s agent keeps a private price limit and a mediator closes the gap in rounds,
     then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, JavaScript, Java, Go, SQL, MySQL, PostgreSQL, MongoDB
  ∙Frameworks & Libraries: Django REST Framework, Django, ReactJS, Spring Boot
   ∙Software Engineering: Full-Stack Development, Production Deployment, Agile, Unit Testing, Application Monitoring,
    ETL, Scrum, REST APIs, Parallel Processing, Event-Driven Architecture
   ∙Tools: Linux, Redis, Apache Kafka, GitHub Actions, nginx, Git, WebSockets, AWS (EC2/RDS), Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Software Developer- Full Stack role at Zoro. I want to help build the data management, monitoring, and deployment processes that let Zoro scale with customer demand. At Thesis Mumbai Tech, I developed Patient Management and Consent modules for 10k+ records and a real-time WebSocket and Redis pipeline that streamed IoT baby-warmer data into PostgreSQL.

LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side rules reject forged evidence, skipped prerequisites, and duplicate submissions. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, it never overdrew the account. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to build scalable infrastructure and customer-facing solutions at Zoro, drawing on LedgerFlow, which kept every balance correct through forced crashes and repeated messages.

Sincerely,
Jay Niketan Pathare
```

---

## 2. Not stated | AL/ML Engineer

Pipeline v3.4.8c; file key Company_Not_Stated_AL_ML_Engineer_a6e1f4; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
AL/ML Engineer#26-01987

svgSan Francisco, CAsvgOnsite

Job Description


AL/ML Engineer
Santa Clara, CA
FT Role

This opportunity is an ideal role for those seeking to build and deploy machine learning models at scale, and thrives in an environment where research translates rapidly into real-world systems.

Key Responsibilities:

- Design, train, and deploy machine learning models for production use at scale.
- Work on LLM-based systems — from fine tuning to building agents and evaluation pipelines.
- Collaborate with engineers and product teams to scope problems, define success metrics, and build robust evaluation frameworks.
- Mitigate LLM challenges: address biases, hallucinations, and knowledge cutoff limitations to improve trust and performance.
- Optimize models for latency, accuracy, and scalability in real-world applications.
- Contribute to end-to-end product development — from research to deployment to iteration.


Qualifications:

- 2+ years of experience in Machine Learning and/or Data Science, with a track record of shipping ML systems into production.
- Strong understanding of Machine Learning and Deep Learning libraries, such as Scikit Learn, Keras, TensorFlow, PyTorch, Theano, or DyLib
- Deep expertise in at least one of: the following:
- Search / retrieval / ranking or recommendation systems
- Generative AI product development (shipping beyond demos, building evals, problem scoping)
- LLM agent products
- LLM fine tuning
- Practical understanding of LLM limitations (bias, hallucinations, knowledge cutoffs).
- Experience working at an early-stage startup or on 0→1 product launches.
- Comfort with both research prototyping and production-grade engineering.


Direct Hire positions: They want local candidates to bay area. Preferred colleges are MIT, California Berkley, Santa Clara, Stanford, California State, Harvey Mudd, SF University. Jr to Mid level experience but looking for top of the class candidates.

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                  Master’s CS student building ML models, evaluation pipelines, and reliable data systems.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals using OCR/LLM
      vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B), CrossRef API, and web scrapers.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
  ∙Added confidence scoring that flags low-confidence fields for human review, and parallelized the pipeline with a CPU-based
     worker pool, cutting total processing time by over 80%.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules: gathered requirements in client meetings,
     prototyped to validate scope, and broke the finalized work into tasks.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitoring dashboard for 4 production projects, pinging each site every 5 minutes to track health.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
Fraud Detection using Graph Neural Networks | PyTorch, GraphSAGE | GitHub                           April 2026
   ∙Benchmarked a GraphSAGE graph neural network at 0.9259 AUC-ROC against a baseline of about 0.858 from a plain
      neural network on the highly imbalanced IEEE-CIS fraud dataset.
  ∙Ran an edge-type ablation across five identifier types, showing the graph adds 0.016 AUC over a no-edge baseline and
     that card links alone deliver almost all of that gain on the held-out test set.
   ∙Prevented data leakage by fitting the feature scaler on the training split only and tuning decision thresholds on validation
      data, then reporting final results only on a held-out 15% test set.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Evaluated the agent on 30 unseen tasks from 16 real code repositories with zero unsupported claims accepted.
   ∙Implemented RIPPLE with Claude Code, checking its generated code by running RIPPLE’s 241-test suite.
   ∙Integrated seven code-analysis tools into the agent’s tool-calling loop under a cap of 25 calls per task.

GoingOnce: Multi-Agent Car Marketplace | Python, LangGraph, ReactJS, Streamlit | GitHub           October 2026
   ∙Prototyped a multi-agent car marketplace with a four-person team: Buy, Sell, Negotiate, and Fleet agents, plus a human
    who approves every simulated bid or listing before it goes through.
  ∙Coded the Negotiate agent, where each side’s agent keeps a private price limit and a mediator closes the gap in rounds,
     then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, SQL, PostgreSQL
  ∙Frameworks & Libraries: PyTorch, LangGraph, ReactJS, Streamlit, TensorFlow, Pandas, NumPy
  ∙AI/ML: Machine Learning, LLMs, Deep Learning, Model Evaluation, GNNs, Agentic AI, Tool Calling
   ∙Software Engineering: Production Deployment, Data Modeling, Parallel Processing, Distributed Systems, Concurrency,
     Application Monitoring
   ∙Tools: Git, Claude Code, Redis, AWS (EC2/RDS), Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the AL/ML Engineer role you posted. I want to help design, train, and deploy machine learning models and build evaluation pipelines for LLM-based systems. At HeinOnline, I built a pipeline that combined the CrossRef API, web scrapers, and OCR/LLM vision to extract metadata from 28k+ pages of law journals with about 91% accuracy.

In my fraud-detection project, I trained graph neural networks in PyTorch on highly imbalanced transaction data. GraphSAGE reached 0.9259 AUC-ROC, against about 0.858 for a plain neural-network baseline. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to optimize models for latency, accuracy, and scalability in real-world applications on your team, building on my fraud model's edge-type ablation, which showed the graph adds 0.016 AUC.

Sincerely,
Jay Niketan Pathare
```

---

## 3. UST | Software Engineer

Pipeline v3.4.8c; file key UST_Software_Engineer; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Careers at UST
Software Engineer

- Job ID: 66812
- 2 Openings
- Frisco
Role description



Software Engineer



The Role

UST is searching for a skilled and motivated Software Engineer to design, develop, test, and maintain high-quality software applications. The ideal candidate will collaborate with cross-functional teams to deliver scalable, reliable, and innovative solutions that meet business requirements.





What You’ll Do

· Design, develop, test, deploy, and maintain software applications.

· Analyze business requirements and translate them into technical solutions.

· Write clean, efficient, and reusable code following coding standards and best practices.

· Participate in code reviews and ensure software quality.

· Troubleshoot, debug, and resolve application issues.

· Collaborate with product managers, architects, QA teams, and stakeholders.

· Develop APIs, integrations, and backend services as required.

· Optimize application performance, scalability, and security.

· Create and maintain technical documentation. Stay updated with emerging technologies and industry trends.



This position description identifies the responsibilities and tasks typically associated with the performance of the position. Other relevant essential functions may be required.



What You Need

· Bachelor's degree in Computer Science, Information Technology, Engineering, or related field.

· Strong programming experience in one or more languages such as Java, C#, Python, JavaScript, or Go.

· Experience with object-oriented design principles and software development methodologies.

· Knowledge of REST APIs, microservices, and web technologies.

· Experience with databases such as SQL Server, MySQL, PostgreSQL, or MongoDB.

· Familiarity with Git and CI/CD tools.

· Understanding of cloud platforms such as Azure, AWS, or GCP.

· Strong problem-solving and analytical skills.

· Excellent communication and teamwork abilities.





Location & Compensation



Compensation can differ depending on factors including but not limited to the specific office location, role, skill set, education, and level of experience. UST provides a reasonable range of compensation for roles that may be hired in various U.S. markets as set forth below.

Role Location: Hybrid- Frisco, Texas

Compensation Range: $56,000-$84,000







Who We Are

Since 1999, UST has worked side by side with the world’s best companies to make a powerful impact through transformation. Headquartered in the United States, UST is powered by technology, driven by AI, inspired by people, and led by our purpose, we partner with our clients from design to operation. Our AI-driven digital solutions, proprietary platforms, engineering, R&D, products, and innovation ecosystem turn core challenges into impactful, disruptive business outcomes. With deep industry knowledge and a future-ready mindset, we infuse expertise, innovation, and agility into our clients’ organizations—delivering measurable value and positive lasting change for them, their customers, and communities around the world. Together, with 30,000+ employees in 30+ countries, we build for boundless impact—touching billions of lives in the process. Visit us at .



Benefits

Full-time, regular employees accrue a minimum of 10 days of paid vacation per year, receive 6 days of paid sick leave each year (pro-rated for new hires throughout the year), 10 paid holidays, and are eligible for paid bereavement leave and jury duty. They are eligible to participate in the Company’s 401(k) Retirement Plan with employer matching. They and their dependents residing in the US are eligible for medical, dental, and vision insurance, as well as the following Company-paid Employee Only benefits: basic life insurance, accidental death and disability insurance, and short- and long-term disability benefits. Regular employees may purchase additional voluntary short-term disability benefits, and participate in a Health Savings Account (HSA) as well as a Flexible Spending Account (FSA) for healthcare, dependent child care, and/or commuting expenses as allowable under IRS guidelines. Benefits offerings vary in Puerto Rico.

Part-time employees receive 6 days of paid sick leave each year (pro-rated for new hires throughout the year) and are eligible to participate in the Company’s 401(k) Retirement Plan with employer matching.

Full-time temporary employees receive 6 days of paid sick leave each year (pro-rated for new hires throughout the year) and are eligible to participate in the Company’s 401(k) program with employer matching. They and their dependents residing in the US are eligible for medical, dental, and vision insurance.

Part-time temporary employees receive 6 days of paid sick leave each year (pro-rated for new hires throughout the year).

All US employees who work in a state or locality with more generous paid sick leave benefits than specified here will receive the benefit of those sick leave laws.



Equal Employment Opportunity Statement

UST is an Equal Opportunity Employer.

All qualified applicants will receive consideration for employment without regard to race, color, religion, sex, sexual orientation, gender identity, national origin, disability, status as a protected veteran, or any other applicable characteristics protected by law. We will consider qualified applicants with arrest or conviction records in accordance with state and local laws and “fair chance” ordinances.

UST reserves the right to periodically redefine your roles and responsibilities based on the requirements of the organization and/or your performance.



\#UST

\#CB

\#LI-AP4
Skills



AI Coding Agents, AI Mentor Studio, AI FinOps
Benefits
Compensation range: $ 56,000.00 to 84,000.00 per year

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
             Master’s CS student building backend APIs, event-driven services, and reliable distributed systems.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant data pipeline that processed 28k+ pages of law journals, combining CrossRef API, web scrapers,
     and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B).
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL | GitHub           October 2026
  ∙Coded the Java payment flow so that each payment takes effect exactly once even when Kafka delivers a message more
     than once, using a transactional outbox and idempotent consumers.
   ∙Prevented overspending under 200 simultaneous payments on an account funded for only 50, letting only the funded
     payments through and leaving the account balance at exactly zero with no overdraft.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Optimized outbox polling to reduce response time for the slowest 5% of payment requests by about 58%.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Created a Git-diff check that flags unexpected edits, missing tests, and stale callers.
   ∙Directed Claude Code while building RIPPLE, checking the code it generated by running RIPPLE’s 241-test suite and
      testing how the agent handles edge cases across real repositories.

LaunchOps: Employee Onboarding Platform | Django, Go, PostgreSQL | GitHub                     March 2026
   ∙Designed a Django REST and React onboarding platform with a 20-task workflow across HR, IT, and managers.
   ∙Enforced server-side checks that block forged evidence, skipped prerequisites, and duplicate submissions.
   ∙Implemented a real-time quiz service in Go that runs as two copies behind nginx, with Redis keeping both copies in sync
     and a unique MongoDB index rejecting duplicate answers in live sessions.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, SQL, Java, Go, JavaScript, PostgreSQL, MongoDB, MySQL
  ∙Frameworks & Libraries: Django REST Framework, Django, Spring Boot, ReactJS
   ∙Software Engineering: REST APIs, Backend Development, Code Review, OOP, Microservices, Continuous Integration,
     Unit Testing, Data Validation, Application Monitoring, Distributed Systems
   ∙Tools: Git, AWS (EC2/RDS), Claude Code, Redis, Apache Kafka, nginx, Docker, WebSockets

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Software Engineer role at UST. I want to help design, develop, test, and maintain the APIs, integrations, and backend services that UST delivers. At Thesis Mumbai Tech, I reviewed and merged team pull requests, mentored new hires through weekly coding rounds, and responded to heartbeat-detected production failures by restoring the affected services.

LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. Under 200 simultaneous payments on an account funded for only 50, only the funded payments went through and the balance ended at exactly zero. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to design, develop, test, deploy, and maintain software applications at UST, building on LedgerFlow, where a GitHub Actions CI workflow runs every automated test.

Sincerely,
Jay Niketan Pathare
```

---

## 4. Meritore Technologies LLC | Software Engineer

Pipeline v3.4.8c; file key Meritore_Technologies_LLC_Software_Engineer; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
company: Capgemini

Job Code : JPC - 1372

Job Description

JOB ID 12239: Software Engineer

Meritore Technologies LLC, a Ashburn, VA based IT Solution, Services and Product Development Firm has Multiple Openings for JOB ID 12239: Software Engineer.

Job duties include:

- Design develop software modules and components.
- Write clean, efficient, and well-documented code.
- Participate in code reviews to improve code quality.
- Conduct unit and integration testing to ensure software quality.
- Collaborate with team members to identify and resolve issues.
- Use version control systems to manage code effectively.
- Stay updated with the latest technologies and industry trends.



Requirements:

Bachelor's degree in Science, IT, Business Administration or related with at least 12 months of experience or 3 consecutive years of related Bachelor’s level education in Science, IT, Business Administration or related with 24 months of experience.

Salary ranges between $150,758.00 to $153,000.00/year.

Send resume to: hr@meritore.com including the JOB ID.

Travel and relocation to various unanticipated client locations throughout the United States may be required. Equal Opportunity Employer

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                     Master’s CS student building reliable backend, full-stack, and distributed systems.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision
      (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitoring dashboard for 4 production projects, pinging each site every 5 minutes to track health.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Evaluated the agent on 30 unseen tasks from 16 real code repositories with zero unsupported claims accepted.
   ∙Created a Git-diff check that flags unexpected edits, missing tests, and stale callers.
   ∙Measured agent usage at about 10 tool calls and about 17 model calls per run, with under one duplicate call.
   ∙Implemented RIPPLE with Claude Code, checking its generated code by running RIPPLE’s 241-test suite.
   ∙Integrated seven code-analysis tools into the agent’s tool-calling loop under a cap of 25 calls per task.

LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL | GitHub           October 2026
   ∙Designed a payment API and a double-entry ledger as two Spring Boot services that talk through Kafka.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Configured a GitHub Actions CI workflow that runs all 94 of the ledger’s tests, including integration tests that start real
     database and message-broker containers with Testcontainers.

GoingOnce: Multi-Agent Car Marketplace | Python, LangGraph, ReactJS, Streamlit | GitHub           October 2026
   ∙Prototyped a multi-agent car marketplace with a four-person team: Buy, Sell, Negotiate, and Fleet agents, plus a human
    who approves every simulated bid or listing before it goes through.
  ∙Coded the Negotiate agent, where each side’s agent keeps a private price limit and a mediator closes the gap in rounds,
     then closes the simulated deal: escrow payment, insurance, loan payoff, title, and transport.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, Java, SQL, PostgreSQL, MySQL
  ∙Frameworks & Libraries: Testcontainers, ReactJS, Spring Boot
   ∙Software Engineering: Code Review, Integration Testing, Unit Testing, Data Validation, REST APIs, Full-Stack
     Development, Microservices, Backend Development, Event-Driven Architecture, ETL
   ∙Tools: Git, Apache Kafka, GitHub Actions, Claude Code, Redis, AWS (EC2/RDS)

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Software Engineer role at Meritore Technologies LLC. I want to help design and develop software modules and components with clean, efficient, and well-documented code at Meritore. At Thesis Mumbai Tech, I reviewed and merged team pull requests, mentored new hires through weekly coding rounds, and responded to heartbeat-detected production failures by restoring the affected services.

I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Its Git-diff check flags unexpected edits, missing tests, and stale callers. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, it never overdrew the account. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to improve code quality at Meritore Technologies LLC, building on LedgerFlow, where a GitHub Actions CI workflow runs every automated test.

Sincerely,
Jay Niketan Pathare
```

---

## 5. Allergan Aesthetics | Integration Engineer

Pipeline v3.4.8c; file key Allergan_Aesthetics_Integration_Engineer; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Integration Engineer
Allergan Aesthetics
North Chicago, IL, Entry Level, Onsite, Full Time, Software Engineering
Education: Bachelor's (required)

Company Description
About AbbVie
AbbVie's mission is to discover and deliver innovative medicines and solutions that solve serious health issues today and address the medical challenges of tomorrow. We strive to have a remarkable impact on people's lives across several key therapeutic areas including immunology, oncology, and neuroscience - and products and services in our Allergan Aesthetics portfolio. For more information about AbbVie, please visit us at Follow @abbvie on LinkedIn, Facebook, Instagram, X and YouTube.

Job Description
Global Therapeutic Platforms (GTP) Architecture & Platforms (A&P) builds the shared integration, API, data, and AI platforms that GTP teams use across the R&D lifecycle, including clinical, safety, and regulatory workflows.
We are seeking an early-career Integration Engineer to help build and support system-to-system integrations and APIs on AWS. You will work with senior engineers and business stakeholders, start with well-scoped tasks, and take on more ownership as you grow. AI coding agents such as Claude Code or Codex are a core part of how we build, test, and document software.

Responsibilities
- Gather and clarify requirements with business and technical stakeholders.
- Build, test, and deploy integrations and APIs using AWS serverless services such as Lambda, Step Functions, SQS/SNS, EventBridge, S3, and API Gateway.
- Write clean, maintainable code with proper error handling, logging, and retry, following team patterns.
- Use Terraform, GitHub Actions, and Git-based workflows to deploy and manage your work.
- Use AI coding agents day to day, following team standards for reviewing AI-generated code.
- Help monitor and troubleshoot integrations in production.
- Communicate clearly, share status, raise blockers early, and document your work.
- Follow corporate policies, including cybersecurity, change control, and the software development lifecycle.

Qualifications
Required:
- Bachelor's degree in Computer Science, Software Engineering, or Information Systems.
- Internship, co-op, or substantial project experience building software.
- Proficiency in at least one language such as Python, TypeScript/JavaScript, or Java.
- Hands-on experience using AI coding agents (Claude Code, Codex, or similar) to build working software, and the ability to explain how you checked the agent's output.
- Working knowledge of Git and a basic understanding of APIs and event-driven architecture.
- Strong problem-solving and communication skills, and a willingness to learn quickly.
- Initiative and ownership pick up work proactively, seeks help when needed, and keeps others informed.
Preferred:
- Exposure to AWS, Terraform, or CI/CD pipelines such as GitHub Actions.
- Familiarity with REST/OpenAPI or SQL databases.
- AWS certification or interest in pursuing one.

Additional Information
The compensation range described below is the range of possible base pay compensation. We offer a comprehensive package of benefits including paid time off, medical/dental/vision insurance and 401(k) to eligible employees. This job is eligible to participate in our short-term incentive programs.
AbbVie is an equal opportunity employer. Equal Opportunity Employer/Veterans/Disabled.
US & Puerto Rico only - to learn more, visit

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                Master’s CS student building event-driven APIs, backend services, and AI-assisted software.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant data pipeline that processed 28k+ pages of law journals, combining CrossRef API, web scrapers,
     and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B).
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
   ∙Gathered requirements in client meetings, prototyped to validate scope, and led a team of 4 through end-to-end delivery
      of healthcare platform modules.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, GitHub Actions | GitHub        October 2026
   ∙Designed a payment API and a double-entry ledger as two Spring Boot services that talk through Kafka.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Stress-tested the ledger with 200 simultaneous payment requests against an account funded for only 50; only funded
     payments went through and the balance ended at zero with no overdraft.
   ∙Verified the Java payment ledger in a GitHub Actions CI workflow that runs all 94 of its tests, including integration tests
     that run against real PostgreSQL and Kafka instances in containers.

LaunchOps: Employee Onboarding Platform | Django, ReactJS, Python | GitHub                     March 2026
   ∙Created a Django REST and React platform that guides new employees through a 20-task onboarding workflow shared
     by HR, IT, and managers, with an owner and prerequisites on every task.
   ∙Enforced server-side rules that reject forged evidence, skipped prerequisites, duplicate submissions, and edits to other
      users’ tasks, and hold completion while support issues stay open.
   ∙Implemented a real-time quiz service in Go that runs as two copies behind nginx, with Redis keeping both copies in sync
     and a unique MongoDB index rejecting duplicate answers in live sessions.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Evaluated the agent on 30 unseen tasks from 16 real code repositories with zero unsupported claims accepted.
   ∙Directed Claude Code while building RIPPLE, checking the code it generated by running RIPPLE’s 241-test suite and
      testing how the agent handles edge cases across real repositories.
   ∙Validated every finished code change with RIPPLE’s own Git-diff check, which runs after the change is made, reads its
     Git diff, and flags unexpected edits, missing tests, and stale callers.

TECHNICAL SKILLS
  ∙Languages & Databases: Python, Java, SQL, Go, JavaScript, PostgreSQL, MongoDB
  ∙Frameworks & Libraries: Django REST Framework, Django, Spring Boot, ReactJS
   ∙Software Engineering: REST APIs, Event-Driven Architecture, Application Monitoring, Production Deployment,
    SDLC, Continuous Integration, Microservices, Backend Development, Full-Stack Development, Unit Testing
   ∙Tools: Git, Claude Code, AWS (EC2/RDS), GitHub Actions, Redis, Apache Kafka, nginx, GitHub

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Integration Engineer role at Allergan Aesthetics. I want to help build and support system-to-system integrations and APIs on AWS for clinical and regulatory workflows. At Thesis Mumbai Tech, I led delivery of healthcare platform modules with a team of 4, gathering requirements in client meetings and prototyping to validate scope.

LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. A GitHub Actions CI workflow runs its 94 automated tests. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to build, test, and deploy integrations and APIs at Allergan Aesthetics, drawing on LedgerFlow, where each payment takes effect exactly once.

Sincerely,
Jay Niketan Pathare
```

---

## 6. Audible, Inc. | Software Development Engineer

Pipeline v3.4.8c; file key Audible_Inc_Software_Development_Engineer; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Software Development Engineer
Job ID: 10539152 | Audible, Inc.
Description
At Audible, we believe stories have the power to transform lives. It's why we work with some of the world's leading creators to produce and share audio storytelling with our millions of global listeners. We are dreamers and inventors who come from a wide range of backgrounds and experiences to empower and inspire each other. Imagine your future with us.

ABOUT YOU
If you're a dedicated problem solver, this is the role for you. Identifying and overcoming challenges is at the heart of everything you do; whether it's looking ahead to our listeners problems, or analyzing every inefficiency, you thrive when you strive for perfection. We look for people who take responsibility, who feel the pride in a job well done and see every failure as an opportunity to learn. With a knowledgeable team around you, and opportunities to challenge yourself, it's a perfect environment to develop and apply your new skills.

As a Software Development Engineer, you will...
- Develop, test, and maintain software components and applications for the world's largest audiobook creator and provider
- Identify and resolve software defects through code review, log analysis, metrics examination, debugging, and other troubleshooting methods
- Write maintainable and scalable code for software components as part of an agile engineering team
- Collaborate with stakeholders to envision, design, develop, test, and launch customer-centric software that inspires and impacts users
- Apply computer science, engineering, and analysis principles to solve moderate-scale problems
- Continuously enhance testability, operational excellence (OE), and documentation for owned software components
- Handle data classification, storage, and management in accordance with company policies
- Participate in the interview process and provide mentorship to fellow engineers

ABOUT AUDIBLE
Audible is the leading producer and provider of audio storytelling. We spark listeners' imaginations, offering immersive, cinematic experiences full of inspiration and insight to enrich our customers' daily lives. We are a global company with an entrepreneurial spirit. We are dreamers and inventors who are passionate about the positive impact Audible can make for our customers and our neighbors. This spirit courses throughout Audible, supporting a culture of creativity and inclusion built on our People Principles and our mission to build more equitable communities in the cities we call home.
Basic Qualifications
- Experience programming with at least one software programming language
- Bachelor's degree or equivalent in Computer Science
Preferred Qualifications
- Experience from previous technical internship(s) or demonstrated project experience
- Experience with Cloud platforms (preferably AWS), database systems (SQL and NoSQL), AI tools for development productivity, contributing to open-source projects, and/or version control systems
- Experience delivering large, cross-functional, customer facing products

Amazon is an equal opportunity employer and does not discriminate on the basis of protected veteran status, disability, or other legally protected status.

Newark, NJ, USA - 141,900.00 USD Annually

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
              Master’s CS student building maintainable, well-tested software with code review and monitoring.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision
      (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL | GitHub           October 2026
  ∙Coded the Java payment flow so that each payment takes effect exactly once even when Kafka delivers a message more
     than once, using a transactional outbox and idempotent consumers.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Configured a GitHub Actions CI workflow that runs all 94 of the ledger’s tests, including integration tests that start real
     database and message-broker containers with Testcontainers.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
   ∙Designed RIPPLE, a Python command-line AI agent that reads a plain-English change request and predicts which files,
       tests, and regression risks it will touch before any code is written.
  ∙Wrote RIPPLE with Claude Code as a coding assistant, checking its output with RIPPLE’s 241-test suite and testing
    how the agent handles edge cases across the real code repositories it analyzes.

LaunchOps: Employee Onboarding Platform | Django, ReactJS, PostgreSQL | GitHub                 March 2026
   ∙Created a Django REST and React platform that guides new employees through a 20-task onboarding workflow shared
     by HR, IT, and managers, with an owner and prerequisites on every task.
   ∙Implemented a real-time quiz service in Go that runs as two copies behind nginx, with Redis keeping both copies in sync
     and a unique MongoDB index rejecting duplicate answers in live sessions.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: SQL, Python, Java, Go, PostgreSQL, NoSQL, MongoDB, MySQL
  ∙Frameworks & Libraries: Django REST Framework, Testcontainers, Django, ReactJS, Spring Boot
   ∙Software Engineering:  Code Review,  Debugging,  Agile,  Application Monitoring,  Unit  Testing, REST APIs,
     Event-Driven Architecture, Parallel Processing, Distributed Systems, Concurrency
   ∙Tools: Claude Code, Redis, Apache Kafka, GitHub Actions, Git, nginx, AWS (EC2/RDS), Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Software Development Engineer role at Audible, Inc. I want to develop, test, and maintain software components and applications that bring audio storytelling to Audible's listeners. At Thesis Mumbai Tech, I reviewed and merged team pull requests, mentored new hires through weekly coding rounds, and responded to heartbeat-detected production failures by restoring the affected services.

LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, it never overdrew the account. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to write maintainable and scalable code for software components at Audible, Inc., building on LedgerFlow, where a GitHub Actions CI workflow runs every automated test.

Sincerely,
Jay Niketan Pathare
```

---

## 7. DoorDash | Software Engineer, ML Infrastructure (MDX)

Pipeline v3.4.8c; file key DoorDash_Software_Engineer_ML_Infrastructure_MDX; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Software Engineer, ML Infrastructure (MDX)
DoorDash
San Francisco, CA; Sunnyvale, CA; Seattle, WA | USD 131k - 192k /yr | Entry Level | Onsite | Full Time | 2+ years experience | Software Engineering
Education: Bachelor's (required), PhD (preferred), Master's (preferred)

About the Team
DoorDash's MDX team sits within Machine Learning Platform and builds the shared foundation that ML engineers across DoorDash, Wolt, and Deliveroo rely on to build and run ML-powered products. We work across the full ML lifecycle: feature engineering, training, evaluation, deployment, serving, and monitoring. Our mission is to increase the velocity and reliability of ML-driven business impact across the company. A central pillar of that work is agentic infrastructure. We are building systems that let agents accelerate and operate the ML workflow itself, including auto research, where agents explore and iterate on modeling ideas, and self-healing systems that detect, diagnose, and remediate failures in ML pipelines and production models with minimal human intervention.

About the Role
You will join a small, high-leverage team building the agentic layer of DoorDash's ML infrastructure. You'll design and build the systems that let agents accelerate how ML engineers across DoorDash, Wolt, and Deliveroo develop, ship, and operate models. That includes auto research systems that explore and iterate on modeling ideas, and agentic developer support that helps ML engineers move through training, evaluation, deployment, and debugging faster. You'll own well-scoped components end to end, from design through production, working across agent orchestration, tooling and integrations with our ML platform, evaluation of agent behavior, and observability. This role is ideal for an engineer with a strong backend foundation who is excited to apply AI agents to real engineering workflows, learns quickly, and wants to grow into technical leadership in a fast-moving area where model capabilities, tooling, and best practices change month to month.

You're excited about this opportunity because you will...
- Build agentic systems that increase the velocity of ML development across DoorDash, Wolt, and Deliveroo, helping ML engineers get from idea to production model faster.
- Design and implement infrastructure that lets agents propose, run, and evaluate modeling experiments.
- Build agentic developer support for the ML lifecycle, such as agents that help engineers set up training jobs, debug failing pipelines, review model deployments, and navigate our platform.
- Develop evaluation and observability for agent behavior, so we can measure whether agents are actually helping, catch regressions early, and build the trust needed to give them more autonomy.
- Work with production standards in mind, including reliability, safety guardrails, cost controls, monitoring, and clear playbooks, so that agentic workflows can run against real ML systems.
- Partner closely with ML engineers, data scientists, and platform teams to understand where their time goes and turn those workflows into durable, reusable platform capabilities.
- Grow quickly in a fast-moving area, with the chance to shape how agents are used to build and operate ML systems at a company of this scale.

We're excited about you because...
- B.S., M.S., or PhD in Computer Science or equivalent
- 2+ years of industry experience in software engineering
- Hands-on experience building ML infrastructure in production including feature engineering and feature stores, data pipelines for ML, training and experimentation platforms, model evaluation, deployment, serving and inference, or monitoring
- Strong backend engineering fundamentals, especially in Python and distributed systems
- Experience operating systems in production, including testing, observability, debugging, and reliability
- A good understanding of how ML engineers and data scientists work, and a track record of building platforms, tools, or services that make them more productive
- Ability to take ambiguous, well-scoped problems from idea to production, and to learn quickly in a fast-moving technical area
- Proficiency in using AI coding tools (e.g., Claude Code, Codex, Cursor) across the software development lifecycle, including designing, generating code, testing, monitoring, and releasing software

Nice To Haves
- Experience building LLM-powered applications or AI agents, including tool use, orchestration, or MCP servers, in production or on substantial projects
- Experience with agent evaluation, LLM observability, tracing, or building eval harnesses
- Experience with ML platforms or MLOps tooling (e.g., Kubeflow, MLflow, Ray, Airflow)
- Experience with Kubernetes and cloud infrastructure (AWS/GCP)
- Experience building developer tools, internal platforms, or self-serve infrastructure
- Experience with guardrails, safety, or cost controls for LLM systems

National base pay range: $130,600 - $192,000 USD
[Compensation, benefits, company, diversity, NYC tool notice and scam notice text removed]

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                     Master’s CS student building agentic developer tools and reliable backend systems.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals using OCR/LLM
      vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B), CrossRef API, and web scrapers.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
  ∙Added confidence scoring that flags low-confidence fields for human review, and parallelized the pipeline with a CPU-based
     worker pool, cutting total processing time by over 80%.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules: gathered requirements in client meetings,
     prototyped to validate scope, and broke the finalized work into tasks.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, restricting access with VPC networking and security groups.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Evaluated the agent on 30 unseen tasks from 16 real code repositories with zero unsupported claims accepted.
   ∙Directed Claude Code while building RIPPLE, checking the code it generated by running RIPPLE’s 241-test suite and
      testing how the agent handles edge cases across real repositories.
   ∙Integrated seven code-analysis tools into the agent’s tool-calling loop under a cap of 25 calls per task, with Python code
     checking each claim against evidence before it enters the report.

LedgerFlow: Event-Driven Payment Ledger | Java, Kafka, PostgreSQL | GitHub                        October 2026
   ∙Designed a payment API and a double-entry ledger as two Java services that talk through Kafka.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Verified that all 250 payments completed with no duplicates while a service restarted in local Kubernetes.

LLM Application Optimization Engine | Python, Gemini API, Novita API, pytest | GitHub                  July 2026
   ∙Created an LLM pipeline that turns a job description into a tailored one-page resume and cover letter.
   ∙Implemented failover from Gemini to Novita’s model API after 3 failed attempts, repairing only failed parts.
   ∙Enforced Python checks that compare every generated resume claim against real source evidence and reject unsupported
      technologies, borrowed results, or changed numbers before output.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, Java, SQL, PostgreSQL, MySQL
  ∙Frameworks & Libraries: pytest, Pandas, NumPy
  ∙AI/ML: Machine Learning, AI Agents, Agentic Workflows, Model Evaluation, LLMs, Tool Calling
   ∙Software Engineering:  Production Deployment, Application Monitoring, Debugging, Distributed Systems, Unit
      Testing, SDLC, Data Pipelines, Data Modeling, Parallel Processing, Data Validation
   ∙Tools: Claude Code, Kubernetes (local k3d), AWS (EC2/RDS), Cursor, Apache Kafka, Git, Gemini API, Novita API

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Software Engineer, ML Infrastructure (MDX) role at DoorDash. I want to design and implement infrastructure that lets agents propose, run, and evaluate modeling experiments for DoorDash's ML platform. At HeinOnline, I built a pipeline that combined the CrossRef API, web scrapers, and OCR/LLM vision to extract metadata from 28k+ pages of law journals with about 91% accuracy.

I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, it never overdrew the account. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to build agentic systems that increase the velocity of ML development at DoorDash, drawing on my LLM engine's provider failover.

Sincerely,
Jay Niketan Pathare
```

---

## 8. ElevenLabs | Full-Stack Engineer (Backend Leaning) - Platform Engineering

Pipeline v3.4.8c; file key ElevenLabs_Full_Stack_Engineer_Backend_Leaning_Platform_Engineering; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Full-Stack Engineer (Backend Leaning) - Platform Engineering
Eleven Labs
Remote | Entry Level | Full Time | Software Engineering

[Company description, "How we work" and "What we offer" sections removed]

About the role
Core Platform builds the foundations every other team at ElevenLabs builds on: how users, workspaces and permissions work across our products. Our systems sit on the path of every request and are relied on by millions of users and by enterprise customers, so correctness, security and safe rollout matter as much as speed.

We are hiring full stack engineers (backend leaning) for two focus areas. Depending on the team you join, your responsibilities might include:

Workspaces & User Management (serving external customers)
- Building and improving the building blocks customers touch directly: API keys, login experience, analytics, admin tooling, workspace security and more
- Working closely with Sales, FDEs and customer teams to turn enterprise and self-serve feedback into the right improvements, and helping large customers with complex organisational structures.
- Shipping customer-facing features end to end, from backend services to the admin and settings UI.

Permissions & Resources (serving ElevenLabs engineering teams)
- Designing and building generic resource and permissioning services that product teams use to build features safely and quickly.
- Solving hard, largely greenfield problems at scale, for example how a customer with a million agents assigns and manages access.
- Working across product teams to understand their needs, and driving adoption with changes that don't require every team to rework their code.

In both teams you will:
- Scope work as part of a large existing system: understand what exists, what could go wrong on rollout, whether a migration is needed, and how downstream teams are affected.
- Roll out changes safely and with minimal disruption to existing users, teams or systems.
- Debug and operate what you build, working from customer reports, logs and code.
- Own features from scoping to completion, with the support of experienced engineers who are happy to mentor.

Requirements
We do not require any formal experience, certifications, or degrees. Instead, we are seeking engineers who can show they have solved impressively hard problems, through past projects or GitHub contributions. We do require:
- Expertise in Python.
- A strong background in backend development, with comfort working across the stack where the work needs it.
- Experience with common software and system design patterns and infrastructure, including APIs, cloud infrastructure tools, storage solutions and data structures.
- Strong test design and security fundamentals.
- Care and attention to detail when changing live, business-critical systems, and the ability to learn a large existing codebase quickly.
- Comfort with ambiguity: working out what should be built, and prioritising among competing signals.

Bonus:
- Experience with authentication, authorization or permissioning (OAuth, SSO/SCIM, RBAC or similar).
- Experience with Kubernetes.
- Experience building internal platforms or services used by other engineering teams.

Location
Our team is based across the UK, EU and US, and this is our main focus. We are flexible for exceptional candidates elsewhere. You can work remotely, or from our offices in Dublin, London, New York, San Francisco and Warsaw.
[Equal-opportunity text removed]

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                      Master’s CS student building backend services and full-stack features end to end.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant data pipeline that processed 28k+ pages of law journals, combining CrossRef API, web scrapers,
     and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B).
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
   ∙Gathered requirements in client meetings, prototyped to validate scope, and led a team of 4 through end-to-end delivery
      of healthcare platform modules.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LaunchOps: Employee Onboarding Platform | Django, ReactJS, Python | GitHub                     March 2026
   ∙Designed a Django REST and React onboarding platform with a 20-task workflow across HR, IT, manager, and employee
       roles, where each task has an owner, prerequisites, and evidence.
   ∙Enforced server-side rules that reject forged evidence, skipped prerequisites, duplicate submissions, and edits to other
      users’ tasks, and hold completion while support issues stay open.
   ∙Created a live-quiz service in Go that runs as two copies behind nginx, with Redis coordinating both copies and a unique
     database index that rejects duplicate answers in live sessions.

LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL | GitHub           October 2026
  ∙Coded the Java payment flow so that each payment takes effect exactly once even when Kafka delivers a message more
     than once, using a transactional outbox and idempotent consumers.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Configured a GitHub Actions CI workflow that runs all 94 of the ledger’s tests.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Evaluated the agent on 30 unseen tasks from 16 real code repositories with zero unsupported claims accepted.
   ∙Integrated seven code-analysis tools into the agent’s tool-calling loop under a cap of 25 calls per task.
   ∙Implemented RIPPLE with Claude Code, checking its generated code by running RIPPLE’s 241-test suite.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, Java, Go, SQL, PostgreSQL, MySQL
  ∙Frameworks & Libraries: Django REST Framework, Django, Spring Boot, ReactJS
   ∙Software Engineering: REST APIs, Backend Development, System Design, Data Structures, Debugging, Full-Stack
     Development, Parallel Processing, Event-Driven Architecture, Distributed Systems, Concurrency
   ∙Tools: Redis, OAuth/Auth0, Apache Kafka, GitHub Actions, Git, Claude Code, nginx, GitHub, JWT

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Full-Stack Engineer (Backend Leaning) - Platform Engineering role at ElevenLabs. I want to build the core platform foundations that every ElevenLabs product builds on, so users, workspaces and permissions stay correct and secure. At Thesis Mumbai Tech, I reviewed and merged team pull requests, mentored new hires through weekly coding rounds, and responded to heartbeat-detected production failures by restoring the affected services.

LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side permission checks block users from editing other users' tasks and reject forged evidence and skipped prerequisites. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. A GitHub Actions CI workflow runs its 94 automated tests. I graduate in December 2026 and can start work in February 2027. I want to design and build generic resource and permissioning services at ElevenLabs, drawing on LaunchOps, where every onboarding task has an owner and prerequisites the server enforces.

Sincerely,
Jay Niketan Pathare
```

---

## 9. Figure | Embedded Software Engineering Intern, Platform

Pipeline v3.4.8c; file key Figure_Embedded_Software_Engineering_Intern_Platform; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- graduation_window: The posting sets a graduation date that does not include Jay's December 2026 graduation. ("Student eligibility: Graduating May 2027 - May 2027")
- student_audience: The program is aimed at students with school left after the program; Jay graduates in December 2026. ("- Rising senior or recent graduate in Computer Science, Computer Engineering, Electrical Engineering, or a related field; must be graduating within one year.")

### JOB POSTING
Embedded Software Engineering Intern, Platform
Figure
San Jose, CA | USD 40 - 45 /hr | Internship | Onsite | Full Time | Software Engineering
Student eligibility: Graduating May 2027 - May 2027
Education: Bachelor's (required)

Figure is an AI robotics company developing autonomous general-purpose humanoid robots. The goal of the company is to ship humanoid robots with human level intelligence. Its robots are engineered to perform a variety of tasks in the home and commercial markets. Figure is headquartered in San Jose, CA.

We are looking for an Embedded Software Engineering Intern to join our Platform team. In summary, you will help build and improve the core software infrastructure that keeps our robot fleet running, with a focus on over-the-air (OTA) and firmware update systems that deliver software reliably and securely to robots in the field.

Responsibilities:
- Design, implement, and test features for the robot software platform, including OTA update delivery, firmware update flows, and the embedded Linux systems that support them.
- Work across software and hardware layers to integrate, debug, and validate updates on real robot hardware.
- Improve the reliability, security, and scalability of how software is deployed across the fleet.
- Measure the impact of your work and share results and recommendations with the team.

Requirements:
- Rising senior or recent graduate in Computer Science, Computer Engineering, Electrical Engineering, or a related field; must be graduating within one year.
- Minimum 10 weeks.
- Strong programming skills in C, C++, Rust, or Python.
- Experience with Linux and networking fundamentals.

Bonus Qualifications:
- Experience with embedded Linux build and update tools such as Yocto, RAUC, or SWUpdate.
- Experience with firmware development, bootloaders, or hardware bring-up.
- Familiarity with applied cryptography, such as code signing, PKI, or secure boot.

The US base pay range for this position is $40.00 to $45.00 per hour.

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
             Master’s CS student building tested C systems code with process management and synchronization.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision
      (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules: gathered requirements in client meetings,
     prototyped to validate scope, and broke the finalized work into tasks.
   ∙Developed a real-time WebSocket + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live
     monitoring, plus Patient Management and Consent modules on normalized schemas for 10k+ records.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

PERSONAL PROJECTS
Pintos Operating System: User Programs Layer | C, x86, Operating Systems, Concurrency             May 2026
   ∙Implemented a teaching operating system’s user-programs layer in C, passing all 80 tests for program startup with
     arguments, parent-child waiting, system calls, and file handling.
   ∙Enforced thread synchronization with locks around shared kernel resources and safety checks on memory access, keeping
     the kernel safe when several user programs run at the same time.
  ∙Programmed the system-call interface that lets user programs open and manage files and processes through the kernel,
     supporting 13 system calls and up to 128 open files per process.

LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL | GitHub           October 2026
   ∙Designed a payment API and a double-entry ledger as two Spring Boot services that talk through Kafka.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Configured a GitHub Actions CI workflow that runs all 94 of the ledger’s tests, including integration tests that start real
     database and message-broker containers with Testcontainers.
   ∙Validated payment correctness by forcing 14 service crashes and repeating 18,000 messages; every one of those runs ended
     with no wrong balances and no payment recorded twice in the ledger.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Integrated seven code-analysis tools into the agent’s tool-calling loop under a cap of 25 calls per task.
   ∙Evaluated the agent on 30 unseen tasks from 16 real code repositories with zero unsupported claims accepted.
   ∙Created a Git-diff check that flags unexpected edits, missing tests, and stale callers.
   ∙Directed Claude Code while building RIPPLE, checking the code it generated by running RIPPLE’s 241-test suite and
      testing how the agent handles edge cases across real repositories.

TECHNICAL SKILLS
  ∙Languages & Databases: Python, C, Java, SQL, PostgreSQL
  ∙Frameworks & Libraries: Testcontainers, Spring Boot
   ∙Software Engineering: Concurrency, Parallel Processing, Thread Synchronization, Operating Systems, Microservices,
     Application Monitoring, Event-Driven Architecture
   ∙Tools: Linux, Apache Kafka, GitHub Actions, Git, Claude Code, AWS (EC2/RDS), Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Embedded Software Engineering Intern, Platform role at Figure. I want to help build and improve the core software infrastructure that keeps Figure's robot fleet running safely through every update. At Thesis Mumbai Tech, I built a real-time WebSocket and Redis pipeline that streamed IoT baby-warmer device data into PostgreSQL with about 2-second live monitoring.

For an operating systems course, I wrote the user-programs layer of the Pintos teaching operating system in C. All 80 tests pass. LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, it never overdrew the account. My Master's in Computer Science at the University at Buffalo is expected in December 2026, and I can start work in February 2027. I am open to relocating. I want to integrate, debug, and validate updates on real robot hardware at Figure, building on the process management I wrote in C for Pintos.

Sincerely,
Jay Niketan Pathare
```

---

## 10. Laminar | Jr. Machine Learning (ML) Developer

Pipeline v3.4.8c; file key Laminar_Jr_Machine_Learning_ML_Developer; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Jr. Machine Learning (ML) Developer
Laminar
Somerville, MA

Responsibilities
Build machine learning models that usher in the next generation of data-driven, fluid-based industrial processes powered by Laminar's proprietary spectral sensors and software platform
Design and run experiments to evaluate and select machine learning models that are generalizable, accurate, and robust to day-to-day process variability
Work with spectral and multi-modal sensor data, building preprocessing and feature extraction pipelines that can derive insights from noisy, real-world sensors
Support model reliability by developing monitoring (and correction systems, when applicable) for model drift, sensor drift, and process anomalies
Develop performant ML infrastructure and tooling in collaboration with ML/Data Scientists and software team members
Work across problem domains including chemometrics, hybrid modeling, and self-supervised learning. Modeling tasks include distribution modeling, drift and anomaly detections, similarity analyses, and continuous calibration
Qualification
Required
Proficient in at least one Python ML framework (PyTorch, JAX, TensorFlow)
Fluent with Python packages for numeric computing and data workflows (e.g. NumPy, Polars, Pandas, scikit-learn)
An engineer who favors clean, testable code and has a proven track record of delivering high-quality work on a timeline
An executor who thrives with direction and can independently complete technical project objectives
Someone detail-oriented who has a natural curiosity about data
You are enthusiastic to test out hypotheses, understand in detail how our models work, and run physical experiments to improve our modeling capabilities
Preferred
Chemical engineering, process engineering, or manufacturing domain knowledge (highly valued)
Experience with cloud environments (AWS, GCP) and/or Databricks
Familiarity with spectral data, time-series modeling, or sensor-driven ML
Familiarity with Bayesian modeling and probabilistic reasoning
Experience building real products (ideally utilizing machine learning) and practicing user-centric design
Benefits
Direct impact on product and culture.
Comprehensive benefits package including Medical, Dental, Vision, Life Insurance, Disability, Transportation benefit, Health and Wellness benefit, and more.
401k plan with employer matching
Equity
Bonus opportunities.
Dynamic and inclusive work environment.
Opportunities for growth and professional development.
Access to Greentown Labs' extensive network of cleantech startups.
Transportation benefit for your commute
A team that celebrates together from rooftop lunches, ping pong matches, Lunch & Learns, and regular team events
Company
Laminar
Laminar delivers factory floor transformation with our spectral sensors and science-led AL/ML models. Formerly H2Ok Innovations.
Somerville, Massachusetts, USA

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                Master’s CS student building machine learning models and testable data pipelines in Python.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals using OCR/LLM
      vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B), CrossRef API, and web scrapers.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
  ∙Added confidence scoring that flags low-confidence fields for human review, and parallelized the pipeline with a CPU-based
     worker pool, cutting total processing time by over 80%.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules: gathered requirements in client meetings,
     prototyped to validate scope, and broke the finalized work into tasks.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
Fraud Detection using Graph Neural Networks | PyTorch, Pandas | GitHub                                April 2026
   ∙Benchmarked a GraphSAGE graph neural network at 0.9259 AUC-ROC against a baseline of about 0.858 from a plain
      neural network on the highly imbalanced IEEE-CIS fraud dataset.
  ∙Ran an edge-type ablation across five identifier types, showing the graph adds 0.016 AUC over a no-edge baseline and
     that card links alone deliver almost all of that gain on the held-out test set.
   ∙Prevented data leakage by fitting the feature scaler on the training split only and tuning decision thresholds on validation
      data, then reporting final results only on a held-out 15% test set.

RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
  ∙Wrote RIPPLE, a command-line AI agent that predicts the files and tests a Python code change will affect.
   ∙Evaluated the agent on 30 unseen tasks from 16 real code repositories with zero unsupported claims accepted.
   ∙Integrated seven code-analysis tools into the agent’s tool-calling loop under a cap of 25 calls per task.
   ∙Implemented RIPPLE with Claude Code, checking its generated code by running RIPPLE’s 241-test suite.

LedgerFlow: Event-Driven Payment Ledger | Java, Kafka, PostgreSQL | GitHub                        October 2026
   ∙Designed a payment API and a double-entry ledger as two Java services that talk through Kafka.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Configured a GitHub Actions CI workflow that runs all 94 of the ledger’s tests.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, Java, SQL, PostgreSQL, MySQL
  ∙Frameworks & Libraries: PyTorch, TensorFlow, NumPy, Pandas, scikit-learn
  ∙AI/ML: Machine Learning, Data Preprocessing, GNNs, Model Evaluation, Deep Learning, Agentic AI, LLM Integration
   ∙Software Engineering: Application Monitoring, Data Modeling, Unit Testing, Data Validation
   ∙Tools: AWS (EC2/RDS), Apache Kafka, GitHub Actions, Git, Claude Code, Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Jr. Machine Learning (ML) Developer role at Laminar. I want to build machine learning models that turn noisy, real-world sensor data into reliable insight for Laminar's industrial customers. At Thesis Mumbai Tech, I built a real-time WebSocket and Redis pipeline that streamed IoT baby-warmer device data into PostgreSQL with about 2-second live monitoring.

In my fraud-detection project, I trained graph neural networks in PyTorch on highly imbalanced transaction data. GraphSAGE reached 0.9259 AUC-ROC, against about 0.858 for a plain neural-network baseline. I also built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. On 30 unseen tasks from 16 repositories, it accepted zero unsupported claims into its reports. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to design and run experiments to evaluate and select machine learning models at Laminar, building on my fraud-model ablation study.

Sincerely,
Jay Niketan Pathare
```

---

## 11. Macy's | Macy's 2027 Tech Early Careers - Software Engineer

Pipeline v3.4.8c; file key Macy_s_Macy_s_2027_Tech_Early_Careers_Software_Engineer; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- student_audience: The program is aimed at students with school left after the program; Jay graduates in December 2026. ("- Rising seniors majoring in Computer Science, Computer Engineering, or a related field with strong academic performance are encouraged to apply. Minimum 3.0 GP")
- enrollment_required: The internship starts after Jay's December 2026 graduation; Jay can start work in February 2027. ("Macy's 2027 Tech Early Careers - Software Engineer")

### JOB POSTING
Macy's 2027 Tech Early Careers - Software Engineer
Macy's
Johns Creek, GA | Entry Level | Onsite | Full Time | Software Engineering
Education: Bachelor's (required)

Job Overview
The Macy's Technology Summer Internship Program provides students with the opportunity to apply classroom knowledge in a real-world setting while exploring a potential engineering career within our organization. Macy's Tech combines the entrepreneurial spirit of a start-up with the stability of an iconic national brand, powered by a strong national footprint, a robust e-commerce business, and a seamless mobile experience that connects it all. Our technology team supports millions of customers in connected commerce across Macy's expansive technology hub.

What You Will Do
- Work alongside mentors and experienced engineers in an agile environment.
- Contribute to clearly defined projects that drive innovation and business impact.
- Collaborate with cross-functional teams and leaders across the organization.
- Gain exposure to a wide range of technologies and development areas, including:
 - Software Development: Java, JavaScript, Node.js, Angular.js, Vue.js, React.js, SRE, etc.
 - Mobile Development: iOS, Swift, Android, SDK, etc.
 - Cloud Development: Azure, AWS, GCP, etc.
 - Compute and Operations: Python, SQL, Unix/Linux, etc.
- Foster an environment of acceptance and respect that strengthens relationships, and ensures authentic connections with colleagues, customers, and communities.
- In addition to the essential duties mentioned above, other duties may be assigned.

Skills You Will Need
- Technical Proficiency & Programming Knowledge: Able to apply knowledge of programming languages (Java preferred), operating systems, and data processing to solve real-world challenges.
- Software Development Lifecycle Understanding: Familiar with Agile or similar methodologies, with the ability to contribute effectively to iterative development projects.
- Analytical & Business Acumen: Able to analyze data to identify trends, inform decisions, and understand the intersection of technology and retail business strategy.
- Collaboration & Communication: Skilled in working with cross-functional teams, with excellent written and verbal communication abilities to articulate ideas clearly and effectively.
- Leadership & Initiative: Demonstrates intellectual curiosity, self-motivation, and the ability to take ownership of tasks while driving results through collaboration and influence.
- Detail Orientation & Execution: Maintains strong organizational skills and attention to detail to ensure accurate, high-quality work and dependable follow-through.

Who You Are
- Rising seniors majoring in Computer Science, Computer Engineering, or a related field with strong academic performance are encouraged to apply. Minimum 3.0 GPA required.
- Regularly required to sit, talk, hear; use hands/fingers to touch, handle, and feel. Occasionally required to move about the workplace and reach with hands and arms. Requires close vision.
- Able to work a flexible schedule based on department and company needs.

[Company story, "About Us" and equal-opportunity text removed]

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
               Master’s CS student building Java software and full-stack applications with collaborative teams.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision
      (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, restricting access with VPC networking and security groups.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka | GitHub                        October 2026
  ∙Wrote a transactional outbox, idempotent Kafka consumers, and a reconciliation check in Java so that a payment is never
     recorded twice or lost when a message is repeated or retried.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Verified the Java payment ledger in a GitHub Actions CI workflow that runs all 94 of its tests, including integration tests
     that run against real PostgreSQL and Kafka instances in containers.

LaunchOps: Employee Onboarding Platform | Django, ReactJS, Python, JavaScript | GitHub           March 2026
   ∙Designed a Django REST and React onboarding platform with a 20-task workflow across HR, IT, and managers.
   ∙Enforced server-side checks that block forged evidence, skipped prerequisites, and duplicate submissions.
   ∙Created a live-quiz service in Go that runs as two copies behind nginx, with Redis coordinating both copies and a unique
     database index that rejects duplicate answers in live sessions.

Pintos Operating System: User Programs Layer | C, x86, Operating Systems, Concurrency             May 2026
   ∙Implemented a teaching operating system’s user-programs layer in C, passing all 80 tests for program startup with
     arguments, parent-child waiting, system calls, and file handling.
  ∙Programmed the system-call interface that lets user programs open and manage files and processes through the kernel,
     supporting 13 system calls and up to 128 open files per process.

TECHNICAL SKILLS
  ∙Languages & Databases: Java, Python, JavaScript, SQL, C, Go, PostgreSQL, MySQL
  ∙Frameworks & Libraries: Django REST Framework, Django, ReactJS, Spring Boot
   ∙Software Engineering:  SDLC,  Agile,  Operating Systems, Data  Pipelines,  Application Monitoring,  Full-Stack
     Development, REST APIs, Parallel Processing, Concurrency, Unit Testing
   ∙Tools: AWS (EC2/RDS), Redis, Apache Kafka, GitHub Actions, nginx, Linux, Git, Docker, WebSockets

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Macy's 2027 Tech Early Careers - Software Engineer role. I want to contribute to clearly defined projects for Macy's connected commerce technology, which serves millions of customers. At Data Maven, I deployed backend services on AWS EC2 and RDS with VPC networking and security groups, and automated provisioning cut setup time by about 40%.

LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, it never overdrew the account. LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Server-side rules reject forged evidence, skipped prerequisites, and duplicate submissions. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to build dependable, well-tested software with the team at Macy's, drawing on LedgerFlow, where a GitHub Actions CI workflow runs every automated test.

Sincerely,
Jay Niketan Pathare
```

---

## 12. Quora | Machine Learning Engineer, New Grad

Pipeline v3.4.8c; file key Quora_Machine_Learning_Engineer_New_Grad; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Machine Learning Engineer, New Grad - Quora (Remote)
Location

Remote - Multiple Locations; Canada; United States
Employment Type

Full time
Location Type

Remote
Department

Engineering

OverviewApplication

*[Quora is a privately held, "remote-first" company. This position can be performed remotely from anywhere in the US or Canada. Please visit careers.quora.com/eligible-countries for details regarding employment eligibility by country.]*
About Quora:

Quora's mission is to grow the world's collective intelligence. To do so, we have two platforms:

- Quora: a global knowledge sharing platform with millions of monthly unique visitors, bringing people together to share insights on various topics and providing a unique platform to learn and connect with others.
- Poe: a cloud workspace where millions of users run multiple AI agents on shared context and tools. One subscription, every frontier model, and the collaboration layer that makes them work together.

This role will be working on our Quora product.
About the Team and Role:

Our ML team is small and highly collaborative, working on challenging problems that impact hundreds of millions of Quora users. With over 100 ML models in production, engineers have opportunities to take ownership of meaningful projects.

We're building the next generation of AI-powered systems to improve content quality and safety across Quora. By leveraging LLMs and agentic workflows, we're transforming how we detect harmful content, automate complex decisions, and respond to evolving challenges at scale. As a Machine Learning Engineer (New Grad), you'll work alongside experienced engineers to design, evaluate, and deploy these systems in production.

No previous trust and safety experience is required. You'll learn from the engineers who built these systems.

Stack: Python, PyTorch, TensorFlow, Spark, Kubernetes
Responsibilities:

- Design, build, and deploy LLM-powered agents to detect and address spam, harassment, and other policy-violating content at Quora's scale
- Develop agentic workflows to automate complex tasks, improving the efficiency and effectiveness of our content and user moderation systems
- Design and improve ML systems that adapt to evolving abuse patterns and new challenges
- Evaluate agent performance through offline evaluations, online experiments, and production monitoring, balancing accuracy, reliability, latency, and cost
- Investigate failure cases, experiment with new approaches, and iterate on solutions to improve system performance
- Identify new opportunities to apply ML and LLMs to content quality and safety across Quora
- Collaborate with experienced engineers and take ownership of projects from early development through production
Minimum Requirements:

- Availability for meetings and impromptu communication during Quora's "coordination hours" (Mon-Fri: 9am-3pm Pacific Time)
- B.S., M.S., or Ph.D. in Computer Science, Engineering or a related technical field, completed or in progress
- Strong understanding of mathematical foundations of Machine Learning algorithms
- Coursework, research, or project experience with LLM applications or transformer models
- Strong knowledge of Python
- A passion for learning and always improving yourself and the team around you
- Able to start full-time in early 2027
Preferred Requirements:

- Previous software engineering experience via an internship, work experience, open-source contribution or coding competition
- Hands-on experience building and evaluating LLM agents, in projects, research, internships, or production
- Regular use of AI coding tools such as Claude Code or Codex
- Coursework or projects in natural language processing (NLP)
- Genuine interest in content safety and quality
- Passion for Quora's mission and goals
Additional Information:

- US candidates only: For US based applicants, the salary range is $107,360 - $152,900 USD + equity + benefits.
- Canada candidates only: For Toronto and Vancouver based applicants, the salary range is $137,852 - $157,061 CAD + equity + benefits. For all other locations in Canada, the salary range is $128,661 - $146,590 CAD + equity + benefits.

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
               Master’s CS student building AI agents, ML models, and evidence-driven evaluation pipelines.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY
Relevant coursework: Agentic AI, Machine Learning, Deep Learning

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered an LLM document-extraction pipeline that pulls metadata from 28k+ pages of law journals using OCR/LLM
      vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B), CrossRef API, and web scrapers.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
  ∙Added confidence scoring that flags low-confidence fields for human review, and parallelized the pipeline with a CPU-based
     worker pool, cutting total processing time by over 80%.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules: gathered requirements in client meetings,
     prototyped to validate scope, and broke the finalized work into tasks.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

PERSONAL PROJECTS
RIPPLE: Agentic Change-Impact Analysis | Python, Python AST, Git, Pydantic | GitHub              August 2026
   ∙Designed RIPPLE, a Python command-line AI agent that reads a plain-English change request and predicts which files,
       tests, and regression risks it will touch before any code is written.
   ∙Evaluated the agent on 30 unseen tasks from 16 real code repositories with zero unsupported claims accepted.
   ∙Integrated seven code-analysis tools into the agent’s tool-calling loop under a cap of 25 calls per task.
  ∙Wrote RIPPLE with Claude Code as a coding assistant, checking its output with RIPPLE’s 241-test suite and testing
    how the agent handles edge cases across the real code repositories it analyzes.

Fraud Detection using Graph Neural Networks | PyTorch, GraphSAGE | GitHub                           April 2026
   ∙Benchmarked a GraphSAGE graph neural network at 0.9259 AUC-ROC against a baseline of about 0.858 from a plain
      neural network on the highly imbalanced IEEE-CIS fraud dataset.
  ∙Ran an edge-type ablation across five identifier types, showing the graph adds 0.016 AUC over a no-edge baseline and
     that card links alone deliver almost all of that gain on the held-out test set.
   ∙Prevented data leakage by fitting the feature scaler on the training split only and tuning decision thresholds on validation
      data, then reporting final results only on a held-out 15% test set.

GoingOnce: Multi-Agent Car Marketplace | Python, LangGraph, ReactJS, Streamlit | GitHub           October 2026
   ∙Prototyped a multi-agent car marketplace with a four-person team: Buy, Sell, Negotiate, and Fleet agents, plus a human
    who approves every simulated bid or listing before it goes through.
  ∙Kept search, history checks, pricing, negotiation math, and logistics in plain code, calling Claude only for language and
     photos with a saved fallback for every call, so results repeat.

TECHNICAL SKILLS
  ∙Languages & Databases: Python, SQL, PostgreSQL
  ∙Frameworks & Libraries: PyTorch, TensorFlow, LangGraph, ReactJS, Streamlit
  ∙AI/ML: Machine Learning, LLMs, LLM Integration, Agentic Workflows, AI Agents, GNNs, Model Evaluation, Deep
     Learning, Tool Calling
   ∙Software Engineering: Algorithms, Production Deployment, Application Monitoring, Data Modeling
   ∙Tools: Kubernetes (local k3d), Git, Claude API, Claude Code, AWS (EC2/RDS), Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Machine Learning Engineer, New Grad role at Quora. I want to help detect harmful content, automate complex decisions, and keep Quora's knowledge platform useful with LLMs and agentic workflows. At HeinOnline, I built a pipeline that combined the CrossRef API, web scrapers, and OCR/LLM vision to extract metadata from 28k+ pages of law journals with about 91% accuracy.

I built RIPPLE, a Python AI agent that predicts which files and tests a code change will affect before any code is written. Claude Code helped me write it, and I checked its output by running RIPPLE's 241-test suite. In my fraud-detection project, I trained graph neural networks in PyTorch on highly imbalanced transaction data. GraphSAGE reached 0.9259 AUC-ROC, against about 0.858 for a plain neural-network baseline. I graduate in December 2026 and can start work in February 2027. I want to design and improve ML systems at Quora, building on RIPPLE, an AI agent that accepted no unsupported claims on unseen tasks.

Sincerely,
Jay Niketan Pathare
```

---

## 13. Twitch | Software Engineer I

Pipeline v3.4.8c; file key Twitch_Software_Engineer_I; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Software Engineer I
Twitch
San Francisco, CA | USD 127k - 185k /yr | Entry Level | Onsite | Full Time | Software Engineering
Education: Bachelor's (required)

About the Role
Join Twitch's Commerce Engineering organization, where we're building rewarding experiences that allow creators to make a living doing what they love. We're behind our continuous patronage features, including channel Subscriptions, Gifting, and Turbo. As a member of the team, you'll work alongside highly engaged, collaborative engineers to design, build, and maintain systems that scale to millions of concurrent users. We actively seek to improve our experiences, and we're looking for people who are passionate about our end users.

Our team is based in San Francisco, CA.

You Will:
- Create interactive experiences that are rewarding for both viewers and creators
- Architect and build robust, scalable applications that can handle millions of concurrent users
- Participate in Operational Excellence work to maintain and support our live services
- Collaborate with fellow engineers, product managers and designers to build new products and solutions

You Have:
- Previous experience building scalable systems
- Excellent proficiency in modern programming languages (Python, Java, Go) and distributed system technologies
- A track record of building product experiences that users love
- Sharp problem-solving skills with a focus on algorithms, data structures, and distributed system design
- Bachelor's degree in Computer Science, Engineering, or equivalent real-world experience

Bonus Points
- Familiarity with Twitch's tech stack: Golang, TypeScript/React
- Experience working with mobile development, either native or hybrid
- Experience with AWS technologies like ECS, DynamoDB, Lambda, SQS, and Step Functions
- A passion for gaming, streaming, or the Twitch platform

Base salary range: $127,100 - $185,000 USD
[Company description, perks, privacy and legal text removed]

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                 Master’s CS student building distributed systems and reliable applications for live services.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant metadata extraction pipeline combining CrossRef API, web scrapers, and OCR/LLM vision
      (Tesseract, Qwen3-VL 8B, Qwen3.5-35B) to process 28k+ pages of law journals.
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules: gathered requirements in client meetings,
     prototyped to validate scope, and broke the finalized work into tasks.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitor pinging 4 production sites every 5 minutes and restored the services it caught failing.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, PostgreSQL | GitHub           October 2026
  ∙Wrote a transactional outbox, idempotent Kafka consumers, and a reconciliation check in Java so that a payment is never
     recorded twice or lost when a message is repeated or retried.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Verified the Java payment ledger in a GitHub Actions CI workflow that runs all 94 of its tests, including integration tests
     that run against real PostgreSQL and Kafka instances in containers.

LaunchOps: Employee Onboarding Platform | Django, Python, Go, ReactJS | GitHub                 March 2026
   ∙Designed a Django REST and React onboarding platform with a 20-task workflow across HR, IT, and managers.
   ∙Enforced server-side checks that block forged evidence, skipped prerequisites, and duplicate submissions.
   ∙Implemented a real-time quiz service in Go that runs as two copies behind nginx, with Redis keeping both copies in sync
     and a unique MongoDB index rejecting duplicate answers in live sessions.

GoingOnce: Multi-Agent Car Marketplace | Python, LangGraph, ReactJS, Streamlit | GitHub           October 2026
   ∙Prototyped a multi-agent car marketplace with a four-person team: Buy, Sell, Negotiate, and Fleet agents, plus a human
    who approves every simulated bid or listing before it goes through.
   ∙Created the Streamlit and React interface for the agents’ streaming API, so users can follow all four agents live as each
      step streams in from the API, including every human approval step.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Python, Java, Go, SQL, PostgreSQL, MongoDB, MySQL
  ∙Frameworks & Libraries: ReactJS, Django, Django REST Framework, Spring Boot
   ∙Software Engineering: Algorithms, Data Structures, System Design, Distributed Systems, Concurrency, Event-Driven
      Architecture, Parallel Processing, Unit Testing, REST APIs, Full-Stack Development
   ∙Tools: AWS (EC2/RDS), Redis, Apache Kafka, GitHub Actions, nginx, Git, WebSockets, Docker

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Software Engineer I role at Twitch. I want to create interactive experiences that are rewarding for both viewers and creators in Commerce Engineering. At Thesis Mumbai Tech, I developed Patient Management and Consent modules for 10k+ records and a real-time WebSocket and Redis pipeline that streamed IoT baby-warmer data into PostgreSQL.

LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. When 200 simultaneous payment requests hit an account funded for only 50, it never overdrew the account. LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Its live-quiz service in Go runs as two copies behind nginx, with Redis keeping them in sync. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to maintain and support the live services at Twitch, drawing on the heartbeat monitor I built at Thesis Mumbai Tech, where I restored services after detected failures.

Sincerely,
Jay Niketan Pathare
```

---

## 14. United States Cold Storage | Java Developer I

Pipeline v3.4.8c; file key United_States_Cold_Storage_Java_Developer_I; experience_variants_enabled=true (score the Experience section too).

### ELIGIBILITY NOTES (shown to Jay; never a document defect)
- none

### JOB POSTING
Java Developer I
United States Cold Storage
USD 95k - 100k /yr | Entry Level | Onsite | Full Time | Software Engineering
Education: Bachelor's (required)

Who We Are
US Cold owns and operates one of the most complex temperature-controlled logistics networks in North America. Every day, our systems coordinate the storage and movement of food at national scale across a network of state-of-the-art distribution centers, including multiple highly automated warehouse facilities.

We continue to advance our core warehouse and logistics platforms. Our current focus is on modular, event-driven, API-first and cloud architecture. We continue to enhance reliability and accelerate engineering productivity by strengthening our SRE and AI practices. This is a large investment in innovation to continue to drive operational excellence at our facilities.

The Role
We are looking for a Full Stack Java Developer with experience building performant, scalable, reliable, and testable software for our warehouse management systems. You are expected to be a hands-on developer who has built mission critical systems using Java and front-end technologies. You should have demonstrable experience applying software design patterns to solve complex problems and have worked within an Agile Scrum model.

You will report to the Associate Director of Software Development in this role.

What You Will Own
- Strong Core Java knowledge
- Hands on participation in design, coding, and testing
- Experience with various back-end micro-services frameworks (Spring)
- Experience with JavaScript as well as some front-end stacks such as Angular or React
- Experience working with test driven development
- Experience working within a continuous delivery framework
- Experience working in a SCRUM team

Technical Environment
- Proven experience in Java and Web development technologies
- Knowledge of relational databases such as Oracle and SQL server and ORM technologies (Hibernate)
- Strong knowledge of JavaScript and popular JavaScript libraries (TypeScript and Angular, specifically)
- Working knowledge of REST frameworks
- Working experience with one or more web application servers
- Experience with Maven and Git
- Experience with Atlassian tools (Confluence, Jira)
- Experience in Supply Chain Logistics is a plus

What We're Looking For
Education: BS degree in Computer Science or a related subject

Compensation & Structure
- Salary Range: $95,000 - $100,000 per year
- Location: Hybrid, Camden, NJ
- Travel: Less than 10%
- Reports to: Associate Director Software Development

Operational Context
This role is primarily technical and office-based, with occasional interaction in operational environments depending on system needs.

[Benefits list, physical and operational boilerplate, and additional-information text removed]

### RESUME (PDF text, PyMuPDF layout-aware)
```text
Jay Niketan Pathare
                  jayadmit456@gmail.com | +1(716)303-9924 | NY, US | Portfolio | LinkedIn | GitHub
                        Master’s CS student building reliable Java, Spring, and React applications.

EXPERIENCE
Software Engineer Practicum | HeinOnline (University at Buffalo), Buffalo, NY             January 2026 – April 2026
   ∙Engineered a fault-tolerant data pipeline that processed 28k+ pages of law journals, combining CrossRef API, web scrapers,
     and OCR/LLM vision (Tesseract, Qwen3-VL 8B, Qwen3.5-35B).
  ∙Merged all three sources into one validated structure with fuzzy matching, cutting manual data entry by ∼90% and
     pushing extraction accuracy to about 91% over five iterations, benchmarked against ground truth.
   ∙Parallelized the pipeline with a CPU-based worker pool that pulls journals from a shared queue, cutting total processing
     time by over 80%, and added confidence scoring to flag low-confidence fields for human review.
   ∙Standardized author names by matching them to HeinOnline’s 500+ authors in PostgreSQL, even when spelled differently.

Software Engineer | Thesis Mumbai Tech (Startup), Mumbai, India                         August 2024 – August 2025
  ∙Led a team of 4 through end-to-end delivery of healthcare platform modules using Agile/Scrum: gathered requirements
      in client meetings, prototyped to validate scope, and reviewed and merged team pull requests.
   ∙Developed Patient Management and Consent modules on normalized schemas for 10k+ records, plus a real-time WebSocket
   + Redis pipeline streaming IoT baby-warmer data into PostgreSQL with ∼2s live monitoring.
   ∙Delivered a WebRTC telemedicine feature that let remote doctors review test results with patients and on-site nurses,
      plus PDF report generation and a color-blindness diagnostic module (95%+ accuracy) with automated reporting.
   ∙Containerized 3+ production projects with Docker Compose for consistent local, staging, and deployment environments.
   ∙Built a heartbeat monitoring dashboard for 4 production projects, pinging each site every 5 minutes to track health.
   ∙Interviewed about 20 student candidates and onboarded the new hires, mentoring them through weekly coding rounds
      over their first 3 weeks and introducing them to the production projects and tech stack.

Cloud Engineer Intern | Data Maven Pvt Ltd, Mumbai, India                           November 2023 – May 2024
   ∙Deployed backend services on AWS EC2 and RDS, using VPC networking and security groups to restrict access.
   ∙Automated cloud resource provisioning, cutting setup time by ∼40% and reducing deployment issues.

Data Engineer Intern | Go Digital Technology Consulting, Mumbai, India                    June 2023 – August 2023
   ∙Authored a Python (Pandas, NumPy) and MySQL ETL workflow to clean and standardize transaction and ledger data
     and generate automated anomaly reports for the compliance and audit team.

PERSONAL PROJECTS
LedgerFlow: Event-Driven Payment Ledger | Java, Spring Boot, Kafka, Maven | GitHub                October 2026
  ∙Wrote a transactional outbox, idempotent Kafka consumers, and a reconciliation check in Java so that a payment is never
     recorded twice or lost when a message is repeated or retried.
   ∙Stress-tested 200 simultaneous payment requests against an account funded for only 50, with no overdraft.
   ∙Tested failure recovery in 27 runs that crashed services on purpose, all ending with zero data errors.
   ∙Verified the Java payment ledger in a GitHub Actions CI workflow that runs all 94 of its tests, including integration tests
     that run against real PostgreSQL and Kafka instances in containers.

LaunchOps: Employee Onboarding Platform | Django, ReactJS, JavaScript | GitHub                  March 2026
   ∙Designed a Django REST and React onboarding platform with a 20-task workflow across HR, IT, and managers.
   ∙Implemented a live-quiz service in Go that runs as two copies behind nginx, kept in sync through Redis.
   ∙Enforced server-side rules that reject forged evidence, skipped prerequisites, duplicate submissions, and edits to other
      users’ tasks, and hold completion while support issues stay open.

GoingOnce: Multi-Agent Car Marketplace | Python, LangGraph, ReactJS | GitHub                     October 2026
   ∙Prototyped a multi-agent car marketplace with a four-person team: Buy, Sell, Negotiate, and Fleet agents, plus a human
    who approves every simulated bid or listing before it goes through.
  ∙Programmed the Fleet agent, which checks market demand, spreads 120 similar rental cars across markets in full truckloads,
     and schedules pickups, so simulated prices hold and transport stays low.

EDUCATION
Master’s in Computer Science | GPA: 3.85 / 4.0                              August 2025 – Expected December 2026
University at Buffalo, The State University of New York, Buffalo, NY

Bachelor of Engineering, Information Technology                                       August 2019 – May 2023
Vivekanand Education Society’s Institute of Technology, Mumbai University, India

TECHNICAL SKILLS
  ∙Languages & Databases: Java, JavaScript, SQL, Go, Python, Relational Databases, PostgreSQL, MySQL
  ∙Frameworks & Libraries: ReactJS, Django, Django REST Framework, Spring Boot
   ∙Software Engineering:  Full-Stack Development, Software Design, Agile, Scrum, Unit Testing, Data Validation,
      Integration Testing, REST APIs, Backend Development, Event-Driven Architecture
   ∙Tools: Maven, Git, Redis, Apache Kafka, GitHub Actions, nginx, Daphne/ASGI, WebSockets, AWS (EC2/RDS)

CERTIFICATIONS & AWARDS
  ∙1st Place, ACV Auctions + Copart Challenge | AI for Good Hackathon Design Challenge, UB      October 2026
  ∙AWS Certified Cloud Practitioner                                                                      July 2024
```

### COVER LETTER
```text
Dear Hiring Manager,

I am applying for the Java Developer I role at United States Cold Storage. I want to help build performant, scalable, reliable, and testable Java software for the warehouse management systems behind cold storage operations. At Thesis Mumbai Tech, I developed Patient Management and Consent modules for 10k+ records and a real-time WebSocket and Redis pipeline that streamed IoT baby-warmer data into PostgreSQL.

LedgerFlow is my Java and Spring Boot payment ledger: a payment API and a double-entry ledger that exchange events through Kafka. A GitHub Actions CI workflow runs its 94 automated tests. LaunchOps is a Django REST and React onboarding platform I built, with a 20-task workflow across HR, IT, manager, and employee roles. Its live-quiz service in Go runs as two copies behind nginx, with Redis keeping them in sync. I graduate in December 2026 and can start work in February 2027. I am open to relocating. I want to work on design, coding, and testing at United States Cold Storage, building on LedgerFlow, where each payment takes effect exactly once.

Sincerely,
Jay Niketan Pathare
```

---
